const fs = require('fs');
const path = require('path');

// Node CJS script to generate 2026-2027 Süper Lig teams and accurate real rosters (22-26 players per team)

const teamsMetaData = [
  {
    id: 'galatasaray',
    name: 'Galatasaray',
    shortName: 'GS',
    badgeColor: 'from-amber-600 to-red-600',
    badgeTextColor: 'text-amber-300',
    secondaryColor: '#ea580c',
    stadiumName: 'RAMS Park',
    budget: 25000000,
    reputation: 5,
    formation: '4-2-3-1',
    tactic: 'ATTACKING',
    baseRating: 82,
    basePlayers: [
      { name: 'Uğurcan Çakır', age: 30, pos: 'GK', role: 'GK', ovr: 81, nat: 'Türkiye', start: true },
      { name: 'Wilfried Singo', age: 25, pos: 'DEF', role: 'RB', ovr: 80, nat: 'Fildişi Sahili', start: true },
      { name: 'Davinson Sánchez', age: 30, pos: 'DEF', role: 'CB', ovr: 84, nat: 'Kolombiya', start: true },
      { name: 'Abdülkerim Bardakcı', age: 31, pos: 'DEF', role: 'CB', ovr: 80, nat: 'Türkiye', start: true },
      { name: 'Eren Elmalı', age: 26, pos: 'DEF', role: 'LB', ovr: 76, nat: 'Türkiye', start: true },
      { name: 'Lucas Torreira', age: 30, pos: 'MID', role: 'CDM', ovr: 83, nat: 'Uruguay', start: true },
      { name: 'İlkay Gündoğan', age: 35, pos: 'MID', role: 'CM', ovr: 84, nat: 'Almanya', start: true },
      { name: 'Gabriel Sara', age: 27, pos: 'MID', role: 'CAM', ovr: 82, nat: 'Brezilya', start: true },
      { name: 'Leroy Sané', age: 30, pos: 'FW', role: 'RW', ovr: 84, nat: 'Almanya', start: true },
      { name: 'Barış Alper Yılmaz', age: 26, pos: 'FW', role: 'LW', ovr: 83, nat: 'Türkiye', start: true },
      { name: 'Victor Osimhen', age: 27, pos: 'FW', role: 'ST', ovr: 87, nat: 'Nijerya', start: true },
      { name: 'Günay Güvenç', age: 35, pos: 'GK', role: 'GK', ovr: 75, nat: 'Türkiye', start: false },
      { name: 'Victor Nelsson', age: 27, pos: 'DEF', role: 'CB', ovr: 79, nat: 'Danimarka', start: false },
      { name: 'Kaan Ayhan', age: 31, pos: 'DEF', role: 'CB', ovr: 78, nat: 'Türkiye', start: false },
      { name: 'Elias Jelert', age: 23, pos: 'DEF', role: 'RB', ovr: 77, nat: 'Danimarka', start: false },
      { name: 'Ismail Jakobs', age: 27, pos: 'DEF', role: 'LB', ovr: 77, nat: 'Senegal', start: false },
      { name: 'Kazımcan Karataş', age: 23, pos: 'DEF', role: 'LB', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Mario Lemina', age: 32, pos: 'MID', role: 'CDM', ovr: 79, nat: 'Gabon', start: false },
      { name: 'Lesley Ugochukwu', age: 22, pos: 'MID', role: 'CDM', ovr: 78, nat: 'Fransa', start: false },
      { name: 'Eyüp Aydın', age: 22, pos: 'MID', role: 'CDM', ovr: 72, nat: 'Almanya', start: false },
      { name: 'Yunus Akgün', age: 26, pos: 'FW', role: 'RW', ovr: 80, nat: 'Türkiye', start: false },
      { name: 'Roland Sallai', age: 29, pos: 'FW', role: 'RW', ovr: 78, nat: 'Macaristan', start: false },
      { name: 'Jankat Yılmaz', age: 21, pos: 'GK', role: 'GK', ovr: 69, nat: 'Türkiye', start: false },
      { name: 'Ali Turap Bülbül', age: 21, pos: 'DEF', role: 'RB', ovr: 69, nat: 'Türkiye', start: false },
      { name: 'Can Armando Güner', age: 18, pos: 'FW', role: 'ST', ovr: 68, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'fenerbahce',
    name: 'Fenerbahçe',
    shortName: 'FB',
    badgeColor: 'from-yellow-400 to-blue-900',
    badgeTextColor: 'text-yellow-300',
    secondaryColor: '#1e3a8a',
    stadiumName: 'Ülker Stadyumu',
    budget: 22000000,
    reputation: 5,
    formation: '4-2-3-1',
    tactic: 'ATTACKING',
    baseRating: 82,
    basePlayers: [
      { name: 'Ederson', age: 32, pos: 'GK', role: 'GK', ovr: 86, nat: 'Brezilya', start: true },
      { name: 'Nélson Semedo', age: 32, pos: 'DEF', role: 'RB', ovr: 79, nat: 'Portekiz', start: true },
      { name: 'Milan Skriniar', age: 31, pos: 'DEF', role: 'CB', ovr: 82, nat: 'Slovakya', start: true },
      { name: 'Nathan Aké', age: 31, pos: 'DEF', role: 'CB', ovr: 83, nat: 'Hollanda', start: true },
      { name: 'Jayden Oosterwolde', age: 25, pos: 'DEF', role: 'LB', ovr: 79, nat: 'Hollanda', start: true },
      { name: 'N\'Golo Kanté', age: 35, pos: 'MID', role: 'CDM', ovr: 83, nat: 'Fransa', start: true },
      { name: 'Fred', age: 33, pos: 'MID', role: 'CM', ovr: 82, nat: 'Brezilya', start: true },
      { name: 'Mason Greenwood', age: 24, pos: 'FW', role: 'RW', ovr: 83, nat: 'İngiltere', start: true },
      { name: 'Anderson Talisca', age: 32, pos: 'MID', role: 'CAM', ovr: 82, nat: 'Brezilya', start: true },
      { name: 'Kerem Aktürkoğlu', age: 27, pos: 'FW', role: 'LW', ovr: 81, nat: 'Türkiye', start: true },
      { name: 'Vedat Muriç', age: 32, pos: 'FW', role: 'ST', ovr: 79, nat: 'Kosova', start: true },
      { name: 'Mert Günok', age: 37, pos: 'GK', role: 'GK', ovr: 80, nat: 'Türkiye', start: false },
      { name: 'Diego Carlos', age: 33, pos: 'DEF', role: 'CB', ovr: 80, nat: 'Brezilya', start: false },
      { name: 'Çağlar Söyüncü', age: 30, pos: 'DEF', role: 'CB', ovr: 79, nat: 'Türkiye', start: false },
      { name: 'Mert Müldür', age: 27, pos: 'DEF', role: 'RB', ovr: 77, nat: 'Türkiye', start: false },
      { name: 'Archie Brown', age: 24, pos: 'DEF', role: 'LB', ovr: 77, nat: 'İngiltere', start: false },
      { name: 'Rodrigo Becão', age: 30, pos: 'DEF', role: 'CB', ovr: 79, nat: 'Brezilya', start: false },
      { name: 'Levent Mercan', age: 25, pos: 'DEF', role: 'LB', ovr: 74, nat: 'Türkiye', start: false },
      { name: 'İsmail Yüksek', age: 27, pos: 'MID', role: 'CDM', ovr: 79, nat: 'Türkiye', start: false },
      { name: 'Matteo Guendouzi', age: 27, pos: 'MID', role: 'CM', ovr: 81, nat: 'Fransa', start: false },
      { name: 'Marco Asensio', age: 30, pos: 'MID', role: 'CAM', ovr: 83, nat: 'İspanya', start: false },
      { name: 'İrfan Can Kahveci', age: 31, pos: 'MID', role: 'RW', ovr: 81, nat: 'Türkiye', start: false },
      { name: 'Mert Hakan Yandaş', age: 31, pos: 'MID', role: 'CM', ovr: 75, nat: 'Türkiye', start: false },
      { name: 'Cengiz Ünder', age: 29, pos: 'FW', role: 'RW', ovr: 77, nat: 'Türkiye', start: false },
      { name: 'Oğuz Aydın', age: 25, pos: 'FW', role: 'LW', ovr: 76, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'besiktas',
    name: 'Beşiktaş',
    shortName: 'BJK',
    badgeColor: 'from-gray-900 to-black',
    badgeTextColor: 'text-white',
    secondaryColor: '#171717',
    stadiumName: 'Tüpraş Stadyumu',
    budget: 18000000,
    reputation: 5,
    formation: '4-2-3-1',
    tactic: 'ATTACKING',
    baseRating: 80,
    basePlayers: [
      { name: 'Alexander Nübel', age: 29, pos: 'GK', role: 'GK', ovr: 82, nat: 'Almanya', start: true },
      { name: 'Michael Murillo', age: 30, pos: 'DEF', role: 'RB', ovr: 78, nat: 'Panama', start: true },
      { name: 'Emmanuel Agbadou', age: 29, pos: 'DEF', role: 'CB', ovr: 80, nat: 'Fildişi Sahili', start: true },
      { name: 'Felix Uduokhai', age: 28, pos: 'DEF', role: 'CB', ovr: 78, nat: 'Almanya', start: true },
      { name: 'Rıdvan Yılmaz', age: 25, pos: 'DEF', role: 'LB', ovr: 77, nat: 'Türkiye', start: true },
      { name: 'Wilfred Ndidi', age: 29, pos: 'MID', role: 'CDM', ovr: 81, nat: 'Nijerya', start: true },
      { name: 'Salih Özcan', age: 28, pos: 'MID', role: 'CM', ovr: 78, nat: 'Türkiye', start: true },
      { name: 'Václav Černý', age: 28, pos: 'FW', role: 'RW', ovr: 78, nat: 'Çekya', start: true },
      { name: 'Orkun Kökçü', age: 25, pos: 'MID', role: 'CAM', ovr: 83, nat: 'Türkiye', start: true },
      { name: 'Leandro Trossard', age: 31, pos: 'FW', role: 'LW', ovr: 82, nat: 'Belçika', start: true },
      { name: 'Semih Kılıçsoy', age: 20, pos: 'FW', role: 'ST', ovr: 80, nat: 'Türkiye', start: true },
      { name: 'Doğan Alemdar', age: 23, pos: 'GK', role: 'GK', ovr: 75, nat: 'Türkiye', start: false },
      { name: 'Tiago Djaló', age: 26, pos: 'DEF', role: 'CB', ovr: 77, nat: 'Portekiz', start: false },
      { name: 'Emirhan Topçu', age: 25, pos: 'DEF', role: 'CB', ovr: 77, nat: 'Türkiye', start: false },
      { name: 'Yasin Özcan', age: 20, pos: 'DEF', role: 'CB', ovr: 76, nat: 'Türkiye', start: false },
      { name: 'Kassoum Ouattara', age: 21, pos: 'DEF', role: 'LB', ovr: 76, nat: 'Fransa', start: false },
      { name: 'Amir Hadziahmetovic', age: 29, pos: 'MID', role: 'CDM', ovr: 76, nat: 'Bosna Hersek', start: false },
      { name: 'Kartal Kayra Yılmaz', age: 25, pos: 'MID', role: 'CM', ovr: 74, nat: 'Türkiye', start: false },
      { name: 'Junior Olaitan', age: 24, pos: 'MID', role: 'CAM', ovr: 74, nat: 'Benin', start: false },
      { name: 'Milot Rashica', age: 30, pos: 'FW', role: 'RW', ovr: 78, nat: 'Kosova', start: false },
      { name: 'Hyeongyu Oh', age: 25, pos: 'FW', role: 'ST', ovr: 77, nat: 'Güney Kore', start: false },
      { name: 'Mustafa Hekimoğlu', age: 19, pos: 'FW', role: 'ST', ovr: 74, nat: 'Türkiye', start: false },
      { name: 'Emre Bilgin', age: 22, pos: 'GK', role: 'GK', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Fahri Kerem Ay', age: 21, pos: 'MID', role: 'CM', ovr: 70, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'trabzonspor',
    name: 'Trabzonspor',
    shortName: 'TS',
    badgeColor: 'from-red-800 to-sky-700',
    badgeTextColor: 'text-sky-300',
    secondaryColor: '#991b1b',
    stadiumName: 'Papara Park',
    budget: 12000000,
    reputation: 4,
    formation: '4-2-3-1',
    tactic: 'BALANCED',
    baseRating: 78,
    basePlayers: [
      { name: 'André Onana', age: 30, pos: 'GK', role: 'GK', ovr: 83, nat: 'Kamerun', start: true },
      { name: 'Samet Akaydin', age: 32, pos: 'DEF', role: 'CB', ovr: 75, nat: 'Türkiye', start: true },
      { name: 'Stefan Savic', age: 36, pos: 'DEF', role: 'CB', ovr: 78, nat: 'Karadağ', start: true },
      { name: 'Cenk Özkacar', age: 26, pos: 'DEF', role: 'CB', ovr: 76, nat: 'Türkiye', start: true },
      { name: 'Sidny Lopes Cabral', age: 24, pos: 'DEF', role: 'RB', ovr: 74, nat: 'Yeşil Burun A.', start: true },
      { name: 'Batista Mendy', age: 27, pos: 'MID', role: 'CDM', ovr: 78, nat: 'Fransa', start: true },
      { name: 'Okay Yokuşlu', age: 32, pos: 'MID', role: 'CDM', ovr: 77, nat: 'Türkiye', start: true },
      { name: 'Ruslan Malinovskyi', age: 33, pos: 'MID', role: 'CAM', ovr: 78, nat: 'Ukrayna', start: true },
      { name: 'Ernest Muçi', age: 25, pos: 'MID', role: 'CAM', ovr: 77, nat: 'Arnavutluk', start: true },
      { name: 'Mohamed Salah Ghaly', age: 34, pos: 'FW', role: 'RW', ovr: 87, nat: 'Mısır', start: true },
      { name: 'Ebere Paul Onuachu', age: 32, pos: 'FW', role: 'ST', ovr: 80, nat: 'Nijerya', start: true },
      { name: 'Onuralp Çevikkan', age: 21, pos: 'GK', role: 'GK', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Arseniy Batagov', age: 24, pos: 'DEF', role: 'CB', ovr: 75, nat: 'Ukrayna', start: false },
      { name: 'Mustafa Eskihellaç', age: 29, pos: 'DEF', role: 'RB', ovr: 74, nat: 'Türkiye', start: false },
      { name: 'Wagner Fabrício Cardoso Pina', age: 24, pos: 'DEF', role: 'RB', ovr: 72, nat: 'Yeşil Burun A.', start: false },
      { name: 'Chibuike Godfrey Nwaiwu', age: 23, pos: 'DEF', role: 'CB', ovr: 72, nat: 'Nijerya', start: false },
      { name: 'John Lundstram', age: 32, pos: 'MID', role: 'CDM', ovr: 76, nat: 'İngiltere', start: false },
      { name: 'Ozan Tufan', age: 31, pos: 'MID', role: 'CM', ovr: 76, nat: 'Türkiye', start: false },
      { name: 'Tim Jabol Folcarelli', age: 27, pos: 'MID', role: 'CM', ovr: 74, nat: 'Fransa', start: false },
      { name: 'Benjamin Bouchouari', age: 25, pos: 'MID', role: 'CM', ovr: 75, nat: 'Fas', start: false },
      { name: 'Aral Şimşir', age: 24, pos: 'MID', role: 'CAM', ovr: 75, nat: 'Türkiye', start: false },
      { name: 'Denis Mihai Draguş', age: 27, pos: 'FW', role: 'ST', ovr: 76, nat: 'Romanya', start: false },
      { name: 'Umut Nayir', age: 33, pos: 'FW', role: 'ST', ovr: 75, nat: 'Türkiye', start: false },
      { name: 'Cihan Çanak', age: 22, pos: 'FW', role: 'RW', ovr: 74, nat: 'Türkiye', start: false },
      { name: 'Poyraz Efe Yıldırım', age: 22, pos: 'FW', role: 'ST', ovr: 69, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'basaksehir',
    name: 'RAMS Başakşehir',
    shortName: 'IBFK',
    badgeColor: 'from-orange-600 to-blue-900',
    badgeTextColor: 'text-orange-300',
    secondaryColor: '#ea580c',
    stadiumName: 'Fatih Terim Stadyumu',
    budget: 10000000,
    reputation: 4,
    formation: '4-3-3',
    tactic: 'BALANCED',
    baseRating: 76,
    basePlayers: [
      { name: 'Muhammed Şengezer', age: 30, pos: 'GK', role: 'GK', ovr: 76, nat: 'Türkiye', start: true },
      { name: 'Jerome Opoku', age: 28, pos: 'DEF', role: 'CB', ovr: 75, nat: 'Gana', start: true },
      { name: 'Ousseynou Ba', age: 31, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Senegal', start: true },
      { name: 'Christopher Operi', age: 29, pos: 'DEF', role: 'LB', ovr: 74, nat: 'Fildişi Sahili', start: true },
      { name: 'Onur Bulut', age: 32, pos: 'DEF', role: 'RB', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Berat Özdemir', age: 28, pos: 'MID', role: 'CDM', ovr: 75, nat: 'Türkiye', start: true },
      { name: 'Berkay Özcan', age: 28, pos: 'MID', role: 'CM', ovr: 75, nat: 'Türkiye', start: true },
      { name: 'Olivier Michel Kemen', age: 30, pos: 'MID', role: 'CM', ovr: 75, nat: 'Kamerun', start: true },
      { name: 'Abbasbek Fayzullayev', age: 23, pos: 'MID', role: 'CAM', ovr: 76, nat: 'Özbekistan', start: true },
      { name: 'Eldor Shomurodov', age: 31, pos: 'FW', role: 'ST', ovr: 77, nat: 'Özbekistan', start: true },
      { name: 'Nuno Miguel da Costa Jóia', age: 36, pos: 'FW', role: 'ST', ovr: 75, nat: 'Yeşil Burun A.', start: true },
      { name: 'Volkan Babacan', age: 38, pos: 'GK', role: 'GK', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Deniz Dilmen', age: 21, pos: 'GK', role: 'GK', ovr: 69, nat: 'Türkiye', start: false },
      { name: 'Emin Bayram', age: 23, pos: 'DEF', role: 'CB', ovr: 75, nat: 'Türkiye', start: false },
      { name: 'Michal Karbownik', age: 25, pos: 'DEF', role: 'LB', ovr: 74, nat: 'Polonya', start: false },
      { name: 'Festy Ebosele', age: 24, pos: 'DEF', role: 'RB', ovr: 74, nat: 'İrlanda', start: false },
      { name: 'Hamza Güreler', age: 20, pos: 'DEF', role: 'CB', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Ömer Ali Şahiner', age: 35, pos: 'MID', role: 'RB', ovr: 74, nat: 'Türkiye', start: false },
      { name: 'Umut Güneş', age: 26, pos: 'MID', role: 'CM', ovr: 74, nat: 'Türkiye', start: false },
      { name: 'Jakub Kałuwiński', age: 24, pos: 'MID', role: 'CM', ovr: 74, nat: 'Polonya', start: false },
      { name: 'Edin Visca', age: 36, pos: 'MID', role: 'RW', ovr: 77, nat: 'Bosna Hersek', start: false },
      { name: 'Yusuf Sarı', age: 28, pos: 'FW', role: 'RW', ovr: 76, nat: 'Türkiye', start: false },
      { name: 'Davie Selke', age: 32, pos: 'FW', role: 'ST', ovr: 75, nat: 'Almanya', start: false },
      { name: 'Bertuğ Yıldırım', age: 24, pos: 'FW', role: 'ST', ovr: 75, nat: 'Türkiye', start: false },
      { name: 'Andreas Skov Olsen', age: 27, pos: 'FW', role: 'RW', ovr: 77, nat: 'Danimarka', start: false }
    ]
  },
  {
    id: 'samsunspor',
    name: 'Samsunspor',
    shortName: 'SAM',
    badgeColor: 'from-red-600 to-red-900',
    badgeTextColor: 'text-white',
    secondaryColor: '#dc2626',
    stadiumName: '19 Mayıs Stadyumu',
    budget: 6000000,
    reputation: 3,
    formation: '4-2-3-1',
    tactic: 'ATTACKING',
    baseRating: 75,
    basePlayers: [
      { name: 'Okan Kocuk', age: 31, pos: 'GK', role: 'GK', ovr: 75, nat: 'Türkiye', start: true },
      { name: 'Logi Tomasson', age: 26, pos: 'DEF', role: 'LB', ovr: 74, nat: 'İzlanda', start: true },
      { name: 'Josafat Mendes', age: 24, pos: 'DEF', role: 'RB', ovr: 74, nat: 'İsveç', start: true },
      { name: 'Toni Borevkovic', age: 29, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Hırvatistan', start: true },
      { name: 'Yunus Emre Çift', age: 23, pos: 'DEF', role: 'CB', ovr: 72, nat: 'Türkiye', start: true },
      { name: 'Emre Kılınç', age: 32, pos: 'MID', role: 'LM', ovr: 75, nat: 'Türkiye', start: true },
      { name: 'Antoine Makoumbou', age: 28, pos: 'MID', role: 'CM', ovr: 75, nat: 'Kongo', start: true },
      { name: 'Afonso Sousa', age: 26, pos: 'MID', role: 'CAM', ovr: 75, nat: 'Portekiz', start: true },
      { name: 'Tanguy Coulibaly', age: 25, pos: 'MID', role: 'RM', ovr: 74, nat: 'Fransa', start: true },
      { name: 'Marius Mouandilmadji', age: 29, pos: 'FW', role: 'ST', ovr: 75, nat: 'Çad', start: true },
      { name: 'Arbnor Muja', age: 28, pos: 'FW', role: 'RW', ovr: 74, nat: 'Arnavutluk', start: true },
      { name: 'Bilal Bayazit', age: 27, pos: 'GK', role: 'GK', ovr: 74, nat: 'Türkiye', start: false },
      { name: 'Efe Berat Törüz', age: 20, pos: 'GK', role: 'GK', ovr: 66, nat: 'Türkiye', start: false },
      { name: 'Ali Badra A. Diabate', age: 20, pos: 'DEF', role: 'CB', ovr: 70, nat: 'Fildişi Sahili', start: false },
      { name: 'Igor Drapiński', age: 22, pos: 'DEF', role: 'CB', ovr: 71, nat: 'Polonya', start: false },
      { name: 'Enes Albak', age: 21, pos: 'DEF', role: 'LB', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Yalçın Kayan', age: 28, pos: 'MID', role: 'CM', ovr: 74, nat: 'Türkiye', start: false },
      { name: 'Celil Yüksel', age: 29, pos: 'MID', role: 'CM', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Elliot Watt', age: 26, pos: 'MID', role: 'CM', ovr: 72, nat: 'İskoçya', start: false },
      { name: 'Samed Onur', age: 24, pos: 'MID', role: 'CAM', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Elayis Tavsan', age: 25, pos: 'FW', role: 'RW', ovr: 74, nat: 'Hollanda', start: false },
      { name: 'Pape Cherif Ndiaye', age: 31, pos: 'FW', role: 'ST', ovr: 75, nat: 'Senegal', start: false },
      { name: 'Fatih Kaya', age: 27, pos: 'FW', role: 'ST', ovr: 72, nat: 'Almanya', start: false },
      { name: 'Richie Omorowa', age: 22, pos: 'FW', role: 'ST', ovr: 71, nat: 'İsveç', start: false }
    ]
  },
  {
    id: 'eyupspor',
    name: 'ikas Eyüpspor',
    shortName: 'EYÜ',
    badgeColor: 'from-purple-900 to-indigo-900',
    badgeTextColor: 'text-purple-300',
    secondaryColor: '#581c87',
    stadiumName: 'Recep Tayyip Erdoğan Stadyumu',
    budget: 8000000,
    reputation: 3,
    formation: '4-1-4-1',
    tactic: 'BALANCED',
    baseRating: 75,
    basePlayers: [
      { name: 'Horațiu Moldovan', age: 29, pos: 'GK', role: 'GK', ovr: 77, nat: 'Romanya', start: true },
      { name: 'Lucas Felipe Calegari', age: 24, pos: 'DEF', role: 'RB', ovr: 75, nat: 'Brezilya', start: true },
      { name: 'Jawad El Yamiq', age: 34, pos: 'DEF', role: 'CB', ovr: 76, nat: 'Fas', start: true },
      { name: 'Fethi Özer', age: 30, pos: 'DEF', role: 'CB', ovr: 72, nat: 'Türkiye', start: true },
      { name: 'Zak Jules', age: 30, pos: 'DEF', role: 'LB', ovr: 72, nat: 'İskoçya', start: true },
      { name: 'Chandrel Massanga', age: 27, pos: 'MID', role: 'CDM', ovr: 74, nat: 'Kongo', start: true },
      { name: 'Abdelhamid Sabiri', age: 30, pos: 'MID', role: 'CAM', ovr: 76, nat: 'Fas', start: true },
      { name: 'Hamza Akman', age: 22, pos: 'MID', role: 'CM', ovr: 72, nat: 'Türkiye', start: true },
      { name: 'Konrad Michalak', age: 29, pos: 'FW', role: 'RW', ovr: 75, nat: 'Polonya', start: true },
      { name: 'Prince Obeng Ampem', age: 28, pos: 'FW', role: 'LW', ovr: 75, nat: 'Gana', start: true },
      { name: 'Lenny Pintor', age: 26, pos: 'FW', role: 'ST', ovr: 73, nat: 'Fransa', start: true },
      { name: 'Umut Keseci', age: 23, pos: 'GK', role: 'GK', ovr: 67, nat: 'Türkiye', start: false },
      { name: 'Anıl Yaşar', age: 24, pos: 'DEF', role: 'CB', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Erdem Gökçe', age: 23, pos: 'DEF', role: 'RB', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Jakhongir Orozov', age: 23, pos: 'DEF', role: 'CB', ovr: 70, nat: 'Özbekistan', start: false },
      { name: 'Talha Ulvan', age: 25, pos: 'DEF', role: 'RB', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Buğra Çağlıyan', age: 22, pos: 'MID', role: 'CM', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'David José Soares Oliveira Furtado Costa', age: 23, pos: 'MID', role: 'CM', ovr: 71, nat: 'Yeşil Burun A.', start: false },
      { name: 'Mete Kaan Demir', age: 28, pos: 'MID', role: 'LM', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Charles Andre Raux Yao', age: 25, pos: 'MID', role: 'CM', ovr: 71, nat: 'Fransa', start: false },
      { name: 'Taşkın İlter', age: 32, pos: 'MID', role: 'CM', ovr: 71, nat: 'Azerbaycan', start: false },
      { name: 'Ahmed Abdullahi', age: 22, pos: 'FW', role: 'ST', ovr: 68, nat: 'Nijerya', start: false },
      { name: 'Bilal Boutobba', age: 28, pos: 'FW', role: 'RW', ovr: 74, nat: 'Fransa', start: false },
      { name: 'Metehan Altunbaş', age: 24, pos: 'FW', role: 'ST', ovr: 70, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'goztepe',
    name: 'Göztepe',
    shortName: 'GÖZ',
    badgeColor: 'from-yellow-500 to-red-600',
    badgeTextColor: 'text-yellow-200',
    secondaryColor: '#eab308',
    stadiumName: 'Gürsel Aksel Stadyumu',
    budget: 5500000,
    reputation: 3,
    formation: '3-5-2',
    tactic: 'ATTACKING',
    baseRating: 75,
    basePlayers: [
      { name: 'Arda Özçimen', age: 25, pos: 'GK', role: 'GK', ovr: 72, nat: 'Türkiye', start: true },
      { name: 'Taha Altıkardeş', age: 23, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Malcom Bokele', age: 27, pos: 'DEF', role: 'CB', ovr: 75, nat: 'Kamerun', start: true },
      { name: 'Allan Godoi', age: 33, pos: 'DEF', role: 'CB', ovr: 75, nat: 'Brezilya', start: true },
      { name: 'Ogün Bayrak', age: 28, pos: 'DEF', role: 'RB', ovr: 73, nat: 'Türkiye', start: true },
      { name: 'Mohammed Amin Cherni', age: 25, pos: 'DEF', role: 'LB', ovr: 74, nat: 'Tunus', start: true },
      { name: 'Efkan Bekiroğlu', age: 31, pos: 'MID', role: 'CAM', ovr: 75, nat: 'Türkiye', start: true },
      { name: 'Rhaldney', age: 28, pos: 'MID', role: 'CM', ovr: 74, nat: 'Brezilya', start: true },
      { name: 'Novatus Miroshi', age: 24, pos: 'MID', role: 'CDM', ovr: 74, nat: 'Tanzanya', start: true },
      { name: 'Juan', age: 24, pos: 'FW', role: 'ST', ovr: 75, nat: 'Brezilya', start: true },
      { name: 'Sinclair Armstrong', age: 23, pos: 'FW', role: 'ST', ovr: 75, nat: 'İrlanda', start: true },
      { name: 'Luka Gugeshashvili', age: 27, pos: 'GK', role: 'GK', ovr: 74, nat: 'Gürcistan', start: false },
      { name: 'Berke Sarıgül', age: 26, pos: 'GK', role: 'GK', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Furkan Bayır', age: 27, pos: 'DEF', role: 'CB', ovr: 73, nat: 'Türkiye', start: false },
      { name: 'Noah Sonko-Sundberg', age: 30, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Gambiya', start: false },
      { name: 'Arda Okan Kurtulan', age: 24, pos: 'DEF', role: 'RB', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Anthony Dennis', age: 22, pos: 'MID', role: 'CDM', ovr: 74, nat: 'Nijerya', start: false },
      { name: 'Alex Matos', age: 22, pos: 'MID', role: 'CM', ovr: 74, nat: 'İngiltere', start: false },
      { name: 'Alexis Antunes', age: 26, pos: 'MID', role: 'CAM', ovr: 73, nat: 'İsviçre', start: false },
      { name: 'Musah Mohammed', age: 25, pos: 'MID', role: 'CM', ovr: 71, nat: 'Gana', start: false },
      { name: 'Janderson de Carvalho Costa', age: 27, pos: 'FW', role: 'ST', ovr: 74, nat: 'Brezilya', start: false },
      { name: 'Andre Henrique da Silva Martins', age: 25, pos: 'FW', role: 'ST', ovr: 73, nat: 'Brezilya', start: false },
      { name: 'Guilherme Luiz Oliveira da Silva', age: 21, pos: 'FW', role: 'RW', ovr: 72, nat: 'Brezilya', start: false },
      { name: 'Gökdeniz Bayrakdar', age: 25, pos: 'FW', role: 'RW', ovr: 73, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'kasimpasa',
    name: 'Kasımpaşa',
    shortName: 'KAS',
    badgeColor: 'from-blue-700 to-blue-950',
    badgeTextColor: 'text-blue-200',
    secondaryColor: '#1d4ed8',
    stadiumName: 'Recep Tayyip Erdoğan Stadyumu',
    budget: 5000000,
    reputation: 3,
    formation: '4-2-3-1',
    tactic: 'ATTACKING',
    baseRating: 75,
    basePlayers: [
      { name: 'Andreas Gianniotis', age: 34, pos: 'GK', role: 'GK', ovr: 75, nat: 'Yunanistan', start: true },
      { name: 'Claudio Winck Neto', age: 32, pos: 'DEF', role: 'RB', ovr: 75, nat: 'Brezilya', start: true },
      { name: 'Godfried Ayesu Owusu Frimpong', age: 27, pos: 'DEF', role: 'CB', ovr: 73, nat: 'Hollanda', start: true },
      { name: 'Matei Cristian Ilie', age: 24, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Romanya', start: true },
      { name: 'Yunus Emre Atakaya', age: 22, pos: 'DEF', role: 'LB', ovr: 71, nat: 'Türkiye', start: true },
      { name: 'Haris Hajradinovic', age: 32, pos: 'MID', role: 'CAM', ovr: 77, nat: 'Bosna Hersek', start: true },
      { name: 'Mortadha Ben Ouanes', age: 32, pos: 'MID', role: 'LM', ovr: 75, nat: 'Tunus', start: true },
      { name: 'Kerem Demirbay', age: 33, pos: 'MID', role: 'CM', ovr: 77, nat: 'Almanya', start: true },
      { name: 'Mamadou Fall', age: 35, pos: 'FW', role: 'RW', ovr: 75, nat: 'Senegal', start: true },
      { name: 'Fousseni Diabate', age: 31, pos: 'FW', role: 'LW', ovr: 75, nat: 'Mali', start: true },
      { name: 'Pape Habib Gueye', age: 27, pos: 'FW', role: 'ST', ovr: 74, nat: 'Senegal', start: true },
      { name: 'Ali Emre Yanar', age: 28, pos: 'GK', role: 'GK', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Ramazan Özkanlı', age: 24, pos: 'GK', role: 'GK', ovr: 67, nat: 'Türkiye', start: false },
      { name: 'Kamil Ahmet Çörekçi', age: 35, pos: 'DEF', role: 'RB', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Adem Arous', age: 22, pos: 'DEF', role: 'CB', ovr: 69, nat: 'Tunus', start: false },
      { name: 'Ayberk Karapo', age: 22, pos: 'DEF', role: 'CB', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Jakob Vestergaard Jessen', age: 22, pos: 'DEF', role: 'CB', ovr: 70, nat: 'Danimarka', start: false },
      { name: 'Atakan Müjde', age: 23, pos: 'MID', role: 'CM', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Elson Mendes Da Silva', age: 21, pos: 'MID', role: 'CM', ovr: 69, nat: 'Yeşil Burun A.', start: false },
      { name: 'Kubilay Kanatsızkuş', age: 29, pos: 'FW', role: 'ST', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Adrian Benedyczak', age: 26, pos: 'FW', role: 'ST', ovr: 74, nat: 'Polonya', start: false },
      { name: 'Güven Yalçın', age: 28, pos: 'FW', role: 'ST', ovr: 74, nat: 'Türkiye', start: false },
      { name: 'Thiemoko Diarra', age: 23, pos: 'FW', role: 'LW', ovr: 72, nat: 'Mali', start: false },
      { name: 'Ali Yavuz Kol', age: 26, pos: 'FW', role: 'ST', ovr: 71, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'gaziantep',
    name: 'Gaziantep FK',
    shortName: 'GFK',
    badgeColor: 'from-red-700 to-gray-900',
    badgeTextColor: 'text-red-300',
    secondaryColor: '#b91c1c',
    stadiumName: 'Kalyon Stadyumu',
    budget: 4500000,
    reputation: 3,
    formation: '4-2-3-1',
    tactic: 'BALANCED',
    baseRating: 74,
    basePlayers: [
      { name: 'Kacper Tobiasz', age: 24, pos: 'GK', role: 'GK', ovr: 75, nat: 'Polonya', start: true },
      { name: 'Luis Jesus Perez Maqueda', age: 32, pos: 'DEF', role: 'RB', ovr: 74, nat: 'İspanya', start: true },
      { name: 'Myenty Abena', age: 32, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Surinam', start: true },
      { name: 'Arda Kızıldağ', age: 28, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Florin Stefan', age: 30, pos: 'DEF', role: 'LB', ovr: 73, nat: 'Romanya', start: true },
      { name: 'Ogün Özçiçek', age: 28, pos: 'MID', role: 'CDM', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Juninho Bacuna', age: 29, pos: 'MID', role: 'CM', ovr: 75, nat: 'Curaçao', start: true },
      { name: 'Alexandru Lulian Maxim', age: 36, pos: 'MID', role: 'CAM', ovr: 76, nat: 'Romanya', start: true },
      { name: 'Deian Cristian Sorescu', age: 29, pos: 'FW', role: 'RW', ovr: 74, nat: 'Romanya', start: true },
      { name: 'Kacper Kozlowski', age: 23, pos: 'FW', role: 'LW', ovr: 75, nat: 'Polonya', start: true },
      { name: 'Trivante Vincent Stewart', age: 26, pos: 'FW', role: 'ST', ovr: 73, nat: 'Jamaika', start: true },
      { name: 'İbrahim Kağan Alkış', age: 21, pos: 'GK', role: 'GK', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Yusuf Nacar', age: 20, pos: 'GK', role: 'GK', ovr: 66, nat: 'Türkiye', start: false },
      { name: 'Kerim Çalhanoğlu', age: 24, pos: 'DEF', role: 'LB', ovr: 71, nat: 'Almanya', start: false },
      { name: 'Muhammet Onur Başyiğit', age: 22, pos: 'DEF', role: 'CB', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Sabahattin Destici', age: 26, pos: 'DEF', role: 'CB', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Ulrich Meleke', age: 27, pos: 'MID', role: 'CDM', ovr: 72, nat: 'Fildişi Sahili', start: false },
      { name: 'Drissa Camara', age: 24, pos: 'MID', role: 'CM', ovr: 71, nat: 'Fildişi Sahili', start: false },
      { name: 'Enver Kulasin', age: 23, pos: 'FW', role: 'RW', ovr: 71, nat: 'Bosna Hersek', start: false },
      { name: 'Fuat Bavuk', age: 26, pos: 'FW', role: 'ST', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Mirza Cihan', age: 26, pos: 'FW', role: 'LW', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Ali Ablak', age: 23, pos: 'FW', role: 'ST', ovr: 67, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'konyaspor',
    name: 'TÜMOSAN Konyaspor',
    shortName: 'KNY',
    badgeColor: 'from-emerald-700 to-green-950',
    badgeTextColor: 'text-emerald-200',
    secondaryColor: '#047857',
    stadiumName: 'Konya Büyükşehir Stadyumu',
    budget: 4000000,
    reputation: 3,
    formation: '4-2-3-1',
    tactic: 'BALANCED',
    baseRating: 74,
    basePlayers: [
      { name: 'Deniz Ertaş', age: 21, pos: 'GK', role: 'GK', ovr: 72, nat: 'Türkiye', start: true },
      { name: 'Chidozie Collins Awaziem', age: 30, pos: 'DEF', role: 'CB', ovr: 75, nat: 'Nijerya', start: true },
      { name: 'Adil Demirbağ', age: 29, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Rayyan Baniya', age: 27, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Yhoan Andzouana', age: 30, pos: 'DEF', role: 'RB', ovr: 73, nat: 'Kongo', start: true },
      { name: 'Enis Bardhi', age: 31, pos: 'MID', role: 'CAM', ovr: 76, nat: 'Kuzey Makedonya', start: true },
      { name: 'Deniz Türüç', age: 34, pos: 'MID', role: 'RM', ovr: 76, nat: 'Türkiye', start: true },
      { name: 'Sander Svendsen', age: 29, pos: 'MID', role: 'LM', ovr: 74, nat: 'Norveç', start: true },
      { name: 'Morten Bjørlo', age: 31, pos: 'MID', role: 'CM', ovr: 73, nat: 'Norveç', start: true },
      { name: 'Blaz Kramer', age: 30, pos: 'FW', role: 'ST', ovr: 75, nat: 'Slovenya', start: true },
      { name: 'Jackson Muleka', age: 27, pos: 'FW', role: 'ST', ovr: 75, nat: 'Kongo DC', start: true },
      { name: 'Bahadır Güngördü', age: 31, pos: 'GK', role: 'GK', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Guilherme Sityá', age: 36, pos: 'DEF', role: 'LB', ovr: 75, nat: 'Brezilya', start: false },
      { name: 'Arif Boşluk', age: 23, pos: 'DEF', role: 'LB', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'João Pedro do Nascimento da Mata', age: 20, pos: 'DEF', role: 'CB', ovr: 70, nat: 'Brezilya', start: false },
      { name: 'Uğurcan Yazğılı', age: 27, pos: 'MID', role: 'CDM', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Marko Jevtovic', age: 33, pos: 'MID', role: 'CDM', ovr: 73, nat: 'Sırbistan', start: false },
      { name: 'Melih İbrahimoğlu', age: 26, pos: 'MID', role: 'CM', ovr: 73, nat: 'Avusturya', start: false },
      { name: 'Ebrima Colley', age: 27, pos: 'FW', role: 'LW', ovr: 74, nat: 'Gambiya', start: false },
      { name: 'Louka Prip', age: 29, pos: 'FW', role: 'RW', ovr: 72, nat: 'Danimarka', start: false },
      { name: 'Hamidou Keyta', age: 31, pos: 'FW', role: 'LW', ovr: 71, nat: 'Fransa', start: false },
      { name: 'Muhammet Tunahan Taşçı', age: 24, pos: 'FW', role: 'RW', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Melih Bostan', age: 22, pos: 'FW', role: 'ST', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Emir Bars', age: 21, pos: 'FW', role: 'ST', ovr: 68, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'alanyaspor',
    name: 'Corendon Alanyaspor',
    shortName: 'ALA',
    badgeColor: 'from-orange-500 to-green-700',
    badgeTextColor: 'text-orange-200',
    secondaryColor: '#f97316',
    stadiumName: 'Gain Park Stadyumu',
    budget: 4200000,
    reputation: 3,
    formation: '4-2-3-1',
    tactic: 'BALANCED',
    baseRating: 74,
    basePlayers: [
      { name: 'Paulo Victor de Mileo Vidotti', age: 40, pos: 'GK', role: 'GK', ovr: 74, nat: 'Brezilya', start: true },
      { name: 'Florent Hadergjonaj', age: 32, pos: 'DEF', role: 'RB', ovr: 75, nat: 'Kosova', start: true },
      { name: 'Bruno Viana Willemen da Silva', age: 32, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Brezilya', start: true },
      { name: 'Nuno Miguel Reis Lima', age: 25, pos: 'DEF', role: 'CB', ovr: 73, nat: 'Portekiz', start: true },
      { name: 'Ümit Akdağ', age: 23, pos: 'DEF', role: 'LB', ovr: 73, nat: 'Romanya', start: true },
      { name: 'Gaïus Makouta', age: 29, pos: 'MID', role: 'CDM', ovr: 74, nat: 'Kongo', start: true },
      { name: 'Enes Keskin', age: 25, pos: 'MID', role: 'CM', ovr: 71, nat: 'Türkiye', start: true },
      { name: 'Ianis Hagi', age: 28, pos: 'MID', role: 'CAM', ovr: 76, nat: 'Romanya', start: true },
      { name: 'Elia Meschack', age: 29, pos: 'FW', role: 'RW', ovr: 75, nat: 'Kongo DC', start: true },
      { name: 'Yusuf Özdemir', age: 26, pos: 'FW', role: 'LW', ovr: 73, nat: 'Türkiye', start: true },
      { name: 'Hwang Ui-jo', age: 34, pos: 'FW', role: 'ST', ovr: 75, nat: 'Güney Kore', start: true },
      { name: 'Mert Furkan Bayram', age: 22, pos: 'GK', role: 'GK', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Yusuf Karagöz', age: 27, pos: 'GK', role: 'GK', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Bedirhan Özyurt', age: 23, pos: 'DEF', role: 'CB', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Batuhan Yavuz', age: 21, pos: 'DEF', role: 'RB', ovr: 67, nat: 'Türkiye', start: false },
      { name: 'Fatih Aksoy', age: 29, pos: 'DEF', role: 'CB', ovr: 73, nat: 'Türkiye', start: false },
      { name: 'Fidan Aliti', age: 33, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Kosova', start: false },
      { name: 'Emirhan Çavuş', age: 24, pos: 'MID', role: 'CM', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Buluthan Bulut', age: 24, pos: 'MID', role: 'CM', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Antonio Simão Muanza', age: 23, pos: 'MID', role: 'CM', ovr: 69, nat: 'Angola', start: false },
      { name: 'İzzet Çelik', age: 22, pos: 'MID', role: 'CM', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Arda Usluoğlu', age: 20, pos: 'FW', role: 'ST', ovr: 66, nat: 'Türkiye', start: false },
      { name: 'Veysel Karani Ünal', age: 25, pos: 'FW', role: 'ST', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Ruan Pereira Duarte', age: 21, pos: 'FW', role: 'RW', ovr: 71, nat: 'Brezilya', start: false },
      { name: 'İbrahim Kaya', age: 25, pos: 'FW', role: 'ST', ovr: 69, nat: 'Türkiye', start: false },
      { name: 'Omar Ben Ali', age: 21, pos: 'FW', role: 'ST', ovr: 67, nat: 'Tunus', start: false }
    ]
  },
  {
    id: 'rizespor',
    name: 'Çaykur Rizespor',
    shortName: 'RİZ',
    badgeColor: 'from-blue-600 to-green-600',
    badgeTextColor: 'text-green-200',
    secondaryColor: '#2563eb',
    stadiumName: 'Çaykur Didi Stadyumu',
    budget: 4800000,
    reputation: 3,
    formation: '4-2-3-1',
    tactic: 'ATTACKING',
    baseRating: 75,
    basePlayers: [
      { name: 'Yahia Fofana', age: 26, pos: 'GK', role: 'GK', ovr: 77, nat: 'Fildişi Sahili', start: true },
      { name: 'Taha Şahin', age: 26, pos: 'DEF', role: 'RB', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Modibo Sagnan', age: 27, pos: 'DEF', role: 'CB', ovr: 76, nat: 'Mali', start: true },
      { name: 'Husniddin Alikulov', age: 27, pos: 'DEF', role: 'CB', ovr: 75, nat: 'Özbekistan', start: true },
      { name: 'Mithat Pala', age: 26, pos: 'DEF', role: 'LB', ovr: 73, nat: 'Türkiye', start: true },
      { name: 'Taylan Antalyalı', age: 32, pos: 'MID', role: 'CDM', ovr: 75, nat: 'Türkiye', start: true },
      { name: 'Qazim Laçi', age: 31, pos: 'MID', role: 'CM', ovr: 74, nat: 'Arnavutluk', start: true },
      { name: 'Dal Varesanovic', age: 25, pos: 'MID', role: 'CAM', ovr: 75, nat: 'Bosna Hersek', start: true },
      { name: 'Ahmed Kutucu', age: 26, pos: 'FW', role: 'RW', ovr: 76, nat: 'Türkiye', start: true },
      { name: 'Valentin Mihai Mihaila', age: 27, pos: 'FW', role: 'LW', ovr: 76, nat: 'Romanya', start: true },
      { name: 'Ali Sowe', age: 32, pos: 'FW', role: 'ST', ovr: 76, nat: 'Gambiya', start: true },
      { name: 'Zafer Görgen', age: 26, pos: 'GK', role: 'GK', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Erdem Canpolat', age: 25, pos: 'GK', role: 'GK', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Anıl Yaşar', age: 24, pos: 'DEF', role: 'CB', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Eray Korkmaz', age: 23, pos: 'DEF', role: 'RB', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Habil Özbakır', age: 22, pos: 'DEF', role: 'LB', ovr: 67, nat: 'Türkiye', start: false },
      { name: 'Siaka Bakayoko', age: 21, pos: 'DEF', role: 'LB', ovr: 68, nat: 'Fransa', start: false },
      { name: 'Tayyip Talha Sanuç', age: 27, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Türkiye', start: false },
      { name: 'Zakaria Ariss', age: 22, pos: 'DEF', role: 'LB', ovr: 70, nat: 'Fas', start: false },
      { name: 'Attila Mocsi', age: 26, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Macaristan', start: false },
      { name: 'Mame Mor Faye', age: 21, pos: 'MID', role: 'RW', ovr: 70, nat: 'Senegal', start: false },
      { name: 'Muhamed Buljubasic', age: 22, pos: 'MID', role: 'CM', ovr: 71, nat: 'Bosna Hersek', start: false },
      { name: 'Altin Zeqiri', age: 26, pos: 'MID', role: 'LM', ovr: 74, nat: 'Kosova', start: false },
      { name: 'Ibrahim Olawoyin', age: 29, pos: 'FW', role: 'LW', ovr: 75, nat: 'Nijerya', start: false },
      { name: 'Adedire Awokoya Mebude', age: 22, pos: 'FW', role: 'RW', ovr: 71, nat: 'İskoçya', start: false },
      { name: 'Emrecan Bulut', age: 24, pos: 'FW', role: 'ST', ovr: 71, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'kocaelispor',
    name: 'Kocaelispor',
    shortName: 'KOC',
    badgeColor: 'from-green-600 to-black',
    badgeTextColor: 'text-green-300',
    secondaryColor: '#16a34a',
    stadiumName: 'Kocaeli Stadyumu',
    budget: 4500000,
    reputation: 3,
    formation: '4-2-3-1',
    tactic: 'BALANCED',
    baseRating: 74,
    basePlayers: [
      { name: 'Gökhan Değirmenci', age: 37, pos: 'GK', role: 'GK', ovr: 73, nat: 'Türkiye', start: true },
      { name: 'Aaron Appindangoye', age: 34, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Gabon', start: true },
      { name: 'Tarkan Serbest', age: 32, pos: 'DEF', role: 'CB', ovr: 73, nat: 'Avusturya', start: true },
      { name: 'Ahmet Oğuz', age: 33, pos: 'DEF', role: 'RB', ovr: 73, nat: 'Türkiye', start: true },
      { name: 'Muharrem Cinan', age: 28, pos: 'DEF', role: 'LB', ovr: 72, nat: 'Türkiye', start: true },
      { name: 'Pedrinho', age: 33, pos: 'MID', role: 'CAM', ovr: 74, nat: 'Portekiz', start: true },
      { name: 'Mijo Caktas', age: 34, pos: 'MID', role: 'CAM', ovr: 75, nat: 'Hırvatistan', start: true },
      { name: 'Josip Vukovic', age: 34, pos: 'MID', role: 'CDM', ovr: 73, nat: 'Hırvatistan', start: true },
      { name: 'Ryan Mendes', age: 36, pos: 'FW', role: 'LW', ovr: 74, nat: 'Yeşil Burun A.', start: true },
      { name: 'Daniel Candeias', age: 38, pos: 'FW', role: 'RW', ovr: 74, nat: 'Portekiz', start: true },
      { name: 'Markao', age: 32, pos: 'FW', role: 'ST', ovr: 75, nat: 'Brezilya', start: true },
      { name: 'Harun Tekin', age: 37, pos: 'GK', role: 'GK', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Haşim Arda Sarman', age: 23, pos: 'DEF', role: 'CB', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Onur Öztonga', age: 26, pos: 'DEF', role: 'CB', ovr: 69, nat: 'Türkiye', start: false },
      { name: 'Mehmet Yılmaz', age: 30, pos: 'DEF', role: 'RB', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Cihat Çelik', age: 30, pos: 'MID', role: 'CM', ovr: 71, nat: 'Hollanda', start: false },
      { name: 'Mesut Can Tunalı', age: 24, pos: 'MID', role: 'CM', ovr: 69, nat: 'Türkiye', start: false },
      { name: 'Barış Alıcı', age: 29, pos: 'FW', role: 'RW', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Giorgi Beridze', age: 29, pos: 'FW', role: 'LW', ovr: 72, nat: 'Gürcistan', start: false },
      { name: 'Ahmet Sagat', age: 29, pos: 'FW', role: 'ST', ovr: 72, nat: 'Almanya', start: false },
      { name: 'Christian Kouakou', age: 35, pos: 'FW', role: 'ST', ovr: 71, nat: 'Fildişi Sahili', start: false },
      { name: 'Samed Ali Kaya', age: 30, pos: 'FW', role: 'ST', ovr: 70, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'erzurumspor',
    name: 'Erzurumspor FK',
    shortName: 'ERZ',
    badgeColor: 'from-blue-600 to-sky-400',
    badgeTextColor: 'text-blue-100',
    secondaryColor: '#2563eb',
    stadiumName: 'Kâzım Karabekir Stadyumu',
    budget: 3800000,
    reputation: 2,
    formation: '4-3-3',
    tactic: 'DEFENSIVE',
    baseRating: 73,
    basePlayers: [
      { name: 'Ertuğrul Taşkıran', age: 37, pos: 'GK', role: 'GK', ovr: 75, nat: 'Türkiye', start: true },
      { name: 'Orhan Ovacıklı', age: 38, pos: 'DEF', role: 'RB', ovr: 72, nat: 'Türkiye', start: true },
      { name: 'Mustafa Yumlu', age: 39, pos: 'DEF', role: 'CB', ovr: 73, nat: 'Türkiye', start: true },
      { name: 'Nihad Mujakić', age: 28, pos: 'DEF', role: 'CB', ovr: 75, nat: 'Bosna Hersek', start: true },
      { name: 'Guram Giorbelidze', age: 30, pos: 'DEF', role: 'LB', ovr: 72, nat: 'Gürcistan', start: true },
      { name: 'Brandon Baiye', age: 26, pos: 'MID', role: 'CDM', ovr: 73, nat: 'Belçika', start: true },
      { name: 'Murat Cem Akpınar', age: 28, pos: 'MID', role: 'CM', ovr: 73, nat: 'Türkiye', start: true },
      { name: 'Martín Vladimir Rodríguez Torrejón', age: 32, pos: 'MID', role: 'CAM', ovr: 73, nat: 'Şili', start: true },
      { name: 'Gyrano Kerk', age: 31, pos: 'FW', role: 'RW', ovr: 75, nat: 'Surinam', start: true },
      { name: 'Fernando Andrade dos Santos', age: 34, pos: 'FW', role: 'LW', ovr: 73, nat: 'Brezilya', start: true },
      { name: 'Eren Tozlu', age: 36, pos: 'FW', role: 'ST', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Erkan Anapa', age: 29, pos: 'GK', role: 'GK', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Matija Orbanic', age: 26, pos: 'GK', role: 'GK', ovr: 71, nat: 'Hırvatistan', start: false },
      { name: 'Emre Erdem', age: 24, pos: 'DEF', role: 'CB', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Enes Yiğit', age: 24, pos: 'DEF', role: 'CB', ovr: 67, nat: 'Türkiye', start: false },
      { name: 'Cengizhan Bayrak', age: 27, pos: 'DEF', role: 'LB', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Yakup Kırtay', age: 23, pos: 'DEF', role: 'CB', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Amar Gerxhaliu', age: 24, pos: 'DEF', role: 'CB', ovr: 70, nat: 'Kosova', start: false },
      { name: 'Eren Özdemir', age: 23, pos: 'MID', role: 'CM', ovr: 66, nat: 'Türkiye', start: false },
      { name: 'Furkan Özhan', age: 26, pos: 'MID', role: 'CM', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Sefa Akgün', age: 26, pos: 'MID', role: 'CM', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Gürkan Varlık', age: 24, pos: 'FW', role: 'ST', ovr: 67, nat: 'Türkiye', start: false },
      { name: 'Hüseyin Mevlütoğlu', age: 24, pos: 'FW', role: 'LW', ovr: 67, nat: 'Türkiye', start: false },
      { name: 'Nariman Axundzadə', age: 22, pos: 'FW', role: 'ST', ovr: 71, nat: 'Azerbaycan', start: false },
      { name: 'Serkan Köse', age: 28, pos: 'FW', role: 'ST', ovr: 69, nat: 'Türkiye', start: false },
      { name: 'İlkan Sever', age: 22, pos: 'FW', role: 'LW', ovr: 67, nat: 'Türkiye', start: false },
      { name: 'Mustafa Fettahoğlu', age: 26, pos: 'FW', role: 'ST', ovr: 68, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'amedfk',
    name: 'Amed SFK',
    shortName: 'AMD',
    badgeColor: 'from-green-700 to-red-700',
    badgeTextColor: 'text-green-200',
    secondaryColor: '#15803d',
    stadiumName: 'Diyarbakır Stadyumu',
    budget: 4200000,
    reputation: 3,
    formation: '4-2-3-1',
    tactic: 'ATTACKING',
    baseRating: 74,
    basePlayers: [
      { name: 'Marcos Felipe de Freitas Monteiro', age: 30, pos: 'GK', role: 'GK', ovr: 76, nat: 'Brezilya', start: true },
      { name: 'Gökhan Sazdağı', age: 32, pos: 'DEF', role: 'RB', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Alexandre Manuel Penetra Correia', age: 25, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Portekiz', start: true },
      { name: 'Hrvoje Smolcic', age: 26, pos: 'DEF', role: 'CB', ovr: 75, nat: 'Hırvatistan', start: true },
      { name: 'Andrei Borza', age: 21, pos: 'DEF', role: 'LB', ovr: 73, nat: 'Romanya', start: true },
      { name: 'Ylber Ramadani', age: 30, pos: 'MID', role: 'CDM', ovr: 76, nat: 'Arnavutluk', start: true },
      { name: 'Fredy Alfredo', age: 36, pos: 'MID', role: 'CM', ovr: 74, nat: 'Angola', start: true },
      { name: 'Danijel Aleksic', age: 35, pos: 'MID', role: 'CAM', ovr: 74, nat: 'Sırbistan', start: true },
      { name: 'Serdar Gürler', age: 35, pos: 'FW', role: 'RW', ovr: 75, nat: 'Türkiye', start: true },
      { name: 'Hermenegildo da Costa Paulo Bartolomeu', age: 35, pos: 'FW', role: 'LW', ovr: 74, nat: 'Angola', start: true },
      { name: 'Mame Thiam', age: 34, pos: 'FW', role: 'ST', ovr: 77, nat: 'Senegal', start: true },
      { name: 'Erhan Erentürk', age: 31, pos: 'GK', role: 'GK', ovr: 73, nat: 'Türkiye', start: false },
      { name: 'Serdar Saatçı', age: 23, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Türkiye', start: false },
      { name: 'Arda Şengül', age: 28, pos: 'DEF', role: 'CB', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Cemali Sertel', age: 27, pos: 'DEF', role: 'LB', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Joseph Attamah', age: 32, pos: 'DEF', role: 'CB', ovr: 72, nat: 'Gana', start: false },
      { name: 'Sinan Osmanoğlu', age: 37, pos: 'DEF', role: 'CB', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Hasan Abdulkareem Sayyid', age: 27, pos: 'MID', role: 'CAM', ovr: 71, nat: 'Irak', start: false },
      { name: 'Pedro Filipe Barbosa Moreira', age: 34, pos: 'MID', role: 'CM', ovr: 72, nat: 'Portekiz', start: false },
      { name: 'Ferhat Yazgan', age: 34, pos: 'MID', role: 'CDM', ovr: 73, nat: 'Türkiye', start: false },
      { name: 'Ahmed Ildız', age: 30, pos: 'MID', role: 'CM', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Atakan Akkaynak', age: 28, pos: 'MID', role: 'CM', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Atakan Cangöz', age: 34, pos: 'MID', role: 'CM', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Eren Karadağ', age: 27, pos: 'MID', role: 'LM', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Emeka Friday Eze', age: 30, pos: 'FW', role: 'ST', ovr: 73, nat: 'Nijerya', start: false },
      { name: 'Emircan Gürlük', age: 23, pos: 'FW', role: 'LW', ovr: 72, nat: 'Türkiye', start: false },
      { name: 'Hüseyin Bulut', age: 27, pos: 'FW', role: 'LW', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Burak Çoban', age: 32, pos: 'FW', role: 'LW', ovr: 71, nat: 'Türkiye', start: false }
    ]
  },
  {
    id: 'corumfk',
    name: 'Ahlatcı Çorum FK',
    shortName: 'ÇOR',
    badgeColor: 'from-red-700 to-black',
    badgeTextColor: 'text-red-200',
    secondaryColor: '#b91c1c',
    stadiumName: 'Çorum Şehir Stadyumu',
    budget: 3500000,
    reputation: 2,
    formation: '4-3-3',
    tactic: 'BALANCED',
    baseRating: 73,
    basePlayers: [
      { name: 'Alban Lafont', age: 28, pos: 'GK', role: 'GK', ovr: 78, nat: 'Fransa', start: true },
      { name: 'Celal Hanalp', age: 30, pos: 'DEF', role: 'RB', ovr: 72, nat: 'Türkiye', start: true },
      { name: 'David Bates', age: 30, pos: 'DEF', role: 'CB', ovr: 74, nat: 'İskoçya', start: true },
      { name: 'Mehmet Yeşil', age: 28, pos: 'DEF', role: 'CB', ovr: 73, nat: 'Türkiye', start: true },
      { name: 'Umut Meraş', age: 31, pos: 'DEF', role: 'LB', ovr: 73, nat: 'Türkiye', start: true },
      { name: 'Rayan Raveloson', age: 30, pos: 'MID', role: 'CDM', ovr: 75, nat: 'Madagaskar', start: true },
      { name: 'Furkan Soyalp', age: 31, pos: 'MID', role: 'CM', ovr: 73, nat: 'Türkiye', start: true },
      { name: 'Çekdar Orhan', age: 28, pos: 'MID', role: 'CAM', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Ermal Krasniqi', age: 28, pos: 'FW', role: 'RW', ovr: 75, nat: 'Kosova', start: true },
      { name: 'Daniel Moreno Mosquera', age: 32, pos: 'FW', role: 'LW', ovr: 74, nat: 'Kolombiya', start: true },
      { name: 'Mbaye Diagne', age: 35, pos: 'FW', role: 'ST', ovr: 76, nat: 'Senegal', start: true },
      { name: 'Abdulsamed Damlu', age: 27, pos: 'GK', role: 'GK', ovr: 69, nat: 'Türkiye', start: false },
      { name: 'Burak Bozan', age: 26, pos: 'GK', role: 'GK', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Veysel Sapan', age: 31, pos: 'GK', role: 'GK', ovr: 69, nat: 'Türkiye', start: false },
      { name: 'Amadou Cissé', age: 20, pos: 'DEF', role: 'CB', ovr: 67, nat: 'Gine', start: false },
      { name: 'Lumbardh Dellova', age: 28, pos: 'DEF', role: 'CB', ovr: 73, nat: 'Kosova', start: false },
      { name: 'Miraç Acer', age: 30, pos: 'DEF', role: 'RB', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Tarkan Serbest', age: 32, pos: 'DEF', role: 'CB', ovr: 73, nat: 'Türkiye', start: false },
      { name: 'Kahraman Demirtaş', age: 32, pos: 'DEF', role: 'CB', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Cem Üstündağ', age: 26, pos: 'MID', role: 'CM', ovr: 71, nat: 'Avusturya', start: false },
      { name: 'Gift Emmanuel Orban', age: 24, pos: 'FW', role: 'ST', ovr: 76, nat: 'Nijerya', start: false },
      { name: 'Mohamed Khalil', age: 26, pos: 'FW', role: 'ST', ovr: 69, nat: 'Türkiye', start: false },
      { name: 'Florent Hasani', age: 29, pos: 'FW', role: 'CAM', ovr: 73, nat: 'Kosova', start: false },
      { name: 'Zdravko Minchev Dimitrov', age: 28, pos: 'FW', role: 'LW', ovr: 73, nat: 'Bulgaristan', start: false },
      { name: 'Dia Saba', age: 34, pos: 'FW', role: 'CAM', ovr: 75, nat: 'İsrail', start: false }
    ]
  },
  {
    id: 'genclerbirligi',
    name: 'Gençlerbirliği',
    shortName: 'GÇB',
    badgeColor: 'from-red-600 to-black',
    badgeTextColor: 'text-red-200',
    secondaryColor: '#dc2626',
    stadiumName: 'Eryaman Stadyumu',
    budget: 4800000,
    reputation: 3,
    formation: '4-2-3-1',
    tactic: 'ATTACKING',
    baseRating: 74,
    basePlayers: [
      { name: 'Erhan Erentürk', age: 31, pos: 'GK', role: 'GK', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Alperen Babacan', age: 29, pos: 'DEF', role: 'CB', ovr: 73, nat: 'Türkiye', start: true },
      { name: 'Zan Zuzek', age: 29, pos: 'DEF', role: 'CB', ovr: 74, nat: 'Slovenya', start: true },
      { name: 'Fıratcan Üzüm', age: 27, pos: 'DEF', role: 'RB', ovr: 71, nat: 'Türkiye', start: true },
      { name: 'Yasin Güreler', age: 35, pos: 'DEF', role: 'LB', ovr: 72, nat: 'Türkiye', start: true },
      { name: 'Oghenekaro Peter Etebo', age: 31, pos: 'MID', role: 'CDM', ovr: 76, nat: 'Nijerya', start: true },
      { name: 'Metehan Mimaroğlu', age: 31, pos: 'FW', role: 'LW', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Amilton', age: 37, pos: 'FW', role: 'RW', ovr: 75, nat: 'Brezilya', start: true },
      { name: 'Rahman Buğra Çağıran', age: 31, pos: 'MID', role: 'CAM', ovr: 74, nat: 'Türkiye', start: true },
      { name: 'Moussa Djitte', age: 27, pos: 'FW', role: 'ST', ovr: 73, nat: 'Senegal', start: true },
      { name: 'Mustapha Yatabare', age: 40, pos: 'FW', role: 'ST', ovr: 75, nat: 'Mali', start: true },
      { name: 'Orkun Özdemir', age: 31, pos: 'GK', role: 'GK', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Musa Şahindere', age: 23, pos: 'DEF', role: 'CB', ovr: 68, nat: 'Türkiye', start: false },
      { name: 'Halil İbrahim Pehlivan', age: 33, pos: 'DEF', role: 'LB', ovr: 71, nat: 'Türkiye', start: false },
      { name: 'Mikail Okyar', age: 27, pos: 'MID', role: 'CM', ovr: 73, nat: 'Türkiye', start: false },
      { name: 'Enes Keskin', age: 24, pos: 'MID', role: 'CM', ovr: 70, nat: 'Türkiye', start: false },
      { name: 'Samed Onur', age: 24, pos: 'MID', role: 'CM', ovr: 69, nat: 'Türkiye', start: false },
      { name: 'Awer Mabil', age: 30, pos: 'FW', role: 'LW', ovr: 74, nat: 'Avustralya', start: false },
      { name: 'Elias Durmaz', age: 26, pos: 'FW', role: 'RW', ovr: 70, nat: 'İsveç', start: false },
      { name: 'Olarenwaju Kayode', age: 33, pos: 'FW', role: 'ST', ovr: 73, nat: 'Nijerya', start: false },
      { name: 'Zafer Göktuğ Erdem', age: 22, pos: 'FW', role: 'ST', ovr: 66, nat: 'Türkiye', start: false },
      { name: 'Arda Yılmaz', age: 19, pos: 'FW', role: 'ST', ovr: 65, nat: 'Türkiye', start: false }
    ]
  }
];

function generateAttributes(pos, ovr) {
  let pace = ovr, shooting = ovr, passing = ovr, defending = ovr, physical = ovr;
  if (pos === 'GK') {
    pace = Math.min(60, ovr - 25);
    shooting = 15;
    passing = ovr - 10;
    defending = ovr;
    physical = ovr - 5;
  } else if (pos === 'DEF') {
    pace = ovr + Math.floor(Math.random() * 8) - 2;
    shooting = ovr - 25;
    passing = ovr - 8;
    defending = ovr + 4;
    physical = ovr + 3;
  } else if (pos === 'MID') {
    pace = ovr - 2;
    shooting = ovr - 5;
    passing = ovr + 5;
    defending = ovr - 5;
    physical = ovr;
  } else if (pos === 'FW') {
    pace = ovr + 6;
    shooting = ovr + 4;
    passing = ovr - 5;
    defending = 35;
    physical = ovr;
  }
  return {
    pace: Math.max(30, Math.min(99, pace)),
    shooting: Math.max(15, Math.min(99, shooting)),
    passing: Math.max(30, Math.min(99, passing)),
    defending: Math.max(25, Math.min(99, defending)),
    physical: Math.max(40, Math.min(99, physical))
  };
}

const teams = teamsMetaData.map(team => {
  const players = team.basePlayers.map((p, idx) => {
    const prefix = team.id.substring(0, 3);
    const pId = prefix + '-' + (idx + 1);
    const marketValue = p.ovr > 80 ? p.ovr * 2500000 : p.ovr * 120000;
    const item = {
      id: pId,
      name: p.name,
      age: p.age,
      position: p.pos,
      specificRole: p.role,
      overall: p.ovr,
      stamina: 85 + Math.floor(Math.random() * 8),
      form: Number((7.0 + (p.ovr - 70) * 0.1).toFixed(1)),
      marketValue: Math.max(300000, Math.round(marketValue)),
      nationality: p.nat,
      attributes: generateAttributes(p.pos, p.ovr),
      isStarting: p.start
    };
    if (!p.start && idx > 10 && idx <= 15) {
      item.subOrder = idx - 10;
    }
    return item;
  });

  return {
    id: team.id,
    name: team.name,
    shortName: team.shortName,
    badgeColor: team.badgeColor,
    badgeTextColor: team.badgeTextColor,
    secondaryColor: team.secondaryColor,
    stadiumName: team.stadiumName,
    budget: team.budget,
    reputation: team.reputation,
    formation: team.formation,
    tactic: team.tactic,
    players: players
  };
});

const fileContent = `import { Team, Player, LeagueRow } from '../types';

// Preferred team mapping for known key players
const PLAYER_PREFERRED_TEAM_MAP: Record<string, string> = {
  'Uğurcan Çakır': 'galatasaray',
  'Ferdi Kadıoğlu': 'fenerbahce',
  'Eren Elmalı': 'galatasaray',
  'Yasin Özcan': 'besiktas',
  'Pedrinho': 'kocaelispor',
  'Halil İbrahim Pehlivan': 'genclerbirligi',
  'Mame Thiam': 'corumfk',
  'Ahmed Kutucu': 'rizespor',
  'Umut Meraş': 'amedfk',
  'Erhan Erentürk': 'corumfk',
  'Ertuğrul Taşkıran': 'erzurumspor'
};

/**
 * Validation and deduplication function for Süper Lig Teams & Players
 */
export function validateAndDeduplicateTeams(rawTeams: Team[]): Team[] {
  const globalSeenPlayers = new Set<string>();
  const playerPrimaryTeamMap = new Map<string, string>();

  // Pass 1: Assign primary team for every player
  rawTeams.forEach(team => {
    team.players.forEach(p => {
      const cleanName = p.name.trim();
      if (!playerPrimaryTeamMap.has(cleanName)) {
        if (PLAYER_PREFERRED_TEAM_MAP[cleanName]) {
          playerPrimaryTeamMap.set(cleanName, PLAYER_PREFERRED_TEAM_MAP[cleanName]);
        } else {
          playerPrimaryTeamMap.set(cleanName, team.id);
        }
      }
    });
  });

  // Pass 2: Filter and sanitize team rosters
  return rawTeams.map(team => {
    const uniqueTeamPlayers: Player[] = [];
    const teamSeenNames = new Set<string>();

    team.players.forEach((p, index) => {
      const cleanName = p.name.trim();
      const primaryTeamId = playerPrimaryTeamMap.get(cleanName) || team.id;

      if (primaryTeamId === team.id && !teamSeenNames.has(cleanName) && !globalSeenPlayers.has(cleanName)) {
        teamSeenNames.add(cleanName);
        globalSeenPlayers.add(cleanName);

        const slug = cleanName.toLowerCase().replace(/[^a-z0-9]/g, '');
        const playerUniqueId = \`\${team.id}-\${slug || index}\`;

        uniqueTeamPlayers.push({
          ...p,
          id: playerUniqueId,
          teamId: team.id
        });
      }
    });

    return {
      ...team,
      players: uniqueTeamPlayers
    };
  });
}

const RAW_SUPER_LIG_TEAMS: Team[] = ${JSON.stringify(teams, null, 2)};

export const SUPER_LIG_TEAMS: Team[] = validateAndDeduplicateTeams(RAW_SUPER_LIG_TEAMS);

export const SUPER_LIG_LEAGUE_TABLE: LeagueRow[] = SUPER_LIG_TEAMS.map(team => ({
  teamId: team.id,
  teamName: team.name,
  played: 0,
  won: 0,
  drawn: 0,
  lost: 0,
  goalsFor: 0,
  goalsAgainst: 0,
  goalDifference: 0,
  points: 0,
  formHistory: []
}));
`;

const targetPath = path.resolve(process.cwd(), 'src/data/superLigTeams.ts');
fs.writeFileSync(targetPath, fileContent, 'utf-8');
console.log('✅ Successfully generated superLigTeams.ts with ' + teams.length + ' teams!');
