import fs from 'fs';
import path from 'path';

// Script to generate superLigTeams.ts with full 2026-2027 squads (25-35 players per team)

const superLigData = `import { Team, LeagueRow } from '../types';

export const SUPER_LIG_TEAMS: Team[] = [
  {
    id: 'galatasaray',
    name: 'Galatasaray',
    shortName: 'GS',
    badgeColor: 'from-amber-600 to-red-600',
    badgeTextColor: 'text-amber-300',
    secondaryColor: '#ea580c',
    stadiumName: 'RAMS Park',
    budget: 25000000,
    reputation: 5,
    formation: '4-2-3-1',
    tactic: 'ATTACKING',
    players: [
      { id: 'gs-1', name: 'Uğurcan Çakır', age: 30, position: 'GK', specificRole: 'GK', overall: 81, stamina: 90, form: 8.4, marketValue: 10000000, nationality: 'Türkiye', attributes: { pace: 50, shooting: 18, passing: 70, defending: 81, physical: 76 }, isStarting: true },
      { id: 'gs-2', name: 'Wilfried Singo', age: 25, position: 'DEF', specificRole: 'RB', overall: 80, stamina: 90, form: 8.1, marketValue: 18000000, nationality: 'Fildişi Sahili', attributes: { pace: 85, shooting: 55, passing: 72, defending: 80, physical: 84 }, isStarting: true },
      { id: 'gs-3', name: 'Davinson Sánchez', age: 30, position: 'DEF', specificRole: 'CB', overall: 84, stamina: 88, form: 8.8, marketValue: 18000000, nationality: 'Kolombiya', attributes: { pace: 78, shooting: 45, passing: 68, defending: 85, physical: 88 }, isStarting: true },
      { id: 'gs-4', name: 'Abdülkerim Bardakcı', age: 31, position: 'DEF', specificRole: 'CB', overall: 80, stamina: 85, form: 8.0, marketValue: 8000000, nationality: 'Türkiye', attributes: { pace: 68, shooting: 60, passing: 74, defending: 81, physical: 83 }, isStarting: true },
      { id: 'gs-5', name: 'Eren Elmalı', age: 26, position: 'DEF', specificRole: 'LB', overall: 76, stamina: 91, form: 7.7, marketValue: 5000000, nationality: 'Türkiye', attributes: { pace: 84, shooting: 52, passing: 68, defending: 74, physical: 74 }, isStarting: true },
      { id: 'gs-6', name: 'Lucas Torreira', age: 30, position: 'MID', specificRole: 'CDM', overall: 83, stamina: 95, form: 8.9, marketValue: 15000000, nationality: 'Uruguay', attributes: { pace: 72, shooting: 65, passing: 80, defending: 84, physical: 82 }, isStarting: true },
      { id: 'gs-7', name: 'İlkay Gündoğan', age: 35, position: 'MID', specificRole: 'CM', overall: 84, stamina: 86, form: 8.7, marketValue: 12000000, nationality: 'Almanya', attributes: { pace: 65, shooting: 78, passing: 90, defending: 72, physical: 72 }, isStarting: true },
      { id: 'gs-8', name: 'Gabriel Sara', age: 27, position: 'MID', specificRole: 'CAM', overall: 82, stamina: 91, form: 8.6, marketValue: 22000000, nationality: 'Brezilya', attributes: { pace: 76, shooting: 79, passing: 85, defending: 72, physical: 78 }, isStarting: true },
      { id: 'gs-9', name: 'Leroy Sané', age: 30, position: 'FW', specificRole: 'RW', overall: 84, stamina: 88, form: 8.8, marketValue: 35000000, nationality: 'Almanya', attributes: { pace: 91, shooting: 82, passing: 81, defending: 40, physical: 74 }, isStarting: true },
      { id: 'gs-10', name: 'Barış Alper Yılmaz', age: 26, position: 'FW', specificRole: 'LW', overall: 83, stamina: 94, form: 8.8, marketValue: 24000000, nationality: 'Türkiye', attributes: { pace: 92, shooting: 80, passing: 76, defending: 68, physical: 90 }, isStarting: true },
      { id: 'gs-11', name: 'Victor Osimhen', age: 27, position: 'FW', specificRole: 'ST', overall: 87, stamina: 90, form: 9.3, marketValue: 75000000, nationality: 'Nijerya', attributes: { pace: 90, shooting: 88, passing: 70, defending: 42, physical: 88 }, isStarting: true },
      { id: 'gs-12', name: 'Günay Güvenç', age: 35, position: 'GK', specificRole: 'GK', overall: 75, stamina: 88, form: 7.6, marketValue: 800000, nationality: 'Türkiye', attributes: { pace: 45, shooting: 15, passing: 65, defending: 75, physical: 73 }, isStarting: false, subOrder: 1 },
      { id: 'gs-13', name: 'Victor Nelsson', age: 27, position: 'DEF', specificRole: 'CB', overall: 79, stamina: 88, form: 7.8, marketValue: 12000000, nationality: 'Danimarka', attributes: { pace: 68, shooting: 40, passing: 68, defending: 80, physical: 82 }, isStarting: false, subOrder: 2 },
      { id: 'gs-14', name: 'Kaan Ayhan', age: 31, position: 'DEF', specificRole: 'CB', overall: 78, stamina: 88, form: 7.8, marketValue: 4500000, nationality: 'Türkiye', attributes: { pace: 68, shooting: 62, passing: 76, defending: 78, physical: 80 }, isStarting: false, subOrder: 3 },
      { id: 'gs-15', name: 'Elias Jelert', age: 23, position: 'DEF', specificRole: 'RB', overall: 77, stamina: 90, form: 7.7, marketValue: 8000000, nationality: 'Danimarka', attributes: { pace: 84, shooting: 58, passing: 72, defending: 74, physical: 72 }, isStarting: false, subOrder: 4 },
      { id: 'gs-16', name: 'Ismail Jakobs', age: 27, position: 'DEF', specificRole: 'LB', overall: 77, stamina: 89, form: 7.6, marketValue: 7000000, nationality: 'Senegal', attributes: { pace: 86, shooting: 55, passing: 70, defending: 74, physical: 78 }, isStarting: false },
      { id: 'gs-17', name: 'Kazımcan Karataş', age: 23, position: 'DEF', specificRole: 'LB', overall: 72, stamina: 88, form: 7.2, marketValue: 2000000, nationality: 'Türkiye', attributes: { pace: 80, shooting: 50, passing: 66, defending: 70, physical: 72 }, isStarting: false },
      { id: 'gs-18', name: 'Mario Lemina', age: 32, position: 'MID', specificRole: 'CDM', overall: 79, stamina: 88, form: 7.9, marketValue: 8000000, nationality: 'Gabon', attributes: { pace: 74, shooting: 65, passing: 76, defending: 80, physical: 82 }, isStarting: false },
      { id: 'gs-19', name: 'Lesley Ugochukwu', age: 22, position: 'MID', specificRole: 'CDM', overall: 78, stamina: 89, form: 7.8, marketValue: 12000000, nationality: 'Fransa', attributes: { pace: 72, shooting: 62, passing: 76, defending: 79, physical: 84 }, isStarting: false },
      { id: 'gs-20', name: 'Eyüp Aydın', age: 22, position: 'MID', specificRole: 'CDM', overall: 72, stamina: 86, form: 7.2, marketValue: 2500000, nationality: 'Almanya', attributes: { pace: 68, shooting: 60, passing: 75, defending: 71, physical: 72 }, isStarting: false },
      { id: 'gs-21', name: 'Yunus Akgün', age: 26, position: 'FW', specificRole: 'RW', overall: 80, stamina: 88, form: 8.3, marketValue: 14000000, nationality: 'Türkiye', attributes: { pace: 85, shooting: 76, passing: 78, defending: 52, physical: 68 }, isStarting: false },
      { id: 'gs-22', name: 'Roland Sallai', age: 29, position: 'FW', specificRole: 'RW', overall: 78, stamina: 87, form: 7.6, marketValue: 10000000, nationality: 'Macaristan', attributes: { pace: 82, shooting: 76, passing: 74, defending: 58, physical: 75 }, isStarting: false },
      { id: 'gs-23', name: 'Jankat Yılmaz', age: 21, position: 'GK', specificRole: 'GK', overall: 69, stamina: 86, form: 7.0, marketValue: 600000, nationality: 'Türkiye', attributes: { pace: 45, shooting: 15, passing: 60, defending: 69, physical: 70 }, isStarting: false },
      { id: 'gs-24', name: 'Ali Yeşilyurt', age: 21, position: 'DEF', specificRole: 'CB', overall: 66, stamina: 86, form: 6.9, marketValue: 300000, nationality: 'Türkiye', attributes: { pace: 66, shooting: 35, passing: 58, defending: 66, physical: 68 }, isStarting: false },
      { id: 'gs-25', name: 'Ali Turap Bülbül', age: 21, position: 'DEF', specificRole: 'RB', overall: 69, stamina: 88, form: 7.0, marketValue: 800000, nationality: 'Türkiye', attributes: { pace: 78, shooting: 48, passing: 64, defending: 68, physical: 70 }, isStarting: false },
      { id: 'gs-26', name: 'Arda Tagay', age: 18, position: 'MID', specificRole: 'CM', overall: 65, stamina: 86, form: 6.8, marketValue: 200000, nationality: 'Türkiye', attributes: { pace: 68, shooting: 58, passing: 66, defending: 60, physical: 64 }, isStarting: false },
      { id: 'gs-27', name: 'Arda Ünyay', age: 19, position: 'DEF', specificRole: 'CB', overall: 66, stamina: 86, form: 6.8, marketValue: 250000, nationality: 'Türkiye', attributes: { pace: 65, shooting: 35, passing: 58, defending: 66, physical: 68 }, isStarting: false },
      { id: 'gs-28', name: 'Arda Yılmaz', age: 19, position: 'GK', specificRole: 'GK', overall: 65, stamina: 85, form: 6.8, marketValue: 200000, nationality: 'Türkiye', attributes: { pace: 45, shooting: 15, passing: 55, defending: 65, physical: 66 }, isStarting: false },
      { id: 'gs-29', name: 'Berat Luş', age: 19, position: 'DEF', specificRole: 'LB', overall: 65, stamina: 86, form: 6.8, marketValue: 200000, nationality: 'Türkiye', attributes: { pace: 72, shooting: 45, passing: 60, defending: 64, physical: 65 }, isStarting: false },
      { id: 'gs-30', name: 'Can Armando Güner', age: 18, position: 'FW', specificRole: 'ST', overall: 68, stamina: 88, form: 7.0, marketValue: 500000, nationality: 'Türkiye', attributes: { pace: 76, shooting: 68, passing: 58, defending: 32, physical: 68 }, isStarting: false }
    ]
  }
];
`;
