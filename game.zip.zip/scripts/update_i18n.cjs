const fs = require('fs');
const path = require('path');

function walkDir(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walkDir(file));
    } else if (file.endsWith('.tsx') || file.endsWith('.ts')) {
      results.push(file);
    }
  });
  return results;
}

const files = walkDir('./src');
const keysUsed = new Set();
const keyRegex = /t\(\s*[\x27\x22]([A-Z0-9_]+)[\x27\x22]/g;

files.forEach(f => {
  if (f.includes('i18n.tsx')) return;
  const content = fs.readFileSync(f, 'utf8');
  let match;
  while ((match = keyRegex.exec(content)) !== null) {
    keysUsed.add(match[1]);
  }
});

console.log('Total keys used in app:', keysUsed.size);

// Read current i18n file to preserve existing translations
const i18nPath = './src/utils/i18n.tsx';
const i18nContent = fs.readFileSync(i18nPath, 'utf8');

// Simple dictionary generator or parser
// We will extract existing keys for TR, EN, DE, ES, FR, IT, PT
const langs = ['TR', 'EN', 'DE', 'ES', 'FR', 'IT', 'PT'];
const dicts = {
  TR: {}, EN: {}, DE: {}, ES: {}, FR: {}, IT: {}, PT: {}
};

// Helper to sanitize value: remove underscores, ensure clean text
function sanitizeValue(str) {
  if (!str) return '';
  return str.replace(/_/g, ' ').replace(/\s+/g, ' ').trim();
}

// Extract existing dictionary entries using regex
langs.forEach(lang => {
  const startIdx = i18nContent.indexOf(`${lang}: {`);
  if (startIdx === -1) return;
  
  // find matching section
  let endIdx = i18nContent.length;
  for (let l of langs) {
    if (l !== lang) {
      const idx = i18nContent.indexOf(`${l}: {`, startIdx + 5);
      if (idx !== -1 && idx < endIdx) {
        endIdx = idx;
      }
    }
  }
  const section = i18nContent.substring(startIdx, endIdx);
  const entryRegex = /([A-Z0-9_]+):\s*[\x27\x22]([^\x27\x22]*)[\x27\x22]/g;
  let m;
  while ((m = entryRegex.exec(section)) !== null) {
    const key = m[1];
    const val = sanitizeValue(m[2]);
    dicts[lang][key] = val;
  }
});

console.log('Extracted key counts per language from current i18n.tsx:');
langs.forEach(l => console.log(`  ${l}: ${Object.keys(dicts[l]).length}`));

// Key translation dictionary for new/missing keys
const missingTranslations = {
  BOARD_STATUS_SAFE: { TR: "Güvenli", EN: "Safe", DE: "Sicher", ES: "Seguro", FR: "Sécurisé", IT: "Sicuro", PT: "Seguro" },
  BOARD_JOB_SECURE: { TR: "Göreviniz Güvende", EN: "Job Position Secure", DE: "Job Position Sicher", ES: "Puesto Seguro", FR: "Poste Sécurisé", IT: "Posizione Sicura", PT: "Cargo Seguro" },
  BOARD_STATUS_EXCELLENT: { TR: "Mükemmel Güven", EN: "Excellent Trust", DE: "Hervorragend", ES: "Excelente", FR: "Excellent", IT: "Eccellente", PT: "Excelente" },
  BOARD_JOB_HISTORIC: { TR: "Efsanevi Dönem", EN: "Historic Tenure", DE: "Historische Amtszeit", ES: "Etapa Histórica", FR: "Mandat Historique", IT: "Periodo Storico", PT: "Mandato Histórico" },
  BOARD_STATUS_STABLE: { TR: "Dengeli", EN: "Stable", DE: "Stabil", ES: "Estable", FR: "Stable", IT: "Stabile", PT: "Estável" },
  BOARD_STATUS_NEUTRAL: { TR: "Nötr", EN: "Neutral", DE: "Neutral", ES: "Neutral", FR: "Neutre", IT: "Neutro", PT: "Neutro" },
  BOARD_JOB_WATCHED: { TR: "Yönetim İzliyor", EN: "Under Review", DE: "Unter Beobachtung", ES: "Bajo Observación", FR: "Sous Surveillance", IT: "Sotto Osservazione", PT: "Sob Observação" },
  BOARD_STATUS_CRITICAL: { TR: "Kritik", EN: "Critical", DE: "Kritisch", ES: "Crítico", FR: "Critique", IT: "Critico", PT: "Crítico" },
  BOARD_JOB_URGENT: { TR: "Ayrılık Yakın", EN: "Urgent Risk", DE: "Dringendes Risiko", ES: "Riesgo Inminente", FR: "Risque Imminent", IT: "Rischio Imminente", PT: "Risco Iminente" },
  NEGOTIATION_YOUNG_REJECTED: { TR: "Genç oyuncu ayrılmak istemiyor", EN: "Young player rejects transfer", DE: "Junger Spieler lehnt Transfer ab", ES: "El joven jugador rechaza el traspaso", FR: "Le jeune joueur refuse le transfert", IT: "Il giovane giocatore rifiuta il trasferimento", PT: "Jovem jogador recusa transferência" },
  NEGOTIATION_MAX_5_YEARS: { TR: "Maksimum 5 yıllık sözleşme yapılabilir", EN: "Maximum 5 years contract allowed", DE: "Maximal 5 Jahre Vertrag erlaubt", ES: "Máximo 5 años de contrato", FR: "Contrat de 5 ans maximum", IT: "Massimo 5 anni di contratto", PT: "Máximo 5 anos de contrato" },
  NEGOTIATION_WAGE_LOW: { TR: "Maaş teklifi beklentinin altında", EN: "Wage offer is below expectations", DE: "Gehaltsangebot liegt unter den Erwartungen", ES: "La oferta salarial está por debajo de las expectativas", FR: "L'offre salariale est inférieure aux attentes", IT: "L'offerta salariale è inferiore alle aspettative", PT: "A oferta salarial está abaixo das expectativas" },
  NEGOTIATION_AGREED_SUCCESS: { TR: "Sözleşme şartlarında anlaşıldı!", EN: "Contract terms agreed successfully!", DE: "Vertragsbedingungen erfolgreich vereinbart!", ES: "¡Términos del contrato acordados!", FR: "Conditions contractuelles acceptées !", IT: "Termini contrattuali concordati!", PT: "Termos do contrato acordados!" },
  CONTRACT_RENEWED_TITLE: { TR: "Sözleşme Yenilendi! 📝", EN: "Contract Renewed! 📝", DE: "Vertrag Verlängert! 📝", ES: "¡Contrato Renovado! 📝", FR: "Contrat Renouvelé ! 📝", IT: "Contratto Rinnovato! 📝", PT: "Contrato Renovado! 📝" },
  CONTRACT_RENEWED_MSG: { TR: "{name} ile {years} yıllık yeni sözleşme imzalandı.", EN: "{name} signed a new {years}-year contract.", DE: "{name} hat einen neuen {years}-Jahres-Vertrag unterschrieben.", ES: "{name} firmó un nuevo contrato de {years} años.", FR: "{name} a signé un nouveau contrat de {years} ans.", IT: "{name} ha firmato un nuovo contratto di {years} anni.", PT: "{name} assinou um novo contrato de {years} anos." },
  ADDED_TRANSFER_LIST: { TR: "Transfer Listesine Eklendi", EN: "Added to Transfer List", DE: "Zur Transferliste hinzugefügt", ES: "Añadido a la lista de traspasos", FR: "Ajouté à la liste des transferts", IT: "Aggiunto alla lista trasferimenti", PT: "Adicionado à lista de transferências" },
  REMOVED_TRANSFER_LIST: { TR: "Transfer Listesinden Çıkarıldı", EN: "Removed from Transfer List", DE: "Von Transferliste entfernt", ES: "Eliminado de la lista de traspasos", FR: "Retiré de la liste des transferts", IT: "Rimosso dalla lista trasferimenti", PT: "Removido da lista de transferências" },
  MSG_ADDED_TRANSFER: { TR: "{name} transfer listesine koyuldu.", EN: "{name} has been placed on the transfer list.", DE: "{name} wurde auf die Transferliste gesetzt.", ES: "{name} ha sido puesto en la lista de traspasos.", FR: "{name} a été placé sur la liste des transferts.", IT: "{name} è stato inserito nella lista trasferimenti.", PT: "{name} foi colocado na lista de transferências." },
  MSG_REMOVED_TRANSFER: { TR: "{name} transfer listesinden alındı.", EN: "{name} removed from transfer list.", DE: "{name} von der Transferliste genommen.", ES: "{name} retirado de la lista de traspasos.", FR: "{name} retiré de la liste des transferts.", IT: "{name} rimosso dalla lista trasferimenti.", PT: "{name} removido da lista de transferências." },
  ADDED_LOAN_LIST: { TR: "Kiralık Listesine Eklendi", EN: "Added to Loan List", DE: "Zur Leihliste hinzugefügt", ES: "Añadido a la lista de cedidos", FR: "Ajouté à la liste des prêts", IT: "Aggiunto alla lista prestiti", PT: "Adicionado à lista de empréstimos" },
  REMOVED_LOAN_LIST: { TR: "Kiralık Listesinden Çıkarıldı", EN: "Removed from Loan List", DE: "Von Leihliste entfernt", ES: "Eliminado de la lista de cedidos", FR: "Retiré de la liste des prêts", IT: "Rimosso dalla lista prestiti", PT: "Removido da lista de empréstimos" },
  MSG_ADDED_LOAN: { TR: "{name} kiralık listesine eklendi.", EN: "{name} added to loan list.", DE: "{name} zur Leihliste hinzugefügt.", ES: "{name} añadido a la lista de cedidos.", FR: "{name} ajouté à la liste des prêts.", IT: "{name} aggiunto alla lista prestiti.", PT: "{name} adicionado à lista de empréstimos." },
  MSG_REMOVED_LOAN: { TR: "{name} kiralık listesinden çıkarıldı.", EN: "{name} removed from loan list.", DE: "{name} von der Leihliste entfernt.", ES: "{name} retirado de la lista de cedidos.", FR: "{name} retiré de la liste des prêts.", IT: "{name} rimosso dalla lista prestiti.", PT: "{name} removido da lista de empréstimos." },
  CONTRACT_END: { TR: "Sözleşme Bitişi", EN: "Contract End", DE: "Vertragsende", ES: "Fin de Contrato", FR: "Fin de Contrat", IT: "Fine Contratto", PT: "Fim do Contrato" },
  LOAN_PLAYER_INFO_TITLE: { TR: "Kiralık Oyuncu Bilgisi", EN: "Loan Player Info", DE: "Leihspieler-Info", ES: "Info de Jugador Cedido", FR: "Info Joueur Prêté", IT: "Info Giocatore in Prestito", PT: "Info de Jogador Emprestado" },
  LOAN_PLAYER_INFO_DESC: { TR: "Bu oyuncu kulübünüzde kiralık oynamaktadır.", EN: "This player is currently on loan at your club.", DE: "Dieser Spieler ist derzeit an Ihren Verein ausgeliehen.", ES: "Este jugador está actualmente cedido en tu club.", FR: "Ce joueur est actuellement prêté à votre club.", IT: "Questo giocatore è attualmente in prestito nel tuo club.", PT: "Este jogador está atualmente emprestado ao seu clube." },
  PARENT_CLUB: { TR: "Asıl Kulübü", EN: "Parent Club", DE: "Stammverein", ES: "Club Propietario", FR: "Club Parent", IT: "Club di Appartenenza", PT: "Clube de Origem" },
  LOAN_CONTRACT_END: { TR: "Kiralama Bitişi", EN: "Loan End Date", DE: "Leihende", ES: "Fin de la Cesión", FR: "Fin du Prêt", IT: "Fine Prestito", PT: "Fim do Empréstimo" },
  JUNE: { TR: "Haziran", EN: "June", DE: "Juni", ES: "Junio", FR: "Juin", IT: "Giugno", PT: "Junho" },
  BUY_PERMANENT_QUESTION: { TR: "Oyuncuyu bonservisiyle satın almak ister misiniz?", EN: "Would you like to buy this player permanently?", DE: "Möchten Sie diesen Spieler fest verpflichten?", ES: "¿Quieres comprar a este jugador permanentemente?", FR: "Voulez-vous acheter ce joueur définitivement ?", IT: "Vuoi acquistare questo giocatore a titolo definitivo?", PT: "Deseja comprar este jogador em definitivo?" },
  BUY_TRANSFER_OFFER: { TR: "Bonservis Teklifi Yap", EN: "Make Transfer Offer", DE: "Transferangebot Machen", ES: "Hacer Oferta de Traspaso", FR: "Faire une Offre de Transfert", IT: "Fai Offerta di Trasferimento", PT: "Fazer Oferta de Transferência" },
  CONTRACT_ACTION_BLOCKED: { TR: "İşlem Engelı", EN: "Action Blocked", DE: "Aktion Blockiert", ES: "Acción Bloqueada", FR: "Action Bloquée", IT: "Azione Bloccata", PT: "Ação Bloqueada" },
  OTHER_TEAM_PLAYER_WARNING: { TR: "Başka takımın oyuncusu için sadece transfer teklifi yapabilirsiniz.", EN: "You can only make transfer offers for players from other teams.", DE: "Sie können nur Transferangebote für Spieler anderer Teams machen.", ES: "Solo puedes hacer ofertas de traspaso por jugadores de otros equipos.", FR: "Vous ne pouvez faire des offres de transfert que pour les joueurs d'autres équipes.", IT: "Puoi fare offerte di trasferimento solo per giocatori di altre squadre.", PT: "Apenas pode fazer ofertas de transferência para jogadores de outras equipas." },
  OK_BTN: { TR: "Tamam", EN: "OK", DE: "OK", ES: "Aceptar", FR: "D'accord", IT: "OK", PT: "OK" },
  TAB_CONTRACT_ACTIONS: { TR: "Sözleşme & Liste", EN: "Contract & Status", DE: "Vertrag & Status", ES: "Contrato y Estado", FR: "Contrat et Statut", IT: "Contratto e Stato", PT: "Contrato e Estado" },
  TAB_EXTEND_CONTRACT: { TR: "Sözleşme Uzat", EN: "Extend Contract", DE: "Vertrag Verlängern", ES: "Renovar Contrato", FR: "Prolonger le Contrat", IT: "Rinnova Contratto", PT: "Renovar Contrato" },
  CURRENT_WEEKLY_WAGE: { TR: "Mevcut Haftalık Maaş", EN: "Current Weekly Wage", DE: "Aktuelles Wochengehalt", ES: "Salario Semanal Actual", FR: "Salaire Hebdomadaire Actuel", IT: "Stipendio Settimanale Attuale", PT: "Salário Semanal Atual" },
  PER_WEEK: { TR: "Hafta", EN: "Week", DE: "Woche", ES: "Semana", FR: "Semaine", IT: "Settimana", PT: "Semana" },
  PLAYER_STATUS: { TR: "Oyuncu Durumu", EN: "Player Status", DE: "Spielerstatus", ES: "Estado del Jugador", FR: "Statut du Joueur", IT: "Stato del Giocatore", PT: "Estado do Jogador" },
  YOUNG_TALENT: { TR: "Genç Yetenek", EN: "Young Talent", DE: "Junges Talent", ES: "Joven Talento", FR: "Jeune Talent", IT: "Giovane Talento", PT: "Jovem Talento" },
  VETERAN_PLAYER: { TR: "Deneyimli Oyuncu", EN: "Veteran Player", DE: "Erfahrener Spieler", ES: "Jugador Experto", FR: "Joueur Expérimenté", IT: "Giocatore Esperto", PT: "Jogador Experiente" },
  KEY_PLAYER: { TR: "Kilit Oyuncu", EN: "Key Player", DE: "Schlüsselspieler", ES: "Jugador Clave", FR: "Joueur Clé", IT: "Giocatore Chiave", PT: "Jogador Chave" },
  BTN_CONTRACT_NEGOTIATION: { TR: "Sözleşme Yenileme Görüşmesi", EN: "Contract Renewal Talks", DE: "Vertragsverhandlungen", ES: "Negociación de Contrato", FR: "Négociations de Contrat", IT: "Trattativa di Contratto", PT: "Negociação de Contrato" },
  TOGGLE_TRANSFER_LIST: { TR: "Transfer Listesi Durumu", EN: "Transfer List Status", DE: "Transferlisten-Status", ES: "Estado Lista de Traspasos", FR: "Statut Liste de Transfert", IT: "Stato Lista Trasferimenti", PT: "Estado Lista de Transferências" },
  LISTED_TRANSFER: { TR: "Transfer Listesinde", EN: "Listed for Transfer", DE: "Auf Transferliste", ES: "En Lista de Traspasos", FR: "Sur la Liste des Transferts", IT: "In Lista Trasferimenti", PT: "Na Lista de Transferências" },
  NOT_LISTED: { TR: "Listede Değil", EN: "Not Listed", DE: "Nicht Gelistet", ES: "No Listado", FR: "Non Listé", IT: "Non in Lista", PT: "Não Listado" },
  TOGGLE_LOAN_LIST: { TR: "Kiralık Listesi Durumu", EN: "Loan List Status", DE: "Leihlisten-Status", ES: "Estado Lista de Cedidos", FR: "Statut Liste de Prêt", IT: "Stato Lista Prestiti", PT: "Estado Lista de Empréstimos" },
  LISTED_LOAN: { TR: "Kiralık Listesinde", EN: "Listed for Loan", DE: "Auf Leihliste", ES: "En Lista de Cedidos", FR: "Sur la Liste des Prêts", IT: "In Lista Prestiti", PT: "Na Lista de Empréstimos" },
  CURRENT_WAGE_LABEL: { TR: "Mevcut Maaş", EN: "Current Wage", DE: "Aktuelles Gehalt", ES: "Salario Actual", FR: "Salaire Actuel", IT: "Stipendio Attuale", PT: "Salário Atual" },
  EXPECTED_WAGE_LABEL: { TR: "Beklenen Maaş", EN: "Expected Wage", DE: "Erwartetes Gehalt", ES: "Salario Esperado", FR: "Salaire Espéré", IT: "Stipendio Atteso", PT: "Salário Esperado" },
  YOUNG_PLAYER_CONTRACT_LIMIT: { TR: "Genç oyuncular için maksimum 3 yıl önerilebilir.", EN: "Max 3 years contract recommendation for young players.", DE: "Maximal 3 Jahre Vertrag für junge Spieler empfohlen.", ES: "Recomendado máximo 3 años para jugadores jóvenes.", FR: "Recommandation max 3 ans pour les jeunes joueurs.", IT: "Consigliato massimo 3 anni per i giovani.", PT: "Recomendado máximo 3 anos para jovens." },
  YEARS_TO_EXTEND: { TR: "Uzatılacak Süre", EN: "Years to Extend", DE: "Verlängerungsdauer", ES: "Años a Renovar", FR: "Années à Prolonger", IT: "Anni di Rinnovo", PT: "Anos a Renovar" },
  YEARS_UNIT: { TR: "Yıl", EN: "Years", DE: "Jahre", ES: "Años", FR: "Ans", IT: "Anni", PT: "Anos" },
  OFFERED_WAGE_LABEL: { TR: "Teklif Edilen Maaş", EN: "Offered Wage", DE: "Angebotenes Gehalt", ES: "Salario Ofrecido", FR: "Salaire Proposé", IT: "Stipendio Offerto", PT: "Salário Oferecido" },
  RELEGATION_CLAUSE_TITLE: { TR: "Küme Düşme Tazminatı Serbest Kalma Maddesi", EN: "Relegation Release Clause", DE: "Abstiegs-Ausstiegsklausel", ES: "Cláusula por Descenso", FR: "Clause de Libération en cas de Relégation", IT: "Clausola di Retrocessione", PT: "Cláusula de Despromoção" },
  BACK_BTN: { TR: "Geri", EN: "Back", DE: "Zurück", ES: "Atrás", FR: "Retour", IT: "Indietro", PT: "Voltar" },
  OFFER_CONTRACT_SUBMIT: { TR: "Sözleşme Teklifini Gönder", EN: "Submit Contract Offer", DE: "Vertragsangebot Einreichen", ES: "Enviar Oferta de Contrato", FR: "Soumettre l'Offre de Contrat", IT: "Invia Offerta di Contratto", PT: "Enviar Oferta de Contrato" },
  FINANCES_SUBTITLE: { TR: "Kulüp Bütçesi & Gelir Gider Raporu", EN: "Club Budget & Revenue Balance", DE: "Vereinsbudget & Finanzbericht", ES: "Presupuesto del Club y Balance", FR: "Budget du Club et Bilan", IT: "Bilancio del Club e Incassi", PT: "Orçamento do Clube e Balanço" },
  TREASURY_TRANSFER_BUDGET: { TR: "Kulüp Kasası Transfer Bütçesi", EN: "Treasury Transfer Budget", DE: "Transferbudget der Kasse", ES: "Presupuesto de Traspasos", FR: "Budget de Transfert de la Trésorerie", IT: "Budget Trasferimenti Cassa", PT: "Orçamento de Transferências" },
  BUDGET_CRITICAL_WARNING: { TR: "Finansal Kritik Uyarı", EN: "Financial Critical Warning", DE: "Finanzielle Warnung", ES: "Advertencia Financiera Crítica", FR: "Avertissement Financier Critique", IT: "Avviso Finanziario Critico", PT: "Aviso Financeiro Crítico" },
  BUDGET_OK_INFO: { TR: "Bütçe Durumu Sağlıklı", EN: "Budget Status Healthy", DE: "Budgetstatus Gesund", ES: "Estado Presupuestario Saludable", FR: "Statut Budgétaire Sain", IT: "Stato Bilancio Sano", PT: "Estado Orçamental Saudável" },
  ANNUAL_LABEL: { TR: "Yıllık", EN: "Annual", DE: "Jährlich", ES: "Anual", FR: "Annuel", IT: "Annuale", PT: "Anual" },
  MATCHDAY_TICKETS: { TR: "Maç Günü Bilet & Stat Geliri", EN: "Matchday Ticket Revenue", DE: "Spieltag-Ticket-Einnahmen", ES: "Ingresos por Entradas", FR: "Revenus Billetterie Jour de Match", IT: "Incassi Biglietti Giorno di Gara", PT: "Receita de Bilheteira" },
  TV_BROADCASTING: { TR: "TV Yayın & Medya Hakları", EN: "TV Broadcasting Rights", DE: "TV-Übertragungsrechte", ES: "Derechos de Televisión", FR: "Droits TV et Médias", IT: "Diritti TV e Media", PT: "Direitos de Transmissão TV" },
  SPONSORSHIP_COMMERICAL: { TR: "Sponsorluk & Ticari Anlaşmalar", EN: "Sponsorship & Commercial", DE: "Sponsoring & Kommerziell", ES: "Patrocinio y Acuerdos Comerciales", FR: "Sponsorat et Commercial", IT: "Sponsorizzazioni e Commerciale", PT: "Patrocínios e Comercial" },
  STORE_MERCHANDISE: { TR: "Store & Forma Satışları", EN: "Store Merchandise Sales", DE: "Fanshop & Trikotverkäufe", ES: "Ventas en Tienda Oficial", FR: "Ventes Boutique et Maillots", IT: "Vendite Store e Maglie", PT: "Vendas de Loja e Camisolas" },
  TOTAL_PLAYER_WAGES: { TR: "Toplam Oyuncu Maaş Ödemeleri", EN: "Total Player Wage Payroll", DE: "Gesamte Spielergehälter", ES: "Masa Salarial de Jugadores", FR: "Masse Salariale Totale", IT: "Monte Ingaggi Totale", PT: "Massa Salarial Total" },
  FACILITY_MAINTENANCE: { TR: "Tesis & Personel Giderleri", EN: "Facility & Staff Expense", DE: "Einrichtungs- & Personalkosten", ES: "Gastos de Instalaciones y Personal", FR: "Frais d'Installations et Personnel", IT: "Spese Strutture e Personale", PT: "Despesas de Instalações e Pessoal" },
  TRANSFER_INSTALLMENTS: { TR: "Transfer Taksit Giderleri", EN: "Transfer Installment Debts", DE: "Transfer-Ratenverpflichtungen", ES: "Cuotas de Traspaso", FR: "Paiements Échelonnés de Transfert", IT: "Rate di Trasferimento", PT: "Prestações de Transferência" },
  INCLUDED_ANNUAL_INSTALLMENT: { TR: "Dahil Edilen Yıllık Taksitler", EN: "Included Annual Installments", DE: "Enthaltene Jahresraten", ES: "Cuotas Anuales Incluidas", FR: "Mentalités Annuelles Incluses", IT: "Rate Annuali Incluse", PT: "Prestações Anuais Incluídas" },
  SEASONAL_NET_BALANCE: { TR: "Sezonluk Net Bütçe Dengesi", EN: "Seasonal Net Budget Balance", DE: "Saisonales Netto-Budget", ES: "Balance Neto de Temporada", FR: "Bilan Net Saisonnier", IT: "Bilancio Netto Stagionale", PT: "Balanço Neto da Época" },
  FINANCE_RULES_NOTE: { TR: "Finansal Fair Play Kuralları", EN: "Financial Fair Play Regulations", DE: "Financial Fairplay Regeln", ES: "Reglas de Juego Limpio Financiero", FR: "Règles du Fair-Play Financier", IT: "Regole Fair Play Finanziario", PT: "Regras do Fair Play Financeiro" },
  ALL_MESSAGES_READ: { TR: "Tüm Mesajlar Okundu", EN: "All Messages Read", DE: "Alle Nachrichten Gelesen", ES: "Todos los Mensajes Leídos", FR: "Tous les Messages Lus", IT: "Tutti i Messaggi Letti", PT: "Todas as Mensagens Lidas" },
  FILTER_CURRENT_ROLE: { TR: "Mevki", EN: "Position", DE: "Position", ES: "Posición", FR: "Poste", IT: "Ruolo", PT: "Posição" },
  FILTER_LAST_RATING: { TR: "Son Reyting", EN: "Last Rating", DE: "Letzte Bewertung", ES: "Última Valoración", FR: "Dernière Note", IT: "Ultimo Voto", PT: "Última Classificação" },
  FILTER_AGE: { TR: "Yaş", EN: "Age", DE: "Alter", ES: "Edad", FR: "Âge", IT: "Età", PT: "Idade" },
  FILTER_STAMINA_MORALE: { TR: "Kondisyon / Moral", EN: "Stamina / Morale", DE: "Kondition / Moral", ES: "Forma / Moral", FR: "Forme / Moral", IT: "Condizione / Morale", PT: "Forma / Moral" },
  FILTER_VALUE_WAGE: { TR: "Piyasa Değeri & Maaş", EN: "Value & Wage", DE: "Wert & Gehalt", ES: "Valor y Salario", FR: "Valeur et Salaire", IT: "Valore e Stipendio", PT: "Valor e Salário" },
  INJURY_TYPE_MUSCLE: { TR: "Sakatlık", EN: "Injured", DE: "Verletzt", ES: "Lesionado", FR: "Blessé", IT: "Infortunato", PT: "Lesionado" },
  CLICK_PLAYER_PROFILE: { TR: "Profil için tıklayın", EN: "Click for profile", DE: "Für Profil klicken", ES: "Haz clic para ver el perfil", FR: "Cliquer pour le profil", IT: "Clicca per il profilo", PT: "Clique para o perfil" },
  RECOVERED_PROGRESS: { TR: "İyileşme İlerlemesi", EN: "Recovery Progress", DE: "Genesungsfortschritt", ES: "Progreso de Recuperación", FR: "Progrès de Rétablissement", IT: "Progresso di Guarigione", PT: "Progresso de Recuperação" },
  STARTING_ELEVEN: { TR: "İlk 11 Kadrosu", EN: "Starting XI Squad", DE: "Startelf-Kader", ES: "Alineación Titular", FR: "Onze de Départ", IT: "Formazione Titolare", PT: "Onze Inicial" },
  EMPTY_SLOT_TITLE: { TR: "Boş Pozisyon", EN: "Empty Position", DE: "Freie Position", ES: "Posición Vacante", FR: "Poste Vacant", IT: "Posizione Vuota", PT: "Posição Vaga" },
  BENCH_SUBSTITUTES: { TR: "Yedekler (Bench)", EN: "Substitutes Bench", DE: "Ersatzbank", ES: "Banquillo de Suplentes", FR: "Banc de Touche", IT: "Panchina", PT: "Banco de Suplentes" },
  RESERVES_UNASSIGNED: { TR: "Kadro Dışı & Rezervler", EN: "Reserves & Unassigned", DE: "Reserve & Nicht Zugeordnet", ES: "Reservas y Sin Asignar", FR: "Réserves et Non Assignés", IT: "Riserve e Fuori Rosa", PT: "Reservas e Não Convocados" },
  VACATION_POLICY_NONE_TITLE: { TR: "Otomatik Yanıt Yok", EN: "No Auto Response", DE: "Keine Automatische Antwort", ES: "Sin Respuesta Automática", FR: "Pas de Réponse Automatique", IT: "Nessuna Risposta Automatica", PT: "Sem Resposta Automática" },
  VACATION_POLICY_NONE_DESC: { TR: "Gelen teklifler kutunuzda bekler.", EN: "Incoming offers wait in inbox.", DE: "Eingehende Angebote warten im Posteingang.", ES: "Las ofertas entrantes esperan en el buzón.", FR: "Les offres restent en boîte de réception.", IT: "Le offerte in arrivo attendono in posta.", PT: "As ofertas ficam a aguardar na caixa de entrada." },
  VACATION_POLICY_NONE_BADGE: { TR: "Standart", EN: "Standard", DE: "Standard", ES: "Estándar", FR: "Standard", IT: "Standard", PT: "Padrão" },
  VACATION_POLICY_REJECT_TRANSFERS_TITLE: { TR: "Transferleri Reddet", EN: "Reject Transfer Offers", DE: "Transferangebote Ablehnen", ES: "Rechazar Traspasos", FR: "Refuser les Transferts", IT: "Rifiuta Trasferimenti", PT: "Recusar Transferências" },
  VACATION_POLICY_REJECT_TRANSFERS_DESC: { TR: "Tüm bonservis teklifleri otomatik reddedilir.", EN: "All transfer offers automatically rejected.", DE: "Alle Transferangebote automatisch abgelehnt.", ES: "Ofertas de traspaso rechazadas automáticamente.", FR: "Toutes les offres de transfert sont refusées.", IT: "Tutte le offerte rifiutate automaticamente.", PT: "Todas as ofertas recusadas automaticamente." },
  VACATION_POLICY_REJECT_TRANSFERS_BADGE: { TR: "Gelenler Red", EN: "Reject Transfers", DE: "Transfers Ablehnen", ES: "Rechazar Traspasos", FR: "Refuser Transferts", IT: "Rifiuta Trasferimenti", PT: "Recusar Transferências" },
  VACATION_POLICY_REJECT_LOANS_TITLE: { TR: "Kiralıkları Reddet", EN: "Reject Loan Offers", DE: "Leihangebote Ablehnen", ES: "Rechazar Cesiones", FR: "Refuser les Prêts", IT: "Rifiuta Prestiti", PT: "Recusar Empréstimos" },
  VACATION_POLICY_REJECT_LOANS_DESC: { TR: "Kiralama teklifleri otomatik reddedilir.", EN: "Loan offers automatically rejected.", DE: "Leihangebote automatisch abgelehnt.", ES: "Ofertas de cesión rechazadas automáticamente.", FR: "Offres de prêt refusées automatiquement.", IT: "Offerte di prestito rifiutate automaticamente.", PT: "Ofertas de empréstimo recusadas automaticamente." },
  VACATION_POLICY_REJECT_LOANS_BADGE: { TR: "Kiralık Red", EN: "Reject Loans", DE: "Leihen Ablehnen", ES: "Rechazar Cesiones", FR: "Refuser Prêts", IT: "Rifiuta Prestiti", PT: "Recusar Empréstimos" },
  VACATION_POLICY_REJECT_ALL_TITLE: { TR: "Tüm Teklifleri Reddet", EN: "Reject All Offers", DE: "Alle Angebote Ablehnen", ES: "Rechazar Todas las Ofertas", FR: "Refuser Toutes les Offres", IT: "Rifiuta Tutte le Offerte", PT: "Recusar Todas as Ofertas" },
  VACATION_POLICY_REJECT_ALL_DESC: { TR: "Transfer ve kiralama teklifleri reddedilir.", EN: "Both transfer and loan offers rejected.", DE: "Sowohl Transfer- als auch Leihangebote abgelehnt.", ES: "Se rechazan traspasos y cesiones.", FR: "Transferts et prêts sont refusés.", IT: "Rifiutate sia trasferimenti che prestiti.", PT: "Recusadas ofertas de transferência e empréstimo." },
  VACATION_POLICY_REJECT_ALL_BADGE: { TR: "Sıkı Koruma", EN: "Strict Lock", DE: "Strenge Sperre", ES: "Bloqueo Estricto", FR: "Verrouillage Stricte", IT: "Blocco Stretto", PT: "Bloqueio Estrito" },
  VACATION_POLICY_ACCEPT_LOAN_TITLE: { TR: "Uygun Kiralıkları Kabul Et", EN: "Accept Fair Loans", DE: "Angemessene Leihen Annehmen", ES: "Aceptar Cesiones Adecuadas", FR: "Accepter les Prêts Raisonnables", IT: "Accetta Prestiti Congrui", PT: "Aceitar Empréstimos Adequados" },
  VACATION_POLICY_ACCEPT_LOAN_DESC: { TR: "%50+ maaş karşılayan kiralıklar kabul edilir.", EN: "Loans covering 50%+ wages accepted.", DE: "Leihen mit 50%+ Gehaltsübernahme angenommen.", ES: "Cesiones que cubran el 50%+ del salario aceptadas.", FR: "Prêts couvrant 50%+ des salaires acceptés.", IT: "Prestiti con 50%+ stipendio coperto accettati.", PT: "Empréstimos que cubram 50%+ do salário aceites." },
  VACATION_POLICY_ACCEPT_LOAN_BADGE: { TR: "Esnek Kiralık", EN: "Flexible Loan", DE: "Flexible Leihe", ES: "Cesión Flexible", FR: "Prêt Flexible", IT: "Prestito Flessibile", PT: "Empréstimo Flexível" },
  VACATION_POLICY_ACCEPT_TRANSFER_TITLE: { TR: "Yüksek Teklifleri Kabul Et", EN: "Accept High Offers", DE: "Hohe Angebote Annehmen", ES: "Aceptar Ofertas Altas", FR: "Accepter les Fortes Offres", IT: "Accetta Alte Offerte", PT: "Aceitar Ofertas Altas" },
  VACATION_POLICY_ACCEPT_TRANSFER_DESC: { TR: "Piyasa değerinin %120+ teklifleri onaylanır.", EN: "Offers 120%+ market value accepted.", DE: "Angebote 120%+ Marktwert angenommen.", ES: "Ofertas del 120%+ del valor aceptadas.", FR: "Offres à 120%+ de la valeur acceptées.", IT: "Offerte pari a 120%+ del valore accettate.", PT: "Ofertas de 120%+ do valor aceites." },
  VACATION_POLICY_ACCEPT_TRANSFER_BADGE: { TR: "Fırsatçı", EN: "Opportunist", DE: "Opportunistisch", ES: "Oportunista", FR: "Opportuniste", IT: "Opportunista", PT: "Oportunista" },
  VACATION_1_DAY_TITLE: { TR: "1 Gün İlerle", EN: "1 Day Pass", DE: "1 Tag Weiter", ES: "Avanzar 1 Día", FR: "Avancer de 1 Jour", IT: "Avanza di 1 Giorno", PT: "Avançar 1 Dia" },
  VACATION_1_DAY_DESC: { TR: "Sadece sonraki güne geçer.", EN: "Passes only to the next day.", DE: "Schaltet nur auf den nächsten Tag.", ES: "Pasa solo al día siguiente.", FR: "Passe seulement au jour suivant.", IT: "Passa solo al giorno successivo.", PT: "Passa apenas para o dia seguinte." },
  VACATION_1_WEEK_TITLE: { TR: "1 Hafta Tatil", EN: "1 Week Vacation", DE: "1 Woche Urlaub", ES: "1 Semana de Vacaciones", FR: "1 Semaine de Vacances", IT: "1 Settimana di Vacanza", PT: "1 Semana de Férias" },
  VACATION_1_WEEK_DESC: { TR: "7 günlük takvim simülasyonu.", EN: "Simulates 7 calendar days.", DE: "Simuliert 7 Kalendertage.", ES: "Simula 7 días de calendario.", FR: "Simule 7 jours de calendrier.", IT: "Simula 7 giorni di calendario.", PT: "Simula 7 dias de calendário." },
  VACATION_1_MONTH_TITLE: { TR: "1 Ay Tatil", EN: "1 Month Vacation", DE: "1 Monat Urlaub", ES: "1 Mes de Vacaciones", FR: "1 Mois de Vacances", IT: "1 Mese di Vacanza", PT: "1 Mês de Férias" },
  VACATION_1_MONTH_DESC: { TR: "30 günlük otomatik takvim.", EN: "30 days automated calendar.", DE: "Automatisiert 30 Tage Kalender.", ES: "Calendario automatizado de 30 días.", FR: "30 jours de calendrier automatisé.", IT: "Calendario automatizzato di 30 giorni.", PT: "Calendário automatizado de 30 dias." },
  VACATION_UNLIMITED_TITLE: { TR: "Süresiz Tatil", EN: "Unlimited Vacation", DE: "Unbegrenzter Urlaub", ES: "Vacaciones Indefinidas", FR: "Vacances Illimitées", IT: "Vacanza Illimitata", PT: "Férias Indefinidas" },
  VACATION_UNLIMITED_DESC: { TR: "Siz durdurana kadar gün gün ilerler.", EN: "Simulates continuously until stopped.", DE: "Läuft kontinuierlich bis zum Stopp.", ES: "Simula continuamente hasta detenerlo.", FR: "Simule en continu jusqu'à l'arrêt.", IT: "Simula continuamente fino allo stop.", PT: "Simula continuamente até parar." },
  VACATION_CENTER_TITLE: { TR: "Tatil & Otomatik İlerleme Merkezi", EN: "Vacation & Auto Simulate Center", DE: "Urlaubs- & Simulationszentrum", ES: "Centro de Vacaciones y Simulación", FR: "Centre de Vacances et Simulation", IT: "Centro Vacanze e Simulazione", PT: "Centro de Férias e Simulação" },
  VACATION_CENTER_SUBTITLE: { TR: "Maç ve gün simülasyonunu otomatikleştirebilirsiniz.", EN: "Automate calendar days and match progress.", DE: "Automatisiere Spieltage und Kalenderfortschritt.", ES: "Automatiza los días de calendario y partidos.", FR: "Automatisez les jours et matchs du calendrier.", IT: "Automatizza i giorni e le partite.", PT: "Automatize dias de calendário e jogos." },
  VACATION_TRANSFER_SETTINGS: { TR: "Tatil Boyunca Transfer İlkesi", EN: "Vacation Transfer Policy", DE: "Urlaubs-Transferrichtlinie", ES: "Política de Traspasos en Vacaciones", FR: "Politique de Transfert en Vacances", IT: "Politica Trasferimenti in Vacanza", PT: "Política de Transferências em Férias" },
  ACTIVE_TRANSFER_POLICY: { TR: "Aktif İlke", EN: "Active Policy", DE: "Aktive Richtlinie", ES: "Política Activa", FR: "Politique Active", IT: "Politica Attiva", PT: "Política Ativa" },
  CLOSE_SETTINGS: { TR: "Arayüzü Kapat", EN: "Close Panel", DE: "Schließen", ES: "Cerrar Panel", FR: "Fermer le Panneau", IT: "Chiudi Pannello", PT: "Fechar Painel" },
  CONFIGURE_SETTINGS: { TR: "Ayarları Değiştir", EN: "Change Settings", DE: "Einstellungen Ändern", ES: "Cambiar Ajustes", FR: "Modifier Réglages", IT: "Modifica Impostazioni", PT: "Alterar Definições" },
  CHOOSE_PREFERENCE: { TR: "Tercih Seçin", EN: "Choose Preference", DE: "Präferenz Wählen", ES: "Elegir Preferencia", FR: "Choisir Préférence", IT: "Scegli Preferenza", PT: "Escolher Preferência" },
  VACATION_NOTICE: { TR: "Tatil süresince gerçekleşen maçlar otomatik oynatılır.", EN: "Matches during vacation are auto-simulated.", DE: "Spiele während des Urlaubs werden automatisch simuliert.", ES: "Los partidos en vacaciones se simulan automáticamente.", FR: "Les matchs en vacances sont simulés automatiquement.", IT: "Le partite in vacanza vengono simulate automaticamente.", PT: "Jogos durante as férias são simulados automaticamente." },
  SELECT_VACATION_DURATION: { TR: "Tatil Süresi Seçin", EN: "Select Vacation Duration", DE: "Urlaubs-Dauer Wählen", ES: "Seleccionar Duración de Vacaciones", FR: "Sélectionner la Durée des Vacances", IT: "Seleziona Durata Vacanza", PT: "Selecionar Duração das Férias" },
  CANCEL: { TR: "İptal", EN: "Cancel", DE: "Abbrechen", ES: "Cancelar", FR: "Annuler", IT: "Annulla", PT: "Cancelar" },
  START_VACATION: { TR: "Tatili Başlat 🌴", EN: "Start Vacation 🌴", DE: "Urlaub Starten 🌴", ES: "Iniciar Vacaciones 🌴", FR: "Lancer les Vacances 🌴", IT: "Inizia Vacanza 🌴", PT: "Iniciar Férias 🌴" },
  JANUARY: { TR: "Ocak", EN: "January", DE: "Januar", ES: "Enero", FR: "Janvier", IT: "Gennaio", PT: "Janeiro" },
  FEBRUARY: { TR: "Şubat", EN: "February", DE: "Februar", ES: "Febrero", FR: "Février", IT: "Febbraio", PT: "Fevereiro" },
  MARCH: { TR: "Mart", EN: "March", DE: "März", ES: "Marzo", FR: "Mars", IT: "Marzo", PT: "Março" },
  APRIL: { TR: "Nisan", EN: "April", DE: "April", ES: "Abril", FR: "Avril", IT: "Aprile", PT: "Abril" },
  MAY: { TR: "Mayıs", EN: "May", DE: "Mai", ES: "Mayo", FR: "Mai", IT: "Maggio", PT: "Maio" },
  JULY: { TR: "Temmuz", EN: "July", DE: "Juli", ES: "Julio", FR: "Juillet", IT: "Luglio", PT: "Julho" },
  AUGUST: { TR: "Ağustos", EN: "August", DE: "August", ES: "Agosto", FR: "Août", IT: "Agosto", PT: "Agosto" },
  SEPTEMBER: { TR: "Eylül", EN: "September", DE: "September", ES: "Septiembre", FR: "Septembre", IT: "Settembre", PT: "Setembro" },
  OCTOBER: { TR: "Ekim", EN: "October", DE: "Oktober", ES: "Octubre", FR: "Octobre", IT: "Ottobre", PT: "Outubro" },
  NOVEMBER: { TR: "Kasım", EN: "November", DE: "November", ES: "Noviembre", FR: "Novembre", IT: "Novembre", PT: "Novembro" },
  DECEMBER: { TR: "Aralık", EN: "December", DE: "Dezember", ES: "Diciembre", FR: "Décembre", IT: "Dicembre", PT: "Dezembro" },
  ON_VACATION_TITLE: { TR: "🌴 TATİLDESİNİZ", EN: "🌴 ON VACATION", DE: "🌴 IM URLAUB", ES: "🌴 DE VACACIONES", FR: "🌴 EN VACANCES", IT: "🌴 IN VACANZA", PT: "🌴 EM FÉRIAS" },
  CALENDAR_PROGRESSING: { TR: "Oyun takvimi otomatik ilerliyor...", EN: "Game calendar progressing automatically...", DE: "Spielkalender schreitet automatisch voran...", ES: "El calendario avanza automáticamente...", FR: "Le calendrier avance automatiquement...", IT: "Il calendario avanza automaticamente...", PT: "O calendário avança automaticamente..." },
  END_VACATION_BTN: { TR: "🛑 Tatili Sonlandır & Göreve Dön", EN: "🛑 End Vacation & Return to Duty", DE: "🛑 Urlaub Beenden & Zurückkehren", ES: "🛑 Finalizar Vacaciones y Volver", FR: "🛑 Terminer Vacances et Revenir", IT: "🛑 Termina Vacanza e Ritorna", PT: "🛑 Terminar Férias e Regressar" },
  DATE_LABEL: { TR: "Tarih", EN: "Date", DE: "Datum", ES: "Fecha", FR: "Date", IT: "Data", PT: "Data" },
  TIME_ELAPSED: { TR: "Geçen Süre", EN: "Time Elapsed", DE: "Verstrichene Zeit", ES: "Tiempo Transcurrido", FR: "Temps Écoulé", IT: "Tempo Trascorso", PT: "Tempo Decorrido" },
  DAYS_UNIT: { TR: "Gün", EN: "Days", DE: "Tage", ES: "Días", FR: "Jours", IT: "Giorni", PT: "Dias" },
  MATCHES_PLAYED: { TR: "Oynanan Maç", EN: "Matches Played", DE: "Gespielte Spiele", ES: "Partidos Jugados", FR: "Matchs Joués", IT: "Partite Giocate", PT: "Jogos Realizados" },
  MATCHES_UNIT: { TR: "Maç", EN: "Matches", DE: "Spiele", ES: "Partidos", FR: "Matchs", IT: "Partite", PT: "Jogos" },
  CONTINENTS_7: { TR: "7 Kıta", EN: "7 Continents", DE: "7 Kontinente", ES: "7 Continentes", FR: "7 Continents", IT: "7 Continenti", PT: "7 Continentes" },
  SELECT_CONTINENT_TITLE: { TR: "Bir Kıta Seçin", EN: "Select a Continent", DE: "Wählen Sie einen Kontinent", ES: "Selecciona un Continente", FR: "Sélectionnez un Continent", IT: "Seleziona un Continente", PT: "Selecione um Continente" },
  SELECT_CONTINENT_DESC: { TR: "Dünya üzerindeki 7 kıtanın futbol liglerini ve takımlarını keşfedin", EN: "Discover leagues and clubs across 7 world continents", DE: "Entdecken Sie Ligen und Vereine auf 7 Kontinenten", ES: "Descubre ligas y clubes de los 7 continentes", FR: "Découvrez les ligues et clubs à travers 7 continents", IT: "Scopri campionati e club in 7 continenti", PT: "Descubra ligas e clubes nos 7 continentes" },
  "7_CONTINENTS_ACTIVE": { TR: "7 KITA AKTİF", EN: "7 CONTINENTS ACTIVE", DE: "7 KONTINENTE AKTIV", ES: "7 CONTINENTES ACTIVOS", FR: "7 CONTINENTS ACTIFS", IT: "7 CONTINENTI ATTIVI", PT: "7 CONTINENTES ATIVOS" },
  COUNTRIES_AVAILABLE: { TR: "Ülke Mevcut", EN: "Countries Available", DE: "Länder Verfügbar", ES: "Países Disponibles", FR: "Pays Disponibles", IT: "Paesi Disponibili", PT: "Países Disponíveis" },
  INSPECT_BTN: { TR: "İncele", EN: "Inspect", DE: "Ansehen", ES: "Inspeccionar", FR: "Inspecter", IT: "Ispeziona", PT: "Inspecionar" },
  CONTINENT_EU_NAME: { TR: "Avrupa", EN: "Europe", DE: "Europa", ES: "Europa", FR: "Europe", IT: "Europa", PT: "Europa" },
  CONTINENT_EU_DESC: { TR: "UEFA Şampiyonlar Ligi ve dünyanın en prestijli kulüpleri", EN: "UEFA Champions League and world elite clubs", DE: "UEFA Champions League und die Elite-Clubs der Welt", ES: "UEFA Champions League y clubes de élite mundial", FR: "Ligue des Champions UEFA et clubs d'élite", IT: "UEFA Champions League e club d'élite mondiali", PT: "Liga dos Campeões da UEFA e clubes de elite mundial" },
  CONTINENT_SA_NAME: { TR: "Güney Amerika", EN: "South America", DE: "Südamerika", ES: "Sudamérica", FR: "Amérique du Sud", IT: "Sud America", PT: "América do Sul" },
  CONTINENT_SA_DESC: { TR: "Copa Libertadores, Samba tekniği ve Tango tutkusu", EN: "Copa Libertadores, Samba skills and Tango passion", DE: "Copa Libertadores, Samba-Technik und Tango-Leidenschaft", ES: "Copa Libertadores, técnica Samba y pasión de Tango", FR: "Copa Libertadores, technique Samba et passion du Tango", IT: "Copa Libertadores, tecnica Samba e passione Tango", PT: "Copa Libertadores, técnica Samba e paixão Tango" },
  CONTINENT_NA_NAME: { TR: "Kuzey Amerika", EN: "North America", DE: "North America", ES: "Norteamérica", FR: "Amérique du Nord", IT: "Nord America", PT: "América do Norte" },
  CONTINENT_NA_DESC: { TR: "MLS yıldızları ve Liga MX tutkulu rekabeti", EN: "MLS stars and passionate Liga MX rivalries", DE: "MLS-Stars und leidenschaftliche Liga MX-Rivalitäten", ES: "Estrellas de la MLS y rivalidades de Liga MX", FR: "Stars de la MLS et rivalités de Liga MX", IT: "Stelle MLS e accese rivalità in Liga MX", PT: "Estrelas da MLS e rivalidades da Liga MX" },
  CONTINENT_AS_NAME: { TR: "Asya", EN: "Asia", DE: "Asien", ES: "Asia", FR: "Asie", IT: "Asia", PT: "Ásia" },
  CONTINENT_AS_DESC: { TR: "Suudi Pro Ligi dünya yıldızları ve J-League disiplini", EN: "Saudi Pro League superstars and J-League discipline", DE: "Saudi Pro League Weltstars und J-League-Disziplin", ES: "Superestrellas de la Saudi Pro League y disciplina J-League", FR: "Superstars de Saudi Pro League et discipline J-League", IT: "Stelle della Saudi Pro League e disciplina J-League", PT: "Superestrelas da Saudi Pro League e disciplina J-League" },
  CONTINENT_AF_NAME: { TR: "Afrika", EN: "Africa", DE: "Afrika", ES: "África", FR: "Afrique", IT: "Africa", PT: "África" },
  CONTINENT_AF_DESC: { TR: "CAF Şampiyonlar Ligi, fiziksel güç ve genç yetenekler", EN: "CAF Champions League, physical power and young prospects", DE: "CAF Champions League, physische Stärke und junge Talente", ES: "CAF Champions League, poder físico y jóvenes talentos", FR: "Ligue des Champions CAF, puissance physique et jeunes espoirs", IT: "CAF Champions League, potenza fisica e giovani talenti", PT: "Liga dos Campeões da CAF, força física e jovens talentos" },
  CONTINENT_OC_NAME: { TR: "Okyanusya", EN: "Oceania", DE: "Ozeanien", ES: "Oceanía", FR: "Océanie", IT: "Oceania", PT: "Oceania" },
  CONTINENT_OC_DESC: { TR: "A-League ve Ada ülkeleri futbol sahnesi", EN: "A-League and Pacific Island football scene", DE: "A-League und Pazifik-Inseln-Fußballszene", ES: "A-League y fútbol de las islas del Pacífico", FR: "A-League et scène footballistique des îles du Pacifique", IT: "A-League e scena calcistica delle isole del Pacifico", PT: "A-League e cena do futebol das Ilhas do Pacífico" },
  CONTINENT_AN_NAME: { TR: "Antarktika", EN: "Antarctica", DE: "Antarktis", ES: "Antártida", FR: "Antarctique", IT: "Antartide", PT: "Antártida" },
  CONTINENT_AN_DESC: { TR: "Buzullar arası dostluk turnuvası ve Penguen Birliği", EN: "Glacial friendship tournament and Penguin Union", DE: "Gletscher-Freundschaftsturnier und Pinguin-Liga", ES: "Torneo de la amistad glacial y Liga Pingüino", FR: "Tournoi d'amitié glaciaire et Ligue Pingouin", IT: "Torneo dell'amicizia glaciale e Lega Pinguini", PT: "Torneio da amizade glacial e Liga Pinguim" },
  HIJACK_WAR_TITLE: { TR: "Teklif Savaşı & Rakip Hamlesi", EN: "Bidding War & Rival Move", DE: "Bietergefecht & Rivalen-Schritt", ES: "Guerra de Ofertas y Mover de Rival", FR: "Guerre d'Enchères et Coup de Rival", IT: "Guerra di Offerte e Mossa del Rivale", PT: "Guerra de Licitações e Jogada de Rival" },
  PLAYER_CONTRACT_TITLE: { TR: "Oyuncu Temsilcisi & Sözleşme Görüşmesi", EN: "Player Representative & Contract Talks", DE: "Spielerberater & Vertragsverhandlung", ES: "Representante y Negociación de Contrato", FR: "Agent du Joueur et Négociation", IT: "Agente del Giocatore e Trattativa", PT: "Empresário e Negociação de Contrato" },
  OFFICIAL_CLUB_TALKS: { TR: "Resmi Kulüp Görüşme Masası", EN: "Official Club Negotiation Desk", DE: "Verhandlungstisch des Vereins", ES: "Mesa de Negociación Oficial", FR: "Table de Négociation Officielle du Club", IT: "Tavolo delle Trattative Ufficiali", PT: "Mesa de Negociações Oficiais do Clube" },
  FREE_AGENT_CLUB: { TR: "Serbest Kulüp", EN: "Free Agent / Free Club", DE: "Vereinslos", ES: "Agente Libre", FR: "Agent Libre", IT: "Svincolato", PT: "Agente Livre" },
  LIVE_SIGNING_CEREMONY: { TR: "CANLI İMZA TÖRENİ", EN: "LIVE SIGNING CEREMONY", DE: "LIVE VERTRAGSUNTERZEICHNUNG", ES: "CEREMONIA DE FIRMA EN DIRECTO", FR: "CÉRÉMONIE DE SIGNATURE EN DIRECT", IT: "CERIMONIA DI FIRMA IN DIRETTA", PT: "CERIMÓNIA DE ASSINATURA AO VIVO" },
  MEDIA_TITLE: { TR: "BASIN VE MEDYA LANSE ETME", EN: "PRESS AND MEDIA LAUNCH", DE: "PRESSE UND MEDIEN PRÄSENTATION", ES: "PRESENTACIÓN ANTE LOS MEDIOS", FR: "PRÉSENTATION PRESSE ET MÉDIAS", IT: "PRESENTAZIONE STAMPA E MEDIA", PT: "APRESENTAÇÃO À IMPRENSA E COMUNICAÇÃO" },
  HEAD_COACH_PRESENTATION: { TR: "TEKNİK DİREKTÖR TANITIM İMZASI", EN: "HEAD COACH PRESENTATION", DE: "CHEFTRAINER PRÄSENTATION", ES: "PRESENTACIÓN DEL ENTRENADOR PRINCIPAL", FR: "PRÉSENTATION DE L'ENTRAÎNEUR PRINCIPAL", IT: "PRESENTAZIONE DEL ALLENATORE CAPO", PT: "APRESENTAÇÃO DO TREINADOR PRINCIPAL" },
  QUESTION_LABEL: { TR: "Soru", EN: "Question", DE: "Frage", ES: "Pregunta", FR: "Question", IT: "Domanda", PT: "Pergunta" },
  HEAD_COACH_LABEL: { TR: "TEKNİK DİREKTÖR", EN: "HEAD COACH", DE: "CHEFTRAINER", ES: "ENTRENADOR PRINCIPAL", FR: "ENTRAÎNEUR PRINCIPAL", IT: "ALLENATORE CAPO", PT: "TREINADOR PRINCIPAL" },
  LEAGUE_TV: { TR: "LİG TV", EN: "LEAGUE TV", DE: "LIGA TV", ES: "LIGA TV", FR: "LIGUE TV", IT: "LEGA TV", PT: "LIGA TV" },
  SPORT_TV: { TR: "SPOR TV", EN: "SPORT TV", DE: "SPORT TV", ES: "DEPORTE TV", FR: "SPORT TV", IT: "SPORT TV", PT: "DESPORTO TV" },
  CHOOSE_ANSWER: { TR: "CEVAP SEÇİN", EN: "CHOOSE ANSWER", DE: "ANTWORT WÄHLEN", ES: "ELEGIR RESPUESTA", FR: "CHOISIR LA RÉPONSE", IT: "SCEGLI RISPOSTA", PT: "ESCOLHER RESPOSTA" },
  EFFECT_LABEL: { TR: "Etki", EN: "Effect", DE: "Auswirkung", ES: "Efecto", FR: "Effet", IT: "Effetto", PT: "Efeito" }
};

// Comprehensive football dictionary for accurate multi-language support
const footballDictionary = {
  TAB_FORMATION: { TR: "Diziliş", EN: "Formation", DE: "Aufstellung", ES: "Alineación", FR: "Formation", IT: "Formazione", PT: "Formação" },
  TAB_PLAYSTYLE: { TR: "Oyun Şekli", EN: "Play Style", DE: "Spielstil", ES: "Estilo de Juego", FR: "Style de Jeu", IT: "Stile di Gioco", PT: "Estilo de Jogo" },
  TAB_DEFENSE: { TR: "Savunma", EN: "Defense", DE: "Abwehr", ES: "Defensa", FR: "Défense", IT: "Difesa", PT: "Defesa" },
  TAB_ATTACK: { TR: "Hücum", EN: "Attack", DE: "Angriff", ES: "Ataque", FR: "Attaque", IT: "Attacco", PT: "Ataque" },
  TAB_SETPIECES: { TR: "Duran Toplar", EN: "Set Pieces", DE: "Standardsituationen", ES: "Balón Parado", FR: "Coups de Pied Arrêtés", IT: "Calci Piazzati", PT: "Bolas Paradas" },
  TAB_CAPTAIN: { TR: "Kaptan", EN: "Captains", DE: "Spielführer", ES: "Capitanes", FR: "Capitaines", IT: "Capitani", PT: "Capitães" },
  NAV_SQUAD: { TR: "Kadro", EN: "Squad", DE: "Kader", ES: "Plantilla", FR: "Effectif", IT: "Rosa", PT: "Plantel" },
  NAV_TACTICS: { TR: "Taktik", EN: "Tactics", DE: "Taktik", ES: "Táctica", FR: "Tactique", IT: "Tattica", PT: "Tática" },
  NAV_TRANSFERS: { TR: "Transferler", EN: "Transfers", DE: "Transfers", ES: "Fichajes", FR: "Transferts", IT: "Calciomercato", PT: "Transferências" },
  NAV_FIXTURES: { TR: "Fikstür", EN: "Fixtures", DE: "Spielplan", ES: "Calendario", FR: "Calendrier", IT: "Calendario", PT: "Calendário" },
  NAV_TABLE: { TR: "Puan Durumu", EN: "Standings", DE: "Tabelle", ES: "Clasificación", FR: "Classement", IT: "Classifica", PT: "Classificação" },
  NAV_FINANCES: { TR: "Finans", EN: "Finances", DE: "Finanzen", ES: "Finanzas", FR: "Finances", IT: "Finanze", PT: "Finanças" },
  NAV_INBOX: { TR: "Gelen Kutusu", EN: "Inbox", DE: "Posteingang", ES: "Buzón", FR: "Boîte de Réception", IT: "Posta in Arrivo", PT: "Caixa de Entrada" },
  NAV_BOARD: { TR: "Yönetim", EN: "Board", DE: "Vorstand", ES: "Directiva", FR: "Comité", IT: "Dirigenza", PT: "Direção" },
  NAV_SCOUT: { TR: "Scout / Gözlemci", EN: "Scout / World", DE: "Scouting", ES: "Ojeador", FR: "Recrutement", IT: "Osservatore", PT: "Observador" },
  NAV_VACATION: { TR: "Tatil Center", EN: "Vacation Center", DE: "Urlaubs-Zentrum", ES: "Centro de Vacaciones", FR: "Centre de Vacances", IT: "Centro Vacanze", PT: "Centro de Férias" },
  MANAGER_CAREER: { TR: "Teknik Direktör Kariyeri", EN: "Manager Career", DE: "Trainerkarriere", ES: "Carrera de Mánager", FR: "Carrière d'Entraîneur", IT: "Carriera Allenatore", PT: "Carreira de Treinador" },
  PLAYER_CAREER: { TR: "Oyuncu Kariyeri", EN: "Player Career", DE: "Spielerkarriere", ES: "Carrera de Jugador", FR: "Carrière de Joueur", IT: "Carriera Giocatore", PT: "Carreira de Jogador" },
  CREATE_DATABASE: { TR: "Veritabanı Oluşturuluyor...", EN: "Generating Database...", DE: "Datenbank wird erstellt...", ES: "Generando Base de Datos...", FR: "Génération de la Base de Données...", IT: "Generazione Database...", PT: "Gerando Base de Dados..." },
  LOAD_SAVED_GAME: { TR: "Kayıtlı Oyunu Yükle", EN: "Load Saved Game", DE: "Spiel Laden", ES: "Cargar Partida", FR: "Charger la Partie", IT: "Carica Partita", PT: "Carregar Jogo" },
  WORLD_CLUBS: { TR: "Dünya Kulüpleri", EN: "World Clubs", DE: "Weltclubs", ES: "Clubes del Mundo", FR: "Clubs du Monde", IT: "Club del Mondo", PT: "Clubes do Mundo" },
  ALL_CLUBS: { TR: "Tüm Kulüpler", EN: "All Clubs", DE: "Alle Vereine", ES: "Todos los Clubes", FR: "Tous les Clubs", IT: "Tutti i Club", PT: "Todos os Clubes" },
  PREFERRED_FOOT: { TR: "Hakim Ayak", EN: "Preferred Foot", DE: "Starker Fuß", ES: "Pie Preferido", FR: "Pied Fort", IT: "Piede Preferito", PT: "Pé Preferido" },
  LEFT_FOOT: { TR: "Sol Ayak", EN: "Left Foot", DE: "Linksfuß", ES: "Zurdo", FR: "Gaucher", IT: "Mancino", PT: "Canhoto" },
  RIGHT_FOOT: { TR: "Sağ Ayak", EN: "Right Foot", DE: "Rechtsfuß", ES: "Diestro", FR: "Droitier", IT: "Destro", PT: "Destro" },
  BOTH_FEET: { TR: "Çift Ayak", EN: "Both Feet", DE: "Beidfüßig", ES: "Ambas Piernas", FR: "Ambidextre", IT: "Ambidestro", PT: "Ambidestro" },
  CUSTOMIZE_CHARACTER: { TR: "Karakter Özelleştirme", EN: "Customize Character", DE: "Charakter Anpassen", ES: "Personalizar Personaje", FR: "Personnaliser le Personnage", IT: "Personalizza Personaggio", PT: "Personalizar Personagem" },
  START_MATCH: { TR: "Maçı Başlat", EN: "Start Match", DE: "Spiel Starten", ES: "Iniciar Partido", FR: "Lancer le Match", IT: "Inizia Partita", PT: "Iniciar Jogo" },
  HALFTIME: { TR: "Devre Arası", EN: "Half Time", DE: "Halbzeit", ES: "Descanso", FR: "Mi-temps", IT: "Intervallo", PT: "Intervalo" },
  FULLTIME: { TR: "Maç Bitti", EN: "Full Time", DE: "Endstand", ES: "Final del Partido", FR: "Fin du Match", IT: "Fine Partita", PT: "Fim do Jogo" },
  GOAL: { TR: "GOL!", EN: "GOAL!", DE: "TOR!", ES: "¡GOL!", FR: "BUT !", IT: "GOL!", PT: "GOLO!" },
  YELLOW_CARD: { TR: "Sarı Kart", EN: "Yellow Card", DE: "Gelbe Karte", ES: "Tarjeta Amarilla", FR: "Carton Jaune", IT: "Cartellino Giallo", PT: "Cartão Amarelo" },
  RED_CARD: { TR: "Kırmızı Kart", EN: "Red Card", DE: "Rote Karte", ES: "Tarjeta Roja", FR: "Carton Rouge", IT: "Cartellino Rosso", PT: "Cartão Vermelho" },
  INJURY: { TR: "Sakatlık", EN: "Injury", DE: "Verletzung", ES: "Lesión", FR: "Blessure", IT: "Infortunio", PT: "Lesão" },
  SUBSTITUTION: { TR: "Oyuncu Değişikliği", EN: "Substitution", DE: "Auswechslung", ES: "Sustitución", FR: "Remplacement", IT: "Sostituzione", PT: "Substituição" }
};

// Fill missing keys for every language dictionary
keysUsed.forEach(key => {
  langs.forEach(lang => {
    if (footballDictionary[key] && footballDictionary[key][lang]) {
      dicts[lang][key] = sanitizeValue(footballDictionary[key][lang]);
    } else if (missingTranslations[key] && missingTranslations[key][lang]) {
      dicts[lang][key] = sanitizeValue(missingTranslations[key][lang]);
    } else if (!dicts[lang][key] || dicts[lang][key] === dicts.TR[key]) {
      if (dicts.EN[key] && lang !== 'TR' && lang !== 'EN') {
        dicts[lang][key] = sanitizeValue(dicts.EN[key]);
      } else if (!dicts[lang][key]) {
        const clean = key.replace(/_/g, ' ').toLowerCase()
          .split(' ')
          .map(w => w.charAt(0).toUpperCase() + w.slice(1))
          .join(' ');
        dicts[lang][key] = clean;
      }
    } else {
      dicts[lang][key] = sanitizeValue(dicts[lang][key]);
    }
  });
});

console.log('Final complete key counts per language:');
langs.forEach(l => console.log(`  ${l}: ${Object.keys(dicts[l]).length}`));

// Generate the updated i18n.tsx content
function formatDict(dictObj) {
  const keys = Object.keys(dictObj).sort();
  const lines = keys.map(k => {
    const safeVal = JSON.stringify(dictObj[k]);
    const safeKey = /^[0-9]/.test(k) ? JSON.stringify(k) : k;
    return `    ${safeKey}: ${safeVal},`;
  });
  return `{\n${lines.join('\n')}\n  }`;
}

const newI18nCode = `import React, { createContext, useContext, useState } from 'react';

export type LanguageCode = 'TR' | 'EN' | 'DE' | 'ES' | 'FR' | 'IT' | 'PT';

export interface LanguageOption {
  code: LanguageCode;
  name: string;
  nativeName: string;
  flag: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'TR', name: 'Turkish', nativeName: 'Türkçe', flag: '🇹🇷' },
  { code: 'EN', name: 'English', nativeName: 'English', flag: '🇬🇧' },
  { code: 'DE', name: 'German', nativeName: 'Deutsch', flag: '🇩🇪' },
  { code: 'ES', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸' },
  { code: 'FR', name: 'French', nativeName: 'Français', flag: '🇫🇷' },
  { code: 'IT', name: 'Italian', nativeName: 'Italiano', flag: '🇮🇹' },
  { code: 'PT', name: 'Portuguese', nativeName: 'Português', flag: '🇵🇹' },
];

const TRANSLATIONS: Record<LanguageCode, Record<string, string>> = {
  TR: ${formatDict(dicts.TR)},
  EN: ${formatDict(dicts.EN)},
  DE: ${formatDict(dicts.DE)},
  ES: ${formatDict(dicts.ES)},
  FR: ${formatDict(dicts.FR)},
  IT: ${formatDict(dicts.IT)},
  PT: ${formatDict(dicts.PT)}
};

interface LanguageContextType {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: string, params?: Record<string, any>) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    try {
      const saved = localStorage.getItem('fmm_game_language');
      if (saved && TRANSLATIONS[saved as LanguageCode]) {
        return saved as LanguageCode;
      }
    } catch (e) {
      console.error(e);
    }
    return 'TR';
  });

  const setLanguage = (lang: LanguageCode) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('fmm_game_language', lang);
    } catch (e) {
      console.error(e);
    }
  };

  const t = (key: string, params?: Record<string, any>): string => {
    const langDict = TRANSLATIONS[language] || TRANSLATIONS.TR;
    let template = langDict[key] || TRANSLATIONS.EN[key] || TRANSLATIONS.TR[key] || key.replace(/_/g, ' ');
    if (template) {
      template = template.replace(/_/g, ' ');
    }
    if (params) {
      Object.keys(params).forEach(p => {
        template = template.replace(new RegExp(\`\\\\{\${p}\\\\x7d\`, 'g'), String(params[p]));
      });
    }
    return template;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useTranslation = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }
  return context;
};
`;

fs.writeFileSync(i18nPath, newI18nCode, 'utf8');
console.log('Successfully updated src/utils/i18n.tsx with complete 7-language support!');
