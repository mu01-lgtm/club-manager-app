import React, { useState, useEffect, useRef } from 'react';
import {
  Team,
  ManagerProfile,
  LeagueRow,
  Fixture,
  Player,
  FormationType,
  TacticType,
  GameMode,
  CreatedPlayerProfile,
  Scout,
  ScoutReport,
  InboxMessage,
  PendingBuyOffer,
  PlayerRating,
  MatchStats,
  MatchEvent,
  MatchReportData,
  MatchReportScorer,
  MediaReviewItem,
  MediaReviewData
} from './types';
import {
  INITIAL_TEAMS,
  INITIAL_LEAGUE_TABLE,
  DEFAULT_MANAGER,
  FORMATION_COORDINATES,
  generateLeagueSchedule,
  generateInitialStandings
} from './data/initialData';
import { simulateQuickMatch, calculatePostMatchStamina } from './utils/matchEngine';
import { getSimulatedRealDate } from './utils/dateHelper';
import { ensureTeamHas20Players } from './utils/squadExpander';
import { calculateBoardConfidence } from './utils/teamGoalsHelper';
import { deduplicateAndEnrichTeams } from './utils/deduplicateTeams';
import { Header } from './components/Header';
import { Navigation, TabType } from './components/Navigation';
import { FMMSidebar } from './components/FMMSidebar';
import { PlayerProfileModal } from './components/PlayerProfileModal';
import { InboxModal } from './components/InboxModal';
import { TacticalPitch } from './components/TacticalPitch';
import { PlayerTable } from './components/PlayerTable';
import { LeagueTable } from './components/LeagueTable';
import { TransferMarket } from './components/TransferMarket';
import { TrainingCenter } from './components/TrainingCenter';
import { FixturesView } from './components/FixturesView';
import { MatchSimulationModal } from './components/MatchSimulationModal';
import { RotateDeviceOverlay } from './components/RotateDeviceOverlay';
import { ToastNotification, ToastMessage } from './components/ToastNotification';
import { CareerStartModal, SavedGameState } from './components/CareerStartModal';
import { saveCareerSlot, formatCurrentRealDate, SaveSlotData } from './utils/saveSystem';
import { soundFx } from './utils/soundEffects';
import { SplashScreen } from './components/SplashScreen';
import { MainMenuModal } from './components/MainMenuModal';
import { VacationModal, VacationOfferPolicy } from './components/VacationModal';
import { VacationOverlay } from './components/VacationOverlay';
import { PlayerComparisonModal } from './components/PlayerComparisonModal';
import { TeamDetailModal } from './components/TeamDetailModal';
import { NewsFeed } from './components/NewsFeed';
import { PressConferenceModal } from './components/PressConferenceModal';
import { FinancesModal } from './components/FinancesModal';
import { TransferOfferModal } from './components/TransferOfferModal';
import { PreMatchModal } from './components/PreMatchModal';
import { MyPlayerView } from './components/MyPlayerView';
import { PlayerHomeView } from './components/PlayerHomeView';
import { ContractModal } from './components/ContractModal';
import { CountrySquadModal } from './components/CountrySquadModal';
import { WorldScoutModal, INTERNATIONAL_TEAMS } from './components/WorldScoutModal';
import { BoardConfidenceModal } from './components/BoardConfidenceModal';
import { ScoutManagementModal } from './components/ScoutManagementModal';
import { MatchComparisonModal } from './components/MatchComparisonModal';
import { HomeDashboard } from './components/HomeDashboard';
import { useTranslation } from './utils/i18n';
import { Trophy, Sparkles, RefreshCw, Users, Shield, Play, ArrowRight, Zap, Award, X } from 'lucide-react';
import confetti from 'canvas-confetti';

const DAY_NAMES = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cumartesi'];

const INITIAL_SCOUTS: Scout[] = [
  { id: 'scout-1', name: 'Mustafa Sarp', nationality: 'Türkiye', judgmentRating: 16, weeklyWage: 3500 },
  { id: 'scout-2', name: 'Carlos Valderrama', nationality: 'Kolombiya', judgmentRating: 18, weeklyWage: 5000 },
];

const INITIAL_CANDIDATE_SCOUTS: Scout[] = [
  { id: 'scout-cand-1', name: 'Marco van Basten', nationality: 'Hollanda', judgmentRating: 19, weeklyWage: 7500 },
  { id: 'scout-cand-2', name: 'Pavel Nedved', nationality: 'Çekya', judgmentRating: 17, weeklyWage: 4500 },
  { id: 'scout-cand-3', name: 'Gheorghe Hagi', nationality: 'Romanya', judgmentRating: 20, weeklyWage: 9000 },
  { id: 'scout-cand-4', name: 'Rüştü Reçber', nationality: 'Türkiye', judgmentRating: 15, weeklyWage: 3000 },
  { id: 'scout-cand-5', name: 'Diego Lugano', nationality: 'Uruguay', judgmentRating: 16, weeklyWage: 3800 },
  { id: 'scout-cand-6', name: 'Bülent Korkmaz', nationality: 'Türkiye', judgmentRating: 17, weeklyWage: 4200 }
];

export default function App() {
  const { t, language } = useTranslation();
  const [allTeams, setAllTeams] = useState<Team[]>(() => deduplicateAndEnrichTeams(INITIAL_TEAMS));
  const [currentTeamId, setCurrentTeamId] = useState<string>('galatasaray');
  const [manager, setManager] = useState<ManagerProfile>(DEFAULT_MANAGER);

  // Persistent Favorites State
  const [favoritePlayerIds, setFavoritePlayerIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('fmm_favorites') || '[]');
    } catch {
      return [];
    }
  });

  const handleToggleFavorite = (playerId: string) => {
    setFavoritePlayerIds(prev => {
      const next = prev.includes(playerId) ? prev.filter(id => id !== playerId) : [...prev, playerId];
      try {
        localStorage.setItem('fmm_favorites', JSON.stringify(next));
      } catch (e) {
        console.error(e);
      }
      return next;
    });
  };

  // Scout System States
  const [scouts, setScouts] = useState<Scout[]>(INITIAL_SCOUTS);
  const [candidateScouts, setCandidateScouts] = useState<Scout[]>(INITIAL_CANDIDATE_SCOUTS);
  const [scoutReports, setScoutReports] = useState<ScoutReport[]>([]);
  const [isScoutManagementOpen, setIsScoutManagementOpen] = useState<boolean>(false);
  
  // Career Metadata States
  const [activeCareerId, setActiveCareerId] = useState<string>('');
  const [activeCareerName, setActiveCareerName] = useState<string>('Süper Lig Kariyerim');

  // Player Career Mode States
  const [gameMode, setGameMode] = useState<GameMode>('MANAGER');
  const [createdPlayer, setCreatedPlayer] = useState<CreatedPlayerProfile | null>(null);

  const [currentWeek, setCurrentWeek] = useState<number>(1);
  const [currentSeason, setCurrentSeason] = useState<number>(1);
  const [currentDayIndex, setCurrentDayIndex] = useState<number>(0);
  const [hasUnreadNews, setHasUnreadNews] = useState<boolean>(true);
  const [isAdvancingDay, setIsAdvancingDay] = useState<boolean>(false);
  const isAdvancingRef = useRef<boolean>(false);
  const [hasCelebratedChampionship, setHasCelebratedChampionship] = useState<boolean>(false);
  const [seasonPhase, setSeasonPhase] = useState<'REGULAR' | 'VACATION' | 'FRIENDLIES'>('REGULAR');

  const [standings, setStandings] = useState<LeagueRow[]>(INITIAL_LEAGUE_TABLE);
  const [fixtures, setFixtures] = useState<Fixture[]>(() =>
    generateLeagueSchedule(INITIAL_TEAMS.map(t => t.id))
  );

  // Mandatory Hard Reset Data function: clears localStorage and reloads fresh superLigTeams.ts data
  const hardResetData = () => {
    try {
      localStorage.clear();
      localStorage.removeItem('fmm_saved_games');
    } catch (e) {
      console.error('Local storage clear error:', e);
    }
    const freshTeams = JSON.parse(JSON.stringify(INITIAL_TEAMS)) as Team[];
    const freshStandings = JSON.parse(JSON.stringify(INITIAL_LEAGUE_TABLE)) as LeagueRow[];
    setAllTeams(freshTeams);
    setStandings(freshStandings);
    setFixtures(generateLeagueSchedule(freshTeams.map(t => t.id)));
    setCurrentTeamId('galatasaray');
    setCurrentWeek(1);
    setCurrentSeason(1);
    setCurrentDayIndex(0);
    setGameMode('MANAGER');
    setCreatedPlayer(null);
    setShowMainMenu(true);
    setIsCareerModalOpen(false);
    showToast('info', 'Veri ve Hafıza Temizlendi 🔄', 'Eski kayıtlı veriler silindi, superLigTeams.ts dosyasındaki güncel 18 takım ve kadrolar yüklendi.');
  };

  // Auto-sync effect on mount: forces wiping stale cache & loads fresh superLigTeams.ts data
  useEffect(() => {
    let needsReset = false;
    try {
      const stored = localStorage.getItem('fmm_saved_games');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].allTeams) {
          const firstSave = parsed[0];
          if (
            firstSave.allTeams.length !== INITIAL_TEAMS.length ||
            firstSave.allTeams.some((t: Team) => !t.players || t.players.length < 20)
          ) {
            needsReset = true;
          }
        }
      }
    } catch (err) {
      console.error('Local storage check error:', err);
    }

    if (
      needsReset ||
      allTeams.length !== INITIAL_TEAMS.length ||
      standings.length !== INITIAL_TEAMS.length ||
      allTeams.some(t => !t.players || t.players.length < 20)
    ) {
      hardResetData();
    }
  }, []);

  const [activeTab, setActiveTab] = useState<TabType>('HOME');
  const [activeTacticsSubMenu, setActiveTacticsSubMenu] = useState<string>('Diziliş');
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [profilePlayer, setProfilePlayer] = useState<Player | null>(null);
  const [profilePlayerTeam, setProfilePlayerTeam] = useState<Team | null>(null);
  const [contractModalPlayer, setContractModalPlayer] = useState<Player | null>(null);
  const [countryModalName, setCountryModalName] = useState<string | null>(null);
  const [isWorldScoutOpen, setIsWorldScoutOpen] = useState<boolean>(false);
  const [isFullSquadModalOpen, setIsFullSquadModalOpen] = useState<boolean>(false);
  const [isFinancesModalOpen, setIsFinancesModalOpen] = useState<boolean>(false);
  const [isMatchComparisonOpen, setIsMatchComparisonOpen] = useState<boolean>(false);
  const [isPlayerComparisonOpen, setIsPlayerComparisonOpen] = useState<boolean>(false);
  const [teamDetailModalData, setTeamDetailModalData] = useState<Team | null>(null);
  const [isQuickSimMatch, setIsQuickSimMatch] = useState<boolean>(false);
  const [offerModalData, setOfferModalData] = useState<{
    player: Player;
    team?: Team;
    initialType: 'BUY' | 'LOAN';
    initialStage?: 'CLUB_DEAL' | 'PLAYER_CONTRACT';
  } | null>(null);

  // Pending 1-Day Buy Offers & Mid-Season Transfer Arrival Queues
  const [pendingBuyOffers, setPendingBuyOffers] = useState<PendingBuyOffer[]>([]);
  const [pendingTransferArrivals, setPendingTransferArrivals] = useState<{
    player: Player;
    dealType: 'BUY' | 'LOAN';
    fee: number;
    joinWeek: number;
  }[]>([]);

  // Vacation Mode States
  const [isVacationModalOpen, setIsVacationModalOpen] = useState<boolean>(false);
  const [isVacationActive, setIsVacationActive] = useState<boolean>(false);
  const [vacationDaysTotal, setVacationDaysTotal] = useState<number>(7);
  const [vacationDaysElapsed, setVacationDaysElapsed] = useState<number>(0);
  const [vacationSimulatedMatches, setVacationSimulatedMatches] = useState<number>(0);
  const [vacationOfferPolicy, setVacationOfferPolicy] = useState<VacationOfferPolicy>('NONE');

  // Board Confidence Modal State
  const [isBoardConfidenceModalOpen, setIsBoardConfidenceModalOpen] = useState<boolean>(false);
  const [lastMatchForMediaReview, setLastMatchForMediaReview] = useState<MatchReportData | null>(null);

  const handleStartVacation = (totalDays: number) => {
    setVacationDaysTotal(totalDays);
    setVacationDaysElapsed(0);
    setVacationSimulatedMatches(0);
    setIsVacationActive(true);
    setIsVacationModalOpen(false);
    showToast('info', '🌴 Tatil Başladı!', 'Takvim kendiliğinden gün gün ilerliyor...');
  };

  const handleStopVacation = () => {
    setIsVacationActive(false);
    showToast('info', '🛑 Tatil Sonlandırıldı', 'Kulübün başına geri döndünüz.');
  };

  const handleSendBuyOffer = (
    player: Player,
    sellerTeam: Team | undefined,
    offerFee: number,
    effectiveFee: number,
    buyProb: number
  ) => {
    const newOffer: PendingBuyOffer = {
      id: `buy-offer-${Date.now()}-${Math.random()}`,
      player,
      sellerTeam,
      userTeam: currentTeam,
      offerFee,
      effectiveFee,
      buyProb,
      submittedDayIndex: currentDayIndex,
      submittedWeek: currentWeek,
      daysRemaining: 1
    };
    setPendingBuyOffers(prev => [...prev, newOffer]);
  };

  const handleAddAirportCelebrationInbox = (player: Player) => {
    const dateStr = `${currentWeek}. Hafta`;
    const airportMsg: InboxMessage = {
      id: `msg-airport-${Date.now()}`,
      sender: 'Taraftar Derneği & Medya',
      subject: `🔥 HAVALİMANINDA BÜYÜK COŞKU: ${player.name} GELİYOR!`,
      date: dateStr,
      content: `Binlerce coşkulu taraftar, meşaleler ve tezahüratlar eşliğinde yeni yıldız transferimiz ${player.name}'ı havalimanında karşıladı! Müthiş bir atmosferin yaşandığı karşılamada ${player.name}, bu harika kulübün parçası olmaktan büyük heyecan duyduğunu belirtti.`,
      isRead: false,
      tag: 'MEDYA'
    };
    setInboxMessages(prev => [airportMsg, ...prev]);
  };

  const handleOpenContractNegotiation = (player: Player, sellerTeam?: Team) => {
    setOfferModalData({
      player,
      team: sellerTeam,
      initialType: 'BUY',
      initialStage: 'PLAYER_CONTRACT'
    });
  };

  const handleOpenPlayerProfile = (p: Player, team?: Team) => {
    let resolvedTeam = team;
    if (!resolvedTeam) {
      resolvedTeam = allTeams.find(t => t.players.some(pl => pl.id === p.id));
    }
    if (!resolvedTeam) {
      const intTeam = INTERNATIONAL_TEAMS.find(t =>
        t.players.some(pl => pl.id === p.id) ||
        (p.parentClubName && t.name.toLowerCase().includes(p.parentClubName.toLowerCase()))
      );
      if (intTeam) {
        resolvedTeam = {
          id: intTeam.id,
          name: intTeam.name,
          badgeColor: intTeam.badgeColor,
          badgeTextColor: 'text-white',
          shortName: intTeam.shortName,
          stadiumName: intTeam.stadium,
          players: intTeam.players,
          budget: intTeam.budget,
          overall: intTeam.overall,
          formation: '4-3-3',
          tactic: 'ATTACKING'
        } as Team;
      }
    }
    setProfilePlayer(p);
    setProfilePlayerTeam(resolvedTeam || null);
  };

  const handleUpdatePlayerContract = (playerId: string, updates: Partial<Player>) => {
    setAllTeams(prev => prev.map(team => ({
      ...team,
      players: team.players.map(p => p.id === playerId ? { ...p, ...updates } : p)
    })));
    if (profilePlayer && profilePlayer.id === playerId) {
      setProfilePlayer(prev => prev ? { ...prev, ...updates } : null);
    }
    if (contractModalPlayer && contractModalPlayer.id === playerId) {
      setContractModalPlayer(prev => prev ? { ...prev, ...updates } : null);
    }
  };

  const handleTransferPlayer = (
    transferredPlayer: Player,
    sellerTeam: Team | undefined,
    buyerTeamId: string,
    transferFee: number,
    isPendingArrival?: boolean
  ) => {
    if (isPendingArrival) {
      // Player joins during Ara Transfer Dönemi (Mid-season transfer window, e.g. Week 18)
      setPendingTransferArrivals(prev => [
        ...prev,
        {
          player: transferredPlayer,
          dealType: 'BUY',
          fee: transferFee,
          joinWeek: 18
        }
      ]);

      // Deduct fee & remove from seller team
      setAllTeams(prev => prev.map(team => {
        if (sellerTeam && team.id === sellerTeam.id) {
          return {
            ...team,
            budget: team.budget + transferFee,
            players: team.players.filter(p => p.id !== transferredPlayer.id)
          };
        }
        if (team.id === buyerTeamId) {
          return {
            ...team,
            budget: Math.max(0, team.budget - transferFee)
          };
        }
        return team;
      }));

      const dateStr = `${currentWeek}. Hafta`;
      const transferInboxMsg: InboxMessage = {
        id: `msg-pending-tr-${Date.now()}`,
        sender: 'Kulüp İdari İşler Masası',
        subject: `📝 Resmi Anlaşma İmzalandı: ${transferredPlayer.name}`,
        date: dateStr,
        content: `${transferredPlayer.name} ile resmi sözleşme şartlarında tam anlaşma sağlandı. Lig devam ettiği için TFF kuralları gereği oyuncu Ara Transfer Döneminde (18. Hafta) takıma katılacaktır.`,
        isRead: false,
        tag: 'TRANSFER'
      };
      setInboxMessages(prev => [transferInboxMsg, ...prev]);

      showToast(
        'success',
        '📝 Anlaşma Tamamlandı!',
        `${transferredPlayer.name} ile anlaşıldı! Lig devam ettiği için oyuncu Ara Transfer Döneminde takıma katılacaktır.`
      );
    } else {
      // Immediate Arrival (Pre-season or break)
      setAllTeams(prev => prev.map(team => {
        if (sellerTeam && team.id === sellerTeam.id) {
          return {
            ...team,
            budget: team.budget + transferFee,
            players: team.players.filter(p => p.id !== transferredPlayer.id)
          };
        }
        if (team.id === buyerTeamId) {
          const updatedPlayers = team.players.some(p => p.id === transferredPlayer.id)
            ? team.players
            : [...team.players, { ...transferredPlayer, isStarting: false }];
          return {
            ...team,
            budget: Math.max(0, team.budget - transferFee),
            players: updatedPlayers
          };
        }
        return team;
      }));

      showToast(
        'success',
        '🤝 Transfer Tamamlandı!',
        `${transferredPlayer.name} hemen takıma katıldı ve A Takım kadrosuna eklendi.`
      );
    }
  };

  const [isMatchModalOpen, setIsMatchModalOpen] = useState(false);
  const [isPreMatchOpen, setIsPreMatchOpen] = useState(false);
  const [isInboxOpen, setIsInboxOpen] = useState(false);
  const [openedFromInbox, setOpenedFromInbox] = useState(false);
  const [isCareerModalOpen, setIsCareerModalOpen] = useState(false);
  const [showPressConference, setShowPressConference] = useState(false);

  // Önerilen Kadro Önizleme State
  const [isRecommendedPreviewActive, setIsRecommendedPreviewActive] = useState(false);
  const [backupPlayers, setBackupPlayers] = useState<Player[]>([]);

  // Automatic revert if user leaves TACTICS tab without saving recommended lineup
  useEffect(() => {
    if (activeTab !== 'TACTICS' && isRecommendedPreviewActive) {
      if (backupPlayers.length > 0) {
        setAllTeams((prev) =>
          prev.map((t) => {
            if (t.id !== currentTeamId) return t;
            return {
              ...t,
              players: backupPlayers
            };
          })
        );
      }
      setIsRecommendedPreviewActive(false);
      setBackupPlayers([]);
    }
  }, [activeTab, isRecommendedPreviewActive, backupPlayers, currentTeamId]);

  // Handlers for Önerilen Kadro (Position-aware & Form/Training & Last Match Rating prioritized with dynamic rotation)
  const handleGoToTacticsWithRecommended = () => {
    const currentTeamObj = allTeams.find(t => t.id === currentTeamId) || allTeams[0];
    setBackupPlayers([...currentTeamObj.players]);

    const available = currentTeamObj.players.filter(p => !p.isInjured && !p.isSuspended);

    // Performance score: Base Overall + Last Match Rating + Form + Morale + Training Progress & Intensity + Stamina + Weekly Dynamic Rotation
    const getScore = (p: Player, roleHint?: string) => {
      const baseOverall = p.overall * 1.5;

      // Son Maç Reytingi ve Ortalama Reyting
      const recentRating = p.lastRating ?? p.averageRating ?? (p.form ?? 7);
      const ratingImpact = (recentRating - 6.5) * 8.5;

      // Form & Moral
      const formImpact = ((p.form ?? 7) - 6) * 4.5;
      const moraleImpact = (((p.morale ?? 75) - 60) / 40) * 6;

      // Antrenman Performansı & İlerlemesi
      const growth = p.growthProgress ?? 50;
      const trainingImpact = (growth / 100) * 12;
      const intensityBoost = p.trainingIntensity === 'Ağır' ? 5 : p.trainingIntensity === 'Normal' ? 2 : -2;

      // Kondisyon / Yorgunluk Durumu (Düşük stamina rotasyona sebep olur)
      const stam = p.stamina ?? 100;
      const staminaPenalty = stam < 80 ? (stam - 80) * 1.5 : (stam - 80) * 0.2;

      // Haftalık Dinamik Form Değişkeni (Her maç birebir aynı 11 çıkmaz, yakın güçteki oyuncular rotasyona girer)
      const numId = Number(p.id.replace(/\D/g, '') || 1);
      const weeklyVariation = Math.sin(numId * 19.3 + (currentWeek || 1) * 4.1) * 5.5;

      // Role-specific attribute affinity
      let roleBonus = 0;
      const attrs = p.attributes;
      if (attrs && roleHint) {
        if (roleHint === 'CB') roleBonus = (attrs.defending * 0.4 + attrs.physical * 0.3);
        else if (roleHint === 'LB' || roleHint === 'RB' || roleHint === 'LWB' || roleHint === 'RWB') roleBonus = (attrs.pace * 0.4 + attrs.defending * 0.3);
        else if (roleHint === 'CDM') roleBonus = (attrs.defending * 0.35 + attrs.physical * 0.35);
        else if (roleHint === 'CAM') roleBonus = (attrs.passing * 0.35 + attrs.shooting * 0.35);
        else if (roleHint === 'LM' || roleHint === 'RM' || roleHint === 'LW' || roleHint === 'RW') roleBonus = (attrs.pace * 0.4 + attrs.passing * 0.3);
        else if (roleHint === 'ST') roleBonus = (attrs.shooting * 0.45 + attrs.physical * 0.25);
      }

      return baseOverall + ratingImpact + formImpact + moraleImpact + trainingImpact + intensityBoost + staminaPenalty + weeklyVariation + roleBonus;
    };

    // Strict categorization by position
    const gkPool = available.filter(p => p.position === 'GK').sort((a,b) => getScore(b) - getScore(a));
    const defPool = available.filter(p => p.position === 'DEF').sort((a,b) => getScore(b) - getScore(a));
    const midPool = available.filter(p => p.position === 'MID').sort((a,b) => getScore(b) - getScore(a));
    const fwPool = available.filter(p => p.position === 'FW').sort((a,b) => getScore(b) - getScore(a));

    const currentFormation = (currentTeamObj.formation || '4-3-3') as FormationType;
    const formationSlots = FORMATION_COORDINATES[currentFormation] || FORMATION_COORDINATES['4-3-3'];

    const chosenIds = new Set<string>();
    const startersByIndex: (Player | null)[] = new Array(11).fill(null);

    // 1. Assign GK (Index 0)
    const bestGK = gkPool[0] || available.find(p => p.position === 'GK') || available[0];
    if (bestGK) {
      startersByIndex[0] = bestGK;
      chosenIds.add(bestGK.id);
    }

    // 2. Assign remaining slots strictly matching their position requirements
    formationSlots.forEach((slot, slotIdx) => {
      if (slotIdx === 0) return; // GK already assigned
      const role = slot.role;

      let candidate: Player | undefined;

      if (role === 'LB' || role === 'RB' || role === 'LWB' || role === 'RWB' || role === 'CB') {
        // DEF slot: sort DEF pool with role affinity
        const availableDefs = defPool.filter(p => !chosenIds.has(p.id)).sort((a, b) => getScore(b, role) - getScore(a, role));
        candidate = availableDefs[0];
      } else if (role === 'CDM' || role === 'CM' || role === 'CAM' || role === 'LM' || role === 'RM') {
        // MID slot: sort MID pool with role affinity
        const availableMids = midPool.filter(p => !chosenIds.has(p.id)).sort((a, b) => getScore(b, role) - getScore(a, role));
        candidate = availableMids[0];
      } else if (role === 'LW' || role === 'RW' || role === 'ST') {
        // FW slot: sort FW pool with role affinity
        const availableFws = fwPool.filter(p => !chosenIds.has(p.id)).sort((a, b) => getScore(b, role) - getScore(a, role));
        candidate = availableFws[0];
      }

      if (candidate) {
        startersByIndex[slotIdx] = candidate;
        chosenIds.add(candidate.id);
      }
    });

    // 3. Fallback for any unassigned slot if the squad doesn't have enough players in a specific natural position
    formationSlots.forEach((slot, slotIdx) => {
      if (startersByIndex[slotIdx]) return;
      const role = slot.role;

      let fallbackPool: Player[] = [];
      if (role === 'LB' || role === 'RB' || role === 'CB' || role === 'LWB' || role === 'RWB') {
        // If DEF ran out, prefer defensive MIDs
        fallbackPool = available.filter(p => !chosenIds.has(p.id) && p.position === 'MID').sort((a, b) => getScore(b) - getScore(a));
      } else if (role === 'LW' || role === 'RW' || role === 'ST') {
        // If FW ran out, prefer attacking MIDs
        fallbackPool = available.filter(p => !chosenIds.has(p.id) && p.position === 'MID').sort((a, b) => getScore(b) - getScore(a));
      } else {
        // If MID ran out, prefer FWs or DEFs
        fallbackPool = available.filter(p => !chosenIds.has(p.id)).sort((a, b) => getScore(b) - getScore(a));
      }

      const candidate = fallbackPool[0] || available.filter(p => !chosenIds.has(p.id))[0];
      if (candidate) {
        startersByIndex[slotIdx] = candidate;
        chosenIds.add(candidate.id);
      }
    });

    const filledStarters = startersByIndex.filter(Boolean) as Player[];

    // If still < 11, backfill with remaining available players
    if (filledStarters.length < 11) {
      const remainingPool = available.filter(p => !chosenIds.has(p.id)).sort((a, b) => getScore(b) - getScore(a));
      const extraNeeded = 11 - filledStarters.length;
      filledStarters.push(...remainingPool.slice(0, extraNeeded));
    }

    const newStarterIds = new Set(filledStarters.map(p => p.id));
    const rest = currentTeamObj.players.filter(p => !newStarterIds.has(p.id));

    const posOrder: Record<string, number> = { GK: 0, DEF: 1, MID: 2, FW: 3 };
    const sortedRest = [...rest].sort((a, b) => (posOrder[a.position] ?? 2) - (posOrder[b.position] ?? 2) || b.overall - a.overall);

    const reorderedPlayers = [
      ...filledStarters.map(p => ({ ...p, isStarting: true })),
      ...sortedRest.map(p => ({ ...p, isStarting: false }))
    ];

    setAllTeams((prev) =>
      prev.map((t) => {
        if (t.id !== currentTeamId) return t;
        return {
          ...t,
          players: reorderedPlayers
        };
      })
    );

    setIsRecommendedPreviewActive(true);
    setActiveTab('TACTICS');
    showToast('info', 'Önerilen Kadro Dizildi ⚽', 'Mevkilere göre kaleci, defans, orta saha ve forvetler doğru yerlerine yerleştirildi.');
  };

  const handleSaveRecommendedLineup = () => {
    setIsRecommendedPreviewActive(false);
    setBackupPlayers([]);
    showToast('success', 'Geçerli Kadro Güncellendi! 💾', 'Önerilen kadro ana dizilişiniz olarak kaydedildi.');
  };

  const handleCancelRecommendedLineup = () => {
    if (backupPlayers.length > 0) {
      setAllTeams((prev) =>
        prev.map((t) => {
          if (t.id !== currentTeamId) return t;
          return {
            ...t,
            players: backupPlayers
          };
        })
      );
    }
    setIsRecommendedPreviewActive(false);
    setBackupPlayers([]);
    showToast('info', 'Eski Kadroya Dönüldü ↺', 'Taktik dizilişiniz önceki haline getirildi.');
  };

  // Gelen Kutusu (Inbox) Messages State
  const [inboxMessages, setInboxMessages] = useState<InboxMessage[]>([
    {
      id: 'm1',
      sender: 'Kulüp Yönetim Kurulu',
      subject: `Sezon Hedefleri ve Bütçe Onayı`,
      date: '27 Temmuz 2026',
      content: `Sayın Menajer, yönetim kurulu olarak bu sezondaki lig şampiyonluğu hedefinizi tam olarak destekliyoruz. Transfer bütçeniz ve yönetim hedefleriniz onaylanmıştır. Başarılar dileriz.`,
      isRead: false,
      tag: 'YÖNETİM'
    },
    {
      id: 'm2',
      sender: 'Sağlık Ekibi Sorumlusu',
      subject: 'Haftalık Oyuncu Kondisyon & Sakatlık Raporu',
      date: '26 Temmuz 2026',
      content: 'Takımdaki tüm oyuncuların genel dayanıklılık seviyeleri takip edilmektedir. Yoğun maç temposunda oyuncuları dinlendirerek antrenman yüklerini düzenlemeniz tavsiye edilir.',
      isRead: false,
      tag: 'SAĞLIK'
    },
    {
      id: 'm3',
      sender: 'Baş Gözlemci (Scout)',
      subject: 'Transfer Pazarı Fırsat Liste Güncellemesi',
      date: '25 Temmuz 2026',
      content: 'Transfer pazarındaki yeni fırsat oyuncuları listenize eklenmiştir. Yüksek reytingli genç yetenekleri kadroya katmak için Transfer Pazarı sekmesini inceleyebilirsiniz.',
      isRead: true,
      tag: 'SCOUT'
    }
  ]);

  const handleToggleInboxRead = (id: string) => {
    setInboxMessages(prev => prev.map(m => m.id === id ? { ...m, isRead: true } : m));
  };

  const handleMarkAllInboxRead = () => {
    setInboxMessages(prev => prev.map(m => ({ ...m, isRead: true })));
  };

  // Splash Screen & Main Menu Flow States
  const [showSplash, setShowSplash] = useState(true);
  const [showMainMenu, setShowMainMenu] = useState(false);
  const [careerModalMode, setCareerModalMode] = useState<'MENU' | 'NEW_CAREER' | 'LOAD_CAREER'>('MENU');

  // Real-time Playtime Counter & Global Click Sound
  useEffect(() => {
    const timer = setInterval(() => {
      // Only increment total playtime when an active career is running and main menu is closed
      if (activeCareerId && !showMainMenu && !showSplash) {
        const current = parseInt(localStorage.getItem('fm_total_playtime_seconds') || '0', 10);
        localStorage.setItem('fm_total_playtime_seconds', (current + 1).toString());
      }
    }, 1000);

    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.closest('button') || target.closest('a') || target.closest('[role="button"]'))) {
        soundFx.playButtonClick();
      }
    };
    window.addEventListener('click', handleGlobalClick);

    return () => {
      clearInterval(timer);
      window.removeEventListener('click', handleGlobalClick);
    };
  }, [activeCareerId, showMainMenu, showSplash]);

  // Toast Notification System
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [daysSinceLastConditionRestore, setDaysSinceLastConditionRestore] = useState<number>(7);

  const showToast = (type: 'success' | 'error' | 'info', title: string, message: string) => {
    const newToast: ToastMessage = {
      id: Date.now().toString() + Math.random().toString(),
      type,
      title,
      message
    };
    setToasts(prev => [...prev.slice(-2), newToast]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== newToast.id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Helper: Trigger Auto-Save every week or week increment
  const triggerAutoSave = (
    updatedWeek?: number,
    updatedSeason?: number,
    updatedTeams?: Team[],
    updatedStandings?: LeagueRow[],
    updatedFixtures?: Fixture[]
  ) => {
    try {
      const curTeam = (updatedTeams || allTeams).find(t => t.id === currentTeamId) || (updatedTeams || allTeams)[0];
      const slotData: SaveSlotData = {
        saveDate: formatCurrentRealDate(),
        gameDateStr: `${updatedSeason || currentSeason}. Sezon, ${updatedWeek || currentWeek}. Hafta`,
        managerName: manager.name,
        teamId: currentTeamId,
        currentWeek: updatedWeek || currentWeek,
        currentSeason: updatedSeason || currentSeason,
        currentDayIndex: currentDayIndex,
        allTeams: updatedTeams || allTeams,
        standings: updatedStandings || standings,
        fixtures: updatedFixtures || fixtures,
        scouts,
        scoutReports,
        inboxMessages,
        pendingBuyOffers,
        pendingTransferArrivals,
        gameMode,
        createdPlayer: createdPlayer || undefined
      };
      saveCareerSlot(activeCareerId, activeCareerName || `${curTeam?.name || 'Takım'} Kariyeri`, 'AUTO', slotData);
      showToast('info', '⚡ Otomatik Kayıt Alındı', `${updatedWeek || currentWeek}. Hafta itibariyle kariyeriniz otomatik kaydedildi.`);
    } catch (err) {
      console.error('Auto save error:', err);
    }
  };

  // Handler: Start New Game Career (Manager or Player Career)
  const handleStartNewGame = (
    managerOrPlayerName: string,
    teamId: string,
    mode: GameMode = 'MANAGER',
    createdPlayerProfile?: CreatedPlayerProfile,
    customTeamsList?: Team[],
    customSaveName?: string
  ) => {
    try {
      const newCareerId = 'career_' + Date.now();
      setGameMode(mode);
      setCreatedPlayer(createdPlayerProfile || null);
      setManager(prev => ({ ...prev, name: managerOrPlayerName }));
      setCurrentTeamId(teamId);
      setCurrentWeek(1);
      setCurrentSeason(1);
      setCurrentDayIndex(0);

      const baseList = (customTeamsList && customTeamsList.length >= 6)
        ? customTeamsList
        : INITIAL_TEAMS;

      let teamsCopy = JSON.parse(JSON.stringify(baseList.map(t => ensureTeamHas20Players(t)))) as Team[];

      // Ensure selected team is included in teamsCopy
      if (!teamsCopy.some(t => t.id === teamId)) {
        const foundInt = INTERNATIONAL_TEAMS.find(t => t.id === teamId);
        if (foundInt) {
          teamsCopy.unshift(ensureTeamHas20Players({
            id: foundInt.id,
            name: foundInt.name,
            badgeColor: foundInt.badgeColor,
            badgeTextColor: 'text-white',
            shortName: foundInt.shortName,
            stadiumName: foundInt.stadium,
            players: foundInt.players,
            budget: foundInt.budget,
            overall: foundInt.overall,
            formation: '4-3-3',
            tactic: 'ATTACKING'
          }) as Team);
        }
      }

      if (mode === 'PLAYER_CAREER' && createdPlayerProfile) {
        const targetTeam = teamsCopy.find(t => t.id === teamId);
        if (targetTeam) {
          const playerObj: Player = {
            id: createdPlayerProfile.id,
            name: createdPlayerProfile.name,
            age: createdPlayerProfile.age,
            position: createdPlayerProfile.position,
            specificRole: createdPlayerProfile.specificRole,
            overall: createdPlayerProfile.overall,
            stamina: createdPlayerProfile.stamina,
            form: createdPlayerProfile.form,
            marketValue: createdPlayerProfile.marketValue,
            attributes: createdPlayerProfile.attributes,
            isStarting: true,
            goalsScored: 0,
            assists: 0,
            wage: createdPlayerProfile.wage,
            nationality: createdPlayerProfile.nationality,
            number: 10
          };
          if (!targetTeam.players.some(p => p.id === playerObj.id)) {
            targetTeam.players.unshift(playerObj);
          }
        }
      }

      const selTeam = teamsCopy.find(t => t.id === teamId) || teamsCopy[0];
      const finalSaveName = customSaveName?.trim() || `${selTeam?.name || 'Takım'} Kariyeri`;

      if (selTeam?.name) {
        localStorage.setItem('fm_last_played_team', selTeam.name);
      }

      setActiveCareerId(newCareerId);
      setActiveCareerName(finalSaveName);

      const initialStandings = generateInitialStandings(teamsCopy);
      const initialFixtures = generateLeagueSchedule(teamsCopy.map(t => t.id), teamId, 1);

      setAllTeams(teamsCopy);
      setStandings(initialStandings);
      setFixtures(initialFixtures);
      setIsCareerModalOpen(false);
      setShowMainMenu(false);
      setShowPressConference(true);

      // Initial saves: Save as BOTH Normal slot AND Auto slot immediately!
      const initialSlotData: SaveSlotData = {
        saveDate: formatCurrentRealDate(),
        gameDateStr: '1. Sezon, 1. Hafta',
        managerName: managerOrPlayerName,
        teamId: teamId,
        currentWeek: 1,
        currentSeason: 1,
        currentDayIndex: 0,
        allTeams: teamsCopy,
        standings: initialStandings,
        fixtures: initialFixtures,
        scouts,
        scoutReports,
        inboxMessages,
        pendingBuyOffers,
        pendingTransferArrivals,
        gameMode: mode,
        createdPlayer: createdPlayerProfile
      };

      try {
        saveCareerSlot(newCareerId, finalSaveName, 'NORMAL', initialSlotData);
        saveCareerSlot(newCareerId, finalSaveName, 'AUTO', initialSlotData);
      } catch (err) {
        console.error('Error saving initial career slot:', err);
      }

      showToast('success', 'Kariyer Oluşturuldu & Kaydedildi 💾', `"${finalSaveName}" dosyası başlangıç verileriyle kaydedildi.`);
    } catch (error) {
      console.error('Error in handleStartNewGame:', error);
      setIsCareerModalOpen(false);
      setShowMainMenu(false);
      setShowPressConference(true);
    }
  };

  // Handler: Reset All Data & Force Reload superLigTeams.ts
  const handleResetAllData = () => {
    hardResetData();
  };

  // Handler: Transfer Created Player
  const handleTransferCreatedPlayer = (newTeamId: string) => {
    if (!createdPlayer) return;
    const newTeam = allTeams.find(t => t.id === newTeamId);
    if (!newTeam) return;

    const updatedTeams = allTeams.map(t => {
      if (t.id === currentTeamId) {
        return {
          ...t,
          players: t.players.filter(p => p.id !== createdPlayer.id)
        };
      }
      if (t.id === newTeamId) {
        const playerObj: Player = {
          id: createdPlayer.id,
          name: createdPlayer.name,
          age: createdPlayer.age,
          position: createdPlayer.position,
          specificRole: createdPlayer.specificRole,
          overall: createdPlayer.overall,
          stamina: createdPlayer.stamina,
          form: createdPlayer.form,
          marketValue: createdPlayer.marketValue,
          attributes: createdPlayer.attributes,
          isStarting: true,
          goalsScored: createdPlayer.goalsScored,
          assists: createdPlayer.assists,
          wage: createdPlayer.wage,
          nationality: createdPlayer.nationality,
          number: 10
        };
        return {
          ...t,
          players: [playerObj, ...t.players]
        };
      }
      return t;
    });

    setAllTeams(updatedTeams);
    setCurrentTeamId(newTeamId);
    setCreatedPlayer(prev => prev ? { ...prev, currentTeamId: newTeamId } : null);
    showToast('success', 'Transfer Gerçekleşti! 📝', `${createdPlayer.name}, €${(createdPlayer.marketValue / 1_000_000).toFixed(1)}M bonservis bedeliyle ${newTeam.name} kulübüne transfer oldu!`);
  };

  // Handler: Complete Press Conference
  const handlePressConferenceComplete = (answersSummary: string[]) => {
    setShowPressConference(false);
    setActiveTab(gameMode === 'PLAYER_CAREER' ? 'MY_PLAYER' : 'HOME');
    const team = allTeams.find(t => t.id === currentTeamId) || allTeams[0];
    showToast(
      'success',
      'İmza Töreni & Basın Toplantısı Tamamlandı! 🎙️',
      gameMode === 'PLAYER_CAREER'
        ? `${createdPlayer?.name || manager.name}, ${team.name} formasını giydi. Sezon başlıyor!`
        : `${manager.name} yönetiminde ${team.name} sezonu resmen başladı. Başarılar!`
    );
  };

  // Handler: Manual Save Game Career
  const handleSaveGame = () => {
    const currentTeam = allTeams.find(t => t.id === currentTeamId) || allTeams[0];
    const slotData: SaveSlotData = {
      saveDate: formatCurrentRealDate(),
      gameDateStr: `${currentSeason}. Sezon, ${currentWeek}. Hafta`,
      managerName: manager.name,
      teamId: currentTeam.id,
      currentWeek,
      currentSeason,
      currentDayIndex,
      allTeams,
      standings,
      fixtures,
      scouts,
      scoutReports,
      inboxMessages,
      pendingBuyOffers,
      pendingTransferArrivals,
      gameMode,
      createdPlayer: createdPlayer || undefined
    };

    try {
      saveCareerSlot(activeCareerId, activeCareerName, 'NORMAL', slotData);
      showToast('success', 'Manuel Kayıt Başarılı! 💾', `${activeCareerName} (${currentSeason}. Sezon, ${currentWeek}. Hafta) kaydedildi.`);
    } catch (e) {
      console.error('Save error:', e);
      showToast('error', 'Kayıt Hatası', 'Oyunu kaydederken bir sorun oluştu.');
    }
  };

  // Handler: Load Saved Career
  const handleLoadSavedGame = (savedState: any) => {
    if (savedState.id) {
      setActiveCareerId(savedState.id);
    }
    if (savedState.saveName) {
      setActiveCareerName(savedState.saveName);
    }
    setManager(prev => ({ ...prev, name: savedState.managerName }));
    setCurrentTeamId(savedState.teamId);
    setCurrentWeek(savedState.currentWeek);
    setCurrentSeason(savedState.currentSeason);
    setCurrentDayIndex(savedState.currentDayIndex || 0);
    setAllTeams(savedState.allTeams);
    setStandings(savedState.standings);
    setFixtures(savedState.fixtures);
    if (savedState.scouts) setScouts(savedState.scouts);
    if (savedState.scoutReports) setScoutReports(savedState.scoutReports);
    if (savedState.inboxMessages) setInboxMessages(savedState.inboxMessages);
    if (savedState.pendingBuyOffers) setPendingBuyOffers(savedState.pendingBuyOffers);
    if (savedState.pendingTransferArrivals) setPendingTransferArrivals(savedState.pendingTransferArrivals);
    setGameMode(savedState.gameMode || 'MANAGER');
    setCreatedPlayer(savedState.createdPlayer || null);
    const loadedTeam = (savedState.allTeams || []).find((t: Team) => t.id === savedState.teamId);
    if (loadedTeam?.name) {
      localStorage.setItem('fm_last_played_team', loadedTeam.name);
    }

    setIsCareerModalOpen(false);
    setShowMainMenu(false);
    showToast('success', 'Kariyer Yüklendi! 📂', `${savedState.saveName || 'Kariyer'} oyunu başarıyla açıldı.`);
  };

  // Active user team
  const currentTeam = allTeams.find(t => t.id === currentTeamId) || allTeams[0] || INITIAL_TEAMS[0];

  // Current opponent fixture
  const currentWeekFixture = currentTeam ? fixtures.find(
    f => f.week === currentWeek && (f.homeTeamId === currentTeam.id || f.awayTeamId === currentTeam.id)
  ) : undefined;

  const opponentTeamId = (currentWeekFixture && currentTeam)
    ? currentWeekFixture.homeTeamId === currentTeam.id
      ? currentWeekFixture.awayTeamId
      : currentWeekFixture.homeTeamId
    : (currentTeam ? allTeams.find(t => t.id !== currentTeam.id)?.id || 'fenerbahce' : 'fenerbahce');

  const opponentTeam = allTeams.find(t => t.id === opponentTeamId) || allTeams[1] || allTeams[0] || INITIAL_TEAMS[1];

  useEffect(() => {
    if (!isVacationActive) return;

    if (vacationDaysTotal !== -1 && vacationDaysElapsed >= vacationDaysTotal) {
      setIsVacationActive(false);
      showToast('success', '🌴 Tatil Tamamlandı!', `${vacationDaysElapsed} günlük tatiliniz sona erdi. Kulübe hoş geldiniz.`);
      return;
    }

    const timer = setTimeout(() => {
      if (currentDayIndex < 4) {
        handleAdvanceDay();
      } else {
        if (currentTeam && opponentTeam) {
          const quickSim = simulateQuickMatch(currentTeam, opponentTeam);
          let prizeMoney = 150000;
          if (quickSim.homeScore > quickSim.awayScore) {
            prizeMoney = 500000;
          } else if (quickSim.homeScore === quickSim.awayScore) {
            prizeMoney = 250000;
          }
          handleMatchCompleted(quickSim.homeScore, quickSim.awayScore, prizeMoney);
          setVacationSimulatedMatches(prev => prev + 1);
        }
      }
      setVacationDaysElapsed(prev => prev + 1);
    }, 1600);

    return () => clearTimeout(timer);
  }, [isVacationActive, vacationDaysElapsed, vacationDaysTotal, currentDayIndex, currentTeam, opponentTeam]);

  // Handler: Select team
  const handleSelectTeam = (teamId: string) => {
    setCurrentTeamId(teamId);
    setSelectedPlayer(null);
  };

  // Handler: Swap starter and sub or two starters or place into any empty slot with no position restrictions
  const handleSwapPlayers = (p1: Player, p2: Player) => {
    const isP1Empty = p1.id.startsWith('empty-slot-');
    const isP2Empty = p2.id.startsWith('empty-slot-');
    const isP1Remove = p1.id.startsWith('empty-slot-remove-') || p1.id === 'empty-slot-remove';
    const isP2Remove = p2.id.startsWith('empty-slot-remove-') || p2.id === 'empty-slot-remove';

    // Direct Removal from Starting 11 to Bench (Leaves empty slot without moving any other player)
    if (isP2Remove || isP1Remove) {
      const targetPlayer = isP2Remove ? p1 : p2;
      setAllTeams((prevTeams) =>
        prevTeams.map((team) => {
          if (team.id !== currentTeam.id) return team;

          // 1. Derive current fixed slot index (0..10) for all starting players
          const currentSlots: (Player | null)[] = new Array(11).fill(null);
          const assignedIds = new Set<string>();

          // Explicit starterIndex
          team.players.forEach((p) => {
            if (p.isStarting && p.starterIndex !== undefined && p.starterIndex >= 0 && p.starterIndex < 11) {
              if (!currentSlots[p.starterIndex]) {
                currentSlots[p.starterIndex] = p;
                assignedIds.add(p.id);
              }
            }
          });

          // Any other starters without starterIndex get locked into next vacant slot
          team.players.forEach((p) => {
            if (p.isStarting && !assignedIds.has(p.id)) {
              const emptyIdx = currentSlots.findIndex((s) => s === null);
              if (emptyIdx !== -1) {
                currentSlots[emptyIdx] = p;
                assignedIds.add(p.id);
              }
            }
          });

          const playerIdToSlot = new Map<string, number>();
          currentSlots.forEach((p, slotIdx) => {
            if (p) playerIdToSlot.set(p.id, slotIdx);
          });

          // 2. Remove target player to bench and freeze all other starters in their exact slots
          const updated = team.players.map((p) => {
            if (p.id === targetPlayer.id) {
              return { ...p, isStarting: false, starterIndex: undefined };
            }
            if (p.isStarting) {
              const lockedSlot = playerIdToSlot.get(p.id) ?? p.starterIndex;
              return { ...p, starterIndex: lockedSlot };
            }
            return p;
          });
          return { ...team, players: updated };
        })
      );
      setSelectedPlayer(null);
      showToast('info', 'Yedeklere Alındı 📋', `${targetPlayer.name} ilk 11'den çıkarılıp boş slota çevrildi.`);
      return;
    }

    const isP1Injured = !!(p1.isInjured || (p1.injuryWeeksLeft && p1.injuryWeeksLeft > 0));
    const isP2Injured = !!(p2.isInjured || (p2.injuryWeeksLeft && p2.injuryWeeksLeft > 0));
    const isP1Suspended = !!(p1.isSuspended || (p1.suspensionMatchesLeft && p1.suspensionMatchesLeft > 0));
    const isP2Suspended = !!(p2.isSuspended || (p2.suspensionMatchesLeft && p2.suspensionMatchesLeft > 0));

    // Prevent placing injured or suspended player into starting XI slot
    if (isP2Empty && isP1Injured) {
      showToast('error', 'Sakat Oyuncu Oynatılamaz! 🏥', `${p1.name} sakat olduğu için (${p1.injuryWeeksLeft || 1} hafta) ilk 11'e alınamaz. Tedavisi devam ediyor.`);
      return;
    }
    if (isP1Empty && isP2Injured) {
      showToast('error', 'Sakat Oyuncu Oynatılamaz! 🏥', `${p2.name} sakat olduğu için (${p2.injuryWeeksLeft || 1} hafta) ilk 11'e alınamaz. Tedavisi devam ediyor.`);
      return;
    }
    if (isP2Empty && isP1Suspended) {
      showToast('error', 'Cezalı Oyuncu Oynatılamaz! 🟥', `${p1.name} cezalı olduğu için (${p1.suspensionReason || 'Kırmızı Kart'}) ilk 11'e alınamaz.`);
      return;
    }
    if (isP1Empty && isP2Suspended) {
      showToast('error', 'Cezalı Oyuncu Oynatılamaz! 🟥', `${p2.name} cezalı olduğu için (${p2.suspensionReason || 'Kırmızı Kart'}) ilk 11'e alınamaz.`);
      return;
    }

    // Check if one of them is starting and the other injured/suspended player is trying to enter starting XI
    const existingP1 = currentTeam.players.find((p) => p.id === p1.id);
    const existingP2 = currentTeam.players.find((p) => p.id === p2.id);

    if (existingP1 && existingP2) {
      if ((existingP1.isStarting && isP2Injured) || (existingP2.isStarting && isP1Injured)) {
        const injuredP = isP1Injured ? p1 : p2;
        showToast('error', 'Sakat Oyuncu Oynatılamaz! 🏥', `${injuredP.name} sakat olduğu için (${injuredP.injuryWeeksLeft || 1} hafta) ilk 11'e alınamaz. Tedavisi devam ediyor.`);
        return;
      }
      if ((existingP1.isStarting && isP2Suspended) || (existingP2.isStarting && isP1Suspended)) {
        const suspP = isP1Suspended ? p1 : p2;
        showToast('error', 'Cezalı Oyuncu Oynatılamaz! 🟥', `${suspP.name} cezalı olduğu için (${suspP.suspensionReason || 'Kırmızı Kart'}) ilk 11'e alınamaz.`);
        return;
      }
    }

    setAllTeams((prevTeams) =>
      prevTeams.map((team) => {
        if (team.id !== currentTeam.id) return team;

        // Derive current fixed slot index (0..10) for all starting players
        const currentSlots: (Player | null)[] = new Array(11).fill(null);
        const assignedIds = new Set<string>();

        team.players.forEach((p) => {
          if (p.isStarting && p.starterIndex !== undefined && p.starterIndex >= 0 && p.starterIndex < 11) {
            if (!currentSlots[p.starterIndex]) {
              currentSlots[p.starterIndex] = p;
              assignedIds.add(p.id);
            }
          }
        });

        team.players.forEach((p) => {
          if (p.isStarting && !assignedIds.has(p.id)) {
            const emptyIdx = currentSlots.findIndex((s) => s === null);
            if (emptyIdx !== -1) {
              currentSlots[emptyIdx] = p;
              assignedIds.add(p.id);
            }
          }
        });

        const playerIdToSlot = new Map<string, number>();
        currentSlots.forEach((p, slotIdx) => {
          if (p) playerIdToSlot.set(p.id, slotIdx);
        });

        let playersCopy = team.players.map((p) => {
          if (p.isStarting) {
            return { ...p, starterIndex: playerIdToSlot.get(p.id) ?? p.starterIndex };
          }
          return p;
        });

        if (isP2Empty || isP1Empty) {
          const emptySlotStr = isP2Empty ? p2.id : p1.id;
          const movingPlayerObj = isP2Empty ? p1 : p2;
          const targetSlot = parseInt(emptySlotStr.replace('empty-slot-', ''), 10);

          if (!isNaN(targetSlot) && targetSlot >= 0 && targetSlot < 11) {
            playersCopy = playersCopy.map((p) => {
              if (p.id === movingPlayerObj.id) {
                return { ...p, isStarting: true, starterIndex: targetSlot };
              }
              // If another player was in this specific slot, unseat them to bench
              if (p.starterIndex === targetSlot && p.id !== movingPlayerObj.id) {
                return { ...p, isStarting: false, starterIndex: undefined };
              }
              return p;
            });
          }
        } else {
          const idx1 = playersCopy.findIndex((p) => p.id === p1.id);
          const idx2 = playersCopy.findIndex((p) => p.id === p2.id);

          if (idx1 !== -1 && idx2 !== -1) {
            const player1 = playersCopy[idx1];
            const player2 = playersCopy[idx2];

            const p1IsStarting = player1.isStarting;
            const p2IsStarting = player2.isStarting;
            const p1Slot = player1.starterIndex;
            const p2Slot = player2.starterIndex;

            if (p1IsStarting && p2IsStarting) {
              // Both are starters on pitch: swap their starterIndex / positions freely!
              playersCopy[idx1] = { ...player1, starterIndex: p2Slot };
              playersCopy[idx2] = { ...player2, starterIndex: p1Slot };
            } else if (p1IsStarting && !p2IsStarting) {
              // P1 is starter, P2 is sub: P2 takes P1's slot, P1 goes to bench
              playersCopy[idx1] = { ...player1, isStarting: false, starterIndex: undefined };
              playersCopy[idx2] = { ...player2, isStarting: true, starterIndex: p1Slot };
            } else if (!p1IsStarting && p2IsStarting) {
              // P1 is sub, P2 is starter: P1 takes P2's slot, P2 goes to bench
              playersCopy[idx1] = { ...player1, isStarting: true, starterIndex: p2Slot };
              playersCopy[idx2] = { ...player2, isStarting: false, starterIndex: undefined };
            } else {
              // Both on bench: swap their array positions
              const temp = playersCopy[idx1];
              playersCopy[idx1] = playersCopy[idx2];
              playersCopy[idx2] = temp;
            }
          }
        }

        return { ...team, players: playersCopy };
      })
    );
    setSelectedPlayer(null);
    showToast('info', 'Kadro Güncellendi 📋', `${p1.name} ⇄ ${p2.name} değişimi uygulandı.`);
  };

  // Handler: Change Formation
  const handleChangeFormation = (formation: FormationType) => {
    setAllTeams((prev) =>
      prev.map((t) => (t.id === currentTeam.id ? { ...t, formation } : t))
    );
    showToast('info', 'Taktik Değişikliği 📋', `Yeni diziliş ayarlandı: ${formation}`);
  };

  // Handler: Change Tactic Style
  const handleChangeTactic = (tactic: TacticType) => {
    setAllTeams((prev) =>
      prev.map((t) => (t.id === currentTeam.id ? { ...t, tactic } : t))
    );
    showToast('info', 'Oyun Anlayışı 🎯', `Yeni taktik stil: ${tactic}`);
  };

  // Handler: Update Detailed Tactical Settings
  const handleUpdateTacticalDetails = (details: Team['tacticalDetails']) => {
    setAllTeams((prev) =>
      prev.map((t) => (t.id === currentTeam.id ? { ...t, tacticalDetails: { ...t.tacticalDetails, ...details } } : t))
    );
  };

  // Handler: Buy Player from Transfer Market
  const handleBuyPlayer = (newPlayer: Player) => {
    setAllTeams((prevTeams) =>
      prevTeams.map((team) => {
        if (team.id !== currentTeam.id) return team;
        return {
          ...team,
          budget: team.budget - newPlayer.marketValue,
          players: [...team.players, { ...newPlayer, isStarting: false }]
        };
      })
    );

    const dateStr = `${currentWeek}. Hafta`;
    const otherTeams = allTeams.filter(t => t.id !== currentTeam.id);
    const rivalTeam = otherTeams.length > 0 ? otherTeams[Math.floor(Math.random() * otherTeams.length)] : allTeams[0];

    // 1. Fan Club Inbox Message
    const fanMsg: InboxMessage = {
      id: `msg-tr-fan-${Date.now()}`,
      sender: 'Taraftar Derneği Temsilciliği',
      subject: `🔥 YENİ TRANSFER COŞKUSU: ${newPlayer.name}!`,
      date: dateStr,
      content: `Sayın Menajerim,\n\n${newPlayer.name} (${newPlayer.specificRole || newPlayer.position}) transferi kulübümüzde ve camiamızda müthiş bir sevinç yarattı! Tribünler yeni oyuncumuzu sahada formamızla görmek için sabırsızlanıyor.\n\nBaşarılar Dileriz,\nTaraftar Grubu`,
      isRead: false,
      tag: 'YÖNETİM'
    };

    // 2. Rival Manager Statement Inbox Message (Varied without OVR mentions)
    const rivalQuotes = [
      `"${currentTeam.name} takımı ${newPlayer.name} hamlesiyle kadrosuna çok değerli bir isim kattı. Sahada zorlu bir mücadele bizi bekliyor ama biz kendi futbolumuzu oynayıp galibiyeti hedefleyeceğiz."`,
      `"${newPlayer.name} kaliteli ve takıma derinlik katan bir oyuncu. ${currentTeam.name} yönetimi iyi bir transfer gerçekleştirdi. Ancak biz taktiksel disiplinimizle karşılık vereceğiz."`,
      `"${newPlayer.name} transferi ligdeki rekabeti daha da kızıştıracak. Rakibimize hayırlı olsun fakat biz sahaya 3 puan parolasıyla çıkmaya devam edeceğiz."`
    ];
    const chosenQuote = rivalQuotes[Math.floor(Math.random() * rivalQuotes.length)];

    const rivalManagerMsg: InboxMessage = {
      id: `msg-tr-rival-${Date.now()}`,
      sender: `${rivalTeam.name} Teknik Direktörü`,
      subject: `🎙️ RAKİP TD YORUMU: "${newPlayer.name} HAMLESİ"`,
      date: dateStr,
      content: chosenQuote,
      isRead: false,
      tag: 'MEDYA'
    };

    setInboxMessages(prev => [fanMsg, rivalManagerMsg, ...prev]);
    showToast('success', 'Transfer Tamamlandı! 🤝', `${newPlayer.name} kadroya katıldı. Taraftar ve basın tebrik mesajları Gelen Kutusu'na eklendi.`);
  };

  // Handler: Update Individual Player Training Focus & Intensity
  const handleUpdatePlayerTraining = (playerId: string, focus: string, intensity: string) => {
    setAllTeams((prevTeams) =>
      prevTeams.map((team) => {
        if (team.id !== currentTeam.id) return team;
        const updatedPlayers = team.players.map((p) => {
          if (p.id !== playerId) return p;
          return {
            ...p,
            trainingFocus: focus as any,
            trainingIntensity: intensity as any
          };
        });
        return { ...team, players: updatedPlayers };
      })
    );
  };

  // Handler: Update Player Attributes (e.g. Target Position)
  const handleUpdatePlayerAttributes = (playerId: string, attributes: Partial<Player>) => {
    setAllTeams((prevTeams) =>
      prevTeams.map((team) => {
        if (team.id !== currentTeam.id) return team;
        const updatedPlayers = team.players.map((p) => {
          if (p.id !== playerId) return p;
          return {
            ...p,
            ...attributes
          };
        });
        return { ...team, players: updatedPlayers };
      })
    );
  };

  // Handler: Restore Stamina
  const handleRestoreStaminaAll = () => {
    setDaysSinceLastConditionRestore(0);
    setAllTeams((prevTeams) =>
      prevTeams.map((team) => {
        if (team.id !== currentTeam.id) return team;
        const restored = team.players.map((p) => ({ ...p, stamina: 100 }));
        return { ...team, players: restored };
      })
    );
  };

  // Handler: Save Manager Name
  const handleUpdateManagerName = (newName: string) => {
    setManager((prev) => ({ ...prev, name: newName }));
    showToast('success', 'Profil Güncellendi 👤', `Menajer ismi "${newName}" olarak kaydedildi.`);
  };

  // Scout Assignment & Hiring Handlers
  const handleAssignScout = (playerId: string, playerName: string) => {
    const availableScout = scouts.find(s => !s.assignedPlayerId);
    if (!availableScout) {
      setIsScoutManagementOpen(true);
      showToast('info', 'Boşta Gözlemci Yok', 'Tüm gözlemcileriniz görevde. Yeni gözlemci işe alabilirsiniz.');
      return;
    }

    setScouts(prev => prev.map(s => {
      if (s.id === availableScout.id) {
        return {
          ...s,
          assignedPlayerId: playerId,
          assignedPlayerName: playerName,
          assignedDaysLeft: 7 // 1 Week
        };
      }
      return s;
    }));

    showToast(
      'success',
      '🔍 Gözlemci Görevlendirildi',
      `${availableScout.name}, ${playerName} oyuncusunu izlemek üzere göreve başladı. Rapor 1 hafta içinde hazır olacak.`
    );
  };

  const handleHireScout = (scoutToHire: Scout) => {
    if (scouts.length >= 5) {
      showToast('error', 'Limit Aşıldı', 'Maksimum 5 gözlemci sınırına ulaşıldı.');
      return;
    }

    setScouts(prev => [...prev, scoutToHire]);
    setCandidateScouts(prev => prev.filter(c => c.id !== scoutToHire.id));
    showToast('success', 'Gözlemci İşe Alındı! 👔', `${scoutToHire.name} (€${(scoutToHire.weeklyWage).toLocaleString()}/hf) ekibinize katıldı!`);
  };

  const handleFireScout = (scoutId: string) => {
    const scoutToFire = scouts.find(s => s.id === scoutId);
    if (!scoutToFire) return;

    setScouts(prev => prev.filter(s => s.id !== scoutId));
    setCandidateScouts(prev => [...prev, { ...scoutToFire, assignedPlayerId: null, assignedPlayerName: null, assignedDaysLeft: null }]);
    showToast('info', 'Sözleşme Feshedildi', `${scoutToFire.name} ile yollar ayrıldı.`);
  };

  const processScoutingProgress = (daysAdvanced: number) => {
    setScouts(prevScouts => {
      return prevScouts.map(s => {
        if (!s.assignedPlayerId || s.assignedDaysLeft == null) return s;
        const remaining = s.assignedDaysLeft - daysAdvanced;
        if (remaining <= 0) {
          // Finished scouting!
          let playerObj: Player | undefined;
          for (const tm of allTeams) {
            const found = tm.players.find(p => p.id === s.assignedPlayerId);
            if (found) {
              playerObj = found;
              break;
            }
          }
          if (playerObj) {
            const pot = playerObj.potential || (
              playerObj.age <= 21
                ? Math.min(99, playerObj.overall + 10)
                : playerObj.age <= 25
                ? Math.min(99, playerObj.overall + 4)
                : playerObj.overall
            );

            setScoutReports(prevR => [
              ...prevR.filter(r => r.playerId !== playerObj!.id),
              {
                playerId: playerObj!.id,
                playerName: playerObj!.name,
                revealedPotential: pot,
                expiryDaysLeft: 14 // 2 Weeks
              }
            ]);

            showToast(
              'success',
              '🔍 Gözlem Raporu Geldi!',
              `${s.name}, ${playerObj.name} için rapor sundu: Potansiyel (PA): ${pot}`
            );
          }
          return {
            ...s,
            assignedPlayerId: null,
            assignedPlayerName: null,
            assignedDaysLeft: null
          };
        }
        return { ...s, assignedDaysLeft: remaining };
      });
    });

    setScoutReports(prevReports =>
      prevReports
        .map(r => ({ ...r, expiryDaysLeft: r.expiryDaysLeft - daysAdvanced }))
        .filter(r => r.expiryDaysLeft > 0)
    );
  };

  // Handler: Complete Match & Advance League
  const handleMatchCompleted = (
    homeScoreParam: number,
    awayScoreParam: number,
    prizeMoney: number,
    userPlayerRatings?: PlayerRating[],
    simMatchStats?: MatchStats | null,
    simMatchEvents?: MatchEvent[]
  ) => {
    // In MatchSimulationModal, parameter 1 is home team score and parameter 2 is away team score
    const finalHomeScore = homeScoreParam;
    const finalAwayScore = awayScoreParam;

    // Simulate all other unplayed matches in currentWeek so all teams' scores stay updated
    const otherResults: { homeTeamId: string; awayTeamId: string; homeScore: number; awayScore: number }[] = [];
    const playerStatsMap: Record<string, { goals: number; assists: number; rating: number }> = {};

    const unplayedOtherFixtures = fixtures.filter(
      f => f.week === currentWeek && !f.played && !(f.homeTeamId === currentTeam.id || f.awayTeamId === currentTeam.id)
    );

    unplayedOtherFixtures.forEach(fix => {
      const hTeam = allTeams.find(t => t.id === fix.homeTeamId);
      const aTeam = allTeams.find(t => t.id === fix.awayTeamId);
      if (hTeam && aTeam) {
        const sim = simulateQuickMatch(hTeam, aTeam);
        otherResults.push({
          homeTeamId: fix.homeTeamId,
          awayTeamId: fix.awayTeamId,
          homeScore: sim.homeScore,
          awayScore: sim.awayScore
        });
        if (sim.playerStats) {
          sim.playerStats.forEach(st => {
            playerStatsMap[st.playerId] = {
              goals: st.goals,
              assists: st.assists,
              rating: st.rating
            };
          });
        }
      }
    });

    if (userPlayerRatings) {
      userPlayerRatings.forEach(pr => {
        playerStatsMap[pr.playerId] = {
          goals: pr.goals,
          assists: pr.assists,
          rating: pr.rating
        };
      });
    }

    // 1. Update Current Week Fixtures with Scores
    setFixtures((prevFixtures) =>
      prevFixtures.map((f) => {
        if (f.week === currentWeek) {
          if (f.homeTeamId === currentTeam.id || f.awayTeamId === currentTeam.id) {
            return {
              ...f,
              played: true,
              homeScore: finalHomeScore,
              awayScore: finalAwayScore
            };
          }
          const otherSim = otherResults.find(o => o.homeTeamId === f.homeTeamId && o.awayTeamId === f.awayTeamId);
          if (otherSim) {
            return {
              ...f,
              played: true,
              homeScore: otherSim.homeScore,
              awayScore: otherSim.awayScore
            };
          }
        }
        return f;
      })
    );

    // 2. Update League Table Standings for all played matches in current week
    setStandings((prevStandings) => {
      let updated = [...prevStandings];

      // Update User Match Result
      const homeId = currentWeekFixture?.homeTeamId || currentTeam.id;
      const awayId = currentWeekFixture?.awayTeamId || opponentTeam.id;

      updated = updateTeamRow(updated, homeId, finalHomeScore, finalAwayScore);
      updated = updateTeamRow(updated, awayId, finalAwayScore, finalHomeScore);

      // Update Other Matches Results
      otherResults.forEach(o => {
        updated = updateTeamRow(updated, o.homeTeamId, o.homeScore, o.awayScore);
        updated = updateTeamRow(updated, o.awayTeamId, o.awayScore, o.homeScore);
      });

      return updated;
    });

    // 3. Dynamic Match Result Notification & Match Report Generation
    const realDateObj = getSimulatedRealDate(currentSeason, currentWeek, currentDayIndex, language);
    const matchDateStr = realDateObj.dateStr;

    const isUserHome = currentWeekFixture ? currentWeekFixture.homeTeamId === currentTeam.id : true;
    const userGoals = isUserHome ? finalHomeScore : finalAwayScore;
    const oppGoals = isUserHome ? finalAwayScore : finalHomeScore;
    const goalDiff = userGoals - oppGoals;
    const isWin = userGoals > oppGoals;
    const isDraw = userGoals === oppGoals;

    let resultMsgSubject = '';
    let resultMsgContent = '';

    if (isWin) {
      if (goalDiff >= 3) {
        const bigWinTitles = [
          `🔥 ŞOV VE FARKLI GALİBİYET: ${currentTeam.name} ${userGoals}-${oppGoals} ${opponentTeam.name}`,
          `💥 TARİHİ FARK: ${currentTeam.name} Rakibini Sahadan Sildi (${userGoals}-${oppGoals})`,
          `✨ GÖVDE GÖSTERİSİ: Muhteşem Futbolla ${userGoals}-${oppGoals} Zafer!`
        ];
        resultMsgSubject = bigWinTitles[Math.floor(Math.random() * bigWinTitles.length)];
        resultMsgContent = `Sayın Menajerim,\n\n${currentWeek}. Haftada ${opponentTeam.name} karşısında aldığımız ${userGoals}-${oppGoals}'lik görkemli galibiyetle lige damga vurduk! Oyuncularımızın temposu, yüksek pas isabeti ve bitiriciliği rakip savunmayı tamamen çaresiz bıraktı.\n\nYönetim kurulu ve taraftarlarımız bu muazzam oyun için sizi ve tüm takımı tebrik ediyor!`;
      } else {
        const winTitles = [
          `🎉 ZAFER BİLDİRİMİ: ${currentTeam.name} ${userGoals}-${oppGoals} ${opponentTeam.name}`,
          `🔥 MUHTEŞEM 3 PUAN! ${currentTeam.name} Sahadan Galip Ayrıldı (${userGoals}-${oppGoals})`,
          `⚡ KRİTİK GALİBİYET: ${currentTeam.name} ${userGoals}-${oppGoals} ${opponentTeam.name}`,
          `🚀 SON DAKİKA GOLÜYLE KRİTİK 3 PUAN: ${userGoals}-${oppGoals}`
        ];
        resultMsgSubject = winTitles[Math.floor(Math.random() * winTitles.length)];
        resultMsgContent = `Sayın Menajerim,\n\n${currentWeek}. Hafta lig mücadelesinde ${opponentTeam.name} karşısında alınan ${userGoals}-${oppGoals}'lik galibiyet kulübümüzde harika bir hava yarattı. Oyuncularımızın taktiksel disiplini ve sahadaki mücadele hırsı 3 puanı getiren en önemli faktörler oldu.\n\nÖzellikle hücum varyasyonlarımız rakip savunmayı zorladı. Tebrikler!`;
      }
    } else if (isDraw) {
      const drawTitles = [
        `🤝 PUANLAR PAYLAŞILDI: ${currentTeam.name} ${userGoals}-${oppGoals} ${opponentTeam.name}`,
        `⚖️ SERT MÜCADELEDE BERABERLİK: ${userGoals}-${oppGoals}`,
        `⚔️ ZORLU KARŞILAŞMADA 1 PUAN HANEMİZE YAZILDI`
      ];
      resultMsgSubject = drawTitles[Math.floor(Math.random() * drawTitles.length)];
      resultMsgContent = `Sayın Hocam,\n\n${currentWeek}. Hafta karşılaşmasında ${opponentTeam.name} ile başa baş geçen 90 dakika ${userGoals}-${oppGoals} beraberlikle tamamlandı. İki tarafın da galibiyeti kovaladığı maçta sahadan 1 puanla ayrıldık.\n\nLig maratonunda deplasman/saha puanlarının önemi büyük. Önümüzdeki maça odaklanıyoruz.`;
    } else {
      const lossTitles = [
        `💔 MAÇ SONUCU: ${currentTeam.name} ${userGoals}-${oppGoals} ${opponentTeam.name}`,
        `⚠️ ŞOK MAĞLUBİYET: Puan Kaybı Yaşandı (${userGoals}-${oppGoals})`,
        `📉 KRİTİK PUAN KAYBI: ${currentTeam.name} ${userGoals}-${oppGoals} ${opponentTeam.name}`
      ];
      resultMsgSubject = lossTitles[Math.floor(Math.random() * lossTitles.length)];
      resultMsgContent = `Sayın Menajerim,\n\n${currentWeek}. Haftada ${opponentTeam.name} karşısında sahadan ${userGoals}-${oppGoals}'lik mağlubiyetle ayrıldık. Yapılan basit savunma hataları ve değerlendirilemeyen gol fırsatları skora olumsuz yansıdı.\n\nTeknik heyetimizin önümüzdeki antrenmanlarda eksikleri gidermek üzere özel çalışma programı hazırlaması bekleniyor. Moral bozmadan çalışacağız.`;
    }

    // Build realistic scorers list safely
    const matchScorers: MatchReportScorer[] = [];
    
    if (simMatchEvents && simMatchEvents.length > 0) {
      simMatchEvents
        .filter(e => e.type === 'GOAL' || e.isPenaltyMissed || (e.text && e.text.includes('PENALTI KAÇTI')))
        .forEach(e => {
          const isHomeEvent = e.teamId ? (e.teamId === currentWeekFixture?.homeTeamId) : !!e.isHomeTeamEvent;
          const scoringTeamName = isHomeEvent ? (currentWeekFixture?.homeTeamId === currentTeam.id ? currentTeam.name : opponentTeam.name) : (currentWeekFixture?.homeTeamId === currentTeam.id ? opponentTeam.name : currentTeam.name);
          const isPen = !!e.isPenalty || e.text.includes('PENALTI GOLÜ') || e.text.includes('penaltı noktasından');
          const isPenMissed = !!e.isPenaltyMissed || e.text.includes('PENALTI KAÇTI');
          matchScorers.push({
            minute: e.minute,
            player: e.playerName || 'Oyuncu',
            name: e.playerName || 'Oyuncu',
            scorerId: e.scorerId || e.playerId,
            assistantName: e.assistantName,
            assistantId: e.assistantId,
            team: scoringTeamName,
            isPenalty: isPen,
            isPenaltyMissed: isPenMissed
          });
        });
    }

    if (matchScorers.length === 0 && (userGoals > 0 || oppGoals > 0)) {
      const userRatingMap: Record<string, { goals: number; assists: number; rating: number }> = { ...playerStatsMap };
      if (Array.isArray(userPlayerRatings)) {
        userPlayerRatings.forEach(pr => {
          userRatingMap[pr.playerId] = {
            goals: pr.goals,
            assists: pr.assists,
            rating: pr.rating
          };
        });
      }

      const userScorerPool: string[] = [];
      Object.entries(userRatingMap)
        .filter(([pid, stats]) => (stats.goals || 0) > 0 && currentTeam.players.some(p => p.id === pid))
        .forEach(([pid, stats]) => {
          const playerObj = currentTeam.players.find(p => p.id === pid);
          const pName = playerObj?.name || 'Oyuncu';
          for (let g = 0; g < (stats.goals || 1); g++) {
            userScorerPool.push(pName);
          }
        });

      while (userScorerPool.length < userGoals) {
        const fwMid = currentTeam.players.filter(p => p.position === 'FW' || p.position === 'MID' || p.isStarting);
        const randP = fwMid[Math.floor(Math.random() * fwMid.length)] || currentTeam.players[0];
        userScorerPool.push(randP.name);
      }

      const oppScorerPool: string[] = [];
      const oppAttackers = opponentTeam.players.filter(p => p.position === 'FW' || p.position === 'MID');
      for (let i = 0; i < oppGoals; i++) {
        const oppP = oppAttackers[Math.floor(Math.random() * (oppAttackers.length || 1))] || opponentTeam.players[0];
        oppScorerPool.push(oppP?.name || 'Rakip Forvet');
      }

      userScorerPool.slice(0, userGoals).forEach((pName, i) => {
        const minute = Math.min(90, Math.max(4, Math.floor(Math.random() * 80) + 6 + i * 4));
        matchScorers.push({
          minute,
          player: pName,
          team: currentTeam.name
        });
      });

      oppScorerPool.slice(0, oppGoals).forEach((pName, i) => {
        const minute = Math.min(90, Math.max(7, Math.floor(Math.random() * 80) + 8 + i * 4));
        matchScorers.push({
          minute,
          player: pName,
          team: opponentTeam.name
        });
      });
    }

    matchScorers.sort((a, b) => a.minute - b.minute);

    const homeTeamInfo = isUserHome ? currentTeam : opponentTeam;
    const awayTeamInfo = isUserHome ? opponentTeam : currentTeam;
    const homeGoalsCount = isUserHome ? userGoals : oppGoals;
    const awayGoalsCount = isUserHome ? oppGoals : userGoals;

    const userRatingMapFinal: Record<string, { goals: number; assists: number; rating: number }> = { ...playerStatsMap };
    if (Array.isArray(userPlayerRatings)) {
      userPlayerRatings.forEach(pr => {
        userRatingMapFinal[pr.playerId] = {
          goals: pr.goals,
          assists: pr.assists,
          rating: pr.rating
        };
      });
    }

    const allMatchRatings: { playerId: string; name: string; teamName: string; rating: number; goals: number; assists: number }[] = [];

    if (Array.isArray(userPlayerRatings) && userPlayerRatings.length > 0) {
      userPlayerRatings.forEach(pr => {
        const isCurrent = currentTeam.players.some(p => p.id === pr.playerId || p.name === pr.playerName);
        const tName = pr.teamId === currentTeam.id || isCurrent ? currentTeam.name : opponentTeam.name;
        allMatchRatings.push({
          playerId: pr.playerId,
          name: pr.playerName,
          teamName: tName,
          rating: pr.rating,
          goals: pr.goals || 0,
          assists: pr.assists || 0
        });
      });
    } else {
      // Fallback if no ratings array passed
      currentTeam.players.filter(p => p.isStarting).forEach(p => {
        const pGoals = matchScorers.filter(s => s.player === p.name && s.team === currentTeam.name).length;
        const calcR = Math.min(9.8, Math.max(5.2, Number(((userRatingMapFinal[p.id]?.rating || 6.6) + (isWin ? 0.7 : isDraw ? 0.1 : -0.5) + pGoals * 1.2).toFixed(1))));
        allMatchRatings.push({
          playerId: p.id,
          name: p.name,
          teamName: currentTeam.name,
          rating: calcR,
          goals: pGoals,
          assists: 0
        });
      });
      opponentTeam.players.filter(p => p.isStarting).forEach(p => {
        const pGoals = matchScorers.filter(s => s.player === p.name && s.team === opponentTeam.name).length;
        const calcR = Math.min(9.8, Math.max(5.0, Number((6.5 + (!isWin && !isDraw ? 0.7 : isDraw ? 0.1 : -0.5) + pGoals * 1.2).toFixed(1))));
        allMatchRatings.push({
          playerId: p.id,
          name: p.name,
          teamName: opponentTeam.name,
          rating: calcR,
          goals: pGoals,
          assists: 0
        });
      });
    }

    // Sort descending strictly by match performance rating & goals
    allMatchRatings.sort((a, b) => {
      if (Math.abs(b.rating - a.rating) > 0.05) {
        return b.rating - a.rating;
      }
      return (b.goals || 0) - (a.goals || 0);
    });

    const motm = allMatchRatings[0] || {
      name: matchScorers[0]?.player || currentTeam.players[0]?.name || 'Maçın Yıldızı',
      teamName: matchScorers[0]?.team || currentTeam.name,
      rating: 8.5,
      goals: matchScorers.length > 0 ? 1 : 0,
      assists: 0
    };

    const standoutList = allMatchRatings.slice(0, 4).map(p => ({
      name: p.name,
      teamName: p.teamName,
      rating: p.rating
    }));

    // Extract and format match cards (Yellow / Red)
    const matchCards: { name: string; teamName: string; type: 'YELLOW' | 'RED'; minute: number; playerId?: string }[] = [];
    if (simMatchEvents && simMatchEvents.length > 0) {
      simMatchEvents
        .filter(e => e.type === 'YELLOW_CARD' || e.type === 'RED_CARD')
        .forEach(e => {
          const isHomeEvent = e.teamId ? (e.teamId === currentWeekFixture?.homeTeamId) : !!e.isHomeTeamEvent;
          const cardTeamName = isHomeEvent ? (currentWeekFixture?.homeTeamId === currentTeam.id ? currentTeam.name : opponentTeam.name) : (currentWeekFixture?.homeTeamId === currentTeam.id ? opponentTeam.name : currentTeam.name);
          matchCards.push({
            name: e.playerName || 'Oyuncu',
            teamName: cardTeamName,
            type: e.type === 'RED_CARD' ? 'RED' : 'YELLOW',
            minute: e.minute,
            playerId: (e as any).playerId
          });
        });
    }

    matchCards.sort((a, b) => a.minute - b.minute);

    const matchReportPayload: MatchReportData = {
      homeTeam: {
        id: homeTeamInfo.id,
        name: homeTeamInfo.name,
        shortName: homeTeamInfo.shortName,
        badgeColor: homeTeamInfo.badgeColor
      },
      awayTeam: {
        id: awayTeamInfo.id,
        name: awayTeamInfo.name,
        shortName: awayTeamInfo.shortName,
        badgeColor: awayTeamInfo.badgeColor
      },
      homeScore: homeGoalsCount,
      awayScore: awayGoalsCount,
      scorers: matchScorers,
      cards: matchCards,
      playerRatings: allMatchRatings,
      motm: motm ? {
        name: motm.name,
        rating: motm.rating,
        teamName: motm.teamName,
        goals: motm.goals,
        assists: motm.assists
      } : undefined,
      standoutPlayers: standoutList,
      stats: simMatchStats ? {
        possessionHome: simMatchStats.possessionHome,
        possessionAway: simMatchStats.possessionAway,
        shotsHome: simMatchStats.shotsHome,
        shotsAway: simMatchStats.shotsAway,
        shotsOnTargetHome: simMatchStats.shotsOnTargetHome,
        shotsOnTargetAway: simMatchStats.shotsOnTargetAway,
        cornersHome: simMatchStats.cornersHome,
        cornersAway: simMatchStats.cornersAway,
        foulsHome: simMatchStats.foulsHome,
        foulsAway: simMatchStats.foulsAway,
        savesHome: simMatchStats.savesHome,
        savesAway: simMatchStats.savesAway,
        passAccuracyHome: simMatchStats.passAccuracyHome,
        passAccuracyAway: simMatchStats.passAccuracyAway,
        yellowCardsHome: simMatchStats.yellowCardsHome,
        yellowCardsAway: simMatchStats.yellowCardsAway,
        xGHome: simMatchStats.xGHome,
        xGAway: simMatchStats.xGAway
      } : {
        possessionHome: isUserHome ? (isWin ? 57 : isDraw ? 50 : 45) : (isWin ? 43 : isDraw ? 50 : 55),
        possessionAway: isUserHome ? (isWin ? 43 : isDraw ? 50 : 55) : (isWin ? 57 : isDraw ? 50 : 45),
        shotsHome: Math.floor((homeGoalsCount * 2.5) + 6 + Math.random() * 3),
        shotsAway: Math.floor((awayGoalsCount * 2.5) + 5 + Math.random() * 3),
        shotsOnTargetHome: homeGoalsCount + Math.floor(Math.random() * 3) + 2,
        shotsOnTargetAway: awayGoalsCount + Math.floor(Math.random() * 3) + 2,
        cornersHome: Math.floor(Math.random() * 5) + 3,
        cornersAway: Math.floor(Math.random() * 5) + 3,
        foulsHome: Math.floor(Math.random() * 6) + 8,
        foulsAway: Math.floor(Math.random() * 6) + 8
      }
    };

    setLastMatchForMediaReview(matchReportPayload);

    const matchResultInboxMsg: InboxMessage = {
      id: `match-res-${Date.now()}-${Math.random()}`,
      date: matchDateStr,
      sender: 'Maç & Analiz Servisi',
      senderName: 'Süper Lig Analiz Kurulu',
      senderRole: 'Baş Analist',
      senderKey: 'INBOX_SENDER_TECHNICAL_STAFF',
      subject: resultMsgSubject,
      subjectKey: isWin ? 'INBOX_MSG_VICTORY_SUBJECT' : isDraw ? 'INBOX_MSG_DRAW_SUBJECT' : 'INBOX_MSG_DEFEAT_SUBJECT',
      subjectParams: {
        userGoals,
        oppGoals,
        opponent: opponentTeam.name,
        week: currentWeek
      },
      content: resultMsgContent,
      contentKey: isWin ? 'INBOX_MSG_VICTORY_CONTENT' : isDraw ? 'INBOX_MSG_DRAW_CONTENT' : 'INBOX_MSG_DEFEAT_CONTENT',
      contentParams: {
        userGoals,
        oppGoals,
        opponent: opponentTeam.name,
        week: currentWeek
      },
      isRead: false,
      tag: 'MAÇ_SONUCU',
      category: 'MATCH_REPORT',
      matchReport: matchReportPayload
    };

    // 4. Update Stamina, Stats, Unhappiness & Injury Days for all players
    const newInboxMsgs: InboxMessage[] = [matchResultInboxMsg];

    // Championship Guarantee Check
    const calcMaxWeeks = (allTeams.length - 1) * 2;
    const remainingWeeks = Math.max(0, calcMaxWeeks - currentWeek);
    const sortedStandingsForChamp = [...standings].sort((a, b) => b.points - a.points);
    const leader = sortedStandingsForChamp[0];
    const runnerUp = sortedStandingsForChamp[1];

    if (leader && runnerUp && leader.teamId === currentTeam.id) {
      const pointsLead = leader.points - runnerUp.points;
      const isGuaranteed = pointsLead > (remainingWeeks * 3) || (remainingWeeks === 0 && leader.teamId === currentTeam.id);

      if (isGuaranteed && !hasCelebratedChampionship) {
        setHasCelebratedChampionship(true);

        // Increment total trophies in main menu user profile
        const currentTrophies = parseInt(localStorage.getItem('fm_total_trophies') || '0', 10);
        localStorage.setItem('fm_total_trophies', (currentTrophies + 1).toString());

        try {
          confetti({
            particleCount: 150,
            spread: 90,
            origin: { y: 0.5 }
          });
        } catch (e) {
          console.log('Confetti trigger', e);
        }

        newInboxMsgs.push(
          {
            id: `champ-1-${Date.now()}`,
            date: matchDateStr,
            sender: 'Kulüp Yönetim Kurulu',
            senderName: 'Yönetim Kurulu Başkanı',
            senderRole: 'Başkan',
            subject: `🏆 ŞAMPİYONLUK GARANTİLENDİ! ${currentTeam.name} ŞAMPİYON!`,
            content: `Sayın Menajerim ${manager.name},\n\nSÜPER LİG ŞAMPİYONLUĞUMUZ MATEMATİKSEL OLARAK GARANTİLENDİ! Kulüp Yönetim Kurulu olarak sizi, teknik heyetinizi ve sahadaki tüm oyuncularımızı tebrik ediyoruz.\n\nKulüp müzemize getirdiğiniz bu tarihi kupa için camiamız ve taraftarlarımız size minnettardır! Bravo Hocam!`,
            isRead: false,
            tag: 'YÖNETİM',
            category: 'NEWS'
          },
          {
            id: `champ-2-${Date.now()}`,
            date: matchDateStr,
            sender: 'Taraftar Derneği & Çarşı Grubu',
            senderName: 'Taraftar Birliği',
            senderRole: 'Tribün Liderleri',
            subject: `🔥 TARAFTARLARDAN SOKAKLARDA COŞKULU ŞAMPİYONLUK KUTLAMASI!`,
            content: `ŞEHİR MEYDANLARINDA ŞAMPİYONLUK COŞKUSU!\n\nBinlerce meşale, coşkulu marşlar ve davullar eşliğinde tüm sokaklar bayraklarla donatıldı! Taraftarlar tesislerin önüne akın ederek "${manager.name}" tezahüratları haykırıyor! Teşekkürler Hocam!`,
            isRead: false,
            tag: 'MEDYA',
            category: 'NEWS'
          },
          {
            id: `champ-3-${Date.now()}`,
            date: matchDateStr,
            sender: 'Büyükşehir Belediye Başkanlığı',
            senderName: 'Şehir Yönetimi',
            senderRole: 'Belediye Başkanı',
            subject: `🏙️ BELEDİYE BAŞKANINDAN ŞAMPİYONLUK TEBRİK BİLDİRİMİ`,
            content: `Şehrimizin gururu ${currentTeam.name}'in kazandığı tarihi şampiyonluğu coşkuyla kutluyoruz! Şehir meydanında dev şampiyonluk sahnesi kurulmaktadır. Tüm teknik ekibimize teşekkür ederiz.`,
            isRead: false,
            tag: 'YÖNETİM',
            category: 'NEWS'
          }
        );
      }
    }

    setAllTeams((prev) =>
      prev.map((t) => {
        const isUserTeam = t.id === currentTeam.id;

        const updatedPlayers = t.players.map((p) => {
          let newStamina = p.stamina;
          let newAppearances = p.appearances || 0;
          let newUnplayedStreak = p.unplayedStreak || 0;
          let newUnhappyStatus = p.unhappyStatus;
          let isListed = p.isListedForTransfer;

          if (p.isStarting) {
            newStamina = calculatePostMatchStamina(p);
            newAppearances += 1;
            newUnplayedStreak = 0;
            if (newUnhappyStatus === 'UNHAPPY_BENCH') {
              newUnhappyStatus = undefined;
            }
          } else {
            // Bench recovers stamina gradually
            newStamina = Math.min(100, p.stamina + 25);

            if (isUserTeam) {
              newUnplayedStreak += 1;
              if (newUnplayedStreak === 3) {
                newUnhappyStatus = 'UNHAPPY_BENCH';
                const complaintVariations = [
                  `Sayın Hocam, son 3 maçtır forma şansı bulamıyorum. Takıma katkı sağlamak istiyorum, lütfen ilk 11'de yer verin.`,
                  `Teknik Direktörüm, yedek kulübesinde beklemek beni yıpratıyor. Formumu koruyabilmem için oynamaya ihtiyacım var.`,
                  `Hocam, kadro seçimlerinizde bana yer vermemeniz moralimi bozuyor. Sahada kendimi kanıtlamak istiyorum.`
                ];
                const selectedComplaint = complaintVariations[Math.floor(Math.random() * complaintVariations.length)];

                newInboxMsgs.push({
                  id: `unhappy-${p.id}-${Date.now()}`,
                  date: matchDateStr,
                  sender: p.name,
                  senderName: p.name,
                  senderRole: `Futbolcu (${p.position})`,
                  subject: `⚠️ Forma Şansı Şikayeti: ${p.name}`,
                  content: selectedComplaint,
                  isRead: false,
                  tag: 'TAKTIK',
                  category: 'COMPLAINT',
                  actionData: { player: p, sellerTeam: currentTeam }
                });
              } else if (newUnplayedStreak >= 5 && !isListed) {
                newUnhappyStatus = 'TRANSFER_REQUESTED';
                isListed = true;

                newInboxMsgs.push({
                  id: `transfer-req-${p.id}-${Date.now()}`,
                  date: matchDateStr,
                  sender: p.name,
                  senderName: p.name,
                  senderRole: `Futbolcu (${p.position})`,
                  subject: `🚨 TRANSFER TALEBİ: ${p.name}`,
                  content: `Sayın Hocam, üst üste 5 maçtır süre alamadığım için takımdan ayrılmak istiyorum. Lütfen beni transfer listesine koyun ve gelen teklifleri değerlendirin.`,
                  isRead: false,
                  tag: 'TRANSFER',
                  category: 'COMPLAINT',
                  actionData: { player: p, sellerTeam: currentTeam }
                });
              }
            }
          }

          // Realistic Potential & Age-Based Training Growth / Degradation & Heavy Training Injury Calculation
          const isVeteran = p.age >= 32;
          const isDeclining = p.age >= 33;
          const potentialCeiling = p.potential || (
            p.age <= 19 ? Math.min(99, p.overall + 10) :
            p.age <= 22 ? Math.min(99, p.overall + 7) :
            p.age <= 25 ? Math.min(99, p.overall + 4) :
            p.age <= 28 ? Math.min(99, p.overall + 2) :
            p.overall
          );
          const potentialHeadroom = Math.max(0, potentialCeiling - p.overall);

          let growthInc = 0;
          if (p.age <= 20) {
            // Young wonderkids develop depending on remaining potential headroom
            growthInc = potentialHeadroom > 0 ? (2 + Math.min(4, Math.round(potentialHeadroom * 0.35))) : 1;
          } else if (p.age <= 24) {
            // Young pros developing steadily
            growthInc = potentialHeadroom > 0 ? (1 + Math.min(3, Math.round(potentialHeadroom * 0.25))) : 1;
          } else if (p.age <= 28) {
            // Prime players developing slowly if headroom remains
            growthInc = potentialHeadroom > 0 ? 1 : 0;
          } else if (p.age <= 32) {
            // Plateau / stability
            growthInc = 0;
          } else {
            // Veterans 33+: gradual physical degradation cycle
            growthInc = p.age >= 36 ? 4 : p.age >= 34 ? 3 : 2;
          }

          // Match performance bonus if young player performed well
          const pStatItem = playerStatsMap[p.id];
          if (p.isStarting && pStatItem && pStatItem.rating >= 7.5 && p.age <= 24 && potentialHeadroom > 0) {
            growthInc += 1;
          }

          let justInjured = false;
          let addedInjuryWeeks = 0;
          let injuryCause = '';

          // Accurate, balanced injury model: Low general frequency, progressive by age, multiplied by training intensity
          if (!p.isInjured) {
            // 1. Base age risk per week (Realistic low thresholds)
            let baseAgeRisk = 0.002; // Gençler (<=24 yaş): %0.2 çok düşük / nadir
            if (p.age >= 36) {
              baseAgeRisk = 0.055; // 36+ yaş: %5.5
            } else if (p.age >= 34) {
              baseAgeRisk = 0.040; // 34-35 yaş: %4.0
            } else if (p.age >= 32) {
              baseAgeRisk = 0.030; // 32-33 yaş: %3.0
            } else if (p.age >= 30) {
              baseAgeRisk = 0.020; // 30-31 yaş: %2.0
            } else if (p.age >= 27) {
              baseAgeRisk = 0.008; // 27-29 yaş: %0.8
            } else if (p.age >= 24) {
              baseAgeRisk = 0.004; // 24-26 yaş: %0.4
            }

            // 2. Training intensity multiplier
            let intensityMultiplier = 1.0;
            if (p.trainingIntensity === 'Ağır') {
              growthInc = Math.round(growthInc * 1.3);
              newStamina = Math.max(10, newStamina - 4); // 4% extra stamina penalty
              intensityMultiplier = 3.8; // Heavy training significantly boosts injury risk
            } else if (p.trainingIntensity === 'Hafif') {
              growthInc = Math.max(0, Math.round(growthInc * 0.7));
              intensityMultiplier = 0.15; // Light training has almost zero injury risk
            }

            // 3. Stamina exhaustion multiplier (<60% stamina increases risk)
            const staminaMultiplier = (p.stamina < 50) ? 2.2 : (p.stamina < 70) ? 1.5 : 1.0;

            const finalWeeklyInjuryProbability = baseAgeRisk * intensityMultiplier * staminaMultiplier;

            if (Math.random() < finalWeeklyInjuryProbability) {
              justInjured = true;
              if (p.age >= 33) {
                addedInjuryWeeks = Math.floor(Math.random() * 3) + 2; // 2-4 weeks for veterans
              } else if (p.age >= 28) {
                addedInjuryWeeks = Math.floor(Math.random() * 2) + 1; // 1-2 weeks
              } else {
                addedInjuryWeeks = Math.floor(Math.random() * 2) + 1; // 1-2 weeks for young
              }
              injuryCause = p.trainingIntensity === 'Ağır' ? 'Ağır Antrenman Yüklenmesi' : 'Kas Yorgunluğu & Zorlanma';
            }
          }

          let newProgress = (p.growthProgress || 0) + growthInc;
          let updatedAttrs = { ...p.attributes };
          let newOverall = p.overall;
          let newMarketValue = p.marketValue;

          if (newProgress >= 100) {
            newProgress = newProgress - 100;

            if (isDeclining) {
              // 33+ Age Degradation: Physical traits decline first, then technical
              if (updatedAttrs.pace > 35 && (Math.random() < 0.6 || updatedAttrs.physical <= 35)) {
                updatedAttrs.pace = Math.max(35, updatedAttrs.pace - 1);
              } else if (updatedAttrs.physical > 35 && Math.random() < 0.6) {
                updatedAttrs.physical = Math.max(35, updatedAttrs.physical - 1);
              } else if (updatedAttrs.shooting > 35 && Math.random() < 0.5) {
                updatedAttrs.shooting = Math.max(35, updatedAttrs.shooting - 1);
              } else if (updatedAttrs.passing > 35 && Math.random() < 0.5) {
                updatedAttrs.passing = Math.max(35, updatedAttrs.passing - 1);
              } else if (updatedAttrs.defending > 35) {
                updatedAttrs.defending = Math.max(35, updatedAttrs.defending - 1);
              }

              newOverall = Math.max(45, Math.round((updatedAttrs.pace + updatedAttrs.shooting + updatedAttrs.passing + updatedAttrs.defending + updatedAttrs.physical) / 5));
              newMarketValue = Math.max(100000, Math.round((p.marketValue || 1000000) * 0.96));
            } else if (potentialHeadroom > 0 || p.overall < potentialCeiling) {
              // Young / Prime Player Attribute Growth aligned with training focus
              const focus = p.trainingFocus || 'Genel';
              if (focus === 'Hücum') {
                updatedAttrs.shooting = Math.min(potentialCeiling, updatedAttrs.shooting + 1);
              } else if (focus === 'Pas') {
                updatedAttrs.passing = Math.min(potentialCeiling, updatedAttrs.passing + 1);
              } else if (focus === 'Defans') {
                updatedAttrs.defending = Math.min(potentialCeiling, updatedAttrs.defending + 1);
              } else if (focus === 'Fizik') {
                updatedAttrs.physical = Math.min(potentialCeiling, updatedAttrs.physical + 1);
              } else {
                updatedAttrs.pace = Math.min(potentialCeiling, updatedAttrs.pace + 1);
              }
              newOverall = Math.min(potentialCeiling, Math.round((updatedAttrs.pace + updatedAttrs.shooting + updatedAttrs.passing + updatedAttrs.defending + updatedAttrs.physical) / 5));
              if (newOverall > p.overall) {
                newMarketValue = Math.round((p.marketValue || 1000000) * 1.12);
              }
            }
          }

          // Injury recovery week reduction + new heavy training injury
          const newInjuryWeeks = p.injuryWeeksLeft ? Math.max(0, p.injuryWeeksLeft - 1) : 0;
          const finalInjuryWeeks = justInjured ? (newInjuryWeeks + addedInjuryWeeks) : newInjuryWeeks;

          if (justInjured) {
            showToast(
              'error',
              '🚨 Ağır Antrenman Sakatlığı!',
              `${p.name} (${p.age} yaş) ağır antrenman yüküne dayanamayarak ${addedInjuryWeeks} hafta sakatlandı!`
            );
          }

          // Suspension / Disciplinary handling
          let isStillSuspended = p.isSuspended;
          let suspensionMatches = p.suspensionMatchesLeft || 0;
          let suspReason = p.suspensionReason;

          // If the player was suspended entering this match, decrement suspension matches left
          if (isStillSuspended && suspensionMatches > 0) {
            suspensionMatches -= 1;
            if (suspensionMatches <= 0) {
              isStillSuspended = false;
              suspReason = undefined;
            }
          }

          // Count cards received in this match
          const matchYellows = matchCards.filter(c => (c.playerId ? c.playerId === p.id : c.name === p.name) && c.type === 'YELLOW').length;
          const matchReds = matchCards.filter(c => (c.playerId ? c.playerId === p.id : c.name === p.name) && c.type === 'RED').length;
          const prevYellows = p.yellowCards || 0;
          const newYellowCards = prevYellows + matchYellows;
          const newRedCards = (p.redCards || 0) + matchReds;

          // Check for new suspensions from this match
          if (matchReds > 0) {
            isStillSuspended = true;
            suspensionMatches = 1;
            suspReason = 'Kırmızı Kart Cezası (1 Maç Men)';
            if (isUserTeam) {
              newInboxMsgs.push({
                id: `susp-red-${p.id}-${Date.now()}`,
                date: matchDateStr,
                sender: 'TFF Disiplin Kurulu (PFDK)',
                senderName: 'TFF Hukuk Müşavirliği',
                senderRole: 'Disiplin Müfettişi',
                subject: `🚨 DİSİPLİN CEZASI: ${p.name} Kırmızı Kart Nedeniyle 1 Maç Cezalı!`,
                content: `Sayın Menajerim,\n\n${currentWeek}. Hafta müsabakasında doğrudan/çift sarıdan kırmızı kart gören futbolcumuz ${p.name}, Profesyonel Futbol Disiplin Kurulu (PFDK) talimatları uyarınca 1 resmi müsabakadan men cezası almıştır.\n\nOyuncumuz bir sonraki lig maçında kadroya alınamayacaktır. Bilgilerinize rica olunur.`,
                isRead: false,
                tag: 'YÖNETİM',
                category: 'NEWS'
              });
            }
          } else if (Math.floor(newYellowCards / 4) > Math.floor(prevYellows / 4)) {
            isStillSuspended = true;
            suspensionMatches = 1;
            suspReason = `Sarı Kart Sınırı Cezası (${newYellowCards}. Sarı Kart - 1 Maç Men)`;
            if (isUserTeam) {
              newInboxMsgs.push({
                id: `susp-yellow-${p.id}-${Date.now()}`,
                date: matchDateStr,
                sender: 'TFF Disiplin Kurulu (PFDK)',
                senderName: 'TFF Hukuk Müşavirliği',
                senderRole: 'Disiplin Müfettişi',
                subject: `⚠️ SARI KART CEZASI: ${p.name} 4 Sarı Karta Ulaşarak Cezalı Duruma Düştü!`,
                content: `Sayın Menajerim,\n\nFutbolcumuz ${p.name}, lig müsabakalarında toplam ${newYellowCards} sarı karta ulaşarak sarı kart ceza sınırını doldurmuştur. Talimatlar gereği oyuncumuz 1 resmi lig maçında cezalı duruma düşmüştür.\n\nBir sonraki hafta forma giyemeyecektir.`,
                isRead: false,
                tag: 'YÖNETİM',
                category: 'NEWS'
              });
            }
          }

          const pStat = playerStatsMap[p.id];
          const newGoalsScored = (p.goalsScored || 0) + (pStat?.goals || 0);
          const newAssists = (p.assists || 0) + (pStat?.assists || 0);
          const newLastRating = pStat?.rating || p.lastRating || p.form || 7.0;

          return {
            ...p,
            stamina: newStamina,
            appearances: newAppearances,
            unplayedStreak: newUnplayedStreak,
            unhappyStatus: newUnhappyStatus,
            isListedForTransfer: isListed,
            growthProgress: newProgress,
            attributes: updatedAttrs,
            overall: newOverall,
            marketValue: newMarketValue,
            isInjured: finalInjuryWeeks > 0,
            injuryWeeksLeft: finalInjuryWeeks,
            yellowCards: newYellowCards,
            redCards: newRedCards,
            isSuspended: isStillSuspended,
            suspensionMatchesLeft: suspensionMatches,
            suspensionReason: suspReason,
            goalsScored: newGoalsScored,
            assists: newAssists,
            lastRating: newLastRating
          };
        });

        // Add prize money to user team
        const newBudget = t.id === currentTeam.id ? t.budget + prizeMoney : t.budget;

        return { ...t, players: updatedPlayers, budget: newBudget };
      })
    );

    // Refresh promising talents report every 2 weeks into inbox with continuous variety and peak scouted OVR
    if (currentWeek % 2 === 0) {
      const allYoungTalents: { player: Player; teamName: string; teamObj?: Team }[] = [];
      
      // Collect from domestic teams
      allTeams.forEach(t => {
        t.players.forEach(p => {
          if (p.age <= 21 && (p.potential || p.overall) >= 70 && t.id !== currentTeam.id) {
            allYoungTalents.push({ player: p, teamName: t.name, teamObj: t });
          }
        });
      });

      // Collect from international wonderkid pool
      INTERNATIONAL_TEAMS.forEach(it => {
        it.players.forEach(p => {
          if (p.age <= 21 && (p.potential || p.overall) >= 72) {
            allYoungTalents.push({ player: p, teamName: `${it.name} (${it.flag})` });
          }
        });
      });

      // Deterministic pseudo-random rotation cycle based on currentWeek & season to guarantee diverse talents every cycle
      const cycleOffset = ((currentWeek / 2) * 3) % Math.max(1, allYoungTalents.length);
      const rotatedPool = [
        ...allYoungTalents.slice(cycleOffset),
        ...allYoungTalents.slice(0, cycleOffset)
      ];
      
      // Pick 3 diverse talents (from different positions if possible)
      const selectedTalents: { player: Player; teamName: string; teamObj?: Team }[] = [];
      const usedPos = new Set<string>();

      for (const item of rotatedPool) {
        if (selectedTalents.length >= 3) break;
        if (!usedPos.has(item.player.position) || selectedTalents.length >= 2) {
          selectedTalents.push(item);
          usedPos.add(item.player.position);
        }
      }

      if (selectedTalents.length > 0) {
        const TRAIT_DESCRIPTIONS = [
          'Özel bitiricilik, ceza sahası içi soğukkanlılığı ve keskin gol vuruşlarıyla ön plana çıkıyor.',
          'Dar alanda milimetrik pas trafiği, yüksek oyun zekası ve pres kırma yeteneğiyle dikkat çekiyor.',
          'Patlayıcı ivmelenmesi, yüksek dripling kabiliyeti ve kanatlardaki dikine oyunuyla rakip savunmaları zorluyor.',
          'Duran toplarda, ceza sahası dışından falsolu şutlarda ve kilit paslarda üstün bir tekniğe sahip.',
          'Hava toplarındaki mutlak hakimiyeti, fiziksel direnci ve ikili mücadelelerdeki başarısıyla geleceğin yıldız adayı.',
          'Mükemmel saha görüşü, derinlemesine ara pas yeteneği ve tempoyu dikte etme becerisi sergiliyor.',
          'Bire bir savunmada agresif müdahaleleri, kademe sezgisi ve pozisyon bilgisiyle güven veriyor.'
        ];

        const talentLines = selectedTalents.map((st, i) => {
          const trait = TRAIT_DESCRIPTIONS[(st.player.name.length + currentWeek * 3 + i) % TRAIT_DESCRIPTIONS.length];
          // Calculate peak reachable OVR when scouted/developed to max capacity
          const basePeak = st.player.potential || Math.min(99, st.player.overall + (st.player.age <= 18 ? 14 : st.player.age <= 19 ? 11 : st.player.age <= 20 ? 8 : 5));
          const maxPeakOvr = Math.min(99, Math.max(basePeak, st.player.overall + 4));

          return `⭐ ${st.player.name} (${st.player.position} - ${st.player.age} Yaş, ${st.teamName})\n   ↳ İzlendiğinde Ulaşabileceği En Yüksek OVR: ${maxPeakOvr} OVR\n   💡 Scout Raporu: ${trait}`;
        }).join('\n\n');

        newInboxMsgs.push({
          id: `promising-talents-${currentWeek}-${Date.now()}`,
          date: matchDateStr,
          sender: 'Gözlemci Ekibi (Scout Departmanı)',
          senderName: 'Gözlemci Ekibi (Scout)',
          senderRole: 'Baş Gözlemci',
          subject: `⭐ Gelecek Vadeden Genç Yetenekler (${currentWeek}. Hafta Raporu)`,
          content: `Sayın Hocam,\n\nScout ekibimizin son 2 haftalık lig ve uluslararası tarama raporları neticesinde potansiyeli en yüksek genç yetenekler listelenmiştir:\n\n${talentLines}\n\nBu genç yıldız adaylarını detaylı incelemek ve kulübümüze kazandırmak için isimlerine tıklayabilir veya gözlemci gönderebilirsiniz.`,
          isRead: false,
          tag: 'SCOUT',
          category: 'SCOUT_REPORT',
          actionData: {
            player: selectedTalents[0].player,
            sellerTeam: selectedTalents[0].teamObj
          }
        });
      }
    }

    if (newInboxMsgs.length > 0) {
      setInboxMessages(prev => [...newInboxMsgs, ...prev]);
    }

    // Increment condition restore cooldown (7 days per week)
    setDaysSinceLastConditionRestore((prev) => prev + 7);

    // 5. Advance Week and Reset Day
    setCurrentDayIndex(0);
    setHasUnreadNews(true);

    const maxSeasonWeeks = fixtures.length > 0 ? Math.max(...fixtures.map(f => f.week)) : 38;

    if (currentWeek < maxSeasonWeeks) {
      const nextW = currentWeek + 1;
      setCurrentWeek(nextW);
      triggerAutoSave(nextW, currentSeason);
    } else {
      // Season Finished - Continuous Progression to Next Season!
      const sortedStandings = [...standings].sort((a, b) => b.points - a.points || b.goalDifference - a.goalDifference);
      const champion = allTeams.find(t => t.id === sortedStandings[0]?.teamId);
      const userRank = sortedStandings.findIndex(s => s.teamId === currentTeam.id) + 1;

      // Increment total trophy count if user team won the championship
      if (champion?.id === currentTeam.id) {
        const curTrophies = parseInt(localStorage.getItem('fm_total_trophies') || '0', 10);
        localStorage.setItem('fm_total_trophies', (curTrophies + 1).toString());
      }

      const seasonPrizeMoney = Math.max(8_000_000, 35_000_000 - (userRank - 1) * 1_500_000);

      // Award prize money to user team
      setAllTeams(prev => prev.map(t => {
        if (t.id === currentTeam.id) {
          return { ...t, budget: t.budget + seasonPrizeMoney };
        }
        return t;
      }));

      // Send End of Season & Offseason Notifications
      const endSeasonInboxMsgs: InboxMessage[] = [
        {
          id: `season-end-${Date.now()}-1`,
          date: matchDateStr,
          sender: 'Türkiye Futbol Federasyonu',
          senderName: 'TFF Başkanlığı',
          senderRole: 'Lig Kurulu',
          subject: `🏆 ${currentSeason}. SEZON TAMAMLANDI: Şampiyon ${champion?.name || 'Süper Lig Şampiyonu'}!`,
          content: `Tebrikler Menajerim,\n\n${currentSeason}. Süper Lig sezonu resmen sona erdi! Takımınız ${currentTeam.name} ligi ${userRank}. sırada tamamladı. Kulüp kasasına lig derecesi ve yayın hakları geliri olarak €${(seasonPrizeMoney / 1_000_000).toFixed(1)}M ödül aktarıldı.\n\nYeni sezon çalışmaları başlamılmıştır.`,
          isRead: false,
          tag: 'YÖNETİM'
        },
        {
          id: `season-end-${Date.now()}-2`,
          date: matchDateStr,
          sender: 'Kulüp Sağlık & İdari Heyet',
          senderName: 'Futbol Direktörlüğü',
          senderRole: 'İdari Sorumlu',
          subject: `🏖️ YAZ TATİLİ & MİLLİ TAKIM KAMPLARI BAŞLADI (Yaz Dönemi)`,
          content: `Sayın Hocam,\n\nSezonun tamamlanmasıyla birlikte milli takıma davet edilen oyuncularımız ulusal kamplara katılmıştır. Diğer oyuncularımız ise yaz tatiline çıkarılmıştır.\n\nYaz transfer penceresi ve kiralama dönemi resmen açılmıştır! Kadronuzu yeni sezon öncesi güçlendirmek için transfer çalışmalarına başlayabilirsiniz.`,
          isRead: false,
          tag: 'YÖNETİM'
        },
        {
          id: `season-end-${Date.now()}-3`,
          date: matchDateStr,
          sender: 'Teknik Kadro',
          senderName: 'Kondisyon & Taktik Ekibi',
          senderRole: 'Yardımcı Antrenör',
          subject: `⚽ YENİ SEZON FİKSTÜRÜ & HAZIRLIK KAMPI PLANLANDI`,
          content: `Sayın Menajerim,\n\n${currentSeason + 1}. Sezon Süper Lig fikstürü çekildi! Sezon öncesi taktiksel uyumu artırmak ve oyuncu kondisyonlarını zirveye çıkarmak amacıyla 4 adet hazırlık maçı takvime eklendi.\n\nBaşarılar dileriz!`,
          isRead: false,
          tag: 'TAKTIK'
        }
      ];

      setInboxMessages(prev => [...endSeasonInboxMsgs, ...prev]);

      // Reset Standings and Schedule for New Season
      const resetTable = INITIAL_LEAGUE_TABLE.map(row => ({
        ...row,
        played: 0,
        won: 0,
        drawn: 0,
        lost: 0,
        goalsFor: 0,
        goalsAgainst: 0,
        goalDifference: 0,
        points: 0
      }));

      const nextSeason = currentSeason + 1;
      const newSchedule = generateLeagueSchedule(allTeams.map(t => t.id), currentTeam.id, nextSeason);
      setCurrentSeason(nextSeason);
      setCurrentWeek(1);
      setStandings(resetTable);
      setFixtures(newSchedule);

      triggerAutoSave(1, nextSeason, undefined, resetTable, newSchedule);

      showToast('success', `🏆 ${currentSeason}. SEZON TAMAMLANDI!`, `Ligi ${userRank}. sırada bitirdiniz. €${(seasonPrizeMoney / 1_000_000).toFixed(1)}M ödül bütçenize eklendi. ${currentSeason + 1}. Sezon başladı!`);
      confetti({ particleCount: 180, spread: 110, origin: { y: 0.5 } });
    }

    // Advance Scouting Progress (1 week = 7 days)
    processScoutingProgress(7);

    // Process pending transfer offers & arrivals (7 days pass)
    processPendingOffersAndArrivals(7, matchDateStr);

    showToast(
      'success',
      'Maç Tamamlandı ⚽',
      `${finalHomeScore} - ${finalAwayScore} sonucu işlendi. Bütçenize €${(prizeMoney / 1_000_000).toFixed(1)}M eklendi!`
    );
  };

  // Helper: Update standings row
  const updateTeamRow = (rows: LeagueRow[], teamId: string, goalsFor: number, goalsAgainst: number) => {
    return rows.map((r) => {
      if (r.teamId !== teamId) return r;

      const won = goalsFor > goalsAgainst ? r.won + 1 : r.won;
      const drawn = goalsFor === goalsAgainst ? r.drawn + 1 : r.drawn;
      const lost = goalsFor < goalsAgainst ? r.lost + 1 : r.lost;
      const points = r.points + (goalsFor > goalsAgainst ? 3 : goalsFor === goalsAgainst ? 1 : 0);
      const gf = r.goalsFor + goalsFor;
      const ga = r.goalsAgainst + goalsAgainst;

      return {
        ...r,
        played: r.played + 1,
        won,
        drawn,
        lost,
        goalsFor: gf,
        goalsAgainst: ga,
        goalDifference: gf - ga,
        points
      };
    });
  };

  const currentRank =
    [...standings]
      .sort((a, b) => b.points - a.points || b.goalDifference - a.goalDifference)
      .findIndex((s) => s.teamId === currentTeam.id) + 1;

  const currentTeamStanding = standings.find((s) => s.teamId === currentTeam.id);

  const processPendingOffersAndArrivals = (daysPassed: number, simDateStr: string) => {
    // 1. Process 1-day pending buy offer decisions
    setPendingBuyOffers((prevOffers) => {
      const remainingOffers: PendingBuyOffer[] = [];
      const generatedInboxMsgs: InboxMessage[] = [];

      prevOffers.forEach((offer) => {
        const nextRemaining = offer.daysRemaining - daysPassed;
        if (nextRemaining <= 0) {
          const isSuccess = Math.random() * 100 <= offer.buyProb;
          const sellerName = offer.sellerTeam ? offer.sellerTeam.name : 'Kulüp';

          if (isSuccess) {
            generatedInboxMsgs.push({
              id: `msg-buy-accepted-${Date.now()}-${Math.random()}`,
              sender: `${sellerName} Yönetimi`,
              subject: `✅ Transfer Teklifi Kabul Edildi: ${offer.player.name}`,
              date: simDateStr,
              content: `${sellerName} yönetimi, ${offer.player.name} için sunduğunuz €${(offer.effectiveFee / 1_000_000).toFixed(1)}M bonservis teklifini KABUL ETTİ!\n\nOyuncunun maaş ve sözleşme detaylarını görüşmek için aşağıdaki "Sözleşme Görüşmesi Yap" butonuna tıklayabilirsiniz.`,
              isRead: false,
              tag: 'TRANSFER',
              actionType: 'OPEN_CONTRACT_NEGOTIATION',
              actionData: {
                player: offer.player,
                sellerTeam: offer.sellerTeam,
                effectiveFee: offer.effectiveFee
              }
            });
          } else {
            const counterFee = Math.round(offer.effectiveFee * 1.3);
            generatedInboxMsgs.push({
              id: `msg-buy-rejected-${Date.now()}-${Math.random()}`,
              sender: `${sellerName} Yönetimi`,
              subject: `❌ Transfer Teklifi Reddedildi: ${offer.player.name}`,
              date: simDateStr,
              content: `${sellerName} yönetimi, ${offer.player.name} için sunduğunuz €${(offer.effectiveFee / 1_000_000).toFixed(1)}M bonservis teklifini yetersiz bularak REDDETTİ. Kulüp en az €${(counterFee / 1_000_000).toFixed(1)}M talep etmektedir.`,
              isRead: false,
              tag: 'TRANSFER'
            });
          }
        } else {
          remainingOffers.push({ ...offer, daysRemaining: nextRemaining });
        }
      });

      if (generatedInboxMsgs.length > 0) {
        setInboxMessages(prev => [...generatedInboxMsgs, ...prev]);
        showToast('info', '📬 Transfer Yanıtı Geldi!', `${generatedInboxMsgs.length} adet transfer teklifi yanıtı Gelen Kutusu'na ulaştı!`);
      }

      return remainingOffers;
    });

    // 2. Process pending mid-season transfer arrivals (e.g. week 18 / Ara Transfer)
    setPendingTransferArrivals((prevArrivals) => {
      const remainingArrivals: { player: Player; dealType: 'BUY' | 'LOAN'; fee: number; joinWeek: number }[] = [];
      const arrivedPlayers: Player[] = [];

      prevArrivals.forEach((item) => {
        if (currentWeek >= item.joinWeek) {
          arrivedPlayers.push(item.player);
          const arrivalMsg: InboxMessage = {
            id: `msg-arrival-${Date.now()}-${Math.random()}`,
            sender: 'Kulüp İdari İşler',
            subject: `🎉 YENİ TRANSFER TAKIMA KATILDI: ${item.player.name}`,
            date: simDateStr,
            content: `Ara Transfer Dönemi başladı! Önceden anlaşması tamamlanan ${item.player.name} resmi olarak A Takım kadromuza katıldı ve antrenmanlara başladı.`,
            isRead: false,
            tag: 'TRANSFER'
          };
          setInboxMessages(prev => [arrivalMsg, ...prev]);
        } else {
          remainingArrivals.push(item);
        }
      });

      if (arrivedPlayers.length > 0) {
        setAllTeams(prevTeams => prevTeams.map(t => {
          if (t.id !== currentTeam.id) return t;
          return {
            ...t,
            players: [...t.players, ...arrivedPlayers.map(p => ({ ...p, isStarting: false }))]
          };
        }));
      }

      return remainingArrivals;
    });

    // 3. Auto-handle incoming transfer/loan offers according to active vacationOfferPolicy
    if (vacationOfferPolicy !== 'NONE' || isVacationActive) {
      const listedTransfers = currentTeam.players.filter(p => p.isListedForTransfer);
      const listedLoans = currentTeam.players.filter(p => p.isListedForLoan);

      let targetCandidates: { player: Player; offerType: 'TRANSFER' | 'LOAN' }[] = [];
      listedTransfers.forEach(p => targetCandidates.push({ player: p, offerType: 'TRANSFER' }));
      listedLoans.forEach(p => targetCandidates.push({ player: p, offerType: 'LOAN' }));

      if (targetCandidates.length === 0 && Math.random() < 0.25) {
        const unlisted = currentTeam.players.filter(p => !p.isStarting && p.overall >= 68);
        if (unlisted.length > 0) {
          const randP = unlisted[Math.floor(Math.random() * unlisted.length)];
          targetCandidates.push({ player: randP, offerType: Math.random() > 0.5 ? 'TRANSFER' : 'LOAN' });
        }
      }

      if (targetCandidates.length > 0 && Math.random() < 0.4) {
        const chosen = targetCandidates[Math.floor(Math.random() * targetCandidates.length)];
        const targetPlayer = chosen.player;
        const isTransfer = chosen.offerType === 'TRANSFER';
        const rivalClubs = allTeams.filter(t => t.id !== currentTeam.id);

        if (rivalClubs.length > 0) {
          const buyerTeam = rivalClubs[Math.floor(Math.random() * rivalClubs.length)];
          const offerFee = Math.round((targetPlayer.marketValue || 5000000) * (1.1 + Math.random() * 0.25));

          if (vacationOfferPolicy === 'REJECT_ALL') {
            setInboxMessages(prev => [{
              id: `auto-reject-${Date.now()}-${Math.random()}`,
              sender: `${buyerTeam.name} Yönetimi`,
              subject: `❌ OTOMATİK REDDEDİLDİ: ${targetPlayer.name} Teklifi`,
              date: simDateStr,
              content: `${buyerTeam.name} kulübü ${targetPlayer.name} için €${(offerFee / 1_000_000).toFixed(1)}M teklifte bulundu. Tatil transfer ayarlarınız (Tüm Teklifleri Reddet) gereği teklif OTOMATİK REDDEDİLDİ.`,
              isRead: false,
              tag: 'TRANSFER'
            }, ...prev]);
          } else if (vacationOfferPolicy === 'REJECT_TRANSFERS' && isTransfer) {
            setInboxMessages(prev => [{
              id: `auto-reject-transfer-${Date.now()}-${Math.random()}`,
              sender: `${buyerTeam.name} Yönetimi`,
              subject: `❌ OTOMATİK REDDEDİLDİ: ${targetPlayer.name} Transfer Teklifi`,
              date: simDateStr,
              content: `${buyerTeam.name} kulübü ${targetPlayer.name} için €${(offerFee / 1_000_000).toFixed(1)}M bonservis teklifinde bulundu. Tatil transfer ayarlarınız (Tüm Transfer Tekliflerini Reddet) gereği teklif OTOMATİK REDDEDİLDİ.`,
              isRead: false,
              tag: 'TRANSFER'
            }, ...prev]);
          } else if (vacationOfferPolicy === 'REJECT_LOANS' && !isTransfer) {
            setInboxMessages(prev => [{
              id: `auto-reject-loan-${Date.now()}-${Math.random()}`,
              sender: `${buyerTeam.name} Yönetimi`,
              subject: `❌ OTOMATİK REDDEDİLDİ: ${targetPlayer.name} Kiralama Teklifi`,
              date: simDateStr,
              content: `${buyerTeam.name} kulübü ${targetPlayer.name} için kiralama teklifinde bulundu. Tatil transfer ayarlarınız (Tüm Kiralık Tekliflerini Reddet) gereği teklif OTOMATİK REDDEDİLDİ.`,
              isRead: false,
              tag: 'TRANSFER'
            }, ...prev]);
          } else if (vacationOfferPolicy === 'ACCEPT_TRANSFER_LISTED_ONLY') {
            if (isTransfer && targetPlayer.isListedForTransfer) {
              handleTransferPlayer(targetPlayer, currentTeam, buyerTeam.id, offerFee, false);
              setInboxMessages(prev => [{
                id: `auto-accept-transfer-${Date.now()}-${Math.random()}`,
                sender: 'Kulüp Transfer Masası',
                subject: `✅ OTOMATİK SATIŞ GERÇEKLEŞTİ: ${targetPlayer.name}`,
                date: simDateStr,
                content: `Transfer listesindeki oyuncunuz ${targetPlayer.name}, ${buyerTeam.name} kulübüne €${(offerFee / 1_000_000).toFixed(1)}M bonservis bedeliyle OTOMATİK SATILDI! Transfer geliri bütçenize eklendi.`,
                isRead: false,
                tag: 'TRANSFER'
              }, ...prev]);
            } else {
              setInboxMessages(prev => [{
                id: `auto-reject-unlisted-${Date.now()}-${Math.random()}`,
                sender: `${buyerTeam.name} Yönetimi`,
                subject: `❌ OTOMATİK REDDEDİLDİ: ${targetPlayer.name} Teklifi`,
                date: simDateStr,
                content: `${buyerTeam.name} kulübü ${targetPlayer.name} için teklifte bulundu. Oyuncu transfer listesinde olmadığı için tatil ayarlarınız gereği teklif OTOMATİK REDDEDİLDİ.`,
                isRead: false,
                tag: 'TRANSFER'
              }, ...prev]);
            }
          } else if (vacationOfferPolicy === 'ACCEPT_LOAN_LISTED_ONLY') {
            if (!isTransfer && targetPlayer.isListedForLoan) {
              handleTransferPlayer({ ...targetPlayer, isLoaned: true, parentClubName: currentTeam.name }, currentTeam, buyerTeam.id, 0, false);
              setInboxMessages(prev => [{
                id: `auto-accept-loan-${Date.now()}-${Math.random()}`,
                sender: 'Kulüp Transfer Masası',
                subject: `✅ OTOMATİK KİRALAMA GERÇEKLEŞTİ: ${targetPlayer.name}`,
                date: simDateStr,
                content: `Kiralık listesindeki oyuncunuz ${targetPlayer.name}, sezon sonuna kadar ${buyerTeam.name} kulübüne OTOMATİK KİRALANDI!`,
                isRead: false,
                tag: 'TRANSFER'
              }, ...prev]);
            } else {
              setInboxMessages(prev => [{
                id: `auto-reject-unlisted-loan-${Date.now()}-${Math.random()}`,
                sender: `${buyerTeam.name} Yönetimi`,
                subject: `❌ OTOMATİK REDDEDİLDİ: ${targetPlayer.name} Teklifi`,
                date: simDateStr,
                content: `${buyerTeam.name} kulübü ${targetPlayer.name} için teklifte bulundu. Oyuncu kiralık listesinde olmadığı için tatil ayarlarınız gereği teklif OTOMATİK REDDEDİLDİ.`,
                isRead: false,
                tag: 'TRANSFER'
              }, ...prev]);
            }
          }
        }
      }
    }
  };

  const handleAdvanceDay = () => {
    if (isAdvancingRef.current || isAdvancingDay) return;
    isAdvancingRef.current = true;
    setIsAdvancingDay(true);
    processScoutingProgress(1);

    // Age and status-aware stamina and morale recovery logic
    setAllTeams(prevTeams => prevTeams.map(t => ({
      ...t,
      players: t.players.map(p => {
        // Stamina Recovery: Young recovers fast (+12), Prime moderate (+9), Veteran slow (+4 to +6)
        let staminaRecovery = 8;
        if (p.age <= 22) staminaRecovery = 12;
        else if (p.age <= 29) staminaRecovery = 9;
        else if (p.age <= 33) staminaRecovery = 6;
        else staminaRecovery = 4; // Age 34+

        if (!p.isStarting) staminaRecovery += 2; // Reserves rest better

        // Morale Recovery: Young recovers fast, veterans regain slowly and decay when benched
        let currentMorale = p.morale ?? Math.min(95, Math.max(50, Math.round((p.form ?? 7) * 10)));
        let moraleRecovery = 2;
        if (p.age <= 22) {
          moraleRecovery = p.isStarting ? 4 : 2;
        } else if (p.age <= 29) {
          moraleRecovery = p.isStarting ? 3 : 1;
        } else { // Age 30+
          moraleRecovery = p.isStarting ? 2 : -1; // Unhappy when benched
        }

        if ((p.form ?? 7) >= 8.0) moraleRecovery += 2;

        return {
          ...p,
          stamina: Math.min(100, p.stamina + staminaRecovery),
          morale: Math.min(100, Math.max(30, currentMorale + moraleRecovery))
        };
      })
    })));

    setTimeout(() => {
      isAdvancingRef.current = false;
      setIsAdvancingDay(false);
      if (currentDayIndex < 4) {
        const nextIndex = currentDayIndex + 1;
        setCurrentDayIndex(nextIndex);

        // Realistic Date helper with active language
        const realSimDate = getSimulatedRealDate(currentSeason, currentWeek, nextIndex, language);
        const simDateStr = realSimDate.dateStr;

        processPendingOffersAndArrivals(1, simDateStr);

        // Generate dynamic notifications upon calendar advance
        if (nextIndex === 0 || (currentWeek % 4 === 1 && nextIndex === 1)) {
          // Monthly Contract Renewal Warning Notification for User's Team (Excluding Loan Players)
          const expiringUserPlayers = currentTeam.players.filter(p => (p.contractUntil || 2026) <= 2027 && !p.isLoaned && !p.parentClubName);
          if (expiringUserPlayers.length > 0) {
            const playerListStr = expiringUserPlayers.map(p => `• ${p.name} (${p.position} - ${p.overall} OVR, Sözleşme Bitiş: ${p.contractUntil || 2026})`).join('\n');
            const contractWarningMsg: InboxMessage = {
              id: `msg-${Date.now()}-contract-warning`,
              sender: 'Kulüp İnsan Kaynakları & Sözleşme Masası',
              senderName: 'Kulüp İnsan Kaynakları & Sözleşme Masası',
              senderRole: 'İdari Direktör',
              subject: `⚠️ AYLIK BİLDİRİM: Sözleşmesi 1 Yıldan Az Kalan Oyuncularınız (${expiringUserPlayers.length} Oyuncu)`,
              subjectParams: { count: expiringUserPlayers.length },
              date: simDateStr,
              content: `Sayın Menajer ${manager.name},\n\nKulübümüz bünyesinde sözleşmesinin bitimine 1 yıldan az süre kalan oyuncularımızın listesi aşağıdadır:\n\n${playerListStr}\n\nBu oyuncuları sezon sonunda bedelsiz (serbest) kaybetme riskiyle karşılaşmamak adına isimlerine tıklayarak veya Kadro ekranından sözleşmelerini yenilemeniz önemle rica olunur.`,
              contentParams: { name: manager.name, playerList: playerListStr, count: expiringUserPlayers.length },
              isRead: false,
              tag: 'YÖNETİM',
              category: 'ADMIN_REPORT',
              actionData: {
                player: expiringUserPlayers[0],
                sellerTeam: currentTeam
              }
            };
            setInboxMessages(prev => [contractWarningMsg, ...prev]);
          }

          // Occasional Transfer Intelligence Notification for Expiring Star Contracts in Other Leagues
          const rivalExpiringStars: { name: string; teamName: string; ovr: number; age: number; pos: string }[] = [];
          allTeams.forEach(tm => {
            if (tm.id !== currentTeam.id) {
              tm.players.forEach(p => {
                if ((p.contractUntil || 2026) <= 2027 && p.overall >= 78) {
                  rivalExpiringStars.push({ name: p.name, teamName: tm.name, ovr: p.overall, age: p.age, pos: p.position });
                }
              });
            }
          });
          INTERNATIONAL_TEAMS.forEach(ext => {
            ext.players.forEach(p => {
              if ((p.contractUntil || 2026) <= 2027 && p.overall >= 82) {
                rivalExpiringStars.push({ name: p.name, teamName: `${ext.name} (${ext.flag})`, ovr: p.overall, age: p.age, pos: p.position });
              }
            });
          });

          if (rivalExpiringStars.length > 0) {
            const star = rivalExpiringStars[Math.floor(Math.random() * rivalExpiringStars.length)];
            let foundPlayer: Player | undefined = undefined;
            let foundTeam: Team | undefined = undefined;

            for (const tm of allTeams) {
              if (tm.name === star.teamName) {
                foundTeam = tm;
                foundPlayer = tm.players.find(p => p.name === star.name);
                break;
              }
            }
            if (!foundPlayer) {
              for (const ext of INTERNATIONAL_TEAMS) {
                if (`${ext.name} (${ext.flag})` === star.teamName || ext.name === star.teamName) {
                  foundPlayer = ext.players.find(p => p.name === star.name);
                  break;
                }
              }
            }

            const rivalStarMsg: InboxMessage = {
              id: `msg-${Date.now()}-rival-star`,
              sender: 'Uluslararası Scout & Transfer İstihbaratı',
              subject: `🌟 FIRSAT BİLDİRİMİ: ${star.name} (${star.teamName}) Sözleşmesi Sona Eriyor!`,
              date: simDateStr,
              content: `Küresel transfer istihbarat ağımızdan gelen son rapora göre, ${star.teamName} forması giyen yıldız oyuncu ${star.name} (${star.age} yaş, ${star.pos} - ${star.ovr} OVR) kulübüyle sözleşme yenilemeyi reddetti.\n\nSözleşmesinin bitimine 1 yıldan az kalan yıldız futbolcuyu uygun bonservis opsiyonuyla kadronuza katmak için Transfer Pazarını inceleyebilirsiniz.`,
              isRead: false,
              tag: 'TRANSFER',
              actionData: foundPlayer ? {
                player: foundPlayer,
                sellerTeam: foundTeam
              } : undefined
            };
            setInboxMessages(prev => [rivalStarMsg, ...prev]);
          }
        }

        if (nextIndex === 2) { // 2 Days Before Match
          const pressConferenceQuotes = [
            `${opponentTeam.name} teknik direktörü maç öncesi düzenlenen basın toplantısında iddialı konuştu:\n"${currentTeam.name} güçlü ve disiplinli bir rakip olabilir ancak biz sahadan galibiyetle ayrılmak için planımızı hazırladık. Taraftarlarımıza 3 puanı armağan etmek istiyoruz."`,
            `${opponentTeam.name} teknik direktörü basın mensuplarının sorularını yanıtladı:\n"Saha avantajımızı sonuna kadar kullanacağız. Rakibimizin hücum hatlarını durduracak taktiksel önlemleri aldık. Galibiyetten başka bir sonuç kabul edilemez."`,
            `${opponentTeam.name} çalıştırıcısı basın karşısına geçti:\n"Kritik bir maça çıkıyoruz. Sahaya tüm gücümüzü yansıtıp rakibimize geçit vermeyeceğiz. Oyuncularımın konsantrasyonu üst seviyede."`,
            `${opponentTeam.name} teknik patronundan maç öncesi dikkat çeken açıklamalar:\n"${currentTeam.name} takımına saygı duyuyoruz fakat çekinmiyoruz. İlk dakikadan itibaren baskı kurup galibiyete ulaşan taraf olacağız."`,
            `${opponentTeam.name} hocası iddialı konuştu:\n"Zorlu bir mücadele bizi bekliyor ancak kondisyonumuz ve taktik disiplinimiz tam. Oyun kontrolünü elimizde tutup maçı kazanacağız."`
          ];
          const randomQuote = pressConferenceQuotes[Math.floor(Math.random() * pressConferenceQuotes.length)];

          const rivalMsg: InboxMessage = {
            id: `msg-${Date.now()}-rival`,
            sender: `${opponentTeam.name} Teknik Kadrosu`,
            subject: `🎙️ Rakip TD Açıklaması: "${currentTeam.name} Maçı Öncesi İddialı Sözler"`,
            date: simDateStr,
            content: randomQuote,
            isRead: false,
            tag: 'MEDYA'
          };

          setInboxMessages(prev => [rivalMsg, ...prev]);
        } else if (nextIndex === 3) { // 1 Day Before Match (Eve)
          const avail = currentTeam.players.filter(p => !p.isInjured && !p.isSuspended);

          const getXiScore = (p: Player) => {
            const baseOverall = p.overall * 1.5;
            const recentRating = p.lastRating ?? p.averageRating ?? (p.form ?? 7);
            const ratingImpact = (recentRating - 6.5) * 8.5;
            const formImpact = ((p.form ?? 7) - 6) * 4.5;
            const moraleImpact = (((p.morale ?? 75) - 60) / 40) * 6;
            const growth = p.growthProgress ?? 50;
            const trainingImpact = (growth / 100) * 12;
            const intensityBoost = p.trainingIntensity === 'Ağır' ? 5 : p.trainingIntensity === 'Normal' ? 2 : -2;
            const stam = p.stamina ?? 100;
            const staminaPenalty = stam < 80 ? (stam - 80) * 1.5 : (stam - 80) * 0.2;
            const numId = Number(p.id.replace(/\D/g, '') || 1);
            const weeklyVariation = Math.sin(numId * 19.3 + currentWeek * 4.1) * 5.5;
            return baseOverall + ratingImpact + formImpact + moraleImpact + trainingImpact + intensityBoost + staminaPenalty + weeklyVariation;
          };

          const gkPool = avail.filter(p => p.position === 'GK').sort((a,b) => getXiScore(b) - getXiScore(a));
          const defPool = avail.filter(p => p.position === 'DEF').sort((a,b) => getXiScore(b) - getXiScore(a));
          const midPool = avail.filter(p => p.position === 'MID').sort((a,b) => getXiScore(b) - getXiScore(a));
          const fwPool = avail.filter(p => p.position === 'FW').sort((a,b) => getXiScore(b) - getXiScore(a));

          const curFormation = currentTeam.formation || '4-3-3';
          let targetDef = 4, targetMid = 3, targetFw = 3;
          if (curFormation === '4-4-2') { targetDef = 4; targetMid = 4; targetFw = 2; }
          else if (curFormation === '3-5-2') { targetDef = 3; targetMid = 5; targetFw = 2; }
          else if (curFormation === '4-2-3-1') { targetDef = 4; targetMid = 5; targetFw = 1; }
          else if (curFormation === '5-3-2') { targetDef = 5; targetMid = 3; targetFw = 2; }

          const topGk = gkPool[0] || currentTeam.players.find(p => p.position === 'GK') || currentTeam.players[0];
          const topDef = defPool.slice(0, targetDef);
          const topMid = midPool.slice(0, targetMid);
          const topFw = fwPool.slice(0, targetFw);

          const xiMsg: InboxMessage = {
            id: `msg-${Date.now()}-1`,
            sender: t('SENDER_TECHNICAL_ANALYSIS'),
            subject: t('RECOMMENDED_XI_SUBJECT', { opponent: opponentTeam.name }),
            date: simDateStr,
            content: t('RECOMMENDED_XI_BODY', {
              opponent: opponentTeam.name,
              gk: `${topGk.name} (${topGk.overall} OVR)`,
              def: topDef.map(p => p.name).join(', ') || 'Savunma Hattı',
              mid: [...topMid, ...topFw].map(p => p.name).join(', ') || 'Orta Saha & Hücum',
              formation: currentTeam.formation
            }),
            isRead: false,
            tag: 'TAKTIK'
          };

          setInboxMessages(prev => [xiMsg, ...prev]);
        } else if (nextIndex === 4) {
          const matchMsg: InboxMessage = {
            id: `msg-${Date.now()}`,
            sender: t('SENDER_CLUB_OPERATIONS') || 'Kulüp İdari İşler',
            subject: t('INBOX_MSG_MATCH_DAY_SUBJECT', { home: currentTeam.name, away: opponentTeam.name }),
            subjectKey: 'INBOX_MSG_MATCH_DAY_SUBJECT',
            subjectParams: { home: currentTeam.name, away: opponentTeam.name },
            date: simDateStr,
            content: t('INBOX_MSG_MATCH_DAY_CONTENT', { week: currentWeek }),
            contentKey: 'INBOX_MSG_MATCH_DAY_CONTENT',
            contentParams: { week: currentWeek, home: currentTeam.name, away: opponentTeam.name },
            isRead: false,
            tag: 'YÖNETİM'
          };
          setInboxMessages(prev => [matchMsg, ...prev]);
        } else {
          // If a match was played previously, generate authentic media reviews from press and pundits
          if (lastMatchForMediaReview) {
            const mr = lastMatchForMediaReview;
            const isUserHome = mr.homeTeam.id === currentTeam.id;
            const userScore = isUserHome ? mr.homeScore : mr.awayScore;
            const oppScore = isUserHome ? mr.awayScore : mr.homeScore;
            const userWon = userScore > oppScore;
            const isDraw = userScore === oppScore;

            const reviews: MediaReviewItem[] = [
              {
                author: 'Kıdemli Taktik Masası & Lig Analisti',
                source: 'Fanatik Gazetesi & Vole',
                comment: userWon
                  ? `${currentTeam.name} sahada taktiksel açıdan kusursuz bir plan uyguladı. Özellikle geçiş oyunlarında ${mr.motm?.name || 'hücum hattı'} inanılmaz fark yarattı.`
                  : isDraw
                  ? `İki takım da birbirine bariz üstünlük kuramadı. Ancak ${currentTeam.name} için kaçan net pozisyonlar 2 puanın kaybedilmesine yol açtı.`
                  : `${currentTeam.name} savunmada beklemediği boşluklar verdi. Rakip bu zaafları çok iyi değerlendirdi, teknik ekibin bu maçı çok iyi analiz etmesi şart.`
              },
              {
                author: 'Avrupa Futbol Masası & Uluslararası Analiz Servisi',
                source: 'Uluslararası Spor Masası',
                comment: userWon
                  ? `Temsilcimiz ${currentTeam.name} sergilediği modern pres futboluyla Avrupa standartlarında bir 90 dakika çıkardı.`
                  : `${currentTeam.name} lig maratonunda kritik bir virajı geride bıraktı. Kadro derinliği ve rotasyonun önemi bu haftalarda daha çok anlaşılacak.`
              },
              {
                author: 'Stüdyo Futbol Masası & Analiz Heyeti',
                source: 'Ulusal Spor Stüdyosu',
                comment: userWon
                  ? `Hocanın oyuncu tercihleri ve maç içindeki hamleleri tam isabet. Takım oyun disiplininden bir saniye bile kopmadı.`
                  : isDraw
                  ? `Mücadelesi çok yüksek bir maçtı. İki takım da puanı hak etti ama ${currentTeam.name} son vuruşlarda daha soğukkanlı olabilirdi.`
                  : `Takımın fiziksel direnci ikinci yarıda biraz düştü. Oyuncuların reaksiyon vermesi ve bir an önce toparlanması gerekiyor.`
              },
              {
                author: 'Uluslararası Basın Servisi',
                source: 'Avrupa Spor Servisi',
                comment: `Süper Lig'de haftanın en çok konuşulan karşılaşması geride kaldı. ${mr.homeTeam.name} ${mr.homeScore}-${mr.awayScore} ${mr.awayTeam.name} skoru lig tablosundaki dengeleri doğrudan etkiledi.`
              }
            ];

            const mediaReviewData: MediaReviewData = {
              matchSummary: `${mr.homeTeam.name} ${mr.homeScore} - ${mr.awayScore} ${mr.awayTeam.name} karşılaşması sonrası spor kamuoyu ve basından öne çıkan yorumlar derlendi.`,
              reviews
            };

            const mediaInboxMsg: InboxMessage = {
              id: `msg-media-${Date.now()}`,
              sender: 'Ulusal & Dış Basın Servisi',
              subject: `📰 BASIN & YORUMCU DEĞERLENDİRMELERİ: ${mr.homeTeam.name} ${mr.homeScore}-${mr.awayScore} ${mr.awayTeam.name}`,
              date: simDateStr,
              content: `Dünkü karşılaşmanın ardından yerli ve yabancı spor yazarları, gazete manşetleri ve TV yorumcuları 90 dakikayı masaya yatırdı. İşte haftanın öne çıkan değerlendirmeleri:`,
              isRead: false,
              tag: 'MEDYA',
              category: 'NEWS',
              mediaReview: mediaReviewData
            };

            setInboxMessages(prev => [mediaInboxMsg, ...prev]);
            setLastMatchForMediaReview(null);
          } else {
            // Diverse training, youth talent, and performance reports featuring multiple players without OVR numbers
            const sortedByForm = [...currentTeam.players].sort((a,b) => (b.form ?? 7) - (a.form ?? 7));
            const standoutPlayers = sortedByForm.slice(0, Math.min(3, Math.floor(Math.random() * 2) + 2)); // 2 to 3 players
            const standoutNames = standoutPlayers.map(p => p.name).join(', ');

            // Select random combinations of young players (age <= 23 or 25)
            const youngCandidates = currentTeam.players.filter(p => p.age <= 23);
            let youngPool = youngCandidates.length >= 2 ? youngCandidates : currentTeam.players.filter(p => p.age <= 25);
            if (youngPool.length < 2) youngPool = currentTeam.players;

            const shuffledYoung = [...youngPool].sort(() => Math.random() - 0.5);
            const selectedYoung = shuffledYoung.slice(0, Math.min(shuffledYoung.length, Math.floor(Math.random() * 2) + 2));
            const youngNames = selectedYoung.map(p => p.name).join(' ve ');

            const reportTypes = [
              {
                sender: 'Performans & Antrenman Analisti',
                subject: `🔥 Antrenmanda Öne Çıkan İsimler: ${standoutNames}`,
                tag: 'TAKTIK' as const,
                content: `Bugünkü yüksek tempolu antrenman seansında ${standoutNames} sergiledikleri hırs, şut isabeti ve yüksek kondisyonla teknik heyetin takdirini topladı. Form grafiklerini zirveye taşıyan oyuncularımız gelecek maç öncesi hazır görünüyor.`
              },
              {
                sender: 'Altyapı & Scout Direktörü',
                subject: `🌟 Gelecek Maç İçin Umut Vadeden Yetenekler: ${youngNames}`,
                tag: 'SCOUT' as const,
                content: `Genç oyuncularımız ${youngNames}, özel bitiricilik ve dar alanda hızlı pas antrenmanında müthiş bir gelişim gösterdi. Teknik ekip oyuncuların ilk 11 rekabetine dahil edilmesi yönünde olumlu görüş bildirdi.`
              },
              {
                sender: 'Fizyoterapi & Sağlık Kurulu',
                subject: `🩺 Takım Sağlık & Kondisyon Raporu (${simDateStr})`,
                tag: 'SAĞLIK' as const,
                content: `Fiziksel yükleme seansları sonrası kadrodaki tüm oyuncuların laktat ve laktik asit ölçümleri tamamlandı. Sakatlık riski minimizasyonu başarıyla uygulandı, takım genel fiziksel direnci üst seviyede.`
              },
              {
                sender: 'Taktik Hazırlık Grubu',
                subject: `📊 Set Oyunları ve Form Yükseliş Raporu`,
                tag: 'TAKTIK' as const,
                content: `Bugünkü antrenmanda ceza sahası organizasyonları ve korner setleri üzerinde duruldu. Takımımızın duran top ve hücum varyasyonlarındaki başarı oranı artış kaydetti.`
              }
            ];

            const chosenReport = reportTypes[nextIndex % reportTypes.length];
            const dailyMsg: InboxMessage = {
              id: `msg-${Date.now()}`,
              sender: chosenReport.sender,
              subject: chosenReport.subject,
              date: simDateStr,
              content: chosenReport.content,
              isRead: false,
              tag: chosenReport.tag
            };
            setInboxMessages(prev => [dailyMsg, ...prev]);
          }
        }

        setHasUnreadNews(true);

        // Redirect automatically to Gelen Kutusu as requested
        setIsInboxOpen(true);

        if (nextIndex === 4) {
          showToast('info', t('MATCH_DAY_ARRIVED'), t('MATCH_DAY_NOTIFICATION_BODY'));
        } else {
          showToast('info', `📅 ${t('CALENDAR_ADVANCED')}`, t('CALENDAR_ADVANCED_BODY').replace('{date}', simDateStr));
        }
      } else {
        setIsPreMatchOpen(true);
      }
    }, 1200);
  };

  return (
    <div className="flex flex-row h-screen w-screen overflow-hidden bg-[#120f21] text-slate-100 font-sans antialiased selection:bg-[#7b2cbf] selection:text-white">
      
      {/* Landscape Lock Orientation Overlay */}
      <RotateDeviceOverlay />

      {/* Day Advance Transition Flash Overlay */}
      {isAdvancingDay && (
        <div className="fixed inset-0 z-[9999] bg-purple-950/30 backdrop-blur-[2px] flex items-center justify-center transition-all animate-pulse pointer-events-none">
          <div className="bg-[#1e1738] border border-purple-500/50 px-5 py-2.5 rounded-2xl shadow-2xl flex items-center gap-3 text-purple-200 font-black text-sm">
            <Sparkles className="w-5 h-5 text-amber-300 animate-spin" />
            <span>{t('ADVANCING_CALENDAR')}</span>
          </div>
        </div>
      )}

      {/* Toast Notification System */}
      <ToastNotification toasts={toasts} onRemove={removeToast} />

      {/* Official FMM Fixed Vertical Sidebar */}
      <FMMSidebar
        activeTab={activeTab}
        onChangeTab={(tab) => {
          setActiveTab(tab);
          if (tab === 'NEWS') setHasUnreadNews(false);
        }}
        currentTeam={currentTeam}
        gameMode={gameMode}
        hasUnreadNews={hasUnreadNews}
        onOpenInboxModal={() => setIsInboxOpen(true)}
        onOpenMainMenu={() => setShowMainMenu(true)}
        unreadCount={inboxMessages.filter(m => !m.isRead).length}
      />

      {/* Main Content Workspace (Right of Sidebar) */}
      <div className="flex-1 flex flex-col h-full overflow-hidden min-w-0">
        
        {/* Top Bar / Header */}
        <Header
          manager={manager}
          currentTeam={currentTeam}
          opponentTeam={opponentTeam}
          allTeams={allTeams}
          currentWeek={currentWeek}
          currentSeason={currentSeason}
          currentDayIndex={currentDayIndex}
          currentDayName={DAY_NAMES[currentDayIndex]}
          isMatchDay={currentDayIndex === 4}
          onSelectTeam={handleSelectTeam}
          onAdvanceDay={handleAdvanceDay}
          onOpenPreMatch={() => {
            const startingPlayers = currentTeam.players.filter((p) => p.isStarting);
            const injuredIn11 = startingPlayers.find((p) => p.isInjured || (p.injuryWeeksLeft && p.injuryWeeksLeft > 0));
            const suspendedIn11 = startingPlayers.find((p) => p.isSuspended || (p.suspensionMatchesLeft && p.suspensionMatchesLeft > 0));

            if (injuredIn11) {
              showToast(
                'error',
                'Sakat Oyuncu Kadroda! 🏥',
                `İlk 11'inizde sakat olan ${injuredIn11.name} (${injuredIn11.injuryWeeksLeft || 1} hafta) bulunuyor. Sakat oyuncuyla maça çıkamazsınız. Lütfen Taktik ekranından kadroyu düzenleyin.`
              );
              setActiveTab('TACTICS');
              return;
            }
            if (suspendedIn11) {
              showToast(
                'error',
                'Cezalı Oyuncu Kadroda! 🟥',
                `İlk 11'inizde cezalı olan ${suspendedIn11.name} (${suspendedIn11.suspensionReason || 'Kırmızı Kart'}) bulunuyor. Cezalı oyuncuyla maça çıkamazsınız. Lütfen Taktik ekranından kadroyu düzenleyin.`
              );
              setActiveTab('TACTICS');
              return;
            }
            setIsPreMatchOpen(true);
          }}
          onSaveGame={handleSaveGame}
          onOpenCareerMenu={() => setShowMainMenu(true)}
          onOpenWorldScout={() => setIsWorldScoutOpen(true)}
        />

        {/* Navigation Bar */}
        <Navigation
          activeTab={activeTab}
          onTabChange={setActiveTab}
          gameMode={gameMode}
        />

        {/* Main Workspace Body (Full Vertical Stretch to Screen Bottom) */}
        <main className={`flex-1 max-w-[1500px] w-full mx-auto flex flex-col min-h-0 h-full ${
          activeTab === 'TACTICS' ? 'p-1.5 sm:p-2 overflow-hidden' : 'px-2 pt-2 pb-3 sm:px-3 sm:pt-3 sm:pb-4 overflow-y-auto custom-scrollbar'
        }`}>
          
          {/* Tab: OYUNCUM (MY PLAYER CAREER VIEW) */}
          {(activeTab === 'MY_PLAYER' || (gameMode === 'PLAYER_CAREER' && (activeTab === 'TRAINING' || activeTab === 'TRANSFERS'))) && createdPlayer && (
            <MyPlayerView
              createdPlayer={createdPlayer}
              currentTeam={currentTeam}
              allTeams={allTeams}
              onUpdatePlayerProfile={(updated) => setCreatedPlayer(updated)}
              onTransferToTeam={handleTransferCreatedPlayer}
            />
          )}
          
          {/* Tab 0: ANA SAYFA (OVERVIEW - Distinct layout for Player Career vs Manager Career) */}
          {activeTab === 'HOME' && (
            gameMode === 'PLAYER_CAREER' && createdPlayer ? (
              <PlayerHomeView
                player={{
                  id: createdPlayer.id,
                  name: createdPlayer.name,
                  age: createdPlayer.age,
                  position: (createdPlayer.position as string) === 'SANTRAFOR' ? 'FW' : (createdPlayer.position as string) === 'STOPER' ? 'DEF' : (createdPlayer.position as string) === 'KALECİ' ? 'GK' : createdPlayer.position,
                  specificRole: createdPlayer.specificRole || createdPlayer.position,
                  overall: createdPlayer.overall || Math.round((createdPlayer.attributes.pace + createdPlayer.attributes.shooting + createdPlayer.attributes.passing + createdPlayer.attributes.defending + createdPlayer.attributes.physical) / 5) || 78,
                  stamina: createdPlayer.stamina || 98,
                  form: createdPlayer.form || 9,
                  marketValue: createdPlayer.marketValue || 18500000,
                  attributes: createdPlayer.attributes,
                  isStarting: true,
                  goalsScored: createdPlayer.goalsScored || 0,
                  assists: createdPlayer.assists || 0,
                  wage: createdPlayer.wage || 25000,
                  lastRating: createdPlayer.averageRating || 8.2
                }}
                avatar={createdPlayer.avatar}
                currentTeam={currentTeam}
                opponentTeam={opponentTeam}
                currentWeek={currentWeek}
                onPlayMatch={() => setIsMatchModalOpen(true)}
                onOpenMyPlayerTab={() => setActiveTab('MY_PLAYER')}
                onOpenNewsTab={() => setActiveTab('NEWS')}
              />
            ) : (
              <HomeDashboard
                currentTeam={currentTeam}
                opponentTeam={opponentTeam}
                currentWeek={currentWeek}
                currentSeason={currentSeason}
                managerName={manager.name}
                allTeams={allTeams}
                standings={standings}
                currentWeekFixture={currentWeekFixture}
                inboxMessages={inboxMessages}
                onOpenPreMatch={() => {
                  const startingPlayers = currentTeam.players.filter((p) => p.isStarting);
                  const injuredIn11 = startingPlayers.find((p) => p.isInjured || (p.injuryWeeksLeft && p.injuryWeeksLeft > 0));
                  const suspendedIn11 = startingPlayers.find((p) => p.isSuspended || (p.suspensionMatchesLeft && p.suspensionMatchesLeft > 0));

                  if (injuredIn11) {
                    showToast(
                      'error',
                      'Sakat Oyuncu Kadroda! 🏥',
                      `İlk 11'inizde sakat olan ${injuredIn11.name} (${injuredIn11.injuryWeeksLeft || 1} hafta) bulunuyor. Sakat oyuncuyla maça çıkamazsınız. Lütfen Taktik ekranından kadroyu düzenleyin.`
                    );
                    setActiveTab('TACTICS');
                    return;
                  }
                  if (suspendedIn11) {
                    showToast(
                      'error',
                      'Cezalı Oyuncu Kadroda! 🟥',
                      `İlk 11'inizde cezalı olan ${suspendedIn11.name} (${suspendedIn11.suspensionReason || 'Kırmızı Kart'}) bulunuyor. Cezalı oyuncuyla maça çıkamazsınız. Lütfen Taktik ekranından kadroyu düzenleyin.`
                    );
                    setActiveTab('TACTICS');
                    return;
                  }
                  setIsMatchModalOpen(true);
                }}
                onOpenMatchComparison={() => setIsMatchComparisonOpen(true)}
                onOpenVacationModal={() => setIsVacationModalOpen(true)}
                onOpenBoardConfidenceModal={() => setIsBoardConfidenceModalOpen(true)}
                onOpenFinancesModal={() => setIsFinancesModalOpen(true)}
                onOpenFullSquadModal={() => setIsFullSquadModalOpen(true)}
                onNavigateTab={(tab) => setActiveTab(tab as any)}
                onChangeFormation={(f) => {
                  handleChangeFormation(f);
                  showToast('info', 'Diziliş Güncellendi ⚽', `Takım dizilişi ${f} olarak değiştirildi.`);
                }}
              />
            )
          )}

          {/* Tab 0.5: SON HABERLER */}
          {activeTab === 'NEWS' && (
            <div className="w-full h-full min-h-0 flex-1 overflow-y-auto custom-scrollbar flex flex-col p-1 sm:p-2">
              <NewsFeed
                currentTeam={currentTeam}
                opponentTeam={opponentTeam}
                currentWeek={currentWeek}
                allTeams={allTeams}
              />
            </div>
          )}

          {/* Tab 1: KADRO VE TAKTİK EKRANI (AAA Desktop 16:9 Layout) */}
          {activeTab === 'TACTICS' && (
            <div className="w-full h-full min-h-0 flex flex-col flex-1 overflow-hidden">
              <TacticalPitch
                team={currentTeam}
                selectedPlayer={selectedPlayer}
                onSelectPlayer={setSelectedPlayer}
                onSwapPlayers={handleSwapPlayers}
                onChangeFormation={handleChangeFormation}
                onChangeTactic={handleChangeTactic}
                onUpdateTacticalDetails={handleUpdateTacticalDetails}
                activeSubMenu={activeTacticsSubMenu}
                isRecommendedPreviewActive={isRecommendedPreviewActive}
                onGoToRecommendedLineup={handleGoToTacticsWithRecommended}
                onSaveRecommendedLineup={handleSaveRecommendedLineup}
                onCancelRecommendedLineup={handleCancelRecommendedLineup}
                onOpenPlayerProfile={(p) => handleOpenPlayerProfile(p, currentTeam)}
              />
            </div>
          )}

          {/* Tab 2: PUAN DURUMU */}
          {activeTab === 'STANDINGS' && (
            <div className="h-full overflow-hidden flex flex-col">
              <LeagueTable
                standings={standings}
                currentTeamId={currentTeam.id}
                userTeam={currentTeam}
                fixtures={fixtures}
                allTeams={allTeams}
                currentWeek={currentWeek}
                onOpenPlayerProfile={(p, t) => {
                  setProfilePlayer(p);
                  setProfilePlayerTeam(t || null);
                }}
                onBuyPlayer={handleBuyPlayer}
                showToast={showToast}
              />
            </div>
          )}

          {/* Tab 3: TRANSFER PAZARI */}
          {activeTab === 'TRANSFERS' && (
            <div className="h-full overflow-hidden flex flex-col">
              <TransferMarket
                currentTeam={currentTeam}
                allTeams={allTeams}
                favoritePlayerIds={favoritePlayerIds}
                onToggleFavorite={handleToggleFavorite}
                onBuyPlayer={handleBuyPlayer}
                onSelectPlayerProfile={handleOpenPlayerProfile}
                onShowToast={showToast}
              />
            </div>
          )}

          {/* Tab 4: ANTRENMAN */}
          {activeTab === 'TRAINING' && (
            <div className="h-full overflow-hidden flex flex-col">
              <TrainingCenter
                currentTeam={currentTeam}
                onUpdatePlayerTraining={handleUpdatePlayerTraining}
                onUpdatePlayerAttributes={handleUpdatePlayerAttributes}
                onRestoreStaminaAll={handleRestoreStaminaAll}
                daysSinceLastRestore={daysSinceLastConditionRestore}
                onShowToast={showToast}
              />
            </div>
          )}

          {/* Tab 5: FİKSTÜR TAKVİMİ */}
          {activeTab === 'FIXTURES' && (
            <div className="w-full flex flex-col">
              <FixturesView
                fixtures={fixtures}
                allTeams={allTeams}
                currentWeek={currentWeek}
                currentTeamId={currentTeam.id}
              />
            </div>
          )}

        </main>

      </div>

      {/* Live Match Simulation Modal */}
      {/* Pre-Match Review & Lineup Modal */}
      {isPreMatchOpen && (
        <PreMatchModal
          isOpen={isPreMatchOpen}
          homeTeam={currentWeekFixture?.homeTeamId === currentTeam.id ? currentTeam : opponentTeam}
          awayTeam={currentWeekFixture?.homeTeamId === currentTeam.id ? opponentTeam : currentTeam}
          currentTeam={currentTeam}
          opponentTeam={opponentTeam}
          manager={manager}
          currentWeek={currentWeek}
          currentSeason={currentSeason}
          allTeams={allTeams}
          onClose={() => setIsPreMatchOpen(false)}
          onOpenPlayerProfile={(player, team) => {
            handleOpenPlayerProfile(player, team || currentTeam);
          }}
          onOpenTeamModal={(team) => {
            const populated = ensureTeamHas20Players(team);
            if (team.id === currentTeam.id) {
              setIsFullSquadModalOpen(true);
            } else {
              setTeamDetailModalData(populated);
            }
          }}
          onStartMatch={(isQuickSim?: boolean) => {
            setIsPreMatchOpen(false);
            setIsQuickSimMatch(!!isQuickSim);
            setIsMatchModalOpen(true);
          }}
          onEditTactics={() => {
            setIsPreMatchOpen(false);
            setActiveTab('TACTICS');
          }}
        />
      )}

      {/* Match Simulation Modal */}
      {isMatchModalOpen && (
        <MatchSimulationModal
          homeTeam={currentWeekFixture?.homeTeamId === currentTeam.id ? currentTeam : opponentTeam}
          awayTeam={currentWeekFixture?.homeTeamId === currentTeam.id ? opponentTeam : currentTeam}
          weekNumber={currentWeek}
          userTeamId={currentTeam.id}
          initialQuickSim={isQuickSimMatch}
          onClose={() => {
            setIsMatchModalOpen(false);
            setIsQuickSimMatch(false);
            setIsInboxOpen(true);
          }}
          onMatchCompleted={handleMatchCompleted}
          onOpenPlayerProfile={(p) => setProfilePlayer(p)}
        />
      )}

      {/* FMM Player Profile Screen Modal */}
      {profilePlayer && (
        <PlayerProfileModal
          player={profilePlayer}
          team={profilePlayerTeam || currentTeam}
          userTeamId={currentTeam.id}
          scouts={scouts}
          scoutReports={scoutReports}
          favoritePlayerIds={favoritePlayerIds}
          onToggleFavorite={handleToggleFavorite}
          onClose={() => {
            setProfilePlayer(null);
            setProfilePlayerTeam(null);
            if (openedFromInbox) {
              setIsInboxOpen(true);
              setOpenedFromInbox(false);
            }
          }}
          onOpenContractModal={(p) => setContractModalPlayer(p)}
          onOpenCountryModal={(c) => {
            setProfilePlayer(null);
            setProfilePlayerTeam(null);
            setCountryModalName(c);
          }}
          onOpenTeamModal={(t) => {
            setProfilePlayer(null);
            setProfilePlayerTeam(null);
            const populated = ensureTeamHas20Players(t);
            if (t.id === currentTeam.id) {
              setIsFullSquadModalOpen(true);
            } else {
              setTeamDetailModalData(populated);
            }
          }}
          onAssignScout={handleAssignScout}
          onOpenScoutManagement={() => setIsScoutManagementOpen(true)}
          onOpenOfferModal={(p, t, initialType) => {
            setProfilePlayer(null);
            setProfilePlayerTeam(null);
            setOfferModalData({ player: p, team: t, initialType });
          }}
        />
      )}

      {/* Transfer & Loan Negotiation Offer Modal */}
      {offerModalData && (
        <TransferOfferModal
          isOpen={!!offerModalData}
          onClose={() => setOfferModalData(null)}
          player={offerModalData.player}
          sellerTeam={offerModalData.team}
          userTeam={currentTeam}
          initialOfferType={offerModalData.initialType}
          initialStage={offerModalData.initialStage || 'CLUB_DEAL'}
          currentWeek={currentWeek}
          onSendBuyOffer={handleSendBuyOffer}
          onAddAirportCelebrationInbox={handleAddAirportCelebrationInbox}
          onTransferSuccess={(pl, dealType, fee, updatedProps, isPendingArrival) => {
            const finalPlayer = updatedProps ? { ...pl, ...updatedProps } : pl;
            handleTransferPlayer(finalPlayer, offerModalData.team || currentTeam, currentTeam.id, fee, isPendingArrival);
            setOfferModalData(null);
          }}
          showToast={showToast}
        />
      )}

      {/* Finances Breakdown Modal */}
      {isFinancesModalOpen && (
        <FinancesModal
          isOpen={isFinancesModalOpen}
          onClose={() => setIsFinancesModalOpen(false)}
          team={currentTeam}
        />
      )}

      {/* Contract Extension & Actions Modal */}
      {contractModalPlayer && (
        <ContractModal
          isOpen={!!contractModalPlayer}
          onClose={() => setContractModalPlayer(null)}
          player={contractModalPlayer}
          team={profilePlayerTeam || currentTeam}
          userTeamId={currentTeam.id}
          onUpdatePlayerContract={handleUpdatePlayerContract}
          showToast={showToast}
          onOpenOfferModal={(p, t, defaultType) => setOfferModalData({ player: p, team: t, initialType: defaultType || 'BUY' })}
        />
      )}

      {/* Scout Management & Hiring Modal */}
      {isScoutManagementOpen && (
        <ScoutManagementModal
          isOpen={isScoutManagementOpen}
          onClose={() => setIsScoutManagementOpen(false)}
          scouts={scouts}
          candidateScouts={candidateScouts}
          userBudget={currentTeam.budget}
          onHireScout={handleHireScout}
          onFireScout={handleFireScout}
        />
      )}

      {/* Country National Squad & Transfer Modal */}
      {countryModalName && (
        <CountrySquadModal
          isOpen={!!countryModalName}
          onClose={() => setCountryModalName(null)}
          countryName={countryModalName}
          allTeams={allTeams}
          userTeam={currentTeam}
          onTransferPlayer={handleTransferPlayer}
          showToast={showToast}
          onSelectPlayer={(p, t) => handleOpenPlayerProfile(p, t)}
        />
      )}

      {/* World Map & Continents Scouting Modal */}
      {isWorldScoutOpen && (
        <WorldScoutModal
          isOpen={isWorldScoutOpen}
          onClose={() => setIsWorldScoutOpen(false)}
          allTeams={allTeams}
          userTeam={currentTeam}
          onSelectPlayerProfile={handleOpenPlayerProfile}
          onTransferPlayer={handleTransferPlayer}
          showToast={showToast}
        />
      )}

      {/* Full Squad Vertical List Modal (Alt Alta Tüm Takım Oyuncuları) */}
      {isFullSquadModalOpen && (
        <div className="fixed inset-0 z-[9980] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-fadeIn">
          <div className="bg-[#181528] border-2 border-[#3d2f63] rounded-2xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
            
            {/* Header */}
            <div className="p-3.5 bg-[#120f21] border-b border-[#2d244c] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-purple-600/20 border border-purple-500/40 text-purple-300 font-extrabold text-sm">
                  📋
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-sm sm:text-base">
                    {currentTeam.name} - {t('TEAM_SQUAD_TITLE')}
                  </h3>
                  <p className="text-[10px] text-slate-400">
                    {t('TOTAL_PLAYERS_LABEL').replace('{count}', String(currentTeam.players.length))} • {t('FORMATION_LABEL')}: {currentTeam.formation}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setIsFullSquadModalOpen(false);
                    setActiveTab('TACTICS');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600 text-purple-200 hover:text-white font-extrabold text-xs border border-purple-500/40 transition-all"
                >
                  {t('GO_TO_TACTICAL_PITCH')} ⚽
                </button>
                <button
                  onClick={() => setIsFullSquadModalOpen(false)}
                  className="p-1.5 rounded-xl bg-[#271f45] hover:bg-[#392e63] text-slate-300 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Players Table (Alt Alta Oyuncu Listesi) */}
            <div className="p-3 sm:p-4 overflow-y-auto flex-1 space-y-2 custom-scrollbar">
              <div className="grid grid-cols-1 gap-2">
                {currentTeam.players.map((p, index) => (
                  <div
                    key={p.id}
                    onClick={() => {
                      handleOpenPlayerProfile(p, currentTeam);
                    }}
                    className={`border p-3 rounded-xl flex items-center justify-between cursor-pointer transition-all group ${
                      p.isLoaned
                        ? 'bg-[#1e172e] border-amber-500/50 hover:border-amber-400'
                        : 'bg-[#120f21] border-[#282142] hover:border-purple-500/60 hover:bg-[#1f1938]'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="text-xs font-black text-slate-500 w-5 text-center">
                        {index + 1}
                      </span>
                      <div className={`w-9 h-9 rounded-xl border flex items-center justify-center font-black text-sm shrink-0 ${
                        p.isLoaned ? 'bg-amber-500/20 border-amber-500/50 text-amber-300' : 'bg-purple-600/20 border-purple-500/40 text-amber-300'
                      }`}>
                        {p.overall}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-extrabold text-sm text-white group-hover:text-purple-300 transition-colors truncate">
                            {p.name}
                          </span>
                          <span className="px-2 py-0.5 text-[10px] font-black bg-purple-950 border border-purple-500/40 text-purple-300 rounded-md shrink-0">
                            {p.specificRole || p.position}
                          </span>
                          {p.isLoaned && (
                            <span className="px-2 py-0.5 text-[10px] font-black bg-amber-500/20 border border-amber-500/50 text-amber-300 rounded-md shrink-0 flex items-center gap-1">
                              🔄 {t('LOANED_LABEL')} ({p.parentClubName || t('PERMANENT_TRANSFER')})
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5 flex-wrap">
                          <span>{p.age} {t('YEARS_OLD')}</span>
                          <span>•</span>
                          <span>🌐 {p.nationality || 'Türkiye'}</span>
                          <span>•</span>
                          <span className="text-purple-300 font-extrabold">👕 {p.appearances || 0} Maç</span>
                          <span>•</span>
                          <span className="text-emerald-400 font-extrabold">⚽ {p.goalsScored || 0} Gol</span>
                          <span>•</span>
                          <span className="text-sky-400 font-extrabold">🅰️ {p.assists || 0} Asist</span>
                          <span>•</span>
                          <span className="text-amber-400 font-extrabold">🟨 {p.yellowCards || 0} Sarı</span>
                          <span>•</span>
                          <span className="text-rose-400 font-extrabold">🟥 {p.redCards || 0} Kır.</span>
                          <span>•</span>
                          <span>{t('FORM_LABEL')}: %{Math.round((p.form || 7.5) * 10)}</span>
                          <span>•</span>
                          <span>{t('ENERGY_LABEL')}: %{p.stamina ?? 100}</span>
                          {p.isLoaned && (
                            <>
                              <span>•</span>
                              <span className="text-amber-400 font-bold">{t('LOAN_END_LABEL')}: 30 Haziran 2026</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right hidden sm:block">
                        <span className="text-[10px] text-slate-400 font-bold block">{t('MARKET_VALUE')}</span>
                        <span className="text-xs font-black text-amber-300">
                          €{((p.marketValue || 5000000) / 1_000_000).toFixed(1)}M
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* FMM Inbox Messages Modal */}
      {isInboxOpen && (
        <InboxModal
          isOpen={isInboxOpen}
          onClose={() => setIsInboxOpen(false)}
          team={currentTeam}
          allTeams={allTeams}
          messages={inboxMessages}
          onToggleRead={handleToggleInboxRead}
          onMarkAllRead={handleMarkAllInboxRead}
          onGoToTacticsWithRecommended={handleGoToTacticsWithRecommended}
          onOpenContractNegotiation={handleOpenContractNegotiation}
          onOpenPlayerProfile={(p, t) => {
            setOpenedFromInbox(true);
            setIsInboxOpen(false);
            handleOpenPlayerProfile(p, t);
          }}
          onOpenTeamModal={(t) => {
            setOpenedFromInbox(true);
            setIsInboxOpen(false);
            setTeamDetailModalData(ensureTeamHas20Players(t));
          }}
        />
      )}

      {/* Team Detail Modal */}
      {teamDetailModalData && (
        <TeamDetailModal
          isOpen={!!teamDetailModalData}
          onClose={() => {
            setTeamDetailModalData(null);
            if (openedFromInbox) {
              setIsInboxOpen(true);
              setOpenedFromInbox(false);
            }
          }}
          team={teamDetailModalData}
          allTeams={allTeams}
          fixtures={fixtures}
          userTeamId={currentTeam.id}
          onSelectPlayerProfile={handleOpenPlayerProfile}
        />
      )}

      {/* Player Comparison Modal */}
      {isPlayerComparisonOpen && (
        <PlayerComparisonModal
          isOpen={isPlayerComparisonOpen}
          onClose={() => setIsPlayerComparisonOpen(false)}
          allTeams={allTeams}
          userTeam={currentTeam}
          onOpenPlayerProfile={handleOpenPlayerProfile}
        />
      )}

      {/* Press Conference Modal */}
      {showPressConference && (
        <PressConferenceModal
          isOpen={showPressConference}
          manager={manager}
          team={currentTeam}
          onComplete={handlePressConferenceComplete}
        />
      )}

      {/* Match Comparison & Tactical Analysis Modal */}
      {isMatchComparisonOpen && (
        <MatchComparisonModal
          isOpen={isMatchComparisonOpen}
          onClose={() => setIsMatchComparisonOpen(false)}
          homeTeam={currentWeekFixture?.homeTeamId === currentTeam.id ? currentTeam : opponentTeam}
          awayTeam={currentWeekFixture?.homeTeamId === currentTeam.id ? opponentTeam : currentTeam}
          userTeam={currentTeam}
          currentWeek={currentWeek}
          fixture={currentWeekFixture}
          onGoToTactics={() => setActiveTab('TACTICS')}
          onStartPreMatch={() => setIsPreMatchOpen(true)}
        />
      )}

      {/* Start Game & Saved Career Modal */}
      <CareerStartModal
        isOpen={isCareerModalOpen}
        initialMode={careerModalMode}
        allTeams={allTeams}
        onStartNewGame={handleStartNewGame}
        onLoadSavedGame={handleLoadSavedGame}
        onClose={() => {
          setIsCareerModalOpen(false);
          setShowMainMenu(true);
        }}
      />

      {/* Main Menu Screen Overlay */}
      {showMainMenu && (
        <MainMenuModal
          onStartNewGame={() => {
            setCareerModalMode('NEW_CAREER');
            setShowMainMenu(false);
            setIsCareerModalOpen(true);
          }}
          onContinueGame={() => {
            if (activeCareerId) {
              setShowMainMenu(false);
            } else {
              setCareerModalMode('NEW_CAREER');
              setShowMainMenu(false);
              setIsCareerModalOpen(true);
            }
          }}
          onOpenSavedGames={() => {
            setCareerModalMode('LOAD_CAREER');
            setShowMainMenu(false);
            setIsCareerModalOpen(true);
          }}
          hasActiveGame={!!activeCareerId}
          activeSaveInfo={null}
          onResetData={handleResetAllData}
          onOpenWorldScout={() => setIsWorldScoutOpen(true)}
        />
      )}

      {/* Initial Animated Splash Screen */}
      {showSplash && (
        <SplashScreen
          onFinishLoading={() => {
            setShowSplash(false);
            setShowMainMenu(true);
          }}
        />
      )}

      {/* Board Confidence Analysis Modal */}
      <BoardConfidenceModal
        isOpen={isBoardConfidenceModalOpen}
        onClose={() => setIsBoardConfidenceModalOpen(false)}
        currentTeam={currentTeam}
        currentRank={currentRank}
        totalTeams={allTeams.length}
        points={currentTeamStanding?.points || 0}
        won={currentTeamStanding?.won || 0}
        drawn={currentTeamStanding?.drawn || 0}
        lost={currentTeamStanding?.lost || 0}
        form={currentTeamStanding?.form || []}
        boardConfidence={calculateBoardConfidence(
          currentRank,
          allTeams.length,
          currentTeamStanding?.played || 0,
          currentTeam,
          currentTeamStanding?.won || 0,
          currentTeamStanding?.drawn || 0,
          currentTeamStanding?.lost || 0,
          currentTeamStanding?.form || []
        )}
      />

      {/* Vacation Setup Modal */}
      <VacationModal
        isOpen={isVacationModalOpen}
        onClose={() => setIsVacationModalOpen(false)}
        onStartVacation={handleStartVacation}
        vacationPolicy={vacationOfferPolicy}
        onUpdateVacationPolicy={setVacationOfferPolicy}
      />

      {/* Vacation Active Running Banner/Overlay */}
      <VacationOverlay
        isActive={isVacationActive}
        totalDays={vacationDaysTotal}
        daysElapsed={vacationDaysElapsed}
        matchesPlayed={vacationSimulatedMatches}
        currentDayName={DAY_NAMES[currentDayIndex] || 'Maç Günü'}
        currentWeek={currentWeek}
        currentSeason={currentSeason}
        currentDayIndex={currentDayIndex}
        onStopVacation={handleStopVacation}
      />

    </div>
  );
}

