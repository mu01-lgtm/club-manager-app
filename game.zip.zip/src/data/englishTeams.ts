import { ExternalTeamData } from '../components/WorldScoutModal';

export const ENGLISH_TEAMS: ExternalTeamData[] = [
  // 1. Manchester City
  {
    id: 'manchester-city',
    name: 'Manchester City',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Etihad Stadium',
    manager: 'Pep Guardiola',
    overall: 88,
    budget: 150000000,
    badgeColor: 'from-sky-400 to-blue-600',
    shortName: 'MCI',
    players: [
      { id: 'mci-1', name: 'Ederson', age: 30, position: 'GK', specificRole: 'GK', overall: 88, stamina: 90, form: 8.2, marketValue: 35000000, wage: 31429, nationality: 'Brezilya', attributes: { pace: 58, shooting: 15, passing: 92, defending: 87, physical: 82 }, isStarting: true },
      { id: 'mci-2', name: 'Kyle Walker', age: 34, position: 'DEF', specificRole: 'RB', overall: 84, stamina: 85, form: 7.9, marketValue: 12000000, wage: 36000, nationality: 'İngiltere', attributes: { pace: 88, shooting: 60, passing: 74, defending: 83, physical: 84 }, isStarting: true },
      { id: 'mci-3', name: 'Ruben Dias', age: 27, position: 'DEF', specificRole: 'CB', overall: 88, stamina: 93, form: 8.5, marketValue: 80000000, wage: 34286, nationality: 'Portekiz', attributes: { pace: 74, shooting: 40, passing: 75, defending: 89, physical: 88 }, isStarting: true },
      { id: 'mci-3b', name: 'Manuel Akanji', age: 29, position: 'DEF', specificRole: 'CB', overall: 85, stamina: 90, form: 8.3, marketValue: 42000000, wage: 28000, nationality: 'İsviçre', attributes: { pace: 78, shooting: 45, passing: 76, defending: 85, physical: 84 }, isStarting: true },
      { id: 'mci-3c', name: 'Josko Gvardiol', age: 22, position: 'DEF', specificRole: 'LB', overall: 86, stamina: 92, form: 8.6, marketValue: 75000000, wage: 30000, nationality: 'Hırvatistan', attributes: { pace: 82, shooting: 62, passing: 80, defending: 86, physical: 85 }, isStarting: true },
      { id: 'mci-4', name: 'Rodri', age: 28, position: 'MID', specificRole: 'CDM', overall: 91, stamina: 96, form: 9.2, marketValue: 130000000, wage: 45714, nationality: 'İspanya', attributes: { pace: 72, shooting: 80, passing: 90, defending: 89, physical: 89 }, isStarting: true },
      { id: 'mci-5', name: 'Kevin De Bruyne', age: 33, position: 'MID', specificRole: 'CAM', overall: 90, stamina: 86, form: 8.8, marketValue: 50000000, wage: 57143, nationality: 'Belçika', attributes: { pace: 72, shooting: 88, passing: 94, defending: 65, physical: 75 }, isStarting: true },
      { id: 'mci-6', name: 'Bernardo Silva', age: 29, position: 'MID', specificRole: 'CM', overall: 87, stamina: 94, form: 8.6, marketValue: 70000000, wage: 42857, nationality: 'Portekiz', attributes: { pace: 76, shooting: 78, passing: 89, defending: 68, physical: 70 }, isStarting: true },
      { id: 'mci-7', name: 'Phil Foden', age: 24, position: 'FW', specificRole: 'RW', overall: 89, stamina: 93, form: 8.9, marketValue: 150000000, wage: 40000, nationality: 'İngiltere', attributes: { pace: 85, shooting: 86, passing: 89, defending: 55, physical: 70 }, isStarting: true },
      { id: 'mci-8', name: 'Erling Haaland', age: 24, position: 'FW', specificRole: 'ST', overall: 91, stamina: 92, form: 9.4, marketValue: 180000000, wage: 54286, nationality: 'Norveç', attributes: { pace: 89, shooting: 93, passing: 68, defending: 45, physical: 88 }, isStarting: true },
      { id: 'mci-9', name: 'Jeremy Doku', age: 22, position: 'FW', specificRole: 'LW', overall: 83, stamina: 90, form: 8.2, marketValue: 60000000, wage: 25000, nationality: 'Belçika', attributes: { pace: 93, shooting: 74, passing: 78, defending: 35, physical: 72 }, isStarting: true },
      { id: 'mci-10', name: 'Stefan Ortega', age: 31, position: 'GK', specificRole: 'GK', overall: 81, stamina: 85, form: 8.0, marketValue: 12000000, wage: 18000, nationality: 'Almanya', attributes: { pace: 52, shooting: 15, passing: 82, defending: 81, physical: 78 }, isStarting: false },
      { id: 'mci-11', name: 'John Stones', age: 30, position: 'DEF', specificRole: 'CB', overall: 86, stamina: 88, form: 8.4, marketValue: 40000000, wage: 32000, nationality: 'İngiltere', attributes: { pace: 74, shooting: 55, passing: 85, defending: 87, physical: 82 }, isStarting: false },
      { id: 'mci-12', name: 'Nathan Ake', age: 29, position: 'DEF', specificRole: 'CB', overall: 84, stamina: 89, form: 8.2, marketValue: 35000000, wage: 26000, nationality: 'Hollanda', attributes: { pace: 76, shooting: 50, passing: 78, defending: 85, physical: 82 }, isStarting: false },
      { id: 'mci-13', name: 'Rico Lewis', age: 19, position: 'DEF', specificRole: 'RB', overall: 80, stamina: 92, form: 8.3, marketValue: 38000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 82, shooting: 60, passing: 82, defending: 78, physical: 72 }, isStarting: false },
      { id: 'mci-14', name: 'Mateo Kovacic', age: 30, position: 'MID', specificRole: 'CM', overall: 84, stamina: 88, form: 8.2, marketValue: 30000000, wage: 28000, nationality: 'Hırvatistan', attributes: { pace: 75, shooting: 70, passing: 86, defending: 76, physical: 78 }, isStarting: false },
      { id: 'mci-15', name: 'Ilkay Gündogan', age: 33, position: 'MID', specificRole: 'CM', overall: 85, stamina: 86, form: 8.2, marketValue: 15000000, wage: 32000, nationality: 'Almanya', attributes: { pace: 65, shooting: 80, passing: 88, defending: 72, physical: 72 }, isStarting: false },
      { id: 'mci-16', name: 'Matheus Nunes', age: 25, position: 'MID', specificRole: 'CM', overall: 81, stamina: 90, form: 8.0, marketValue: 35000000, wage: 22000, nationality: 'Portekiz', attributes: { pace: 82, shooting: 72, passing: 80, defending: 74, physical: 78 }, isStarting: false },
      { id: 'mci-17', name: 'Savinho', age: 20, position: 'FW', specificRole: 'RW', overall: 82, stamina: 88, form: 8.3, marketValue: 45000000, wage: 20000, nationality: 'Brezilya', attributes: { pace: 88, shooting: 76, passing: 80, defending: 40, physical: 68 }, isStarting: false },
      { id: 'mci-18', name: 'Jack Grealish', age: 28, position: 'FW', specificRole: 'LW', overall: 84, stamina: 88, form: 8.1, marketValue: 50000000, wage: 35000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 78, passing: 85, defending: 48, physical: 76 }, isStarting: false },
      { id: 'mci-19', name: 'Oscar Bobb', age: 21, position: 'FW', specificRole: 'RW', overall: 79, stamina: 89, form: 8.2, marketValue: 25000000, wage: 15000, nationality: 'Norveç', attributes: { pace: 85, shooting: 76, passing: 80, defending: 40, physical: 68 }, isStarting: false },
      { id: 'mci-20', name: 'James McAtee', age: 21, position: 'MID', specificRole: 'CAM', overall: 77, stamina: 88, form: 8.0, marketValue: 18000000, wage: 12000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 72, passing: 78, defending: 45, physical: 68 }, isStarting: false }
    ]
  },

  // 2. Arsenal
  {
    id: 'arsenal',
    name: 'Arsenal',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Emirates Stadium',
    manager: 'Mikel Arteta',
    overall: 87,
    budget: 120000000,
    badgeColor: 'from-red-600 to-red-800',
    shortName: 'ARS',
    players: [
      { id: 'ars-1', name: 'David Raya', age: 28, position: 'GK', specificRole: 'GK', overall: 85, stamina: 88, form: 8.4, marketValue: 35000000, wage: 22857, nationality: 'İspanya', attributes: { pace: 50, shooting: 15, passing: 85, defending: 85, physical: 78 }, isStarting: true, number: 22 },
      { id: 'ars-timber', name: 'Jurriën Timber', age: 23, position: 'DEF', specificRole: 'LB', overall: 82, stamina: 89, form: 8.1, marketValue: 40000000, wage: 24000, nationality: 'Hollanda', attributes: { pace: 83, shooting: 52, passing: 77, defending: 82, physical: 80 }, isStarting: true, number: 12 },
      { id: 'ars-gabriel', name: 'Gabriel Magalhães', age: 26, position: 'DEF', specificRole: 'CB', overall: 86, stamina: 93, form: 8.7, marketValue: 70000000, wage: 30000, nationality: 'Brezilya', attributes: { pace: 76, shooting: 50, passing: 72, defending: 87, physical: 88 }, isStarting: true, number: 6 },
      { id: 'ars-saliba', name: 'William Saliba', age: 23, position: 'DEF', specificRole: 'CB', overall: 88, stamina: 94, form: 8.9, marketValue: 80000000, wage: 34286, nationality: 'Fransa', attributes: { pace: 82, shooting: 40, passing: 78, defending: 89, physical: 86 }, isStarting: true, number: 2 },
      { id: 'ars-white', name: 'Ben White', age: 26, position: 'DEF', specificRole: 'RB', overall: 84, stamina: 92, form: 8.3, marketValue: 55000000, wage: 28571, nationality: 'İngiltere', attributes: { pace: 78, shooting: 55, passing: 78, defending: 84, physical: 80 }, isStarting: true, number: 4 },
      { id: 'ars-merino', name: 'Mikel Merino', age: 28, position: 'MID', specificRole: 'CM', overall: 83, stamina: 91, form: 8.2, marketValue: 40000000, wage: 25000, nationality: 'İspanya', attributes: { pace: 72, shooting: 74, passing: 82, defending: 81, physical: 85 }, isStarting: true, number: 23 },
      { id: 'ars-rice', name: 'Declan Rice', age: 25, position: 'MID', specificRole: 'CDM', overall: 87, stamina: 97, form: 8.7, marketValue: 110000000, wage: 34286, nationality: 'İngiltere', attributes: { pace: 78, shooting: 75, passing: 84, defending: 87, physical: 88 }, isStarting: true, number: 41 },
      { id: 'ars-odegaard', name: 'Martin Ødegaard', age: 25, position: 'MID', specificRole: 'CAM', overall: 89, stamina: 95, form: 8.8, marketValue: 110000000, wage: 38571, nationality: 'Norveç', attributes: { pace: 76, shooting: 82, passing: 91, defending: 62, physical: 72 }, isStarting: true, number: 8 },
      { id: 'ars-martinelli', name: 'Gabriel Martinelli', age: 23, position: 'FW', specificRole: 'LW', overall: 84, stamina: 92, form: 8.2, marketValue: 70000000, wage: 28571, nationality: 'Brezilya', attributes: { pace: 89, shooting: 80, passing: 78, defending: 45, physical: 76 }, isStarting: true, number: 11 },
      { id: 'ars-havertz', name: 'Kai Havertz', age: 25, position: 'FW', specificRole: 'ST', overall: 84, stamina: 91, form: 8.4, marketValue: 65000000, wage: 31429, nationality: 'Almanya', attributes: { pace: 80, shooting: 81, passing: 80, defending: 55, physical: 80 }, isStarting: true, number: 29 },
      { id: 'ars-saka', name: 'Bukayo Saka', age: 22, position: 'FW', specificRole: 'RW', overall: 88, stamina: 94, form: 8.9, marketValue: 140000000, wage: 35714, nationality: 'İngiltere', attributes: { pace: 88, shooting: 84, passing: 86, defending: 60, physical: 78 }, isStarting: true, number: 7 },
      { id: 'ars-9', name: 'Neto', age: 35, position: 'GK', specificRole: 'GK', overall: 78, stamina: 82, form: 7.8, marketValue: 5000000, wage: 12000, nationality: 'Brezilya', attributes: { pace: 50, shooting: 15, passing: 72, defending: 78, physical: 74 }, isStarting: false, number: 32 },
      { id: 'ars-10', name: 'Riccardo Calafiori', age: 22, position: 'DEF', specificRole: 'LB', overall: 82, stamina: 88, form: 8.2, marketValue: 45000000, wage: 20000, nationality: 'İtalya', attributes: { pace: 79, shooting: 58, passing: 76, defending: 83, physical: 82 }, isStarting: false, number: 33 },
      { id: 'ars-11', name: 'Oleksandr Zinchenko', age: 27, position: 'DEF', specificRole: 'LB', overall: 80, stamina: 86, form: 7.9, marketValue: 28000000, wage: 22000, nationality: 'Ukrayna', attributes: { pace: 74, shooting: 65, passing: 84, defending: 75, physical: 70 }, isStarting: false, number: 17 },
      { id: 'ars-12', name: 'Takehiro Tomiyasu', age: 25, position: 'DEF', specificRole: 'RB', overall: 80, stamina: 85, form: 8.0, marketValue: 25000000, wage: 18000, nationality: 'Japonya', attributes: { pace: 76, shooting: 50, passing: 74, defending: 81, physical: 80 }, isStarting: false, number: 18 },
      { id: 'ars-13', name: 'Jakub Kiwior', age: 24, position: 'DEF', specificRole: 'CB', overall: 78, stamina: 88, form: 8.0, marketValue: 22000000, wage: 15000, nationality: 'Polonya', attributes: { pace: 75, shooting: 45, passing: 72, defending: 78, physical: 78 }, isStarting: false, number: 15 },
      { id: 'ars-14', name: 'Thomas Partey', age: 31, position: 'MID', specificRole: 'CDM', overall: 82, stamina: 85, form: 8.1, marketValue: 20000000, wage: 28000, nationality: 'Gana', attributes: { pace: 68, shooting: 72, passing: 82, defending: 82, physical: 82 }, isStarting: false, number: 5 },
      { id: 'ars-15', name: 'Jorginho', age: 32, position: 'MID', specificRole: 'CDM', overall: 81, stamina: 82, form: 8.0, marketValue: 12000000, wage: 22000, nationality: 'İtalya', attributes: { pace: 55, shooting: 68, passing: 88, defending: 74, physical: 68 }, isStarting: false, number: 20 },
      { id: 'ars-16', name: 'Ethan Nwaneri', age: 17, position: 'MID', specificRole: 'CAM', overall: 76, stamina: 90, form: 8.5, marketValue: 20000000, wage: 10000, nationality: 'İngiltere', attributes: { pace: 80, shooting: 74, passing: 78, defending: 45, physical: 68 }, isStarting: false, number: 53 },
      { id: 'ars-17', name: 'Leandro Trossard', age: 29, position: 'FW', specificRole: 'LW', overall: 83, stamina: 88, form: 8.3, marketValue: 35000000, wage: 22000, nationality: 'Belçika', attributes: { pace: 78, shooting: 82, passing: 81, defending: 42, physical: 68 }, isStarting: false, number: 19 },
      { id: 'ars-18', name: 'Gabriel Jesus', age: 27, position: 'FW', specificRole: 'ST', overall: 82, stamina: 86, form: 8.0, marketValue: 40000000, wage: 30000, nationality: 'Brezilya', attributes: { pace: 82, shooting: 80, passing: 78, defending: 48, physical: 76 }, isStarting: false, number: 9 },
      { id: 'ars-19', name: 'Raheem Sterling', age: 29, position: 'FW', specificRole: 'RW', overall: 81, stamina: 86, form: 8.0, marketValue: 30000000, wage: 32000, nationality: 'İngiltere', attributes: { pace: 86, shooting: 78, passing: 76, defending: 40, physical: 68 }, isStarting: false, number: 30 },
      { id: 'ars-20', name: 'Myles Lewis-Skelly', age: 17, position: 'DEF', specificRole: 'LB', overall: 74, stamina: 90, form: 8.3, marketValue: 12000000, wage: 8000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 55, passing: 76, defending: 74, physical: 72 }, isStarting: false, number: 49 }
    ]
  },

  // 3. Liverpool
  {
    id: 'liverpool',
    name: 'Liverpool',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Anfield',
    manager: 'Arne Slot',
    overall: 87,
    budget: 110000000,
    badgeColor: 'from-red-700 to-red-900',
    shortName: 'LIV',
    players: [
      { id: 'liv-1', name: 'Alisson Becker', age: 31, position: 'GK', specificRole: 'GK', overall: 89, stamina: 88, form: 8.7, marketValue: 45000000, wage: 34286, nationality: 'Brezilya', attributes: { pace: 55, shooting: 15, passing: 88, defending: 90, physical: 85 }, isStarting: true },
      { id: 'liv-bradley', name: 'Conor Bradley', age: 21, position: 'DEF', specificRole: 'RB', overall: 79, stamina: 90, form: 8.2, marketValue: 25000000, wage: 18000, nationality: 'Kuzey İrlanda', attributes: { pace: 84, shooting: 62, passing: 76, defending: 77, physical: 76 }, isStarting: true },
      { id: 'liv-3', name: 'Virgil van Dijk', age: 33, position: 'DEF', specificRole: 'CB', overall: 89, stamina: 90, form: 8.9, marketValue: 40000000, wage: 42857, nationality: 'Hollanda', attributes: { pace: 78, shooting: 60, passing: 78, defending: 90, physical: 89 }, isStarting: true },
      { id: 'liv-3b', name: 'Ibrahima Konate', age: 25, position: 'DEF', specificRole: 'CB', overall: 84, stamina: 88, form: 8.3, marketValue: 45000000, wage: 25000, nationality: 'Fransa', attributes: { pace: 80, shooting: 40, passing: 68, defending: 85, physical: 87 }, isStarting: true },
      { id: 'liv-3c', name: 'Andy Robertson', age: 30, position: 'DEF', specificRole: 'LB', overall: 85, stamina: 92, form: 8.2, marketValue: 35000000, wage: 28000, nationality: 'İskoçya', attributes: { pace: 82, shooting: 62, passing: 81, defending: 82, physical: 78 }, isStarting: true },
      { id: 'liv-4', name: 'Alexis Mac Allister', age: 25, position: 'MID', specificRole: 'CM', overall: 86, stamina: 93, form: 8.6, marketValue: 75000000, wage: 30000, nationality: 'Arjantin', attributes: { pace: 75, shooting: 80, passing: 87, defending: 79, physical: 80 }, isStarting: true },
      { id: 'liv-5', name: 'Dominik Szoboszlai', age: 23, position: 'MID', specificRole: 'CAM', overall: 84, stamina: 94, form: 8.3, marketValue: 65000000, wage: 27143, nationality: 'Macaristan', attributes: { pace: 84, shooting: 84, passing: 85, defending: 65, physical: 80 }, isStarting: true },
      { id: 'liv-5b', name: 'Ryan Gravenberch', age: 22, position: 'MID', specificRole: 'CDM', overall: 83, stamina: 90, form: 8.6, marketValue: 50000000, wage: 22000, nationality: 'Hollanda', attributes: { pace: 80, shooting: 74, passing: 83, defending: 79, physical: 82 }, isStarting: true },
      { id: 'liv-6', name: 'Mohamed Salah', age: 32, position: 'FW', specificRole: 'RW', overall: 89, stamina: 91, form: 9.1, marketValue: 65000000, wage: 50000, nationality: 'Mısır', attributes: { pace: 89, shooting: 89, passing: 84, defending: 45, physical: 78 }, isStarting: true },
      { id: 'liv-7', name: 'Luis Diaz', age: 27, position: 'FW', specificRole: 'LW', overall: 85, stamina: 92, form: 8.7, marketValue: 75000000, wage: 28000, nationality: 'Kolombiya', attributes: { pace: 91, shooting: 81, passing: 78, defending: 42, physical: 76 }, isStarting: true },
      { id: 'liv-8', name: 'Diogo Jota', age: 27, position: 'FW', specificRole: 'ST', overall: 84, stamina: 88, form: 8.4, marketValue: 50000000, wage: 26000, nationality: 'Portekiz', attributes: { pace: 83, shooting: 84, passing: 76, defending: 42, physical: 77 }, isStarting: true },
      { id: 'liv-9', name: 'Caoimhin Kelleher', age: 25, position: 'GK', specificRole: 'GK', overall: 80, stamina: 86, form: 8.2, marketValue: 20000000, wage: 16000, nationality: 'İrlanda', attributes: { pace: 50, shooting: 15, passing: 76, defending: 80, physical: 76 }, isStarting: false },
      { id: 'liv-10', name: 'Joe Gomez', age: 27, position: 'DEF', specificRole: 'CB', overall: 80, stamina: 88, form: 8.0, marketValue: 25000000, wage: 20000, nationality: 'İngiltere', attributes: { pace: 82, shooting: 45, passing: 72, defending: 80, physical: 80 }, isStarting: false },
      { id: 'liv-11', name: 'Jarell Quansah', age: 21, position: 'DEF', specificRole: 'CB', overall: 78, stamina: 89, form: 8.1, marketValue: 22000000, wage: 14000, nationality: 'İngiltere', attributes: { pace: 76, shooting: 40, passing: 74, defending: 78, physical: 82 }, isStarting: false },
      { id: 'liv-12', name: 'Kostas Tsimikas', age: 28, position: 'DEF', specificRole: 'LB', overall: 78, stamina: 87, form: 7.9, marketValue: 18000000, wage: 18000, nationality: 'Yunanistan', attributes: { pace: 80, shooting: 58, passing: 76, defending: 76, physical: 74 }, isStarting: false },
      { id: 'liv-13', name: 'Wataru Endo', age: 31, position: 'MID', specificRole: 'CDM', overall: 80, stamina: 88, form: 8.1, marketValue: 15000000, wage: 20000, nationality: 'Japonya', attributes: { pace: 68, shooting: 65, passing: 76, defending: 81, physical: 82 }, isStarting: false },
      { id: 'liv-14', name: 'Curtis Jones', age: 23, position: 'MID', specificRole: 'CM', overall: 80, stamina: 91, form: 8.3, marketValue: 35000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 74, passing: 82, defending: 74, physical: 76 }, isStarting: false },
      { id: 'liv-15', name: 'Harvey Elliott', age: 21, position: 'MID', specificRole: 'CAM', overall: 79, stamina: 90, form: 8.2, marketValue: 32000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 76, passing: 82, defending: 52, physical: 68 }, isStarting: false },
      { id: 'liv-16', name: 'Cody Gakpo', age: 25, position: 'FW', specificRole: 'LW', overall: 83, stamina: 89, form: 8.2, marketValue: 50000000, wage: 24000, nationality: 'Hollanda', attributes: { pace: 85, shooting: 82, passing: 79, defending: 40, physical: 79 }, isStarting: false },
      { id: 'liv-17', name: 'Federico Chiesa', age: 26, position: 'FW', specificRole: 'RW', overall: 83, stamina: 86, form: 8.1, marketValue: 35000000, wage: 25000, nationality: 'İtalya', attributes: { pace: 88, shooting: 80, passing: 76, defending: 48, physical: 74 }, isStarting: false },
      { id: 'liv-18', name: 'Darwin Nuñez', age: 25, position: 'FW', specificRole: 'ST', overall: 83, stamina: 90, form: 8.1, marketValue: 65000000, wage: 28000, nationality: 'Uruguay', attributes: { pace: 90, shooting: 81, passing: 70, defending: 42, physical: 86 }, isStarting: false }
    ]
  },

  // 4. Chelsea
  {
    id: 'chelsea',
    name: 'Chelsea',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Stamford Bridge',
    manager: 'Enzo Maresca',
    overall: 85,
    budget: 130000000,
    badgeColor: 'from-blue-600 to-blue-900',
    shortName: 'CHE',
    players: [
      { id: 'che-1', name: 'Robert Sanchez', age: 26, position: 'GK', specificRole: 'GK', overall: 80, stamina: 86, form: 7.9, marketValue: 20000000, wage: 17143, nationality: 'İspanya', attributes: { pace: 50, shooting: 15, passing: 75, defending: 80, physical: 80 }, isStarting: true },
      { id: 'che-2', name: 'Reece James', age: 24, position: 'DEF', specificRole: 'RB', overall: 84, stamina: 85, form: 8.2, marketValue: 50000000, wage: 28571, nationality: 'İngiltere', attributes: { pace: 82, shooting: 74, passing: 82, defending: 83, physical: 86 }, isStarting: true },
      { id: 'che-3', name: 'Wesley Fofana', age: 23, position: 'DEF', specificRole: 'CB', overall: 81, stamina: 86, form: 8.0, marketValue: 35000000, wage: 22000, nationality: 'Fransa', attributes: { pace: 78, shooting: 40, passing: 70, defending: 82, physical: 82 }, isStarting: true },
      { id: 'che-4', name: 'Levi Colwill', age: 21, position: 'DEF', specificRole: 'CB', overall: 82, stamina: 90, form: 8.2, marketValue: 50000000, wage: 20000, nationality: 'İngiltere', attributes: { pace: 76, shooting: 45, passing: 78, defending: 82, physical: 82 }, isStarting: true },
      { id: 'che-5', name: 'Marc Cucurella', age: 26, position: 'DEF', specificRole: 'LB', overall: 83, stamina: 91, form: 8.4, marketValue: 40000000, wage: 24000, nationality: 'İspanya', attributes: { pace: 80, shooting: 60, passing: 76, defending: 82, physical: 80 }, isStarting: true },
      { id: 'che-6', name: 'Moises Caicedo', age: 22, position: 'MID', specificRole: 'CDM', overall: 85, stamina: 95, form: 8.6, marketValue: 80000000, wage: 28571, nationality: 'Ekvador', attributes: { pace: 78, shooting: 68, passing: 82, defending: 85, physical: 85 }, isStarting: true },
      { id: 'che-7', name: 'Enzo Fernandez', age: 23, position: 'MID', specificRole: 'CM', overall: 84, stamina: 92, form: 8.2, marketValue: 75000000, wage: 30000, nationality: 'Arjantin', attributes: { pace: 72, shooting: 76, passing: 87, defending: 78, physical: 78 }, isStarting: true },
      { id: 'che-8', name: 'Cole Palmer', age: 22, position: 'MID', specificRole: 'CAM', overall: 88, stamina: 93, form: 9.1, marketValue: 110000000, wage: 38000, nationality: 'İngiltere', attributes: { pace: 82, shooting: 87, passing: 89, defending: 52, physical: 74 }, isStarting: true },
      { id: 'che-9', name: 'Noni Madueke', age: 22, position: 'FW', specificRole: 'RW', overall: 81, stamina: 90, form: 8.1, marketValue: 40000000, wage: 20000, nationality: 'İngiltere', attributes: { pace: 89, shooting: 78, passing: 76, defending: 40, physical: 72 }, isStarting: true },
      { id: 'che-10', name: 'Nicolas Jackson', age: 23, position: 'FW', specificRole: 'ST', overall: 82, stamina: 91, form: 8.3, marketValue: 50000000, wage: 22000, nationality: 'Senegal', attributes: { pace: 87, shooting: 81, passing: 72, defending: 38, physical: 81 }, isStarting: true },
      { id: 'che-11', name: 'Pedro Neto', age: 24, position: 'FW', specificRole: 'LW', overall: 82, stamina: 88, form: 8.2, marketValue: 50000000, wage: 24000, nationality: 'Portekiz', attributes: { pace: 90, shooting: 78, passing: 80, defending: 42, physical: 70 }, isStarting: true },
      { id: 'che-12', name: 'Filip Jørgensen', age: 22, position: 'GK', specificRole: 'GK', overall: 78, stamina: 86, form: 7.9, marketValue: 18000000, wage: 14000, nationality: 'Danimarka', attributes: { pace: 50, shooting: 15, passing: 74, defending: 78, physical: 76 }, isStarting: false },
      { id: 'che-13', name: 'Malo Gusto', age: 21, position: 'DEF', specificRole: 'RB', overall: 80, stamina: 92, form: 8.3, marketValue: 35000000, wage: 18000, nationality: 'Fransa', attributes: { pace: 86, shooting: 60, passing: 76, defending: 78, physical: 78 }, isStarting: false },
      { id: 'che-14', name: 'Tosin Adarabioyo', age: 26, position: 'DEF', specificRole: 'CB', overall: 79, stamina: 88, form: 8.0, marketValue: 22000000, wage: 16000, nationality: 'İngiltere', attributes: { pace: 72, shooting: 40, passing: 70, defending: 80, physical: 84 }, isStarting: false },
      { id: 'che-15', name: 'Benoît Badiashile', age: 23, position: 'DEF', specificRole: 'CB', overall: 79, stamina: 87, form: 7.9, marketValue: 25000000, wage: 18000, nationality: 'Fransa', attributes: { pace: 74, shooting: 42, passing: 72, defending: 80, physical: 83 }, isStarting: false },
      { id: 'che-16', name: 'Romeo Lavia', age: 20, position: 'MID', specificRole: 'CDM', overall: 79, stamina: 88, form: 8.1, marketValue: 35000000, wage: 18000, nationality: 'Belçika', attributes: { pace: 76, shooting: 65, passing: 80, defending: 78, physical: 80 }, isStarting: false },
      { id: 'che-17', name: 'Kiernan Dewsbury-Hall', age: 25, position: 'MID', specificRole: 'CM', overall: 80, stamina: 91, form: 8.2, marketValue: 30000000, wage: 20000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 74, passing: 80, defending: 74, physical: 78 }, isStarting: false },
      { id: 'che-18', name: 'Joao Felix', age: 24, position: 'FW', specificRole: 'CAM', overall: 82, stamina: 87, form: 8.2, marketValue: 45000000, wage: 28000, nationality: 'Portekiz', attributes: { pace: 82, shooting: 80, passing: 83, defending: 42, physical: 70 }, isStarting: false },
      { id: 'che-19', name: 'Christopher Nkunku', age: 26, position: 'FW', specificRole: 'CAM', overall: 84, stamina: 86, form: 8.1, marketValue: 60000000, wage: 30000, nationality: 'Fransa', attributes: { pace: 84, shooting: 83, passing: 82, defending: 45, physical: 74 }, isStarting: false },
      { id: 'che-20', name: 'Jadon Sancho', age: 24, position: 'FW', specificRole: 'LW', overall: 81, stamina: 88, form: 8.0, marketValue: 45000000, wage: 28000, nationality: 'İngiltere', attributes: { pace: 84, shooting: 76, passing: 82, defending: 38, physical: 68 }, isStarting: false },
      { id: 'che-21', name: 'Marcus Bettinelli', age: 32, position: 'GK', specificRole: 'GK', overall: 72, stamina: 82, form: 7.5, marketValue: 2000000, wage: 8000, nationality: 'İngiltere', attributes: { pace: 45, shooting: 15, passing: 65, defending: 73, physical: 72 }, isStarting: false },
      { id: 'che-22', name: 'Lucas Bergström', age: 21, position: 'GK', specificRole: 'GK', overall: 68, stamina: 80, form: 7.4, marketValue: 1000000, wage: 5000, nationality: 'Finlandiya', attributes: { pace: 45, shooting: 15, passing: 60, defending: 69, physical: 70 }, isStarting: false },
      { id: 'che-23', name: 'Axel Disasi', age: 26, position: 'DEF', specificRole: 'CB', overall: 79, stamina: 88, form: 7.9, marketValue: 28000000, wage: 20000, nationality: 'Fransa', attributes: { pace: 70, shooting: 40, passing: 68, defending: 80, physical: 85 }, isStarting: false },
      { id: 'che-24', name: 'Trevoh Chalobah', age: 25, position: 'DEF', specificRole: 'CB', overall: 78, stamina: 87, form: 7.9, marketValue: 22000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 74, shooting: 42, passing: 70, defending: 79, physical: 80 }, isStarting: false },
      { id: 'che-25', name: 'Renato Veiga', age: 21, position: 'DEF', specificRole: 'LB', overall: 77, stamina: 90, form: 8.1, marketValue: 20000000, wage: 15000, nationality: 'Portekiz', attributes: { pace: 78, shooting: 62, passing: 74, defending: 77, physical: 82 }, isStarting: false },
      { id: 'che-26', name: 'Ben Chilwell', age: 27, position: 'DEF', specificRole: 'LB', overall: 79, stamina: 84, form: 7.7, marketValue: 22000000, wage: 25000, nationality: 'İngiltere', attributes: { pace: 80, shooting: 65, passing: 76, defending: 78, physical: 74 }, isStarting: false },
      { id: 'che-27', name: 'Josh Acheampong', age: 18, position: 'DEF', specificRole: 'RB', overall: 72, stamina: 88, form: 8.0, marketValue: 8000000, wage: 6000, nationality: 'İngiltere', attributes: { pace: 82, shooting: 50, passing: 70, defending: 72, physical: 72 }, isStarting: false },
      { id: 'che-28', name: 'Cesare Casadei', age: 21, position: 'MID', specificRole: 'CM', overall: 75, stamina: 88, form: 7.9, marketValue: 15000000, wage: 12000, nationality: 'İtalya', attributes: { pace: 74, shooting: 72, passing: 75, defending: 70, physical: 80 }, isStarting: false },
      { id: 'che-29', name: 'Carney Chukwuemeka', age: 20, position: 'MID', specificRole: 'CAM', overall: 76, stamina: 88, form: 8.0, marketValue: 18000000, wage: 14000, nationality: 'İngiltere', attributes: { pace: 80, shooting: 74, passing: 78, defending: 58, physical: 76 }, isStarting: false },
      { id: 'che-30', name: 'Mykhailo Mudryk', age: 23, position: 'FW', specificRole: 'LW', overall: 78, stamina: 88, form: 7.8, marketValue: 30000000, wage: 22000, nationality: 'Ukrayna', attributes: { pace: 94, shooting: 74, passing: 72, defending: 35, physical: 68 }, isStarting: false },
      { id: 'che-31', name: 'Marc Guiu', age: 18, position: 'FW', specificRole: 'ST', overall: 74, stamina: 89, form: 8.1, marketValue: 12000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 82, shooting: 76, passing: 65, defending: 32, physical: 78 }, isStarting: false },
      { id: 'che-32', name: 'Tyrique George', age: 18, position: 'FW', specificRole: 'LW', overall: 71, stamina: 88, form: 8.0, marketValue: 6000000, wage: 6000, nationality: 'İngiltere', attributes: { pace: 86, shooting: 72, passing: 70, defending: 35, physical: 66 }, isStarting: false },
      { id: 'che-33', name: 'Omari Kellyman', age: 18, position: 'MID', specificRole: 'CAM', overall: 70, stamina: 86, form: 7.8, marketValue: 5000000, wage: 5000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 68, passing: 72, defending: 45, physical: 70 }, isStarting: false },
      { id: 'che-34', name: 'Harvey Vale', age: 20, position: 'MID', specificRole: 'LM', overall: 70, stamina: 86, form: 7.7, marketValue: 4000000, wage: 5000, nationality: 'İngiltere', attributes: { pace: 80, shooting: 68, passing: 72, defending: 48, physical: 68 }, isStarting: false },
      { id: 'che-35', name: 'David Datro Fofana', age: 21, position: 'FW', specificRole: 'ST', overall: 74, stamina: 88, form: 7.8, marketValue: 10000000, wage: 10000, nationality: 'Fildişi Sahili', attributes: { pace: 86, shooting: 74, passing: 64, defending: 32, physical: 78 }, isStarting: false },
      { id: 'che-36', name: 'Deivid Washington', age: 19, position: 'FW', specificRole: 'ST', overall: 71, stamina: 86, form: 7.7, marketValue: 8000000, wage: 8000, nationality: 'Brezilya', attributes: { pace: 82, shooting: 72, passing: 64, defending: 30, physical: 74 }, isStarting: false }
    ]
  },

  // 5. Manchester United
  {
    id: 'manchester-united',
    name: 'Manchester United',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Old Trafford',
    manager: 'Ruben Amorim',
    overall: 84,
    budget: 100000000,
    badgeColor: 'from-red-600 to-black',
    shortName: 'MUN',
    players: [
      { id: 'mun-1', name: 'Andre Onana', age: 28, position: 'GK', specificRole: 'GK', overall: 83, stamina: 88, form: 8.1, marketValue: 35000000, wage: 22857, nationality: 'Kamerun', attributes: { pace: 50, shooting: 15, passing: 86, defending: 83, physical: 80 }, isStarting: true },
      { id: 'mun-2', name: 'Diogo Dalot', age: 25, position: 'DEF', specificRole: 'RB', overall: 82, stamina: 92, form: 8.2, marketValue: 40000000, wage: 20000, nationality: 'Portekiz', attributes: { pace: 82, shooting: 68, passing: 78, defending: 80, physical: 80 }, isStarting: true },
      { id: 'mun-3', name: 'Matthijs de Ligt', age: 24, position: 'DEF', specificRole: 'CB', overall: 84, stamina: 89, form: 8.2, marketValue: 55000000, wage: 28571, nationality: 'Hollanda', attributes: { pace: 72, shooting: 50, passing: 72, defending: 85, physical: 86 }, isStarting: true },
      { id: 'mun-4', name: 'Lisandro Martinez', age: 26, position: 'DEF', specificRole: 'CB', overall: 84, stamina: 90, form: 8.3, marketValue: 50000000, wage: 25714, nationality: 'Arjantin', attributes: { pace: 78, shooting: 52, passing: 81, defending: 85, physical: 84 }, isStarting: true },
      { id: 'mun-5', name: 'Noussair Mazraoui', age: 26, position: 'DEF', specificRole: 'LB', overall: 81, stamina: 88, form: 8.1, marketValue: 30000000, wage: 18000, nationality: 'Fas', attributes: { pace: 80, shooting: 65, passing: 78, defending: 80, physical: 76 }, isStarting: true },
      { id: 'mun-6', name: 'Kobbie Mainoo', age: 19, position: 'MID', specificRole: 'CM', overall: 81, stamina: 92, form: 8.6, marketValue: 55000000, wage: 23333, nationality: 'İngiltere', attributes: { pace: 78, shooting: 72, passing: 84, defending: 78, physical: 78 }, isStarting: true },
      { id: 'mun-7', name: 'Manuel Ugarte', age: 23, position: 'MID', specificRole: 'CDM', overall: 81, stamina: 93, form: 8.1, marketValue: 45000000, wage: 22000, nationality: 'Uruguay', attributes: { pace: 76, shooting: 62, passing: 76, defending: 83, physical: 85 }, isStarting: true },
      { id: 'mun-8', name: 'Bruno Fernandes', age: 29, position: 'MID', specificRole: 'CAM', overall: 87, stamina: 97, form: 8.7, marketValue: 65000000, wage: 42857, nationality: 'Portekiz', attributes: { pace: 74, shooting: 85, passing: 90, defending: 68, physical: 78 }, isStarting: true },
      { id: 'mun-9', name: 'Amad Diallo', age: 22, position: 'FW', specificRole: 'RW', overall: 80, stamina: 89, form: 8.4, marketValue: 35000000, wage: 16000, nationality: 'Fildişi Sahili', attributes: { pace: 86, shooting: 76, passing: 80, defending: 42, physical: 68 }, isStarting: true },
      { id: 'mun-10', name: 'Marcus Rashford', age: 26, position: 'FW', specificRole: 'LW', overall: 82, stamina: 88, form: 7.9, marketValue: 55000000, wage: 35714, nationality: 'İngiltere', attributes: { pace: 90, shooting: 83, passing: 76, defending: 40, physical: 78 }, isStarting: true },
      { id: 'mun-11', name: 'Rasmus Højlund', age: 21, position: 'FW', specificRole: 'ST', overall: 81, stamina: 90, form: 8.2, marketValue: 60000000, wage: 20000, nationality: 'Danimarka', attributes: { pace: 88, shooting: 80, passing: 68, defending: 36, physical: 84 }, isStarting: true },
      { id: 'mun-12', name: 'Altay Bayındır', age: 26, position: 'GK', specificRole: 'GK', overall: 76, stamina: 85, form: 7.8, marketValue: 10000000, wage: 12000, nationality: 'Türkiye', attributes: { pace: 50, shooting: 15, passing: 72, defending: 76, physical: 76 }, isStarting: false },
      { id: 'mun-13', name: 'Harry Maguire', age: 31, position: 'DEF', specificRole: 'CB', overall: 80, stamina: 86, form: 8.0, marketValue: 18000000, wage: 22000, nationality: 'İngiltere', attributes: { pace: 58, shooting: 52, passing: 72, defending: 81, physical: 87 }, isStarting: false },
      { id: 'mun-14', name: 'Luke Shaw', age: 29, position: 'DEF', specificRole: 'LB', overall: 81, stamina: 82, form: 7.9, marketValue: 25000000, wage: 25000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 60, passing: 78, defending: 81, physical: 78 }, isStarting: false },
      { id: 'mun-15', name: 'Leny Yoro', age: 18, position: 'DEF', specificRole: 'CB', overall: 79, stamina: 90, form: 8.3, marketValue: 45000000, wage: 16000, nationality: 'Fransa', attributes: { pace: 80, shooting: 40, passing: 74, defending: 80, physical: 78 }, isStarting: false },
      { id: 'mun-16', name: 'Casemiro', age: 32, position: 'MID', specificRole: 'CDM', overall: 82, stamina: 84, form: 7.9, marketValue: 20000000, wage: 35000, nationality: 'Brezilya', attributes: { pace: 60, shooting: 72, passing: 78, defending: 84, physical: 85 }, isStarting: false },
      { id: 'mun-17', name: 'Christian Eriksen', age: 32, position: 'MID', specificRole: 'CM', overall: 80, stamina: 82, form: 8.0, marketValue: 12000000, wage: 20000, nationality: 'Danimarka', attributes: { pace: 58, shooting: 78, passing: 88, defending: 62, physical: 65 }, isStarting: false },
      { id: 'mun-18', name: 'Mason Mount', age: 25, position: 'MID', specificRole: 'CAM', overall: 80, stamina: 86, form: 7.9, marketValue: 35000000, wage: 25000, nationality: 'İngiltere', attributes: { pace: 76, shooting: 78, passing: 81, defending: 60, physical: 72 }, isStarting: false },
      { id: 'mun-19', name: 'Alejandro Garnacho', age: 20, position: 'FW', specificRole: 'RW', overall: 81, stamina: 91, form: 8.3, marketValue: 50000000, wage: 18000, nationality: 'Arjantin', attributes: { pace: 89, shooting: 78, passing: 76, defending: 38, physical: 72 }, isStarting: false },
      { id: 'mun-20', name: 'Joshua Zirkzee', age: 23, position: 'FW', specificRole: 'ST', overall: 80, stamina: 88, form: 8.0, marketValue: 40000000, wage: 20000, nationality: 'Hollanda', attributes: { pace: 80, shooting: 78, passing: 78, defending: 42, physical: 82 }, isStarting: false }
    ]
  },

  // 6. Tottenham Hotspur
  {
    id: 'tottenham',
    name: 'Tottenham Hotspur',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Tottenham Hotspur Stadium',
    manager: 'Ange Postecoglou',
    overall: 84,
    budget: 90000000,
    badgeColor: 'from-slate-100 to-navy-900',
    shortName: 'TOT',
    players: [
      { id: 'tot-1', name: 'Guglielmo Vicario', age: 27, position: 'GK', specificRole: 'GK', overall: 83, stamina: 88, form: 8.3, marketValue: 35000000, wage: 20000, nationality: 'İtalya', attributes: { pace: 50, shooting: 15, passing: 76, defending: 84, physical: 78 }, isStarting: true },
      { id: 'tot-2', name: 'Pedro Porro', age: 24, position: 'DEF', specificRole: 'RB', overall: 83, stamina: 92, form: 8.4, marketValue: 45000000, wage: 22857, nationality: 'İspanya', attributes: { pace: 84, shooting: 74, passing: 81, defending: 78, physical: 78 }, isStarting: true },
      { id: 'tot-3', name: 'Cristian Romero', age: 26, position: 'DEF', specificRole: 'CB', overall: 85, stamina: 91, form: 8.6, marketValue: 60000000, wage: 28571, nationality: 'Arjantin', attributes: { pace: 80, shooting: 48, passing: 72, defending: 86, physical: 87 }, isStarting: true },
      { id: 'tot-4', name: 'Micky van de Ven', age: 23, position: 'DEF', specificRole: 'CB', overall: 83, stamina: 93, form: 8.5, marketValue: 55000000, wage: 22000, nationality: 'Hollanda', attributes: { pace: 92, shooting: 45, passing: 74, defending: 83, physical: 83 }, isStarting: true },
      { id: 'tot-5', name: 'Destiny Udogie', age: 21, position: 'DEF', specificRole: 'LB', overall: 82, stamina: 93, form: 8.3, marketValue: 45000000, wage: 20000, nationality: 'İtalya', attributes: { pace: 87, shooting: 62, passing: 75, defending: 80, physical: 82 }, isStarting: true },
      { id: 'tot-6', name: 'Yves Bissouma', age: 27, position: 'MID', specificRole: 'CDM', overall: 82, stamina: 90, form: 8.1, marketValue: 35000000, wage: 22000, nationality: 'Mali', attributes: { pace: 78, shooting: 68, passing: 80, defending: 82, physical: 82 }, isStarting: true },
      { id: 'tot-7', name: 'Pape Matar Sarr', age: 21, position: 'MID', specificRole: 'CM', overall: 81, stamina: 94, form: 8.2, marketValue: 40000000, wage: 18000, nationality: 'Senegal', attributes: { pace: 82, shooting: 72, passing: 80, defending: 78, physical: 80 }, isStarting: true },
      { id: 'tot-8', name: 'James Maddison', age: 27, position: 'MID', specificRole: 'CAM', overall: 85, stamina: 88, form: 8.4, marketValue: 65000000, wage: 34000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 82, passing: 88, defending: 58, physical: 72 }, isStarting: true },
      { id: 'tot-9', name: 'Brennan Johnson', age: 23, position: 'FW', specificRole: 'RW', overall: 81, stamina: 90, form: 8.3, marketValue: 45000000, wage: 20000, nationality: 'Galler', attributes: { pace: 91, shooting: 78, passing: 75, defending: 40, physical: 74 }, isStarting: true },
      { id: 'tot-10', name: 'Son Heung-min', age: 32, position: 'FW', specificRole: 'LW', overall: 87, stamina: 90, form: 8.8, marketValue: 45000000, wage: 42857, nationality: 'Güney Kore', attributes: { pace: 87, shooting: 88, passing: 82, defending: 42, physical: 72 }, isStarting: true },
      { id: 'tot-11', name: 'Dominic Solanke', age: 26, position: 'FW', specificRole: 'ST', overall: 82, stamina: 90, form: 8.2, marketValue: 50000000, wage: 26000, nationality: 'İngiltere', attributes: { pace: 82, shooting: 82, passing: 72, defending: 45, physical: 84 }, isStarting: true },
      { id: 'tot-12', name: 'Fraser Forster', age: 36, position: 'GK', specificRole: 'GK', overall: 75, stamina: 80, form: 7.7, marketValue: 2000000, wage: 8000, nationality: 'İngiltere', attributes: { pace: 45, shooting: 15, passing: 68, defending: 76, physical: 78 }, isStarting: false },
      { id: 'tot-13', name: 'Radu Drăgușin', age: 22, position: 'DEF', specificRole: 'CB', overall: 79, stamina: 89, form: 8.1, marketValue: 28000000, wage: 16000, nationality: 'Romanya', attributes: { pace: 74, shooting: 40, passing: 68, defending: 80, physical: 84 }, isStarting: false },
      { id: 'tot-14', name: 'Ben Davies', age: 31, position: 'DEF', specificRole: 'LB', overall: 78, stamina: 86, form: 7.9, marketValue: 10000000, wage: 15000, nationality: 'Galler', attributes: { pace: 72, shooting: 58, passing: 74, defending: 78, physical: 76 }, isStarting: false },
      { id: 'tot-15', name: 'Archie Gray', age: 18, position: 'MID', specificRole: 'CM', overall: 77, stamina: 91, form: 8.2, marketValue: 30000000, wage: 12000, nationality: 'İngiltere', attributes: { pace: 80, shooting: 68, passing: 78, defending: 76, physical: 74 }, isStarting: false },
      { id: 'tot-16', name: 'Lucas Bergvall', age: 18, position: 'MID', specificRole: 'CAM', overall: 76, stamina: 90, form: 8.3, marketValue: 22000000, wage: 10000, nationality: 'İsveç', attributes: { pace: 78, shooting: 72, passing: 80, defending: 58, physical: 72 }, isStarting: false },
      { id: 'tot-17', name: 'Rodrigo Bentancur', age: 27, position: 'MID', specificRole: 'CM', overall: 81, stamina: 88, form: 8.1, marketValue: 35000000, wage: 22000, nationality: 'Uruguay', attributes: { pace: 74, shooting: 72, passing: 82, defending: 79, physical: 78 }, isStarting: false },
      { id: 'tot-18', name: 'Dejan Kulusevski', age: 24, position: 'FW', specificRole: 'CAM', overall: 83, stamina: 92, form: 8.5, marketValue: 55000000, wage: 25000, nationality: 'İsveç', attributes: { pace: 81, shooting: 80, passing: 84, defending: 58, physical: 82 }, isStarting: false },
      { id: 'tot-19', name: 'Richarlison', age: 27, position: 'FW', specificRole: 'ST', overall: 81, stamina: 88, form: 8.0, marketValue: 38000000, wage: 26000, nationality: 'Brezilya', attributes: { pace: 82, shooting: 81, passing: 72, defending: 45, physical: 80 }, isStarting: false },
      { id: 'tot-20', name: 'Timo Werner', age: 28, position: 'FW', specificRole: 'LW', overall: 79, stamina: 87, form: 7.9, marketValue: 22000000, wage: 20000, nationality: 'Almanya', attributes: { pace: 89, shooting: 74, passing: 72, defending: 38, physical: 70 }, isStarting: false }
    ]
  },

  // 7. Aston Villa
  {
    id: 'aston-villa',
    name: 'Aston Villa',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Villa Park',
    manager: 'Unai Emery',
    overall: 83,
    budget: 70000000,
    badgeColor: 'from-sky-700 to-amber-700',
    shortName: 'AVL',
    players: [
      { id: 'avl-1', name: 'Emiliano Martínez', age: 31, position: 'GK', specificRole: 'GK', overall: 87, stamina: 88, form: 8.8, marketValue: 30000000, wage: 25000, nationality: 'Arjantin', attributes: { pace: 50, shooting: 15, passing: 78, defending: 88, physical: 82 }, isStarting: true },
      { id: 'avl-2', name: 'Ezri Konsa', age: 26, position: 'DEF', specificRole: 'CB', overall: 82, stamina: 90, form: 8.2, marketValue: 35000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 40, passing: 72, defending: 82, physical: 80 }, isStarting: true },
      { id: 'avl-3', name: 'Pau Torres', age: 27, position: 'DEF', specificRole: 'CB', overall: 83, stamina: 88, form: 8.3, marketValue: 45000000, wage: 22000, nationality: 'İspanya', attributes: { pace: 74, shooting: 45, passing: 82, defending: 83, physical: 78 }, isStarting: true },
      { id: 'avl-4', name: 'Lucas Digne', age: 31, position: 'DEF', specificRole: 'LB', overall: 80, stamina: 86, form: 8.0, marketValue: 15000000, wage: 16000, nationality: 'Fransa', attributes: { pace: 76, shooting: 65, passing: 80, defending: 78, physical: 74 }, isStarting: true },
      { id: 'avl-5', name: 'Matty Cash', age: 27, position: 'DEF', specificRole: 'RB', overall: 79, stamina: 90, form: 8.1, marketValue: 25000000, wage: 15000, nationality: 'Polonya', attributes: { pace: 82, shooting: 62, passing: 74, defending: 78, physical: 78 }, isStarting: true },
      { id: 'avl-6', name: 'Amadou Onana', age: 22, position: 'MID', specificRole: 'CDM', overall: 82, stamina: 92, form: 8.4, marketValue: 50000000, wage: 22000, nationality: 'Belçika', attributes: { pace: 76, shooting: 68, passing: 78, defending: 82, physical: 88 }, isStarting: true },
      { id: 'avl-7', name: 'Youri Tielemans', age: 27, position: 'MID', specificRole: 'CM', overall: 83, stamina: 88, form: 8.5, marketValue: 35000000, wage: 24000, nationality: 'Belçika', attributes: { pace: 68, shooting: 82, passing: 86, defending: 72, physical: 74 }, isStarting: true },
      { id: 'avl-8', name: 'John McGinn', age: 29, position: 'MID', specificRole: 'CM', overall: 82, stamina: 95, form: 8.3, marketValue: 30000000, wage: 20000, nationality: 'İskoçya', attributes: { pace: 74, shooting: 76, passing: 80, defending: 78, physical: 84 }, isStarting: true },
      { id: 'avl-9', name: 'Leon Bailey', age: 27, position: 'FW', specificRole: 'RW', overall: 82, stamina: 88, form: 8.3, marketValue: 40000000, wage: 20000, nationality: 'Jamaika', attributes: { pace: 90, shooting: 80, passing: 78, defending: 38, physical: 70 }, isStarting: true },
      { id: 'avl-10', name: 'Ollie Watkins', age: 28, position: 'FW', specificRole: 'ST', overall: 85, stamina: 92, form: 8.7, marketValue: 65000000, wage: 30000, nationality: 'İngiltere', attributes: { pace: 86, shooting: 85, passing: 76, defending: 45, physical: 82 }, isStarting: true },
      { id: 'avl-11', name: 'Morgan Rogers', age: 22, position: 'FW', specificRole: 'LW', overall: 80, stamina: 90, form: 8.4, marketValue: 35000000, wage: 16000, nationality: 'İngiltere', attributes: { pace: 84, shooting: 78, passing: 78, defending: 42, physical: 80 }, isStarting: true },
      { id: 'avl-12', name: 'Jhon Durán', age: 20, position: 'FW', specificRole: 'ST', overall: 81, stamina: 88, form: 8.6, marketValue: 45000000, wage: 18000, nationality: 'Kolombiya', attributes: { pace: 88, shooting: 83, passing: 68, defending: 35, physical: 85 }, isStarting: false },
      { id: 'avl-13', name: 'Ian Maatsen', age: 22, position: 'DEF', specificRole: 'LB', overall: 80, stamina: 90, form: 8.2, marketValue: 32000000, wage: 16000, nationality: 'Hollanda', attributes: { pace: 86, shooting: 65, passing: 76, defending: 76, physical: 72 }, isStarting: false },
      { id: 'avl-14', name: 'Ross Barkley', age: 30, position: 'MID', specificRole: 'CM', overall: 78, stamina: 85, form: 8.0, marketValue: 12000000, wage: 14000, nationality: 'İngiltere', attributes: { pace: 72, shooting: 76, passing: 80, defending: 68, physical: 78 }, isStarting: false }
    ]
  },

  // 8. Newcastle United
  {
    id: 'newcastle',
    name: 'Newcastle United',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'St. James\' Park',
    manager: 'Eddie Howe',
    overall: 83,
    budget: 80000000,
    badgeColor: 'from-slate-800 to-black',
    shortName: 'NEW',
    players: [
      { id: 'new-1', name: 'Nick Pope', age: 32, position: 'GK', specificRole: 'GK', overall: 83, stamina: 86, form: 8.2, marketValue: 20000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 50, shooting: 15, passing: 68, defending: 84, physical: 82 }, isStarting: true },
      { id: 'new-2', name: 'Kieran Trippier', age: 33, position: 'DEF', specificRole: 'RB', overall: 82, stamina: 85, form: 8.1, marketValue: 15000000, wage: 22000, nationality: 'İngiltere', attributes: { pace: 72, shooting: 70, passing: 86, defending: 80, physical: 74 }, isStarting: true },
      { id: 'new-3', name: 'Fabian Schär', age: 32, position: 'DEF', specificRole: 'CB', overall: 82, stamina: 86, form: 8.3, marketValue: 18000000, wage: 18000, nationality: 'İsviçre', attributes: { pace: 68, shooting: 72, passing: 80, defending: 83, physical: 80 }, isStarting: true },
      { id: 'new-4', name: 'Sven Botman', age: 24, position: 'DEF', specificRole: 'CB', overall: 83, stamina: 88, form: 8.2, marketValue: 45000000, wage: 22000, nationality: 'Hollanda', attributes: { pace: 72, shooting: 40, passing: 72, defending: 85, physical: 86 }, isStarting: true },
      { id: 'new-5', name: 'Dan Burn', age: 32, position: 'DEF', specificRole: 'LB', overall: 79, stamina: 88, form: 8.1, marketValue: 12000000, wage: 15000, nationality: 'İngiltere', attributes: { pace: 62, shooting: 40, passing: 68, defending: 80, physical: 88 }, isStarting: true },
      { id: 'new-6', name: 'Bruno Guimarães', age: 26, position: 'MID', specificRole: 'CDM', overall: 86, stamina: 94, form: 8.7, marketValue: 85000000, wage: 32000, nationality: 'Brezilya', attributes: { pace: 76, shooting: 78, passing: 87, defending: 83, physical: 84 }, isStarting: true },
      { id: 'new-7', name: 'Sandro Tonali', age: 24, position: 'MID', specificRole: 'CM', overall: 84, stamina: 92, form: 8.4, marketValue: 60000000, wage: 28000, nationality: 'İtalya', attributes: { pace: 80, shooting: 75, passing: 84, defending: 80, physical: 82 }, isStarting: true },
      { id: 'new-8', name: 'Joelinton', age: 28, position: 'MID', specificRole: 'CM', overall: 82, stamina: 95, form: 8.3, marketValue: 40000000, wage: 22000, nationality: 'Brezilya', attributes: { pace: 78, shooting: 74, passing: 78, defending: 80, physical: 89 }, isStarting: true },
      { id: 'new-9', name: 'Anthony Gordon', age: 23, position: 'FW', specificRole: 'LW', overall: 83, stamina: 92, form: 8.5, marketValue: 60000000, wage: 22000, nationality: 'İngiltere', attributes: { pace: 90, shooting: 80, passing: 78, defending: 45, physical: 76 }, isStarting: true },
      { id: 'new-10', name: 'Alexander Isak', age: 24, position: 'FW', specificRole: 'ST', overall: 86, stamina: 90, form: 8.8, marketValue: 90000000, wage: 34000, nationality: 'İsveç', attributes: { pace: 89, shooting: 87, passing: 78, defending: 38, physical: 78 }, isStarting: true },
      { id: 'new-11', name: 'Jacob Murphy', age: 29, position: 'FW', specificRole: 'RW', overall: 78, stamina: 88, form: 8.0, marketValue: 18000000, wage: 14000, nationality: 'İngiltere', attributes: { pace: 84, shooting: 74, passing: 76, defending: 42, physical: 72 }, isStarting: true },
      { id: 'new-12', name: 'Harvey Barnes', age: 26, position: 'FW', specificRole: 'LW', overall: 80, stamina: 88, form: 8.2, marketValue: 30000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 85, shooting: 80, passing: 75, defending: 38, physical: 72 }, isStarting: false },
      { id: 'new-13', name: 'Tino Livramento', age: 21, position: 'DEF', specificRole: 'RB', overall: 79, stamina: 92, form: 8.2, marketValue: 35000000, wage: 15000, nationality: 'İngiltere', attributes: { pace: 86, shooting: 58, passing: 74, defending: 78, physical: 74 }, isStarting: false },
      { id: 'new-14', name: 'Lewis Hall', age: 19, position: 'DEF', specificRole: 'LB', overall: 78, stamina: 90, form: 8.3, marketValue: 28000000, wage: 12000, nationality: 'İngiltere', attributes: { pace: 82, shooting: 62, passing: 78, defending: 76, physical: 72 }, isStarting: false }
    ]
  },

  // 9. Hull City
  {
    id: 'hull-city',
    name: 'Hull City',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'MKM Stadium',
    manager: 'Tim Walter',
    overall: 77,
    budget: 26000000,
    badgeColor: 'from-amber-600 to-black',
    shortName: 'HUL',
    players: [
      { id: 'hul-1', name: 'Ivor Pandur', age: 24, position: 'GK', specificRole: 'GK', overall: 76, stamina: 86, form: 7.9, marketValue: 6000000, wage: 8000, nationality: 'Hırvatistan', attributes: { pace: 50, shooting: 15, passing: 72, defending: 76, physical: 75 }, isStarting: true },
      { id: 'hul-2', name: 'Alfie Jones', age: 26, position: 'DEF', specificRole: 'CB', overall: 77, stamina: 88, form: 8.0, marketValue: 8000000, wage: 10000, nationality: 'İngiltere', attributes: { pace: 70, shooting: 35, passing: 68, defending: 78, physical: 80 }, isStarting: true },
      { id: 'hul-3', name: 'Sean McLoughlin', age: 27, position: 'DEF', specificRole: 'CB', overall: 76, stamina: 88, form: 7.8, marketValue: 6500000, wage: 9000, nationality: 'İrlanda', attributes: { pace: 68, shooting: 32, passing: 66, defending: 77, physical: 82 }, isStarting: true },
      { id: 'hul-4', name: 'Cody Drameh', age: 22, position: 'DEF', specificRole: 'RB', overall: 76, stamina: 90, form: 7.9, marketValue: 8000000, wage: 8000, nationality: 'İngiltere', attributes: { pace: 84, shooting: 50, passing: 70, defending: 75, physical: 74 }, isStarting: true },
      { id: 'hul-5', name: 'Ryan Giles', age: 24, position: 'DEF', specificRole: 'LB', overall: 77, stamina: 92, form: 8.1, marketValue: 9000000, wage: 10000, nationality: 'İngiltere', attributes: { pace: 86, shooting: 60, passing: 78, defending: 74, physical: 72 }, isStarting: true },
      { id: 'hul-6', name: 'Regan Slater', age: 24, position: 'MID', specificRole: 'CM', overall: 77, stamina: 94, form: 8.0, marketValue: 7500000, wage: 9000, nationality: 'İngiltere', attributes: { pace: 74, shooting: 68, passing: 76, defending: 76, physical: 80 }, isStarting: true },
      { id: 'hul-7', name: 'Óscar Zambrano', age: 20, position: 'MID', specificRole: 'CDM', overall: 76, stamina: 90, form: 8.1, marketValue: 9000000, wage: 8000, nationality: 'Ekvador', attributes: { pace: 72, shooting: 62, passing: 78, defending: 77, physical: 76 }, isStarting: true },
      { id: 'hul-8', name: 'Abdülkadir Ömür', age: 25, position: 'MID', specificRole: 'CAM', overall: 79, stamina: 90, form: 8.3, marketValue: 12000000, wage: 14000, nationality: 'Türkiye', attributes: { pace: 80, shooting: 74, passing: 82, defending: 50, physical: 68 }, isStarting: true },
      { id: 'hul-9', name: 'Liam Millar', age: 24, position: 'FW', specificRole: 'LW', overall: 77, stamina: 90, form: 8.0, marketValue: 8500000, wage: 9000, nationality: 'Kanada', attributes: { pace: 88, shooting: 75, passing: 74, defending: 40, physical: 72 }, isStarting: true },
      { id: 'hul-10', name: 'Mohamed Belloumi', age: 22, position: 'FW', specificRole: 'RW', overall: 78, stamina: 89, form: 8.2, marketValue: 11000000, wage: 10000, nationality: 'Cezayir', attributes: { pace: 86, shooting: 78, passing: 76, defending: 38, physical: 70 }, isStarting: true },
      { id: 'hul-11', name: 'Chris Bedia', age: 28, position: 'FW', specificRole: 'ST', overall: 77, stamina: 88, form: 8.0, marketValue: 7500000, wage: 10000, nationality: 'Fildişi Sahili', attributes: { pace: 78, shooting: 79, passing: 66, defending: 35, physical: 84 }, isStarting: true }
    ]
  },

  // 10. Brighton & Hove Albion
  {
    id: 'brighton',
    name: 'Brighton & Hove Albion',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'AMEX Stadium',
    manager: 'Fabian Hürzeler',
    overall: 81,
    budget: 55000000,
    badgeColor: 'from-blue-500 to-white',
    shortName: 'BHA',
    players: [
      { id: 'bha-1', name: 'Bart Verbruggen', age: 22, position: 'GK', specificRole: 'GK', overall: 80, stamina: 88, form: 8.2, marketValue: 22000000, wage: 14000, nationality: 'Hollanda', attributes: { pace: 50, shooting: 15, passing: 80, defending: 80, physical: 78 }, isStarting: true },
      { id: 'bha-2', name: 'Lewis Dunk', age: 32, position: 'DEF', specificRole: 'CB', overall: 81, stamina: 86, form: 8.1, marketValue: 15000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 62, shooting: 50, passing: 78, defending: 83, physical: 84 }, isStarting: true },
      { id: 'bha-3', name: 'Jan Paul van Hecke', age: 24, position: 'DEF', specificRole: 'CB', overall: 80, stamina: 88, form: 8.2, marketValue: 25000000, wage: 15000, nationality: 'Hollanda', attributes: { pace: 72, shooting: 40, passing: 76, defending: 81, physical: 82 }, isStarting: true },
      { id: 'bha-4', name: 'Pervis Estupiñán', age: 26, position: 'DEF', specificRole: 'LB', overall: 80, stamina: 92, form: 8.1, marketValue: 30000000, wage: 16000, nationality: 'Ekvador', attributes: { pace: 85, shooting: 62, passing: 76, defending: 78, physical: 78 }, isStarting: true },
      { id: 'bha-5', name: 'Joel Veltman', age: 32, position: 'DEF', specificRole: 'RB', overall: 78, stamina: 85, form: 7.9, marketValue: 10000000, wage: 12000, nationality: 'Hollanda', attributes: { pace: 72, shooting: 45, passing: 72, defending: 79, physical: 76 }, isStarting: true },
      { id: 'bha-6', name: 'Carlos Baleba', age: 20, position: 'MID', specificRole: 'CDM', overall: 80, stamina: 92, form: 8.5, marketValue: 40000000, wage: 16000, nationality: 'Kamerun', attributes: { pace: 80, shooting: 68, passing: 78, defending: 80, physical: 85 }, isStarting: true },
      { id: 'bha-7', name: 'Yasin Ayari', age: 20, position: 'MID', specificRole: 'CM', overall: 77, stamina: 88, form: 8.1, marketValue: 18000000, wage: 12000, nationality: 'İsveç', attributes: { pace: 76, shooting: 70, passing: 78, defending: 72, physical: 72 }, isStarting: true },
      { id: 'bha-8', name: 'Kaoru Mitoma', age: 27, position: 'FW', specificRole: 'LW', overall: 83, stamina: 90, form: 8.6, marketValue: 50000000, wage: 22000, nationality: 'Japonya', attributes: { pace: 88, shooting: 80, passing: 82, defending: 45, physical: 70 }, isStarting: true },
      { id: 'bha-9', name: 'Yankuba Minteh', age: 20, position: 'FW', specificRole: 'RW', overall: 79, stamina: 90, form: 8.3, marketValue: 32000000, wage: 14000, nationality: 'Gambia', attributes: { pace: 93, shooting: 76, passing: 74, defending: 38, physical: 72 }, isStarting: true },
      { id: 'bha-10', name: 'Joao Pedro', age: 22, position: 'FW', specificRole: 'ST', overall: 82, stamina: 90, form: 8.5, marketValue: 50000000, wage: 22000, nationality: 'Brezilya', attributes: { pace: 84, shooting: 82, passing: 78, defending: 40, physical: 78 }, isStarting: true },
      { id: 'bha-11', name: 'Danny Welbeck', age: 33, position: 'FW', specificRole: 'ST', overall: 79, stamina: 85, form: 8.3, marketValue: 10000000, wage: 15000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 80, passing: 72, defending: 42, physical: 78 }, isStarting: false }
    ]
  },

  // 11. Fulham
  {
    id: 'fulham',
    name: 'Fulham',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Craven Cottage',
    manager: 'Marco Silva',
    overall: 80,
    budget: 45000000,
    badgeColor: 'from-slate-100 to-black',
    shortName: 'FUL',
    players: [
      { id: 'ful-1', name: 'Bernd Leno', age: 32, position: 'GK', specificRole: 'GK', overall: 82, stamina: 86, form: 8.3, marketValue: 18000000, wage: 18000, nationality: 'Almanya', attributes: { pace: 50, shooting: 15, passing: 72, defending: 83, physical: 78 }, isStarting: true },
      { id: 'ful-2', name: 'Joachim Andersen', age: 28, position: 'DEF', specificRole: 'CB', overall: 81, stamina: 88, form: 8.2, marketValue: 30000000, wage: 18000, nationality: 'Danimarka', attributes: { pace: 70, shooting: 45, passing: 80, defending: 82, physical: 84 }, isStarting: true },
      { id: 'ful-3', name: 'Calvin Bassey', age: 24, position: 'DEF', specificRole: 'CB', overall: 79, stamina: 90, form: 8.1, marketValue: 22000000, wage: 15000, nationality: 'Nijerya', attributes: { pace: 80, shooting: 38, passing: 70, defending: 79, physical: 86 }, isStarting: true },
      { id: 'ful-4', name: 'Antonee Robinson', age: 27, position: 'DEF', specificRole: 'LB', overall: 81, stamina: 94, form: 8.4, marketValue: 35000000, wage: 18000, nationality: 'ABD', attributes: { pace: 90, shooting: 55, passing: 74, defending: 80, physical: 78 }, isStarting: true },
      { id: 'ful-5', name: 'Timothy Castagne', age: 28, position: 'DEF', specificRole: 'RB', overall: 78, stamina: 88, form: 7.9, marketValue: 15000000, wage: 14000, nationality: 'Belçika', attributes: { pace: 80, shooting: 60, passing: 74, defending: 78, physical: 76 }, isStarting: true },
      { id: 'ful-6', name: 'Sasa Lukic', age: 28, position: 'MID', specificRole: 'CM', overall: 78, stamina: 88, form: 8.0, marketValue: 18000000, wage: 14000, nationality: 'Sırbistan', attributes: { pace: 72, shooting: 70, passing: 80, defending: 76, physical: 78 }, isStarting: true },
      { id: 'ful-7', name: 'Sander Berge', age: 26, position: 'MID', specificRole: 'CDM', overall: 79, stamina: 90, form: 8.1, marketValue: 25000000, wage: 16000, nationality: 'Norveç', attributes: { pace: 72, shooting: 68, passing: 78, defending: 80, physical: 86 }, isStarting: true },
      { id: 'ful-8', name: 'Andreas Pereira', age: 28, position: 'MID', specificRole: 'CAM', overall: 80, stamina: 88, form: 8.2, marketValue: 25000000, wage: 18000, nationality: 'Brezilya', attributes: { pace: 76, shooting: 78, passing: 82, defending: 58, physical: 72 }, isStarting: true },
      { id: 'ful-9', name: 'Alex Iwobi', age: 28, position: 'FW', specificRole: 'LW', overall: 80, stamina: 90, form: 8.2, marketValue: 25000000, wage: 18000, nationality: 'Nijerya', attributes: { pace: 82, shooting: 75, passing: 80, defending: 52, physical: 76 }, isStarting: true },
      { id: 'ful-10', name: 'Raul Jimenez', age: 33, position: 'FW', specificRole: 'ST', overall: 79, stamina: 84, form: 8.2, marketValue: 12000000, wage: 16000, nationality: 'Meksika', attributes: { pace: 72, shooting: 80, passing: 74, defending: 40, physical: 80 }, isStarting: true },
      { id: 'ful-11', name: 'Adama Traore', age: 28, position: 'FW', specificRole: 'RW', overall: 78, stamina: 86, form: 8.0, marketValue: 18000000, wage: 15000, nationality: 'İspanya', attributes: { pace: 95, shooting: 68, passing: 70, defending: 35, physical: 88 }, isStarting: true }
    ]
  },

  // 12. Bournemouth
  {
    id: 'bournemouth',
    name: 'Bournemouth',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Vitality Stadium',
    manager: 'Andoni Iraola',
    overall: 80,
    budget: 40000000,
    badgeColor: 'from-red-600 to-black',
    shortName: 'BOU',
    players: [
      { id: 'bou-1', name: 'Kepa Arrizabalaga', age: 29, position: 'GK', specificRole: 'GK', overall: 80, stamina: 86, form: 8.1, marketValue: 18000000, wage: 16000, nationality: 'İspanya', attributes: { pace: 50, shooting: 15, passing: 80, defending: 80, physical: 74 }, isStarting: true },
      { id: 'bou-2', name: 'Ilya Zabarnyi', age: 21, position: 'DEF', specificRole: 'CB', overall: 81, stamina: 92, form: 8.4, marketValue: 38000000, wage: 16000, nationality: 'Ukrayna', attributes: { pace: 76, shooting: 38, passing: 74, defending: 82, physical: 84 }, isStarting: true },
      { id: 'bou-3', name: 'Marcos Senesi', age: 27, position: 'DEF', specificRole: 'CB', overall: 79, stamina: 88, form: 8.0, marketValue: 22000000, wage: 15000, nationality: 'Arjantin', attributes: { pace: 70, shooting: 45, passing: 76, defending: 80, physical: 82 }, isStarting: true },
      { id: 'bou-4', name: 'Milos Kerkez', age: 20, position: 'DEF', specificRole: 'LB', overall: 80, stamina: 92, form: 8.3, marketValue: 35000000, wage: 15000, nationality: 'Macaristan', attributes: { pace: 88, shooting: 60, passing: 74, defending: 78, physical: 76 }, isStarting: true },
      { id: 'bou-5', name: 'Julian Araujo', age: 23, position: 'DEF', specificRole: 'RB', overall: 77, stamina: 88, form: 7.9, marketValue: 15000000, wage: 12000, nationality: 'Meksika', attributes: { pace: 82, shooting: 52, passing: 72, defending: 76, physical: 74 }, isStarting: true },
      { id: 'bou-6', name: 'Ryan Christie', age: 29, position: 'MID', specificRole: 'CM', overall: 79, stamina: 94, form: 8.2, marketValue: 18000000, wage: 14000, nationality: 'İskoçya', attributes: { pace: 78, shooting: 74, passing: 80, defending: 74, physical: 78 }, isStarting: true },
      { id: 'bou-7', name: 'Justin Kluivert', age: 25, position: 'FW', specificRole: 'LW', overall: 80, stamina: 88, form: 8.2, marketValue: 25000000, wage: 16000, nationality: 'Hollanda', attributes: { pace: 86, shooting: 78, passing: 76, defending: 38, physical: 70 }, isStarting: true },
      { id: 'bou-8', name: 'Antoine Semenyo', age: 24, position: 'FW', specificRole: 'RW', overall: 81, stamina: 92, form: 8.5, marketValue: 40000000, wage: 18000, nationality: 'Gana', attributes: { pace: 88, shooting: 82, passing: 76, defending: 42, physical: 82 }, isStarting: true },
      { id: 'bou-9', name: 'Evanilson', age: 24, position: 'FW', specificRole: 'ST', overall: 81, stamina: 88, form: 8.2, marketValue: 42000000, wage: 20000, nationality: 'Brezilya', attributes: { pace: 82, shooting: 82, passing: 72, defending: 38, physical: 80 }, isStarting: true }
    ]
  },

  // 13. Brentford
  {
    id: 'brentford',
    name: 'Brentford',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Gtech Community Stadium',
    manager: 'Thomas Frank',
    overall: 80,
    budget: 40000000,
    badgeColor: 'from-red-600 to-amber-500',
    shortName: 'BRE',
    players: [
      { id: 'bre-1', name: 'Mark Flekken', age: 31, position: 'GK', specificRole: 'GK', overall: 80, stamina: 86, form: 8.1, marketValue: 15000000, wage: 15000, nationality: 'Hollanda', attributes: { pace: 50, shooting: 15, passing: 78, defending: 80, physical: 78 }, isStarting: true },
      { id: 'bre-2', name: 'Ethan Pinnock', age: 31, position: 'DEF', specificRole: 'CB', overall: 80, stamina: 88, form: 8.2, marketValue: 15000000, wage: 15000, nationality: 'Jamaika', attributes: { pace: 68, shooting: 38, passing: 68, defending: 82, physical: 86 }, isStarting: true },
      { id: 'bre-3', name: 'Nathan Collins', age: 23, position: 'DEF', specificRole: 'CB', overall: 79, stamina: 90, form: 8.1, marketValue: 28000000, wage: 14000, nationality: 'İrlanda', attributes: { pace: 72, shooting: 40, passing: 72, defending: 80, physical: 84 }, isStarting: true },
      { id: 'bre-4', name: 'Rico Henry', age: 27, position: 'DEF', specificRole: 'LB', overall: 79, stamina: 90, form: 8.0, marketValue: 20000000, wage: 14000, nationality: 'İngiltere', attributes: { pace: 88, shooting: 55, passing: 72, defending: 78, physical: 72 }, isStarting: true },
      { id: 'bre-5', name: 'Christian Nørgaard', age: 30, position: 'MID', specificRole: 'CDM', overall: 80, stamina: 88, form: 8.1, marketValue: 18000000, wage: 16000, nationality: 'Danimarka', attributes: { pace: 65, shooting: 65, passing: 78, defending: 82, physical: 82 }, isStarting: true },
      { id: 'bre-6', name: 'Mikkel Damsgaard', age: 24, position: 'MID', specificRole: 'CAM', overall: 79, stamina: 88, form: 8.3, marketValue: 22000000, wage: 14000, nationality: 'Danimarka', attributes: { pace: 78, shooting: 74, passing: 82, defending: 50, physical: 68 }, isStarting: true },
      { id: 'bre-7', name: 'Bryan Mbeumo', age: 25, position: 'FW', specificRole: 'RW', overall: 83, stamina: 92, form: 8.8, marketValue: 55000000, wage: 22000, nationality: 'Kamerun', attributes: { pace: 86, shooting: 84, passing: 80, defending: 45, physical: 78 }, isStarting: true },
      { id: 'bre-8', name: 'Yoane Wissa', age: 27, position: 'FW', specificRole: 'ST', overall: 81, stamina: 90, form: 8.5, marketValue: 35000000, wage: 18000, nationality: 'Kongo DR', attributes: { pace: 85, shooting: 82, passing: 74, defending: 40, physical: 76 }, isStarting: true },
      { id: 'bre-9', name: 'Kevin Schade', age: 22, position: 'FW', specificRole: 'LW', overall: 78, stamina: 88, form: 8.0, marketValue: 22000000, wage: 12000, nationality: 'Almanya', attributes: { pace: 92, shooting: 74, passing: 70, defending: 35, physical: 74 }, isStarting: true }
    ]
  },

  // 14. Leeds United
  {
    id: 'leeds-united',
    name: 'Leeds United',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Elland Road',
    manager: 'Daniel Farke',
    overall: 79,
    budget: 35000000,
    badgeColor: 'from-white via-yellow-400 to-blue-600',
    shortName: 'LEE',
    players: [
      { id: 'lee-1', name: 'Illan Meslier', age: 24, position: 'GK', specificRole: 'GK', overall: 79, stamina: 88, form: 8.1, marketValue: 18000000, wage: 15000, nationality: 'Fransa', attributes: { pace: 50, shooting: 15, passing: 78, defending: 79, physical: 78 }, isStarting: true },
      { id: 'lee-2', name: 'Pascal Struijk', age: 25, position: 'DEF', specificRole: 'CB', overall: 78, stamina: 90, form: 8.2, marketValue: 16000000, wage: 14000, nationality: 'Hollanda', attributes: { pace: 72, shooting: 40, passing: 74, defending: 80, physical: 84 }, isStarting: true },
      { id: 'lee-3', name: 'Joe Rodon', age: 26, position: 'DEF', specificRole: 'CB', overall: 78, stamina: 90, form: 8.1, marketValue: 15000000, wage: 14000, nationality: 'Galler', attributes: { pace: 74, shooting: 35, passing: 70, defending: 80, physical: 82 }, isStarting: true },
      { id: 'lee-4', name: 'Junior Firpo', age: 28, position: 'DEF', specificRole: 'LB', overall: 77, stamina: 88, form: 8.0, marketValue: 12000000, wage: 12000, nationality: 'Dominik Cum.', attributes: { pace: 82, shooting: 58, passing: 74, defending: 76, physical: 76 }, isStarting: true },
      { id: 'lee-5', name: 'Jayden Bogle', age: 24, position: 'DEF', specificRole: 'RB', overall: 77, stamina: 90, form: 8.1, marketValue: 12000000, wage: 12000, nationality: 'İngiltere', attributes: { pace: 84, shooting: 60, passing: 72, defending: 76, physical: 76 }, isStarting: true },
      { id: 'lee-6', name: 'Ethan Ampadu', age: 23, position: 'MID', specificRole: 'CDM', overall: 80, stamina: 92, form: 8.4, marketValue: 22000000, wage: 16000, nationality: 'Galler', attributes: { pace: 76, shooting: 62, passing: 80, defending: 82, physical: 82 }, isStarting: true },
      { id: 'lee-7', name: 'Ao Tanaka', age: 25, position: 'MID', specificRole: 'CM', overall: 78, stamina: 92, form: 8.3, marketValue: 16000000, wage: 14000, nationality: 'Japonya', attributes: { pace: 76, shooting: 72, passing: 82, defending: 74, physical: 78 }, isStarting: true },
      { id: 'lee-8', name: 'Brenden Aaronson', age: 23, position: 'MID', specificRole: 'CAM', overall: 78, stamina: 92, form: 8.2, marketValue: 18000000, wage: 14000, nationality: 'ABD', attributes: { pace: 82, shooting: 74, passing: 78, defending: 55, physical: 70 }, isStarting: true },
      { id: 'lee-9', name: 'Willy Gnonto', age: 20, position: 'FW', specificRole: 'RW', overall: 80, stamina: 90, form: 8.5, marketValue: 25000000, wage: 16000, nationality: 'İtalya', attributes: { pace: 90, shooting: 78, passing: 76, defending: 42, physical: 72 }, isStarting: true },
      { id: 'lee-10', name: 'Largie Ramazani', age: 23, position: 'FW', specificRole: 'LW', overall: 78, stamina: 89, form: 8.2, marketValue: 16000000, wage: 12000, nationality: 'Belçika', attributes: { pace: 89, shooting: 76, passing: 74, defending: 38, physical: 70 }, isStarting: true },
      { id: 'lee-11', name: 'Mateo Joseph', age: 20, position: 'FW', specificRole: 'ST', overall: 77, stamina: 88, form: 8.1, marketValue: 14000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 84, shooting: 78, passing: 68, defending: 35, physical: 78 }, isStarting: true },
      { id: 'lee-12', name: 'Joël Piroe', age: 25, position: 'FW', specificRole: 'ST', overall: 78, stamina: 86, form: 8.2, marketValue: 16000000, wage: 14000, nationality: 'Hollanda', attributes: { pace: 78, shooting: 82, passing: 72, defending: 38, physical: 76 }, isStarting: false },
      { id: 'lee-13', name: 'Manor Solomon', age: 25, position: 'FW', specificRole: 'LW', overall: 78, stamina: 88, form: 8.1, marketValue: 15000000, wage: 14000, nationality: 'İsrail', attributes: { pace: 86, shooting: 76, passing: 76, defending: 38, physical: 68 }, isStarting: false }
    ]
  },

  // 15. Everton
  {
    id: 'everton',
    name: 'Everton',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Goodison Park',
    manager: 'Sean Dyche',
    overall: 79,
    budget: 30000000,
    badgeColor: 'from-blue-700 to-blue-900',
    shortName: 'EVE',
    players: [
      { id: 'eve-1', name: 'Jordan Pickford', age: 30, position: 'GK', specificRole: 'GK', overall: 83, stamina: 88, form: 8.4, marketValue: 25000000, wage: 22000, nationality: 'İngiltere', attributes: { pace: 50, shooting: 15, passing: 82, defending: 84, physical: 78 }, isStarting: true },
      { id: 'eve-2', name: 'Jarrad Branthwaite', age: 22, position: 'DEF', specificRole: 'CB', overall: 82, stamina: 92, form: 8.5, marketValue: 50000000, wage: 20000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 40, passing: 76, defending: 83, physical: 85 }, isStarting: true },
      { id: 'eve-3', name: 'James Tarkowski', age: 31, position: 'DEF', specificRole: 'CB', overall: 81, stamina: 88, form: 8.2, marketValue: 18000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 62, shooting: 42, passing: 68, defending: 83, physical: 86 }, isStarting: true },
      { id: 'eve-4', name: 'Vitaliy Mykolenko', age: 25, position: 'DEF', specificRole: 'LB', overall: 78, stamina: 88, form: 8.0, marketValue: 20000000, wage: 15000, nationality: 'Ukrayna', attributes: { pace: 78, shooting: 52, passing: 72, defending: 79, physical: 78 }, isStarting: true },
      { id: 'eve-5', name: 'Idrissa Gueye', age: 34, position: 'MID', specificRole: 'CDM', overall: 79, stamina: 86, form: 8.1, marketValue: 8000000, wage: 15000, nationality: 'Senegal', attributes: { pace: 72, shooting: 62, passing: 74, defending: 82, physical: 80 }, isStarting: true },
      { id: 'eve-6', name: 'Dwight McNeil', age: 24, position: 'MID', specificRole: 'CAM', overall: 79, stamina: 90, form: 8.3, marketValue: 25000000, wage: 16000, nationality: 'İngiltere', attributes: { pace: 76, shooting: 78, passing: 80, defending: 58, physical: 74 }, isStarting: true },
      { id: 'eve-7', name: 'Dominic Calvert-Lewin', age: 27, position: 'FW', specificRole: 'ST', overall: 79, stamina: 86, form: 8.1, marketValue: 22000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 80, shooting: 79, passing: 68, defending: 42, physical: 86 }, isStarting: true },
      { id: 'eve-8', name: 'Iliman Ndiaye', age: 24, position: 'FW', specificRole: 'LW', overall: 79, stamina: 88, form: 8.2, marketValue: 25000000, wage: 15000, nationality: 'Senegal', attributes: { pace: 84, shooting: 76, passing: 78, defending: 42, physical: 74 }, isStarting: true }
    ]
  },

  // 16. Crystal Palace
  {
    id: 'crystal-palace',
    name: 'Crystal Palace',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Selhurst Park',
    manager: 'Oliver Glasner',
    overall: 80,
    budget: 40000000,
    badgeColor: 'from-blue-600 to-red-600',
    shortName: 'CRY',
    players: [
      { id: 'cry-1', name: 'Dean Henderson', age: 27, position: 'GK', specificRole: 'GK', overall: 80, stamina: 86, form: 8.2, marketValue: 18000000, wage: 16000, nationality: 'İngiltere', attributes: { pace: 50, shooting: 15, passing: 74, defending: 81, physical: 78 }, isStarting: true },
      { id: 'cry-2', name: 'Marc Guéhi', age: 24, position: 'DEF', specificRole: 'CB', overall: 83, stamina: 92, form: 8.5, marketValue: 50000000, wage: 22000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 40, passing: 76, defending: 84, physical: 83 }, isStarting: true },
      { id: 'cry-3', name: 'Maxence Lacroix', age: 24, position: 'DEF', specificRole: 'CB', overall: 80, stamina: 88, form: 8.1, marketValue: 28000000, wage: 16000, nationality: 'Fransa', attributes: { pace: 85, shooting: 38, passing: 68, defending: 80, physical: 82 }, isStarting: true },
      { id: 'cry-4', name: 'Daniel Muñoz', age: 28, position: 'DEF', specificRole: 'RB', overall: 81, stamina: 94, form: 8.4, marketValue: 30000000, wage: 18000, nationality: 'Kolombiya', attributes: { pace: 84, shooting: 68, passing: 76, defending: 80, physical: 82 }, isStarting: true },
      { id: 'cry-5', name: 'Adam Wharton', age: 20, position: 'MID', specificRole: 'CDM', overall: 81, stamina: 90, form: 8.6, marketValue: 45000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 74, shooting: 68, passing: 84, defending: 80, physical: 76 }, isStarting: true },
      { id: 'cry-6', name: 'Eberechi Eze', age: 26, position: 'MID', specificRole: 'CAM', overall: 84, stamina: 90, form: 8.7, marketValue: 65000000, wage: 28000, nationality: 'İngiltere', attributes: { pace: 82, shooting: 82, passing: 86, defending: 48, physical: 74 }, isStarting: true },
      { id: 'cry-7', name: 'Daichi Kamada', age: 28, position: 'MID', specificRole: 'CAM', overall: 79, stamina: 88, form: 8.0, marketValue: 22000000, wage: 16000, nationality: 'Japonya', attributes: { pace: 74, shooting: 76, passing: 80, defending: 52, physical: 70 }, isStarting: true },
      { id: 'cry-8', name: 'Jean-Philippe Mateta', age: 27, position: 'FW', specificRole: 'ST', overall: 82, stamina: 90, form: 8.6, marketValue: 38000000, wage: 20000, nationality: 'Fransa', attributes: { pace: 80, shooting: 83, passing: 68, defending: 38, physical: 87 }, isStarting: true },
      { id: 'cry-9', name: 'Ismaïla Sarr', age: 26, position: 'FW', specificRole: 'RW', overall: 79, stamina: 88, form: 8.1, marketValue: 22000000, wage: 15000, nationality: 'Senegal', attributes: { pace: 90, shooting: 76, passing: 74, defending: 38, physical: 74 }, isStarting: true }
    ]
  },

  // 17. Sunderland
  {
    id: 'sunderland',
    name: 'Sunderland',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Stadium of Light',
    manager: 'Régis Le Bris',
    overall: 78,
    budget: 30000000,
    badgeColor: 'from-red-600 to-white',
    shortName: 'SUN',
    players: [
      { id: 'sun-1', name: 'Anthony Patterson', age: 24, position: 'GK', specificRole: 'GK', overall: 78, stamina: 88, form: 8.2, marketValue: 15000000, wage: 12000, nationality: 'İngiltere', attributes: { pace: 50, shooting: 15, passing: 74, defending: 78, physical: 78 }, isStarting: true },
      { id: 'sun-2', name: 'Trai Hume', age: 22, position: 'DEF', specificRole: 'RB', overall: 77, stamina: 92, form: 8.1, marketValue: 14000000, wage: 10000, nationality: 'Kuzey İrlanda', attributes: { pace: 80, shooting: 52, passing: 72, defending: 78, physical: 78 }, isStarting: true },
      { id: 'sun-3', name: 'Dan Ballard', age: 24, position: 'DEF', specificRole: 'CB', overall: 78, stamina: 90, form: 8.2, marketValue: 15000000, wage: 12000, nationality: 'Kuzey İrlanda', attributes: { pace: 72, shooting: 38, passing: 68, defending: 80, physical: 86 }, isStarting: true },
      { id: 'sun-4', name: 'Luke O\'Nien', age: 29, position: 'DEF', specificRole: 'CB', overall: 77, stamina: 94, form: 8.1, marketValue: 10000000, wage: 12000, nationality: 'İngiltere', attributes: { pace: 74, shooting: 58, passing: 74, defending: 78, physical: 80 }, isStarting: true },
      { id: 'sun-5', name: 'Dennis Cirkin', age: 22, position: 'DEF', specificRole: 'LB', overall: 77, stamina: 90, form: 8.2, marketValue: 14000000, wage: 10000, nationality: 'İngiltere', attributes: { pace: 84, shooting: 60, passing: 74, defending: 76, physical: 76 }, isStarting: true },
      { id: 'sun-6', name: 'Dan Neil', age: 22, position: 'MID', specificRole: 'CDM', overall: 78, stamina: 92, form: 8.3, marketValue: 18000000, wage: 14000, nationality: 'İngiltere', attributes: { pace: 74, shooting: 70, passing: 80, defending: 78, physical: 78 }, isStarting: true },
      { id: 'sun-7', name: 'Jobe Bellingham', age: 19, position: 'MID', specificRole: 'CM', overall: 79, stamina: 92, form: 8.5, marketValue: 24000000, wage: 14000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 76, passing: 80, defending: 72, physical: 82 }, isStarting: true },
      { id: 'sun-8', name: 'Chris Rigg', age: 17, position: 'MID', specificRole: 'CAM', overall: 77, stamina: 90, form: 8.4, marketValue: 20000000, wage: 8000, nationality: 'İngiltere', attributes: { pace: 80, shooting: 74, passing: 78, defending: 55, physical: 70 }, isStarting: true },
      { id: 'sun-9', name: 'Patrick Roberts', age: 27, position: 'FW', specificRole: 'RW', overall: 78, stamina: 88, form: 8.2, marketValue: 14000000, wage: 12000, nationality: 'İngiltere', attributes: { pace: 84, shooting: 76, passing: 80, defending: 40, physical: 66 }, isStarting: true },
      { id: 'sun-10', name: 'Romaine Mundle', age: 21, position: 'FW', specificRole: 'LW', overall: 78, stamina: 90, form: 8.4, marketValue: 16000000, wage: 10000, nationality: 'İngiltere', attributes: { pace: 88, shooting: 78, passing: 74, defending: 38, physical: 70 }, isStarting: true },
      { id: 'sun-11', name: 'Wilson Isidor', age: 24, position: 'FW', specificRole: 'ST', overall: 78, stamina: 89, form: 8.3, marketValue: 16000000, wage: 12000, nationality: 'Fransa', attributes: { pace: 86, shooting: 80, passing: 70, defending: 35, physical: 76 }, isStarting: true }
    ]
  },

  // 18. Nottingham Forest
  {
    id: 'nottingham-forest',
    name: 'Nottingham Forest',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'City Ground',
    manager: 'Nuno Espírito Santo',
    overall: 80,
    budget: 45000000,
    badgeColor: 'from-red-600 to-red-800',
    shortName: 'NFO',
    players: [
      { id: 'nfo-1', name: 'Matz Sels', age: 32, position: 'GK', specificRole: 'GK', overall: 80, stamina: 86, form: 8.3, marketValue: 15000000, wage: 15000, nationality: 'Belçika', attributes: { pace: 50, shooting: 15, passing: 72, defending: 81, physical: 78 }, isStarting: true },
      { id: 'nfo-2', name: 'Murillo', age: 22, position: 'DEF', specificRole: 'CB', overall: 82, stamina: 92, form: 8.6, marketValue: 45000000, wage: 18000, nationality: 'Brezilya', attributes: { pace: 80, shooting: 52, passing: 78, defending: 83, physical: 85 }, isStarting: true },
      { id: 'nfo-3', name: 'Nikola Milenković', age: 26, position: 'DEF', specificRole: 'CB', overall: 81, stamina: 88, form: 8.3, marketValue: 28000000, wage: 18000, nationality: 'Sırbistan', attributes: { pace: 70, shooting: 40, passing: 70, defending: 82, physical: 88 }, isStarting: true },
      { id: 'nfo-4', name: 'Ola Aina', age: 27, position: 'DEF', specificRole: 'LB', overall: 79, stamina: 90, form: 8.2, marketValue: 18000000, wage: 14000, nationality: 'Nijerya', attributes: { pace: 84, shooting: 60, passing: 74, defending: 78, physical: 78 }, isStarting: true },
      { id: 'nfo-5', name: 'Neco Williams', age: 23, position: 'DEF', specificRole: 'RB', overall: 78, stamina: 88, form: 8.0, marketValue: 18000000, wage: 12000, nationality: 'Galler', attributes: { pace: 82, shooting: 62, passing: 74, defending: 76, physical: 74 }, isStarting: true },
      { id: 'nfo-6', name: 'Elliot Anderson', age: 21, position: 'MID', specificRole: 'CM', overall: 79, stamina: 90, form: 8.3, marketValue: 28000000, wage: 14000, nationality: 'İskoçya', attributes: { pace: 78, shooting: 74, passing: 80, defending: 74, physical: 78 }, isStarting: true },
      { id: 'nfo-7', name: 'Morgan Gibbs-White', age: 24, position: 'MID', specificRole: 'CAM', overall: 83, stamina: 92, form: 8.7, marketValue: 55000000, wage: 25000, nationality: 'İngiltere', attributes: { pace: 80, shooting: 80, passing: 85, defending: 58, physical: 76 }, isStarting: true },
      { id: 'nfo-8', name: 'Callum Hudson-Odoi', age: 23, position: 'FW', specificRole: 'LW', overall: 80, stamina: 88, form: 8.3, marketValue: 28000000, wage: 16000, nationality: 'İngiltere', attributes: { pace: 88, shooting: 78, passing: 78, defending: 40, physical: 72 }, isStarting: true },
      { id: 'nfo-9', name: 'Anthony Elanga', age: 22, position: 'FW', specificRole: 'RW', overall: 80, stamina: 90, form: 8.3, marketValue: 30000000, wage: 16000, nationality: 'İsveç', attributes: { pace: 92, shooting: 76, passing: 75, defending: 42, physical: 74 }, isStarting: true },
      { id: 'nfo-10', name: 'Chris Wood', age: 32, position: 'FW', specificRole: 'ST', overall: 82, stamina: 86, form: 8.7, marketValue: 20000000, wage: 20000, nationality: 'Yeni Zelanda', attributes: { pace: 70, shooting: 84, passing: 65, defending: 40, physical: 88 }, isStarting: true }
    ]
  },

  // 19. Ipswich Town
  {
    id: 'ipswich',
    name: 'Ipswich Town',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Portman Road',
    manager: 'Kieran McKenna',
    overall: 76,
    budget: 25000000,
    badgeColor: 'from-blue-600 to-white',
    shortName: 'IPS',
    players: [
      { id: 'ips-1', name: 'Arijanet Muric', age: 25, position: 'GK', specificRole: 'GK', overall: 77, stamina: 86, form: 7.9, marketValue: 12000000, wage: 10000, nationality: 'Kosova', attributes: { pace: 50, shooting: 15, passing: 76, defending: 77, physical: 80 }, isStarting: true },
      { id: 'ips-2', name: 'Jacob Greaves', age: 23, position: 'DEF', specificRole: 'CB', overall: 77, stamina: 88, form: 8.0, marketValue: 18000000, wage: 10000, nationality: 'İngiltere', attributes: { pace: 72, shooting: 38, passing: 72, defending: 78, physical: 82 }, isStarting: true },
      { id: 'ips-3', name: 'Leif Davis', age: 24, position: 'DEF', specificRole: 'LB', overall: 77, stamina: 92, form: 8.1, marketValue: 18000000, wage: 10000, nationality: 'İngiltere', attributes: { pace: 84, shooting: 60, passing: 80, defending: 74, physical: 72 }, isStarting: true },
      { id: 'ips-4', name: 'Kalvin Phillips', age: 28, position: 'MID', specificRole: 'CDM', overall: 78, stamina: 85, form: 7.9, marketValue: 18000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 68, shooting: 68, passing: 80, defending: 80, physical: 80 }, isStarting: true },
      { id: 'ips-5', name: 'Omari Hutchinson', age: 20, position: 'FW', specificRole: 'RW', overall: 78, stamina: 90, form: 8.3, marketValue: 22000000, wage: 12000, nationality: 'Jamaika', attributes: { pace: 88, shooting: 76, passing: 78, defending: 40, physical: 68 }, isStarting: true },
      { id: 'ips-6', name: 'Liam Delap', age: 21, position: 'FW', specificRole: 'ST', overall: 78, stamina: 88, form: 8.4, marketValue: 20000000, wage: 12000, nationality: 'İngiltere', attributes: { pace: 84, shooting: 79, passing: 68, defending: 38, physical: 84 }, isStarting: true },
      { id: 'ips-7', name: 'Sammie Szmodics', age: 28, position: 'FW', specificRole: 'CAM', overall: 77, stamina: 88, form: 8.1, marketValue: 15000000, wage: 10000, nationality: 'İrlanda', attributes: { pace: 78, shooting: 78, passing: 76, defending: 50, physical: 74 }, isStarting: true }
    ]
  },

  // 20. Coventry City
  {
    id: 'coventry-city',
    name: 'Coventry City',
    country: 'İngiltere',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    stadium: 'Coventry Building Society Arena',
    manager: 'Mark Robins',
    overall: 76,
    budget: 24000000,
    badgeColor: 'from-sky-500 to-sky-700',
    shortName: 'COV',
    players: [
      { id: 'cov-1', name: 'Oliver Dovin', age: 22, position: 'GK', specificRole: 'GK', overall: 76, stamina: 86, form: 7.9, marketValue: 6000000, wage: 8000, nationality: 'İsveç', attributes: { pace: 50, shooting: 15, passing: 70, defending: 76, physical: 76 }, isStarting: true },
      { id: 'cov-2', name: 'Bobby Thomas', age: 23, position: 'DEF', specificRole: 'CB', overall: 76, stamina: 88, form: 7.9, marketValue: 7000000, wage: 9000, nationality: 'İngiltere', attributes: { pace: 70, shooting: 35, passing: 68, defending: 77, physical: 82 }, isStarting: true },
      { id: 'cov-3', name: 'Liam Kitching', age: 24, position: 'DEF', specificRole: 'CB', overall: 76, stamina: 88, form: 7.8, marketValue: 6500000, wage: 9000, nationality: 'İngiltere', attributes: { pace: 68, shooting: 32, passing: 66, defending: 76, physical: 84 }, isStarting: true },
      { id: 'cov-4', name: 'Milan van Ewijk', age: 23, position: 'DEF', specificRole: 'RB', overall: 78, stamina: 92, form: 8.2, marketValue: 12000000, wage: 11000, nationality: 'Hollanda', attributes: { pace: 88, shooting: 60, passing: 74, defending: 76, physical: 76 }, isStarting: true },
      { id: 'cov-5', name: 'Jake Bidwell', age: 31, position: 'DEF', specificRole: 'LB', overall: 75, stamina: 86, form: 7.7, marketValue: 4000000, wage: 8000, nationality: 'İngiltere', attributes: { pace: 72, shooting: 52, passing: 70, defending: 75, physical: 80 }, isStarting: true },
      { id: 'cov-6', name: 'Ben Sheaf', age: 26, position: 'MID', specificRole: 'CDM', overall: 78, stamina: 92, form: 8.2, marketValue: 12000000, wage: 12000, nationality: 'İngiltere', attributes: { pace: 72, shooting: 68, passing: 80, defending: 79, physical: 82 }, isStarting: true },
      { id: 'cov-7', name: 'Jack Rudoni', age: 23, position: 'MID', specificRole: 'CM', overall: 77, stamina: 90, form: 8.0, marketValue: 9000000, wage: 9000, nationality: 'İngiltere', attributes: { pace: 76, shooting: 72, passing: 78, defending: 70, physical: 78 }, isStarting: true },
      { id: 'cov-8', name: 'Tatsuhiro Sakamoto', age: 27, position: 'FW', specificRole: 'RW', overall: 77, stamina: 90, form: 8.1, marketValue: 9000000, wage: 10000, nationality: 'Japonya', attributes: { pace: 84, shooting: 74, passing: 78, defending: 48, physical: 68 }, isStarting: true },
      { id: 'cov-9', name: 'Haji Wright', age: 26, position: 'FW', specificRole: 'LW', overall: 79, stamina: 90, form: 8.4, marketValue: 15000000, wage: 14000, nationality: 'ABD', attributes: { pace: 86, shooting: 82, passing: 72, defending: 40, physical: 84 }, isStarting: true },
      { id: 'cov-10', name: 'Ellis Simms', age: 23, position: 'FW', specificRole: 'ST', overall: 77, stamina: 88, form: 8.0, marketValue: 10000000, wage: 11000, nationality: 'İngiltere', attributes: { pace: 80, shooting: 80, passing: 68, defending: 35, physical: 86 }, isStarting: true },
      { id: 'cov-11', name: 'Norman Bassette', age: 19, position: 'FW', specificRole: 'ST', overall: 74, stamina: 86, form: 7.7, marketValue: 5000000, wage: 6000, nationality: 'Belçika', attributes: { pace: 82, shooting: 74, passing: 64, defending: 32, physical: 78 }, isStarting: false }
    ]
  }
];
