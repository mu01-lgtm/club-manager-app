import { Team, LeagueRow, Fixture, ManagerProfile, PitchPosition, FormationType } from '../types';
import { SUPER_LIG_TEAMS, SUPER_LIG_LEAGUE_TABLE } from './superLigTeams';

export const INITIAL_TEAMS: Team[] = SUPER_LIG_TEAMS;
export const INITIAL_LEAGUE_TABLE: LeagueRow[] = SUPER_LIG_LEAGUE_TABLE;


export const DEFAULT_MANAGER: ManagerProfile = {
  name: "Ali Yılmaz",
  experienceYears: 5,
  nationality: "Türkiye",
  favoriteFormation: "4-3-3",
  trophiesWon: 2
};

export const FORMATION_COORDINATES: Record<FormationType, PitchPosition[]> = {
  '4-3-3': [
    { role: 'GK', posName: 'Kaleci', topPct: 89, leftPct: 50 },
    { role: 'LB', posName: 'Sol Bek', topPct: 70, leftPct: 15 },
    { role: 'CB', posName: 'Sol Stoper', topPct: 71, leftPct: 37 },
    { role: 'CB', posName: 'Sağ Stoper', topPct: 71, leftPct: 63 },
    { role: 'RB', posName: 'Sağ Bek', topPct: 70, leftPct: 85 },
    { role: 'CM', posName: 'Sol İç', topPct: 50, leftPct: 28 },
    { role: 'CDM', posName: 'Ön Libero', topPct: 54, leftPct: 50 },
    { role: 'CM', posName: 'Sağ İç', topPct: 50, leftPct: 72 },
    { role: 'LW', posName: 'Sol Kanat', topPct: 26, leftPct: 20 },
    { role: 'ST', posName: 'Santrafor', topPct: 16, leftPct: 50 },
    { role: 'RW', posName: 'Sağ Kanat', topPct: 26, leftPct: 80 },
  ],
  '4-2-3-1': [
    { role: 'GK', posName: 'Kaleci', topPct: 89, leftPct: 50 },
    { role: 'LB', posName: 'Sol Bek', topPct: 70, leftPct: 15 },
    { role: 'CB', posName: 'Sol Stoper', topPct: 71, leftPct: 37 },
    { role: 'CB', posName: 'Sağ Stoper', topPct: 71, leftPct: 63 },
    { role: 'RB', posName: 'Sağ Bek', topPct: 70, leftPct: 85 },
    { role: 'CDM', posName: 'Defansif OS', topPct: 54, leftPct: 34 },
    { role: 'CDM', posName: 'Defansif OS', topPct: 54, leftPct: 66 },
    { role: 'LM', posName: 'Sol Orta', topPct: 34, leftPct: 18 },
    { role: 'CAM', posName: 'Ofansif OS', topPct: 34, leftPct: 50 },
    { role: 'RM', posName: 'Sağ Orta', topPct: 34, leftPct: 82 },
    { role: 'ST', posName: 'Santrafor', topPct: 16, leftPct: 50 },
  ],
  '4-4-2': [
    { role: 'GK', posName: 'Kaleci', topPct: 89, leftPct: 50 },
    { role: 'LB', posName: 'Sol Bek', topPct: 70, leftPct: 15 },
    { role: 'CB', posName: 'Sol Stoper', topPct: 71, leftPct: 37 },
    { role: 'CB', posName: 'Sağ Stoper', topPct: 71, leftPct: 63 },
    { role: 'RB', posName: 'Sağ Bek', topPct: 70, leftPct: 85 },
    { role: 'LM', posName: 'Sol Kanat', topPct: 48, leftPct: 16 },
    { role: 'CM', posName: 'Merkez OS', topPct: 50, leftPct: 38 },
    { role: 'CM', posName: 'Merkez OS', topPct: 50, leftPct: 62 },
    { role: 'RM', posName: 'Sağ Kanat', topPct: 48, leftPct: 84 },
    { role: 'ST', posName: 'Sol Forvet', topPct: 17, leftPct: 36 },
    { role: 'ST', posName: 'Sağ Forvet', topPct: 17, leftPct: 64 },
  ],
  '3-5-2': [
    { role: 'GK', posName: 'Kaleci', topPct: 89, leftPct: 50 },
    { role: 'CB', posName: 'Sol Stoper', topPct: 71, leftPct: 25 },
    { role: 'CB', posName: 'Merkez Stoper', topPct: 72, leftPct: 50 },
    { role: 'CB', posName: 'Sağ Stoper', topPct: 71, leftPct: 75 },
    { role: 'LWB', posName: 'Sol Kanat Bek', topPct: 48, leftPct: 14 },
    { role: 'CDM', posName: 'Defansif OS', topPct: 54, leftPct: 34 },
    { role: 'CAM', posName: 'Ofansif OS', topPct: 36, leftPct: 50 },
    { role: 'CDM', posName: 'Defansif OS', topPct: 54, leftPct: 66 },
    { role: 'RWB', posName: 'Sağ Kanat Bek', topPct: 48, leftPct: 86 },
    { role: 'ST', posName: 'Sol Forvet', topPct: 17, leftPct: 36 },
    { role: 'ST', posName: 'Sağ Forvet', topPct: 17, leftPct: 64 },
  ],
  '5-3-2': [
    { role: 'GK', posName: 'Kaleci', topPct: 89, leftPct: 50 },
    { role: 'LWB', posName: 'Sol Bek', topPct: 68, leftPct: 14 },
    { role: 'CB', posName: 'Sol Stoper', topPct: 72, leftPct: 32 },
    { role: 'CB', posName: 'Merkez Stoper', topPct: 73, leftPct: 50 },
    { role: 'CB', posName: 'Sağ Stoper', topPct: 72, leftPct: 68 },
    { role: 'RWB', posName: 'Sağ Bek', topPct: 68, leftPct: 86 },
    { role: 'CM', posName: 'Sol OS', topPct: 50, leftPct: 30 },
    { role: 'CDM', posName: 'Merkez OS', topPct: 53, leftPct: 50 },
    { role: 'CM', posName: 'Sağ OS', topPct: 50, leftPct: 70 },
    { role: 'ST', posName: 'Sol Forvet', topPct: 17, leftPct: 36 },
    { role: 'ST', posName: 'Sağ Forvet', topPct: 17, leftPct: 64 },
  ],
  '4-1-4-1': [
    { role: 'GK', posName: 'Kaleci', topPct: 89, leftPct: 50 },
    { role: 'LB', posName: 'Sol Bek', topPct: 70, leftPct: 15 },
    { role: 'CB', posName: 'Sol Stoper', topPct: 71, leftPct: 37 },
    { role: 'CB', posName: 'Sağ Stoper', topPct: 71, leftPct: 63 },
    { role: 'RB', posName: 'Sağ Bek', topPct: 70, leftPct: 85 },
    { role: 'CDM', posName: 'Ön Libero', topPct: 56, leftPct: 50 },
    { role: 'LM', posName: 'Sol Kanat', topPct: 36, leftPct: 18 },
    { role: 'CM', posName: 'Sol OS', topPct: 38, leftPct: 38 },
    { role: 'CM', posName: 'Sağ OS', topPct: 38, leftPct: 62 },
    { role: 'RM', posName: 'Sağ Kanat', topPct: 36, leftPct: 82 },
    { role: 'ST', posName: 'Santrafor', topPct: 16, leftPct: 50 },
  ],
  '3-4-3': [
    { role: 'GK', posName: 'Kaleci', topPct: 89, leftPct: 50 },
    { role: 'CB', posName: 'Sol Stoper', topPct: 71, leftPct: 25 },
    { role: 'CB', posName: 'Merkez Stoper', topPct: 72, leftPct: 50 },
    { role: 'CB', posName: 'Sağ Stoper', topPct: 71, leftPct: 75 },
    { role: 'LM', posName: 'Sol Kanat', topPct: 48, leftPct: 15 },
    { role: 'CM', posName: 'Sol OS', topPct: 50, leftPct: 38 },
    { role: 'CM', posName: 'Sağ OS', topPct: 50, leftPct: 62 },
    { role: 'RM', posName: 'Sağ Kanat', topPct: 48, leftPct: 85 },
    { role: 'LW', posName: 'Sol Forvet', topPct: 24, leftPct: 20 },
    { role: 'ST', posName: 'Santrafor', topPct: 16, leftPct: 50 },
    { role: 'RW', posName: 'Sağ Forvet', topPct: 24, leftPct: 80 },
  ]
};

// Teams & League Table are loaded from ./superLigTeams.ts

export function generateInitialStandings(teams: Team[]): LeagueRow[] {
  return teams.map(t => ({
    teamId: t.id,
    teamName: t.name,
    badgeColor: t.badgeColor,
    badgeTextColor: t.badgeTextColor || 'text-white',
    played: 0,
    won: 0,
    drawn: 0,
    lost: 0,
    goalsFor: 0,
    goalsAgainst: 0,
    goalDifference: 0,
    points: 0,
    formHistory: []
  }));
}


import { getLeagueConfigForTeam, MONTHS_BY_LANG, DAYS_BY_LANG } from '../utils/dateHelper';

// League Table is initialized from SUPER_LIG_TEAMS at start of career

export function generateLeagueSchedule(teamIds: string[], leagueKeyOrTeamId?: string, season: number = 1): Fixture[] {
  const fixtures: Fixture[] = [];
  const list = [...teamIds];
  if (list.length % 2 !== 0) {
    list.push('BYE');
  }
  const n = list.length;
  let fixtureId = 1;

  const numRounds = n - 1;
  const sampleTeamId = leagueKeyOrTeamId || teamIds[0] || 'galatasaray';
  const leagueConfig = getLeagueConfigForTeam(sampleTeamId);
  const baseYear = (leagueConfig.startYear || 2025) + (season - 1);
  const baseStartDate = new Date(baseYear, leagueConfig.startMonth, leagueConfig.startDay);

  const calculateFixtureDateInfo = (weekNum: number, matchIdxInWeek: number) => {
    const dist = leagueConfig.matchDistribution;
    const matchSlot = dist[matchIdxInWeek % dist.length] || { dayOffset: 1, time: '20:00', dayIndex: 5 };

    const matchDateObj = new Date(baseStartDate.getTime());
    // Add weeks
    matchDateObj.setDate(matchDateObj.getDate() + (weekNum - 1) * 7 + matchSlot.dayOffset);

    const dayNum = matchDateObj.getDate();
    const monthIdx = matchDateObj.getMonth();
    const monthNameTR = MONTHS_BY_LANG.TR[monthIdx];
    const jsDay = matchDateObj.getDay();
    const customDayIndex = jsDay === 0 ? 6 : jsDay - 1;
    const dayNameTR = DAYS_BY_LANG.TR[customDayIndex];

    return {
      matchDate: `${dayNum} ${monthNameTR} ${matchDateObj.getFullYear()}`,
      matchTime: matchSlot.time,
      dayName: dayNameTR,
      dayIndex: matchSlot.dayIndex,
      leagueId: leagueConfig.leagueId
    };
  };

  for (let round = 0; round < numRounds; round++) {
    const weekNumber = round + 1;
    let matchIdxInWeek = 0;
    for (let i = 0; i < n / 2; i++) {
      let homeIdx: number;
      let awayIdx: number;

      if (i === 0) {
        homeIdx = round;
        awayIdx = n - 1;
      } else {
        homeIdx = (round + i) % (n - 1);
        awayIdx = (round - i + (n - 1)) % (n - 1);
      }

      // Alternate home/away for the fixed team
      if (i === 0 && round % 2 === 1) {
        const temp = homeIdx;
        homeIdx = awayIdx;
        awayIdx = temp;
      }

      const home = list[homeIdx];
      const away = list[awayIdx];

      if (home !== 'BYE' && away !== 'BYE') {
        const dateInfo = calculateFixtureDateInfo(weekNumber, matchIdxInWeek++);
        fixtures.push({
          id: `fix-${fixtureId++}`,
          week: weekNumber,
          homeTeamId: home,
          awayTeamId: away,
          played: false,
          matchDate: dateInfo.matchDate,
          matchTime: dateInfo.matchTime,
          dayName: dateInfo.dayName,
          dayIndex: dateInfo.dayIndex,
          leagueId: dateInfo.leagueId
        });
      }
    }
  }

  // Second half (Rövanş Maçları)
  const firstHalfFixtures = [...fixtures];
  for (const f of firstHalfFixtures) {
    const weekNumber = f.week + numRounds;
    // calculate corresponding return leg date
    const dateInfo = calculateFixtureDateInfo(weekNumber, (fixtureId % (n / 2)));
    fixtures.push({
      id: `fix-${fixtureId++}`,
      week: weekNumber,
      homeTeamId: f.awayTeamId,
      awayTeamId: f.homeTeamId,
      played: false,
      matchDate: dateInfo.matchDate,
      matchTime: dateInfo.matchTime,
      dayName: dateInfo.dayName,
      dayIndex: dateInfo.dayIndex,
      leagueId: dateInfo.leagueId
    });
  }

  return fixtures;
}

export const INITIAL_MARKET_PLAYERS = [
  { id: 'mkt-1', name: 'Sergio Ramos', age: 38, position: 'DEF' as const, specificRole: 'CB', overall: 81, stamina: 80, form: 8.0, marketValue: 2000000, nationality: 'İspanya', attributes: { pace: 60, shooting: 65, passing: 75, defending: 83, physical: 82 }, isStarting: false },
  { id: 'mkt-2', name: 'Wissam Ben Yedder', age: 34, position: 'FW' as const, specificRole: 'ST', overall: 80, stamina: 82, form: 7.9, marketValue: 3500000, nationality: 'Fransa', attributes: { pace: 78, shooting: 82, passing: 78, defending: 38, physical: 68 }, isStarting: false },
  { id: 'mkt-3', name: 'Keylor Navas', age: 37, position: 'GK' as const, specificRole: 'GK', overall: 80, stamina: 82, form: 8.0, marketValue: 2000000, nationality: 'Kosta Rika', attributes: { pace: 50, shooting: 15, passing: 72, defending: 81, physical: 74 }, isStarting: false },
  { id: 'mkt-4', name: 'Joel Matip', age: 33, position: 'DEF' as const, specificRole: 'CB', overall: 79, stamina: 80, form: 7.8, marketValue: 3000000, nationality: 'Kamerun', attributes: { pace: 64, shooting: 40, passing: 72, defending: 81, physical: 80 }, isStarting: false },
  { id: 'mkt-5', name: 'Dele Alli', age: 28, position: 'MID' as const, specificRole: 'CAM', overall: 76, stamina: 82, form: 7.5, marketValue: 4000000, nationality: 'İngiltere', attributes: { pace: 74, shooting: 76, passing: 76, defending: 60, physical: 74 }, isStarting: false },
  { id: 'mkt-6', name: 'Miralem Pjanic', age: 34, position: 'MID' as const, specificRole: 'CM', overall: 77, stamina: 80, form: 7.7, marketValue: 2500000, nationality: 'Bosna-Hersek', attributes: { pace: 62, shooting: 74, passing: 84, defending: 68, physical: 66 }, isStarting: false },
  { id: 'mkt-7', name: 'Memphis Depay', age: 30, position: 'FW' as const, specificRole: 'ST', overall: 81, stamina: 85, form: 8.0, marketValue: 5000000, nationality: 'Hollanda', attributes: { pace: 80, shooting: 82, passing: 80, defending: 35, physical: 78 }, isStarting: false },
  { id: 'mkt-8', name: 'Rafinha Alcântara', age: 31, position: 'MID' as const, specificRole: 'CAM', overall: 76, stamina: 82, form: 7.6, marketValue: 3000000, nationality: 'Brezilya', attributes: { pace: 72, shooting: 74, passing: 80, defending: 55, physical: 68 }, isStarting: false }
];
