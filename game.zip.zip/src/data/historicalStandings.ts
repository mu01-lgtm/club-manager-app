import { LeagueRow } from '../types';

export interface HistoricalSeasonStanding {
  season: string;
  seasonLabel: string;
  champion: string;
  standings: LeagueRow[];
}

export const SUPER_LIG_HISTORICAL_STANDINGS: Record<string, HistoricalSeasonStanding> = {
  '2024-25': {
    season: '2024/25',
    seasonLabel: '2024/25 Sezonu (Geçen Sezon)',
    champion: 'Galatasaray',
    standings: [
      { teamId: 'galatasaray', teamName: 'Galatasaray', played: 38, won: 33, drawn: 3, lost: 2, goalsFor: 92, goalsAgainst: 26, goalDifference: 66, points: 102, formHistory: ['W', 'W', 'W', 'W', 'W'] },
      { teamId: 'fenerbahce', teamName: 'Fenerbahçe', played: 38, won: 31, drawn: 6, lost: 1, goalsFor: 99, goalsAgainst: 31, goalDifference: 68, points: 99, formHistory: ['W', 'W', 'W', 'D', 'W'] },
      { teamId: 'trabzonspor', teamName: 'Trabzonspor', played: 38, won: 21, drawn: 4, lost: 13, goalsFor: 69, goalsAgainst: 50, goalDifference: 19, points: 67, formHistory: ['W', 'W', 'L', 'W', 'W'] },
      { teamId: 'basaksehir', teamName: 'RAMS Başakşehir', played: 38, won: 18, drawn: 7, lost: 13, goalsFor: 57, goalsAgainst: 43, goalDifference: 14, points: 61, formHistory: ['W', 'D', 'W', 'W', 'L'] },
      { teamId: 'kasimpasa', teamName: 'Kasımpaşa', played: 38, won: 16, drawn: 8, lost: 14, goalsFor: 62, goalsAgainst: 65, goalDifference: -3, points: 56, formHistory: ['W', 'L', 'W', 'W', 'D'] },
      { teamId: 'besiktas', teamName: 'Beşiktaş', played: 38, won: 16, drawn: 8, lost: 14, goalsFor: 52, goalsAgainst: 47, goalDifference: 5, points: 56, formHistory: ['D', 'W', 'L', 'W', 'D'] },
      { teamId: 'sivasspor', teamName: 'EMS Yapı Sivasspor', played: 38, won: 14, drawn: 12, lost: 12, goalsFor: 47, goalsAgainst: 54, goalDifference: -7, points: 54, formHistory: ['W', 'D', 'W', 'D', 'L'] },
      { teamId: 'alanyaspor', teamName: 'Corendon Alanyaspor', played: 38, won: 12, drawn: 16, lost: 10, goalsFor: 53, goalsAgainst: 50, goalDifference: 3, points: 52, formHistory: ['D', 'D', 'D', 'W', 'D'] },
      { teamId: 'caykurrizespor', teamName: 'Çaykur Rizespor', played: 38, won: 14, drawn: 8, lost: 16, goalsFor: 48, goalsAgainst: 58, goalDifference: -10, points: 50, formHistory: ['L', 'D', 'L', 'W', 'L'] },
      { teamId: 'antalyaspor', teamName: 'Bitexen Antalyaspor', played: 38, won: 12, drawn: 13, lost: 13, goalsFor: 44, goalsAgainst: 49, goalDifference: -5, points: 49, formHistory: ['D', 'L', 'W', 'L', 'D'] },
      { teamId: 'gaziantepfk', teamName: 'Gaziantep FK', played: 38, won: 12, drawn: 8, lost: 18, goalsFor: 50, goalsAgainst: 57, goalDifference: -7, points: 44, formHistory: ['W', 'W', 'W', 'L', 'D'] },
      { teamId: 'adanademirspor', teamName: 'Yukatel Adana Demirspor', played: 38, won: 10, drawn: 14, lost: 14, goalsFor: 54, goalsAgainst: 61, goalDifference: -7, points: 44, formHistory: ['L', 'L', 'L', 'W', 'L'] },
      { teamId: 'samsunspor', teamName: 'Yılport Samsunspor', played: 38, won: 11, drawn: 10, lost: 17, goalsFor: 42, goalsAgainst: 52, goalDifference: -10, points: 43, formHistory: ['W', 'D', 'L', 'D', 'L'] },
      { teamId: 'kayserispor', teamName: 'Mondihome Kayserispor', played: 38, won: 11, drawn: 12, lost: 15, goalsFor: 44, goalsAgainst: 57, goalDifference: -13, points: 42, formHistory: ['L', 'D', 'D', 'L', 'W'] },
      { teamId: 'hatayspor', teamName: 'Atakaş Hatayspor', played: 38, won: 9, drawn: 14, lost: 15, goalsFor: 45, goalsAgainst: 52, goalDifference: -7, points: 41, formHistory: ['W', 'D', 'W', 'D', 'L'] },
      { teamId: 'konyaspor', teamName: 'TÜMOSAN Konyaspor', played: 38, won: 9, drawn: 14, lost: 15, goalsFor: 40, goalsAgainst: 53, goalDifference: -13, points: 41, formHistory: ['L', 'D', 'D', 'W', 'D'] },
      { teamId: 'eyupspor', teamName: 'ikas Eyüpspor', played: 38, won: 24, drawn: 3, lost: 7, goalsFor: 77, goalsAgainst: 31, goalDifference: 46, points: 75, formHistory: ['W', 'W', 'W', 'W', 'W'] }, // 1. Lig Şampiyonu
      { teamId: 'goztepe', teamName: 'Göztepe', played: 38, won: 21, drawn: 7, lost: 6, goalsFor: 60, goalsAgainst: 20, goalDifference: 40, points: 70, formHistory: ['W', 'D', 'W', 'W', 'D'] }, // 1. Lig 2.si
      { teamId: 'bodrumfk', teamName: 'Sipay Bodrum FK', played: 38, won: 15, drawn: 12, lost: 7, goalsFor: 43, goalsAgainst: 22, goalDifference: 21, points: 57, formHistory: ['W', 'W', 'D', 'W', 'W'] } // 1. Lig Play-off Şampiyonu
    ]
  },
  '2023-24': {
    season: '2023/24',
    seasonLabel: '2023/24 Sezonu',
    champion: 'Galatasaray',
    standings: [
      { teamId: 'galatasaray', teamName: 'Galatasaray', played: 38, won: 33, drawn: 3, lost: 2, goalsFor: 92, goalsAgainst: 26, goalDifference: 66, points: 102, formHistory: ['W', 'W', 'W', 'W', 'W'] },
      { teamId: 'fenerbahce', teamName: 'Fenerbahçe', played: 38, won: 31, drawn: 6, lost: 1, goalsFor: 99, goalsAgainst: 31, goalDifference: 68, points: 99, formHistory: ['W', 'W', 'W', 'D', 'W'] },
      { teamId: 'trabzonspor', teamName: 'Trabzonspor', played: 38, won: 21, drawn: 4, lost: 13, goalsFor: 69, goalsAgainst: 50, goalDifference: 19, points: 67, formHistory: ['W', 'W', 'L', 'W', 'W'] },
      { teamId: 'basaksehir', teamName: 'Başakşehir', played: 38, won: 18, drawn: 7, lost: 13, goalsFor: 57, goalsAgainst: 43, goalDifference: 14, points: 61, formHistory: ['W', 'D', 'W', 'W', 'L'] },
      { teamId: 'kasimpasa', teamName: 'Kasımpaşa', played: 38, won: 16, drawn: 8, lost: 14, goalsFor: 62, goalsAgainst: 65, goalDifference: -3, points: 56, formHistory: ['W', 'L', 'W', 'W', 'D'] },
      { teamId: 'besiktas', teamName: 'Beşiktaş', played: 38, won: 16, drawn: 8, lost: 14, goalsFor: 52, goalsAgainst: 47, goalDifference: 5, points: 56, formHistory: ['D', 'W', 'L', 'W', 'D'] },
      { teamId: 'sivasspor', teamName: 'Sivasspor', played: 38, won: 14, drawn: 12, lost: 12, goalsFor: 47, goalsAgainst: 54, goalDifference: -7, points: 54, formHistory: ['W', 'D', 'W', 'D', 'L'] },
      { teamId: 'alanyaspor', teamName: 'Alanyaspor', played: 38, won: 12, drawn: 16, lost: 10, goalsFor: 53, goalsAgainst: 50, goalDifference: 3, points: 52, formHistory: ['D', 'D', 'D', 'W', 'D'] },
      { teamId: 'caykurrizespor', teamName: 'Çaykur Rizespor', played: 38, won: 14, drawn: 8, lost: 16, goalsFor: 48, goalsAgainst: 58, goalDifference: -10, points: 50, formHistory: ['L', 'D', 'L', 'W', 'L'] },
      { teamId: 'antalyaspor', teamName: 'Antalyaspor', played: 38, won: 12, drawn: 13, lost: 13, goalsFor: 44, goalsAgainst: 49, goalDifference: -5, points: 49, formHistory: ['D', 'L', 'W', 'L', 'D'] },
      { teamId: 'gaziantepfk', teamName: 'Gaziantep FK', played: 38, won: 12, drawn: 8, lost: 18, goalsFor: 50, goalsAgainst: 57, goalDifference: -7, points: 44, formHistory: ['W', 'W', 'W', 'L', 'D'] },
      { teamId: 'adanademirspor', teamName: 'Adana Demirspor', played: 38, won: 10, drawn: 14, lost: 14, goalsFor: 54, goalsAgainst: 61, goalDifference: -7, points: 44, formHistory: ['L', 'L', 'L', 'W', 'L'] },
      { teamId: 'samsunspor', teamName: 'Samsunspor', played: 38, won: 11, drawn: 10, lost: 17, goalsFor: 42, goalsAgainst: 52, goalDifference: -10, points: 43, formHistory: ['W', 'D', 'L', 'D', 'L'] },
      { teamId: 'kayserispor', teamName: 'Kayserispor', played: 38, won: 11, drawn: 12, lost: 15, goalsFor: 44, goalsAgainst: 57, goalDifference: -13, points: 42, formHistory: ['L', 'D', 'D', 'L', 'W'] },
      { teamId: 'hatayspor', teamName: 'Hatayspor', played: 38, won: 9, drawn: 14, lost: 15, goalsFor: 45, goalsAgainst: 52, goalDifference: -7, points: 41, formHistory: ['W', 'D', 'W', 'D', 'L'] },
      { teamId: 'konyaspor', teamName: 'Konyaspor', played: 38, won: 9, drawn: 14, lost: 15, goalsFor: 40, goalsAgainst: 53, goalDifference: -13, points: 41, formHistory: ['L', 'D', 'D', 'W', 'D'] },
      { teamId: 'eyupspor', teamName: 'Eyüpspor', played: 34, won: 24, drawn: 3, lost: 7, goalsFor: 77, goalsAgainst: 31, goalDifference: 46, points: 75, formHistory: ['W', 'W', 'W', 'W', 'W'] },
      { teamId: 'goztepe', teamName: 'Göztepe', played: 34, won: 21, drawn: 7, lost: 6, goalsFor: 60, goalsAgainst: 20, goalDifference: 40, points: 70, formHistory: ['W', 'D', 'W', 'W', 'D'] },
      { teamId: 'bodrumfk', teamName: 'Bodrum FK', played: 34, won: 15, drawn: 12, lost: 7, goalsFor: 43, goalsAgainst: 22, goalDifference: 21, points: 57, formHistory: ['W', 'W', 'D', 'W', 'W'] }
    ]
  },
  '2022-23': {
    season: '2022/23',
    seasonLabel: '2022/23 Sezonu',
    champion: 'Galatasaray',
    standings: [
      { teamId: 'galatasaray', teamName: 'Galatasaray', played: 36, won: 28, drawn: 4, lost: 4, goalsFor: 83, goalsAgainst: 27, goalDifference: 56, points: 88, formHistory: ['W', 'W', 'W', 'W', 'W'] },
      { teamId: 'fenerbahce', teamName: 'Fenerbahçe', played: 36, won: 25, drawn: 5, lost: 6, goalsFor: 87, goalsAgainst: 42, goalDifference: 45, points: 80, formHistory: ['W', 'L', 'W', 'W', 'W'] },
      { teamId: 'besiktas', teamName: 'Beşiktaş', played: 36, won: 23, drawn: 9, lost: 4, goalsFor: 78, goalsAgainst: 36, goalDifference: 42, points: 78, formHistory: ['D', 'W', 'W', 'W', 'W'] },
      { teamId: 'adanademirspor', teamName: 'Adana Demirspor', played: 36, won: 21, drawn: 6, lost: 9, goalsFor: 76, goalsAgainst: 45, goalDifference: 31, points: 69, formHistory: ['L', 'W', 'L', 'W', 'W'] },
      { teamId: 'basaksehir', teamName: 'Başakşehir', played: 36, won: 18, drawn: 8, lost: 10, goalsFor: 54, goalsAgainst: 37, goalDifference: 17, points: 62, formHistory: ['W', 'W', 'D', 'W', 'L'] },
      { teamId: 'trabzonspor', teamName: 'Trabzonspor', played: 36, won: 17, drawn: 6, lost: 13, goalsFor: 64, goalsAgainst: 54, goalDifference: 10, points: 57, formHistory: ['W', 'L', 'W', 'W', 'L'] },
      { teamId: 'konyaspor', teamName: 'Konyaspor', played: 36, won: 12, drawn: 15, lost: 9, goalsFor: 49, goalsAgainst: 41, goalDifference: 8, points: 51, formHistory: ['D', 'L', 'W', 'D', 'D'] },
      { teamId: 'kayserispor', teamName: 'Kayserispor', played: 36, won: 15, drawn: 5, lost: 16, goalsFor: 55, goalsAgainst: 61, goalDifference: -6, points: 47, formHistory: ['L', 'L', 'L', 'W', 'L'] },
      { teamId: 'kasimpasa', teamName: 'Kasımpaşa', played: 36, won: 12, drawn: 7, lost: 17, goalsFor: 45, goalsAgainst: 61, goalDifference: -16, points: 43, formHistory: ['L', 'W', 'L', 'W', 'W'] },
      { teamId: 'alanyaspor', teamName: 'Alanyaspor', played: 36, won: 11, drawn: 8, lost: 17, goalsFor: 54, goalsAgainst: 70, goalDifference: -16, points: 41, formHistory: ['L', 'L', 'W', 'L', 'L'] },
      { teamId: 'antalyaspor', teamName: 'Antalyaspor', played: 36, won: 11, drawn: 8, lost: 17, goalsFor: 46, goalsAgainst: 55, goalDifference: -9, points: 41, formHistory: ['L', 'W', 'D', 'D', 'L'] },
      { teamId: 'sivasspor', teamName: 'Sivasspor', played: 36, won: 11, drawn: 8, lost: 17, goalsFor: 46, goalsAgainst: 54, goalDifference: -8, points: 41, formHistory: ['D', 'W', 'L', 'L', 'L'] },
      { teamId: 'samsunspor', teamName: 'Samsunspor', played: 36, won: 23, drawn: 9, lost: 4, goalsFor: 70, goalsAgainst: 26, goalDifference: 44, points: 78, formHistory: ['W', 'W', 'W', 'W', 'W'] }, // 1. Lig Şampiyonu
      { teamId: 'caykurrizespor', teamName: 'Çaykur Rizespor', played: 36, won: 18, drawn: 14, lost: 4, goalsFor: 64, goalsAgainst: 35, goalDifference: 29, points: 68, formHistory: ['D', 'W', 'W', 'D', 'W'] }, // 1. Lig 2.si
      { teamId: 'gaziantepfk', teamName: 'Gaziantep FK', played: 36, won: 6, drawn: 7, lost: 23, goalsFor: 31, goalsAgainst: 72, goalDifference: -41, points: 25, formHistory: ['L', 'L', 'L', 'L', 'L'] },
      { teamId: 'hatayspor', teamName: 'Hatayspor', played: 36, won: 6, drawn: 5, lost: 25, goalsFor: 19, goalsAgainst: 83, goalDifference: -64, points: 23, formHistory: ['L', 'L', 'L', 'L', 'L'] },
      { teamId: 'eyupspor', teamName: 'Eyüpspor', played: 36, won: 18, drawn: 8, lost: 10, goalsFor: 40, goalsAgainst: 30, goalDifference: 10, points: 62, formHistory: ['L', 'W', 'L', 'W', 'D'] },
      { teamId: 'goztepe', teamName: 'Göztepe', played: 36, won: 17, drawn: 9, lost: 10, goalsFor: 45, goalsAgainst: 31, goalDifference: 14, points: 60, formHistory: ['D', 'D', 'W', 'D', 'W'] },
      { teamId: 'bodrumfk', teamName: 'Bodrum FK', played: 36, won: 18, drawn: 7, lost: 11, goalsFor: 55, goalsAgainst: 40, goalDifference: 15, points: 61, formHistory: ['L', 'W', 'W', 'W', 'W'] }
    ]
  },
  '2021-22': {
    season: '2021/22',
    seasonLabel: '2021/22 Sezonu',
    champion: 'Trabzonspor',
    standings: [
      { teamId: 'trabzonspor', teamName: 'Trabzonspor', played: 38, won: 23, drawn: 12, lost: 3, goalsFor: 69, goalsAgainst: 36, goalDifference: 33, points: 81, formHistory: ['D', 'D', 'W', 'D', 'L'] },
      { teamId: 'fenerbahce', teamName: 'Fenerbahçe', played: 38, won: 21, drawn: 10, lost: 7, goalsFor: 73, goalsAgainst: 38, goalDifference: 35, points: 73, formHistory: ['W', 'D', 'W', 'W', 'W'] },
      { teamId: 'konyaspor', teamName: 'Konyaspor', played: 38, won: 20, drawn: 8, lost: 10, goalsFor: 66, goalsAgainst: 45, goalDifference: 21, points: 68, formHistory: ['D', 'W', 'L', 'L', 'W'] },
      { teamId: 'basaksehir', teamName: 'Başakşehir', played: 38, won: 19, drawn: 8, lost: 11, goalsFor: 56, goalsAgainst: 36, goalDifference: 20, points: 65, formHistory: ['W', 'D', 'D', 'W', 'W'] },
      { teamId: 'alanyaspor', teamName: 'Alanyaspor', played: 38, won: 19, drawn: 7, lost: 12, goalsFor: 67, goalsAgainst: 58, goalDifference: 9, points: 64, formHistory: ['W', 'W', 'W', 'W', 'L'] },
      { teamId: 'besiktas', teamName: 'Beşiktaş', played: 38, won: 15, drawn: 14, lost: 9, goalsFor: 56, goalsAgainst: 48, goalDifference: 8, points: 59, formHistory: ['D', 'W', 'D', 'D', 'L'] },
      { teamId: 'antalyaspor', teamName: 'Antalyaspor', played: 38, won: 16, drawn: 11, lost: 11, goalsFor: 54, goalsAgainst: 47, goalDifference: 7, points: 59, formHistory: ['D', 'W', 'W', 'W', 'D'] },
      { teamId: 'adanademirspor', teamName: 'Adana Demirspor', played: 38, won: 15, drawn: 10, lost: 13, goalsFor: 60, goalsAgainst: 47, goalDifference: 13, points: 55, formHistory: ['W', 'L', 'L', 'L', 'L'] },
      { teamId: 'sivasspor', teamName: 'Sivasspor', played: 38, won: 14, drawn: 12, lost: 12, goalsFor: 52, goalsAgainst: 50, goalDifference: 2, points: 54, formHistory: ['W', 'W', 'D', 'W', 'W'] },
      { teamId: 'kasimpasa', teamName: 'Kasımpaşa', played: 38, won: 15, drawn: 8, lost: 15, goalsFor: 67, goalsAgainst: 57, goalDifference: 10, points: 53, formHistory: ['L', 'W', 'W', 'W', 'L'] },
      { teamId: 'hatayspor', teamName: 'Hatayspor', played: 38, won: 15, drawn: 8, lost: 15, goalsFor: 49, goalsAgainst: 60, goalDifference: -11, points: 53, formHistory: ['W', 'L', 'L', 'L', 'D'] },
      { teamId: 'galatasaray', teamName: 'Galatasaray', played: 38, won: 14, drawn: 10, lost: 14, goalsFor: 51, goalsAgainst: 53, goalDifference: -2, points: 52, formHistory: ['W', 'W', 'L', 'W', 'D'] },
      { teamId: 'kayserispor', teamName: 'Kayserispor', played: 38, won: 12, drawn: 11, lost: 15, goalsFor: 54, goalsAgainst: 61, goalDifference: -7, points: 47, formHistory: ['L', 'W', 'D', 'D', 'L'] },
      { teamId: 'gaziantepfk', teamName: 'Gaziantep FK', played: 38, won: 12, drawn: 10, lost: 16, goalsFor: 48, goalsAgainst: 56, goalDifference: -8, points: 46, formHistory: ['L', 'D', 'D', 'L', 'W'] },
      { teamId: 'caykurrizespor', teamName: 'Çaykur Rizespor', played: 38, won: 10, drawn: 6, lost: 22, goalsFor: 44, goalsAgainst: 71, goalDifference: -27, points: 36, formHistory: ['L', 'W', 'L', 'W', 'L'] },
      { teamId: 'goztepe', teamName: 'Göztepe', played: 38, won: 7, drawn: 7, lost: 24, goalsFor: 40, goalsAgainst: 77, goalDifference: -37, points: 28, formHistory: ['D', 'L', 'L', 'D', 'L'] },
      { teamId: 'samsunspor', teamName: 'Samsunspor', played: 36, won: 13, drawn: 12, lost: 11, goalsFor: 54, goalsAgainst: 46, goalDifference: 8, points: 51, formHistory: ['D', 'D', 'L', 'W', 'W'] },
      { teamId: 'eyupspor', teamName: 'Eyüpspor', played: 36, won: 15, drawn: 12, lost: 9, goalsFor: 56, goalsAgainst: 44, goalDifference: 12, points: 57, formHistory: ['W', 'W', 'D', 'W', 'D'] },
      { teamId: 'bodrumfk', teamName: 'Bodrum FK', played: 38, won: 21, drawn: 9, lost: 8, goalsFor: 61, goalsAgainst: 27, goalDifference: 34, points: 72, formHistory: ['W', 'W', 'W', 'W', 'W'] }
    ]
  }
};

export const HISTORICAL_CLUB_FINISHES: Record<string, { season: string; rank: number; points: number; title?: string; status?: string }[]> = {
  galatasaray: [
    { season: '2024/25', rank: 1, points: 102, title: 'Şampiyon 🏆', status: 'UEFA Şampiyonlar Ligi' },
    { season: '2023/24', rank: 1, points: 102, title: 'Şampiyon 🏆', status: 'UEFA Şampiyonlar Ligi' },
    { season: '2022/23', rank: 1, points: 88, title: 'Şampiyon 🏆', status: 'UEFA Şampiyonlar Ligi' },
    { season: '2021/22', rank: 13, points: 52, status: 'Orta Sıralar' },
    { season: '2020/21', rank: 2, points: 84, title: 'İkinci (Averajla)', status: 'UEFA Şampiyonlar Ligi Eleme' }
  ],
  fenerbahce: [
    { season: '2024/25', rank: 2, points: 99, title: 'İkinci 🥈', status: 'UEFA Şampiyonlar Ligi 2. Eleme' },
    { season: '2023/24', rank: 2, points: 99, title: 'İkinci 🥈', status: 'UEFA Şampiyonlar Ligi 2. Eleme' },
    { season: '2022/23', rank: 2, points: 80, title: 'İkinci 🥈 (TR Kupası Şampiyonu)', status: 'UEFA Konferans Ligi' },
    { season: '2021/22', rank: 2, points: 73, title: 'İkinci 🥈', status: 'UEFA Şampiyonlar Ligi Eleme' },
    { season: '2020/21', rank: 3, points: 82, status: 'UEFA Avrupa Ligi' }
  ],
  besiktas: [
    { season: '2024/25', rank: 6, points: 56, title: 'TR Kupası Şampiyonu 🏆', status: 'UEFA Avrupa Ligi Play-off' },
    { season: '2023/24', rank: 6, points: 56, title: 'TR Kupası Şampiyonu 🏆', status: 'UEFA Avrupa Ligi Play-off' },
    { season: '2022/23', rank: 3, points: 78, status: 'UEFA Konferans Ligi' },
    { season: '2021/22', rank: 6, points: 59, status: 'Süper Kupa Şampiyonu' },
    { season: '2020/21', rank: 1, points: 84, title: 'Şampiyon 🏆 (Çifte Kupa)', status: 'UEFA Şampiyonlar Ligi' }
  ],
  trabzonspor: [
    { season: '2024/25', rank: 3, points: 67, status: 'UEFA Avrupa Ligi 2. Eleme' },
    { season: '2023/24', rank: 3, points: 67, status: 'UEFA Avrupa Ligi 2. Eleme' },
    { season: '2022/23', rank: 6, points: 57, status: 'Süper Kupa Şampiyonu' },
    { season: '2021/22', rank: 1, points: 81, title: 'Şampiyon 🏆', status: 'UEFA Şampiyonlar Ligi Play-off' },
    { season: '2020/21', rank: 4, points: 71, status: 'UEFA Konferans Ligi' }
  ],
  basaksehir: [
    { season: '2024/25', rank: 4, points: 61, status: 'UEFA Konferans Ligi 2. Eleme' },
    { season: '2023/24', rank: 4, points: 61, status: 'UEFA Konferans Ligi 2. Eleme' },
    { season: '2022/23', rank: 5, points: 62, status: 'TR Kupası Finalisti' },
    { season: '2021/22', rank: 4, points: 65, status: 'UEFA Konferans Ligi' },
    { season: '2020/21', rank: 12, points: 48, status: 'Ligde Kaldı' }
  ],
  kasimpasa: [
    { season: '2024/25', rank: 5, points: 56, status: 'Üst Sıralar' },
    { season: '2023/24', rank: 5, points: 56, status: 'Üst Sıralar' },
    { season: '2022/23', rank: 10, points: 43, status: 'Orta Sıralar' },
    { season: '2021/22', rank: 11, points: 53, status: 'Orta Sıralar' }
  ],
  sivasspor: [
    { season: '2024/25', rank: 7, points: 54, status: 'Orta Sıralar' },
    { season: '2023/24', rank: 7, points: 54, status: 'Orta Sıralar' },
    { season: '2022/23', rank: 14, points: 41, status: 'UEFA Konferans Ligi Son 16' },
    { season: '2021/22', rank: 10, points: 54, title: 'TR Kupası Şampiyonu 🏆', status: 'UEFA Avrupa Ligi Play-off' }
  ],
  alanyaspor: [
    { season: '2024/25', rank: 8, points: 52, status: 'Orta Sıralar' },
    { season: '2023/24', rank: 8, points: 52, status: 'Orta Sıralar' },
    { season: '2022/23', rank: 11, points: 41, status: 'Orta Sıralar' },
    { season: '2021/22', rank: 5, points: 64, status: 'Üst Sıralar' }
  ],
  caykurrizespor: [
    { season: '2024/25', rank: 9, points: 50, status: 'Orta Sıralar' },
    { season: '2023/24', rank: 9, points: 50, status: 'Orta Sıralar' },
    { season: '2022/23', rank: 2, points: 68, title: '1. Lig 2.si 🥈', status: 'Süper Lig\'e Yükseldi' },
    { season: '2021/22', rank: 17, points: 36, status: '1. Lig\'e Düştü' }
  ],
  antalyaspor: [
    { season: '2024/25', rank: 10, points: 49, status: 'Orta Sıralar' },
    { season: '2023/24', rank: 10, points: 49, status: 'Orta Sıralar' },
    { season: '2022/23', rank: 13, points: 41, status: 'Orta Sıralar' },
    { season: '2021/22', rank: 7, points: 59, status: 'Üst Sıralar' }
  ],
  gaziantepfk: [
    { season: '2024/25', rank: 11, points: 44, status: 'Ligde Kaldı' },
    { season: '2023/24', rank: 11, points: 44, status: 'Ligde Kaldı' },
    { season: '2022/23', rank: 18, points: 25, status: 'Deprem Nedeniyle Çekildi' },
    { season: '2021/22', rank: 15, points: 46, status: 'Ligde Kaldı' }
  ],
  adanademirspor: [
    { season: '2024/25', rank: 12, points: 44, status: 'Orta Sıralar' },
    { season: '2023/24', rank: 12, points: 44, status: 'Orta Sıralar' },
    { season: '2022/23', rank: 4, points: 69, status: 'UEFA Konferans Ligi Play-off' },
    { season: '2021/22', rank: 9, points: 55, status: 'Orta Sıralar' }
  ],
  samsunspor: [
    { season: '2024/25', rank: 13, points: 43, status: 'Ligde Kaldı' },
    { season: '2023/24', rank: 13, points: 43, status: 'Ligde Kaldı' },
    { season: '2022/23', rank: 1, points: 78, title: '1. Lig Şampiyonu 🏆', status: 'Süper Lig\'e Yükseldi' },
    { season: '2021/22', rank: 7, points: 51, status: '1. Lig' }
  ],
  kayserispor: [
    { season: '2024/25', rank: 14, points: 42, status: 'Ligde Kaldı' },
    { season: '2023/24', rank: 14, points: 42, status: 'Ligde Kaldı' },
    { season: '2022/23', rank: 9, points: 47, status: 'Orta Sıralar' },
    { season: '2021/22', rank: 14, points: 47, status: 'TR Kupası Finalisti' }
  ],
  hatayspor: [
    { season: '2024/25', rank: 15, points: 41, status: 'Son Hafta Ligde Kaldı' },
    { season: '2023/24', rank: 15, points: 41, status: 'Son Hafta Ligde Kaldı' },
    { season: '2022/23', rank: 19, points: 23, status: 'Deprem Nedeniyle Çekildi' },
    { season: '2021/22', rank: 12, points: 53, status: 'Orta Sıralar' }
  ],
  konyaspor: [
    { season: '2024/25', rank: 16, points: 41, status: 'Ligde Kaldı' },
    { season: '2023/24', rank: 16, points: 41, status: 'Ligde Kaldı' },
    { season: '2022/23', rank: 8, points: 51, status: 'Orta Sıralar' },
    { season: '2021/22', rank: 3, points: 68, status: 'UEFA Konferans Ligi 2. Eleme' }
  ],
  eyupspor: [
    { season: '2024/25', rank: 1, points: 75, title: '1. Lig Şampiyonu 🏆', status: 'Süper Lig\'e Yükseldi' },
    { season: '2023/24', rank: 1, points: 75, title: '1. Lig Şampiyonu 🏆', status: 'Süper Lig\'e Yükseldi' },
    { season: '2022/23', rank: 6, points: 62, status: '1. Lig Play-off Yarı Final' },
    { season: '2021/22', rank: 6, points: 57, status: '1. Lig Play-off Yarı Final' }
  ],
  goztepe: [
    { season: '2024/25', rank: 2, points: 70, title: '1. Lig 2.si 🥈', status: 'Süper Lig\'e Yükseldi' },
    { season: '2023/24', rank: 2, points: 70, title: '1. Lig 2.si 🥈', status: 'Süper Lig\'e Yükseldi' },
    { season: '2022/23', rank: 7, points: 60, status: '1. Lig Play-off Çeyrek Final' },
    { season: '2021/22', rank: 19, points: 28, status: '1. Lig\'e Düştü' }
  ],
  bodrumfk: [
    { season: '2024/25', rank: 4, points: 57, title: 'Play-off Şampiyonu 🏆', status: 'Tarihinde İlk Kez Süper Lig\'e Yükseldi' },
    { season: '2023/24', rank: 4, points: 57, title: 'Play-off Şampiyonu 🏆', status: 'Tarihinde İlk Kez Süper Lig\'e Yükseldi' },
    { season: '2022/23', rank: 4, points: 61, status: '1. Lig Play-off Finalisti' },
    { season: '2021/22', rank: 3, points: 72, title: '2. Lig Play-off Şampiyonu', status: '1. Lig\'e Yükseldi' }
  ]
};

export function getClubHistoricalFinishes(teamIdOrName: string): { season: string; rank: number; points: number; title?: string; status?: string }[] {
  const cleanId = (teamIdOrName || '')
    .toLowerCase()
    .replace(/ç/g, 'c')
    .replace(/ğ/g, 'g')
    .replace(/ı/g, 'i')
    .replace(/ö/g, 'o')
    .replace(/ş/g, 's')
    .replace(/ü/g, 'u')
    .replace(/[^a-z0-9]/g, '');

  for (const [key, records] of Object.entries(HISTORICAL_CLUB_FINISHES)) {
    if (cleanId === key || cleanId.includes(key) || key.includes(cleanId)) {
      return records;
    }
  }

  // Fallback for foreign clubs or newly created clubs
  return [
    { season: '2024/25', rank: 4, points: 68, status: 'Üst Sıralar' },
    { season: '2023/24', rank: 5, points: 64, status: 'Lig 5.si' },
    { season: '2022/23', rank: 3, points: 72, status: 'Avrupa Kupaları' }
  ];
}

export function getClubLastSeasonRank(teamIdOrName: string): { season: string; rank: number; points: number; title?: string; status?: string } | null {
  const finishes = getClubHistoricalFinishes(teamIdOrName);
  if (finishes.length > 0) {
    return finishes[0];
  }
  return null;
}

