import { Player, Team } from '../types';

export interface TransfermarktCareerRow {
  season: string;
  club: string;
  league: string;
  transferType: string;
  caps: number;
  goals: number;
  assists: number;
  yellowCards?: number;
  redCards?: number;
  rating: number;
}

export const getNormalizedPlayerKey = (name: string): string => {
  if (!name) return '';
  return name
    .toLowerCase()
    .trim()
    .replace(/ı/g, 'i')
    .replace(/ğ/g, 'g')
    .replace(/ş/g, 's')
    .replace(/ç/g, 'c')
    .replace(/ö/g, 'o')
    .replace(/ü/g, 'u')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '');
};

export const REAL_PLAYER_CAREER_MAP: Record<string, TransfermarktCareerRow[]> = {
  // --- GALATASARAY ---
  'victorosimhen': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.2 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Kiralık (Napoli)', caps: 32, goals: 26, assists: 5, rating: 8.1 },
    { season: '2023/24', club: 'Napoli', league: 'Serie A', transferType: 'Sözleşme', caps: 32, goals: 17, assists: 4, rating: 7.7 },
    { season: '2022/23', club: 'Napoli', league: 'Serie A', transferType: 'Sözleşme', caps: 39, goals: 31, assists: 5, rating: 8.3 },
    { season: '2021/22', club: 'Napoli', league: 'Serie A', transferType: 'Sözleşme', caps: 32, goals: 18, assists: 6, rating: 7.6 },
    { season: '2020/21', club: 'Napoli', league: 'Serie A', transferType: '€77.5M', caps: 30, goals: 10, assists: 3, rating: 7.2 },
    { season: '2019/20', club: 'Lille', league: 'Ligue 1', transferType: '€22.4M', caps: 38, goals: 18, assists: 6, rating: 7.5 },
    { season: '2018/19', club: 'Charleroi', league: 'Pro League', transferType: '€3.5M', caps: 36, goals: 20, assists: 4, rating: 7.4 }
  ],
  'mauroicardi': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.0 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 14, goals: 6, assists: 2, rating: 7.6 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: '€10.0M', caps: 47, goals: 32, assists: 12, rating: 8.2 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Kiralık (PSG)', caps: 26, goals: 23, assists: 8, rating: 8.4 },
    { season: '2021/22', club: 'Paris SG', league: 'Ligue 1', transferType: 'Sözleşme', caps: 30, goals: 5, assists: 0, rating: 6.9 },
    { season: '2020/21', club: 'Paris SG', league: 'Ligue 1', transferType: '€50.0M', caps: 28, goals: 13, assists: 6, rating: 7.3 },
    { season: '2019/20', club: 'Paris SG', league: 'Ligue 1', transferType: 'Kiralık (Inter)', caps: 34, goals: 20, assists: 4, rating: 7.5 },
    { season: '2018/19', club: 'Inter', league: 'Serie A', transferType: 'Sözleşme', caps: 37, goals: 17, assists: 5, rating: 7.4 }
  ],
  'ugurcancakir': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Sözleşme Uzatma', caps: 38, goals: 0, assists: 0, rating: 7.7 },
    { season: '2023/24', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Sözleşme Uzatma', caps: 40, goals: 0, assists: 0, rating: 7.6 },
    { season: '2022/23', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Sözleşme Uzatma', caps: 44, goals: 0, assists: 0, rating: 7.8 },
    { season: '2021/22', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Sözleşme', caps: 39, goals: 0, assists: 0, rating: 8.1 },
    { season: '2020/21', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Altyapı / Pro', caps: 38, goals: 0, assists: 0, rating: 7.7 }
  ],
  'wilfriedsingo': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Monaco', league: 'Ligue 1', transferType: 'Sözleşme', caps: 31, goals: 1, assists: 2, rating: 7.5 },
    { season: '2023/24', club: 'Monaco', league: 'Ligue 1', transferType: '€10.0M', caps: 25, goals: 1, assists: 1, rating: 7.4 },
    { season: '2022/23', club: 'Torino', league: 'Serie A', transferType: 'Sözleşme', caps: 35, goals: 2, assists: 3, rating: 7.3 }
  ],
  'davinsonsanchez': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.9 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 32, goals: 3, assists: 2, rating: 7.8 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: '€9.5M', caps: 32, goals: 3, assists: 2, rating: 7.9 },
    { season: '2022/23', club: 'Tottenham', league: 'Premier League', transferType: 'Sözleşme', caps: 24, goals: 0, assists: 0, rating: 7.0 },
    { season: '2021/22', club: 'Tottenham', league: 'Premier League', transferType: 'Sözleşme', caps: 32, goals: 2, assists: 1, rating: 7.2 }
  ],
  'abdulkerimbardakci': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 36, goals: 4, assists: 1, rating: 7.6 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 44, goals: 6, assists: 1, rating: 7.8 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: '€2.8M', caps: 33, goals: 3, assists: 3, rating: 7.7 },
    { season: '2021/22', club: 'Konyaspor', league: 'Süper Lig', transferType: 'Sözleşme', caps: 34, goals: 5, assists: 4, rating: 7.8 }
  ],
  'erenelmali': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Sözleşme', caps: 35, goals: 1, assists: 2, rating: 7.4 },
    { season: '2023/24', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Sözleşme', caps: 38, goals: 1, assists: 1, rating: 7.3 },
    { season: '2022/23', club: 'Trabzonspor', league: 'Süper Lig', transferType: '€3.6M', caps: 47, goals: 0, assists: 3, rating: 7.4 },
    { season: '2021/22', club: 'Kasımpaşa', league: 'Süper Lig', transferType: 'A Takım', caps: 37, goals: 1, assists: 4, rating: 7.5 }
  ],
  'lucastorreira': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 36, goals: 1, assists: 3, rating: 7.7 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 47, goals: 1, assists: 3, rating: 7.8 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: '€6.0M', caps: 34, goals: 0, assists: 1, rating: 7.7 },
    { season: '2021/22', club: 'Fiorentina', league: 'Serie A', transferType: 'Kiralık (Arsenal)', caps: 35, goals: 5, assists: 2, rating: 7.4 }
  ],
  'ilkaygundogan': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.0 },
    { season: '2024/25', club: 'Manchester City', league: 'Premier League', transferType: 'Bonservissiz', caps: 36, goals: 3, assists: 4, rating: 7.6 },
    { season: '2023/24', club: 'FC Barcelona', league: 'La Liga', transferType: 'Bonservissiz', caps: 51, goals: 5, assists: 14, rating: 8.1 },
    { season: '2022/23', club: 'Manchester City', league: 'Premier League', transferType: 'Sözleşme Uzatma', caps: 51, goals: 11, assists: 7, rating: 8.2 },
    { season: '2021/22', club: 'Manchester City', league: 'Premier League', transferType: 'Sözleşme', caps: 43, goals: 10, assists: 6, rating: 7.8 }
  ],
  'gabrielsara': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: '€18.0M', caps: 35, goals: 5, assists: 8, rating: 7.7 },
    { season: '2023/24', club: 'Norwich City', league: 'Championship', transferType: 'Sözleşme', caps: 53, goals: 14, assists: 12, rating: 8.0 },
    { season: '2022/23', club: 'Norwich City', league: 'Championship', transferType: '€10.5M', caps: 43, goals: 7, assists: 4, rating: 7.5 }
  ],
  'leroysane': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.1 },
    { season: '2024/25', club: 'Bayern München', league: 'Bundesliga', transferType: 'Sözleşme', caps: 38, goals: 10, assists: 11, rating: 7.8 },
    { season: '2023/24', club: 'Bayern München', league: 'Bundesliga', transferType: 'Sözleşme', caps: 42, goals: 10, assists: 13, rating: 8.0 },
    { season: '2022/23', club: 'Bayern München', league: 'Bundesliga', transferType: 'Sözleşme', caps: 44, goals: 14, assists: 10, rating: 7.9 },
    { season: '2021/22', club: 'Bayern München', league: 'Bundesliga', transferType: 'Sözleşme', caps: 45, goals: 14, assists: 15, rating: 7.9 }
  ],
  'barisalperyilmaz': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 37, goals: 9, assists: 7, rating: 7.7 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 55, goals: 7, assists: 12, rating: 7.8 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 30, goals: 4, assists: 2, rating: 7.2 },
    { season: '2021/22', club: 'Galatasaray', league: 'Süper Lig', transferType: '€2.1M', caps: 23, goals: 0, assists: 1, rating: 6.8 },
    { season: '2020/21', club: 'Keçiörengücü', league: '1. Lig', transferType: 'Transfer', caps: 36, goals: 8, assists: 5, rating: 7.4 }
  ],
  'fernandomuslera': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme Yenilendi', caps: 37, goals: 0, assists: 0, rating: 7.6 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 52, goals: 0, assists: 0, rating: 7.8 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 35, goals: 0, assists: 0, rating: 7.8 },
    { season: '2021/22', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 36, goals: 0, assists: 0, rating: 7.2 },
    { season: '2020/21', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 22, goals: 0, assists: 0, rating: 7.4 }
  ],
  'gunayguvenc': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.2 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 12, goals: 0, assists: 0, rating: 7.1 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: '€250K', caps: 10, goals: 0, assists: 0, rating: 7.3 },
    { season: '2022/23', club: 'Kasımpaşa', league: 'Süper Lig', transferType: 'Kiralık (Gaziantep)', caps: 16, goals: 0, assists: 0, rating: 7.2 },
    { season: '2021/22', club: 'Gaziantep FK', league: 'Süper Lig', transferType: 'Kaptan', caps: 35, goals: 0, assists: 0, rating: 7.4 }
  ],
  'victornelsson': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 28, goals: 1, assists: 0, rating: 7.5 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 46, goals: 2, assists: 0, rating: 7.7 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 35, goals: 1, assists: 1, rating: 7.8 },
    { season: '2021/22', club: 'Galatasaray', league: 'Süper Lig', transferType: '€7.0M', caps: 45, goals: 1, assists: 1, rating: 7.5 }
  ],
  'kaanayhan': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 34, goals: 1, assists: 3, rating: 7.4 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: '€2.8M', caps: 46, goals: 1, assists: 3, rating: 7.6 },
    { season: '2022/23', club: 'Sassuolo', league: 'Serie A', transferType: 'Sözleşme', caps: 11, goals: 1, assists: 0, rating: 7.0 }
  ],
  'eliasjelert': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.4 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: '€9.0M', caps: 24, goals: 0, assists: 1, rating: 7.3 },
    { season: '2023/24', club: 'FC København', league: 'Superligaen', transferType: 'A Takım', caps: 45, goals: 1, assists: 3, rating: 7.6 }
  ],
  'ismailjakobs': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Kiralık (Monaco)', caps: 22, goals: 1, assists: 2, rating: 7.4 },
    { season: '2023/24', club: 'Monaco', league: 'Ligue 1', transferType: 'Sözleşme', caps: 23, goals: 1, assists: 2, rating: 7.3 }
  ],
  'mariolemina': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Wolverhampton', league: 'Premier League', transferType: 'Sözleşme Uzatma', caps: 35, goals: 4, assists: 1, rating: 7.6 },
    { season: '2023/24', club: 'Wolverhampton', league: 'Premier League', transferType: '€11.0M', caps: 39, goals: 5, assists: 1, rating: 7.7 },
    { season: '2022/23', club: 'OGC Nice', league: 'Ligue 1', transferType: 'Sözleşme', caps: 22, goals: 1, assists: 1, rating: 7.4 },
    { season: '2019/20', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Kiralık (Southampton)', caps: 28, goals: 1, assists: 0, rating: 7.5 }
  ],
  'yunusakgun': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 32, goals: 10, assists: 6, rating: 7.7 },
    { season: '2023/24', club: 'Leicester City', league: 'Championship', transferType: 'Kiralık (Galatasaray)', caps: 29, goals: 2, assists: 3, rating: 7.2 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Geri Döndü', caps: 28, goals: 1, assists: 4, rating: 7.3 },
    { season: '2021/22', club: 'Adana Demirspor', league: 'Süper Lig', transferType: 'Kiralık (Galatasaray)', caps: 38, goals: 9, assists: 17, rating: 8.1 }
  ],
  'rolandsallai': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: '€6.0M', caps: 28, goals: 4, assists: 3, rating: 7.4 },
    { season: '2023/24', club: 'SC Freiburg', league: 'Bundesliga', transferType: 'Sözleşme', caps: 37, goals: 8, assists: 4, rating: 7.5 }
  ],
  'michybatshuayi': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 32, goals: 8, assists: 3, rating: 7.5 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 43, goals: 24, assists: 3, rating: 7.9 },
    { season: '2022/23', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€3.5M', caps: 32, goals: 20, assists: 2, rating: 7.8 },
    { season: '2021/22', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Kiralık (Chelsea)', caps: 42, goals: 14, assists: 5, rating: 7.3 }
  ],

  // --- FENERBAHÇE ---
  'edindzeko': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 38, goals: 21, assists: 6, rating: 7.7 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 46, goals: 25, assists: 10, rating: 7.9 },
    { season: '2022/23', club: 'Inter', league: 'Serie A', transferType: 'Sözleşme', caps: 52, goals: 14, assists: 5, rating: 7.3 },
    { season: '2021/22', club: 'Inter', league: 'Serie A', transferType: '€2.8M', caps: 49, goals: 17, assists: 10, rating: 7.4 },
    { season: '2020/21', club: 'AS Roma', league: 'Serie A', transferType: 'Sözleşme', caps: 38, goals: 13, assists: 5, rating: 7.1 },
    { season: '2019/20', club: 'AS Roma', league: 'Serie A', transferType: 'Sözleşme', caps: 43, goals: 19, assists: 14, rating: 7.6 }
  ],
  'dusantadic': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.9 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 38, goals: 12, assists: 15, rating: 7.8 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 56, goals: 16, assists: 16, rating: 8.0 },
    { season: '2022/23', club: 'Ajax', league: 'Eredivisie', transferType: 'Sözleşme', caps: 47, goals: 13, assists: 21, rating: 8.1 },
    { season: '2021/22', club: 'Ajax', league: 'Eredivisie', transferType: 'Sözleşme', caps: 45, goals: 16, assists: 22, rating: 8.2 },
    { season: '2020/21', club: 'Ajax', league: 'Eredivisie', transferType: 'Sözleşme', caps: 51, goals: 22, assists: 26, rating: 8.3 }
  ],
  'fred': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 35, goals: 4, assists: 8, rating: 7.6 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€9.7M', caps: 35, goals: 3, assists: 8, rating: 7.8 },
    { season: '2022/23', club: 'Manchester Utd', league: 'Premier League', transferType: 'Sözleşme', caps: 56, goals: 6, assists: 6, rating: 7.2 },
    { season: '2021/22', club: 'Manchester Utd', league: 'Premier League', transferType: 'Sözleşme', caps: 36, goals: 4, assists: 6, rating: 7.1 }
  ],
  'sofyanamrabat': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Kiralık (Fiorentina)', caps: 31, goals: 2, assists: 3, rating: 7.6 },
    { season: '2023/24', club: 'Manchester Utd', league: 'Premier League', transferType: 'Kiralık (Fiorentina)', caps: 30, goals: 0, assists: 0, rating: 7.1 },
    { season: '2022/23', club: 'Fiorentina', league: 'Serie A', transferType: 'Sözleşme', caps: 49, goals: 0, assists: 1, rating: 7.4 }
  ],
  'youssefennesyri': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€19.5M', caps: 36, goals: 16, assists: 3, rating: 7.7 },
    { season: '2023/24', club: 'Sevilla FC', league: 'La Liga', transferType: 'Sözleşme', caps: 41, goals: 20, assists: 3, rating: 7.6 },
    { season: '2022/23', club: 'Sevilla FC', league: 'La Liga', transferType: 'Sözleşme', caps: 48, goals: 18, assists: 2, rating: 7.5 }
  ],
  'dominiklivakovic': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 35, goals: 0, assists: 0, rating: 7.6 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€6.6M', caps: 40, goals: 0, assists: 0, rating: 7.7 },
    { season: '2022/23', club: 'Dinamo Zagreb', league: 'HNL', transferType: 'Kaptan', caps: 49, goals: 0, assists: 0, rating: 7.8 }
  ],
  'ederson': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.1 },
    { season: '2024/25', club: 'Manchester City', league: 'Premier League', transferType: 'Sözleşme', caps: 43, goals: 0, assists: 0, rating: 8.0 },
    { season: '2023/24', club: 'Manchester City', league: 'Premier League', transferType: 'Sözleşme', caps: 43, goals: 0, assists: 0, rating: 8.0 },
    { season: '2022/23', club: 'Manchester City', league: 'Premier League', transferType: 'Sözleşme', caps: 48, goals: 0, assists: 1, rating: 8.1 },
    { season: '2021/22', club: 'Manchester City', league: 'Premier League', transferType: 'Sözleşme', caps: 49, goals: 0, assists: 0, rating: 8.2 }
  ],
  'nelsonsemedo': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Wolverhampton', league: 'Premier League', transferType: 'Sözleşme', caps: 36, goals: 0, assists: 1, rating: 7.4 },
    { season: '2023/24', club: 'Wolverhampton', league: 'Premier League', transferType: 'Sözleşme', caps: 41, goals: 0, assists: 1, rating: 7.3 },
    { season: '2020/21', club: 'Wolverhampton', league: 'Premier League', transferType: '€30.0M', caps: 35, goals: 1, assists: 1, rating: 7.2 },
    { season: '2019/20', club: 'FC Barcelona', league: 'La Liga', transferType: 'Sözleşme', caps: 42, goals: 1, assists: 6, rating: 7.5 }
  ],
  'milanskriniar': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Paris SG', league: 'Ligue 1', transferType: 'Sözleşme', caps: 28, goals: 0, assists: 0, rating: 7.5 },
    { season: '2023/24', club: 'Paris SG', league: 'Ligue 1', transferType: 'Bonservissiz', caps: 32, goals: 1, assists: 0, rating: 7.6 },
    { season: '2022/23', club: 'Inter', league: 'Serie A', transferType: 'Sözleşme', caps: 31, goals: 0, assists: 1, rating: 7.7 },
    { season: '2021/22', club: 'Inter', league: 'Serie A', transferType: 'Sözleşme', caps: 48, goals: 4, assists: 0, rating: 8.0 }
  ],
  'jaydenoosterwolde': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 14, goals: 0, assists: 0, rating: 7.5 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 43, goals: 2, assists: 0, rating: 7.7 },
    { season: '2022/23', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€6.0M', caps: 5, goals: 0, assists: 0, rating: 7.0 },
    { season: '2021/22', club: 'Parma', league: 'Serie B', transferType: '€3.0M', caps: 12, goals: 0, assists: 0, rating: 7.2 }
  ],
  'sebastianszymanski': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 36, goals: 3, assists: 6, rating: 7.5 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€9.75M', caps: 55, goals: 13, assists: 19, rating: 8.1 },
    { season: '2022/23', club: 'Feyenoord', league: 'Eredivisie', transferType: 'Kiralık (Dynamo Moscow)', caps: 40, goals: 10, assists: 7, rating: 7.8 }
  ],
  'andersontalisca': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.9 },
    { season: '2024/25', club: 'Al-Nassr', league: 'Pro League', transferType: 'Sözleşme', caps: 25, goals: 16, assists: 4, rating: 7.8 },
    { season: '2023/24', club: 'Al-Nassr', league: 'Pro League', transferType: 'Sözleşme', caps: 25, goals: 25, assists: 4, rating: 8.1 },
    { season: '2022/23', club: 'Al-Nassr', league: 'Pro League', transferType: 'Sözleşme', caps: 27, goals: 20, assists: 2, rating: 8.0 },
    { season: '2017/18', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Kiralık (Benfica)', caps: 47, goals: 20, assists: 8, rating: 8.3 }
  ],
  'caglarsoyuncu': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€8.5M', caps: 32, goals: 2, assists: 1, rating: 7.5 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Kiralık (Atlético)', caps: 16, goals: 2, assists: 1, rating: 7.4 },
    { season: '2022/23', club: 'Leicester City', league: 'Premier League', transferType: 'Sözleşme', caps: 9, goals: 1, assists: 0, rating: 7.1 },
    { season: '2019/20', club: 'Leicester City', league: 'Premier League', transferType: 'Sözleşme', caps: 42, goals: 1, assists: 1, rating: 7.9 }
  ],
  'alexanderdjiku': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 34, goals: 1, assists: 1, rating: 7.6 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 36, goals: 3, assists: 2, rating: 7.8 },
    { season: '2022/23', club: 'Strasbourg', league: 'Ligue 1', transferType: 'Kaptan', caps: 31, goals: 1, assists: 2, rating: 7.5 }
  ],
  'cengizunder': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 20, goals: 4, assists: 2, rating: 7.3 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€15.0M', caps: 33, goals: 9, assists: 3, rating: 7.5 },
    { season: '2022/23', club: 'Marseille', league: 'Ligue 1', transferType: 'Sözleşme', caps: 46, goals: 5, assists: 6, rating: 7.4 },
    { season: '2017/18', club: 'AS Roma', league: 'Serie A', transferType: '€14.25M', caps: 32, goals: 8, assists: 2, rating: 7.6 }
  ],
  'allansaintmaximin': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Kiralık (Al-Ahli)', caps: 30, goals: 4, assists: 5, rating: 7.6 },
    { season: '2023/24', club: 'Al-Ahli', league: 'Pro League', transferType: '€27.2M', caps: 31, goals: 4, assists: 10, rating: 7.7 },
    { season: '2022/23', club: 'Newcastle', league: 'Premier League', transferType: 'Sözleşme', caps: 31, goals: 1, assists: 5, rating: 7.5 }
  ],
  'ismailyuksek': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 32, goals: 1, assists: 2, rating: 7.5 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 47, goals: 1, assists: 5, rating: 7.7 },
    { season: '2022/23', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'A Takım', caps: 23, goals: 1, assists: 1, rating: 7.4 }
  ],
  'irfancankahveci': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 35, goals: 6, assists: 5, rating: 7.6 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 46, goals: 18, assists: 12, rating: 8.2 },
    { season: '2020/21', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€7.0M', caps: 12, goals: 0, assists: 2, rating: 7.2 },
    { season: '2019/20', club: 'Başakşehir', league: 'Süper Lig', transferType: 'Şampiyonluk', caps: 39, goals: 6, assists: 5, rating: 7.8 }
  ],

  // --- BEŞİKTAŞ ---
  'ciroimmobile': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 32, goals: 14, assists: 3, rating: 7.7 },
    { season: '2023/24', club: 'Lazio', league: 'Serie A', transferType: 'Sözleşme', caps: 43, goals: 11, assists: 1, rating: 7.2 },
    { season: '2022/23', club: 'Lazio', league: 'Serie A', transferType: 'Sözleşme', caps: 38, goals: 14, assists: 5, rating: 7.4 },
    { season: '2019/20', club: 'Lazio', league: 'Serie A', transferType: 'Altın Ayakkabı', caps: 44, goals: 39, assists: 8, rating: 8.5 }
  ],
  'rafasilva': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.9 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 35, goals: 11, assists: 9, rating: 7.8 },
    { season: '2023/24', club: 'Benfica', league: 'Liga Portugal', transferType: 'Sözleşme', caps: 52, goals: 22, assists: 15, rating: 8.2 },
    { season: '2022/23', club: 'Benfica', league: 'Liga Portugal', transferType: 'Sözleşme', caps: 47, goals: 14, assists: 14, rating: 8.0 }
  ],
  'gedsonfernandes': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 36, goals: 7, assists: 5, rating: 7.6 },
    { season: '2023/24', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 45, goals: 3, assists: 6, rating: 7.5 },
    { season: '2022/23', club: 'Beşiktaş', league: 'Süper Lig', transferType: '€6.0M', caps: 36, goals: 3, assists: 7, rating: 7.6 },
    { season: '2021/22', club: 'Rizespor', league: 'Süper Lig', transferType: 'Kiralık (Benfica)', caps: 11, goals: 3, assists: 3, rating: 7.8 },
    { season: '2020/21', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Kiralık (Benfica)', caps: 18, goals: 1, assists: 3, rating: 7.5 }
  ],
  'mertgunok': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 35, goals: 0, assists: 0, rating: 7.5 },
    { season: '2023/24', club: 'Beşiktaş', league: 'Süper Lig', transferType: '1. Kaleci', caps: 36, goals: 0, assists: 0, rating: 7.7 },
    { season: '2021/22', club: 'Beşiktaş', league: 'Süper Lig', transferType: '€1.3M', caps: 12, goals: 0, assists: 0, rating: 7.3 },
    { season: '2019/20', club: 'Başakşehir', league: 'Süper Lig', transferType: 'Şampiyonluk', caps: 45, goals: 0, assists: 0, rating: 7.9 }
  ],
  'semihkilicsoy': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 30, goals: 8, assists: 4, rating: 7.5 },
    { season: '2023/24', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'A Takım', caps: 35, goals: 12, assists: 3, rating: 7.8 }
  ],
  'gabrielpaulista': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 28, goals: 1, assists: 1, rating: 7.5 },
    { season: '2023/24', club: 'Atlético Madrid', league: 'La Liga', transferType: 'Transfer', caps: 5, goals: 0, assists: 0, rating: 7.1 },
    { season: '2022/23', club: 'Valencia', league: 'La Liga', transferType: 'Kaptan', caps: 23, goals: 1, assists: 0, rating: 7.3 }
  ],
  'milotrashica': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 32, goals: 5, assists: 6, rating: 7.5 },
    { season: '2023/24', club: 'Beşiktaş', league: 'Süper Lig', transferType: '€5.25M', caps: 41, goals: 5, assists: 7, rating: 7.6 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Kiralık (Norwich)', caps: 30, goals: 6, assists: 7, rating: 7.7 }
  ],
  'joaomario': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Kiralık (Benfica)', caps: 26, goals: 3, assists: 4, rating: 7.4 },
    { season: '2023/24', club: 'Benfica', league: 'Liga Portugal', transferType: 'Sözleşme', caps: 51, goals: 9, assists: 4, rating: 7.6 },
    { season: '2022/23', club: 'Benfica', league: 'Liga Portugal', transferType: 'Sözleşme', caps: 51, goals: 23, assists: 15, rating: 8.1 }
  ],

  // --- TRABZONSPOR ---
  'stefansavic': [
    { season: '2025/26', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 22, goals: 0, assists: 0, rating: 7.5 },
    { season: '2023/24', club: 'Atlético Madrid', league: 'La Liga', transferType: 'Sözleşme', caps: 33, goals: 0, assists: 0, rating: 7.4 },
    { season: '2022/23', club: 'Atlético Madrid', league: 'La Liga', transferType: 'Sözleşme', caps: 29, goals: 0, assists: 0, rating: 7.6 }
  ],
  'edinvisca': [
    { season: '2025/26', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Sözleşme', caps: 37, goals: 6, assists: 12, rating: 7.6 },
    { season: '2023/24', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Sözleşme', caps: 37, goals: 5, assists: 12, rating: 7.7 },
    { season: '2021/22', club: 'Trabzonspor', league: 'Süper Lig', transferType: '€4.3M', caps: 26, goals: 9, assists: 13, rating: 8.0 }
  ],
  'anthonynwakaeme': [
    { season: '2025/26', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 25, goals: 3, assists: 4, rating: 7.5 },
    { season: '2023/24', club: 'Al-Fayha', league: 'Pro League', transferType: 'Sözleşme', caps: 27, goals: 6, assists: 5, rating: 7.4 },
    { season: '2021/22', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Şampiyonluk', caps: 36, goals: 15, assists: 11, rating: 8.2 }
  ],
  'denisdragus': [
    { season: '2025/26', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'Trabzonspor', league: 'Süper Lig', transferType: '€1.7M', caps: 28, goals: 4, assists: 2, rating: 7.3 },
    { season: '2023/24', club: 'Gaziantep FK', league: 'Süper Lig', transferType: 'Kiralık (Standard Liège)', caps: 35, goals: 15, assists: 2, rating: 7.8 }
  ],
  'simonbanza': [
    { season: '2025/26', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Kiralık (Braga)', caps: 30, goals: 15, assists: 3, rating: 7.7 },
    { season: '2023/24', club: 'SC Braga', league: 'Liga Portugal', transferType: 'Sözleşme', caps: 41, goals: 23, assists: 5, rating: 8.0 }
  ],

  // --- TURKISH STARS ABROAD ---
  'ardaguler': [
    { season: '2025/26', club: 'Real Madrid', league: 'La Liga', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Real Madrid', league: 'La Liga', transferType: 'Sözleşme', caps: 26, goals: 6, assists: 5, rating: 7.6 },
    { season: '2023/24', club: 'Real Madrid', league: 'La Liga', transferType: '€20.0M', caps: 12, goals: 6, assists: 0, rating: 7.9 },
    { season: '2022/23', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'A Takım', caps: 35, goals: 6, assists: 7, rating: 8.0 },
    { season: '2021/22', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Altyapı / Pro', caps: 16, goals: 3, assists: 5, rating: 7.7 }
  ],
  'keremakturkoglu': [
    { season: '2025/26', club: 'Benfica', league: 'Liga Portugal', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Benfica', league: 'Liga Portugal', transferType: '€12.0M', caps: 35, goals: 11, assists: 8, rating: 7.7 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 54, goals: 15, assists: 9, rating: 7.6 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 38, goals: 10, assists: 12, rating: 7.8 },
    { season: '2021/22', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 52, goals: 13, assists: 13, rating: 7.6 }
  ],
  'ferdikadioglu': [
    { season: '2025/26', club: 'Brighton', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Brighton', league: 'Premier League', transferType: '€30.0M', caps: 28, goals: 2, assists: 2, rating: 7.5 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 51, goals: 3, assists: 5, rating: 8.1 },
    { season: '2022/23', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 48, goals: 4, assists: 5, rating: 7.9 }
  ],
  'hakancalhanoglu': [
    { season: '2025/26', club: 'Inter', league: 'Serie A', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.3 },
    { season: '2024/25', club: 'Inter', league: 'Serie A', transferType: 'Sözleşme', caps: 40, goals: 11, assists: 3, rating: 8.1 },
    { season: '2023/24', club: 'Inter', league: 'Serie A', transferType: 'Şampiyonluk', caps: 40, goals: 15, assists: 3, rating: 8.3 },
    { season: '2022/23', club: 'Inter', league: 'Serie A', transferType: 'Sözleşme', caps: 49, goals: 4, assists: 8, rating: 7.8 },
    { season: '2021/22', club: 'Inter', league: 'Serie A', transferType: 'Bonservissiz', caps: 46, goals: 8, assists: 13, rating: 8.0 }
  ],
  'kenanyildiz': [
    { season: '2025/26', club: 'Juventus', league: 'Serie A', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Juventus', league: 'Serie A', transferType: '10 Numara', caps: 38, goals: 6, assists: 5, rating: 7.7 },
    { season: '2023/24', club: 'Juventus', league: 'Serie A', transferType: 'A Takım', caps: 32, goals: 4, assists: 1, rating: 7.5 }
  ],

  // --- WORLD / EUROPEAN STARS ---
  'kylianmbappe': [
    { season: '2025/26', club: 'Real Madrid', league: 'La Liga', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.5 },
    { season: '2024/25', club: 'Real Madrid', league: 'La Liga', transferType: 'Bonservissiz', caps: 38, goals: 28, assists: 8, rating: 8.4 },
    { season: '2023/24', club: 'Paris SG', league: 'Ligue 1', transferType: 'Sözleşme', caps: 48, goals: 44, assists: 10, rating: 8.6 },
    { season: '2022/23', club: 'Paris SG', league: 'Ligue 1', transferType: 'Sözleşme', caps: 43, goals: 41, assists: 10, rating: 8.5 }
  ],
  'viniciusjunior': [
    { season: '2025/26', club: 'Real Madrid', league: 'La Liga', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.7 },
    { season: '2024/25', club: 'Real Madrid', league: 'La Liga', transferType: 'Sözleşme', caps: 39, goals: 24, assists: 11, rating: 8.5 },
    { season: '2023/24', club: 'Real Madrid', league: 'La Liga', transferType: 'Şampiyonlar Ligi Şampiyonu', caps: 39, goals: 24, assists: 11, rating: 8.6 },
    { season: '2022/23', club: 'Real Madrid', league: 'La Liga', transferType: 'Sözleşme', caps: 55, goals: 23, assists: 21, rating: 8.4 }
  ],
  'judebellingham': [
    { season: '2025/26', club: 'Real Madrid', league: 'La Liga', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.6 },
    { season: '2024/25', club: 'Real Madrid', league: 'La Liga', transferType: 'Sözleşme', caps: 42, goals: 14, assists: 10, rating: 8.3 },
    { season: '2023/24', club: 'Real Madrid', league: 'La Liga', transferType: '€103.0M', caps: 42, goals: 23, assists: 13, rating: 8.7 },
    { season: '2022/23', club: 'Borussia Dortmund', league: 'Bundesliga', transferType: 'Sözleşme', caps: 42, goals: 14, assists: 7, rating: 8.2 }
  ],
  'erlinghaaland': [
    { season: '2025/26', club: 'Manchester City', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.7 },
    { season: '2024/25', club: 'Manchester City', league: 'Premier League', transferType: 'Sözleşme', caps: 40, goals: 34, assists: 5, rating: 8.5 },
    { season: '2023/24', club: 'Manchester City', league: 'Premier League', transferType: 'Gol Kralı', caps: 45, goals: 38, assists: 6, rating: 8.4 },
    { season: '2022/23', club: 'Manchester City', league: 'Premier League', transferType: '€60.0M', caps: 53, goals: 52, assists: 9, rating: 8.8 }
  ],
  'kevindebruyne': [
    { season: '2025/26', club: 'Manchester City', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.5 },
    { season: '2024/25', club: 'Manchester City', league: 'Premier League', transferType: 'Kaptan', caps: 26, goals: 6, assists: 12, rating: 8.1 },
    { season: '2023/24', club: 'Manchester City', league: 'Premier League', transferType: 'Sözleşme', caps: 26, goals: 6, assists: 18, rating: 8.4 },
    { season: '2022/23', club: 'Manchester City', league: 'Premier League', transferType: 'Treble', caps: 49, goals: 10, assists: 31, rating: 8.7 }
  ],
  'mohamedsalah': [
    { season: '2025/26', club: 'Liverpool', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.6 },
    { season: '2024/25', club: 'Liverpool', league: 'Premier League', transferType: 'Sözleşme', caps: 44, goals: 25, assists: 14, rating: 8.4 },
    { season: '2023/24', club: 'Liverpool', league: 'Premier League', transferType: 'Sözleşme', caps: 44, goals: 25, assists: 14, rating: 8.3 },
    { season: '2022/23', club: 'Liverpool', league: 'Premier League', transferType: 'Sözleşme', caps: 51, goals: 30, assists: 16, rating: 8.2 }
  ],
  'robertlewandowski': [
    { season: '2025/26', club: 'FC Barcelona', league: 'La Liga', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.4 },
    { season: '2024/25', club: 'FC Barcelona', league: 'La Liga', transferType: 'Sözleşme', caps: 45, goals: 26, assists: 9, rating: 8.2 },
    { season: '2023/24', club: 'FC Barcelona', league: 'La Liga', transferType: 'Sözleşme', caps: 49, goals: 26, assists: 9, rating: 8.0 },
    { season: '2022/23', club: 'FC Barcelona', league: 'La Liga', transferType: '€45.0M', caps: 46, goals: 33, assists: 8, rating: 8.4 }
  ],
  // --- MORE SÜPER LİG & WORLD STARS ---
  'cenktosun': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.4 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 20, goals: 3, assists: 1, rating: 7.2 },
    { season: '2023/24', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 47, goals: 11, assists: 8, rating: 7.5 },
    { season: '2022/23', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 34, goals: 18, assists: 8, rating: 7.9 },
    { season: '2021/22', club: 'Everton', league: 'Premier League', transferType: 'Sözleşme', caps: 3, goals: 0, assists: 0, rating: 6.5 },
    { season: '2020/21', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Kiralık (Everton)', caps: 4, goals: 3, assists: 1, rating: 7.8 }
  ],
  'yusufyazici': [
    { season: '2025/26', club: 'Olympiacos', league: 'Super League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'Olympiacos', league: 'Super League', transferType: 'Bonservissiz', caps: 15, goals: 2, assists: 1, rating: 7.3 },
    { season: '2023/24', club: 'Lille', league: 'Ligue 1', transferType: 'Sözleşme', caps: 42, goals: 12, assists: 4, rating: 7.6 },
    { season: '2022/23', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Kiralık (Lille)', caps: 20, goals: 5, assists: 1, rating: 7.2 },
    { season: '2020/21', club: 'Lille', league: 'Ligue 1', transferType: 'Şampiyonluk', caps: 42, goals: 14, assists: 5, rating: 7.8 }
  ],
  'ernestmuci': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 28, goals: 5, assists: 2, rating: 7.4 },
    { season: '2023/24', club: 'Beşiktaş', league: 'Süper Lig', transferType: '€10.0M', caps: 17, goals: 4, assists: 0, rating: 7.5 },
    { season: '2022/23', club: 'Legia Warszawa', league: 'Ekstraklasa', transferType: 'Sözleşme', caps: 37, goals: 6, assists: 7, rating: 7.4 }
  ],
  'alexoxladechamberlain': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.4 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 18, goals: 2, assists: 1, rating: 7.2 },
    { season: '2023/24', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 30, goals: 4, assists: 1, rating: 7.4 },
    { season: '2022/23', club: 'Liverpool', league: 'Premier League', transferType: 'Sözleşme', caps: 13, goals: 1, assists: 0, rating: 6.9 }
  ],
  'hakanziyech': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 22, goals: 4, assists: 3, rating: 7.5 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Kiralık (Chelsea)', caps: 23, goals: 8, assists: 4, rating: 7.8 },
    { season: '2022/23', club: 'Chelsea', league: 'Premier League', transferType: 'Sözleşme', caps: 24, goals: 0, assists: 3, rating: 7.1 }
  ],
  'driesmertens': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 36, goals: 6, assists: 11, rating: 7.7 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 51, goals: 12, assists: 19, rating: 8.1 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 33, goals: 7, assists: 4, rating: 7.7 }
  ],
  'keremdemirbay': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 30, goals: 3, assists: 4, rating: 7.4 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: '€3.7M', caps: 42, goals: 6, assists: 7, rating: 7.7 }
  ],
  'krzysztofpiatek': [
    { season: '2025/26', club: 'Başakşehir', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Başakşehir', league: 'Süper Lig', transferType: 'Sözleşme', caps: 36, goals: 18, assists: 2, rating: 7.7 },
    { season: '2023/24', club: 'Başakşehir', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 36, goals: 17, assists: 1, rating: 7.8 }
  ],
  'reymanaj': [
    { season: '2025/26', club: 'Sivasspor', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Sivasspor', league: 'Süper Lig', transferType: 'Sözleşme', caps: 30, goals: 12, assists: 2, rating: 7.6 },
    { season: '2023/24', club: 'Sivasspor', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 36, goals: 22, assists: 2, rating: 8.1 }
  ],
  'mamethiam': [
    { season: '2025/26', club: 'Eyüpspor', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Pendikspor', league: 'Süper Lig', transferType: '€1.7M', caps: 34, goals: 18, assists: 7, rating: 7.8 },
    { season: '2023/24', club: 'Kayserispor', league: 'Süper Lig', transferType: 'Kaptan', caps: 19, goals: 12, assists: 2, rating: 7.9 }
  ],
  'okayyokuslu': [
    { season: '2025/26', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Trabzonspor', league: 'Süper Lig', transferType: '€1.65M', caps: 30, goals: 2, assists: 2, rating: 7.5 },
    { season: '2023/24', club: 'West Brom', league: 'Championship', transferType: 'Sözleşme', caps: 48, goals: 1, assists: 1, rating: 7.7 }
  ],
  'ozantufan': [
    { season: '2025/26', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'Trabzonspor', league: 'Süper Lig', transferType: '€2.0M', caps: 28, goals: 3, assists: 2, rating: 7.4 },
    { season: '2023/24', club: 'Hull City', league: 'Championship', transferType: 'Sözleşme', caps: 40, goals: 10, assists: 2, rating: 7.6 }
  ],
  'sametakaydin': [
    { season: '2025/26', club: 'Çaykur Rizespor', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.4 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 10, goals: 0, assists: 0, rating: 7.1 },
    { season: '2023/24', club: 'Panathinaikos', league: 'Super League', transferType: 'Kiralık (Fenerbahçe)', caps: 15, goals: 0, assists: 1, rating: 7.2 },
    { season: '2022/23', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€3.7M', caps: 21, goals: 0, assists: 0, rating: 7.4 }
  ],
  'rodrigobecao': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 22, goals: 1, assists: 0, rating: 7.6 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€8.3M', caps: 22, goals: 1, assists: 0, rating: 7.7 }
  ],
  'brightosayisamuel': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 30, goals: 1, assists: 3, rating: 7.5 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 39, goals: 4, assists: 2, rating: 7.7 }
  ],
  'almusrati': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: '€11.0M', caps: 28, goals: 2, assists: 1, rating: 7.5 },
    { season: '2023/24', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Kiralık (Braga)', caps: 13, goals: 1, assists: 0, rating: 7.4 }
  ],
  'cherndour': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Kiralık (PSG)', caps: 22, goals: 1, assists: 2, rating: 7.4 }
  ],
  'orkunkokcu': [
    { season: '2025/26', club: 'Benfica', league: 'Liga Portugal', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.0 },
    { season: '2024/25', club: 'Benfica', league: 'Liga Portugal', transferType: 'Sözleşme', caps: 43, goals: 7, assists: 11, rating: 7.9 },
    { season: '2023/24', club: 'Benfica', league: 'Liga Portugal', transferType: '€25.0M', caps: 43, goals: 7, assists: 11, rating: 7.8 },
    { season: '2022/23', club: 'Feyenoord', league: 'Eredivisie', transferType: 'Kaptan & Şampiyon', caps: 46, goals: 12, assists: 5, rating: 8.3 }
  ],
  'zekicelik': [
    { season: '2025/26', club: 'AS Roma', league: 'Serie A', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'AS Roma', league: 'Serie A', transferType: 'Sözleşme', caps: 29, goals: 0, assists: 2, rating: 7.4 },
    { season: '2022/23', club: 'AS Roma', league: 'Serie A', transferType: '€7.0M', caps: 34, goals: 0, assists: 1, rating: 7.3 }
  ],
  'enesunal': [
    { season: '2025/26', club: 'Bournemouth', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Bournemouth', league: 'Premier League', transferType: '€16.5M', caps: 22, goals: 4, assists: 2, rating: 7.5 },
    { season: '2022/23', club: 'Getafe', league: 'La Liga', transferType: 'Sözleşme', caps: 38, goals: 15, assists: 5, rating: 7.9 }
  ],
  'merihdemiral': [
    { season: '2025/26', club: 'Al-Ahli', league: 'Pro League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Al-Ahli', league: 'Pro League', transferType: 'Sözleşme', caps: 30, goals: 1, assists: 1, rating: 7.6 },
    { season: '2023/24', club: 'Al-Ahli', league: 'Pro League', transferType: '€16.6M', caps: 21, goals: 1, assists: 1, rating: 7.5 }
  ],

  // --- ARSENAL & PREMIER LEAGUE STARS ---
  'leandrotrossard': [
    { season: '2025/26', club: 'Arsenal', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Arsenal', league: 'Premier League', transferType: 'Sözleşme Uzatma', caps: 46, goals: 17, assists: 2, rating: 7.8 },
    { season: '2023/24', club: 'Arsenal', league: 'Premier League', transferType: 'Sözleşme Uzatma', caps: 46, goals: 17, assists: 2, rating: 7.8 },
    { season: '2022/23', club: 'Arsenal', league: 'Premier League', transferType: '€24.0M', caps: 22, goals: 1, assists: 10, rating: 7.6 },
    { season: '2022/23', club: 'Brighton', league: 'Premier League', transferType: 'Sözleşme', caps: 17, goals: 7, assists: 3, rating: 7.7 },
    { season: '2021/22', club: 'Brighton', league: 'Premier League', transferType: 'Sözleşme', caps: 34, goals: 8, assists: 3, rating: 7.4 },
    { season: '2020/21', club: 'Brighton', league: 'Premier League', transferType: 'Sözleşme', caps: 35, goals: 5, assists: 5, rating: 7.3 },
    { season: '2019/20', club: 'Brighton', league: 'Premier League', transferType: '€20.0M', caps: 31, goals: 5, assists: 3, rating: 7.2 },
    { season: '2018/19', club: 'KRC Genk', league: 'Pro League', transferType: 'Altyapı / Pro', caps: 47, goals: 22, assists: 11, rating: 8.1 }
  ],
  'trossard': [
    { season: '2025/26', club: 'Arsenal', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Arsenal', league: 'Premier League', transferType: 'Sözleşme Uzatma', caps: 46, goals: 17, assists: 2, rating: 7.8 },
    { season: '2023/24', club: 'Arsenal', league: 'Premier League', transferType: 'Sözleşme Uzatma', caps: 46, goals: 17, assists: 2, rating: 7.8 },
    { season: '2022/23', club: 'Arsenal', league: 'Premier League', transferType: '€24.0M', caps: 22, goals: 1, assists: 10, rating: 7.6 },
    { season: '2022/23', club: 'Brighton', league: 'Premier League', transferType: 'Sözleşme', caps: 17, goals: 7, assists: 3, rating: 7.7 },
    { season: '2021/22', club: 'Brighton', league: 'Premier League', transferType: 'Sözleşme', caps: 34, goals: 8, assists: 3, rating: 7.4 },
    { season: '2020/21', club: 'Brighton', league: 'Premier League', transferType: 'Sözleşme', caps: 35, goals: 5, assists: 5, rating: 7.3 },
    { season: '2019/20', club: 'Brighton', league: 'Premier League', transferType: '€20.0M', caps: 31, goals: 5, assists: 3, rating: 7.2 },
    { season: '2018/19', club: 'KRC Genk', league: 'Pro League', transferType: 'Altyapı / Pro', caps: 47, goals: 22, assists: 11, rating: 8.1 }
  ],
  'bukayosaka': [
    { season: '2025/26', club: 'Arsenal', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.5 },
    { season: '2024/25', club: 'Arsenal', league: 'Premier League', transferType: 'Sözleşme Uzatma', caps: 47, goals: 16, assists: 15, rating: 8.3 },
    { season: '2023/24', club: 'Arsenal', league: 'Premier League', transferType: 'Sözleşme Uzatma', caps: 47, goals: 20, assists: 14, rating: 8.4 },
    { season: '2022/23', club: 'Arsenal', league: 'Premier League', transferType: 'Altyapı / Pro', caps: 48, goals: 15, assists: 11, rating: 8.2 }
  ],
  'martinodegaard': [
    { season: '2025/26', club: 'Arsenal', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.5 },
    { season: '2024/25', club: 'Arsenal', league: 'Premier League', transferType: 'Kaptan', caps: 45, goals: 11, assists: 11, rating: 8.3 },
    { season: '2023/24', club: 'Arsenal', league: 'Premier League', transferType: 'Kaptan', caps: 48, goals: 11, assists: 11, rating: 8.4 },
    { season: '2021/22', club: 'Arsenal', league: 'Premier League', transferType: '€35.0M', caps: 40, goals: 7, assists: 5, rating: 7.9 },
    { season: '2020/21', club: 'Arsenal', league: 'Premier League', transferType: 'Kiralık (Real Madrid)', caps: 20, goals: 2, assists: 2, rating: 7.5 },
    { season: '2019/20', club: 'Real Sociedad', league: 'La Liga', transferType: 'Kiralık (Real Madrid)', caps: 36, goals: 7, assists: 9, rating: 8.1 }
  ],
  'declanrice': [
    { season: '2025/26', club: 'Arsenal', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.5 },
    { season: '2024/25', club: 'Arsenal', league: 'Premier League', transferType: 'Sözleşme Uzatma', caps: 51, goals: 7, assists: 10, rating: 8.3 },
    { season: '2023/24', club: 'Arsenal', league: 'Premier League', transferType: '€116.6M', caps: 51, goals: 7, assists: 10, rating: 8.4 },
    { season: '2022/23', club: 'West Ham', league: 'Premier League', transferType: 'Kaptan & Konferans Şampiyonu', caps: 50, goals: 5, assists: 4, rating: 8.2 }
  ],
  'gabrielmartinelli': [
    { season: '2025/26', club: 'Arsenal', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.1 },
    { season: '2024/25', club: 'Arsenal', league: 'Premier League', transferType: 'Sözleşme Uzatma', caps: 44, goals: 8, assists: 5, rating: 7.7 },
    { season: '2022/23', club: 'Arsenal', league: 'Premier League', transferType: 'Sözleşme Uzatma', caps: 46, goals: 15, assists: 6, rating: 8.0 },
    { season: '2019/20', club: 'Arsenal', league: 'Premier League', transferType: '€7.1M', caps: 26, goals: 10, assists: 4, rating: 7.5 }
  ],
  'kaihavertz': [
    { season: '2025/26', club: 'Arsenal', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.2 },
    { season: '2024/25', club: 'Arsenal', league: 'Premier League', transferType: 'Sözleşme', caps: 51, goals: 14, assists: 7, rating: 8.0 },
    { season: '2023/24', club: 'Arsenal', league: 'Premier League', transferType: '€75.0M', caps: 51, goals: 14, assists: 7, rating: 8.0 },
    { season: '2022/23', club: 'Chelsea', league: 'Premier League', transferType: 'Sözleşme', caps: 47, goals: 9, assists: 1, rating: 7.2 },
    { season: '2020/21', club: 'Chelsea', league: 'Premier League', transferType: '€80.0M', caps: 45, goals: 9, assists: 8, rating: 7.7 },
    { season: '2019/20', club: 'Bayer Leverkusen', league: 'Bundesliga', transferType: 'Altyapı / Pro', caps: 45, goals: 18, assists: 9, rating: 8.3 }
  ],
  'colepalmer': [
    { season: '2025/26', club: 'Chelsea', league: 'Premier League', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.6 },
    { season: '2024/25', club: 'Chelsea', league: 'Premier League', transferType: 'Sözleşme Uzatma', caps: 45, goals: 25, assists: 15, rating: 8.5 },
    { season: '2023/24', club: 'Chelsea', league: 'Premier League', transferType: '€47.0M', caps: 45, goals: 25, assists: 15, rating: 8.6 },
    { season: '2022/23', club: 'Manchester City', league: 'Premier League', transferType: 'Altyapı / Pro', caps: 25, goals: 1, assists: 1, rating: 7.3 }
  ],
  'lamineyamal': [
    { season: '2025/26', club: 'FC Barcelona', league: 'La Liga', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.6 },
    { season: '2024/25', club: 'FC Barcelona', league: 'La Liga', transferType: 'Sözleşme Uzatma', caps: 50, goals: 10, assists: 14, rating: 8.5 },
    { season: '2023/24', club: 'FC Barcelona', league: 'La Liga', transferType: 'Altyapı / Pro', caps: 50, goals: 7, assists: 10, rating: 8.3 }
  ],
  'pedri': [
    { season: '2025/26', club: 'FC Barcelona', league: 'La Liga', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.5 },
    { season: '2024/25', club: 'FC Barcelona', league: 'La Liga', transferType: 'Sözleşme Uzatma', caps: 34, goals: 4, assists: 5, rating: 8.2 },
    { season: '2020/21', club: 'FC Barcelona', league: 'La Liga', transferType: '€20.0M', caps: 52, goals: 4, assists: 6, rating: 8.1 },
    { season: '2019/20', club: 'Las Palmas', league: 'La Liga2', transferType: 'Altyapı / Pro', caps: 37, goals: 4, assists: 7, rating: 7.8 }
  ],
  'gavi': [
    { season: '2025/26', club: 'FC Barcelona', league: 'La Liga', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.3 },
    { season: '2024/25', club: 'FC Barcelona', league: 'La Liga', transferType: 'Sözleşme Uzatma', caps: 15, goals: 2, assists: 1, rating: 7.8 },
    { season: '2022/23', club: 'FC Barcelona', league: 'La Liga', transferType: 'Altyapı / Pro', caps: 49, goals: 3, assists: 7, rating: 8.1 }
  ],
  'harrykane': [
    { season: '2025/26', club: 'Bayern München', league: 'Bundesliga', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.8 },
    { season: '2024/25', club: 'Bayern München', league: 'Bundesliga', transferType: 'Sözleşme', caps: 45, goals: 44, assists: 12, rating: 8.7 },
    { season: '2023/24', club: 'Bayern München', league: 'Bundesliga', transferType: '€95.0M', caps: 45, goals: 44, assists: 12, rating: 8.8 },
    { season: '2022/23', club: 'Tottenham', league: 'Premier League', transferType: 'Kaptan', caps: 49, goals: 32, assists: 5, rating: 8.5 }
  ],
  'jamalmusiala': [
    { season: '2025/26', club: 'Bayern München', league: 'Bundesliga', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.6 },
    { season: '2024/25', club: 'Bayern München', league: 'Bundesliga', transferType: 'Sözleşme Uzatma', caps: 38, goals: 12, assists: 8, rating: 8.3 },
    { season: '2022/23', club: 'Bayern München', league: 'Bundesliga', transferType: 'Altyapı / Pro', caps: 47, goals: 16, assists: 16, rating: 8.5 }
  ],
  'lautaromartinez': [
    { season: '2025/26', club: 'Inter', league: 'Serie A', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.7 },
    { season: '2024/25', club: 'Inter', league: 'Serie A', transferType: 'Kaptan & Gol Kralı', caps: 44, goals: 27, assists: 7, rating: 8.5 },
    { season: '2023/24', club: 'Inter', league: 'Serie A', transferType: 'Kaptan & Şampiyon', caps: 44, goals: 27, assists: 7, rating: 8.6 },
    { season: '2018/19', club: 'Inter', league: 'Serie A', transferType: '€25.0M', caps: 35, goals: 9, assists: 1, rating: 7.5 }
  ],
  'khvichakvaratskhelia': [
    { season: '2025/26', club: 'Napoli', league: 'Serie A', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.4 },
    { season: '2024/25', club: 'Napoli', league: 'Serie A', transferType: 'Sözleşme', caps: 45, goals: 11, assists: 9, rating: 8.1 },
    { season: '2022/23', club: 'Napoli', league: 'Serie A', transferType: '€13.3M', caps: 43, goals: 14, assists: 17, rating: 8.6 },
    { season: '2021/22', club: 'Dinamo Batumi', league: 'Erovnuli Liga', transferType: 'Transfer', caps: 11, goals: 8, assists: 2, rating: 8.2 }
  ],
  'jonassvensson': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 32, goals: 1, assists: 3, rating: 7.4 },
    { season: '2023/24', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 15, goals: 1, assists: 1, rating: 7.4 },
    { season: '2022/23', club: 'Adana Demirspor', league: 'Süper Lig', transferType: 'Sözleşme', caps: 29, goals: 0, assists: 5, rating: 7.6 }
  ],
  'arthurmasuaku': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.5 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 30, goals: 1, assists: 4, rating: 7.4 },
    { season: '2023/24', club: 'Beşiktaş', league: 'Süper Lig', transferType: '€2.0M', caps: 29, goals: 0, assists: 2, rating: 7.5 },
    { season: '2022/23', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Kiralık (West Ham)', caps: 32, goals: 2, assists: 6, rating: 7.6 }
  ],
  'felixuduokhai': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Kiralık (Augsburg)', caps: 28, goals: 1, assists: 1, rating: 7.5 },
    { season: '2023/24', club: 'FC Augsburg', league: 'Bundesliga', transferType: 'Sözleşme', caps: 33, goals: 2, assists: 0, rating: 7.4 }
  ]
};

/**
 * Enhanced real career map entry lookup supporting alias names and last-name matching.
 */
export const findRealCareerMapEntry = (name: string): TransfermarktCareerRow[] | undefined => {
  if (!name) return undefined;
  const normKey = getNormalizedPlayerKey(name);
  if (REAL_PLAYER_CAREER_MAP[normKey]) return REAL_PLAYER_CAREER_MAP[normKey];

  // Try last name
  const parts = name.trim().split(/\s+/);
  if (parts.length > 1) {
    const lastName = parts[parts.length - 1];
    const lastNorm = getNormalizedPlayerKey(lastName);
    if (REAL_PLAYER_CAREER_MAP[lastNorm]) return REAL_PLAYER_CAREER_MAP[lastNorm];
  }

  // Try token containment for matching keys
  for (const mapKey of Object.keys(REAL_PLAYER_CAREER_MAP)) {
    if (mapKey.length >= 5 && (normKey.includes(mapKey) || mapKey.includes(normKey))) {
      return REAL_PLAYER_CAREER_MAP[mapKey];
    }
  }

  return undefined;
};

/**
 * Intelligent career history generator for any player not explicitly in REAL_PLAYER_CAREER_MAP.
 * Uses player characteristics (age, nationality, position, rating, current team)
 * to craft realistic Transfermarkt-style career histories.
 */
export const generatePlayerCareerHistory = (player: Player, team: Team): TransfermarktCareerRow[] => {
  const realRows = findRealCareerMapEntry(player.name);
  const curRating = player.averageRating ? Number(player.averageRating.toFixed(2)) : Number((player.form || 7.2).toFixed(2));

  if (realRows && realRows.length > 0) {
    const cloned = realRows.map((row, idx, arr) => {
      let tType = row.transferType;
      if (tType === 'Sözleşme' || tType === 'Kaptan' || tType === 'Şampiyonluk' || tType === '10 Numara' || tType === 'Gol Kralı') {
        const isSameClub = (idx > 0 && arr[idx - 1].club === row.club) || (idx < arr.length - 1 && arr[idx + 1].club === row.club);
        if (isSameClub) {
          tType = 'Sözleşme Uzatma';
        } else {
          const valM = Math.max(0.5, ((player.marketValue || 6000000) / 1000000 * 0.4)).toFixed(1);
          tType = `€${valM}M`;
        }
      }
      const yCards = row.yellowCards !== undefined ? row.yellowCards : Math.max(0, Math.round(row.caps * 0.12 + (idx % 3)));
      const rCards = row.redCards !== undefined ? row.redCards : (idx % 6 === 0 ? 1 : 0);
      return { 
        ...row, 
        transferType: tType,
        goals: row.goals ?? 0,
        assists: row.assists ?? 0,
        yellowCards: yCards,
        redCards: rCards
      };
    });
    cloned[0].club = team.name;
    cloned[0].league = team.country ? `${team.country} Ligi` : 'Süper Lig';
    cloned[0].caps = player.appearances ?? 0;
    cloned[0].goals = player.goalsScored ?? 0;
    cloned[0].assists = player.assists ?? 0;
    cloned[0].yellowCards = player.yellowCards ?? 0;
    cloned[0].redCards = player.redCards ?? 0;
    cloned[0].rating = (player.appearances && player.appearances > 0) ? curRating : 0;
    return cloned;
  }

  // Hash seed for consistency
  let hash = 0;
  const seedStr = player.id + player.name;
  for (let i = 0; i < seedStr.length; i++) hash = (hash << 5) - hash + seedStr.charCodeAt(i);
  const seed = Math.abs(hash);

  const careerLength = Math.max(2, Math.min(7, player.age - 17));
  const isFw = player.position === 'FW' || player.specificRole === 'ST' || player.specificRole === 'CF';
  const isMid = player.position === 'MID' || player.specificRole === 'CAM' || player.specificRole === 'RW' || player.specificRole === 'LW';
  const isGk = player.position === 'GK';

  // Club pools categorized by region and country
  const trClubsTop = ['Galatasaray', 'Fenerbahçe', 'Beşiktaş', 'Trabzonspor', 'Başakşehir'];
  const trClubsMid = ['Konyaspor', 'Antalyaspor', 'Sivasspor', 'Kasımpaşa', 'Göztepe', 'Alanyaspor', 'Gaziantep FK', 'Rizespor', 'Kayserispor', 'Samsunspor'];
  const trClubsDev = ['Ankaragücü', 'Gençlerbirliği', 'Keçiörengücü', 'Altınordu', 'Bursaspor', 'Erzurumspor', 'Manisa FK', 'Sakaryaspor', 'Kocaelispor', 'Göztepe'];

  const esClubs = ['Sevilla FC', 'Real Betis', 'Valencia CF', 'Villarreal CF', 'Celta Vigo', 'CA Osasuna', 'Getafe CF', 'RCD Mallorca', 'Rayo Vallecano', 'RCD Espanyol'];
  const enClubs = ['Leicester City', 'Leeds United', 'Everton FC', 'Fulham FC', 'West Ham United', 'Southampton FC', 'Wolverhampton', 'Brentford FC', 'Bournemouth', 'Crystal Palace'];
  const deClubs = ['Eintracht Frankfurt', 'VfB Stuttgart', 'VfL Wolfsburg', 'Borussia M’gladbach', 'TSG Hoffenheim', 'SC Freiburg', 'Mainz 05', 'FC Augsburg', 'Union Berlin'];
  const itClubs = ['Fiorentina', 'Torino FC', 'Bologna FC', 'Sassuolo', 'Udinese Calcio', 'Genoa CFC', 'Hellas Verona', 'SS Lazio', 'Atalanta BC'];
  const frClubs = ['Stade Rennais', 'LOSC Lille', 'OGC Nice', 'Toulouse FC', 'Montpellier HSC', 'FC Nantes', 'Stade Reims', 'RC Lens', 'RC Strasbourg'];
  const ptClubs = ['SC Braga', 'Vitória Guimarães', 'Rio Ave FC', 'Boavista FC', 'FC Famalicão', 'Estoril Praia', 'Gil Vicente'];
  const nlClubs = ['AZ Alkmaar', 'FC Twente', 'FC Utrecht', 'SC Heerenveen', 'NEC Nijmegen', 'Sparta Rotterdam', 'Vitesse Arnhem'];
  const southAmClubs = ['Santos FC', 'Flamengo', 'Boca Juniors', 'River Plate', 'São Paulo', 'Palmeiras', 'Atlético Nacional', 'Cruzeiro', 'Internacional'];
  const euroTopClubs = ['Real Madrid', 'FC Barcelona', 'Manchester City', 'Bayern München', 'Paris SG', 'Inter', 'Arsenal', 'Juventus', 'Liverpool', 'Chelsea FC'];

  const rows: TransfermarktCareerRow[] = [];
  const currentYear = 2025;

  for (let i = 0; i < careerLength; i++) {
    const startYr = currentYear - i;
    const endYrStr = (startYr + 1).toString().slice(-2);
    const seasonStr = `${startYr}/${endYrStr}`;
    const ageAtSeason = player.age - i;

    let clubName = team.name;
    let leagueName = team.country ? `${team.country} Ligi` : 'Süper Lig';
    let transferFee = 'Sözleşme';

    if (i === 0) {
      clubName = team.name;
      transferFee = player.isLoaned ? `Kiralık (${player.parentClubName || 'Eski Kulüp'})` : 'Mevcut Kulüp';
    } else if (i === 1 && (seed % 3 === 0)) {
      clubName = team.name;
      transferFee = 'Sözleşme Yenilendi';
    } else if (ageAtSeason <= 19) {
      clubName = `${team.name} Altyapı`;
      transferFee = 'Altyapı / Pro';
      leagueName = 'Gelişim Ligi';
    } else {
      const nat = player.nationality || '';
      if (nat === 'Türkiye') {
        if (player.overall >= 80 && i > 1) {
          clubName = trClubsTop[(seed + i) % trClubsTop.length];
        } else if (player.overall >= 74) {
          clubName = trClubsMid[(seed + i) % trClubsMid.length];
        } else {
          clubName = trClubsDev[(seed + i) % trClubsDev.length];
          leagueName = '1. Lig';
        }
      } else if (nat === 'İspanya') {
        clubName = esClubs[(seed + i) % esClubs.length];
        leagueName = 'La Liga';
      } else if (nat === 'İngiltere') {
        clubName = enClubs[(seed + i) % enClubs.length];
        leagueName = 'Premier League';
      } else if (nat === 'Almanya') {
        clubName = deClubs[(seed + i) % deClubs.length];
        leagueName = 'Bundesliga';
      } else if (nat === 'İtalya') {
        clubName = itClubs[(seed + i) % itClubs.length];
        leagueName = 'Serie A';
      } else if (nat === 'Fransa') {
        clubName = frClubs[(seed + i) % frClubs.length];
        leagueName = 'Ligue 1';
      } else if (nat === 'Portekiz') {
        clubName = ptClubs[(seed + i) % ptClubs.length];
        leagueName = 'Liga Portugal';
      } else if (nat === 'Hollanda') {
        clubName = nlClubs[(seed + i) % nlClubs.length];
        leagueName = 'Eredivisie';
      } else if (['Brezilya', 'Arjantin', 'Uruguay', 'Kolombiya'].includes(nat)) {
        if (i >= careerLength - 2) {
          clubName = southAmClubs[(seed + i) % southAmClubs.length];
          leagueName = 'Güney Amerika Ligi';
        } else {
          clubName = esClubs[(seed + i) % esClubs.length];
          leagueName = 'La Liga';
        }
      } else {
        if (player.overall >= 82 && i === 1) {
          clubName = euroTopClubs[(seed + i) % euroTopClubs.length];
          leagueName = 'Avrupa Ligi';
        } else {
          const mixedPool = [...esClubs, ...enClubs, ...deClubs, ...itClubs, ...frClubs];
          clubName = mixedPool[(seed + i) % mixedPool.length];
          leagueName = 'Avrupa Ligi';
        }
      }

      const valM = Math.max(0.5, ((player.marketValue || 6000000) / 1000000 * (0.3 + ((seed + i) % 5) * 0.15))).toFixed(1);
      transferFee = (i % 3 === 0) ? 'Bonservissiz' : (i % 4 === 0) ? 'Kiralık' : `€${valM}M`;
    }

    const baseCaps = ageAtSeason < 20 ? 10 + (seed % 10) : 22 + ((seed + i * 7) % 14);
    const caps = i === 0 ? (player.appearances ?? 0) : Math.min(38, baseCaps);

    let goals = 0;
    let assists = 0;
    let yellowCards = 0;
    let redCards = 0;

    if (i === 0) {
      goals = player.goalsScored ?? 0;
      assists = player.assists ?? 0;
      yellowCards = player.yellowCards ?? 0;
      redCards = player.redCards ?? 0;
    } else if (isGk) {
      goals = 0;
      assists = 0;
      yellowCards = (seed + i) % 4 === 0 ? 1 : 0;
      redCards = (seed + i) % 18 === 0 ? 1 : 0;
    } else if (isFw) {
      goals = Math.round(caps * 0.38 * (0.8 + ((seed + i) % 5) * 0.1));
      assists = Math.round(caps * 0.12 * (0.8 + (seed % 4) * 0.1));
      yellowCards = Math.max(0, Math.round(caps * 0.08 + ((seed + i) % 3)));
      redCards = (seed + i * 2) % 11 === 0 ? 1 : 0;
    } else if (isMid) {
      goals = Math.round(caps * 0.15 * (0.8 + ((seed + i) % 4) * 0.1));
      assists = Math.round(caps * 0.22 * (0.8 + (seed % 4) * 0.1));
      yellowCards = Math.max(1, Math.round(caps * 0.14 + ((seed + i) % 3)));
      redCards = (seed + i * 3) % 9 === 0 ? 1 : 0;
    } else {
      goals = Math.round(caps * 0.04);
      assists = Math.round(caps * 0.05);
      yellowCards = Math.max(1, Math.round(caps * 0.18 + ((seed + i) % 4)));
      redCards = (seed + i * 2) % 8 === 0 ? 1 : 0;
    }

    const rating = i === 0 ? curRating : Number((6.8 + (player.overall / 100) * 1.1 + ((seed + i) % 5) * 0.06).toFixed(2));

    rows.push({
      season: seasonStr,
      club: clubName,
      league: leagueName,
      transferType: transferFee,
      caps,
      goals,
      assists,
      yellowCards,
      redCards,
      rating
    });
  }

  return rows;
};
