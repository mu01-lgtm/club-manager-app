import { ExternalTeamData } from '../components/WorldScoutModal';

export const SPANISH_TEAMS: ExternalTeamData[] = [
  // 1. Real Madrid CF (Updated per Screenshot 2 & User Request)
  {
    id: 'real-madrid',
    name: 'Real Madrid CF',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Santiago Bernabéu',
    manager: 'Carlo Ancelotti',
    overall: 88,
    budget: 150000000,
    badgeColor: 'from-amber-400 to-amber-600',
    shortName: 'RMA',
    players: [
      // 11 Starters in 4-3-3 order: (0: GK, 1: LB, 2: LCB, 3: RCB, 4: RB, 5: LCM, 6: CDM, 7: RCM, 8: LW, 9: ST, 10: RW)
      { id: 'rma-courtois', name: 'Thibaut Courtois', age: 32, position: 'GK', specificRole: 'GK', overall: 89, stamina: 88, form: 8.4, marketValue: 40000000, wage: 35000, nationality: 'Belçika', attributes: { pace: 50, shooting: 15, passing: 72, defending: 90, physical: 85 }, isStarting: true, number: 1 },
      { id: 'rma-vazquez', name: 'Lucas Vázquez', age: 33, position: 'DEF', specificRole: 'LB', overall: 81, stamina: 90, form: 8.1, marketValue: 10000000, wage: 25000, nationality: 'İspanya', attributes: { pace: 80, shooting: 72, passing: 78, defending: 78, physical: 76 }, isStarting: true, number: 17 },
      { id: 'rma-huijsen', name: 'Dean Huijsen', age: 19, position: 'DEF', specificRole: 'CB', overall: 79, stamina: 88, form: 8.1, marketValue: 25000000, wage: 18000, nationality: 'İspanya', attributes: { pace: 74, shooting: 52, passing: 78, defending: 80, physical: 81 }, isStarting: true, number: 4 },
      { id: 'rma-rudiger', name: 'Antonio Rüdiger', age: 31, position: 'DEF', specificRole: 'CB', overall: 87, stamina: 94, form: 8.5, marketValue: 40000000, wage: 32000, nationality: 'Almanya', attributes: { pace: 80, shooting: 48, passing: 72, defending: 88, physical: 90 }, isStarting: true, number: 22 },
      { id: 'rma-arnold', name: 'Trent Alexander-Arnold', age: 25, position: 'DEF', specificRole: 'RB', overall: 86, stamina: 90, form: 8.5, marketValue: 70000000, wage: 38000, nationality: 'İngiltere', attributes: { pace: 80, shooting: 78, passing: 92, defending: 78, physical: 75 }, isStarting: true, number: 66 },
      { id: 'rma-bellingham', name: 'Jude Bellingham', age: 21, position: 'MID', specificRole: 'CAM', overall: 90, stamina: 95, form: 8.9, marketValue: 180000000, wage: 50000, nationality: 'İngiltere', attributes: { pace: 82, shooting: 86, passing: 88, defending: 78, physical: 87 }, isStarting: true, number: 5 },
      { id: 'rma-valverde', name: 'Federico Valverde', age: 26, position: 'MID', specificRole: 'CDM', overall: 88, stamina: 98, form: 8.7, marketValue: 120000000, wage: 40000, nationality: 'Uruguay', attributes: { pace: 89, shooting: 82, passing: 85, defending: 80, physical: 88 }, isStarting: true, number: 8 },
      { id: 'rma-guler', name: 'Arda Güler', age: 19, position: 'MID', specificRole: 'CM', overall: 82, stamina: 90, form: 8.4, marketValue: 50000000, wage: 30000, nationality: 'Türkiye', attributes: { pace: 80, shooting: 81, passing: 86, defending: 45, physical: 66 }, isStarting: true, number: 15 },
      { id: 'rma-vinicius', name: 'Vinícius Júnior', age: 24, position: 'FW', specificRole: 'LW', overall: 90, stamina: 93, form: 9.0, marketValue: 170000000, wage: 55000, nationality: 'Brezilya', attributes: { pace: 95, shooting: 85, passing: 83, defending: 34, physical: 76 }, isStarting: true, number: 7 },
      { id: 'rma-mbappe', name: 'Kylian Mbappé', age: 25, position: 'FW', specificRole: 'ST', overall: 92, stamina: 94, form: 9.2, marketValue: 180000000, wage: 65000, nationality: 'Fransa', attributes: { pace: 97, shooting: 91, passing: 83, defending: 38, physical: 80 }, isStarting: true, number: 9 },
      { id: 'rma-brahim', name: 'Brahim Díaz', age: 25, position: 'FW', specificRole: 'RW', overall: 82, stamina: 88, form: 8.1, marketValue: 40000000, wage: 22000, nationality: 'Fas', attributes: { pace: 84, shooting: 78, passing: 82, defending: 40, physical: 65 }, isStarting: true, number: 21 },
      // Yedekler & Rotasyon
      { id: 'rma-lunin', name: 'Andriy Lunin', age: 25, position: 'GK', specificRole: 'GK', overall: 82, stamina: 88, form: 8.2, marketValue: 20000000, wage: 18000, nationality: 'Ukrayna', attributes: { pace: 50, shooting: 15, passing: 70, defending: 82, physical: 78 }, isStarting: false, number: 13 },
      { id: 'rma-militao', name: 'Éder Militão', age: 26, position: 'DEF', specificRole: 'CB', overall: 86, stamina: 86, form: 8.2, marketValue: 55000000, wage: 28500, nationality: 'Brezilya', attributes: { pace: 82, shooting: 45, passing: 70, defending: 86, physical: 85 }, isStarting: false, isInjured: true, injuryType: 'Kalça', injuryWeeksLeft: 3, number: 3 },
      { id: 'rma-asencio', name: 'Raúl Asencio', age: 21, position: 'DEF', specificRole: 'CB', overall: 76, stamina: 85, form: 7.8, marketValue: 15000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 75, shooting: 40, passing: 68, defending: 78, physical: 78 }, isStarting: false, isInjured: true, injuryType: 'Kas', injuryWeeksLeft: 2, number: 35 },
      { id: 'rma-mendy', name: 'Ferland Mendy', age: 29, position: 'DEF', specificRole: 'LB', overall: 83, stamina: 89, form: 7.9, marketValue: 22000000, wage: 28000, nationality: 'Fransa', attributes: { pace: 88, shooting: 55, passing: 72, defending: 83, physical: 84 }, isStarting: false, number: 23 },
      { id: 'rma-frangarcia', name: 'Fran García', age: 25, position: 'DEF', specificRole: 'LB', overall: 79, stamina: 92, form: 8.0, marketValue: 15000000, wage: 18000, nationality: 'İspanya', attributes: { pace: 88, shooting: 55, passing: 74, defending: 76, physical: 75 }, isStarting: false, number: 20 },
      { id: 'rma-camavinga', name: 'Eduardo Camavinga', age: 21, position: 'MID', specificRole: 'CDM', overall: 84, stamina: 92, form: 8.0, marketValue: 70000000, wage: 32000, nationality: 'Fransa', attributes: { pace: 82, shooting: 68, passing: 81, defending: 83, physical: 82 }, isStarting: false, number: 6 },
      { id: 'rma-tchouameni', name: 'Aurélien Tchouaméni', age: 24, position: 'MID', specificRole: 'CDM', overall: 85, stamina: 93, form: 8.2, marketValue: 75000000, wage: 35000, nationality: 'Fransa', attributes: { pace: 78, shooting: 70, passing: 82, defending: 86, physical: 86 }, isStarting: false, number: 14 },
      { id: 'rma-rodrygo', name: 'Rodrygo', age: 23, position: 'FW', specificRole: 'RW', overall: 86, stamina: 85, form: 8.3, marketValue: 100000000, wage: 33000, nationality: 'Brezilya', attributes: { pace: 89, shooting: 82, passing: 81, defending: 36, physical: 72 }, isStarting: false, isInjured: true, injuryType: 'Eklem & Bağ', injuryWeeksLeft: 4, number: 11 },
      { id: 'rma-endrick', name: 'Endrick', age: 18, position: 'FW', specificRole: 'ST', overall: 78, stamina: 88, form: 8.0, marketValue: 60000000, wage: 20000, nationality: 'Brezilya', attributes: { pace: 88, shooting: 81, passing: 68, defending: 35, physical: 78 }, isStarting: false, number: 16 },
      { id: 'rma-mastantuono', name: 'Franco Mastantuono', age: 17, position: 'FW', specificRole: 'RW', overall: 77, stamina: 86, form: 8.0, marketValue: 35000000, wage: 18000, nationality: 'Arjantin', attributes: { pace: 82, shooting: 78, passing: 79, defending: 40, physical: 68 }, isStarting: false, number: 30 },
      { id: 'rma-asprilla', name: 'Yaser Asprilla', age: 22, position: 'FW', specificRole: 'RW', overall: 76, stamina: 88, form: 7.9, marketValue: 25000000, wage: 18000, nationality: 'Kolombiya', attributes: { pace: 84, shooting: 74, passing: 76, defending: 38, physical: 68 }, isStarting: false, number: 28 },
    ]
  },

  // 2. FC Barcelona (Updated per Screenshot 3)
  {
    id: 'fc-barcelona',
    name: 'FC Barcelona',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Spotify Camp Nou',
    manager: 'Hansi Flick',
    overall: 86,
    budget: 85000000,
    badgeColor: 'from-blue-700 to-red-700',
    shortName: 'BAR',
    players: [
      // Kaleciler
      { id: 'bar-joangarcia', name: 'Joan García', age: 23, position: 'GK', specificRole: 'GK', overall: 80, stamina: 90, form: 8.2, marketValue: 20000000, wage: 16000, nationality: 'İspanya', attributes: { pace: 50, shooting: 15, passing: 72, defending: 81, physical: 78 }, isStarting: true },
      { id: 'bar-szczesny', name: 'Wojciech Szczęsny', age: 34, position: 'GK', specificRole: 'GK', overall: 81, stamina: 84, form: 8.0, marketValue: 10000000, wage: 20000, nationality: 'Polonya', attributes: { pace: 48, shooting: 15, passing: 70, defending: 82, physical: 78 }, isStarting: false },
      { id: 'bar-yaakobishvili', name: 'Áron Yaakobishvili', age: 18, position: 'GK', specificRole: 'GK', overall: 71, stamina: 85, form: 7.6, marketValue: 5000000, wage: 6000, nationality: 'Macaristan', attributes: { pace: 48, shooting: 15, passing: 65, defending: 72, physical: 72 }, isStarting: false },
      // Defanslar
      { id: 'bar-cubarsi', name: 'Pau Cubarsí', age: 17, position: 'DEF', specificRole: 'CB', overall: 82, stamina: 90, form: 8.3, marketValue: 50000000, wage: 20000, nationality: 'İspanya', attributes: { pace: 76, shooting: 40, passing: 83, defending: 83, physical: 76 }, isStarting: true },
      { id: 'bar-kounde', name: 'Jules Koundé', age: 25, position: 'DEF', specificRole: 'RB', overall: 85, stamina: 92, form: 8.3, marketValue: 55000000, wage: 34000, nationality: 'Fransa', attributes: { pace: 84, shooting: 52, passing: 75, defending: 86, physical: 80 }, isStarting: true },
      { id: 'bar-balde', name: 'Alejandro Balde', age: 20, position: 'DEF', specificRole: 'LB', overall: 82, stamina: 93, form: 8.1, marketValue: 45000000, wage: 28000, nationality: 'İspanya', attributes: { pace: 92, shooting: 50, passing: 74, defending: 78, physical: 76 }, isStarting: true },
      { id: 'bar-araujo', name: 'Ronald Araújo', age: 25, position: 'DEF', specificRole: 'CB', overall: 86, stamina: 91, form: 8.3, marketValue: 70000000, wage: 38000, nationality: 'Uruguay', attributes: { pace: 85, shooting: 46, passing: 68, defending: 87, physical: 88 }, isStarting: true },
      { id: 'bar-christensen', name: 'Andreas Christensen', age: 28, position: 'DEF', specificRole: 'CB', overall: 82, stamina: 86, form: 8.0, marketValue: 30000000, wage: 26000, nationality: 'Danimarka', attributes: { pace: 68, shooting: 38, passing: 75, defending: 83, physical: 78 }, isStarting: false },
      { id: 'bar-garcia', name: 'Eric García', age: 23, position: 'DEF', specificRole: 'CB', overall: 78, stamina: 86, form: 7.8, marketValue: 18000000, wage: 18000, nationality: 'İspanya', attributes: { pace: 70, shooting: 42, passing: 78, defending: 78, physical: 74 }, isStarting: false },
      { id: 'bar-martin', name: 'Gerard Martín', age: 22, position: 'DEF', specificRole: 'LB', overall: 74, stamina: 85, form: 7.7, marketValue: 8000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 78, shooting: 48, passing: 70, defending: 74, physical: 72 }, isStarting: false },
      { id: 'bar-fort', name: 'Hector Fort', age: 18, position: 'DEF', specificRole: 'RB', overall: 75, stamina: 87, form: 7.8, marketValue: 12000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 82, shooting: 52, passing: 72, defending: 74, physical: 70 }, isStarting: false },
      { id: 'bar-espart', name: 'Xavi Espart', age: 17, position: 'DEF', specificRole: 'RB', overall: 70, stamina: 84, form: 7.5, marketValue: 4000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 78, shooting: 48, passing: 68, defending: 70, physical: 68 }, isStarting: false },
      { id: 'bar-cortes', name: 'Álvaro Cortés', age: 19, position: 'DEF', specificRole: 'CB', overall: 70, stamina: 84, form: 7.5, marketValue: 4000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 68, shooting: 35, passing: 64, defending: 71, physical: 74 }, isStarting: false },
      { id: 'bar-torrents', name: 'Jofre Torrents', age: 17, position: 'DEF', specificRole: 'LB', overall: 70, stamina: 80, form: 7.4, marketValue: 4000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 78, shooting: 48, passing: 66, defending: 70, physical: 68 }, isStarting: false, isInjured: true, injuryType: 'Baldır', injuryWeeksLeft: 3 },
      // Orta Sahalar
      { id: 'bar-yamal', name: 'Lamine Yamal', age: 17, position: 'FW', specificRole: 'RW', overall: 87, stamina: 95, form: 9.1, marketValue: 140000000, wage: 30000, nationality: 'İspanya', attributes: { pace: 91, shooting: 83, passing: 86, defending: 40, physical: 68 }, isStarting: true },
      { id: 'bar-raphinha', name: 'Raphinha', age: 27, position: 'FW', specificRole: 'LW', overall: 86, stamina: 93, form: 8.8, marketValue: 70000000, wage: 38000, nationality: 'Brezilya', attributes: { pace: 89, shooting: 84, passing: 83, defending: 50, physical: 76 }, isStarting: true },
      { id: 'bar-pedri', name: 'Pedri', age: 21, position: 'MID', specificRole: 'CM', overall: 87, stamina: 90, form: 8.6, marketValue: 90000000, wage: 32000, nationality: 'İspanya', attributes: { pace: 78, shooting: 75, passing: 90, defending: 72, physical: 70 }, isStarting: true },
      { id: 'bar-gavi', name: 'Gavi', age: 19, position: 'MID', specificRole: 'CM', overall: 85, stamina: 94, form: 8.5, marketValue: 80000000, wage: 30000, nationality: 'İspanya', attributes: { pace: 80, shooting: 74, passing: 83, defending: 78, physical: 82 }, isStarting: true },
      { id: 'bar-dejong', name: 'Frenkie de Jong', age: 27, position: 'MID', specificRole: 'CDM', overall: 86, stamina: 85, form: 8.3, marketValue: 70000000, wage: 42000, nationality: 'Hollanda', attributes: { pace: 81, shooting: 70, passing: 87, defending: 79, physical: 80 }, isStarting: false, isInjured: true, injuryType: 'Menisküs', injuryWeeksLeft: 4 },
      { id: 'bar-olmo', name: 'Dani Olmo', age: 26, position: 'MID', specificRole: 'CAM', overall: 85, stamina: 88, form: 8.3, marketValue: 60000000, wage: 34000, nationality: 'İspanya', attributes: { pace: 79, shooting: 81, passing: 85, defending: 50, physical: 68 }, isStarting: true },
      { id: 'bar-fermin', name: 'Fermín López', age: 21, position: 'MID', specificRole: 'CAM', overall: 80, stamina: 89, form: 8.2, marketValue: 35000000, wage: 18000, nationality: 'İspanya', attributes: { pace: 80, shooting: 78, passing: 79, defending: 58, physical: 72 }, isStarting: false },
      { id: 'bar-bernal', name: 'Marc Bernal', age: 17, position: 'MID', specificRole: 'CM', overall: 76, stamina: 87, form: 7.9, marketValue: 15000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 72, shooting: 65, passing: 78, defending: 76, physical: 74 }, isStarting: false },
      { id: 'bar-casado', name: 'Marc Casadó', age: 20, position: 'MID', specificRole: 'CDM', overall: 78, stamina: 90, form: 8.2, marketValue: 20000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 75, shooting: 64, passing: 80, defending: 78, physical: 76 }, isStarting: false },
      { id: 'bar-fernandez', name: 'Toni Fernández', age: 16, position: 'MID', specificRole: 'RW', overall: 71, stamina: 84, form: 7.6, marketValue: 8000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 78, shooting: 70, passing: 72, defending: 38, physical: 62 }, isStarting: false, isInjured: true, injuryType: 'Şüpheli (Ayak Bileği)', injuryWeeksLeft: 1 },
      { id: 'bar-marques', name: 'Tomás Marqués', age: 18, position: 'MID', specificRole: 'CM', overall: 69, stamina: 84, form: 7.5, marketValue: 4000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 70, shooting: 62, passing: 72, defending: 64, physical: 65 }, isStarting: false },
      { id: 'bar-bisiwu', name: 'Jesse Bisiwu', age: 16, position: 'MID', specificRole: 'LW', overall: 70, stamina: 85, form: 7.5, marketValue: 5000000, wage: 5000, nationality: 'Belçika', attributes: { pace: 82, shooting: 68, passing: 70, defending: 35, physical: 64 }, isStarting: false },
      { id: 'bar-farinas', name: 'Brian Fariñas', age: 18, position: 'MID', specificRole: 'CM', overall: 70, stamina: 84, form: 7.5, marketValue: 4000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 72, shooting: 64, passing: 73, defending: 66, physical: 66 }, isStarting: false },
      // Forvetler
      { id: 'bar-ferran', name: 'Ferran Torres', age: 24, position: 'FW', specificRole: 'ST', overall: 82, stamina: 88, form: 8.0, marketValue: 30000000, wage: 25000, nationality: 'İspanya', attributes: { pace: 83, shooting: 80, passing: 77, defending: 42, physical: 73 }, isStarting: true },
      { id: 'bar-bardghji', name: 'Roony Bardghji', age: 18, position: 'FW', specificRole: 'RW', overall: 77, stamina: 86, form: 8.0, marketValue: 20000000, wage: 12000, nationality: 'İsveç', attributes: { pace: 84, shooting: 76, passing: 75, defending: 38, physical: 68 }, isStarting: false },
      { id: 'bar-kluivert', name: 'Shane Patrick Kluivert', age: 17, position: 'FW', specificRole: 'ST', overall: 71, stamina: 85, form: 7.6, marketValue: 8000000, wage: 8000, nationality: 'Hollanda', attributes: { pace: 80, shooting: 72, passing: 65, defending: 32, physical: 70 }, isStarting: false }
    ]
  },

  // 3. Atlético Madrid (Updated per User Request)
  {
    id: 'atletico-madrid',
    name: 'Atlético Madrid',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Cívitas Metropolitano',
    manager: 'Diego Simeone',
    overall: 85,
    budget: 80000000,
    badgeColor: 'from-red-600 to-blue-800',
    shortName: 'ATM',
    players: [
      // Kaleciler
      { id: 'atm-musso', name: 'Juan Musso', age: 30, position: 'GK', specificRole: 'GK', overall: 79, stamina: 85, form: 7.9, marketValue: 12000000, wage: 18000, nationality: 'Arjantin', attributes: { pace: 48, shooting: 15, passing: 66, defending: 79, physical: 78 }, isStarting: false },
      { id: 'atm-oblak', name: 'Jan Oblak', age: 31, position: 'GK', specificRole: 'GK', overall: 88, stamina: 90, form: 8.3, marketValue: 30000000, wage: 30000, nationality: 'Slovenya', attributes: { pace: 48, shooting: 15, passing: 68, defending: 88, physical: 84 }, isStarting: true },
      // Defanslar
      { id: 'atm-molina', name: 'Nahuel Molina', age: 26, position: 'DEF', specificRole: 'DR', overall: 81, stamina: 90, form: 8.0, marketValue: 28000000, wage: 22000, nationality: 'Arjantin', attributes: { pace: 84, shooting: 62, passing: 74, defending: 78, physical: 76 }, isStarting: true },
      { id: 'atm-llorente', name: 'Marcos Llorente', age: 29, position: 'DEF', specificRole: 'DR', overall: 84, stamina: 96, form: 8.4, marketValue: 35000000, wage: 28000, nationality: 'İspanya', attributes: { pace: 89, shooting: 78, passing: 78, defending: 80, physical: 82 }, isStarting: true },
      { id: 'atm-lenormand', name: 'Robin Le Normand', age: 27, position: 'DEF', specificRole: 'DC', overall: 83, stamina: 90, form: 8.1, marketValue: 40000000, wage: 24000, nationality: 'İspanya', attributes: { pace: 74, shooting: 40, passing: 70, defending: 84, physical: 83 }, isStarting: true },
      { id: 'atm-gimenez', name: 'José María Giménez', age: 29, position: 'DEF', specificRole: 'DC', overall: 83, stamina: 86, form: 8.0, marketValue: 25000000, wage: 26000, nationality: 'Uruguay', attributes: { pace: 72, shooting: 45, passing: 62, defending: 85, physical: 86 }, isStarting: true },
      { id: 'atm-pubill', name: 'Marc Pubill', age: 21, position: 'DEF', specificRole: 'DR', overall: 77, stamina: 88, form: 7.8, marketValue: 15000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 82, shooting: 50, passing: 70, defending: 76, physical: 78 }, isStarting: false },
      { id: 'atm-lenglet', name: 'Clément Lenglet', age: 29, position: 'DEF', specificRole: 'DC', overall: 79, stamina: 88, form: 7.9, marketValue: 10000000, wage: 20000, nationality: 'Fransa', attributes: { pace: 70, shooting: 42, passing: 76, defending: 80, physical: 80 }, isStarting: false },
      { id: 'atm-galan', name: 'Javi Galán', age: 29, position: 'DEF', specificRole: 'DL', overall: 79, stamina: 89, form: 7.9, marketValue: 10000000, wage: 16000, nationality: 'İspanya', attributes: { pace: 82, shooting: 52, passing: 74, defending: 78, physical: 75 }, isStarting: false },
      // Orta Sahalar
      { id: 'atm-almada', name: 'Thiago Almada', age: 23, position: 'MID', specificRole: 'AM', overall: 81, stamina: 88, form: 8.2, marketValue: 30000000, wage: 22000, nationality: 'Arjantin', attributes: { pace: 84, shooting: 78, passing: 82, defending: 45, physical: 68 }, isStarting: true },
      { id: 'atm-lino', name: 'Samuel Lino', age: 24, position: 'MID', specificRole: 'LW', overall: 82, stamina: 92, form: 8.3, marketValue: 35000000, wage: 22000, nationality: 'Brezilya', attributes: { pace: 86, shooting: 78, passing: 80, defending: 58, physical: 72 }, isStarting: false },
      { id: 'atm-giuliano', name: 'Giuliano Simeone', age: 21, position: 'MID', specificRole: 'RW', overall: 76, stamina: 88, form: 7.8, marketValue: 12000000, wage: 10000, nationality: 'Arjantin', attributes: { pace: 84, shooting: 72, passing: 70, defending: 50, physical: 74 }, isStarting: false },
      { id: 'atm-baena', name: 'Álex Baena', age: 23, position: 'MID', specificRole: 'LW', overall: 82, stamina: 90, form: 8.3, marketValue: 40000000, wage: 24000, nationality: 'İspanya', attributes: { pace: 80, shooting: 78, passing: 85, defending: 52, physical: 72 }, isStarting: true },
      { id: 'atm-riquelme', name: 'Rodrigo Riquelme', age: 24, position: 'MID', specificRole: 'LW', overall: 80, stamina: 89, form: 8.1, marketValue: 25000000, wage: 18000, nationality: 'İspanya', attributes: { pace: 84, shooting: 76, passing: 80, defending: 50, physical: 68 }, isStarting: true },
      { id: 'atm-pineda', name: 'Orbelín Pineda', age: 28, position: 'MID', specificRole: 'MC', overall: 78, stamina: 88, form: 7.8, marketValue: 12000000, wage: 14000, nationality: 'Meksika', attributes: { pace: 78, shooting: 72, passing: 78, defending: 68, physical: 72 }, isStarting: false },
      { id: 'atm-barrios', name: 'Pablo Barrios', age: 21, position: 'MID', specificRole: 'MC', overall: 79, stamina: 90, form: 8.0, marketValue: 25000000, wage: 16000, nationality: 'İspanya', attributes: { pace: 76, shooting: 70, passing: 81, defending: 76, physical: 75 }, isStarting: true },
      { id: 'atm-cardoso', name: 'Johnny Cardoso', age: 22, position: 'MID', specificRole: 'MC', overall: 78, stamina: 88, form: 7.9, marketValue: 20000000, wage: 15000, nationality: 'ABD', attributes: { pace: 72, shooting: 65, passing: 76, defending: 79, physical: 80 }, isStarting: false },
      { id: 'atm-lemar', name: 'Thomas Lemar', age: 28, position: 'MID', specificRole: 'MC', overall: 78, stamina: 84, form: 7.6, marketValue: 12000000, wage: 20000, nationality: 'Fransa', attributes: { pace: 76, shooting: 72, passing: 81, defending: 58, physical: 68 }, isStarting: false },
      { id: 'atm-koke', name: 'Koke', age: 32, position: 'MID', specificRole: 'MC', overall: 82, stamina: 88, form: 8.0, marketValue: 12000000, wage: 26000, nationality: 'İspanya', attributes: { pace: 65, shooting: 72, passing: 85, defending: 79, physical: 78 }, isStarting: true },
      { id: 'atm-gallagher', name: 'Conor Gallagher', age: 24, position: 'MID', specificRole: 'MC', overall: 82, stamina: 95, form: 8.3, marketValue: 45000000, wage: 28000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 76, passing: 80, defending: 80, physical: 84 }, isStarting: false },
      { id: 'atm-mendoza', name: 'Rodrigo Mendoza', age: 19, position: 'MID', specificRole: 'MC', overall: 72, stamina: 84, form: 7.5, marketValue: 5000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 74, shooting: 65, passing: 74, defending: 65, physical: 68 }, isStarting: false },
      // Forvetler
      { id: 'atm-alvarez', name: 'Julián Alvarez', age: 24, position: 'FW', specificRole: 'ST', overall: 85, stamina: 93, form: 8.6, marketValue: 90000000, wage: 35000, nationality: 'Arjantin', attributes: { pace: 85, shooting: 85, passing: 80, defending: 50, physical: 80 }, isStarting: true },
      { id: 'atm-sorloth', name: 'Alexander Sørloth', age: 28, position: 'FW', specificRole: 'ST', overall: 82, stamina: 88, form: 8.1, marketValue: 25000000, wage: 20000, nationality: 'Norveç', attributes: { pace: 80, shooting: 83, passing: 68, defending: 38, physical: 88 }, isStarting: true },
      { id: 'atm-martin', name: 'Carlos Martín', age: 22, position: 'FW', specificRole: 'ST', overall: 74, stamina: 85, form: 7.6, marketValue: 6000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 78, shooting: 74, passing: 66, defending: 35, physical: 72 }, isStarting: false }
    ]
  },

  // 4. Real Sociedad (Updated per Screenshots)
  {
    id: 'real-sociedad',
    name: 'Real Sociedad',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Anoeta Stadium',
    manager: 'Pellegrino Matarazzo',
    overall: 82,
    budget: 45000000,
    badgeColor: 'from-blue-600 to-white',
    shortName: 'RSO',
    players: [
      // Kaleciler
      { id: 'rso-remiro', name: 'Álex Remiro', age: 29, position: 'GK', specificRole: 'GK', overall: 83, stamina: 90, form: 8.2, marketValue: 25000000, wage: 18000, nationality: 'İspanya', attributes: { pace: 50, shooting: 15, passing: 74, defending: 83, physical: 78 }, isStarting: true },
      { id: 'rso-marrero', name: 'Unai Marrero', age: 23, position: 'GK', specificRole: 'GK', overall: 74, stamina: 85, form: 7.6, marketValue: 4000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 48, shooting: 15, passing: 68, defending: 74, physical: 74 }, isStarting: false },
      // Defanslar
      { id: 'rso-aramburu', name: 'Jon Aramburu', age: 22, position: 'DEF', specificRole: 'DR', overall: 78, stamina: 90, form: 8.1, marketValue: 12000000, wage: 12000, nationality: 'Venezuela', attributes: { pace: 82, shooting: 50, passing: 72, defending: 76, physical: 78 }, isStarting: true },
      { id: 'rso-sgomez', name: 'Sergio Gómez', age: 23, position: 'DEF', specificRole: 'DL', overall: 79, stamina: 89, form: 8.1, marketValue: 18000000, wage: 15000, nationality: 'İspanya', attributes: { pace: 82, shooting: 70, passing: 80, defending: 74, physical: 72 }, isStarting: true },
      { id: 'rso-zubeldia', name: 'Igor Zubeldia', age: 27, position: 'DEF', specificRole: 'DC', overall: 81, stamina: 89, form: 8.0, marketValue: 20000000, wage: 16000, nationality: 'İspanya', attributes: { pace: 72, shooting: 40, passing: 72, defending: 82, physical: 81 }, isStarting: true },
      { id: 'rso-pacheco', name: 'Jon Pacheco', age: 23, position: 'DEF', specificRole: 'DC', overall: 78, stamina: 88, form: 7.9, marketValue: 15000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 70, shooting: 38, passing: 72, defending: 78, physical: 78 }, isStarting: true },
      { id: 'rso-odriozola', name: 'Álvaro Odriozola', age: 28, position: 'DEF', specificRole: 'DR', overall: 76, stamina: 85, form: 7.5, marketValue: 6000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 85, shooting: 52, passing: 70, defending: 73, physical: 70 }, isStarting: false, isInjured: true, injuryType: 'Ön çapraz bağ', injuryWeeksLeft: 6 },
      { id: 'rso-martin', name: 'Jon Martin', age: 18, position: 'DEF', specificRole: 'DC', overall: 72, stamina: 84, form: 7.5, marketValue: 5000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 70, shooting: 35, passing: 66, defending: 72, physical: 74 }, isStarting: false },
      { id: 'rso-kita', name: 'Kazunari Kita', age: 19, position: 'DEF', specificRole: 'DC', overall: 71, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'Japonya', attributes: { pace: 68, shooting: 35, passing: 64, defending: 71, physical: 72 }, isStarting: false },
      { id: 'rso-munoz', name: 'Aihen Muñoz', age: 26, position: 'DEF', specificRole: 'DL', overall: 77, stamina: 88, form: 7.8, marketValue: 10000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 80, shooting: 50, passing: 72, defending: 75, physical: 74 }, isStarting: false },
      { id: 'rso-jlopez', name: 'Javi López', age: 22, position: 'DEF', specificRole: 'DL', overall: 76, stamina: 88, form: 7.7, marketValue: 8000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 82, shooting: 50, passing: 70, defending: 74, physical: 72 }, isStarting: false },
      { id: 'rso-ruperez', name: 'Iñaki Rupérez', age: 21, position: 'DEF', specificRole: 'DR', overall: 71, stamina: 84, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 76, shooting: 45, passing: 66, defending: 70, physical: 70 }, isStarting: false },
      // Orta Sahalar
      { id: 'rso-kubo', name: 'Takefusa Kubo', age: 23, position: 'FW', specificRole: 'RW', overall: 83, stamina: 91, form: 8.5, marketValue: 50000000, wage: 22000, nationality: 'Japonya', attributes: { pace: 88, shooting: 78, passing: 82, defending: 40, physical: 65 }, isStarting: true },
      { id: 'rso-sucic', name: 'Luka Sučić', age: 21, position: 'MID', specificRole: 'AM', overall: 79, stamina: 89, form: 8.1, marketValue: 20000000, wage: 15000, nationality: 'Hırvatistan', attributes: { pace: 76, shooting: 76, passing: 81, defending: 60, physical: 74 }, isStarting: true },
      { id: 'rso-guedes', name: 'Gonçalo Guedes', age: 27, position: 'FW', specificRole: 'LW', overall: 80, stamina: 88, form: 8.0, marketValue: 22000000, wage: 20000, nationality: 'Portekiz', attributes: { pace: 86, shooting: 79, passing: 78, defending: 42, physical: 74 }, isStarting: true },
      { id: 'rso-zakharyan', name: 'Arsen Zakharyan', age: 21, position: 'MID', specificRole: 'MC', overall: 78, stamina: 88, form: 7.9, marketValue: 15000000, wage: 14000, nationality: 'Rusya', attributes: { pace: 76, shooting: 75, passing: 80, defending: 55, physical: 70 }, isStarting: false },
      { id: 'rso-herrera', name: 'Yangel Herrera', age: 26, position: 'MID', specificRole: 'MC', overall: 80, stamina: 91, form: 8.1, marketValue: 20000000, wage: 18000, nationality: 'Venezuela', attributes: { pace: 74, shooting: 72, passing: 78, defending: 78, physical: 82 }, isStarting: false },
      { id: 'rso-soler', name: 'Carlos Soler', age: 27, position: 'MID', specificRole: 'MC', overall: 80, stamina: 88, form: 8.0, marketValue: 20000000, wage: 20000, nationality: 'İspanya', attributes: { pace: 75, shooting: 78, passing: 82, defending: 68, physical: 72 }, isStarting: false },
      { id: 'rso-barrenetxea', name: 'Ander Barrenetxea', age: 22, position: 'FW', specificRole: 'LW', overall: 78, stamina: 88, form: 8.0, marketValue: 18000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 84, shooting: 76, passing: 76, defending: 42, physical: 68 }, isStarting: false },
      { id: 'rso-turrientes', name: 'Beñat Turrientes', age: 22, position: 'MID', specificRole: 'MC', overall: 76, stamina: 88, form: 7.8, marketValue: 10000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 72, shooting: 68, passing: 78, defending: 72, physical: 72 }, isStarting: false },
      { id: 'rso-gorrotxategi', name: 'Jon Gorrotxategi', age: 22, position: 'MID', specificRole: 'DM', overall: 74, stamina: 86, form: 7.6, marketValue: 6000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 70, shooting: 62, passing: 75, defending: 74, physical: 74 }, isStarting: false },
      { id: 'rso-marin', name: 'Pablo Marín', age: 21, position: 'MID', specificRole: 'MC', overall: 74, stamina: 86, form: 7.6, marketValue: 6000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 74, shooting: 68, passing: 76, defending: 55, physical: 66 }, isStarting: false },
      { id: 'rso-goti', name: 'Mikel Goti', age: 22, position: 'MID', specificRole: 'AM', overall: 72, stamina: 84, form: 7.5, marketValue: 4000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 72, shooting: 68, passing: 74, defending: 50, physical: 66 }, isStarting: false },
      // Forvetler
      { id: 'rso-oyarzabal', name: 'Mikel Oyarzabal', age: 27, position: 'FW', specificRole: 'ST', overall: 83, stamina: 91, form: 8.4, marketValue: 45000000, wage: 28000, nationality: 'İspanya', attributes: { pace: 80, shooting: 84, passing: 82, defending: 50, physical: 76 }, isStarting: true },
      { id: 'rso-oskarsson', name: 'Orri Óskarsson', age: 20, position: 'FW', specificRole: 'ST', overall: 76, stamina: 88, form: 7.8, marketValue: 12000000, wage: 10000, nationality: 'İslanda', attributes: { pace: 80, shooting: 78, passing: 66, defending: 35, physical: 78 }, isStarting: false },
    ]
  },

  // 5. Athletic Bilbao (Updated per User Request)
  {
    id: 'athletic-bilbao',
    name: 'Athletic Bilbao',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'San Mamés',
    manager: 'Ernesto Valverde',
    overall: 82,
    budget: 40000000,
    badgeColor: 'from-red-600 to-white',
    shortName: 'ATH',
    players: [
      // Kaleciler
      { id: 'ath-simon', name: 'Unai Simón', age: 27, position: 'GK', specificRole: 'GK', overall: 84, stamina: 90, form: 8.3, marketValue: 30000000, wage: 22000, nationality: 'İspanya', attributes: { pace: 50, shooting: 15, passing: 76, defending: 84, physical: 80 }, isStarting: true },
      { id: 'ath-padilla', name: 'Álex Padilla', age: 21, position: 'GK', specificRole: 'GK', overall: 74, stamina: 85, form: 7.7, marketValue: 5000000, wage: 8000, nationality: 'Meksika', attributes: { pace: 48, shooting: 15, passing: 68, defending: 74, physical: 74 }, isStarting: false },
      { id: 'ath-agirrezabala', name: 'Julen Agirrezabala', age: 23, position: 'GK', specificRole: 'GK', overall: 78, stamina: 88, form: 8.0, marketValue: 12000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 50, shooting: 15, passing: 72, defending: 78, physical: 76 }, isStarting: false },
      // Defanslar
      { id: 'ath-nunez', name: 'Unai Núñez', age: 27, position: 'DEF', specificRole: 'DC', overall: 78, stamina: 88, form: 8.0, marketValue: 12000000, wage: 18000, nationality: 'İspanya', attributes: { pace: 70, shooting: 38, passing: 68, defending: 80, physical: 82 }, isStarting: true },
      { id: 'ath-vivian', name: 'Dani Vivian', age: 25, position: 'DEF', specificRole: 'DC', overall: 82, stamina: 91, form: 8.2, marketValue: 30000000, wage: 18000, nationality: 'İspanya', attributes: { pace: 76, shooting: 40, passing: 68, defending: 83, physical: 85 }, isStarting: true },
      { id: 'ath-boiro', name: 'Adama Boiro', age: 22, position: 'DEF', specificRole: 'DL', overall: 74, stamina: 86, form: 7.6, marketValue: 6000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 82, shooting: 48, passing: 68, defending: 72, physical: 74 }, isStarting: false },
      { id: 'ath-yuri', name: 'Yuri Berchiche', age: 34, position: 'DEF', specificRole: 'DL', overall: 78, stamina: 84, form: 7.8, marketValue: 4000000, wage: 16000, nationality: 'İspanya', attributes: { pace: 78, shooting: 65, passing: 74, defending: 77, physical: 80 }, isStarting: true },
      { id: 'ath-paredes', name: 'Aitor Paredes', age: 24, position: 'DEF', specificRole: 'DC', overall: 79, stamina: 88, form: 8.0, marketValue: 18000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 72, shooting: 38, passing: 66, defending: 79, physical: 80 }, isStarting: false },
      { id: 'ath-yeray', name: 'Yeray Álvarez', age: 29, position: 'DEF', specificRole: 'DC', overall: 79, stamina: 86, form: 7.8, marketValue: 12000000, wage: 16000, nationality: 'İspanya', attributes: { pace: 70, shooting: 38, passing: 65, defending: 80, physical: 81 }, isStarting: false },
      { id: 'ath-areso', name: 'Jesús Areso', age: 25, position: 'DEF', specificRole: 'DR', overall: 77, stamina: 89, form: 7.9, marketValue: 10000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 84, shooting: 52, passing: 72, defending: 74, physical: 76 }, isStarting: true },
      { id: 'ath-gorosabel', name: 'Andoni Gorosabel', age: 28, position: 'DEF', specificRole: 'DR', overall: 76, stamina: 86, form: 7.7, marketValue: 8000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 78, shooting: 48, passing: 70, defending: 74, physical: 72 }, isStarting: false },
      { id: 'ath-rincon', name: 'Hugo Rincón', age: 21, position: 'DEF', specificRole: 'DR', overall: 72, stamina: 84, form: 7.5, marketValue: 4000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 80, shooting: 45, passing: 66, defending: 70, physical: 70 }, isStarting: false },
      { id: 'ath-egiluz', name: 'Unai Egiluz', age: 22, position: 'DEF', specificRole: 'DC', overall: 71, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 68, shooting: 35, passing: 62, defending: 71, physical: 74 }, isStarting: false, isInjured: true, injuryType: 'Çapraz bağ', injuryWeeksLeft: 6 },
      // Orta Sahalar
      { id: 'ath-nicowilliams', name: 'Nico Williams', age: 22, position: 'MID', specificRole: 'LW', overall: 85, stamina: 92, form: 8.7, marketValue: 70000000, wage: 30000, nationality: 'İspanya', attributes: { pace: 94, shooting: 80, passing: 82, defending: 45, physical: 73 }, isStarting: true },
      { id: 'ath-inakiwilliams', name: 'Iñaki Williams', age: 30, position: 'MID', specificRole: 'RW', overall: 82, stamina: 95, form: 8.2, marketValue: 25000000, wage: 24000, nationality: 'Gana', attributes: { pace: 92, shooting: 78, passing: 76, defending: 48, physical: 82 }, isStarting: true },
      { id: 'ath-sancet', name: 'Oihan Sancet', age: 24, position: 'MID', specificRole: 'AM', overall: 81, stamina: 89, form: 8.1, marketValue: 35000000, wage: 20000, nationality: 'İspanya', attributes: { pace: 76, shooting: 80, passing: 80, defending: 58, physical: 80 }, isStarting: true, isInjured: true, injuryType: 'Hamstring', injuryWeeksLeft: 2 },
      { id: 'ath-berenguer', name: 'Álex Berenguer', age: 29, position: 'MID', specificRole: 'LW', overall: 79, stamina: 88, form: 8.0, marketValue: 12000000, wage: 16000, nationality: 'İspanya', attributes: { pace: 82, shooting: 76, passing: 78, defending: 45, physical: 70 }, isStarting: false },
      { id: 'ath-jauregizar', name: 'Mikel Jauregizar', age: 20, position: 'MID', specificRole: 'MC', overall: 76, stamina: 88, form: 7.9, marketValue: 10000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 74, shooting: 65, passing: 78, defending: 72, physical: 72 }, isStarting: true },
      { id: 'ath-galarreta', name: 'Íñigo Ruiz de Galarreta', age: 31, position: 'MID', specificRole: 'MC', overall: 79, stamina: 88, form: 8.0, marketValue: 10000000, wage: 15000, nationality: 'İspanya', attributes: { pace: 70, shooting: 68, passing: 82, defending: 75, physical: 72 }, isStarting: true },
      { id: 'ath-navarro', name: 'Robert Navarro', age: 22, position: 'MID', specificRole: 'LW', overall: 76, stamina: 86, form: 7.8, marketValue: 10000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 82, shooting: 74, passing: 76, defending: 40, physical: 66 }, isStarting: false },
      { id: 'ath-rego', name: 'Alejandro Rego Mora', age: 21, position: 'MID', specificRole: 'MC', overall: 72, stamina: 84, form: 7.5, marketValue: 4000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 72, shooting: 62, passing: 74, defending: 68, physical: 70 }, isStarting: false },
      { id: 'ath-prados', name: 'Beñat Prados', age: 23, position: 'MID', specificRole: 'MC', overall: 78, stamina: 90, form: 8.0, marketValue: 15000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 76, shooting: 68, passing: 78, defending: 76, physical: 76 }, isStarting: false },
      { id: 'ath-canales', name: 'Peio Canales', age: 19, position: 'MID', specificRole: 'AM', overall: 72, stamina: 84, form: 7.5, marketValue: 5000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 74, shooting: 68, passing: 75, defending: 48, physical: 66 }, isStarting: false },
      { id: 'ath-selton', name: 'Selton Sanchez', age: 18, position: 'MID', specificRole: 'MC', overall: 70, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 72, shooting: 62, passing: 72, defending: 65, physical: 68 }, isStarting: false },
      { id: 'ath-vesga', name: 'Mikel Vesga', age: 31, position: 'MID', specificRole: 'MC', overall: 76, stamina: 86, form: 7.6, marketValue: 6000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 64, shooting: 65, passing: 76, defending: 76, physical: 80 }, isStarting: false },
      { id: 'ath-gerenabarrena', name: 'Beñat Gerenabarrena', age: 21, position: 'MID', specificRole: 'MC', overall: 71, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 70, shooting: 62, passing: 72, defending: 68, physical: 70 }, isStarting: false },
      // Forvetler
      { id: 'ath-sannadi', name: 'Maroan Sannadi', age: 23, position: 'FW', specificRole: 'ST', overall: 74, stamina: 85, form: 7.6, marketValue: 6000000, wage: 8000, nationality: 'Fas', attributes: { pace: 78, shooting: 74, passing: 62, defending: 35, physical: 78 }, isStarting: false },
      { id: 'ath-guruzeta', name: 'Gorka Guruzeta', age: 27, position: 'FW', specificRole: 'ST', overall: 79, stamina: 88, form: 8.1, marketValue: 18000000, wage: 16000, nationality: 'İspanya', attributes: { pace: 78, shooting: 80, passing: 72, defending: 40, physical: 78 }, isStarting: true },
      { id: 'ath-djalo', name: 'Álvaro Djaló', age: 24, position: 'FW', specificRole: 'LW', overall: 78, stamina: 88, form: 8.0, marketValue: 15000000, wage: 14000, nationality: 'Gana', attributes: { pace: 88, shooting: 76, passing: 74, defending: 40, physical: 70 }, isStarting: false }
    ]
  },

  // 6. Villarreal CF (Updated per Screenshot)
  {
    id: 'villarreal',
    name: 'Villarreal CF',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Estadio de la Cerámica',
    manager: 'Iñigo Pérez',
    overall: 81,
    budget: 35000000,
    badgeColor: 'from-amber-400 to-blue-700',
    shortName: 'VIL',
    players: [
      // Kaleciler
      { id: 'vil-junior', name: 'Luiz Júnior', age: 23, position: 'GK', specificRole: 'GK', overall: 79, stamina: 88, form: 8.0, marketValue: 15000000, wage: 15000, nationality: 'Brezilya', attributes: { pace: 50, shooting: 15, passing: 70, defending: 79, physical: 78 }, isStarting: true },
      // Defanslar
      { id: 'vil-foyth', name: 'Juan Foyth', age: 26, position: 'DEF', specificRole: 'DR', overall: 80, stamina: 90, form: 8.1, marketValue: 22000000, wage: 18000, nationality: 'Arjantin', attributes: { pace: 78, shooting: 50, passing: 74, defending: 81, physical: 80 }, isStarting: true },
      { id: 'vil-mourino', name: 'Santiago Mouriño', age: 22, position: 'DEF', specificRole: 'DR', overall: 75, stamina: 86, form: 7.7, marketValue: 8000000, wage: 10000, nationality: 'Uruguay', attributes: { pace: 76, shooting: 45, passing: 68, defending: 75, physical: 78 }, isStarting: false },
      { id: 'vil-kambwala', name: 'Willy Kambwala', age: 19, position: 'DEF', specificRole: 'DC', overall: 74, stamina: 85, form: 7.6, marketValue: 8000000, wage: 10000, nationality: 'Kongo', attributes: { pace: 74, shooting: 38, passing: 65, defending: 74, physical: 78 }, isStarting: false },
      { id: 'vil-freeman', name: 'Alexander Freeman', age: 20, position: 'DEF', specificRole: 'DR', overall: 71, stamina: 84, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'Amerika B. D.', attributes: { pace: 78, shooting: 48, passing: 66, defending: 70, physical: 70 }, isStarting: false },
      { id: 'vil-romero', name: 'Carlos Romero', age: 22, position: 'DEF', specificRole: 'DL', overall: 75, stamina: 86, form: 7.7, marketValue: 6000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 80, shooting: 50, passing: 70, defending: 73, physical: 72 }, isStarting: false },
      { id: 'vil-costa', name: 'Logan Costa', age: 23, position: 'DEF', specificRole: 'DC', overall: 77, stamina: 88, form: 7.8, marketValue: 12000000, wage: 12000, nationality: 'Yeşil Burun Adaları', attributes: { pace: 72, shooting: 38, passing: 68, defending: 77, physical: 82 }, isStarting: true },
      { id: 'vil-cardona', name: 'Sergi Cardona', age: 25, position: 'DEF', specificRole: 'DL', overall: 77, stamina: 89, form: 7.9, marketValue: 10000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 80, shooting: 52, passing: 72, defending: 76, physical: 75 }, isStarting: true },
      { id: 'vil-pnavarro', name: 'Pau Navarro', age: 19, position: 'DEF', specificRole: 'DC', overall: 72, stamina: 84, form: 7.5, marketValue: 4000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 70, shooting: 35, passing: 65, defending: 72, physical: 72 }, isStarting: false },
      { id: 'vil-diallo', name: 'Moussa Diallo', age: 20, position: 'DEF', specificRole: 'DC', overall: 70, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'Senegal', attributes: { pace: 68, shooting: 35, passing: 62, defending: 70, physical: 74 }, isStarting: false },
      // Orta Sahalar
      { id: 'vil-pgueye', name: 'Pape Gueye', age: 25, position: 'MID', specificRole: 'MC', overall: 78, stamina: 90, form: 8.0, marketValue: 15000000, wage: 14000, nationality: 'Senegal', attributes: { pace: 74, shooting: 68, passing: 78, defending: 78, physical: 82 }, isStarting: true },
      { id: 'vil-akhomach', name: 'Ilias Akhomach', age: 20, position: 'MID', specificRole: 'RW', overall: 76, stamina: 88, form: 7.8, marketValue: 12000000, wage: 10000, nationality: 'Fas', attributes: { pace: 84, shooting: 72, passing: 76, defending: 38, physical: 65 }, isStarting: false },
      { id: 'vil-buchanan', name: 'Tajon Buchanan', age: 25, position: 'MID', specificRole: 'MR', overall: 77, stamina: 90, form: 7.9, marketValue: 12000000, wage: 12000, nationality: 'Kanada', attributes: { pace: 88, shooting: 70, passing: 74, defending: 62, physical: 72 }, isStarting: true },
      { id: 'vil-moleiro', name: 'Alberto Moleiro', age: 20, position: 'MID', specificRole: 'ML', overall: 78, stamina: 89, form: 8.1, marketValue: 20000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 80, shooting: 75, passing: 81, defending: 45, physical: 66 }, isStarting: true },
      { id: 'vil-diatta', name: 'Alassane Diatta', age: 25, position: 'MID', specificRole: 'MC', overall: 74, stamina: 86, form: 7.6, marketValue: 6000000, wage: 8000, nationality: 'Senegal', attributes: { pace: 76, shooting: 65, passing: 74, defending: 68, physical: 72 }, isStarting: false },
      { id: 'vil-tfernandez', name: 'Thiago Fernández', age: 20, position: 'MID', specificRole: 'LW', overall: 74, stamina: 85, form: 7.6, marketValue: 8000000, wage: 8000, nationality: 'Arjantin', attributes: { pace: 82, shooting: 72, passing: 72, defending: 35, physical: 65 }, isStarting: false },
      { id: 'vil-comesana', name: 'Santi Comesaña', age: 27, position: 'MID', specificRole: 'MC', overall: 78, stamina: 90, form: 7.9, marketValue: 12000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 72, shooting: 70, passing: 78, defending: 76, physical: 78 }, isStarting: true },
      { id: 'vil-macia', name: 'Carlos Maciá', age: 18, position: 'MID', specificRole: 'MC', overall: 70, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 70, shooting: 62, passing: 72, defending: 62, physical: 64 }, isStarting: false },
      // Forvetler
      { id: 'vil-pepe', name: 'Nicolas Pépé', age: 29, position: 'FW', specificRole: 'ST', overall: 79, stamina: 88, form: 8.1, marketValue: 18000000, wage: 18000, nationality: 'Fildişi Sahili', attributes: { pace: 86, shooting: 78, passing: 76, defending: 38, physical: 72 }, isStarting: true },
      { id: 'vil-barry', name: 'Thierno Barry', age: 21, position: 'FW', specificRole: 'ST', overall: 78, stamina: 90, form: 8.2, marketValue: 18000000, wage: 12000, nationality: 'Fransa', attributes: { pace: 84, shooting: 80, passing: 68, defending: 36, physical: 84 }, isStarting: true },
      { id: 'vil-gmoreno', name: 'Gerard Moreno', age: 32, position: 'FW', specificRole: 'ST', overall: 82, stamina: 84, form: 8.1, marketValue: 18000000, wage: 25000, nationality: 'İspanya', attributes: { pace: 76, shooting: 84, passing: 80, defending: 42, physical: 72 }, isStarting: false },
      { id: 'vil-aperez', name: 'Ayoze Pérez', age: 31, position: 'FW', specificRole: 'ST', overall: 81, stamina: 88, form: 8.3, marketValue: 15000000, wage: 18000, nationality: 'İspanya', attributes: { pace: 80, shooting: 82, passing: 76, defending: 42, physical: 72 }, isStarting: false },
      { id: 'vil-oluwaseyi', name: 'Tani Oluwaseyi', age: 24, position: 'FW', specificRole: 'ST', overall: 75, stamina: 88, form: 7.7, marketValue: 6000000, wage: 8000, nationality: 'Kanada', attributes: { pace: 84, shooting: 75, passing: 64, defending: 35, physical: 78 }, isStarting: false },
      { id: 'vil-fores', name: 'Álex Forés', age: 23, position: 'FW', specificRole: 'ST', overall: 73, stamina: 85, form: 7.5, marketValue: 4000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 78, shooting: 74, passing: 62, defending: 32, physical: 72 }, isStarting: false },
      { id: 'vil-hlopez', name: 'Hugo López', age: 19, position: 'FW', specificRole: 'ST', overall: 70, stamina: 82, form: 7.4, marketValue: 2500000, wage: 5000, nationality: 'İspanya', attributes: { pace: 76, shooting: 70, passing: 60, defending: 30, physical: 70 }, isStarting: false }
    ]
  },

  // 7. Sevilla FC (Updated per Screenshot)
  {
    id: 'sevilla',
    name: 'Sevilla FC',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Ramon Sanchez-Pizjuan',
    manager: 'Luis García',
    overall: 80,
    budget: 30000000,
    badgeColor: 'from-red-700 to-white',
    shortName: 'SEV',
    players: [
      // Kaleciler
      { id: 'sev-gonzalez', name: 'Fran González', age: 19, position: 'GK', specificRole: 'GK', overall: 73, stamina: 85, form: 7.6, marketValue: 4000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 48, shooting: 15, passing: 65, defending: 73, physical: 74 }, isStarting: false },
      { id: 'sev-vlachodimos', name: 'Odysseas Vlachodimos', age: 30, position: 'GK', specificRole: 'GK', overall: 78, stamina: 88, form: 7.9, marketValue: 8000000, wage: 16000, nationality: 'Yunanistan', attributes: { pace: 50, shooting: 15, passing: 70, defending: 78, physical: 76 }, isStarting: true },
      // Defanslar
      { id: 'sev-barco', name: 'Valentín Barco', age: 20, position: 'DEF', specificRole: 'DL', overall: 77, stamina: 90, form: 8.0, marketValue: 14000000, wage: 12000, nationality: 'Arjantin', attributes: { pace: 84, shooting: 62, passing: 78, defending: 74, physical: 72 }, isStarting: true },
      { id: 'sev-marcao', name: 'Marcão', age: 28, position: 'DEF', specificRole: 'DC', overall: 77, stamina: 80, form: 7.5, marketValue: 8000000, wage: 15000, nationality: 'Brezilya', attributes: { pace: 62, shooting: 38, passing: 65, defending: 78, physical: 84 }, isStarting: false, isInjured: true, injuryType: 'Kas', injuryWeeksLeft: 3 },
      { id: 'sev-carmona', name: 'José Ángel Carmona', age: 22, position: 'DEF', specificRole: 'DR', overall: 76, stamina: 88, form: 7.8, marketValue: 10000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 80, shooting: 52, passing: 70, defending: 75, physical: 74 }, isStarting: true },
      { id: 'sev-salas', name: 'Kike Salas', age: 22, position: 'DEF', specificRole: 'DC', overall: 76, stamina: 88, form: 7.8, marketValue: 10000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 72, shooting: 40, passing: 68, defending: 76, physical: 78 }, isStarting: true },
      { id: 'sev-nianzou', name: 'Tanguy Nianzou', age: 22, position: 'DEF', specificRole: 'DC', overall: 76, stamina: 88, form: 7.7, marketValue: 8000000, wage: 12000, nationality: 'Fransa', attributes: { pace: 72, shooting: 40, passing: 66, defending: 77, physical: 80 }, isStarting: true },
      { id: 'sev-pedrosa', name: 'Adrià Pedrosa', age: 26, position: 'DEF', specificRole: 'DL', overall: 76, stamina: 88, form: 7.7, marketValue: 8000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 84, shooting: 55, passing: 72, defending: 73, physical: 72 }, isStarting: false },
      { id: 'sev-gattoni', name: 'Federico Gattoni', age: 25, position: 'DEF', specificRole: 'DC', overall: 74, stamina: 85, form: 7.5, marketValue: 5000000, wage: 8000, nationality: 'Arjantin', attributes: { pace: 68, shooting: 38, passing: 64, defending: 74, physical: 76 }, isStarting: false },
      { id: 'sev-jdiaz', name: 'Julio Díaz', age: 19, position: 'DEF', specificRole: 'DL', overall: 71, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 76, shooting: 45, passing: 66, defending: 70, physical: 68 }, isStarting: false },
      { id: 'sev-cardoso', name: 'Fábio Cardoso', age: 30, position: 'DEF', specificRole: 'DC', overall: 75, stamina: 84, form: 7.5, marketValue: 5000000, wage: 10000, nationality: 'Portekiz', attributes: { pace: 64, shooting: 35, passing: 62, defending: 75, physical: 78 }, isStarting: false },
      { id: 'sev-castrin', name: 'Andres Castrin', age: 21, position: 'DEF', specificRole: 'DC', overall: 71, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 68, shooting: 35, passing: 62, defending: 71, physical: 72 }, isStarting: false },
      // Orta Sahalar
      { id: 'sev-vargas', name: 'Rubén Vargas', age: 26, position: 'MID', specificRole: 'LW', overall: 78, stamina: 89, form: 8.0, marketValue: 15000000, wage: 15000, nationality: 'İsviçre', attributes: { pace: 84, shooting: 75, passing: 76, defending: 45, physical: 70 }, isStarting: true },
      { id: 'sev-sow', name: 'Djibril Sow', age: 27, position: 'MID', specificRole: 'MC', overall: 78, stamina: 91, form: 8.0, marketValue: 14000000, wage: 16000, nationality: 'İsviçre', attributes: { pace: 76, shooting: 68, passing: 78, defending: 76, physical: 78 }, isStarting: true },
      { id: 'sev-agoume', name: 'Lucien Agoumé', age: 22, position: 'MID', specificRole: 'MC', overall: 76, stamina: 88, form: 7.8, marketValue: 10000000, wage: 10000, nationality: 'Fransa', attributes: { pace: 72, shooting: 64, passing: 76, defending: 76, physical: 80 }, isStarting: true },
      { id: 'sev-peque', name: 'Peque Fernández', age: 22, position: 'MID', specificRole: 'AM', overall: 76, stamina: 88, form: 7.9, marketValue: 10000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 78, shooting: 74, passing: 78, defending: 45, physical: 66 }, isStarting: false },
      { id: 'sev-jordan', name: 'Joan Jordán', age: 30, position: 'MID', specificRole: 'MC', overall: 76, stamina: 86, form: 7.6, marketValue: 8000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 68, shooting: 72, passing: 80, defending: 72, physical: 72 }, isStarting: false },
      { id: 'sev-oso', name: 'Oso', age: 21, position: 'DEF', specificRole: 'DL', overall: 72, stamina: 84, form: 7.5, marketValue: 4000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 76, shooting: 48, passing: 68, defending: 71, physical: 70 }, isStarting: false },
      { id: 'sev-guridi', name: 'Jon Guridi', age: 29, position: 'MID', specificRole: 'AM', overall: 76, stamina: 88, form: 7.7, marketValue: 8000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 74, shooting: 72, passing: 77, defending: 65, physical: 72 }, isStarting: false },
      { id: 'sev-bueno', name: 'Manu Bueno', age: 20, position: 'MID', specificRole: 'MC', overall: 72, stamina: 84, form: 7.5, marketValue: 4000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 72, shooting: 64, passing: 74, defending: 70, physical: 70 }, isStarting: false },
      // Forvetler
      { id: 'sev-ejuke', name: 'Chidera Ejuke', age: 26, position: 'FW', specificRole: 'LW', overall: 78, stamina: 90, form: 8.1, marketValue: 12000000, wage: 14000, nationality: 'Nijerya', attributes: { pace: 90, shooting: 74, passing: 74, defending: 38, physical: 70 }, isStarting: true },
      { id: 'sev-iromero', name: 'Isaac Romero', age: 24, position: 'FW', specificRole: 'ST', overall: 78, stamina: 89, form: 8.0, marketValue: 12000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 82, shooting: 78, passing: 68, defending: 40, physical: 78 }, isStarting: true },
      { id: 'sev-agonzalez', name: 'Alfon González', age: 25, position: 'FW', specificRole: 'LW', overall: 74, stamina: 86, form: 7.6, marketValue: 5000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 80, shooting: 72, passing: 72, defending: 38, physical: 68 }, isStarting: false },
      { id: 'sev-acuna', name: 'Jesús Acuña', age: 20, position: 'FW', specificRole: 'ST', overall: 71, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 76, shooting: 72, passing: 62, defending: 32, physical: 70 }, isStarting: false }
    ]
  },

  // 8. Real Betis (Updated per Screenshot)
  {
    id: 'real-betis',
    name: 'Real Betis',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Benito Villamarín',
    manager: 'Manuel Pellegrini',
    overall: 80,
    budget: 28000000,
    badgeColor: 'from-green-600 to-white',
    shortName: 'BET',
    players: [
      // Kaleciler
      { id: 'bet-adrian', name: 'Adrián', age: 37, position: 'GK', specificRole: 'GK', overall: 75, stamina: 80, form: 7.6, marketValue: 1500000, wage: 8000, nationality: 'İspanya', attributes: { pace: 45, shooting: 15, passing: 68, defending: 75, physical: 72 }, isStarting: false },
      { id: 'bet-valles', name: 'Álvaro Valles', age: 27, position: 'GK', specificRole: 'GK', overall: 79, stamina: 88, form: 8.1, marketValue: 12000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 50, shooting: 15, passing: 72, defending: 79, physical: 76 }, isStarting: true },
      { id: 'bet-conde', name: 'Diego Conde', age: 25, position: 'GK', specificRole: 'GK', overall: 77, stamina: 85, form: 7.7, marketValue: 6000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 48, shooting: 15, passing: 68, defending: 77, physical: 74 }, isStarting: false, isInjured: true, injuryType: 'Omuz', injuryWeeksLeft: 3 },
      // Defanslar
      { id: 'bet-perraud', name: 'Romain Perraud', age: 26, position: 'DEF', specificRole: 'DL', overall: 78, stamina: 90, form: 8.0, marketValue: 10000000, wage: 16000, nationality: 'Fransa', attributes: { pace: 84, shooting: 60, passing: 74, defending: 77, physical: 76 }, isStarting: true },
      { id: 'bet-bellerin', name: 'Héctor Bellerín', age: 29, position: 'DEF', specificRole: 'DR', overall: 77, stamina: 86, form: 7.7, marketValue: 8000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 82, shooting: 50, passing: 72, defending: 74, physical: 70 }, isStarting: true },
      { id: 'bet-natan', name: 'Natan', age: 23, position: 'DEF', specificRole: 'DC', overall: 77, stamina: 88, form: 7.8, marketValue: 10000000, wage: 12000, nationality: 'Brezilya', attributes: { pace: 72, shooting: 38, passing: 66, defending: 77, physical: 80 }, isStarting: true },
      { id: 'bet-firpo', name: 'Junior Firpo', age: 27, position: 'DEF', specificRole: 'DL', overall: 76, stamina: 84, form: 7.6, marketValue: 8000000, wage: 12000, nationality: 'Dominik Cum.', attributes: { pace: 80, shooting: 52, passing: 70, defending: 74, physical: 74 }, isStarting: false, isInjured: true, injuryType: 'Kas', injuryWeeksLeft: 2 },
      { id: 'bet-vgomez', name: 'Valentín Gómez', age: 21, position: 'DEF', specificRole: 'DC', overall: 76, stamina: 88, form: 7.8, marketValue: 12000000, wage: 10000, nationality: 'Arjantin', attributes: { pace: 74, shooting: 40, passing: 68, defending: 76, physical: 78 }, isStarting: true },
      { id: 'bet-bartra', name: 'Marc Bartra', age: 33, position: 'DEF', specificRole: 'DC', overall: 77, stamina: 82, form: 7.6, marketValue: 3000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 68, shooting: 45, passing: 74, defending: 77, physical: 74 }, isStarting: false },
      { id: 'bet-llorente', name: 'Diego Llorente', age: 30, position: 'DEF', specificRole: 'DC', overall: 77, stamina: 85, form: 7.7, marketValue: 8000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 68, shooting: 42, passing: 70, defending: 77, physical: 78 }, isStarting: false },
      { id: 'bet-ruibal', name: 'Aitor Ruibal', age: 28, position: 'DEF', specificRole: 'DR', overall: 76, stamina: 91, form: 7.8, marketValue: 8000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 80, shooting: 65, passing: 72, defending: 73, physical: 76 }, isStarting: false },
      { id: 'bet-ortiz', name: 'Angel Ortiz', age: 20, position: 'DEF', specificRole: 'DR', overall: 71, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 78, shooting: 45, passing: 66, defending: 70, physical: 68 }, isStarting: false, isInjured: true, injuryType: 'Kas', injuryWeeksLeft: 2 },
      { id: 'bet-nagoran', name: 'Jean Emmanuel N\'Agoran', age: 19, position: 'DEF', specificRole: 'DC', overall: 70, stamina: 82, form: 7.4, marketValue: 2500000, wage: 5000, nationality: 'Fildişi Sahili', attributes: { pace: 70, shooting: 35, passing: 62, defending: 70, physical: 74 }, isStarting: false },
      // Orta Sahalar
      { id: 'bet-antony', name: 'Antony', age: 24, position: 'MID', specificRole: 'RW', overall: 81, stamina: 90, form: 8.3, marketValue: 25000000, wage: 22000, nationality: 'Brezilya', attributes: { pace: 86, shooting: 78, passing: 78, defending: 42, physical: 68 }, isStarting: true },
      { id: 'bet-ezzalzouli', name: 'Abdessamad Ezzalzouli', age: 22, position: 'MID', specificRole: 'LW', overall: 78, stamina: 89, form: 8.0, marketValue: 15000000, wage: 14000, nationality: 'Fas', attributes: { pace: 88, shooting: 74, passing: 72, defending: 38, physical: 70 }, isStarting: true },
      { id: 'bet-isco', name: 'Isco', age: 32, position: 'MID', specificRole: 'AM', overall: 83, stamina: 84, form: 8.5, marketValue: 12000000, wage: 24000, nationality: 'İspanya', attributes: { pace: 70, shooting: 80, passing: 86, defending: 52, physical: 68 }, isStarting: true },
      { id: 'bet-locelso', name: 'Giovani Lo Celso', age: 28, position: 'MID', specificRole: 'AM', overall: 81, stamina: 88, form: 8.2, marketValue: 20000000, wage: 20000, nationality: 'Arjantin', attributes: { pace: 76, shooting: 78, passing: 84, defending: 62, physical: 72 }, isStarting: true },
      { id: 'bet-fidalgo', name: 'Álvaro Fidalgo', age: 27, position: 'MID', specificRole: 'MC', overall: 78, stamina: 90, form: 8.0, marketValue: 12000000, wage: 14000, nationality: 'Meksika', attributes: { pace: 75, shooting: 72, passing: 80, defending: 68, physical: 70 }, isStarting: false },
      { id: 'bet-deossa', name: 'Nelson Deossa', age: 24, position: 'MID', specificRole: 'MC', overall: 76, stamina: 88, form: 7.8, marketValue: 10000000, wage: 10000, nationality: 'Kolombiya', attributes: { pace: 78, shooting: 72, passing: 76, defending: 68, physical: 76 }, isStarting: false },
      { id: 'bet-avila', name: 'Chimy Ávila', age: 30, position: 'FW', specificRole: 'ST', overall: 78, stamina: 88, form: 7.9, marketValue: 6000000, wage: 16000, nationality: 'Arjantin', attributes: { pace: 78, shooting: 80, passing: 70, defending: 45, physical: 82 }, isStarting: false },
      { id: 'bet-fornals', name: 'Pablo Fornals', age: 28, position: 'MID', specificRole: 'MC', overall: 79, stamina: 90, form: 8.1, marketValue: 16000000, wage: 18000, nationality: 'İspanya', attributes: { pace: 74, shooting: 76, passing: 82, defending: 65, physical: 72 }, isStarting: false },
      { id: 'bet-pgarcia', name: 'Pablo García', age: 18, position: 'MID', specificRole: 'RW', overall: 71, stamina: 84, form: 7.5, marketValue: 4000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 78, shooting: 68, passing: 70, defending: 38, physical: 62 }, isStarting: false },
      { id: 'bet-bernal', name: 'Facundo Bernal', age: 21, position: 'MID', specificRole: 'MC', overall: 74, stamina: 86, form: 7.6, marketValue: 6000000, wage: 8000, nationality: 'Uruguay', attributes: { pace: 72, shooting: 64, passing: 75, defending: 72, physical: 74 }, isStarting: false },
      { id: 'bet-roca', name: 'Marc Roca', age: 27, position: 'MID', specificRole: 'MC', overall: 77, stamina: 88, form: 7.8, marketValue: 10000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 68, shooting: 68, passing: 80, defending: 76, physical: 76 }, isStarting: false },
      { id: 'bet-morante', name: 'José Morante', age: 18, position: 'MID', specificRole: 'RW', overall: 70, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 76, shooting: 66, passing: 68, defending: 35, physical: 62 }, isStarting: false },
      { id: 'bet-losada', name: 'Iker Losada', age: 23, position: 'MID', specificRole: 'AM', overall: 75, stamina: 86, form: 7.7, marketValue: 8000000, wage: 9000, nationality: 'İspanya', attributes: { pace: 74, shooting: 74, passing: 76, defending: 48, physical: 66 }, isStarting: false },
      { id: 'bet-samake', name: 'Gnangoro Bouare Samake', age: 18, position: 'MID', specificRole: 'MC', overall: 70, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 72, shooting: 62, passing: 70, defending: 68, physical: 70 }, isStarting: false },
      { id: 'bet-funez', name: 'Rica Fúnez', age: 18, position: 'MID', specificRole: 'MC', overall: 69, stamina: 80, form: 7.3, marketValue: 2500000, wage: 4000, nationality: 'İspanya', attributes: { pace: 70, shooting: 60, passing: 70, defending: 65, physical: 66 }, isStarting: false },
      // Forvetler
      { id: 'bet-cucho', name: 'Cucho Hernández', age: 25, position: 'FW', specificRole: 'ST', overall: 79, stamina: 90, form: 8.2, marketValue: 18000000, wage: 16000, nationality: 'Kolombiya', attributes: { pace: 82, shooting: 80, passing: 72, defending: 40, physical: 78 }, isStarting: true },
      { id: 'bet-petit', name: 'Gonzalo Petit', age: 18, position: 'FW', specificRole: 'ST', overall: 71, stamina: 84, form: 7.5, marketValue: 4000000, wage: 5000, nationality: 'Uruguay', attributes: { pace: 78, shooting: 72, passing: 62, defending: 32, physical: 72 }, isStarting: false }
    ]
  },

  // 9. Valencia CF (Updated per Screenshot)
  {
    id: 'valencia',
    name: 'Valencia CF',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Mestalla',
    manager: 'Carlos Corberán',
    overall: 78,
    budget: 20000000,
    badgeColor: 'from-amber-500 to-black',
    shortName: 'VAL',
    players: [
      // Kaleciler
      { id: 'val-mamardashvili', name: 'Giorgi Mamardashvili', age: 23, position: 'GK', specificRole: 'GK', overall: 84, stamina: 90, form: 8.6, marketValue: 45000000, wage: 20000, nationality: 'Gürcistan', attributes: { pace: 50, shooting: 15, passing: 70, defending: 85, physical: 82 }, isStarting: true },
      { id: 'val-dimitrievski', name: 'Stole Dimitrievski', age: 30, position: 'GK', specificRole: 'GK', overall: 78, stamina: 88, form: 7.9, marketValue: 6000000, wage: 12000, nationality: 'Kuzey Makedonya', attributes: { pace: 48, shooting: 15, passing: 68, defending: 78, physical: 76 }, isStarting: false },
      // Defanslar
      { id: 'val-mosquera', name: 'Cristhian Mosquera', age: 20, position: 'DEF', specificRole: 'DC', overall: 78, stamina: 91, form: 8.1, marketValue: 25000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 78, shooting: 35, passing: 68, defending: 79, physical: 82 }, isStarting: true },
      { id: 'val-tárrega', name: 'César Tárrega', age: 22, position: 'DEF', specificRole: 'DC', overall: 75, stamina: 88, form: 7.7, marketValue: 8000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 72, shooting: 35, passing: 65, defending: 75, physical: 78 }, isStarting: true },
      { id: 'val-gaya', name: 'José Gayà', age: 29, position: 'DEF', specificRole: 'DL', overall: 80, stamina: 88, form: 8.1, marketValue: 20000000, wage: 20000, nationality: 'İspanya', attributes: { pace: 82, shooting: 58, passing: 78, defending: 78, physical: 74 }, isStarting: true },
      { id: 'val-foulquier', name: 'Dimitri Foulquier', age: 31, position: 'DEF', specificRole: 'DR', overall: 76, stamina: 88, form: 7.6, marketValue: 4000000, wage: 12000, nationality: 'Fransa', attributes: { pace: 78, shooting: 45, passing: 68, defending: 75, physical: 80 }, isStarting: true },
      { id: 'val-vazquez', name: 'Jesús Vázquez', age: 21, position: 'DEF', specificRole: 'DL', overall: 74, stamina: 86, form: 7.5, marketValue: 5000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 80, shooting: 50, passing: 68, defending: 72, physical: 70 }, isStarting: false },
      { id: 'val-gasiorowski', name: 'Yarek Gasiorowski', age: 19, position: 'DEF', specificRole: 'DC', overall: 74, stamina: 85, form: 7.6, marketValue: 8000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 70, shooting: 35, passing: 65, defending: 74, physical: 76 }, isStarting: false },
      { id: 'val-rubo', name: 'Rubo Iranzo', age: 21, position: 'DEF', specificRole: 'DC', overall: 71, stamina: 82, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 68, shooting: 35, passing: 62, defending: 71, physical: 72 }, isStarting: false },
      // Orta Sahalar
      { id: 'val-jguerrero', name: 'Javi Guerra', age: 21, position: 'MID', specificRole: 'MC', overall: 78, stamina: 90, form: 8.0, marketValue: 25000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 76, shooting: 74, passing: 80, defending: 72, physical: 78 }, isStarting: true },
      { id: 'val-pepelu', name: 'Pepelu', age: 25, position: 'MID', specificRole: 'MC', overall: 80, stamina: 92, form: 8.2, marketValue: 22000000, wage: 16000, nationality: 'İspanya', attributes: { pace: 70, shooting: 72, passing: 82, defending: 80, physical: 78 }, isStarting: true },
      { id: 'val-barrenechea', name: 'Enzo Barrenechea', age: 23, position: 'MID', specificRole: 'MC', overall: 76, stamina: 88, form: 7.8, marketValue: 10000000, wage: 10000, nationality: 'Arjantin', attributes: { pace: 72, shooting: 65, passing: 76, defending: 76, physical: 78 }, isStarting: false },
      { id: 'val-almeida', name: 'André Almeida', age: 24, position: 'MID', specificRole: 'AM', overall: 77, stamina: 88, form: 7.8, marketValue: 14000000, wage: 14000, nationality: 'Portekiz', attributes: { pace: 74, shooting: 70, passing: 81, defending: 60, physical: 68 }, isStarting: false },
      { id: 'val-lopez', name: 'Diego López', age: 22, position: 'MID', specificRole: 'RW', overall: 77, stamina: 90, form: 8.0, marketValue: 15000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 84, shooting: 74, passing: 74, defending: 45, physical: 68 }, isStarting: true },
      { id: 'val-rioja', name: 'Luis Rioja', age: 30, position: 'MID', specificRole: 'LW', overall: 77, stamina: 88, form: 7.8, marketValue: 8000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 82, shooting: 72, passing: 74, defending: 48, physical: 72 }, isStarting: true },
      { id: 'val-canos', name: 'Sergi Canós', age: 27, position: 'MID', specificRole: 'RW', overall: 75, stamina: 86, form: 7.6, marketValue: 6000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 80, shooting: 72, passing: 72, defending: 42, physical: 70 }, isStarting: false },
      { id: 'val-perez', name: 'Fran Pérez', age: 21, position: 'MID', specificRole: 'RW', overall: 74, stamina: 86, form: 7.6, marketValue: 6000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 82, shooting: 68, passing: 70, defending: 40, physical: 65 }, isStarting: false },
      // Forvetler
      { id: 'val-duro', name: 'Hugo Duro', age: 24, position: 'FW', specificRole: 'ST', overall: 78, stamina: 90, form: 8.0, marketValue: 16000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 80, shooting: 79, passing: 68, defending: 40, physical: 78 }, isStarting: true },
      { id: 'val-mir', name: 'Rafa Mir', age: 27, position: 'FW', specificRole: 'ST', overall: 76, stamina: 86, form: 7.7, marketValue: 8000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 80, shooting: 77, passing: 64, defending: 35, physical: 82 }, isStarting: false },
      { id: 'val-mariz', name: 'Dani Gómez', age: 26, position: 'FW', specificRole: 'ST', overall: 74, stamina: 85, form: 7.5, marketValue: 4000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 78, shooting: 73, passing: 62, defending: 32, physical: 72 }, isStarting: false }
    ]
  },

  // 10. RC Celta de Vigo (Updated per Screenshot)
  {
    id: 'celta-vigo',
    name: 'RC Celta de Vigo',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Abanca-Balaídos',
    manager: 'Claudio Giráldez',
    overall: 78,
    budget: 18000000,
    badgeColor: 'from-sky-400 to-white',
    shortName: 'CEL',
    players: [
      // Kaleciler
      { id: 'cel-guaita', name: 'Vicente Guaita', age: 37, position: 'GK', specificRole: 'GK', overall: 77, stamina: 80, form: 7.7, marketValue: 2000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 45, shooting: 15, passing: 66, defending: 78, physical: 72 }, isStarting: true },
      { id: 'cel-villar', name: 'Iván Villar', age: 27, position: 'GK', specificRole: 'GK', overall: 74, stamina: 85, form: 7.5, marketValue: 3000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 48, shooting: 15, passing: 65, defending: 74, physical: 74 }, isStarting: false },
      // Defanslar
      { id: 'cel-starfelt', name: 'Carl Starfelt', age: 29, position: 'DEF', specificRole: 'DC', overall: 76, stamina: 88, form: 7.7, marketValue: 6000000, wage: 12000, nationality: 'İsveç', attributes: { pace: 70, shooting: 38, passing: 64, defending: 77, physical: 80 }, isStarting: true },
      { id: 'cel-mingueza', name: 'Oscar Mingueza', age: 25, position: 'DEF', specificRole: 'DR', overall: 78, stamina: 90, form: 8.2, marketValue: 12000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 78, shooting: 60, passing: 78, defending: 76, physical: 74 }, isStarting: true },
      { id: 'cel-alvarez', name: 'Hugo Álvarez', age: 21, position: 'DEF', specificRole: 'DL', overall: 76, stamina: 89, form: 8.0, marketValue: 10000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 82, shooting: 68, passing: 76, defending: 72, physical: 70 }, isStarting: true },
      { id: 'cel-jailson', name: 'Jailson', age: 28, position: 'DEF', specificRole: 'DC', overall: 75, stamina: 86, form: 7.6, marketValue: 5000000, wage: 10000, nationality: 'Brezilya', attributes: { pace: 68, shooting: 55, passing: 72, defending: 75, physical: 78 }, isStarting: true },
      { id: 'cel-rabadan', name: 'Marc Vidal', age: 24, position: 'DEF', specificRole: 'DC', overall: 72, stamina: 84, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 68, shooting: 35, passing: 62, defending: 72, physical: 72 }, isStarting: false },
      { id: 'cel-aidoo', name: 'Joseph Aidoo', age: 28, position: 'DEF', specificRole: 'DC', overall: 76, stamina: 85, form: 7.6, marketValue: 6000000, wage: 12000, nationality: 'Gana', attributes: { pace: 72, shooting: 35, passing: 60, defending: 77, physical: 84 }, isStarting: false },
      { id: 'cel-mallo', name: 'Javi Rodríguez', age: 21, position: 'DEF', specificRole: 'DR', overall: 73, stamina: 85, form: 7.6, marketValue: 4000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 76, shooting: 45, passing: 68, defending: 73, physical: 72 }, isStarting: false },
      { id: 'cel-dominguez', name: 'Carlos Domínguez', age: 23, position: 'DEF', specificRole: 'DC', overall: 74, stamina: 86, form: 7.6, marketValue: 5000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 70, shooting: 35, passing: 64, defending: 74, physical: 76 }, isStarting: false },
      { id: 'cel-manquillo', name: 'Javier Manquillo', age: 30, position: 'DEF', specificRole: 'DR', overall: 74, stamina: 84, form: 7.5, marketValue: 3000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 76, shooting: 45, passing: 66, defending: 73, physical: 72 }, isStarting: false },
      { id: 'cel-rzeszot', name: 'Mihailo Ristić', age: 28, position: 'DEF', specificRole: 'DL', overall: 74, stamina: 85, form: 7.5, marketValue: 3000000, wage: 8000, nationality: 'Sırbistan', attributes: { pace: 78, shooting: 55, passing: 70, defending: 72, physical: 74 }, isStarting: false },
      // Orta Sahalar
      { id: 'cel-beltran', name: 'Fran Beltrán', age: 25, position: 'MID', specificRole: 'MC', overall: 78, stamina: 92, form: 8.0, marketValue: 15000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 74, shooting: 68, passing: 80, defending: 75, physical: 74 }, isStarting: true },
      { id: 'cel-moriba', name: 'Ilaix Moriba', age: 21, position: 'MID', specificRole: 'MC', overall: 76, stamina: 88, form: 7.8, marketValue: 10000000, wage: 12000, nationality: 'Gine', attributes: { pace: 76, shooting: 70, passing: 76, defending: 72, physical: 78 }, isStarting: true },
      { id: 'cel-sotelo', name: 'Hugo Sotelo', age: 20, position: 'MID', specificRole: 'MC', overall: 74, stamina: 86, form: 7.6, marketValue: 6000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 72, shooting: 65, passing: 76, defending: 68, physical: 70 }, isStarting: false },
      { id: 'cel-delatorre', name: 'Luca de la Torre', age: 26, position: 'MID', specificRole: 'MC', overall: 75, stamina: 88, form: 7.6, marketValue: 6000000, wage: 10000, nationality: 'Amerika B. D.', attributes: { pace: 74, shooting: 66, passing: 76, defending: 68, physical: 70 }, isStarting: false },
      { id: 'cel-swedberg', name: 'Williot Swedberg', age: 20, position: 'MID', specificRole: 'LW', overall: 76, stamina: 88, form: 8.0, marketValue: 10000000, wage: 8000, nationality: 'İsveç', attributes: { pace: 82, shooting: 74, passing: 72, defending: 38, physical: 70 }, isStarting: true },
      { id: 'cel-bamba', name: 'Jonathan Bamba', age: 28, position: 'MID', specificRole: 'LW', overall: 77, stamina: 88, form: 7.8, marketValue: 10000000, wage: 15000, nationality: 'Fildişi Sahili', attributes: { pace: 84, shooting: 74, passing: 74, defending: 42, physical: 72 }, isStarting: false },
      { id: 'cel-roman', name: 'Fer López', age: 20, position: 'MID', specificRole: 'AM', overall: 72, stamina: 84, form: 7.5, marketValue: 4000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 74, shooting: 68, passing: 74, defending: 45, physical: 66 }, isStarting: false },
      // Forvetler
      { id: 'cel-aspas', name: 'Iago Aspas', age: 37, position: 'FW', specificRole: 'ST', overall: 81, stamina: 80, form: 8.4, marketValue: 4000000, wage: 20000, nationality: 'İspanya', attributes: { pace: 72, shooting: 84, passing: 83, defending: 42, physical: 68 }, isStarting: true },
      { id: 'cel-douvikas', name: 'Tasos Douvikas', age: 25, position: 'FW', specificRole: 'ST', overall: 77, stamina: 88, form: 7.9, marketValue: 12000000, wage: 12000, nationality: 'Yunanistan', attributes: { pace: 80, shooting: 79, passing: 65, defending: 35, physical: 78 }, isStarting: false },
      { id: 'cel-iglesias', name: 'Borja Iglesias', age: 31, position: 'FW', specificRole: 'ST', overall: 77, stamina: 85, form: 7.8, marketValue: 8000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 70, shooting: 80, passing: 68, defending: 38, physical: 82 }, isStarting: true },
      { id: 'cel-duran', name: 'Pablo Durán', age: 23, position: 'FW', specificRole: 'ST', overall: 73, stamina: 85, form: 7.5, marketValue: 3000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 76, shooting: 73, passing: 62, defending: 32, physical: 72 }, isStarting: false }
    ]
  },

  // 11. Rayo Vallecano (Updated per Screenshot)
  {
    id: 'rayo-vallecano',
    name: 'Rayo Vallecano',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Estadio de Vallecas',
    manager: 'Beñat San José',
    overall: 77,
    budget: 15000000,
    badgeColor: 'from-red-600 to-white',
    shortName: 'RAY',
    players: [
      // Kaleciler
      { id: 'ray-batalla', name: 'Augusto Batalla', age: 28, position: 'GK', specificRole: 'GK', overall: 77, stamina: 88, form: 7.8, marketValue: 5000000, wage: 10000, nationality: 'Arjantin', attributes: { pace: 48, shooting: 15, passing: 66, defending: 77, physical: 76 }, isStarting: true },
      { id: 'ray-cardenas', name: 'Dani Cárdenas', age: 27, position: 'GK', specificRole: 'GK', overall: 75, stamina: 85, form: 7.6, marketValue: 3000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 48, shooting: 15, passing: 65, defending: 75, physical: 74 }, isStarting: false },
      // Defanslar
      { id: 'ray-lejeune', name: 'Florian Lejeune', age: 33, position: 'DEF', specificRole: 'DC', overall: 77, stamina: 85, form: 7.8, marketValue: 3000000, wage: 12000, nationality: 'Fransa', attributes: { pace: 62, shooting: 55, passing: 70, defending: 78, physical: 80 }, isStarting: true },
      { id: 'ray-mumin', name: 'Abdul Mumin', age: 26, position: 'DEF', specificRole: 'DC', overall: 76, stamina: 88, form: 7.8, marketValue: 6000000, wage: 10000, nationality: 'Gana', attributes: { pace: 74, shooting: 35, passing: 62, defending: 76, physical: 82 }, isStarting: true },
      { id: 'ray-chavarria', name: 'Pep Chavarría', age: 26, position: 'DEF', specificRole: 'DL', overall: 75, stamina: 88, form: 7.7, marketValue: 4000000, wage: 9000, nationality: 'İspanya', attributes: { pace: 82, shooting: 50, passing: 68, defending: 73, physical: 72 }, isStarting: true },
      { id: 'ray-balliu', name: 'Iván Balliu', age: 32, position: 'DEF', specificRole: 'DR', overall: 76, stamina: 86, form: 7.7, marketValue: 4000000, wage: 10000, nationality: 'Arnavutluk', attributes: { pace: 78, shooting: 48, passing: 68, defending: 75, physical: 74 }, isStarting: true },
      { id: 'ray-espino', name: 'Alfonso Espino', age: 32, position: 'DEF', specificRole: 'DL', overall: 75, stamina: 85, form: 7.6, marketValue: 3000000, wage: 10000, nationality: 'Uruguay', attributes: { pace: 80, shooting: 52, passing: 66, defending: 74, physical: 76 }, isStarting: false },
      { id: 'ray-rrat', name: 'Pelayo Fernández', age: 21, position: 'DEF', specificRole: 'DC', overall: 72, stamina: 84, form: 7.5, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 68, shooting: 35, passing: 62, defending: 72, physical: 74 }, isStarting: false },
      { id: 'ray-aridane', name: 'Aridane Hernández', age: 35, position: 'DEF', specificRole: 'DC', overall: 73, stamina: 80, form: 7.4, marketValue: 1000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 58, shooting: 35, passing: 58, defending: 74, physical: 80 }, isStarting: false },
      // Orta Sahalar
      { id: 'ray-palazon', name: 'Isi Palazón', age: 29, position: 'MID', specificRole: 'RW', overall: 78, stamina: 90, form: 8.0, marketValue: 12000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 80, shooting: 78, passing: 78, defending: 50, physical: 72 }, isStarting: true },
      { id: 'ray-james', name: 'James Rodríguez', age: 33, position: 'MID', specificRole: 'AM', overall: 80, stamina: 80, form: 8.1, marketValue: 5000000, wage: 18000, nationality: 'Kolombiya', attributes: { pace: 65, shooting: 82, passing: 87, defending: 42, physical: 68 }, isStarting: true },
      { id: 'ray-alvaro', name: 'Álvaro García', age: 31, position: 'MID', specificRole: 'LW', overall: 77, stamina: 91, form: 7.8, marketValue: 8000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 89, shooting: 74, passing: 72, defending: 48, physical: 70 }, isStarting: true },
      { id: 'ray-unailopez', name: 'Unai López', age: 28, position: 'MID', specificRole: 'MC', overall: 76, stamina: 88, form: 7.7, marketValue: 6000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 72, shooting: 72, passing: 78, defending: 68, physical: 70 }, isStarting: true },
      { id: 'ray-valentin', name: 'Óscar Valentín', age: 29, position: 'MID', specificRole: 'MC', overall: 77, stamina: 92, form: 7.8, marketValue: 8000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 70, shooting: 62, passing: 74, defending: 78, physical: 80 }, isStarting: true },
      { id: 'ray-gumbau', name: 'Gerard Gumbau', age: 29, position: 'MID', specificRole: 'MC', overall: 75, stamina: 86, form: 7.6, marketValue: 4000000, wage: 9000, nationality: 'İspanya', attributes: { pace: 68, shooting: 68, passing: 76, defending: 72, physical: 74 }, isStarting: false },
      { id: 'ray-ciss', name: 'Pathé Ciss', age: 30, position: 'MID', specificRole: 'MC', overall: 76, stamina: 88, form: 7.7, marketValue: 6000000, wage: 10000, nationality: 'Senegal', attributes: { pace: 72, shooting: 65, passing: 74, defending: 76, physical: 80 }, isStarting: false },
      { id: 'ray-trejo', name: 'Óscar Trejo', age: 36, position: 'MID', specificRole: 'AM', overall: 74, stamina: 78, form: 7.5, marketValue: 1500000, wage: 8000, nationality: 'Arjantin', attributes: { pace: 64, shooting: 72, passing: 78, defending: 52, physical: 68 }, isStarting: false },
      { id: 'ray-embarba', name: 'Adrián Embarba', age: 32, position: 'MID', specificRole: 'RW', overall: 75, stamina: 85, form: 7.6, marketValue: 3000000, wage: 9000, nationality: 'İspanya', attributes: { pace: 78, shooting: 74, passing: 74, defending: 45, physical: 68 }, isStarting: false },
      { id: 'ray-defrutos', name: 'Jorge de Frutos', age: 27, position: 'MID', specificRole: 'RW', overall: 76, stamina: 88, form: 7.8, marketValue: 8000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 84, shooting: 72, passing: 72, defending: 42, physical: 70 }, isStarting: false },
      { id: 'ray-bebe', name: 'Bebé', age: 34, position: 'MID', specificRole: 'LW', overall: 72, stamina: 80, form: 7.4, marketValue: 1000000, wage: 6000, nationality: 'Yeşil Burun Adaları', attributes: { pace: 78, shooting: 78, passing: 66, defending: 35, physical: 76 }, isStarting: false },
      // Forvetler
      { id: 'ray-camello', name: 'Sergio Camello', age: 23, position: 'FW', specificRole: 'ST', overall: 76, stamina: 88, form: 7.9, marketValue: 10000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 80, shooting: 76, passing: 68, defending: 38, physical: 72 }, isStarting: true },
      { id: 'ray-desantamaria', name: 'Etienne Eto\'o', age: 22, position: 'FW', specificRole: 'ST', overall: 71, stamina: 84, form: 7.4, marketValue: 3000000, wage: 5000, nationality: 'Kamerun', attributes: { pace: 78, shooting: 72, passing: 60, defending: 32, physical: 74 }, isStarting: false },
      { id: 'ray-falcao', name: 'Raúl de Tomás', age: 29, position: 'FW', specificRole: 'ST', overall: 76, stamina: 82, form: 7.6, marketValue: 5000000, wage: 15000, nationality: 'İspanya', attributes: { pace: 74, shooting: 80, passing: 68, defending: 35, physical: 74 }, isStarting: false }
    ]
  },

  // 12. CA Osasuna (Updated per Screenshot)
  {
    id: 'osasuna',
    name: 'CA Osasuna',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'El Sadar',
    manager: 'Dani Pendín',
    overall: 77,
    budget: 15000000,
    badgeColor: 'from-red-700 to-blue-900',
    shortName: 'OSA',
    players: [
      // Kaleciler
      { id: 'osa-herrera', name: 'Sergio Herrera', age: 31, position: 'GK', specificRole: 'GK', overall: 78, stamina: 88, form: 7.9, marketValue: 6000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 48, shooting: 15, passing: 68, defending: 78, physical: 76 }, isStarting: true },
      { id: 'osa-aitor', name: 'Aitor Fernández', age: 33, position: 'GK', specificRole: 'GK', overall: 75, stamina: 82, form: 7.5, marketValue: 2000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 45, shooting: 15, passing: 64, defending: 75, physical: 72 }, isStarting: false },
      { id: 'osa-rafa', name: 'Rafa Fernández', age: 20, position: 'GK', specificRole: 'GK', overall: 70, stamina: 80, form: 7.3, marketValue: 1000000, wage: 4000, nationality: 'İspanya', attributes: { pace: 42, shooting: 15, passing: 60, defending: 70, physical: 68 }, isStarting: false },
      // Defanslar
      { id: 'osa-boyomo', name: 'Enzo Boyomo', age: 22, position: 'DEF', specificRole: 'DC', overall: 77, stamina: 88, form: 7.9, marketValue: 10000000, wage: 10000, nationality: 'Kamerun', attributes: { pace: 74, shooting: 38, passing: 64, defending: 77, physical: 80 }, isStarting: true },
      { id: 'osa-catena', name: 'Alejandro Catena', age: 29, position: 'DEF', specificRole: 'DC', overall: 77, stamina: 88, form: 7.7, marketValue: 6000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 62, shooting: 40, passing: 66, defending: 78, physical: 82 }, isStarting: true },
      { id: 'osa-rosier', name: 'Valentin Rosier', age: 28, position: 'DEF', specificRole: 'DR', overall: 76, stamina: 86, form: 7.7, marketValue: 5000000, wage: 10000, nationality: 'Fransa', attributes: { pace: 80, shooting: 50, passing: 68, defending: 73, physical: 74 }, isStarting: true },
      { id: 'osa-bretones', name: 'Abel Bretones', age: 24, position: 'DEF', specificRole: 'DL', overall: 75, stamina: 88, form: 7.7, marketValue: 5000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 82, shooting: 52, passing: 68, defending: 72, physical: 72 }, isStarting: true },
      { id: 'osa-herrando', name: 'Jorge Herrando', age: 23, position: 'DEF', specificRole: 'DC', overall: 74, stamina: 85, form: 7.5, marketValue: 4000000, wage: 7000, nationality: 'İspanya', attributes: { pace: 66, shooting: 35, passing: 62, defending: 75, physical: 78 }, isStarting: false },
      { id: 'osa-arguibide', name: 'Íñigo Arguibide', age: 19, position: 'DEF', specificRole: 'DR', overall: 71, stamina: 82, form: 7.4, marketValue: 2000000, wage: 4000, nationality: 'İspanya', attributes: { pace: 76, shooting: 42, passing: 62, defending: 69, physical: 68 }, isStarting: false },
      { id: 'osa-ibarrondo', name: 'Kepa Ibarrondo', age: 18, position: 'DEF', specificRole: 'DR', overall: 69, stamina: 80, form: 7.3, marketValue: 1200000, wage: 3000, nationality: 'İspanya', attributes: { pace: 74, shooting: 40, passing: 60, defending: 68, physical: 66 }, isStarting: false },
      { id: 'osa-santos', name: 'Unai Santos', age: 19, position: 'DEF', specificRole: 'DC', overall: 69, stamina: 80, form: 7.3, marketValue: 1000000, wage: 3000, nationality: 'İspanya', attributes: { pace: 64, shooting: 32, passing: 58, defending: 70, physical: 72 }, isStarting: false },
      // Orta Sahalar
      { id: 'osa-moro', name: 'Raúl Moro', age: 21, position: 'MID', specificRole: 'LW', overall: 76, stamina: 88, form: 7.9, marketValue: 8000000, wage: 9000, nationality: 'İspanya', attributes: { pace: 86, shooting: 72, passing: 72, defending: 40, physical: 64 }, isStarting: true },
      { id: 'osa-oroz', name: 'Aimar Oroz', age: 22, position: 'MID', specificRole: 'AM', overall: 78, stamina: 90, form: 8.1, marketValue: 18000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 76, shooting: 74, passing: 81, defending: 55, physical: 70 }, isStarting: true },
      { id: 'osa-rubengarcia', name: 'Rubén García', age: 31, position: 'MID', specificRole: 'RW', overall: 76, stamina: 85, form: 7.7, marketValue: 4000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 74, shooting: 74, passing: 78, defending: 52, physical: 68 }, isStarting: true },
      { id: 'osa-moncayola', name: 'Jon Moncayola', age: 26, position: 'MID', specificRole: 'MC', overall: 78, stamina: 92, form: 7.9, marketValue: 12000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 76, shooting: 72, passing: 78, defending: 75, physical: 78 }, isStarting: true },
      { id: 'osa-torro', name: 'Lucas Torró', age: 30, position: 'MID', specificRole: 'MC', overall: 77, stamina: 86, form: 7.7, marketValue: 6000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 62, shooting: 60, passing: 74, defending: 79, physical: 84 }, isStarting: true },
      { id: 'osa-moigomez', name: 'Moi Gómez', age: 30, position: 'MID', specificRole: 'MC', overall: 76, stamina: 85, form: 7.6, marketValue: 4000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 70, shooting: 72, passing: 78, defending: 60, physical: 68 }, isStarting: false },
      { id: 'osa-dubasin', name: 'Jonathan Dubasin', age: 24, position: 'MID', specificRole: 'RW', overall: 74, stamina: 86, form: 7.6, marketValue: 4000000, wage: 7000, nationality: 'Belçika', attributes: { pace: 80, shooting: 72, passing: 70, defending: 42, physical: 68 }, isStarting: false },
      { id: 'osa-munoz', name: 'Iker Muñoz', age: 21, position: 'MID', specificRole: 'MC', overall: 75, stamina: 88, form: 7.7, marketValue: 6000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 72, shooting: 64, passing: 75, defending: 74, physical: 74 }, isStarting: false },
      { id: 'osa-morales', name: 'Anai Morales', age: 19, position: 'MID', specificRole: 'MC', overall: 70, stamina: 80, form: 7.3, marketValue: 1500000, wage: 3000, nationality: 'İspanya', attributes: { pace: 70, shooting: 62, passing: 72, defending: 65, physical: 66 }, isStarting: false },
      { id: 'osa-echegoyen', name: 'Mauro Echegoyen', age: 19, position: 'MID', specificRole: 'MC', overall: 70, stamina: 80, form: 7.3, marketValue: 1500000, wage: 3000, nationality: 'İspanya', attributes: { pace: 70, shooting: 60, passing: 72, defending: 66, physical: 68 }, isStarting: false },
      // Forvetler
      { id: 'osa-budimir', name: 'Ante Budimir', age: 33, position: 'FW', specificRole: 'ST', overall: 80, stamina: 85, form: 8.3, marketValue: 5000000, wage: 16000, nationality: 'Hırvatistan', attributes: { pace: 70, shooting: 82, passing: 65, defending: 40, physical: 85 }, isStarting: true },
      { id: 'osa-raulgarcia', name: 'Raúl García de Haro', age: 23, position: 'FW', specificRole: 'ST', overall: 75, stamina: 86, form: 7.6, marketValue: 6000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 74, shooting: 76, passing: 64, defending: 35, physical: 76 }, isStarting: false },
      { id: 'osa-barja', name: 'Kike Barja', age: 27, position: 'FW', specificRole: 'LW', overall: 74, stamina: 82, form: 7.5, marketValue: 3000000, wage: 7000, nationality: 'İspanya', attributes: { pace: 78, shooting: 70, passing: 72, defending: 40, physical: 65 }, isStarting: false },
      { id: 'osa-benito', name: 'Iker Benito', age: 21, position: 'FW', specificRole: 'LW', overall: 72, stamina: 84, form: 7.4, marketValue: 2500000, wage: 5000, nationality: 'İspanya', attributes: { pace: 82, shooting: 68, passing: 66, defending: 38, physical: 64 }, isStarting: false },
      { id: 'osa-horro', name: 'Aimar Horro', age: 18, position: 'FW', specificRole: 'ST', overall: 68, stamina: 78, form: 7.2, marketValue: 1000000, wage: 2000, nationality: 'İspanya', attributes: { pace: 72, shooting: 68, passing: 58, defending: 30, physical: 68 }, isStarting: false }
    ]
  },

  // 13. Getafe CF (Updated per Screenshot)
  {
    id: 'getafe',
    name: 'Getafe CF',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Coliseum',
    manager: 'José Bordalás',
    overall: 76,
    budget: 14000000,
    badgeColor: 'from-blue-600 to-blue-900',
    shortName: 'GET',
    players: [
      // Kaleciler
      { id: 'get-soria', name: 'David Soria', age: 31, position: 'GK', specificRole: 'GK', overall: 78, stamina: 88, form: 7.9, marketValue: 7000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 48, shooting: 15, passing: 65, defending: 78, physical: 76 }, isStarting: true },
      { id: 'get-letacek', name: 'Jiří Letáček', age: 25, position: 'GK', specificRole: 'GK', overall: 73, stamina: 82, form: 7.5, marketValue: 2000000, wage: 6000, nationality: 'Çekya', attributes: { pace: 45, shooting: 15, passing: 62, defending: 73, physical: 72 }, isStarting: false },
      { id: 'get-ferrer', name: 'Diego Ferrer', age: 20, position: 'GK', specificRole: 'GK', overall: 69, stamina: 80, form: 7.2, marketValue: 1000000, wage: 3000, nationality: 'İspanya', attributes: { pace: 42, shooting: 15, passing: 58, defending: 69, physical: 68 }, isStarting: false },
      // Defanslar
      { id: 'get-abqar', name: 'Abdel Abqar', age: 25, position: 'DEF', specificRole: 'DC', overall: 77, stamina: 88, form: 7.8, marketValue: 7000000, wage: 10000, nationality: 'Fas', attributes: { pace: 72, shooting: 35, passing: 62, defending: 77, physical: 82 }, isStarting: true },
      { id: 'get-djene', name: 'Djené Dakonam', age: 32, position: 'DEF', specificRole: 'DC', overall: 77, stamina: 88, form: 7.8, marketValue: 4000000, wage: 12000, nationality: 'Togo', attributes: { pace: 75, shooting: 35, passing: 62, defending: 78, physical: 80 }, isStarting: true },
      { id: 'get-sangare', name: 'Buba Sangaré', age: 17, position: 'DEF', specificRole: 'DC', overall: 71, stamina: 82, form: 7.5, marketValue: 3000000, wage: 4000, nationality: 'İspanya', attributes: { pace: 76, shooting: 35, passing: 60, defending: 71, physical: 70 }, isStarting: false },
      { id: 'get-sanusi', name: 'Zaidu Sanusi', age: 27, position: 'DEF', specificRole: 'DL', overall: 75, stamina: 86, form: 7.6, marketValue: 4000000, wage: 8000, nationality: 'Nijerya', attributes: { pace: 84, shooting: 45, passing: 65, defending: 72, physical: 74 }, isStarting: true },
      { id: 'get-boselli', name: 'Sebastién Boselli', age: 20, position: 'DEF', specificRole: 'DC', overall: 74, stamina: 85, form: 7.6, marketValue: 4000000, wage: 6000, nationality: 'Uruguay', attributes: { pace: 70, shooting: 35, passing: 62, defending: 74, physical: 76 }, isStarting: false },
      { id: 'get-iglesias', name: 'Juan Iglesias', age: 25, position: 'DEF', specificRole: 'DR', overall: 74, stamina: 86, form: 7.5, marketValue: 3000000, wage: 7000, nationality: 'İspanya', attributes: { pace: 76, shooting: 42, passing: 66, defending: 72, physical: 72 }, isStarting: true },
      { id: 'get-bekkoucha', name: 'Ismael Bekkoucha', age: 19, position: 'DEF', specificRole: 'DC', overall: 69, stamina: 80, form: 7.2, marketValue: 1000000, wage: 3000, nationality: 'Fas', attributes: { pace: 68, shooting: 30, passing: 58, defending: 69, physical: 70 }, isStarting: false },
      { id: 'get-davichi', name: 'Davichi', age: 18, position: 'DEF', specificRole: 'DL', overall: 68, stamina: 80, form: 7.2, marketValue: 800000, wage: 2000, nationality: 'İspanya', attributes: { pace: 74, shooting: 38, passing: 60, defending: 66, physical: 64 }, isStarting: false },
      { id: 'get-femenia', name: 'Kiko Femenía', age: 33, position: 'DEF', specificRole: 'DR', overall: 74, stamina: 82, form: 7.4, marketValue: 1500000, wage: 7000, nationality: 'İspanya', attributes: { pace: 74, shooting: 48, passing: 68, defending: 71, physical: 68 }, isStarting: false },
      { id: 'get-valero', name: 'Juanma Valero', age: 19, position: 'DEF', specificRole: 'DC', overall: 68, stamina: 78, form: 7.2, marketValue: 800000, wage: 2000, nationality: 'İspanya', attributes: { pace: 64, shooting: 30, passing: 56, defending: 68, physical: 70 }, isStarting: false },
      { id: 'get-hamdoune', name: 'Mohamed Hamdoune', age: 20, position: 'DEF', specificRole: 'DC', overall: 68, stamina: 78, form: 7.2, marketValue: 800000, wage: 2000, nationality: 'Fas', attributes: { pace: 66, shooting: 30, passing: 56, defending: 68, physical: 70 }, isStarting: false },
      { id: 'get-hermoso', name: 'Javi Hermoso', age: 25, position: 'DEF', specificRole: 'DC', overall: 72, stamina: 82, form: 7.4, marketValue: 2000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 66, shooting: 32, passing: 60, defending: 72, physical: 74 }, isStarting: false },
      // Orta Sahalar
      { id: 'get-martim', name: 'Mario Martín', age: 20, position: 'MID', specificRole: 'MC', overall: 74, stamina: 88, form: 7.7, marketValue: 5000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 72, shooting: 64, passing: 75, defending: 72, physical: 72 }, isStarting: true },
      { id: 'get-neyou', name: 'Yvan Neyou', age: 27, position: 'MID', specificRole: 'MC', overall: 74, stamina: 86, form: 7.6, marketValue: 3000000, wage: 7000, nationality: 'Kamerun', attributes: { pace: 70, shooting: 62, passing: 74, defending: 73, physical: 76 }, isStarting: true },
      { id: 'get-terrats', name: 'Ramon Terrats', age: 23, position: 'MID', specificRole: 'MC', overall: 74, stamina: 86, form: 7.6, marketValue: 4000000, wage: 7000, nationality: 'İspanya', attributes: { pace: 70, shooting: 66, passing: 76, defending: 70, physical: 70 }, isStarting: true },
      { id: 'get-munoz', name: 'Javier Muñoz', age: 29, position: 'MID', specificRole: 'AM', overall: 74, stamina: 85, form: 7.5, marketValue: 3000000, wage: 7000, nationality: 'İspanya', attributes: { pace: 72, shooting: 68, passing: 75, defending: 60, physical: 68 }, isStarting: false },
      { id: 'get-alderete', name: 'Omar Alderete', age: 27, position: 'MID', specificRole: 'MC', overall: 76, stamina: 88, form: 7.8, marketValue: 6000000, wage: 10000, nationality: 'Paraguay', attributes: { pace: 68, shooting: 50, passing: 68, defending: 78, physical: 82 }, isStarting: true },
      { id: 'get-risco', name: 'Alberto Risco', age: 19, position: 'MID', specificRole: 'MC', overall: 69, stamina: 80, form: 7.3, marketValue: 1200000, wage: 3000, nationality: 'İspanya', attributes: { pace: 70, shooting: 62, passing: 71, defending: 60, physical: 64 }, isStarting: false },
      // Forvetler
      { id: 'get-uche', name: 'Christantus Uche', age: 21, position: 'FW', specificRole: 'ST', overall: 76, stamina: 88, form: 8.0, marketValue: 8000000, wage: 8000, nationality: 'Nijerya', attributes: { pace: 80, shooting: 74, passing: 70, defending: 55, physical: 82 }, isStarting: true },
      { id: 'get-satriano', name: 'Martín Satriano', age: 23, position: 'FW', specificRole: 'ST', overall: 75, stamina: 86, form: 7.6, marketValue: 5000000, wage: 8000, nationality: 'Uruguay', attributes: { pace: 76, shooting: 75, passing: 64, defending: 35, physical: 76 }, isStarting: true },
      { id: 'get-mayoral', name: 'Borja Mayoral', age: 27, position: 'FW', specificRole: 'ST', overall: 78, stamina: 88, form: 8.0, marketValue: 12000000, wage: 15000, nationality: 'İspanya', attributes: { pace: 78, shooting: 80, passing: 70, defending: 38, physical: 74 }, isStarting: false },
      { id: 'get-juanmi', name: 'Juanmi', age: 31, position: 'FW', specificRole: 'LW', overall: 75, stamina: 84, form: 7.6, marketValue: 3000000, wage: 9000, nationality: 'İspanya', attributes: { pace: 76, shooting: 76, passing: 68, defending: 38, physical: 68 }, isStarting: false },
      { id: 'get-tallal', name: 'Yassin Tallal', age: 19, position: 'FW', specificRole: 'ST', overall: 69, stamina: 80, form: 7.3, marketValue: 1200000, wage: 3000, nationality: 'Fas', attributes: { pace: 76, shooting: 68, passing: 58, defending: 30, physical: 66 }, isStarting: false },
      { id: 'get-sola', name: 'Álex Sola', age: 25, position: 'FW', specificRole: 'RW', overall: 74, stamina: 86, form: 7.6, marketValue: 3500000, wage: 7000, nationality: 'İspanya', attributes: { pace: 82, shooting: 68, passing: 72, defending: 55, physical: 68 }, isStarting: false },
      { id: 'get-mastan', name: 'Alejandro Mastantuono', age: 19, position: 'FW', specificRole: 'ST', overall: 68, stamina: 78, form: 7.2, marketValue: 800000, wage: 2000, nationality: 'İspanya', attributes: { pace: 72, shooting: 66, passing: 58, defending: 30, physical: 65 }, isStarting: false },
      { id: 'get-drammeh', name: 'Ibrahim Drammeh Cissé', age: 18, position: 'FW', specificRole: 'ST', overall: 68, stamina: 78, form: 7.2, marketValue: 800000, wage: 2000, nationality: 'Gambiya', attributes: { pace: 74, shooting: 66, passing: 56, defending: 30, physical: 68 }, isStarting: false },
      { id: 'get-pastor', name: 'Marcos Pastor Hernanz', age: 18, position: 'FW', specificRole: 'ST', overall: 67, stamina: 76, form: 7.1, marketValue: 600000, wage: 2000, nationality: 'İspanya', attributes: { pace: 70, shooting: 65, passing: 55, defending: 30, physical: 64 }, isStarting: false },
      { id: 'get-kiri', name: 'Álvaro Gutierrez Kiri', age: 18, position: 'FW', specificRole: 'ST', overall: 67, stamina: 76, form: 7.1, marketValue: 600000, wage: 2000, nationality: 'İspanya', attributes: { pace: 70, shooting: 65, passing: 55, defending: 30, physical: 64 }, isStarting: false }
    ]
  },

  // 14. Deportivo Alavés (Updated per Screenshot)
  {
    id: 'alaves',
    name: 'Deportivo Alavés',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Mendizorrotza Stadium',
    manager: 'Luis García Plaza',
    overall: 76,
    budget: 12000000,
    badgeColor: 'from-blue-600 to-white',
    shortName: 'ALA',
    players: [
      // Kaleciler
      { id: 'ala-sivera', name: 'Antonio Sivera', age: 28, position: 'GK', specificRole: 'GK', overall: 77, stamina: 88, form: 7.8, marketValue: 5000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 48, shooting: 15, passing: 66, defending: 77, physical: 75 }, isStarting: true },
      { id: 'ala-owono', name: 'Jesús Owono', age: 23, position: 'GK', specificRole: 'GK', overall: 72, stamina: 82, form: 7.4, marketValue: 1500000, wage: 5000, nationality: 'Ekvator Ginesi', attributes: { pace: 45, shooting: 15, passing: 60, defending: 72, physical: 70 }, isStarting: false },
      { id: 'ala-rodriguez', name: 'Adrián Rodríguez', age: 23, position: 'GK', specificRole: 'GK', overall: 70, stamina: 80, form: 7.3, marketValue: 1000000, wage: 4000, nationality: 'Arjantin', attributes: { pace: 42, shooting: 15, passing: 58, defending: 70, physical: 68 }, isStarting: false },
      // Defanslar
      { id: 'ala-enriquez', name: 'Youssef Enriquez', age: 19, position: 'DEF', specificRole: 'DL', overall: 72, stamina: 84, form: 7.5, marketValue: 3000000, wage: 5000, nationality: 'Fas', attributes: { pace: 80, shooting: 45, passing: 65, defending: 69, physical: 68 }, isStarting: true },
      { id: 'ala-garces', name: 'Facundo Garcés', age: 24, position: 'DEF', specificRole: 'DC', overall: 75, stamina: 86, form: 7.6, marketValue: 4000000, wage: 8000, nationality: 'Arjantin', attributes: { pace: 68, shooting: 35, passing: 60, defending: 76, physical: 78 }, isStarting: true },
      { id: 'ala-tenaglia', name: 'Nahuel Tenaglia', age: 28, position: 'DEF', specificRole: 'DR', overall: 75, stamina: 88, form: 7.6, marketValue: 4000000, wage: 8000, nationality: 'Arjantin', attributes: { pace: 76, shooting: 45, passing: 66, defending: 75, physical: 76 }, isStarting: true },
      { id: 'ala-diarra', name: 'Mousse Diarra', age: 23, position: 'DEF', specificRole: 'DC', overall: 74, stamina: 85, form: 7.5, marketValue: 3000000, wage: 6000, nationality: 'Mali', attributes: { pace: 70, shooting: 35, passing: 60, defending: 74, physical: 78 }, isStarting: true },
      { id: 'ala-cida', name: 'Javi Cida', age: 20, position: 'DEF', specificRole: 'DR', overall: 70, stamina: 80, form: 7.3, marketValue: 1200000, wage: 3000, nationality: 'İspanya', attributes: { pace: 74, shooting: 40, passing: 62, defending: 68, physical: 66 }, isStarting: false },
      { id: 'ala-benavidez', name: 'Carlos Benavidez', age: 26, position: 'DEF', specificRole: 'DC', overall: 74, stamina: 86, form: 7.5, marketValue: 3000000, wage: 7000, nationality: 'Uruguay', attributes: { pace: 68, shooting: 55, passing: 68, defending: 74, physical: 76 }, isStarting: false },
      { id: 'ala-koidi', name: 'Yelle Koidi', age: 19, position: 'DEF', specificRole: 'DC', overall: 68, stamina: 78, form: 7.2, marketValue: 800000, wage: 2000, nationality: 'Fransa', attributes: { pace: 66, shooting: 30, passing: 56, defending: 68, physical: 70 }, isStarting: false },
      { id: 'ala-novoa', name: 'Hugo Novoa', age: 21, position: 'DEF', specificRole: 'DR', overall: 73, stamina: 85, form: 7.5, marketValue: 3000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 82, shooting: 58, passing: 68, defending: 68, physical: 68 }, isStarting: false },
      { id: 'ala-maras', name: 'Nikola Maraš', age: 28, position: 'DEF', specificRole: 'DC', overall: 73, stamina: 82, form: 7.3, marketValue: 1800000, wage: 6000, nationality: 'Sırbistan', attributes: { pace: 60, shooting: 35, passing: 58, defending: 74, physical: 78 }, isStarting: false },
      { id: 'ala-olaiz', name: 'Xabi Olaiz', age: 19, position: 'DEF', specificRole: 'DC', overall: 68, stamina: 78, form: 7.2, marketValue: 800000, wage: 2000, nationality: 'İspanya', attributes: { pace: 64, shooting: 30, passing: 56, defending: 68, physical: 70 }, isStarting: false },
      // Orta Sahalar
      { id: 'ala-rebbach', name: 'Abde Rebbach', age: 25, position: 'MID', specificRole: 'LW', overall: 74, stamina: 86, form: 7.6, marketValue: 3500000, wage: 7000, nationality: 'Cezayir', attributes: { pace: 84, shooting: 70, passing: 70, defending: 40, physical: 66 }, isStarting: true },
      { id: 'ala-blanco', name: 'Antonio Blanco', age: 24, position: 'MID', specificRole: 'MC', overall: 76, stamina: 90, form: 7.8, marketValue: 8000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 72, shooting: 64, passing: 78, defending: 75, physical: 74 }, isStarting: true },
      { id: 'ala-vicente', name: 'Carlos Vicente', age: 25, position: 'MID', specificRole: 'RW', overall: 76, stamina: 90, form: 7.9, marketValue: 8000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 84, shooting: 74, passing: 72, defending: 45, physical: 74 }, isStarting: true },
      { id: 'ala-perea', name: 'Darío Perea', age: 20, position: 'MID', specificRole: 'MC', overall: 70, stamina: 80, form: 7.3, marketValue: 1200000, wage: 3000, nationality: 'İspanya', attributes: { pace: 70, shooting: 62, passing: 72, defending: 65, physical: 66 }, isStarting: false },
      { id: 'ala-mrodriguez', name: 'Miguel Rodríguez', age: 21, position: 'MID', specificRole: 'RW', overall: 74, stamina: 86, form: 7.6, marketValue: 4000000, wage: 7000, nationality: 'İspanya', attributes: { pace: 82, shooting: 72, passing: 70, defending: 42, physical: 68 }, isStarting: false },
      { id: 'ala-ibanez', name: 'Pablo Ibáñez', age: 25, position: 'MID', specificRole: 'MC', overall: 74, stamina: 86, form: 7.5, marketValue: 3000000, wage: 7000, nationality: 'İspanya', attributes: { pace: 72, shooting: 68, passing: 74, defending: 72, physical: 74 }, isStarting: true },
      { id: 'ala-guevara', name: 'Ander Guevara', age: 27, position: 'MID', specificRole: 'MC', overall: 76, stamina: 90, form: 7.7, marketValue: 6000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 70, shooting: 65, passing: 77, defending: 74, physical: 74 }, isStarting: true },
      { id: 'ala-perez', name: 'Ángel Pérez', age: 20, position: 'MID', specificRole: 'RW', overall: 69, stamina: 80, form: 7.3, marketValue: 1000000, wage: 3000, nationality: 'İspanya', attributes: { pace: 78, shooting: 64, passing: 66, defending: 38, physical: 62 }, isStarting: false },
      { id: 'ala-djalo', name: 'Balu Djalo', age: 20, position: 'MID', specificRole: 'MC', overall: 69, stamina: 80, form: 7.3, marketValue: 1000000, wage: 3000, nationality: 'Gine-Bissau', attributes: { pace: 72, shooting: 60, passing: 70, defending: 66, physical: 68 }, isStarting: false },
      { id: 'ala-mikel', name: 'Mikel Rodríguez', age: 19, position: 'MID', specificRole: 'MC', overall: 68, stamina: 78, form: 7.2, marketValue: 800000, wage: 2000, nationality: 'İspanya', attributes: { pace: 70, shooting: 60, passing: 70, defending: 64, physical: 66 }, isStarting: false },
      { id: 'ala-mendes', name: 'Tomas Mendes', age: 19, position: 'MID', specificRole: 'MC', overall: 68, stamina: 78, form: 7.2, marketValue: 800000, wage: 2000, nationality: 'Gine-Bissau', attributes: { pace: 70, shooting: 58, passing: 70, defending: 65, physical: 66 }, isStarting: false },
      // Forvetler
      { id: 'ala-mariano', name: 'Mariano Díaz', age: 31, position: 'FW', specificRole: 'ST', overall: 74, stamina: 80, form: 7.4, marketValue: 2000000, wage: 10000, nationality: 'Dominik Cum.', attributes: { pace: 76, shooting: 76, passing: 60, defending: 35, physical: 78 }, isStarting: false },
      { id: 'ala-tonimartinez', name: 'Toni Martínez', age: 27, position: 'FW', specificRole: 'ST', overall: 75, stamina: 86, form: 7.7, marketValue: 4000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 76, shooting: 76, passing: 62, defending: 35, physical: 78 }, isStarting: true },
      { id: 'ala-boye', name: 'Lucas Boyé', age: 28, position: 'FW', specificRole: 'ST', overall: 76, stamina: 86, form: 7.7, marketValue: 6000000, wage: 10000, nationality: 'Arjantin', attributes: { pace: 72, shooting: 78, passing: 68, defending: 40, physical: 82 }, isStarting: true },
      { id: 'ala-manas', name: 'Aitor Mañas', age: 21, position: 'FW', specificRole: 'ST', overall: 69, stamina: 80, form: 7.3, marketValue: 1000000, wage: 3000, nationality: 'İspanya', attributes: { pace: 74, shooting: 68, passing: 58, defending: 30, physical: 70 }, isStarting: false }
    ]
  },

  // 15. RCD Espanyol (Updated per Screenshot)
  {
    id: 'espanyol',
    name: 'RCD Espanyol',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'RCDE Stadium',
    manager: 'Manolo González',
    overall: 75,
    budget: 12000000,
    badgeColor: 'from-blue-600 to-white',
    shortName: 'ESP',
    players: [
      // Kaleciler
      { id: 'esp-dmitrovic', name: 'Marko Dmitrović', age: 32, position: 'GK', specificRole: 'GK', overall: 76, stamina: 85, form: 7.7, marketValue: 3000000, wage: 10000, nationality: 'Sırbistan', attributes: { pace: 48, shooting: 15, passing: 68, defending: 76, physical: 76 }, isStarting: true },
      { id: 'esp-fortuno', name: 'Ángel Fortuño', age: 23, position: 'GK', specificRole: 'GK', overall: 71, stamina: 82, form: 7.4, marketValue: 1200000, wage: 4000, nationality: 'İspanya', attributes: { pace: 45, shooting: 15, passing: 60, defending: 71, physical: 70 }, isStarting: false },
      // Defanslar
      { id: 'esp-elhilali', name: 'Omar El Hilali', age: 20, position: 'DEF', specificRole: 'DR', overall: 75, stamina: 88, form: 7.8, marketValue: 6000000, wage: 7000, nationality: 'Fas', attributes: { pace: 80, shooting: 45, passing: 68, defending: 74, physical: 72 }, isStarting: true },
      { id: 'esp-hartman', name: 'Quilindschy Hartman', age: 22, position: 'DEF', specificRole: 'DL', overall: 77, stamina: 90, form: 8.0, marketValue: 12000000, wage: 10000, nationality: 'Hollanda', attributes: { pace: 82, shooting: 55, passing: 74, defending: 75, physical: 76 }, isStarting: true },
      { id: 'esp-cabrera', name: 'Leandro Cabrera', age: 33, position: 'DEF', specificRole: 'DC', overall: 75, stamina: 85, form: 7.6, marketValue: 2000000, wage: 10000, nationality: 'Uruguay', attributes: { pace: 60, shooting: 38, passing: 62, defending: 76, physical: 80 }, isStarting: true },
      { id: 'esp-kumbulla', name: 'Marash Kumbulla', age: 24, position: 'DEF', specificRole: 'DC', overall: 76, stamina: 86, form: 7.7, marketValue: 6000000, wage: 10000, nationality: 'Arnavutluk', attributes: { pace: 66, shooting: 35, passing: 62, defending: 77, physical: 80 }, isStarting: true },
      { id: 'esp-rubio', name: 'Miguel Rubio', age: 26, position: 'DEF', specificRole: 'DC', overall: 73, stamina: 84, form: 7.5, marketValue: 2000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 64, shooting: 35, passing: 60, defending: 74, physical: 76 }, isStarting: false },
      { id: 'esp-nazinho', name: 'Flavio Nazinho', age: 21, position: 'DEF', specificRole: 'DL', overall: 72, stamina: 84, form: 7.5, marketValue: 2500000, wage: 5000, nationality: 'Portekiz', attributes: { pace: 80, shooting: 48, passing: 65, defending: 69, physical: 68 }, isStarting: false },
      { id: 'esp-hinojo', name: 'Roger Hinojo', age: 19, position: 'DEF', specificRole: 'DL', overall: 69, stamina: 80, form: 7.3, marketValue: 1000000, wage: 3000, nationality: 'İspanya', attributes: { pace: 76, shooting: 42, passing: 62, defending: 67, physical: 66 }, isStarting: false },
      // Orta Sahalar
      { id: 'esp-aguado', name: 'Gabriel Aguado', age: 19, position: 'MID', specificRole: 'MC', overall: 72, stamina: 84, form: 7.5, marketValue: 3000000, wage: 5000, nationality: 'Brezilya', attributes: { pace: 72, shooting: 64, passing: 74, defending: 68, physical: 68 }, isStarting: false },
      { id: 'esp-puado', name: 'Javi Puado', age: 26, position: 'MID', specificRole: 'LW', overall: 76, stamina: 89, form: 7.9, marketValue: 8000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 80, shooting: 76, passing: 72, defending: 42, physical: 74 }, isStarting: true, isInjured: true, injuryType: 'Çapraz bağ', injuryWeeksLeft: 8 },
      { id: 'esp-exposito', name: 'Edu Expósito', age: 28, position: 'MID', specificRole: 'MC', overall: 75, stamina: 86, form: 7.6, marketValue: 4000000, wage: 9000, nationality: 'İspanya', attributes: { pace: 72, shooting: 70, passing: 78, defending: 68, physical: 70 }, isStarting: true },
      { id: 'esp-dolan', name: 'Tyrhys Dolan', age: 22, position: 'MID', specificRole: 'RW', overall: 74, stamina: 86, form: 7.6, marketValue: 5000000, wage: 8000, nationality: 'İngiltere', attributes: { pace: 82, shooting: 70, passing: 72, defending: 40, physical: 66 }, isStarting: false },
      { id: 'esp-milla', name: 'Pere Milla', age: 31, position: 'MID', specificRole: 'LW', overall: 74, stamina: 84, form: 7.5, marketValue: 2000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 74, shooting: 74, passing: 72, defending: 45, physical: 72 }, isStarting: false },
      { id: 'esp-lozano', name: 'Pol Lozano', age: 24, position: 'MID', specificRole: 'MC', overall: 74, stamina: 88, form: 7.6, marketValue: 4000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 72, shooting: 64, passing: 75, defending: 72, physical: 72 }, isStarting: true },
      { id: 'esp-urko', name: 'Urko González', age: 23, position: 'MID', specificRole: 'MC', overall: 73, stamina: 85, form: 7.5, marketValue: 3000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 70, shooting: 62, passing: 74, defending: 72, physical: 74 }, isStarting: true },
      { id: 'esp-calatrava', name: 'Álex Calatrava', age: 24, position: 'MID', specificRole: 'AM', overall: 73, stamina: 85, form: 7.6, marketValue: 3000000, wage: 6000, nationality: 'İspanya', attributes: { pace: 76, shooting: 70, passing: 75, defending: 42, physical: 65 }, isStarting: false },
      { id: 'esp-carreras', name: 'Jofre Carreras', age: 23, position: 'MID', specificRole: 'RW', overall: 74, stamina: 86, form: 7.6, marketValue: 4000000, wage: 7000, nationality: 'İspanya', attributes: { pace: 82, shooting: 70, passing: 72, defending: 40, physical: 66 }, isStarting: true },
      { id: 'esp-jhernandez', name: 'Javier Hernández', age: 20, position: 'MID', specificRole: 'MC', overall: 69, stamina: 80, form: 7.3, marketValue: 1200000, wage: 3000, nationality: 'İspanya', attributes: { pace: 70, shooting: 62, passing: 71, defending: 62, physical: 64 }, isStarting: false },
      { id: 'esp-roca', name: 'Antoniu Roca', age: 21, position: 'MID', specificRole: 'MC', overall: 69, stamina: 80, form: 7.3, marketValue: 1200000, wage: 3000, nationality: 'İspanya', attributes: { pace: 72, shooting: 64, passing: 70, defending: 55, physical: 64 }, isStarting: false },
      // Forvetler
      { id: 'esp-roberto', name: 'Roberto Fernández', age: 22, position: 'FW', specificRole: 'ST', overall: 74, stamina: 85, form: 7.6, marketValue: 4000000, wage: 7000, nationality: 'İspanya', attributes: { pace: 76, shooting: 74, passing: 62, defending: 35, physical: 76 }, isStarting: true },
      { id: 'esp-kikegarcia', name: 'Kike García', age: 34, position: 'FW', specificRole: 'ST', overall: 75, stamina: 82, form: 7.6, marketValue: 2000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 68, shooting: 76, passing: 64, defending: 40, physical: 82 }, isStarting: false },
      { id: 'esp-mfernandez', name: 'Marcos Fernández', age: 21, position: 'FW', specificRole: 'ST', overall: 69, stamina: 80, form: 7.3, marketValue: 1200000, wage: 3000, nationality: 'İspanya', attributes: { pace: 74, shooting: 68, passing: 58, defending: 30, physical: 70 }, isStarting: false }
    ]
  },

  // 16. Málaga CF
  {
    id: 'malaga',
    name: 'Málaga CF',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'La Rosaleda',
    manager: 'Sergio Pellicer',
    overall: 76,
    budget: 15000000,
    badgeColor: 'from-sky-500 to-white',
    shortName: 'MAL',
    players: [
      { id: 'mal-1', name: 'Alfonso Herrero', age: 30, position: 'GK', specificRole: 'GK', overall: 77, stamina: 88, form: 8.0, marketValue: 3500000, wage: 12000, nationality: 'İspanya', attributes: { pace: 50, shooting: 15, passing: 68, defending: 78, physical: 76 }, isStarting: true },
      { id: 'mal-2', name: 'Einar Galilea', age: 30, position: 'DEF', specificRole: 'CB', overall: 75, stamina: 86, form: 7.8, marketValue: 2500000, wage: 10000, nationality: 'İspanya', attributes: { pace: 64, shooting: 35, passing: 66, defending: 76, physical: 80 }, isStarting: true },
      { id: 'mal-3', name: 'Nelson Monte', age: 29, position: 'DEF', specificRole: 'CB', overall: 76, stamina: 87, form: 7.9, marketValue: 3000000, wage: 12000, nationality: 'Portekiz', attributes: { pace: 68, shooting: 38, passing: 68, defending: 77, physical: 80 }, isStarting: true },
      { id: 'mal-4', name: 'Carlos Puga', age: 23, position: 'DEF', specificRole: 'RB', overall: 74, stamina: 89, form: 7.7, marketValue: 2000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 82, shooting: 50, passing: 70, defending: 73, physical: 72 }, isStarting: true },
      { id: 'mal-5', name: 'Dani Sánchez', age: 24, position: 'DEF', specificRole: 'LB', overall: 74, stamina: 88, form: 7.7, marketValue: 2000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 80, shooting: 52, passing: 70, defending: 73, physical: 70 }, isStarting: true },
      { id: 'mal-6', name: 'Luismi', age: 31, position: 'MID', specificRole: 'CDM', overall: 76, stamina: 89, form: 7.8, marketValue: 2500000, wage: 11000, nationality: 'İspanya', attributes: { pace: 66, shooting: 60, passing: 75, defending: 77, physical: 80 }, isStarting: true },
      { id: 'mal-7', name: 'Manu Molina', age: 32, position: 'MID', specificRole: 'CM', overall: 76, stamina: 88, form: 7.9, marketValue: 2500000, wage: 12000, nationality: 'İspanya', attributes: { pace: 68, shooting: 68, passing: 80, defending: 72, physical: 72 }, isStarting: true },
      { id: 'mal-8', name: 'David Larrubia', age: 22, position: 'MID', specificRole: 'CAM', overall: 76, stamina: 90, form: 8.1, marketValue: 5000000, wage: 9000, nationality: 'İspanya', attributes: { pace: 80, shooting: 74, passing: 78, defending: 48, physical: 68 }, isStarting: true },
      { id: 'mal-9', name: 'Kevin Medina', age: 23, position: 'FW', specificRole: 'LW', overall: 76, stamina: 89, form: 8.0, marketValue: 4000000, wage: 9000, nationality: 'İspanya', attributes: { pace: 86, shooting: 74, passing: 74, defending: 42, physical: 68 }, isStarting: true },
      { id: 'mal-10', name: 'Antonio Cordero', age: 17, position: 'FW', specificRole: 'RW', overall: 76, stamina: 91, form: 8.2, marketValue: 6000000, wage: 7000, nationality: 'İspanya', attributes: { pace: 88, shooting: 75, passing: 76, defending: 40, physical: 66 }, isStarting: true },
      { id: 'mal-11', name: 'Dioni', age: 34, position: 'FW', specificRole: 'ST', overall: 75, stamina: 82, form: 7.7, marketValue: 1500000, wage: 10000, nationality: 'İspanya', attributes: { pace: 70, shooting: 78, passing: 66, defending: 36, physical: 76 }, isStarting: true },
      { id: 'mal-12', name: 'Carlos López', age: 19, position: 'GK', specificRole: 'GK', overall: 71, stamina: 84, form: 7.5, marketValue: 1000000, wage: 4000, nationality: 'İspanya', attributes: { pace: 48, shooting: 15, passing: 62, defending: 72, physical: 72 }, isStarting: false },
      { id: 'mal-13', name: 'Diego Murillo', age: 23, position: 'DEF', specificRole: 'CB', overall: 73, stamina: 86, form: 7.6, marketValue: 1500000, wage: 6000, nationality: 'İspanya', attributes: { pace: 70, shooting: 35, passing: 64, defending: 74, physical: 76 }, isStarting: false },
      { id: 'mal-14', name: 'Victor García', age: 27, position: 'DEF', specificRole: 'LB', overall: 73, stamina: 86, form: 7.6, marketValue: 1500000, wage: 7000, nationality: 'İspanya', attributes: { pace: 78, shooting: 48, passing: 68, defending: 72, physical: 70 }, isStarting: false },
      { id: 'mal-15', name: 'Izan Merino', age: 18, position: 'MID', specificRole: 'CDM', overall: 73, stamina: 88, form: 7.7, marketValue: 3000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 72, shooting: 58, passing: 73, defending: 74, physical: 76 }, isStarting: false },
      { id: 'mal-16', name: 'Dani Lorenzo', age: 21, position: 'MID', specificRole: 'CM', overall: 74, stamina: 88, form: 7.8, marketValue: 2500000, wage: 7000, nationality: 'İspanya', attributes: { pace: 74, shooting: 68, passing: 76, defending: 66, physical: 70 }, isStarting: false },
      { id: 'mal-17', name: 'Aaron Ochoa', age: 17, position: 'MID', specificRole: 'CAM', overall: 72, stamina: 86, form: 7.6, marketValue: 2500000, wage: 4000, nationality: 'İrlanda', attributes: { pace: 78, shooting: 70, passing: 74, defending: 42, physical: 62 }, isStarting: false },
      { id: 'mal-18', name: 'Julen Lobete', age: 24, position: 'FW', specificRole: 'RW', overall: 74, stamina: 88, form: 7.7, marketValue: 2200000, wage: 8000, nationality: 'İspanya', attributes: { pace: 82, shooting: 74, passing: 71, defending: 40, physical: 70 }, isStarting: false },
      { id: 'mal-19', name: 'Roko Baturina', age: 24, position: 'FW', specificRole: 'ST', overall: 74, stamina: 86, form: 7.6, marketValue: 2000000, wage: 8000, nationality: 'Hırvatistan', attributes: { pace: 74, shooting: 76, passing: 64, defending: 36, physical: 80 }, isStarting: false },
      { id: 'mal-20', name: 'Álex Pastor', age: 24, position: 'DEF', specificRole: 'CB', overall: 73, stamina: 86, form: 7.6, marketValue: 1600000, wage: 6000, nationality: 'İspanya', attributes: { pace: 68, shooting: 36, passing: 65, defending: 74, physical: 78 }, isStarting: false }
    ]
  },

  // 17. Racing de Santander
  {
    id: 'racing-santander',
    name: 'Racing de Santander',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'El Sardinero',
    manager: 'José Alberto López',
    overall: 77,
    budget: 14000000,
    badgeColor: 'from-emerald-600 to-white',
    shortName: 'RAC',
    players: [
      { id: 'rac-1', name: 'Jokin Ezkieta', age: 28, position: 'GK', specificRole: 'GK', overall: 78, stamina: 88, form: 8.2, marketValue: 4500000, wage: 13000, nationality: 'İspanya', attributes: { pace: 50, shooting: 15, passing: 70, defending: 78, physical: 80 }, isStarting: true },
      { id: 'rac-2', name: 'Manu Hernando', age: 26, position: 'DEF', specificRole: 'CB', overall: 76, stamina: 88, form: 7.9, marketValue: 3500000, wage: 11000, nationality: 'İspanya', attributes: { pace: 68, shooting: 40, passing: 68, defending: 77, physical: 80 }, isStarting: true },
      { id: 'rac-3', name: 'Javier Castro', age: 24, position: 'DEF', specificRole: 'CB', overall: 75, stamina: 88, form: 7.8, marketValue: 3000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 70, shooting: 36, passing: 66, defending: 76, physical: 78 }, isStarting: true },
      { id: 'rac-4', name: 'Clément Michelin', age: 27, position: 'DEF', specificRole: 'RB', overall: 76, stamina: 90, form: 8.0, marketValue: 3500000, wage: 12000, nationality: 'Fransa', attributes: { pace: 82, shooting: 55, passing: 74, defending: 74, physical: 75 }, isStarting: true },
      { id: 'rac-5', name: 'Saúl García', age: 29, position: 'DEF', specificRole: 'LB', overall: 76, stamina: 90, form: 8.0, marketValue: 3000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 80, shooting: 56, passing: 76, defending: 74, physical: 74 }, isStarting: true },
      { id: 'rac-6', name: 'Íñigo Sainz-Maza', age: 26, position: 'MID', specificRole: 'CDM', overall: 76, stamina: 91, form: 7.9, marketValue: 3500000, wage: 11000, nationality: 'İspanya', attributes: { pace: 70, shooting: 62, passing: 76, defending: 77, physical: 79 }, isStarting: true },
      { id: 'rac-7', name: 'Aritz Aldasoro', age: 25, position: 'MID', specificRole: 'CM', overall: 76, stamina: 91, form: 8.0, marketValue: 4000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 74, shooting: 70, passing: 78, defending: 74, physical: 78 }, isStarting: true },
      { id: 'rac-8', name: 'Pablo Rodríguez', age: 23, position: 'MID', specificRole: 'CAM', overall: 76, stamina: 89, form: 8.0, marketValue: 4500000, wage: 11000, nationality: 'İspanya', attributes: { pace: 80, shooting: 75, passing: 78, defending: 46, physical: 68 }, isStarting: true },
      { id: 'rac-9', name: 'Iñigo Vicente', age: 26, position: 'FW', specificRole: 'LW', overall: 80, stamina: 92, form: 8.6, marketValue: 10000000, wage: 18000, nationality: 'İspanya', attributes: { pace: 82, shooting: 79, passing: 85, defending: 45, physical: 70 }, isStarting: true },
      { id: 'rac-10', name: 'Andrés Martín', age: 25, position: 'FW', specificRole: 'RW', overall: 79, stamina: 91, form: 8.5, marketValue: 8000000, wage: 16000, nationality: 'İspanya', attributes: { pace: 85, shooting: 80, passing: 78, defending: 44, physical: 72 }, isStarting: true },
      { id: 'rac-11', name: 'Juan Carlos Arana', age: 24, position: 'FW', specificRole: 'ST', overall: 78, stamina: 90, form: 8.3, marketValue: 6000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 80, shooting: 80, passing: 68, defending: 38, physical: 80 }, isStarting: true },
      { id: 'rac-12', name: 'Miquel Parera', age: 28, position: 'GK', specificRole: 'GK', overall: 73, stamina: 85, form: 7.6, marketValue: 1500000, wage: 7000, nationality: 'İspanya', attributes: { pace: 48, shooting: 15, passing: 64, defending: 74, physical: 75 }, isStarting: false },
      { id: 'rac-13', name: 'Pol Moreno', age: 30, position: 'DEF', specificRole: 'CB', overall: 73, stamina: 85, form: 7.5, marketValue: 1500000, wage: 7000, nationality: 'İspanya', attributes: { pace: 64, shooting: 35, passing: 64, defending: 74, physical: 80 }, isStarting: false },
      { id: 'rac-14', name: 'Mario García', age: 20, position: 'DEF', specificRole: 'LB', overall: 74, stamina: 88, form: 7.8, marketValue: 2500000, wage: 6000, nationality: 'İspanya', attributes: { pace: 82, shooting: 50, passing: 71, defending: 73, physical: 71 }, isStarting: false },
      { id: 'rac-15', name: 'Unai Vencedor', age: 23, position: 'MID', specificRole: 'CM', overall: 76, stamina: 89, form: 7.9, marketValue: 5000000, wage: 13000, nationality: 'İspanya', attributes: { pace: 70, shooting: 68, passing: 80, defending: 74, physical: 74 }, isStarting: false },
      { id: 'rac-16', name: 'Maguette Gueye', age: 21, position: 'MID', specificRole: 'CDM', overall: 74, stamina: 90, form: 7.8, marketValue: 3000000, wage: 7000, nationality: 'Senegal', attributes: { pace: 74, shooting: 62, passing: 73, defending: 76, physical: 82 }, isStarting: false },
      { id: 'rac-17', name: 'Marco Sangalli', age: 32, position: 'FW', specificRole: 'RW', overall: 74, stamina: 86, form: 7.6, marketValue: 1500000, wage: 9000, nationality: 'İspanya', attributes: { pace: 78, shooting: 71, passing: 74, defending: 55, physical: 72 }, isStarting: false },
      { id: 'rac-18', name: 'Suleiman Camara', age: 22, position: 'FW', specificRole: 'LW', overall: 74, stamina: 89, form: 7.8, marketValue: 2500000, wage: 6000, nationality: 'İspanya', attributes: { pace: 86, shooting: 72, passing: 70, defending: 40, physical: 68 }, isStarting: false },
      { id: 'rac-19', name: 'Ekain Zenitagoia', age: 30, position: 'FW', specificRole: 'ST', overall: 74, stamina: 85, form: 7.6, marketValue: 1800000, wage: 8000, nationality: 'İspanya', attributes: { pace: 76, shooting: 75, passing: 66, defending: 42, physical: 76 }, isStarting: false },
      { id: 'rac-20', name: 'Javi Castro', age: 24, position: 'DEF', specificRole: 'RB', overall: 73, stamina: 86, form: 7.6, marketValue: 1800000, wage: 6000, nationality: 'İspanya', attributes: { pace: 78, shooting: 48, passing: 68, defending: 73, physical: 74 }, isStarting: false }
    ]
  },

  // 18. Deportivo
  {
    id: 'deportivo',
    name: 'Deportivo',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Estadio Riazor',
    manager: 'Óscar Gilsanz',
    overall: 76,
    budget: 16000000,
    badgeColor: 'from-blue-600 to-white',
    shortName: 'DEP',
    players: [
      { id: 'dep-1', name: 'Helton Leite', age: 33, position: 'GK', specificRole: 'GK', overall: 77, stamina: 86, form: 8.0, marketValue: 3000000, wage: 13000, nationality: 'Brezilya', attributes: { pace: 48, shooting: 15, passing: 68, defending: 78, physical: 80 }, isStarting: true },
      { id: 'dep-2', name: 'Pablo Vázquez', age: 30, position: 'DEF', specificRole: 'CB', overall: 75, stamina: 87, form: 7.8, marketValue: 2500000, wage: 11000, nationality: 'İspanya', attributes: { pace: 64, shooting: 40, passing: 66, defending: 76, physical: 82 }, isStarting: true },
      { id: 'dep-3', name: 'Dani Barcia', age: 21, position: 'DEF', specificRole: 'CB', overall: 75, stamina: 89, form: 8.0, marketValue: 3500000, wage: 8000, nationality: 'İspanya', attributes: { pace: 72, shooting: 38, passing: 74, defending: 76, physical: 78 }, isStarting: true },
      { id: 'dep-4', name: 'Ximo Navarro', age: 34, position: 'DEF', specificRole: 'RB', overall: 75, stamina: 85, form: 7.7, marketValue: 1500000, wage: 11000, nationality: 'İspanya', attributes: { pace: 76, shooting: 50, passing: 70, defending: 75, physical: 76 }, isStarting: true },
      { id: 'dep-5', name: 'Rafael Obrador', age: 20, position: 'DEF', specificRole: 'LB', overall: 75, stamina: 90, form: 7.9, marketValue: 3000000, wage: 7000, nationality: 'İspanya', attributes: { pace: 84, shooting: 52, passing: 72, defending: 74, physical: 72 }, isStarting: true },
      { id: 'dep-6', name: 'Diego Villares', age: 28, position: 'MID', specificRole: 'CDM', overall: 76, stamina: 93, form: 8.0, marketValue: 4000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 74, shooting: 65, passing: 76, defending: 78, physical: 80 }, isStarting: true },
      { id: 'dep-7', name: 'José Ángel Jurado', age: 32, position: 'MID', specificRole: 'CM', overall: 75, stamina: 86, form: 7.7, marketValue: 2000000, wage: 11000, nationality: 'İspanya', attributes: { pace: 66, shooting: 68, passing: 79, defending: 74, physical: 76 }, isStarting: true },
      { id: 'dep-8', name: 'Mario Soriano', age: 23, position: 'MID', specificRole: 'CAM', overall: 77, stamina: 90, form: 8.1, marketValue: 5500000, wage: 12000, nationality: 'İspanya', attributes: { pace: 80, shooting: 75, passing: 82, defending: 50, physical: 68 }, isStarting: true },
      { id: 'dep-9', name: 'Yeremay Hernández', age: 21, position: 'FW', specificRole: 'LW', overall: 79, stamina: 92, form: 8.6, marketValue: 12000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 88, shooting: 78, passing: 80, defending: 40, physical: 68 }, isStarting: true },
      { id: 'dep-10', name: 'David Mella', age: 19, position: 'FW', specificRole: 'RW', overall: 77, stamina: 93, form: 8.3, marketValue: 8000000, wage: 10000, nationality: 'İspanya', attributes: { pace: 90, shooting: 75, passing: 75, defending: 45, physical: 70 }, isStarting: true },
      { id: 'dep-11', name: 'Lucas Pérez', age: 35, position: 'FW', specificRole: 'ST', overall: 78, stamina: 83, form: 8.2, marketValue: 2500000, wage: 18000, nationality: 'İspanya', attributes: { pace: 74, shooting: 83, passing: 80, defending: 45, physical: 76 }, isStarting: true },
      { id: 'dep-12', name: 'Germán Parreño', age: 31, position: 'GK', specificRole: 'GK', overall: 73, stamina: 84, form: 7.5, marketValue: 1200000, wage: 7000, nationality: 'İspanya', attributes: { pace: 46, shooting: 15, passing: 64, defending: 73, physical: 76 }, isStarting: false },
      { id: 'dep-13', name: 'Pablo Martínez', age: 35, position: 'DEF', specificRole: 'CB', overall: 74, stamina: 84, form: 7.6, marketValue: 1200000, wage: 8000, nationality: 'Fransa', attributes: { pace: 64, shooting: 36, passing: 68, defending: 75, physical: 80 }, isStarting: false },
      { id: 'dep-14', name: 'Alex Petxarroman', age: 27, position: 'DEF', specificRole: 'RB', overall: 74, stamina: 88, form: 7.7, marketValue: 2000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 80, shooting: 52, passing: 72, defending: 73, physical: 72 }, isStarting: false },
      { id: 'dep-15', name: 'Charlie Patiño', age: 20, position: 'MID', specificRole: 'CM', overall: 74, stamina: 88, form: 7.7, marketValue: 4000000, wage: 8000, nationality: 'İngiltere', attributes: { pace: 70, shooting: 68, passing: 79, defending: 68, physical: 70 }, isStarting: false },
      { id: 'dep-16', name: 'Hugo Rama', age: 27, position: 'MID', specificRole: 'CM', overall: 73, stamina: 86, form: 7.6, marketValue: 1800000, wage: 7000, nationality: 'İspanya', attributes: { pace: 72, shooting: 70, passing: 76, defending: 66, physical: 70 }, isStarting: false },
      { id: 'dep-17', name: 'Cristian Herrera', age: 33, position: 'FW', specificRole: 'RW', overall: 73, stamina: 83, form: 7.5, marketValue: 1200000, wage: 8000, nationality: 'İspanya', attributes: { pace: 76, shooting: 74, passing: 70, defending: 40, physical: 72 }, isStarting: false },
      { id: 'dep-18', name: 'Ivan Barbero', age: 26, position: 'FW', specificRole: 'ST', overall: 74, stamina: 86, form: 7.7, marketValue: 2000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 76, shooting: 76, passing: 64, defending: 38, physical: 80 }, isStarting: false },
      { id: 'dep-19', name: 'Davo', age: 29, position: 'FW', specificRole: 'LW', overall: 73, stamina: 86, form: 7.6, marketValue: 1500000, wage: 7000, nationality: 'İspanya', attributes: { pace: 80, shooting: 72, passing: 70, defending: 42, physical: 70 }, isStarting: false },
      { id: 'dep-20', name: 'Jaime Sánchez', age: 29, position: 'DEF', specificRole: 'CB', overall: 73, stamina: 85, form: 7.5, marketValue: 1400000, wage: 7000, nationality: 'İspanya', attributes: { pace: 66, shooting: 35, passing: 64, defending: 74, physical: 78 }, isStarting: false }
    ]
  },

  // 19. Elche
  {
    id: 'elche',
    name: 'Elche',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Estadio Manuel Martínez Valero',
    manager: 'Eder Sarabia',
    overall: 76,
    budget: 15000000,
    badgeColor: 'from-emerald-700 to-white',
    shortName: 'ELC',
    players: [
      { id: 'elc-1', name: 'Matías Dituro', age: 37, position: 'GK', specificRole: 'GK', overall: 76, stamina: 82, form: 7.9, marketValue: 1800000, wage: 12000, nationality: 'Arjantin', attributes: { pace: 46, shooting: 15, passing: 72, defending: 77, physical: 76 }, isStarting: true },
      { id: 'elc-2', name: 'Pedro Bigas', age: 34, position: 'DEF', specificRole: 'CB', overall: 76, stamina: 85, form: 7.8, marketValue: 2000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 65, shooting: 40, passing: 70, defending: 77, physical: 80 }, isStarting: true },
      { id: 'elc-3', name: 'David Affengruber', age: 23, position: 'DEF', specificRole: 'CB', overall: 76, stamina: 89, form: 8.0, marketValue: 4500000, wage: 10000, nationality: 'Avusturya', attributes: { pace: 70, shooting: 38, passing: 70, defending: 77, physical: 82 }, isStarting: true },
      { id: 'elc-4', name: 'Álvaro Núñez', age: 24, position: 'DEF', specificRole: 'RB', overall: 75, stamina: 91, form: 7.9, marketValue: 3000000, wage: 9000, nationality: 'İspanya', attributes: { pace: 82, shooting: 52, passing: 74, defending: 74, physical: 73 }, isStarting: true },
      { id: 'elc-5', name: 'José Salinas', age: 23, position: 'DEF', specificRole: 'LB', overall: 75, stamina: 90, form: 7.8, marketValue: 3000000, wage: 9000, nationality: 'İspanya', attributes: { pace: 82, shooting: 54, passing: 73, defending: 73, physical: 73 }, isStarting: true },
      { id: 'elc-6', name: 'Aleix Febas', age: 28, position: 'MID', specificRole: 'CM', overall: 77, stamina: 92, form: 8.2, marketValue: 5000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 78, shooting: 70, passing: 82, defending: 72, physical: 74 }, isStarting: true },
      { id: 'elc-7', name: 'Nicolás Castro', age: 23, position: 'MID', specificRole: 'CM', overall: 76, stamina: 90, form: 8.0, marketValue: 4500000, wage: 11000, nationality: 'Arjantin', attributes: { pace: 74, shooting: 74, passing: 79, defending: 70, physical: 76 }, isStarting: true },
      { id: 'elc-8', name: 'Gerard Hernández', age: 19, position: 'MID', specificRole: 'CDM', overall: 74, stamina: 89, form: 7.8, marketValue: 3500000, wage: 6000, nationality: 'İspanya', attributes: { pace: 70, shooting: 60, passing: 76, defending: 75, physical: 74 }, isStarting: true },
      { id: 'elc-9', name: 'Josan', age: 34, position: 'FW', specificRole: 'RW', overall: 75, stamina: 85, form: 7.7, marketValue: 1800000, wage: 11000, nationality: 'İspanya', attributes: { pace: 80, shooting: 72, passing: 74, defending: 50, physical: 70 }, isStarting: true },
      { id: 'elc-10', name: 'Nicolás Fernández Mercau', age: 24, position: 'FW', specificRole: 'LW', overall: 77, stamina: 91, form: 8.1, marketValue: 5500000, wage: 12000, nationality: 'Arjantin', attributes: { pace: 82, shooting: 76, passing: 78, defending: 55, physical: 75 }, isStarting: true },
      { id: 'elc-11', name: 'Agustín Álvarez', age: 23, position: 'FW', specificRole: 'ST', overall: 76, stamina: 89, form: 8.0, marketValue: 5000000, wage: 12000, nationality: 'Uruguay', attributes: { pace: 80, shooting: 79, passing: 68, defending: 38, physical: 78 }, isStarting: true },
      { id: 'elc-12', name: 'Miguel San Román', age: 27, position: 'GK', specificRole: 'GK', overall: 73, stamina: 85, form: 7.5, marketValue: 1500000, wage: 7000, nationality: 'İspanya', attributes: { pace: 48, shooting: 15, passing: 64, defending: 73, physical: 74 }, isStarting: false },
      { id: 'elc-13', name: 'Bambo Diaby', age: 26, position: 'DEF', specificRole: 'CB', overall: 74, stamina: 87, form: 7.6, marketValue: 2200000, wage: 8000, nationality: 'Senegal', attributes: { pace: 76, shooting: 35, passing: 62, defending: 74, physical: 84 }, isStarting: false },
      { id: 'elc-14', name: 'Mario Gaspar', age: 33, position: 'DEF', specificRole: 'CB', overall: 74, stamina: 84, form: 7.5, marketValue: 1500000, wage: 9000, nationality: 'İspanya', attributes: { pace: 68, shooting: 50, passing: 70, defending: 75, physical: 78 }, isStarting: false },
      { id: 'elc-15', name: 'Rodrigo Mendoza', age: 19, position: 'MID', specificRole: 'CM', overall: 74, stamina: 88, form: 7.8, marketValue: 3500000, wage: 6000, nationality: 'İspanya', attributes: { pace: 74, shooting: 68, passing: 77, defending: 68, physical: 70 }, isStarting: false },
      { id: 'elc-16', name: 'Raúl Guti', age: 27, position: 'MID', specificRole: 'CM', overall: 74, stamina: 88, form: 7.7, marketValue: 2500000, wage: 9000, nationality: 'İspanya', attributes: { pace: 72, shooting: 68, passing: 76, defending: 72, physical: 74 }, isStarting: false },
      { id: 'elc-17', name: 'Yago Santiago', age: 21, position: 'FW', specificRole: 'LW', overall: 74, stamina: 89, form: 7.8, marketValue: 3000000, wage: 7000, nationality: 'İspanya', attributes: { pace: 86, shooting: 72, passing: 72, defending: 40, physical: 66 }, isStarting: false },
      { id: 'elc-18', name: 'Mourad El Ghezouani', age: 26, position: 'FW', specificRole: 'ST', overall: 74, stamina: 87, form: 7.7, marketValue: 2500000, wage: 8000, nationality: 'Fas', attributes: { pace: 74, shooting: 76, passing: 62, defending: 42, physical: 84 }, isStarting: false },
      { id: 'elc-19', name: 'Sory Kaba', age: 29, position: 'FW', specificRole: 'ST', overall: 74, stamina: 86, form: 7.6, marketValue: 2500000, wage: 10000, nationality: 'Gine', attributes: { pace: 76, shooting: 76, passing: 64, defending: 40, physical: 84 }, isStarting: false },
      { id: 'elc-20', name: 'John Nwankwo', age: 24, position: 'MID', specificRole: 'CDM', overall: 73, stamina: 87, form: 7.5, marketValue: 2000000, wage: 7000, nationality: 'Nijerya', attributes: { pace: 70, shooting: 58, passing: 72, defending: 75, physical: 80 }, isStarting: false }
    ]
  },

  // 20. Levante UD
  {
    id: 'levante',
    name: 'Levante UD',
    country: 'İspanya',
    flag: '🇪🇸',
    stadium: 'Estadi Ciutat de València',
    manager: 'Julián Calero',
    overall: 77,
    budget: 16000000,
    badgeColor: 'from-red-700 to-blue-700',
    shortName: 'LEV',
    players: [
      { id: 'lev-1', name: 'Andrés Fernández', age: 37, position: 'GK', specificRole: 'GK', overall: 76, stamina: 82, form: 7.9, marketValue: 1500000, wage: 12000, nationality: 'İspanya', attributes: { pace: 46, shooting: 15, passing: 68, defending: 77, physical: 76 }, isStarting: true },
      { id: 'lev-2', name: 'Unai Elgezabal', age: 31, position: 'DEF', specificRole: 'CB', overall: 76, stamina: 88, form: 7.9, marketValue: 2500000, wage: 12000, nationality: 'İspanya', attributes: { pace: 66, shooting: 42, passing: 68, defending: 77, physical: 82 }, isStarting: true },
      { id: 'lev-3', name: 'Adrián de la Fuente', age: 25, position: 'DEF', specificRole: 'CB', overall: 76, stamina: 89, form: 8.0, marketValue: 3500000, wage: 11000, nationality: 'İspanya', attributes: { pace: 70, shooting: 40, passing: 68, defending: 77, physical: 80 }, isStarting: true },
      { id: 'lev-4', name: 'Andrés García', age: 21, position: 'DEF', specificRole: 'RB', overall: 76, stamina: 92, form: 8.1, marketValue: 5000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 86, shooting: 60, passing: 74, defending: 74, physical: 74 }, isStarting: true },
      { id: 'lev-5', name: 'Diego Pampín', age: 24, position: 'DEF', specificRole: 'LB', overall: 75, stamina: 90, form: 7.8, marketValue: 3000000, wage: 9000, nationality: 'İspanya', attributes: { pace: 82, shooting: 54, passing: 73, defending: 74, physical: 73 }, isStarting: true },
      { id: 'lev-6', name: 'Oriol Rey', age: 26, position: 'MID', specificRole: 'CDM', overall: 76, stamina: 91, form: 8.0, marketValue: 4000000, wage: 12000, nationality: 'İspanya', attributes: { pace: 70, shooting: 62, passing: 78, defending: 78, physical: 78 }, isStarting: true },
      { id: 'lev-7', name: 'Giorgi Kochorashvili', age: 25, position: 'MID', specificRole: 'CM', overall: 79, stamina: 93, form: 8.5, marketValue: 9000000, wage: 16000, nationality: 'Gürcistan', attributes: { pace: 76, shooting: 78, passing: 81, defending: 77, physical: 82 }, isStarting: true },
      { id: 'lev-8', name: 'Pablo Martínez', age: 26, position: 'MID', specificRole: 'CAM', overall: 77, stamina: 91, form: 8.1, marketValue: 5500000, wage: 13000, nationality: 'İspanya', attributes: { pace: 76, shooting: 76, passing: 80, defending: 68, physical: 76 }, isStarting: true },
      { id: 'lev-9', name: 'Carlos Álvarez', age: 21, position: 'FW', specificRole: 'RW', overall: 79, stamina: 91, form: 8.5, marketValue: 10000000, wage: 14000, nationality: 'İspanya', attributes: { pace: 84, shooting: 78, passing: 84, defending: 46, physical: 66 }, isStarting: true },
      { id: 'lev-10', name: 'José Luis Morales', age: 37, position: 'FW', specificRole: 'LW', overall: 77, stamina: 84, form: 8.1, marketValue: 2000000, wage: 16000, nationality: 'İspanya', attributes: { pace: 80, shooting: 80, passing: 75, defending: 45, physical: 72 }, isStarting: true },
      { id: 'lev-11', name: 'Fabrício Santos', age: 23, position: 'FW', specificRole: 'ST', overall: 76, stamina: 89, form: 8.0, marketValue: 4500000, wage: 11000, nationality: 'Brezilya', attributes: { pace: 82, shooting: 78, passing: 66, defending: 38, physical: 82 }, isStarting: true },
      { id: 'lev-12', name: 'Alfonso Pastor', age: 23, position: 'GK', specificRole: 'GK', overall: 72, stamina: 84, form: 7.5, marketValue: 1200000, wage: 5000, nationality: 'İspanya', attributes: { pace: 46, shooting: 15, passing: 62, defending: 72, physical: 74 }, isStarting: false },
      { id: 'lev-13', name: 'Jorge Cabello', age: 20, position: 'DEF', specificRole: 'CB', overall: 74, stamina: 88, form: 7.7, marketValue: 2500000, wage: 6000, nationality: 'İspanya', attributes: { pace: 72, shooting: 36, passing: 66, defending: 75, physical: 76 }, isStarting: false },
      { id: 'lev-14', name: 'Xavi Grande', age: 19, position: 'DEF', specificRole: 'RB', overall: 73, stamina: 88, form: 7.6, marketValue: 2000000, wage: 5000, nationality: 'İspanya', attributes: { pace: 82, shooting: 48, passing: 68, defending: 72, physical: 70 }, isStarting: false },
      { id: 'lev-15', name: 'Vicente Iborra', age: 36, position: 'MID', specificRole: 'CDM', overall: 75, stamina: 83, form: 7.7, marketValue: 1500000, wage: 12000, nationality: 'İspanya', attributes: { pace: 58, shooting: 70, passing: 76, defending: 78, physical: 86 }, isStarting: false },
      { id: 'lev-16', name: 'Ángel Algobia', age: 25, position: 'MID', specificRole: 'CM', overall: 74, stamina: 88, form: 7.7, marketValue: 2500000, wage: 8000, nationality: 'İspanya', attributes: { pace: 72, shooting: 66, passing: 76, defending: 74, physical: 76 }, isStarting: false },
      { id: 'lev-17', name: 'Brugui', age: 27, position: 'FW', specificRole: 'LW', overall: 76, stamina: 89, form: 7.9, marketValue: 3500000, wage: 10000, nationality: 'İspanya', attributes: { pace: 84, shooting: 76, passing: 74, defending: 48, physical: 72 }, isStarting: false },
      { id: 'lev-18', name: 'Rober Ibáñez', age: 31, position: 'FW', specificRole: 'RW', overall: 74, stamina: 85, form: 7.6, marketValue: 1800000, wage: 9000, nationality: 'İspanya', attributes: { pace: 80, shooting: 73, passing: 74, defending: 44, physical: 68 }, isStarting: false },
      { id: 'lev-19', name: 'Iván Romero', age: 23, position: 'FW', specificRole: 'ST', overall: 75, stamina: 89, form: 7.8, marketValue: 3000000, wage: 8000, nationality: 'İspanya', attributes: { pace: 80, shooting: 76, passing: 70, defending: 44, physical: 74 }, isStarting: false },
      { id: 'lev-20', name: 'Carlos Espí', age: 19, position: 'FW', specificRole: 'ST', overall: 73, stamina: 87, form: 7.7, marketValue: 2500000, wage: 5000, nationality: 'İspanya', attributes: { pace: 76, shooting: 75, passing: 62, defending: 36, physical: 84 }, isStarting: false }
    ]
  }
];
