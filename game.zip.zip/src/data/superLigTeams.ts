import { Team, Player, LeagueRow } from '../types';
import { getTeamLogoUrl } from './teamLogos';

// Preferred team mapping for known key players
const PLAYER_PREFERRED_TEAM_MAP: Record<string, string> = {
  'Uğurcan Çakır': 'galatasaray',
  'Ferdi Kadıoğlu': 'fenerbahce',
  'Eren Elmalı': 'galatasaray',
  'Yasin Özcan': 'besiktas',
  'Pedrinho': 'kocaelispor',
  'Halil İbrahim Pehlivan': 'genclerbirligi',
  'Mame Thiam': 'corumfk',
  'Ahmed Kutucu': 'rizespor',
  'Umut Meraş': 'amedfk',
  'Erhan Erentürk': 'corumfk',
  'Ertuğrul Taşkıran': 'erzurumspor'
};

/**
 * Validation and deduplication function for Süper Lig Teams & Players
 */
export function validateAndDeduplicateTeams(rawTeams: Team[]): Team[] {
  const globalSeenPlayers = new Set<string>();
  const playerPrimaryTeamMap = new Map<string, string>();

  // Pass 1: Assign primary team for every player
  rawTeams.forEach(team => {
    team.players.forEach(p => {
      const cleanName = p.name.trim();
      if (!playerPrimaryTeamMap.has(cleanName)) {
        if (PLAYER_PREFERRED_TEAM_MAP[cleanName]) {
          playerPrimaryTeamMap.set(cleanName, PLAYER_PREFERRED_TEAM_MAP[cleanName]);
        } else {
          playerPrimaryTeamMap.set(cleanName, team.id);
        }
      }
    });
  });

  // Pass 2: Filter and sanitize team rosters
  return rawTeams.map(team => {
    const uniqueTeamPlayers: Player[] = [];
    const teamSeenNames = new Set<string>();

    team.players.forEach((p, index) => {
      const cleanName = p.name.trim();
      const primaryTeamId = playerPrimaryTeamMap.get(cleanName) || team.id;

      if (primaryTeamId === team.id && !teamSeenNames.has(cleanName) && !globalSeenPlayers.has(cleanName)) {
        teamSeenNames.add(cleanName);
        globalSeenPlayers.add(cleanName);

        const slug = cleanName.toLowerCase().replace(/[^a-z0-9]/g, '');
        const playerUniqueId = `${team.id}-${slug || index}`;

        uniqueTeamPlayers.push({
          ...p,
          id: playerUniqueId,
          teamId: team.id
        });
      }
    });

    // Ensure explicit starterIndex for starters
    let sIdx = 0;
    const finalPlayers = uniqueTeamPlayers.map(p => {
      if (p.isStarting) {
        const starterIndex = p.starterIndex !== undefined ? p.starterIndex : sIdx++;
        return { ...p, isStarting: true, starterIndex };
      }
      return p;
    });

    const teamLogo = team.logoUrl || getTeamLogoUrl(team.id) || getTeamLogoUrl(team.name) || getTeamLogoUrl(team.shortName);

    return {
      ...team,
      logoUrl: teamLogo,
      players: finalPlayers
    };
  });
}

const RAW_SUPER_LIG_TEAMS: Team[] = [
  {
    "id": "galatasaray",
    "name": "Galatasaray",
    "shortName": "GS",
    "badgeColor": "from-amber-600 to-red-600",
    "badgeTextColor": "text-amber-300",
    "secondaryColor": "#ea580c",
    "stadiumName": "RAMS Park",
    "budget": 25000000,
    "reputation": 5,
    "formation": "4-2-3-1",
    "tactic": "ATTACKING",
    "players": [
      {
        "id": "gal-1",
        "name": "Uğurcan Çakır",
        "age": 30,
        "position": "GK",
        "specificRole": "GK",
        "overall": 81,
        "stamina": 88,
        "form": 8.1,
        "marketValue": 20250000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 56,
          "shooting": 15,
          "passing": 71,
          "defending": 81,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "gal-2",
        "name": "Wilfried Singo",
        "age": 25,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 80,
        "stamina": 91,
        "form": 8,
        "marketValue": 9600000,
        "nationality": "Fildişi Sahili",
        "attributes": {
          "pace": 78,
          "shooting": 55,
          "passing": 72,
          "defending": 84,
          "physical": 83
        },
        "isStarting": true
      },
      {
        "id": "gal-3",
        "name": "Davinson Sánchez",
        "age": 30,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 84,
        "stamina": 86,
        "form": 8.4,
        "marketValue": 21000000,
        "nationality": "Kolombiya",
        "attributes": {
          "pace": 82,
          "shooting": 59,
          "passing": 76,
          "defending": 88,
          "physical": 87
        },
        "isStarting": true
      },
      {
        "id": "gal-4",
        "name": "Abdülkerim Bardakcı",
        "age": 31,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 80,
        "stamina": 91,
        "form": 8,
        "marketValue": 9600000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 85,
          "shooting": 55,
          "passing": 72,
          "defending": 84,
          "physical": 83
        },
        "isStarting": true
      },
      {
        "id": "gal-5",
        "name": "Eren Elmalı",
        "age": 26,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 76,
        "stamina": 92,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 78,
          "shooting": 51,
          "passing": 68,
          "defending": 80,
          "physical": 79
        },
        "isStarting": true
      },
      {
        "id": "gal-6",
        "name": "Lucas Torreira",
        "age": 30,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 83,
        "stamina": 92,
        "form": 8.3,
        "marketValue": 20750000,
        "nationality": "Uruguay",
        "attributes": {
          "pace": 81,
          "shooting": 78,
          "passing": 88,
          "defending": 78,
          "physical": 83
        },
        "isStarting": true
      },
      {
        "id": "gal-7",
        "name": "Berkan Kutlu",
        "age": 27,
        "position": "MID",
        "specificRole": "CM",
        "overall": 78,
        "stamina": 90,
        "form": 7.8,
        "marketValue": 6000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 78,
          "shooting": 72,
          "passing": 79,
          "defending": 76,
          "physical": 82
        },
        "isStarting": true
      },
      {
        "id": "gal-8",
        "name": "Gabriel Sara",
        "age": 27,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 82,
        "stamina": 92,
        "form": 8.2,
        "marketValue": 20500000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 80,
          "shooting": 77,
          "passing": 87,
          "defending": 77,
          "physical": 82
        },
        "isStarting": true
      },
      {
        "id": "gal-9",
        "name": "Leroy Sané",
        "age": 30,
        "position": "FW",
        "specificRole": "RW",
        "overall": 84,
        "stamina": 88,
        "form": 8.4,
        "marketValue": 21000000,
        "nationality": "Almanya",
        "attributes": {
          "pace": 90,
          "shooting": 88,
          "passing": 79,
          "defending": 35,
          "physical": 84
        },
        "isStarting": true
      },
      {
        "id": "gal-10",
        "name": "Barış Alper Yılmaz",
        "age": 26,
        "position": "FW",
        "specificRole": "LW",
        "overall": 83,
        "stamina": 88,
        "form": 8.3,
        "marketValue": 20750000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 89,
          "shooting": 87,
          "passing": 78,
          "defending": 35,
          "physical": 83
        },
        "isStarting": true
      },
      {
        "id": "gal-11",
        "name": "Victor Osimhen",
        "age": 27,
        "position": "FW",
        "specificRole": "ST",
        "overall": 87,
        "stamina": 87,
        "form": 8.7,
        "marketValue": 21750000,
        "nationality": "Nijerya",
        "attributes": {
          "pace": 93,
          "shooting": 91,
          "passing": 82,
          "defending": 35,
          "physical": 87
        },
        "isStarting": true
      },
      {
        "id": "gal-12",
        "name": "Günay Güvenç",
        "age": 35,
        "position": "GK",
        "specificRole": "GK",
        "overall": 75,
        "stamina": 86,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 50,
          "shooting": 15,
          "passing": 65,
          "defending": 75,
          "physical": 70
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "gal-13",
        "name": "Victor Nelsson",
        "age": 27,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 79,
        "stamina": 85,
        "form": 7.9,
        "marketValue": 9480000,
        "nationality": "Danimarka",
        "attributes": {
          "pace": 81,
          "shooting": 54,
          "passing": 71,
          "defending": 83,
          "physical": 82
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "gal-14",
        "name": "Kaan Ayhan",
        "age": 31,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 78,
        "stamina": 92,
        "form": 7.8,
        "marketValue": 9360000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 80,
          "shooting": 53,
          "passing": 70,
          "defending": 82,
          "physical": 81
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "gal-15",
        "name": "Elias Jelert",
        "age": 23,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 77,
        "stamina": 88,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Danimarka",
        "attributes": {
          "pace": 80,
          "shooting": 52,
          "passing": 69,
          "defending": 81,
          "physical": 80
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "gal-16",
        "name": "Ismail Jakobs",
        "age": 27,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 77,
        "stamina": 89,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Senegal",
        "attributes": {
          "pace": 78,
          "shooting": 52,
          "passing": 69,
          "defending": 81,
          "physical": 80
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "gal-17",
        "name": "Kazımcan Karataş",
        "age": 23,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 72,
        "stamina": 87,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": false
      },
      {
        "id": "gal-18",
        "name": "Mario Lemina",
        "age": 32,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 79,
        "stamina": 86,
        "form": 7.9,
        "marketValue": 9480000,
        "nationality": "Gabon",
        "attributes": {
          "pace": 77,
          "shooting": 74,
          "passing": 84,
          "defending": 74,
          "physical": 79
        },
        "isStarting": false
      },
      {
        "id": "gal-19",
        "name": "Lesley Ugochukwu",
        "age": 22,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 78,
        "stamina": 92,
        "form": 7.8,
        "marketValue": 9360000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 76,
          "shooting": 73,
          "passing": 83,
          "defending": 73,
          "physical": 78
        },
        "isStarting": false
      },
      {
        "id": "gal-20",
        "name": "Eyüp Aydın",
        "age": 22,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 72,
        "stamina": 92,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Almanya",
        "attributes": {
          "pace": 70,
          "shooting": 67,
          "passing": 77,
          "defending": 67,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "gal-21",
        "name": "Yunus Akgün",
        "age": 26,
        "position": "FW",
        "specificRole": "RW",
        "overall": 80,
        "stamina": 92,
        "form": 8,
        "marketValue": 9600000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 86,
          "shooting": 84,
          "passing": 75,
          "defending": 35,
          "physical": 80
        },
        "isStarting": false
      },
      {
        "id": "gal-22",
        "name": "Roland Sallai",
        "age": 29,
        "position": "FW",
        "specificRole": "RW",
        "overall": 78,
        "stamina": 91,
        "form": 7.8,
        "marketValue": 9360000,
        "nationality": "Macaristan",
        "attributes": {
          "pace": 84,
          "shooting": 82,
          "passing": 73,
          "defending": 35,
          "physical": 78
        },
        "isStarting": false
      },
      {
        "id": "gal-23",
        "name": "Jankat Yılmaz",
        "age": 21,
        "position": "GK",
        "specificRole": "GK",
        "overall": 69,
        "stamina": 86,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 44,
          "shooting": 15,
          "passing": 59,
          "defending": 69,
          "physical": 64
        },
        "isStarting": false
      },
      {
        "id": "gal-24",
        "name": "Ali Turap Bülbül",
        "age": 21,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 69,
        "stamina": 92,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 70,
          "shooting": 44,
          "passing": 61,
          "defending": 73,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "gal-25",
        "name": "Can Armando Güner",
        "age": 18,
        "position": "FW",
        "specificRole": "ST",
        "overall": 68,
        "stamina": 92,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 74,
          "shooting": 72,
          "passing": 63,
          "defending": 35,
          "physical": 68
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "fenerbahce",
    "name": "Fenerbahçe",
    "shortName": "FB",
    "badgeColor": "from-yellow-400 to-blue-900",
    "badgeTextColor": "text-yellow-300",
    "secondaryColor": "#1e3a8a",
    "stadiumName": "Ülker Stadyumu",
    "budget": 22000000,
    "reputation": 5,
    "formation": "4-2-3-1",
    "tactic": "ATTACKING",
    "players": [
      {
        "id": "fen-1",
        "name": "Ederson",
        "age": 32,
        "position": "GK",
        "specificRole": "GK",
        "overall": 86,
        "stamina": 90,
        "form": 8.6,
        "marketValue": 21500000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 60,
          "shooting": 15,
          "passing": 76,
          "defending": 86,
          "physical": 81
        },
        "isStarting": true
      },
      {
        "id": "fen-2",
        "name": "Nélson Semedo",
        "age": 32,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 79,
        "stamina": 86,
        "form": 7.9,
        "marketValue": 9480000,
        "nationality": "Portekiz",
        "attributes": {
          "pace": 83,
          "shooting": 54,
          "passing": 71,
          "defending": 83,
          "physical": 82
        },
        "isStarting": true
      },
      {
        "id": "fen-3",
        "name": "Milan Skriniar",
        "age": 31,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 82,
        "stamina": 91,
        "form": 8.2,
        "marketValue": 20500000,
        "nationality": "Slovakya",
        "attributes": {
          "pace": 85,
          "shooting": 57,
          "passing": 74,
          "defending": 86,
          "physical": 85
        },
        "isStarting": true
      },
      {
        "id": "fen-4",
        "name": "Nathan Aké",
        "age": 31,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 83,
        "stamina": 85,
        "form": 8.3,
        "marketValue": 20750000,
        "nationality": "Hollanda",
        "attributes": {
          "pace": 83,
          "shooting": 58,
          "passing": 75,
          "defending": 87,
          "physical": 86
        },
        "isStarting": true
      },
      {
        "id": "fen-5",
        "name": "Jayden Oosterwolde",
        "age": 25,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 79,
        "stamina": 87,
        "form": 7.9,
        "marketValue": 9480000,
        "nationality": "Hollanda",
        "attributes": {
          "pace": 84,
          "shooting": 54,
          "passing": 71,
          "defending": 83,
          "physical": 82
        },
        "isStarting": true
      },
      {
        "id": "fen-6",
        "name": "N'Golo Kanté",
        "age": 35,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 83,
        "stamina": 85,
        "form": 8.3,
        "marketValue": 20750000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 81,
          "shooting": 78,
          "passing": 88,
          "defending": 78,
          "physical": 83
        },
        "isStarting": true
      },
      {
        "id": "fen-7",
        "name": "Fred",
        "age": 33,
        "position": "MID",
        "specificRole": "CM",
        "overall": 82,
        "stamina": 87,
        "form": 8.2,
        "marketValue": 20500000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 80,
          "shooting": 77,
          "passing": 87,
          "defending": 77,
          "physical": 82
        },
        "isStarting": true
      },
      {
        "id": "fen-8",
        "name": "Mason Greenwood",
        "age": 24,
        "position": "FW",
        "specificRole": "RW",
        "overall": 83,
        "stamina": 91,
        "form": 8.3,
        "marketValue": 20750000,
        "nationality": "İngiltere",
        "attributes": {
          "pace": 89,
          "shooting": 87,
          "passing": 78,
          "defending": 35,
          "physical": 83
        },
        "isStarting": true
      },
      {
        "id": "fen-9",
        "name": "Anderson Talisca",
        "age": 32,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 82,
        "stamina": 89,
        "form": 8.2,
        "marketValue": 20500000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 80,
          "shooting": 77,
          "passing": 87,
          "defending": 77,
          "physical": 82
        },
        "isStarting": true
      },
      {
        "id": "fen-10",
        "name": "Kerem Aktürkoğlu",
        "age": 27,
        "position": "FW",
        "specificRole": "LW",
        "overall": 81,
        "stamina": 87,
        "form": 8.1,
        "marketValue": 20250000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 87,
          "shooting": 85,
          "passing": 76,
          "defending": 35,
          "physical": 81
        },
        "isStarting": true
      },
      {
        "id": "fen-11",
        "name": "Vedat Muriç",
        "age": 32,
        "position": "FW",
        "specificRole": "ST",
        "overall": 79,
        "stamina": 85,
        "form": 7.9,
        "marketValue": 9480000,
        "nationality": "Kosova",
        "attributes": {
          "pace": 85,
          "shooting": 83,
          "passing": 74,
          "defending": 35,
          "physical": 79
        },
        "isStarting": true
      },
      {
        "id": "fen-12",
        "name": "Mert Günok",
        "age": 37,
        "position": "GK",
        "specificRole": "GK",
        "overall": 80,
        "stamina": 85,
        "form": 8,
        "marketValue": 9600000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 55,
          "shooting": 15,
          "passing": 70,
          "defending": 80,
          "physical": 75
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "fen-13",
        "name": "Diego Carlos",
        "age": 33,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 80,
        "stamina": 89,
        "form": 8,
        "marketValue": 9600000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 79,
          "shooting": 55,
          "passing": 72,
          "defending": 84,
          "physical": 83
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "fen-14",
        "name": "Çağlar Söyüncü",
        "age": 30,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 79,
        "stamina": 88,
        "form": 7.9,
        "marketValue": 9480000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 81,
          "shooting": 54,
          "passing": 71,
          "defending": 83,
          "physical": 82
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "fen-15",
        "name": "Mert Müldür",
        "age": 27,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 77,
        "stamina": 86,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 76,
          "shooting": 52,
          "passing": 69,
          "defending": 81,
          "physical": 80
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "fen-16",
        "name": "Archie Brown",
        "age": 24,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 77,
        "stamina": 88,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "İngiltere",
        "attributes": {
          "pace": 75,
          "shooting": 52,
          "passing": 69,
          "defending": 81,
          "physical": 80
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "fen-17",
        "name": "Rodrigo Becão",
        "age": 30,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 79,
        "stamina": 87,
        "form": 7.9,
        "marketValue": 9480000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 82,
          "shooting": 54,
          "passing": 71,
          "defending": 83,
          "physical": 82
        },
        "isStarting": false
      },
      {
        "id": "fen-18",
        "name": "Levent Mercan",
        "age": 25,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 74,
        "stamina": 90,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": false
      },
      {
        "id": "fen-19",
        "name": "İsmail Yüksek",
        "age": 27,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 79,
        "stamina": 86,
        "form": 7.9,
        "marketValue": 9480000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 77,
          "shooting": 74,
          "passing": 84,
          "defending": 74,
          "physical": 79
        },
        "isStarting": false
      },
      {
        "id": "fen-20",
        "name": "Matteo Guendouzi",
        "age": 27,
        "position": "MID",
        "specificRole": "CM",
        "overall": 81,
        "stamina": 87,
        "form": 8.1,
        "marketValue": 20250000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 79,
          "shooting": 76,
          "passing": 86,
          "defending": 76,
          "physical": 81
        },
        "isStarting": false
      },
      {
        "id": "fen-21",
        "name": "Marco Asensio",
        "age": 30,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 83,
        "stamina": 89,
        "form": 8.3,
        "marketValue": 20750000,
        "nationality": "İspanya",
        "attributes": {
          "pace": 81,
          "shooting": 78,
          "passing": 88,
          "defending": 78,
          "physical": 83
        },
        "isStarting": false
      },
      {
        "id": "fen-22",
        "name": "İrfan Can Kahveci",
        "age": 31,
        "position": "MID",
        "specificRole": "RW",
        "overall": 81,
        "stamina": 89,
        "form": 8.1,
        "marketValue": 20250000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 79,
          "shooting": 76,
          "passing": 86,
          "defending": 76,
          "physical": 81
        },
        "isStarting": false
      },
      {
        "id": "fen-23",
        "name": "Mert Hakan Yandaş",
        "age": 31,
        "position": "MID",
        "specificRole": "CM",
        "overall": 75,
        "stamina": 90,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": false
      },
      {
        "id": "fen-24",
        "name": "Cengiz Ünder",
        "age": 29,
        "position": "FW",
        "specificRole": "RW",
        "overall": 77,
        "stamina": 90,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 83,
          "shooting": 81,
          "passing": 72,
          "defending": 35,
          "physical": 77
        },
        "isStarting": false
      },
      {
        "id": "fen-25",
        "name": "Oğuz Aydın",
        "age": 25,
        "position": "FW",
        "specificRole": "LW",
        "overall": 76,
        "stamina": 92,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 82,
          "shooting": 80,
          "passing": 71,
          "defending": 35,
          "physical": 76
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "besiktas",
    "name": "Beşiktaş",
    "shortName": "BJK",
    "badgeColor": "from-gray-900 to-black",
    "badgeTextColor": "text-white",
    "secondaryColor": "#171717",
    "stadiumName": "Tüpraş Stadyumu",
    "budget": 18000000,
    "reputation": 5,
    "formation": "4-2-3-1",
    "tactic": "ATTACKING",
    "players": [
      {
        "id": "bes-1",
        "name": "Alexander Nübel",
        "age": 29,
        "position": "GK",
        "specificRole": "GK",
        "overall": 82,
        "stamina": 89,
        "form": 8.2,
        "marketValue": 20500000,
        "nationality": "Almanya",
        "attributes": {
          "pace": 57,
          "shooting": 15,
          "passing": 72,
          "defending": 82,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "bes-2",
        "name": "Michael Murillo",
        "age": 30,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 78,
        "stamina": 92,
        "form": 7.8,
        "marketValue": 9360000,
        "nationality": "Panama",
        "attributes": {
          "pace": 79,
          "shooting": 53,
          "passing": 70,
          "defending": 82,
          "physical": 81
        },
        "isStarting": true
      },
      {
        "id": "bes-3",
        "name": "Emmanuel Agbadou",
        "age": 29,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 80,
        "stamina": 92,
        "form": 8,
        "marketValue": 9600000,
        "nationality": "Fildişi Sahili",
        "attributes": {
          "pace": 79,
          "shooting": 55,
          "passing": 72,
          "defending": 84,
          "physical": 83
        },
        "isStarting": true
      },
      {
        "id": "bes-4",
        "name": "Felix Uduokhai",
        "age": 28,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 78,
        "stamina": 88,
        "form": 7.8,
        "marketValue": 9360000,
        "nationality": "Almanya",
        "attributes": {
          "pace": 81,
          "shooting": 53,
          "passing": 70,
          "defending": 82,
          "physical": 81
        },
        "isStarting": true
      },
      {
        "id": "bes-5",
        "name": "Rıdvan Yılmaz",
        "age": 25,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 77,
        "stamina": 87,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 78,
          "shooting": 52,
          "passing": 69,
          "defending": 81,
          "physical": 80
        },
        "isStarting": true
      },
      {
        "id": "bes-6",
        "name": "Wilfred Ndidi",
        "age": 29,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 81,
        "stamina": 87,
        "form": 8.1,
        "marketValue": 20250000,
        "nationality": "Nijerya",
        "attributes": {
          "pace": 79,
          "shooting": 76,
          "passing": 86,
          "defending": 76,
          "physical": 81
        },
        "isStarting": true
      },
      {
        "id": "bes-7",
        "name": "Salih Özcan",
        "age": 28,
        "position": "MID",
        "specificRole": "CM",
        "overall": 78,
        "stamina": 89,
        "form": 7.8,
        "marketValue": 9360000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 76,
          "shooting": 73,
          "passing": 83,
          "defending": 73,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "bes-8",
        "name": "Václav Černý",
        "age": 28,
        "position": "FW",
        "specificRole": "RW",
        "overall": 78,
        "stamina": 85,
        "form": 7.8,
        "marketValue": 9360000,
        "nationality": "Çekya",
        "attributes": {
          "pace": 84,
          "shooting": 82,
          "passing": 73,
          "defending": 35,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "bes-9",
        "name": "Orkun Kökçü",
        "age": 25,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 83,
        "stamina": 89,
        "form": 8.3,
        "marketValue": 20750000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 81,
          "shooting": 78,
          "passing": 88,
          "defending": 78,
          "physical": 83
        },
        "isStarting": true
      },
      {
        "id": "bes-10",
        "name": "Leandro Trossard",
        "age": 31,
        "position": "FW",
        "specificRole": "LW",
        "overall": 82,
        "stamina": 92,
        "form": 8.2,
        "marketValue": 20500000,
        "nationality": "Belçika",
        "attributes": {
          "pace": 88,
          "shooting": 86,
          "passing": 77,
          "defending": 35,
          "physical": 82
        },
        "isStarting": true
      },
      {
        "id": "bes-11",
        "name": "Semih Kılıçsoy",
        "age": 20,
        "position": "FW",
        "specificRole": "ST",
        "overall": 80,
        "stamina": 85,
        "form": 8,
        "marketValue": 9600000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 86,
          "shooting": 84,
          "passing": 75,
          "defending": 35,
          "physical": 80
        },
        "isStarting": true
      },
      {
        "id": "bes-12",
        "name": "Doğan Alemdar",
        "age": 23,
        "position": "GK",
        "specificRole": "GK",
        "overall": 75,
        "stamina": 90,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 50,
          "shooting": 15,
          "passing": 65,
          "defending": 75,
          "physical": 70
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "bes-13",
        "name": "Tiago Djaló",
        "age": 26,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 77,
        "stamina": 86,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Portekiz",
        "attributes": {
          "pace": 76,
          "shooting": 52,
          "passing": 69,
          "defending": 81,
          "physical": 80
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "bes-14",
        "name": "Emirhan Topçu",
        "age": 25,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 77,
        "stamina": 91,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 79,
          "shooting": 52,
          "passing": 69,
          "defending": 81,
          "physical": 80
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "bes-15",
        "name": "Yasin Özcan",
        "age": 20,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 76,
        "stamina": 90,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 79,
          "shooting": 51,
          "passing": 68,
          "defending": 80,
          "physical": 79
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "bes-16",
        "name": "Kassoum Ouattara",
        "age": 21,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 76,
        "stamina": 90,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 79,
          "shooting": 51,
          "passing": 68,
          "defending": 80,
          "physical": 79
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "bes-17",
        "name": "Amir Hadziahmetovic",
        "age": 29,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 76,
        "stamina": 89,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Bosna Hersek",
        "attributes": {
          "pace": 74,
          "shooting": 71,
          "passing": 81,
          "defending": 71,
          "physical": 76
        },
        "isStarting": false
      },
      {
        "id": "bes-18",
        "name": "Kartal Kayra Yılmaz",
        "age": 25,
        "position": "MID",
        "specificRole": "CM",
        "overall": 74,
        "stamina": 87,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "bes-19",
        "name": "Junior Olaitan",
        "age": 24,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 74,
        "stamina": 91,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Benin",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "bes-20",
        "name": "Milot Rashica",
        "age": 30,
        "position": "FW",
        "specificRole": "RW",
        "overall": 78,
        "stamina": 92,
        "form": 7.8,
        "marketValue": 9360000,
        "nationality": "Kosova",
        "attributes": {
          "pace": 84,
          "shooting": 82,
          "passing": 73,
          "defending": 35,
          "physical": 78
        },
        "isStarting": false
      },
      {
        "id": "bes-21",
        "name": "Hyeongyu Oh",
        "age": 25,
        "position": "FW",
        "specificRole": "ST",
        "overall": 77,
        "stamina": 87,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Güney Kore",
        "attributes": {
          "pace": 83,
          "shooting": 81,
          "passing": 72,
          "defending": 35,
          "physical": 77
        },
        "isStarting": false
      },
      {
        "id": "bes-22",
        "name": "Mustafa Hekimoğlu",
        "age": 19,
        "position": "FW",
        "specificRole": "ST",
        "overall": 74,
        "stamina": 87,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "bes-23",
        "name": "Emre Bilgin",
        "age": 22,
        "position": "GK",
        "specificRole": "GK",
        "overall": 71,
        "stamina": 90,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 46,
          "shooting": 15,
          "passing": 61,
          "defending": 71,
          "physical": 66
        },
        "isStarting": false
      },
      {
        "id": "bes-24",
        "name": "Fahri Kerem Ay",
        "age": 21,
        "position": "MID",
        "specificRole": "CM",
        "overall": 70,
        "stamina": 87,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 68,
          "shooting": 65,
          "passing": 75,
          "defending": 65,
          "physical": 70
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "trabzonspor",
    "name": "Trabzonspor",
    "shortName": "TS",
    "badgeColor": "from-red-800 to-sky-700",
    "badgeTextColor": "text-sky-300",
    "secondaryColor": "#991b1b",
    "stadiumName": "Papara Park",
    "budget": 12000000,
    "reputation": 4,
    "formation": "4-2-3-1",
    "tactic": "BALANCED",
    "players": [
      {
        "id": "tra-1",
        "name": "André Onana",
        "age": 30,
        "position": "GK",
        "specificRole": "GK",
        "overall": 83,
        "stamina": 90,
        "form": 8.3,
        "marketValue": 20750000,
        "nationality": "Kamerun",
        "attributes": {
          "pace": 58,
          "shooting": 15,
          "passing": 73,
          "defending": 83,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "tra-2",
        "name": "Samet Akaydin",
        "age": 32,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 75,
        "stamina": 90,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "tra-3",
        "name": "Stefan Savic",
        "age": 36,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 78,
        "stamina": 91,
        "form": 7.8,
        "marketValue": 9360000,
        "nationality": "Karadağ",
        "attributes": {
          "pace": 79,
          "shooting": 53,
          "passing": 70,
          "defending": 82,
          "physical": 81
        },
        "isStarting": true
      },
      {
        "id": "tra-4",
        "name": "Cenk Özkacar",
        "age": 26,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 76,
        "stamina": 92,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 78,
          "shooting": 51,
          "passing": 68,
          "defending": 80,
          "physical": 79
        },
        "isStarting": true
      },
      {
        "id": "tra-5",
        "name": "Sidny Lopes Cabral",
        "age": 24,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Yeşil Burun A.",
        "attributes": {
          "pace": 77,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "tra-6",
        "name": "Batista Mendy",
        "age": 27,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 78,
        "stamina": 90,
        "form": 7.8,
        "marketValue": 9360000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 76,
          "shooting": 73,
          "passing": 83,
          "defending": 73,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "tra-7",
        "name": "Okay Yokuşlu",
        "age": 32,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 77,
        "stamina": 85,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 72,
          "passing": 82,
          "defending": 72,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "tra-8",
        "name": "Ruslan Malinovskyi",
        "age": 33,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 78,
        "stamina": 85,
        "form": 7.8,
        "marketValue": 9360000,
        "nationality": "Ukrayna",
        "attributes": {
          "pace": 76,
          "shooting": 73,
          "passing": 83,
          "defending": 73,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "tra-9",
        "name": "Ernest Muçi",
        "age": 25,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 77,
        "stamina": 91,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Arnavutluk",
        "attributes": {
          "pace": 75,
          "shooting": 72,
          "passing": 82,
          "defending": 72,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "tra-10",
        "name": "Mohamed Salah Ghaly",
        "age": 34,
        "position": "FW",
        "specificRole": "RW",
        "overall": 87,
        "stamina": 90,
        "form": 8.7,
        "marketValue": 21750000,
        "nationality": "Mısır",
        "attributes": {
          "pace": 93,
          "shooting": 91,
          "passing": 82,
          "defending": 35,
          "physical": 87
        },
        "isStarting": true
      },
      {
        "id": "tra-11",
        "name": "Ebere Paul Onuachu",
        "age": 32,
        "position": "FW",
        "specificRole": "ST",
        "overall": 80,
        "stamina": 87,
        "form": 8,
        "marketValue": 9600000,
        "nationality": "Nijerya",
        "attributes": {
          "pace": 86,
          "shooting": 84,
          "passing": 75,
          "defending": 35,
          "physical": 80
        },
        "isStarting": true
      },
      {
        "id": "tra-12",
        "name": "Onuralp Çevikkan",
        "age": 21,
        "position": "GK",
        "specificRole": "GK",
        "overall": 68,
        "stamina": 85,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 43,
          "shooting": 15,
          "passing": 58,
          "defending": 68,
          "physical": 63
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "tra-13",
        "name": "Arseniy Batagov",
        "age": 24,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 75,
        "stamina": 86,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Ukrayna",
        "attributes": {
          "pace": 75,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "tra-14",
        "name": "Mustafa Eskihellaç",
        "age": 29,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 74,
        "stamina": 91,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 78,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "tra-15",
        "name": "Wagner Fabrício Cardoso Pina",
        "age": 24,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 72,
        "stamina": 92,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Yeşil Burun A.",
        "attributes": {
          "pace": 70,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "tra-16",
        "name": "Chibuike Godfrey Nwaiwu",
        "age": 23,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 72,
        "stamina": 85,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Nijerya",
        "attributes": {
          "pace": 70,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "tra-17",
        "name": "John Lundstram",
        "age": 32,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 76,
        "stamina": 85,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "İngiltere",
        "attributes": {
          "pace": 74,
          "shooting": 71,
          "passing": 81,
          "defending": 71,
          "physical": 76
        },
        "isStarting": false
      },
      {
        "id": "tra-18",
        "name": "Ozan Tufan",
        "age": 31,
        "position": "MID",
        "specificRole": "CM",
        "overall": 76,
        "stamina": 91,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 74,
          "shooting": 71,
          "passing": 81,
          "defending": 71,
          "physical": 76
        },
        "isStarting": false
      },
      {
        "id": "tra-19",
        "name": "Tim Jabol Folcarelli",
        "age": 27,
        "position": "MID",
        "specificRole": "CM",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "tra-20",
        "name": "Benjamin Bouchouari",
        "age": 25,
        "position": "MID",
        "specificRole": "CM",
        "overall": 75,
        "stamina": 92,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Fas",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": false
      },
      {
        "id": "tra-21",
        "name": "Aral Şimşir",
        "age": 24,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 75,
        "stamina": 89,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": false
      },
      {
        "id": "tra-22",
        "name": "Denis Mihai Draguş",
        "age": 27,
        "position": "FW",
        "specificRole": "ST",
        "overall": 76,
        "stamina": 88,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Romanya",
        "attributes": {
          "pace": 82,
          "shooting": 80,
          "passing": 71,
          "defending": 35,
          "physical": 76
        },
        "isStarting": false
      },
      {
        "id": "tra-23",
        "name": "Umut Nayir",
        "age": 33,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 87,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": false
      },
      {
        "id": "tra-24",
        "name": "Cihan Çanak",
        "age": 22,
        "position": "FW",
        "specificRole": "RW",
        "overall": 74,
        "stamina": 87,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "tra-25",
        "name": "Poyraz Efe Yıldırım",
        "age": 22,
        "position": "FW",
        "specificRole": "ST",
        "overall": 69,
        "stamina": 90,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 73,
          "passing": 64,
          "defending": 35,
          "physical": 69
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "basaksehir",
    "name": "RAMS Başakşehir",
    "shortName": "IBFK",
    "badgeColor": "from-orange-600 to-blue-900",
    "badgeTextColor": "text-orange-300",
    "secondaryColor": "#ea580c",
    "stadiumName": "Fatih Terim Stadyumu",
    "budget": 10000000,
    "reputation": 4,
    "formation": "4-3-3",
    "tactic": "BALANCED",
    "players": [
      {
        "id": "bas-1",
        "name": "Muhammed Şengezer",
        "age": 30,
        "position": "GK",
        "specificRole": "GK",
        "overall": 76,
        "stamina": 92,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 51,
          "shooting": 15,
          "passing": 66,
          "defending": 76,
          "physical": 71
        },
        "isStarting": true
      },
      {
        "id": "bas-2",
        "name": "Jerome Opoku",
        "age": 28,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 75,
        "stamina": 88,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Gana",
        "attributes": {
          "pace": 75,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "bas-3",
        "name": "Ousseynou Ba",
        "age": 31,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 87,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Senegal",
        "attributes": {
          "pace": 78,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "bas-4",
        "name": "Christopher Operi",
        "age": 29,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 74,
        "stamina": 90,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Fildişi Sahili",
        "attributes": {
          "pace": 76,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "bas-5",
        "name": "Onur Bulut",
        "age": 32,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 74,
        "stamina": 87,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 74,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "bas-6",
        "name": "Berat Özdemir",
        "age": 28,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 75,
        "stamina": 91,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "bas-7",
        "name": "Berkay Özcan",
        "age": 28,
        "position": "MID",
        "specificRole": "CM",
        "overall": 75,
        "stamina": 87,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "bas-8",
        "name": "Olivier Michel Kemen",
        "age": 30,
        "position": "MID",
        "specificRole": "CM",
        "overall": 75,
        "stamina": 90,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Kamerun",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "bas-9",
        "name": "Abbasbek Fayzullayev",
        "age": 23,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 76,
        "stamina": 91,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Özbekistan",
        "attributes": {
          "pace": 74,
          "shooting": 71,
          "passing": 81,
          "defending": 71,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "bas-10",
        "name": "Eldor Shomurodov",
        "age": 31,
        "position": "FW",
        "specificRole": "ST",
        "overall": 77,
        "stamina": 87,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Özbekistan",
        "attributes": {
          "pace": 83,
          "shooting": 81,
          "passing": 72,
          "defending": 35,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "bas-11",
        "name": "Nuno Miguel da Costa Jóia",
        "age": 36,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 90,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Yeşil Burun A.",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "bas-12",
        "name": "Volkan Babacan",
        "age": 38,
        "position": "GK",
        "specificRole": "GK",
        "overall": 72,
        "stamina": 85,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 47,
          "shooting": 15,
          "passing": 62,
          "defending": 72,
          "physical": 67
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "bas-13",
        "name": "Deniz Dilmen",
        "age": 21,
        "position": "GK",
        "specificRole": "GK",
        "overall": 69,
        "stamina": 86,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 44,
          "shooting": 15,
          "passing": 59,
          "defending": 69,
          "physical": 64
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "bas-14",
        "name": "Emin Bayram",
        "age": 23,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 75,
        "stamina": 88,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 74,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "bas-15",
        "name": "Michal Karbownik",
        "age": 25,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Polonya",
        "attributes": {
          "pace": 76,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "bas-16",
        "name": "Festy Ebosele",
        "age": 24,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 74,
        "stamina": 89,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "İrlanda",
        "attributes": {
          "pace": 73,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "bas-17",
        "name": "Hamza Güreler",
        "age": 20,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 70,
        "stamina": 86,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 45,
          "passing": 62,
          "defending": 74,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "bas-18",
        "name": "Ömer Ali Şahiner",
        "age": 35,
        "position": "MID",
        "specificRole": "RB",
        "overall": 74,
        "stamina": 85,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "bas-19",
        "name": "Umut Güneş",
        "age": 26,
        "position": "MID",
        "specificRole": "CM",
        "overall": 74,
        "stamina": 85,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "bas-20",
        "name": "Jakub Kałuwiński",
        "age": 24,
        "position": "MID",
        "specificRole": "CM",
        "overall": 74,
        "stamina": 91,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Polonya",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "bas-21",
        "name": "Edin Visca",
        "age": 36,
        "position": "MID",
        "specificRole": "RW",
        "overall": 77,
        "stamina": 85,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Bosna Hersek",
        "attributes": {
          "pace": 75,
          "shooting": 72,
          "passing": 82,
          "defending": 72,
          "physical": 77
        },
        "isStarting": false
      },
      {
        "id": "bas-22",
        "name": "Yusuf Sarı",
        "age": 28,
        "position": "FW",
        "specificRole": "RW",
        "overall": 76,
        "stamina": 90,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 82,
          "shooting": 80,
          "passing": 71,
          "defending": 35,
          "physical": 76
        },
        "isStarting": false
      },
      {
        "id": "bas-23",
        "name": "Davie Selke",
        "age": 32,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 89,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Almanya",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": false
      },
      {
        "id": "bas-24",
        "name": "Bertuğ Yıldırım",
        "age": 24,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 89,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": false
      },
      {
        "id": "bas-25",
        "name": "Andreas Skov Olsen",
        "age": 27,
        "position": "FW",
        "specificRole": "RW",
        "overall": 77,
        "stamina": 89,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Danimarka",
        "attributes": {
          "pace": 83,
          "shooting": 81,
          "passing": 72,
          "defending": 35,
          "physical": 77
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "samsunspor",
    "name": "Samsunspor",
    "shortName": "SAM",
    "badgeColor": "from-red-600 to-red-900",
    "badgeTextColor": "text-white",
    "secondaryColor": "#dc2626",
    "stadiumName": "19 Mayıs Stadyumu",
    "budget": 6000000,
    "reputation": 3,
    "formation": "4-2-3-1",
    "tactic": "ATTACKING",
    "players": [
      {
        "id": "sam-1",
        "name": "Okan Kocuk",
        "age": 31,
        "position": "GK",
        "specificRole": "GK",
        "overall": 75,
        "stamina": 89,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 50,
          "shooting": 15,
          "passing": 65,
          "defending": 75,
          "physical": 70
        },
        "isStarting": true
      },
      {
        "id": "sam-2",
        "name": "Logi Tomasson",
        "age": 26,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 74,
        "stamina": 91,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "İzlanda",
        "attributes": {
          "pace": 76,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "sam-3",
        "name": "Josafat Mendes",
        "age": 24,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 74,
        "stamina": 87,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "İsveç",
        "attributes": {
          "pace": 73,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "sam-4",
        "name": "Toni Borevkovic",
        "age": 29,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 90,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Hırvatistan",
        "attributes": {
          "pace": 72,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "sam-5",
        "name": "Yunus Emre Çift",
        "age": 23,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 72,
        "stamina": 92,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "sam-6",
        "name": "Emre Kılınç",
        "age": 32,
        "position": "MID",
        "specificRole": "LM",
        "overall": 75,
        "stamina": 92,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "sam-7",
        "name": "Antoine Makoumbou",
        "age": 28,
        "position": "MID",
        "specificRole": "CM",
        "overall": 75,
        "stamina": 87,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Kongo",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "sam-8",
        "name": "Afonso Sousa",
        "age": 26,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 75,
        "stamina": 91,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Portekiz",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "sam-9",
        "name": "Tanguy Coulibaly",
        "age": 25,
        "position": "MID",
        "specificRole": "RM",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "sam-10",
        "name": "Marius Mouandilmadji",
        "age": 29,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 87,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Çad",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "sam-11",
        "name": "Arbnor Muja",
        "age": 28,
        "position": "FW",
        "specificRole": "RW",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Arnavutluk",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "sam-12",
        "name": "Bilal Bayazit",
        "age": 27,
        "position": "GK",
        "specificRole": "GK",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 49,
          "shooting": 15,
          "passing": 64,
          "defending": 74,
          "physical": 69
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "sam-13",
        "name": "Efe Berat Törüz",
        "age": 20,
        "position": "GK",
        "specificRole": "GK",
        "overall": 66,
        "stamina": 90,
        "form": 6.6,
        "marketValue": 7920000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 41,
          "shooting": 15,
          "passing": 56,
          "defending": 66,
          "physical": 61
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "sam-14",
        "name": "Ali Badra A. Diabate",
        "age": 20,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 70,
        "stamina": 88,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Fildişi Sahili",
        "attributes": {
          "pace": 74,
          "shooting": 45,
          "passing": 62,
          "defending": 74,
          "physical": 73
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "sam-15",
        "name": "Igor Drapiński",
        "age": 22,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 71,
        "stamina": 92,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Polonya",
        "attributes": {
          "pace": 71,
          "shooting": 46,
          "passing": 63,
          "defending": 75,
          "physical": 74
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "sam-16",
        "name": "Enes Albak",
        "age": 21,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 68,
        "stamina": 92,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 66,
          "shooting": 43,
          "passing": 60,
          "defending": 72,
          "physical": 71
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "sam-17",
        "name": "Yalçın Kayan",
        "age": 28,
        "position": "MID",
        "specificRole": "CM",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "sam-18",
        "name": "Celil Yüksel",
        "age": 29,
        "position": "MID",
        "specificRole": "CM",
        "overall": 72,
        "stamina": 87,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 70,
          "shooting": 67,
          "passing": 77,
          "defending": 67,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "sam-19",
        "name": "Elliot Watt",
        "age": 26,
        "position": "MID",
        "specificRole": "CM",
        "overall": 72,
        "stamina": 85,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "İskoçya",
        "attributes": {
          "pace": 70,
          "shooting": 67,
          "passing": 77,
          "defending": 67,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "sam-20",
        "name": "Samed Onur",
        "age": 24,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 71,
        "stamina": 91,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "sam-21",
        "name": "Elayis Tavsan",
        "age": 25,
        "position": "FW",
        "specificRole": "RW",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Hollanda",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "sam-22",
        "name": "Pape Cherif Ndiaye",
        "age": 31,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 92,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Senegal",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": false
      },
      {
        "id": "sam-23",
        "name": "Fatih Kaya",
        "age": 27,
        "position": "FW",
        "specificRole": "ST",
        "overall": 72,
        "stamina": 90,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Almanya",
        "attributes": {
          "pace": 78,
          "shooting": 76,
          "passing": 67,
          "defending": 35,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "sam-24",
        "name": "Richie Omorowa",
        "age": 22,
        "position": "FW",
        "specificRole": "ST",
        "overall": 71,
        "stamina": 90,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "İsveç",
        "attributes": {
          "pace": 77,
          "shooting": 75,
          "passing": 66,
          "defending": 35,
          "physical": 71
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "eyupspor",
    "name": "Eyüpspor",
    "shortName": "EYÜ",
    "badgeColor": "from-purple-900 to-indigo-900",
    "badgeTextColor": "text-purple-300",
    "secondaryColor": "#581c87",
    "stadiumName": "Recep Tayyip Erdoğan Stadyumu",
    "budget": 8000000,
    "reputation": 3,
    "formation": "4-1-4-1",
    "tactic": "BALANCED",
    "players": [
      {
        "id": "eyu-1",
        "name": "Horațiu Moldovan",
        "age": 29,
        "position": "GK",
        "specificRole": "GK",
        "overall": 77,
        "stamina": 89,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Romanya",
        "attributes": {
          "pace": 52,
          "shooting": 15,
          "passing": 67,
          "defending": 77,
          "physical": 72
        },
        "isStarting": true
      },
      {
        "id": "eyu-2",
        "name": "Lucas Felipe Calegari",
        "age": 24,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 75,
        "stamina": 89,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 75,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "eyu-3",
        "name": "Jawad El Yamiq",
        "age": 34,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 76,
        "stamina": 87,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Fas",
        "attributes": {
          "pace": 77,
          "shooting": 51,
          "passing": 68,
          "defending": 80,
          "physical": 79
        },
        "isStarting": true
      },
      {
        "id": "eyu-4",
        "name": "Fethi Özer",
        "age": 30,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 72,
        "stamina": 89,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 70,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "eyu-5",
        "name": "Zak Jules",
        "age": 30,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 72,
        "stamina": 92,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "İskoçya",
        "attributes": {
          "pace": 75,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "eyu-6",
        "name": "Chandrel Massanga",
        "age": 27,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 74,
        "stamina": 85,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Kongo",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "eyu-7",
        "name": "Abdelhamid Sabiri",
        "age": 30,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 76,
        "stamina": 87,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Fas",
        "attributes": {
          "pace": 74,
          "shooting": 71,
          "passing": 81,
          "defending": 71,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "eyu-8",
        "name": "Hamza Akman",
        "age": 22,
        "position": "MID",
        "specificRole": "CM",
        "overall": 72,
        "stamina": 91,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 70,
          "shooting": 67,
          "passing": 77,
          "defending": 67,
          "physical": 72
        },
        "isStarting": true
      },
      {
        "id": "eyu-9",
        "name": "Konrad Michalak",
        "age": 29,
        "position": "FW",
        "specificRole": "RW",
        "overall": 75,
        "stamina": 87,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Polonya",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "eyu-10",
        "name": "Prince Obeng Ampem",
        "age": 28,
        "position": "FW",
        "specificRole": "LW",
        "overall": 75,
        "stamina": 88,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Gana",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "eyu-11",
        "name": "Lenny Pintor",
        "age": 26,
        "position": "FW",
        "specificRole": "ST",
        "overall": 73,
        "stamina": 87,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 79,
          "shooting": 77,
          "passing": 68,
          "defending": 35,
          "physical": 73
        },
        "isStarting": true
      },
      {
        "id": "eyu-12",
        "name": "Umut Keseci",
        "age": 23,
        "position": "GK",
        "specificRole": "GK",
        "overall": 67,
        "stamina": 85,
        "form": 6.7,
        "marketValue": 8040000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 42,
          "shooting": 15,
          "passing": 57,
          "defending": 67,
          "physical": 62
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "eyu-13",
        "name": "Anıl Yaşar",
        "age": 24,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 70,
        "stamina": 89,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 68,
          "shooting": 45,
          "passing": 62,
          "defending": 74,
          "physical": 73
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "eyu-14",
        "name": "Erdem Gökçe",
        "age": 23,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 71,
        "stamina": 90,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 46,
          "passing": 63,
          "defending": 75,
          "physical": 74
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "eyu-15",
        "name": "Jakhongir Orozov",
        "age": 23,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 70,
        "stamina": 85,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Özbekistan",
        "attributes": {
          "pace": 68,
          "shooting": 45,
          "passing": 62,
          "defending": 74,
          "physical": 73
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "eyu-16",
        "name": "Talha Ulvan",
        "age": 25,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 70,
        "stamina": 85,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 45,
          "passing": 62,
          "defending": 74,
          "physical": 73
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "eyu-17",
        "name": "Buğra Çağlıyan",
        "age": 22,
        "position": "MID",
        "specificRole": "CM",
        "overall": 70,
        "stamina": 90,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 68,
          "shooting": 65,
          "passing": 75,
          "defending": 65,
          "physical": 70
        },
        "isStarting": false
      },
      {
        "id": "eyu-18",
        "name": "David José Soares Oliveira Furtado Costa",
        "age": 23,
        "position": "MID",
        "specificRole": "CM",
        "overall": 71,
        "stamina": 92,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Yeşil Burun A.",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "eyu-19",
        "name": "Mete Kaan Demir",
        "age": 28,
        "position": "MID",
        "specificRole": "LM",
        "overall": 72,
        "stamina": 88,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 70,
          "shooting": 67,
          "passing": 77,
          "defending": 67,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "eyu-20",
        "name": "Charles Andre Raux Yao",
        "age": 25,
        "position": "MID",
        "specificRole": "CM",
        "overall": 71,
        "stamina": 85,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "eyu-21",
        "name": "Taşkın İlter",
        "age": 32,
        "position": "MID",
        "specificRole": "CM",
        "overall": 71,
        "stamina": 87,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Azerbaycan",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "eyu-22",
        "name": "Ahmed Abdullahi",
        "age": 22,
        "position": "FW",
        "specificRole": "ST",
        "overall": 68,
        "stamina": 86,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Nijerya",
        "attributes": {
          "pace": 74,
          "shooting": 72,
          "passing": 63,
          "defending": 35,
          "physical": 68
        },
        "isStarting": false
      },
      {
        "id": "eyu-23",
        "name": "Bilal Boutobba",
        "age": 28,
        "position": "FW",
        "specificRole": "RW",
        "overall": 74,
        "stamina": 89,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "eyu-24",
        "name": "Metehan Altunbaş",
        "age": 24,
        "position": "FW",
        "specificRole": "ST",
        "overall": 70,
        "stamina": 91,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 76,
          "shooting": 74,
          "passing": 65,
          "defending": 35,
          "physical": 70
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "goztepe",
    "name": "Göztepe",
    "shortName": "GÖZ",
    "badgeColor": "from-yellow-500 to-red-600",
    "badgeTextColor": "text-yellow-200",
    "secondaryColor": "#eab308",
    "stadiumName": "Gürsel Aksel Stadyumu",
    "budget": 5500000,
    "reputation": 3,
    "formation": "3-5-2",
    "tactic": "ATTACKING",
    "players": [
      {
        "id": "goz-1",
        "name": "Arda Özçimen",
        "age": 25,
        "position": "GK",
        "specificRole": "GK",
        "overall": 72,
        "stamina": 89,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 47,
          "shooting": 15,
          "passing": 62,
          "defending": 72,
          "physical": 67
        },
        "isStarting": true
      },
      {
        "id": "goz-2",
        "name": "Taha Altıkardeş",
        "age": 23,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 85,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 78,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "goz-3",
        "name": "Malcom Bokele",
        "age": 27,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 75,
        "stamina": 91,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Kamerun",
        "attributes": {
          "pace": 77,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "goz-4",
        "name": "Allan Godoi",
        "age": 33,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 75,
        "stamina": 89,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 79,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "goz-5",
        "name": "Ogün Bayrak",
        "age": 28,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 73,
        "stamina": 90,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 74,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "goz-6",
        "name": "Mohammed Amin Cherni",
        "age": 25,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 74,
        "stamina": 91,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Tunus",
        "attributes": {
          "pace": 78,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "goz-7",
        "name": "Efkan Bekiroğlu",
        "age": 31,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 75,
        "stamina": 88,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "goz-8",
        "name": "Rhaldney",
        "age": 28,
        "position": "MID",
        "specificRole": "CM",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "goz-9",
        "name": "Novatus Miroshi",
        "age": 24,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 74,
        "stamina": 90,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Tanzanya",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "goz-10",
        "name": "Juan",
        "age": 24,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 85,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "goz-11",
        "name": "Sinclair Armstrong",
        "age": 23,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 89,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "İrlanda",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "goz-12",
        "name": "Luka Gugeshashvili",
        "age": 27,
        "position": "GK",
        "specificRole": "GK",
        "overall": 74,
        "stamina": 91,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Gürcistan",
        "attributes": {
          "pace": 49,
          "shooting": 15,
          "passing": 64,
          "defending": 74,
          "physical": 69
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "goz-13",
        "name": "Berke Sarıgül",
        "age": 26,
        "position": "GK",
        "specificRole": "GK",
        "overall": 68,
        "stamina": 92,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 43,
          "shooting": 15,
          "passing": 58,
          "defending": 68,
          "physical": 63
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "goz-14",
        "name": "Furkan Bayır",
        "age": 27,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 73,
        "stamina": 88,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 77,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "goz-15",
        "name": "Noah Sonko-Sundberg",
        "age": 30,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 89,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Gambiya",
        "attributes": {
          "pace": 76,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "goz-16",
        "name": "Arda Okan Kurtulan",
        "age": 24,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 70,
        "stamina": 85,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 69,
          "shooting": 45,
          "passing": 62,
          "defending": 74,
          "physical": 73
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "goz-17",
        "name": "Anthony Dennis",
        "age": 22,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 74,
        "stamina": 87,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Nijerya",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "goz-18",
        "name": "Alex Matos",
        "age": 22,
        "position": "MID",
        "specificRole": "CM",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "İngiltere",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "goz-19",
        "name": "Alexis Antunes",
        "age": 26,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 73,
        "stamina": 87,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "İsviçre",
        "attributes": {
          "pace": 71,
          "shooting": 68,
          "passing": 78,
          "defending": 68,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "goz-20",
        "name": "Musah Mohammed",
        "age": 25,
        "position": "MID",
        "specificRole": "CM",
        "overall": 71,
        "stamina": 90,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Gana",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "goz-21",
        "name": "Janderson de Carvalho Costa",
        "age": 27,
        "position": "FW",
        "specificRole": "ST",
        "overall": 74,
        "stamina": 89,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "goz-22",
        "name": "Andre Henrique da Silva Martins",
        "age": 25,
        "position": "FW",
        "specificRole": "ST",
        "overall": 73,
        "stamina": 90,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 79,
          "shooting": 77,
          "passing": 68,
          "defending": 35,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "goz-23",
        "name": "Guilherme Luiz Oliveira da Silva",
        "age": 21,
        "position": "FW",
        "specificRole": "RW",
        "overall": 72,
        "stamina": 85,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 78,
          "shooting": 76,
          "passing": 67,
          "defending": 35,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "goz-24",
        "name": "Gökdeniz Bayrakdar",
        "age": 25,
        "position": "FW",
        "specificRole": "RW",
        "overall": 73,
        "stamina": 85,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 79,
          "shooting": 77,
          "passing": 68,
          "defending": 35,
          "physical": 73
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "kasimpasa",
    "name": "Kasımpaşa",
    "shortName": "KAS",
    "badgeColor": "from-blue-700 to-blue-950",
    "badgeTextColor": "text-blue-200",
    "secondaryColor": "#1d4ed8",
    "stadiumName": "Recep Tayyip Erdoğan Stadyumu",
    "budget": 5000000,
    "reputation": 3,
    "formation": "4-2-3-1",
    "tactic": "ATTACKING",
    "players": [
      {
        "id": "kas-1",
        "name": "Andreas Gianniotis",
        "age": 34,
        "position": "GK",
        "specificRole": "GK",
        "overall": 75,
        "stamina": 90,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Yunanistan",
        "attributes": {
          "pace": 50,
          "shooting": 15,
          "passing": 65,
          "defending": 75,
          "physical": 70
        },
        "isStarting": true
      },
      {
        "id": "kas-2",
        "name": "Claudio Winck Neto",
        "age": 32,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 75,
        "stamina": 89,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 79,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "kas-3",
        "name": "Godfried Ayesu Owusu Frimpong",
        "age": 27,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 73,
        "stamina": 88,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Hollanda",
        "attributes": {
          "pace": 73,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "kas-4",
        "name": "Matei Cristian Ilie",
        "age": 24,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 91,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Romanya",
        "attributes": {
          "pace": 76,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "kas-5",
        "name": "Yunus Emre Atakaya",
        "age": 22,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 71,
        "stamina": 87,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 46,
          "passing": 63,
          "defending": 75,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "kas-6",
        "name": "Haris Hajradinovic",
        "age": 32,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 77,
        "stamina": 90,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Bosna Hersek",
        "attributes": {
          "pace": 75,
          "shooting": 72,
          "passing": 82,
          "defending": 72,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "kas-7",
        "name": "Mortadha Ben Ouanes",
        "age": 32,
        "position": "MID",
        "specificRole": "LM",
        "overall": 75,
        "stamina": 85,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Tunus",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "kas-8",
        "name": "Kerem Demirbay",
        "age": 33,
        "position": "MID",
        "specificRole": "CM",
        "overall": 77,
        "stamina": 92,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Almanya",
        "attributes": {
          "pace": 75,
          "shooting": 72,
          "passing": 82,
          "defending": 72,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "kas-9",
        "name": "Mamadou Fall",
        "age": 35,
        "position": "FW",
        "specificRole": "RW",
        "overall": 75,
        "stamina": 87,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Senegal",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "kas-10",
        "name": "Fousseni Diabate",
        "age": 31,
        "position": "FW",
        "specificRole": "LW",
        "overall": 75,
        "stamina": 92,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Mali",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "kas-11",
        "name": "Pape Habib Gueye",
        "age": 27,
        "position": "FW",
        "specificRole": "ST",
        "overall": 74,
        "stamina": 92,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Senegal",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "kas-12",
        "name": "Ali Emre Yanar",
        "age": 28,
        "position": "GK",
        "specificRole": "GK",
        "overall": 70,
        "stamina": 87,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 45,
          "shooting": 15,
          "passing": 60,
          "defending": 70,
          "physical": 65
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "kas-13",
        "name": "Ramazan Özkanlı",
        "age": 24,
        "position": "GK",
        "specificRole": "GK",
        "overall": 67,
        "stamina": 86,
        "form": 6.7,
        "marketValue": 8040000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 42,
          "shooting": 15,
          "passing": 57,
          "defending": 67,
          "physical": 62
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "kas-14",
        "name": "Kamil Ahmet Çörekçi",
        "age": 35,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 71,
        "stamina": 90,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 71,
          "shooting": 46,
          "passing": 63,
          "defending": 75,
          "physical": 74
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "kas-15",
        "name": "Adem Arous",
        "age": 22,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 69,
        "stamina": 87,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Tunus",
        "attributes": {
          "pace": 71,
          "shooting": 44,
          "passing": 61,
          "defending": 73,
          "physical": 72
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "kas-16",
        "name": "Ayberk Karapo",
        "age": 22,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 71,
        "stamina": 87,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 46,
          "passing": 63,
          "defending": 75,
          "physical": 74
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "kas-17",
        "name": "Jakob Vestergaard Jessen",
        "age": 22,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 70,
        "stamina": 92,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Danimarka",
        "attributes": {
          "pace": 71,
          "shooting": 45,
          "passing": 62,
          "defending": 74,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "kas-18",
        "name": "Atakan Müjde",
        "age": 23,
        "position": "MID",
        "specificRole": "CM",
        "overall": 70,
        "stamina": 90,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 68,
          "shooting": 65,
          "passing": 75,
          "defending": 65,
          "physical": 70
        },
        "isStarting": false
      },
      {
        "id": "kas-19",
        "name": "Elson Mendes Da Silva",
        "age": 21,
        "position": "MID",
        "specificRole": "CM",
        "overall": 69,
        "stamina": 91,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Yeşil Burun A.",
        "attributes": {
          "pace": 67,
          "shooting": 64,
          "passing": 74,
          "defending": 64,
          "physical": 69
        },
        "isStarting": false
      },
      {
        "id": "kas-20",
        "name": "Kubilay Kanatsızkuş",
        "age": 29,
        "position": "FW",
        "specificRole": "ST",
        "overall": 72,
        "stamina": 91,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 78,
          "shooting": 76,
          "passing": 67,
          "defending": 35,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "kas-21",
        "name": "Adrian Benedyczak",
        "age": 26,
        "position": "FW",
        "specificRole": "ST",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Polonya",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "kas-22",
        "name": "Güven Yalçın",
        "age": 28,
        "position": "FW",
        "specificRole": "ST",
        "overall": 74,
        "stamina": 87,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "kas-23",
        "name": "Thiemoko Diarra",
        "age": 23,
        "position": "FW",
        "specificRole": "LW",
        "overall": 72,
        "stamina": 90,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Mali",
        "attributes": {
          "pace": 78,
          "shooting": 76,
          "passing": 67,
          "defending": 35,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "kas-24",
        "name": "Ali Yavuz Kol",
        "age": 26,
        "position": "FW",
        "specificRole": "ST",
        "overall": 71,
        "stamina": 89,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 77,
          "shooting": 75,
          "passing": 66,
          "defending": 35,
          "physical": 71
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "gaziantep",
    "name": "Gaziantep FK",
    "shortName": "GFK",
    "badgeColor": "from-red-700 to-gray-900",
    "badgeTextColor": "text-red-300",
    "secondaryColor": "#b91c1c",
    "stadiumName": "Kalyon Stadyumu",
    "budget": 4500000,
    "reputation": 3,
    "formation": "4-2-3-1",
    "tactic": "BALANCED",
    "players": [
      {
        "id": "gaz-1",
        "name": "Kacper Tobiasz",
        "age": 24,
        "position": "GK",
        "specificRole": "GK",
        "overall": 75,
        "stamina": 91,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Polonya",
        "attributes": {
          "pace": 50,
          "shooting": 15,
          "passing": 65,
          "defending": 75,
          "physical": 70
        },
        "isStarting": true
      },
      {
        "id": "gaz-2",
        "name": "Luis Jesus Perez Maqueda",
        "age": 32,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "İspanya",
        "attributes": {
          "pace": 78,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "gaz-3",
        "name": "Myenty Abena",
        "age": 32,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Surinam",
        "attributes": {
          "pace": 77,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "gaz-4",
        "name": "Arda Kızıldağ",
        "age": 28,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 92,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 76,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "gaz-5",
        "name": "Florin Stefan",
        "age": 30,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 73,
        "stamina": 86,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Romanya",
        "attributes": {
          "pace": 73,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "gaz-6",
        "name": "Ogün Özçiçek",
        "age": 28,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "gaz-7",
        "name": "Juninho Bacuna",
        "age": 29,
        "position": "MID",
        "specificRole": "CM",
        "overall": 75,
        "stamina": 85,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Curaçao",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "gaz-8",
        "name": "Alexandru Lulian Maxim",
        "age": 36,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 76,
        "stamina": 89,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Romanya",
        "attributes": {
          "pace": 74,
          "shooting": 71,
          "passing": 81,
          "defending": 71,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "gaz-9",
        "name": "Deian Cristian Sorescu",
        "age": 29,
        "position": "FW",
        "specificRole": "RW",
        "overall": 74,
        "stamina": 91,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Romanya",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "gaz-10",
        "name": "Kacper Kozlowski",
        "age": 23,
        "position": "FW",
        "specificRole": "LW",
        "overall": 75,
        "stamina": 90,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Polonya",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "gaz-11",
        "name": "Trivante Vincent Stewart",
        "age": 26,
        "position": "FW",
        "specificRole": "ST",
        "overall": 73,
        "stamina": 85,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Jamaika",
        "attributes": {
          "pace": 79,
          "shooting": 77,
          "passing": 68,
          "defending": 35,
          "physical": 73
        },
        "isStarting": true
      },
      {
        "id": "gaz-12",
        "name": "İbrahim Kağan Alkış",
        "age": 21,
        "position": "GK",
        "specificRole": "GK",
        "overall": 68,
        "stamina": 86,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 43,
          "shooting": 15,
          "passing": 58,
          "defending": 68,
          "physical": 63
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "gaz-13",
        "name": "Yusuf Nacar",
        "age": 20,
        "position": "GK",
        "specificRole": "GK",
        "overall": 66,
        "stamina": 92,
        "form": 6.6,
        "marketValue": 7920000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 41,
          "shooting": 15,
          "passing": 56,
          "defending": 66,
          "physical": 61
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "gaz-14",
        "name": "Kerim Çalhanoğlu",
        "age": 24,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 71,
        "stamina": 88,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Almanya",
        "attributes": {
          "pace": 76,
          "shooting": 46,
          "passing": 63,
          "defending": 75,
          "physical": 74
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "gaz-15",
        "name": "Muhammet Onur Başyiğit",
        "age": 22,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 68,
        "stamina": 90,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 68,
          "shooting": 43,
          "passing": 60,
          "defending": 72,
          "physical": 71
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "gaz-16",
        "name": "Sabahattin Destici",
        "age": 26,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 68,
        "stamina": 87,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 69,
          "shooting": 43,
          "passing": 60,
          "defending": 72,
          "physical": 71
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "gaz-17",
        "name": "Ulrich Meleke",
        "age": 27,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 72,
        "stamina": 88,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Fildişi Sahili",
        "attributes": {
          "pace": 70,
          "shooting": 67,
          "passing": 77,
          "defending": 67,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "gaz-18",
        "name": "Drissa Camara",
        "age": 24,
        "position": "MID",
        "specificRole": "CM",
        "overall": 71,
        "stamina": 85,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Fildişi Sahili",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "gaz-19",
        "name": "Enver Kulasin",
        "age": 23,
        "position": "FW",
        "specificRole": "RW",
        "overall": 71,
        "stamina": 86,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Bosna Hersek",
        "attributes": {
          "pace": 77,
          "shooting": 75,
          "passing": 66,
          "defending": 35,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "gaz-20",
        "name": "Fuat Bavuk",
        "age": 26,
        "position": "FW",
        "specificRole": "ST",
        "overall": 70,
        "stamina": 85,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 76,
          "shooting": 74,
          "passing": 65,
          "defending": 35,
          "physical": 70
        },
        "isStarting": false
      },
      {
        "id": "gaz-21",
        "name": "Mirza Cihan",
        "age": 26,
        "position": "FW",
        "specificRole": "LW",
        "overall": 71,
        "stamina": 89,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 77,
          "shooting": 75,
          "passing": 66,
          "defending": 35,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "gaz-22",
        "name": "Ali Ablak",
        "age": 23,
        "position": "FW",
        "specificRole": "ST",
        "overall": 67,
        "stamina": 89,
        "form": 6.7,
        "marketValue": 8040000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 71,
          "passing": 62,
          "defending": 35,
          "physical": 67
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "konyaspor",
    "name": "Konyaspor",
    "shortName": "KNY",
    "badgeColor": "from-emerald-700 to-green-950",
    "badgeTextColor": "text-emerald-200",
    "secondaryColor": "#047857",
    "stadiumName": "Konya Büyükşehir Stadyumu",
    "budget": 4000000,
    "reputation": 3,
    "formation": "4-2-3-1",
    "tactic": "BALANCED",
    "players": [
      {
        "id": "kon-1",
        "name": "Deniz Ertaş",
        "age": 21,
        "position": "GK",
        "specificRole": "GK",
        "overall": 72,
        "stamina": 90,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 47,
          "shooting": 15,
          "passing": 62,
          "defending": 72,
          "physical": 67
        },
        "isStarting": true
      },
      {
        "id": "kon-2",
        "name": "Chidozie Collins Awaziem",
        "age": 30,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 75,
        "stamina": 88,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Nijerya",
        "attributes": {
          "pace": 80,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "kon-3",
        "name": "Adil Demirbağ",
        "age": 29,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 90,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 78,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "kon-4",
        "name": "Rayyan Baniya",
        "age": 27,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 90,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 79,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "kon-5",
        "name": "Yhoan Andzouana",
        "age": 30,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 73,
        "stamina": 91,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Kongo",
        "attributes": {
          "pace": 76,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "kon-6",
        "name": "Enis Bardhi",
        "age": 31,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 76,
        "stamina": 91,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Kuzey Makedonya",
        "attributes": {
          "pace": 74,
          "shooting": 71,
          "passing": 81,
          "defending": 71,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "kon-7",
        "name": "Deniz Türüç",
        "age": 34,
        "position": "MID",
        "specificRole": "RM",
        "overall": 76,
        "stamina": 88,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 74,
          "shooting": 71,
          "passing": 81,
          "defending": 71,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "kon-8",
        "name": "Sander Svendsen",
        "age": 29,
        "position": "MID",
        "specificRole": "LM",
        "overall": 74,
        "stamina": 87,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Norveç",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "kon-9",
        "name": "Morten Bjørlo",
        "age": 31,
        "position": "MID",
        "specificRole": "CM",
        "overall": 73,
        "stamina": 87,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Norveç",
        "attributes": {
          "pace": 71,
          "shooting": 68,
          "passing": 78,
          "defending": 68,
          "physical": 73
        },
        "isStarting": true
      },
      {
        "id": "kon-10",
        "name": "Blaz Kramer",
        "age": 30,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 91,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Slovenya",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "kon-11",
        "name": "Jackson Muleka",
        "age": 27,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 87,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Kongo DC",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "kon-12",
        "name": "Bahadır Güngördü",
        "age": 31,
        "position": "GK",
        "specificRole": "GK",
        "overall": 72,
        "stamina": 90,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 47,
          "shooting": 15,
          "passing": 62,
          "defending": 72,
          "physical": 67
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "kon-13",
        "name": "Guilherme Sityá",
        "age": 36,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 75,
        "stamina": 85,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 78,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "kon-14",
        "name": "Arif Boşluk",
        "age": 23,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 72,
        "stamina": 92,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 74,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "kon-15",
        "name": "João Pedro do Nascimento da Mata",
        "age": 20,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 70,
        "stamina": 85,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 73,
          "shooting": 45,
          "passing": 62,
          "defending": 74,
          "physical": 73
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "kon-16",
        "name": "Uğurcan Yazğılı",
        "age": 27,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 72,
        "stamina": 92,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 70,
          "shooting": 67,
          "passing": 77,
          "defending": 67,
          "physical": 72
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "kon-17",
        "name": "Marko Jevtovic",
        "age": 33,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 73,
        "stamina": 88,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Sırbistan",
        "attributes": {
          "pace": 71,
          "shooting": 68,
          "passing": 78,
          "defending": 68,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "kon-18",
        "name": "Melih İbrahimoğlu",
        "age": 26,
        "position": "MID",
        "specificRole": "CM",
        "overall": 73,
        "stamina": 91,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Avusturya",
        "attributes": {
          "pace": 71,
          "shooting": 68,
          "passing": 78,
          "defending": 68,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "kon-19",
        "name": "Ebrima Colley",
        "age": 27,
        "position": "FW",
        "specificRole": "LW",
        "overall": 74,
        "stamina": 89,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Gambiya",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "kon-20",
        "name": "Louka Prip",
        "age": 29,
        "position": "FW",
        "specificRole": "RW",
        "overall": 72,
        "stamina": 90,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Danimarka",
        "attributes": {
          "pace": 78,
          "shooting": 76,
          "passing": 67,
          "defending": 35,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "kon-21",
        "name": "Hamidou Keyta",
        "age": 31,
        "position": "FW",
        "specificRole": "LW",
        "overall": 71,
        "stamina": 89,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 77,
          "shooting": 75,
          "passing": 66,
          "defending": 35,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "kon-22",
        "name": "Muhammet Tunahan Taşçı",
        "age": 24,
        "position": "FW",
        "specificRole": "RW",
        "overall": 71,
        "stamina": 87,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 77,
          "shooting": 75,
          "passing": 66,
          "defending": 35,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "kon-23",
        "name": "Melih Bostan",
        "age": 22,
        "position": "FW",
        "specificRole": "ST",
        "overall": 70,
        "stamina": 92,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 76,
          "shooting": 74,
          "passing": 65,
          "defending": 35,
          "physical": 70
        },
        "isStarting": false
      },
      {
        "id": "kon-24",
        "name": "Emir Bars",
        "age": 21,
        "position": "FW",
        "specificRole": "ST",
        "overall": 68,
        "stamina": 89,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 74,
          "shooting": 72,
          "passing": 63,
          "defending": 35,
          "physical": 68
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "alanyaspor",
    "name": "Alanyaspor",
    "shortName": "ALA",
    "badgeColor": "from-orange-500 to-green-700",
    "badgeTextColor": "text-orange-200",
    "secondaryColor": "#f97316",
    "stadiumName": "Gain Park Stadyumu",
    "budget": 4200000,
    "reputation": 3,
    "formation": "4-2-3-1",
    "tactic": "BALANCED",
    "players": [
      {
        "id": "ala-1",
        "name": "Paulo Victor de Mileo Vidotti",
        "age": 40,
        "position": "GK",
        "specificRole": "GK",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 49,
          "shooting": 15,
          "passing": 64,
          "defending": 74,
          "physical": 69
        },
        "isStarting": true
      },
      {
        "id": "ala-2",
        "name": "Florent Hadergjonaj",
        "age": 32,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 75,
        "stamina": 88,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Kosova",
        "attributes": {
          "pace": 78,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "ala-3",
        "name": "Bruno Viana Willemen da Silva",
        "age": 32,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 92,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 79,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "ala-4",
        "name": "Nuno Miguel Reis Lima",
        "age": 25,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 73,
        "stamina": 90,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Portekiz",
        "attributes": {
          "pace": 72,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "ala-5",
        "name": "Ümit Akdağ",
        "age": 23,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 73,
        "stamina": 89,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Romanya",
        "attributes": {
          "pace": 76,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "ala-6",
        "name": "Gaïus Makouta",
        "age": 29,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 74,
        "stamina": 87,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Kongo",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "ala-7",
        "name": "Enes Keskin",
        "age": 25,
        "position": "MID",
        "specificRole": "CM",
        "overall": 71,
        "stamina": 88,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": true
      },
      {
        "id": "ala-8",
        "name": "Ianis Hagi",
        "age": 28,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 76,
        "stamina": 86,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Romanya",
        "attributes": {
          "pace": 74,
          "shooting": 71,
          "passing": 81,
          "defending": 71,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "ala-9",
        "name": "Elia Meschack",
        "age": 29,
        "position": "FW",
        "specificRole": "RW",
        "overall": 75,
        "stamina": 91,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Kongo DC",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "ala-10",
        "name": "Yusuf Özdemir",
        "age": 26,
        "position": "FW",
        "specificRole": "LW",
        "overall": 73,
        "stamina": 88,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 79,
          "shooting": 77,
          "passing": 68,
          "defending": 35,
          "physical": 73
        },
        "isStarting": true
      },
      {
        "id": "ala-11",
        "name": "Hwang Ui-jo",
        "age": 34,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 91,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Güney Kore",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "ala-12",
        "name": "Mert Furkan Bayram",
        "age": 22,
        "position": "GK",
        "specificRole": "GK",
        "overall": 68,
        "stamina": 87,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 43,
          "shooting": 15,
          "passing": 58,
          "defending": 68,
          "physical": 63
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "ala-13",
        "name": "Yusuf Karagöz",
        "age": 27,
        "position": "GK",
        "specificRole": "GK",
        "overall": 68,
        "stamina": 85,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 43,
          "shooting": 15,
          "passing": 58,
          "defending": 68,
          "physical": 63
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "ala-14",
        "name": "Bedirhan Özyurt",
        "age": 23,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 68,
        "stamina": 86,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 69,
          "shooting": 43,
          "passing": 60,
          "defending": 72,
          "physical": 71
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "ala-15",
        "name": "Batuhan Yavuz",
        "age": 21,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 67,
        "stamina": 88,
        "form": 6.7,
        "marketValue": 8040000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 69,
          "shooting": 42,
          "passing": 59,
          "defending": 71,
          "physical": 70
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "ala-16",
        "name": "Fatih Aksoy",
        "age": 29,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 73,
        "stamina": 91,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "ala-17",
        "name": "Fidan Aliti",
        "age": 33,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Kosova",
        "attributes": {
          "pace": 73,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": false
      },
      {
        "id": "ala-18",
        "name": "Emirhan Çavuş",
        "age": 24,
        "position": "MID",
        "specificRole": "CM",
        "overall": 68,
        "stamina": 92,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 66,
          "shooting": 63,
          "passing": 73,
          "defending": 63,
          "physical": 68
        },
        "isStarting": false
      },
      {
        "id": "ala-19",
        "name": "Buluthan Bulut",
        "age": 24,
        "position": "MID",
        "specificRole": "CM",
        "overall": 68,
        "stamina": 86,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 66,
          "shooting": 63,
          "passing": 73,
          "defending": 63,
          "physical": 68
        },
        "isStarting": false
      },
      {
        "id": "ala-20",
        "name": "Antonio Simão Muanza",
        "age": 23,
        "position": "MID",
        "specificRole": "CM",
        "overall": 69,
        "stamina": 90,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Angola",
        "attributes": {
          "pace": 67,
          "shooting": 64,
          "passing": 74,
          "defending": 64,
          "physical": 69
        },
        "isStarting": false
      },
      {
        "id": "ala-21",
        "name": "İzzet Çelik",
        "age": 22,
        "position": "MID",
        "specificRole": "CM",
        "overall": 68,
        "stamina": 92,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 66,
          "shooting": 63,
          "passing": 73,
          "defending": 63,
          "physical": 68
        },
        "isStarting": false
      },
      {
        "id": "ala-22",
        "name": "Arda Usluoğlu",
        "age": 20,
        "position": "FW",
        "specificRole": "ST",
        "overall": 66,
        "stamina": 87,
        "form": 6.6,
        "marketValue": 7920000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 70,
          "passing": 61,
          "defending": 35,
          "physical": 66
        },
        "isStarting": false
      },
      {
        "id": "ala-23",
        "name": "Veysel Karani Ünal",
        "age": 25,
        "position": "FW",
        "specificRole": "ST",
        "overall": 68,
        "stamina": 90,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 74,
          "shooting": 72,
          "passing": 63,
          "defending": 35,
          "physical": 68
        },
        "isStarting": false
      },
      {
        "id": "ala-24",
        "name": "Ruan Pereira Duarte",
        "age": 21,
        "position": "FW",
        "specificRole": "RW",
        "overall": 71,
        "stamina": 87,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 77,
          "shooting": 75,
          "passing": 66,
          "defending": 35,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "ala-25",
        "name": "İbrahim Kaya",
        "age": 25,
        "position": "FW",
        "specificRole": "ST",
        "overall": 69,
        "stamina": 85,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 73,
          "passing": 64,
          "defending": 35,
          "physical": 69
        },
        "isStarting": false
      },
      {
        "id": "ala-26",
        "name": "Omar Ben Ali",
        "age": 21,
        "position": "FW",
        "specificRole": "ST",
        "overall": 67,
        "stamina": 92,
        "form": 6.7,
        "marketValue": 8040000,
        "nationality": "Tunus",
        "attributes": {
          "pace": 73,
          "shooting": 71,
          "passing": 62,
          "defending": 35,
          "physical": 67
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "rizespor",
    "name": "Rizespor",
    "shortName": "RİZ",
    "badgeColor": "from-blue-600 to-green-600",
    "badgeTextColor": "text-green-200",
    "secondaryColor": "#2563eb",
    "stadiumName": "Çaykur Didi Stadyumu",
    "budget": 4800000,
    "reputation": 3,
    "formation": "4-2-3-1",
    "tactic": "ATTACKING",
    "players": [
      {
        "id": "riz-1",
        "name": "Yahia Fofana",
        "age": 26,
        "position": "GK",
        "specificRole": "GK",
        "overall": 77,
        "stamina": 86,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Fildişi Sahili",
        "attributes": {
          "pace": 52,
          "shooting": 15,
          "passing": 67,
          "defending": 77,
          "physical": 72
        },
        "isStarting": true
      },
      {
        "id": "riz-2",
        "name": "Taha Şahin",
        "age": 26,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "riz-3",
        "name": "Modibo Sagnan",
        "age": 27,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 76,
        "stamina": 87,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Mali",
        "attributes": {
          "pace": 75,
          "shooting": 51,
          "passing": 68,
          "defending": 80,
          "physical": 79
        },
        "isStarting": true
      },
      {
        "id": "riz-4",
        "name": "Husniddin Alikulov",
        "age": 27,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 75,
        "stamina": 86,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Özbekistan",
        "attributes": {
          "pace": 77,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "riz-5",
        "name": "Mithat Pala",
        "age": 26,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 73,
        "stamina": 90,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "riz-6",
        "name": "Taylan Antalyalı",
        "age": 32,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 75,
        "stamina": 86,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "riz-7",
        "name": "Qazim Laçi",
        "age": 31,
        "position": "MID",
        "specificRole": "CM",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Arnavutluk",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "riz-8",
        "name": "Dal Varesanovic",
        "age": 25,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 75,
        "stamina": 90,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Bosna Hersek",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "riz-9",
        "name": "Ahmed Kutucu",
        "age": 26,
        "position": "FW",
        "specificRole": "RW",
        "overall": 76,
        "stamina": 91,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 82,
          "shooting": 80,
          "passing": 71,
          "defending": 35,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "riz-10",
        "name": "Valentin Mihai Mihaila",
        "age": 27,
        "position": "FW",
        "specificRole": "LW",
        "overall": 76,
        "stamina": 86,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Romanya",
        "attributes": {
          "pace": 82,
          "shooting": 80,
          "passing": 71,
          "defending": 35,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "riz-11",
        "name": "Ali Sowe",
        "age": 32,
        "position": "FW",
        "specificRole": "ST",
        "overall": 76,
        "stamina": 88,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Gambiya",
        "attributes": {
          "pace": 82,
          "shooting": 80,
          "passing": 71,
          "defending": 35,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "riz-12",
        "name": "Zafer Görgen",
        "age": 26,
        "position": "GK",
        "specificRole": "GK",
        "overall": 71,
        "stamina": 85,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 46,
          "shooting": 15,
          "passing": 61,
          "defending": 71,
          "physical": 66
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "riz-13",
        "name": "Erdem Canpolat",
        "age": 25,
        "position": "GK",
        "specificRole": "GK",
        "overall": 70,
        "stamina": 92,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 45,
          "shooting": 15,
          "passing": 60,
          "defending": 70,
          "physical": 65
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "riz-14",
        "name": "Anıl Yaşar",
        "age": 24,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 70,
        "stamina": 89,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 45,
          "passing": 62,
          "defending": 74,
          "physical": 73
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "riz-15",
        "name": "Eray Korkmaz",
        "age": 23,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 68,
        "stamina": 88,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 71,
          "shooting": 43,
          "passing": 60,
          "defending": 72,
          "physical": 71
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "riz-16",
        "name": "Habil Özbakır",
        "age": 22,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 67,
        "stamina": 89,
        "form": 6.7,
        "marketValue": 8040000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 71,
          "shooting": 42,
          "passing": 59,
          "defending": 71,
          "physical": 70
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "riz-17",
        "name": "Siaka Bakayoko",
        "age": 21,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 68,
        "stamina": 85,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 72,
          "shooting": 43,
          "passing": 60,
          "defending": 72,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "riz-18",
        "name": "Tayyip Talha Sanuç",
        "age": 27,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": false
      },
      {
        "id": "riz-19",
        "name": "Zakaria Ariss",
        "age": 22,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 70,
        "stamina": 92,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Fas",
        "attributes": {
          "pace": 68,
          "shooting": 45,
          "passing": 62,
          "defending": 74,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "riz-20",
        "name": "Attila Mocsi",
        "age": 26,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Macaristan",
        "attributes": {
          "pace": 75,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": false
      },
      {
        "id": "riz-21",
        "name": "Mame Mor Faye",
        "age": 21,
        "position": "MID",
        "specificRole": "RW",
        "overall": 70,
        "stamina": 92,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Senegal",
        "attributes": {
          "pace": 68,
          "shooting": 65,
          "passing": 75,
          "defending": 65,
          "physical": 70
        },
        "isStarting": false
      },
      {
        "id": "riz-22",
        "name": "Muhamed Buljubasic",
        "age": 22,
        "position": "MID",
        "specificRole": "CM",
        "overall": 71,
        "stamina": 90,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Bosna Hersek",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "riz-23",
        "name": "Altin Zeqiri",
        "age": 26,
        "position": "MID",
        "specificRole": "LM",
        "overall": 74,
        "stamina": 90,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Kosova",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "riz-24",
        "name": "Ibrahim Olawoyin",
        "age": 29,
        "position": "FW",
        "specificRole": "LW",
        "overall": 75,
        "stamina": 88,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Nijerya",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": false
      },
      {
        "id": "riz-25",
        "name": "Adedire Awokoya Mebude",
        "age": 22,
        "position": "FW",
        "specificRole": "RW",
        "overall": 71,
        "stamina": 92,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "İskoçya",
        "attributes": {
          "pace": 77,
          "shooting": 75,
          "passing": 66,
          "defending": 35,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "riz-26",
        "name": "Emrecan Bulut",
        "age": 24,
        "position": "FW",
        "specificRole": "ST",
        "overall": 71,
        "stamina": 85,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 77,
          "shooting": 75,
          "passing": 66,
          "defending": 35,
          "physical": 71
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "kocaelispor",
    "name": "Kocaelispor",
    "shortName": "KOC",
    "badgeColor": "from-green-600 to-black",
    "badgeTextColor": "text-green-300",
    "secondaryColor": "#16a34a",
    "stadiumName": "Kocaeli Stadyumu",
    "budget": 4500000,
    "reputation": 3,
    "formation": "4-2-3-1",
    "tactic": "BALANCED",
    "players": [
      {
        "id": "koc-1",
        "name": "Gökhan Değirmenci",
        "age": 37,
        "position": "GK",
        "specificRole": "GK",
        "overall": 73,
        "stamina": 88,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 48,
          "shooting": 15,
          "passing": 63,
          "defending": 73,
          "physical": 68
        },
        "isStarting": true
      },
      {
        "id": "koc-2",
        "name": "Aaron Appindangoye",
        "age": 34,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Gabon",
        "attributes": {
          "pace": 74,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "koc-3",
        "name": "Tarkan Serbest",
        "age": 32,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 73,
        "stamina": 86,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Avusturya",
        "attributes": {
          "pace": 78,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "koc-4",
        "name": "Ahmet Oğuz",
        "age": 33,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 73,
        "stamina": 85,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 78,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "koc-5",
        "name": "Muharrem Cinan",
        "age": 28,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 72,
        "stamina": 85,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 71,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "koc-6",
        "name": "Pedrinho",
        "age": 33,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Portekiz",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "koc-7",
        "name": "Mijo Caktas",
        "age": 34,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 75,
        "stamina": 89,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Hırvatistan",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "koc-8",
        "name": "Josip Vukovic",
        "age": 34,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 73,
        "stamina": 88,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Hırvatistan",
        "attributes": {
          "pace": 71,
          "shooting": 68,
          "passing": 78,
          "defending": 68,
          "physical": 73
        },
        "isStarting": true
      },
      {
        "id": "koc-9",
        "name": "Ryan Mendes",
        "age": 36,
        "position": "FW",
        "specificRole": "LW",
        "overall": 74,
        "stamina": 91,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Yeşil Burun A.",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "koc-10",
        "name": "Daniel Candeias",
        "age": 38,
        "position": "FW",
        "specificRole": "RW",
        "overall": 74,
        "stamina": 90,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Portekiz",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "koc-11",
        "name": "Markao",
        "age": 32,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 89,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "koc-12",
        "name": "Harun Tekin",
        "age": 37,
        "position": "GK",
        "specificRole": "GK",
        "overall": 71,
        "stamina": 89,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 46,
          "shooting": 15,
          "passing": 61,
          "defending": 71,
          "physical": 66
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "koc-13",
        "name": "Haşim Arda Sarman",
        "age": 23,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 68,
        "stamina": 92,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 43,
          "passing": 60,
          "defending": 72,
          "physical": 71
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "koc-14",
        "name": "Onur Öztonga",
        "age": 26,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 69,
        "stamina": 92,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 71,
          "shooting": 44,
          "passing": 61,
          "defending": 73,
          "physical": 72
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "koc-15",
        "name": "Mehmet Yılmaz",
        "age": 30,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 71,
        "stamina": 87,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 46,
          "passing": 63,
          "defending": 75,
          "physical": 74
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "koc-16",
        "name": "Cihat Çelik",
        "age": 30,
        "position": "MID",
        "specificRole": "CM",
        "overall": 71,
        "stamina": 89,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Hollanda",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "koc-17",
        "name": "Mesut Can Tunalı",
        "age": 24,
        "position": "MID",
        "specificRole": "CM",
        "overall": 69,
        "stamina": 90,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 67,
          "shooting": 64,
          "passing": 74,
          "defending": 64,
          "physical": 69
        },
        "isStarting": false
      },
      {
        "id": "koc-18",
        "name": "Barış Alıcı",
        "age": 29,
        "position": "FW",
        "specificRole": "RW",
        "overall": 72,
        "stamina": 86,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 78,
          "shooting": 76,
          "passing": 67,
          "defending": 35,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "koc-19",
        "name": "Giorgi Beridze",
        "age": 29,
        "position": "FW",
        "specificRole": "LW",
        "overall": 72,
        "stamina": 86,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Gürcistan",
        "attributes": {
          "pace": 78,
          "shooting": 76,
          "passing": 67,
          "defending": 35,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "koc-20",
        "name": "Ahmet Sagat",
        "age": 29,
        "position": "FW",
        "specificRole": "ST",
        "overall": 72,
        "stamina": 85,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Almanya",
        "attributes": {
          "pace": 78,
          "shooting": 76,
          "passing": 67,
          "defending": 35,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "koc-21",
        "name": "Christian Kouakou",
        "age": 35,
        "position": "FW",
        "specificRole": "ST",
        "overall": 71,
        "stamina": 90,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Fildişi Sahili",
        "attributes": {
          "pace": 77,
          "shooting": 75,
          "passing": 66,
          "defending": 35,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "koc-22",
        "name": "Samed Ali Kaya",
        "age": 30,
        "position": "FW",
        "specificRole": "ST",
        "overall": 70,
        "stamina": 88,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 76,
          "shooting": 74,
          "passing": 65,
          "defending": 35,
          "physical": 70
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "erzurumspor",
    "name": "Erzurumspor FK",
    "shortName": "ERZ",
    "badgeColor": "from-blue-600 to-sky-400",
    "badgeTextColor": "text-blue-100",
    "secondaryColor": "#2563eb",
    "stadiumName": "Kâzım Karabekir Stadyumu",
    "budget": 3800000,
    "reputation": 2,
    "formation": "4-3-3",
    "tactic": "DEFENSIVE",
    "players": [
      {
        "id": "erz-1",
        "name": "Ertuğrul Taşkıran",
        "age": 37,
        "position": "GK",
        "specificRole": "GK",
        "overall": 75,
        "stamina": 90,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 50,
          "shooting": 15,
          "passing": 65,
          "defending": 75,
          "physical": 70
        },
        "isStarting": true
      },
      {
        "id": "erz-2",
        "name": "Orhan Ovacıklı",
        "age": 38,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 72,
        "stamina": 91,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 74,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "erz-3",
        "name": "Mustafa Yumlu",
        "age": 39,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 73,
        "stamina": 85,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "erz-4",
        "name": "Nihad Mujakić",
        "age": 28,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 75,
        "stamina": 86,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Bosna Hersek",
        "attributes": {
          "pace": 80,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "erz-5",
        "name": "Guram Giorbelidze",
        "age": 30,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 72,
        "stamina": 87,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Gürcistan",
        "attributes": {
          "pace": 75,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "erz-6",
        "name": "Brandon Baiye",
        "age": 26,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 73,
        "stamina": 88,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Belçika",
        "attributes": {
          "pace": 71,
          "shooting": 68,
          "passing": 78,
          "defending": 68,
          "physical": 73
        },
        "isStarting": true
      },
      {
        "id": "erz-7",
        "name": "Murat Cem Akpınar",
        "age": 28,
        "position": "MID",
        "specificRole": "CM",
        "overall": 73,
        "stamina": 86,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 71,
          "shooting": 68,
          "passing": 78,
          "defending": 68,
          "physical": 73
        },
        "isStarting": true
      },
      {
        "id": "erz-8",
        "name": "Martín Vladimir Rodríguez Torrejón",
        "age": 32,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 73,
        "stamina": 92,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Şili",
        "attributes": {
          "pace": 71,
          "shooting": 68,
          "passing": 78,
          "defending": 68,
          "physical": 73
        },
        "isStarting": true
      },
      {
        "id": "erz-9",
        "name": "Gyrano Kerk",
        "age": 31,
        "position": "FW",
        "specificRole": "RW",
        "overall": 75,
        "stamina": 91,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Surinam",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "erz-10",
        "name": "Fernando Andrade dos Santos",
        "age": 34,
        "position": "FW",
        "specificRole": "LW",
        "overall": 73,
        "stamina": 92,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 79,
          "shooting": 77,
          "passing": 68,
          "defending": 35,
          "physical": 73
        },
        "isStarting": true
      },
      {
        "id": "erz-11",
        "name": "Eren Tozlu",
        "age": 36,
        "position": "FW",
        "specificRole": "ST",
        "overall": 74,
        "stamina": 89,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "erz-12",
        "name": "Erkan Anapa",
        "age": 29,
        "position": "GK",
        "specificRole": "GK",
        "overall": 68,
        "stamina": 92,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 43,
          "shooting": 15,
          "passing": 58,
          "defending": 68,
          "physical": 63
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "erz-13",
        "name": "Matija Orbanic",
        "age": 26,
        "position": "GK",
        "specificRole": "GK",
        "overall": 71,
        "stamina": 88,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Hırvatistan",
        "attributes": {
          "pace": 46,
          "shooting": 15,
          "passing": 61,
          "defending": 71,
          "physical": 66
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "erz-14",
        "name": "Emre Erdem",
        "age": 24,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 68,
        "stamina": 92,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 68,
          "shooting": 43,
          "passing": 60,
          "defending": 72,
          "physical": 71
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "erz-15",
        "name": "Enes Yiğit",
        "age": 24,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 67,
        "stamina": 88,
        "form": 6.7,
        "marketValue": 8040000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 70,
          "shooting": 42,
          "passing": 59,
          "defending": 71,
          "physical": 70
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "erz-16",
        "name": "Cengizhan Bayrak",
        "age": 27,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 71,
        "stamina": 90,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 71,
          "shooting": 46,
          "passing": 63,
          "defending": 75,
          "physical": 74
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "erz-17",
        "name": "Yakup Kırtay",
        "age": 23,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 72,
        "stamina": 88,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 77,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": false
      },
      {
        "id": "erz-18",
        "name": "Amar Gerxhaliu",
        "age": 24,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 70,
        "stamina": 88,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Kosova",
        "attributes": {
          "pace": 72,
          "shooting": 45,
          "passing": 62,
          "defending": 74,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "erz-19",
        "name": "Eren Özdemir",
        "age": 23,
        "position": "MID",
        "specificRole": "CM",
        "overall": 66,
        "stamina": 91,
        "form": 6.6,
        "marketValue": 7920000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 64,
          "shooting": 61,
          "passing": 71,
          "defending": 61,
          "physical": 66
        },
        "isStarting": false
      },
      {
        "id": "erz-20",
        "name": "Furkan Özhan",
        "age": 26,
        "position": "MID",
        "specificRole": "CM",
        "overall": 71,
        "stamina": 91,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "erz-21",
        "name": "Sefa Akgün",
        "age": 26,
        "position": "MID",
        "specificRole": "CM",
        "overall": 72,
        "stamina": 87,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 70,
          "shooting": 67,
          "passing": 77,
          "defending": 67,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "erz-22",
        "name": "Gürkan Varlık",
        "age": 24,
        "position": "FW",
        "specificRole": "ST",
        "overall": 67,
        "stamina": 87,
        "form": 6.7,
        "marketValue": 8040000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 71,
          "passing": 62,
          "defending": 35,
          "physical": 67
        },
        "isStarting": false
      },
      {
        "id": "erz-23",
        "name": "Hüseyin Mevlütoğlu",
        "age": 24,
        "position": "FW",
        "specificRole": "LW",
        "overall": 67,
        "stamina": 86,
        "form": 6.7,
        "marketValue": 8040000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 71,
          "passing": 62,
          "defending": 35,
          "physical": 67
        },
        "isStarting": false
      },
      {
        "id": "erz-24",
        "name": "Nariman Axundzadə",
        "age": 22,
        "position": "FW",
        "specificRole": "ST",
        "overall": 71,
        "stamina": 91,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Azerbaycan",
        "attributes": {
          "pace": 77,
          "shooting": 75,
          "passing": 66,
          "defending": 35,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "erz-25",
        "name": "Serkan Köse",
        "age": 28,
        "position": "FW",
        "specificRole": "ST",
        "overall": 69,
        "stamina": 85,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 73,
          "passing": 64,
          "defending": 35,
          "physical": 69
        },
        "isStarting": false
      },
      {
        "id": "erz-26",
        "name": "İlkan Sever",
        "age": 22,
        "position": "FW",
        "specificRole": "LW",
        "overall": 67,
        "stamina": 87,
        "form": 6.7,
        "marketValue": 8040000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 71,
          "passing": 62,
          "defending": 35,
          "physical": 67
        },
        "isStarting": false
      },
      {
        "id": "erz-27",
        "name": "Mustafa Fettahoğlu",
        "age": 26,
        "position": "FW",
        "specificRole": "ST",
        "overall": 68,
        "stamina": 87,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 74,
          "shooting": 72,
          "passing": 63,
          "defending": 35,
          "physical": 68
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "amedfk",
    "name": "Amed SK",
    "shortName": "AMD",
    "badgeColor": "from-green-700 to-red-700",
    "badgeTextColor": "text-green-200",
    "secondaryColor": "#15803d",
    "stadiumName": "Diyarbakır Stadyumu",
    "budget": 4200000,
    "reputation": 3,
    "formation": "4-2-3-1",
    "tactic": "ATTACKING",
    "players": [
      {
        "id": "ame-1",
        "name": "Marcos Felipe de Freitas Monteiro",
        "age": 30,
        "position": "GK",
        "specificRole": "GK",
        "overall": 76,
        "stamina": 88,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 51,
          "shooting": 15,
          "passing": 66,
          "defending": 76,
          "physical": 71
        },
        "isStarting": true
      },
      {
        "id": "ame-2",
        "name": "Gökhan Sazdağı",
        "age": 32,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 74,
        "stamina": 85,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 78,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "ame-3",
        "name": "Alexandre Manuel Penetra Correia",
        "age": 25,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Portekiz",
        "attributes": {
          "pace": 79,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "ame-4",
        "name": "Hrvoje Smolcic",
        "age": 26,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 75,
        "stamina": 92,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Hırvatistan",
        "attributes": {
          "pace": 73,
          "shooting": 50,
          "passing": 67,
          "defending": 79,
          "physical": 78
        },
        "isStarting": true
      },
      {
        "id": "ame-5",
        "name": "Andrei Borza",
        "age": 21,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 73,
        "stamina": 88,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Romanya",
        "attributes": {
          "pace": 75,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "ame-6",
        "name": "Ylber Ramadani",
        "age": 30,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 76,
        "stamina": 90,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Arnavutluk",
        "attributes": {
          "pace": 74,
          "shooting": 71,
          "passing": 81,
          "defending": 71,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "ame-7",
        "name": "Fredy Alfredo",
        "age": 36,
        "position": "MID",
        "specificRole": "CM",
        "overall": 74,
        "stamina": 91,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Angola",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "ame-8",
        "name": "Danijel Aleksic",
        "age": 35,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 74,
        "stamina": 85,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Sırbistan",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "ame-9",
        "name": "Serdar Gürler",
        "age": 35,
        "position": "FW",
        "specificRole": "RW",
        "overall": 75,
        "stamina": 87,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "ame-10",
        "name": "Hermenegildo da Costa Paulo Bartolomeu",
        "age": 35,
        "position": "FW",
        "specificRole": "LW",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Angola",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "ame-11",
        "name": "Mame Thiam",
        "age": 34,
        "position": "FW",
        "specificRole": "ST",
        "overall": 77,
        "stamina": 89,
        "form": 7.7,
        "marketValue": 9240000,
        "nationality": "Senegal",
        "attributes": {
          "pace": 83,
          "shooting": 81,
          "passing": 72,
          "defending": 35,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "ame-12",
        "name": "Erhan Erentürk",
        "age": 31,
        "position": "GK",
        "specificRole": "GK",
        "overall": 73,
        "stamina": 86,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 48,
          "shooting": 15,
          "passing": 63,
          "defending": 73,
          "physical": 68
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "ame-13",
        "name": "Serdar Saatçı",
        "age": 23,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 88,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "ame-14",
        "name": "Arda Şengül",
        "age": 28,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 70,
        "stamina": 91,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 45,
          "passing": 62,
          "defending": 74,
          "physical": 73
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "ame-15",
        "name": "Cemali Sertel",
        "age": 27,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 72,
        "stamina": 89,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 76,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "ame-16",
        "name": "Joseph Attamah",
        "age": 32,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 72,
        "stamina": 88,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Gana",
        "attributes": {
          "pace": 75,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "ame-17",
        "name": "Sinan Osmanoğlu",
        "age": 37,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 72,
        "stamina": 90,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 70,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": false
      },
      {
        "id": "ame-18",
        "name": "Hasan Abdulkareem Sayyid",
        "age": 27,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 71,
        "stamina": 86,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Irak",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "ame-19",
        "name": "Pedro Filipe Barbosa Moreira",
        "age": 34,
        "position": "MID",
        "specificRole": "CM",
        "overall": 72,
        "stamina": 90,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Portekiz",
        "attributes": {
          "pace": 70,
          "shooting": 67,
          "passing": 77,
          "defending": 67,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "ame-20",
        "name": "Ferhat Yazgan",
        "age": 34,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 73,
        "stamina": 91,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 71,
          "shooting": 68,
          "passing": 78,
          "defending": 68,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "ame-21",
        "name": "Ahmed Ildız",
        "age": 30,
        "position": "MID",
        "specificRole": "CM",
        "overall": 72,
        "stamina": 92,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 70,
          "shooting": 67,
          "passing": 77,
          "defending": 67,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "ame-22",
        "name": "Atakan Akkaynak",
        "age": 28,
        "position": "MID",
        "specificRole": "CM",
        "overall": 72,
        "stamina": 89,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 70,
          "shooting": 67,
          "passing": 77,
          "defending": 67,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "ame-23",
        "name": "Atakan Cangöz",
        "age": 34,
        "position": "MID",
        "specificRole": "CM",
        "overall": 70,
        "stamina": 90,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 68,
          "shooting": 65,
          "passing": 75,
          "defending": 65,
          "physical": 70
        },
        "isStarting": false
      },
      {
        "id": "ame-24",
        "name": "Eren Karadağ",
        "age": 27,
        "position": "MID",
        "specificRole": "LM",
        "overall": 71,
        "stamina": 86,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "ame-25",
        "name": "Emeka Friday Eze",
        "age": 30,
        "position": "FW",
        "specificRole": "ST",
        "overall": 73,
        "stamina": 85,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Nijerya",
        "attributes": {
          "pace": 79,
          "shooting": 77,
          "passing": 68,
          "defending": 35,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "ame-26",
        "name": "Emircan Gürlük",
        "age": 23,
        "position": "FW",
        "specificRole": "LW",
        "overall": 72,
        "stamina": 86,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 78,
          "shooting": 76,
          "passing": 67,
          "defending": 35,
          "physical": 72
        },
        "isStarting": false
      },
      {
        "id": "ame-27",
        "name": "Hüseyin Bulut",
        "age": 27,
        "position": "FW",
        "specificRole": "LW",
        "overall": 70,
        "stamina": 85,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 76,
          "shooting": 74,
          "passing": 65,
          "defending": 35,
          "physical": 70
        },
        "isStarting": false
      },
      {
        "id": "ame-28",
        "name": "Burak Çoban",
        "age": 32,
        "position": "FW",
        "specificRole": "LW",
        "overall": 71,
        "stamina": 85,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 77,
          "shooting": 75,
          "passing": 66,
          "defending": 35,
          "physical": 71
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "corumfk",
    "name": "Çorum FK",
    "shortName": "ÇOR",
    "badgeColor": "from-red-700 to-black",
    "badgeTextColor": "text-red-200",
    "secondaryColor": "#b91c1c",
    "stadiumName": "Çorum Şehir Stadyumu",
    "budget": 3500000,
    "reputation": 2,
    "formation": "4-3-3",
    "tactic": "BALANCED",
    "players": [
      {
        "id": "cor-1",
        "name": "Alban Lafont",
        "age": 28,
        "position": "GK",
        "specificRole": "GK",
        "overall": 78,
        "stamina": 85,
        "form": 7.8,
        "marketValue": 9360000,
        "nationality": "Fransa",
        "attributes": {
          "pace": 53,
          "shooting": 15,
          "passing": 68,
          "defending": 78,
          "physical": 73
        },
        "isStarting": true
      },
      {
        "id": "cor-2",
        "name": "Celal Hanalp",
        "age": 30,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 72,
        "stamina": 91,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 77,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "cor-3",
        "name": "David Bates",
        "age": 30,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 90,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "İskoçya",
        "attributes": {
          "pace": 76,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "cor-4",
        "name": "Mehmet Yeşil",
        "age": 28,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 73,
        "stamina": 89,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "cor-5",
        "name": "Umut Meraş",
        "age": 31,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 73,
        "stamina": 92,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 73,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "cor-6",
        "name": "Rayan Raveloson",
        "age": 30,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 75,
        "stamina": 91,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Madagaskar",
        "attributes": {
          "pace": 73,
          "shooting": 70,
          "passing": 80,
          "defending": 70,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "cor-7",
        "name": "Furkan Soyalp",
        "age": 31,
        "position": "MID",
        "specificRole": "CM",
        "overall": 73,
        "stamina": 89,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 71,
          "shooting": 68,
          "passing": 78,
          "defending": 68,
          "physical": 73
        },
        "isStarting": true
      },
      {
        "id": "cor-8",
        "name": "Çekdar Orhan",
        "age": 28,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 74,
        "stamina": 90,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "cor-9",
        "name": "Ermal Krasniqi",
        "age": 28,
        "position": "FW",
        "specificRole": "RW",
        "overall": 75,
        "stamina": 87,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Kosova",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "cor-10",
        "name": "Daniel Moreno Mosquera",
        "age": 32,
        "position": "FW",
        "specificRole": "LW",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Kolombiya",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "cor-11",
        "name": "Mbaye Diagne",
        "age": 35,
        "position": "FW",
        "specificRole": "ST",
        "overall": 76,
        "stamina": 86,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Senegal",
        "attributes": {
          "pace": 82,
          "shooting": 80,
          "passing": 71,
          "defending": 35,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "cor-12",
        "name": "Abdulsamed Damlu",
        "age": 27,
        "position": "GK",
        "specificRole": "GK",
        "overall": 69,
        "stamina": 86,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 44,
          "shooting": 15,
          "passing": 59,
          "defending": 69,
          "physical": 64
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "cor-13",
        "name": "Burak Bozan",
        "age": 26,
        "position": "GK",
        "specificRole": "GK",
        "overall": 70,
        "stamina": 91,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 45,
          "shooting": 15,
          "passing": 60,
          "defending": 70,
          "physical": 65
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "cor-14",
        "name": "Veysel Sapan",
        "age": 31,
        "position": "GK",
        "specificRole": "GK",
        "overall": 69,
        "stamina": 90,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 44,
          "shooting": 15,
          "passing": 59,
          "defending": 69,
          "physical": 64
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "cor-15",
        "name": "Amadou Cissé",
        "age": 20,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 67,
        "stamina": 90,
        "form": 6.7,
        "marketValue": 8040000,
        "nationality": "Gine",
        "attributes": {
          "pace": 68,
          "shooting": 42,
          "passing": 59,
          "defending": 71,
          "physical": 70
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "cor-16",
        "name": "Lumbardh Dellova",
        "age": 28,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 73,
        "stamina": 85,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Kosova",
        "attributes": {
          "pace": 76,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "cor-17",
        "name": "Miraç Acer",
        "age": 30,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 71,
        "stamina": 85,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 46,
          "passing": 63,
          "defending": 75,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "cor-18",
        "name": "Tarkan Serbest",
        "age": 32,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 73,
        "stamina": 87,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 77,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": false
      },
      {
        "id": "cor-19",
        "name": "Kahraman Demirtaş",
        "age": 32,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 71,
        "stamina": 89,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 76,
          "shooting": 46,
          "passing": 63,
          "defending": 75,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "cor-20",
        "name": "Cem Üstündağ",
        "age": 26,
        "position": "MID",
        "specificRole": "CM",
        "overall": 71,
        "stamina": 89,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Avusturya",
        "attributes": {
          "pace": 69,
          "shooting": 66,
          "passing": 76,
          "defending": 66,
          "physical": 71
        },
        "isStarting": false
      },
      {
        "id": "cor-21",
        "name": "Gift Emmanuel Orban",
        "age": 24,
        "position": "FW",
        "specificRole": "ST",
        "overall": 76,
        "stamina": 89,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Nijerya",
        "attributes": {
          "pace": 82,
          "shooting": 80,
          "passing": 71,
          "defending": 35,
          "physical": 76
        },
        "isStarting": false
      },
      {
        "id": "cor-22",
        "name": "Mohamed Khalil",
        "age": 26,
        "position": "FW",
        "specificRole": "ST",
        "overall": 69,
        "stamina": 85,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 75,
          "shooting": 73,
          "passing": 64,
          "defending": 35,
          "physical": 69
        },
        "isStarting": false
      },
      {
        "id": "cor-23",
        "name": "Florent Hasani",
        "age": 29,
        "position": "FW",
        "specificRole": "CAM",
        "overall": 73,
        "stamina": 89,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Kosova",
        "attributes": {
          "pace": 79,
          "shooting": 77,
          "passing": 68,
          "defending": 35,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "cor-24",
        "name": "Zdravko Minchev Dimitrov",
        "age": 28,
        "position": "FW",
        "specificRole": "LW",
        "overall": 73,
        "stamina": 90,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Bulgaristan",
        "attributes": {
          "pace": 79,
          "shooting": 77,
          "passing": 68,
          "defending": 35,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "cor-25",
        "name": "Dia Saba",
        "age": 34,
        "position": "FW",
        "specificRole": "CAM",
        "overall": 75,
        "stamina": 90,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "İsrail",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": false
      }
    ]
  },
  {
    "id": "genclerbirligi",
    "name": "Gençlerbirliği",
    "shortName": "GÇB",
    "badgeColor": "from-red-600 to-black",
    "badgeTextColor": "text-red-200",
    "secondaryColor": "#dc2626",
    "stadiumName": "Eryaman Stadyumu",
    "budget": 4800000,
    "reputation": 3,
    "formation": "4-2-3-1",
    "tactic": "ATTACKING",
    "players": [
      {
        "id": "gen-1",
        "name": "Atalay Gökçe",
        "age": 22,
        "position": "GK",
        "specificRole": "GK",
        "overall": 74,
        "stamina": 86,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 49,
          "shooting": 15,
          "passing": 64,
          "defending": 74,
          "physical": 69
        },
        "isStarting": true
      },
      {
        "id": "gen-2",
        "name": "Alperen Babacan",
        "age": 29,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 73,
        "stamina": 89,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 71,
          "shooting": 48,
          "passing": 65,
          "defending": 77,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "gen-3",
        "name": "Zan Zuzek",
        "age": 29,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 74,
        "stamina": 91,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Slovenya",
        "attributes": {
          "pace": 77,
          "shooting": 49,
          "passing": 66,
          "defending": 78,
          "physical": 77
        },
        "isStarting": true
      },
      {
        "id": "gen-4",
        "name": "Fıratcan Üzüm",
        "age": 27,
        "position": "DEF",
        "specificRole": "RB",
        "overall": 71,
        "stamina": 92,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 70,
          "shooting": 46,
          "passing": 63,
          "defending": 75,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "gen-5",
        "name": "Yasin Güreler",
        "age": 35,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 72,
        "stamina": 89,
        "form": 7.2,
        "marketValue": 8640000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 74,
          "shooting": 47,
          "passing": 64,
          "defending": 76,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "gen-6",
        "name": "Oghenekaro Peter Etebo",
        "age": 31,
        "position": "MID",
        "specificRole": "CDM",
        "overall": 76,
        "stamina": 89,
        "form": 7.6,
        "marketValue": 9120000,
        "nationality": "Nijerya",
        "attributes": {
          "pace": 74,
          "shooting": 71,
          "passing": 81,
          "defending": 71,
          "physical": 76
        },
        "isStarting": true
      },
      {
        "id": "gen-7",
        "name": "Metehan Mimaroğlu",
        "age": 31,
        "position": "FW",
        "specificRole": "LW",
        "overall": 74,
        "stamina": 92,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "gen-8",
        "name": "Amilton",
        "age": 37,
        "position": "FW",
        "specificRole": "RW",
        "overall": 75,
        "stamina": 85,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Brezilya",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "gen-9",
        "name": "Rahman Buğra Çağıran",
        "age": 31,
        "position": "MID",
        "specificRole": "CAM",
        "overall": 74,
        "stamina": 90,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 69,
          "passing": 79,
          "defending": 69,
          "physical": 74
        },
        "isStarting": true
      },
      {
        "id": "gen-10",
        "name": "Moussa Djitte",
        "age": 27,
        "position": "FW",
        "specificRole": "ST",
        "overall": 73,
        "stamina": 89,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Senegal",
        "attributes": {
          "pace": 79,
          "shooting": 77,
          "passing": 68,
          "defending": 35,
          "physical": 73
        },
        "isStarting": true
      },
      {
        "id": "gen-11",
        "name": "Mustapha Yatabare",
        "age": 40,
        "position": "FW",
        "specificRole": "ST",
        "overall": 75,
        "stamina": 91,
        "form": 7.5,
        "marketValue": 9000000,
        "nationality": "Mali",
        "attributes": {
          "pace": 81,
          "shooting": 79,
          "passing": 70,
          "defending": 35,
          "physical": 75
        },
        "isStarting": true
      },
      {
        "id": "gen-12",
        "name": "Orkun Özdemir",
        "age": 31,
        "position": "GK",
        "specificRole": "GK",
        "overall": 70,
        "stamina": 86,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 45,
          "shooting": 15,
          "passing": 60,
          "defending": 70,
          "physical": 65
        },
        "isStarting": false,
        "subOrder": 1
      },
      {
        "id": "gen-13",
        "name": "Musa Şahindere",
        "age": 23,
        "position": "DEF",
        "specificRole": "CB",
        "overall": 68,
        "stamina": 92,
        "form": 6.8,
        "marketValue": 8160000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 69,
          "shooting": 43,
          "passing": 60,
          "defending": 72,
          "physical": 71
        },
        "isStarting": false,
        "subOrder": 2
      },
      {
        "id": "gen-14",
        "name": "Halil İbrahim Pehlivan",
        "age": 33,
        "position": "DEF",
        "specificRole": "LB",
        "overall": 71,
        "stamina": 90,
        "form": 7.1,
        "marketValue": 8520000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 69,
          "shooting": 46,
          "passing": 63,
          "defending": 75,
          "physical": 74
        },
        "isStarting": false,
        "subOrder": 3
      },
      {
        "id": "gen-15",
        "name": "Mikail Okyar",
        "age": 27,
        "position": "MID",
        "specificRole": "CM",
        "overall": 73,
        "stamina": 87,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 71,
          "shooting": 68,
          "passing": 78,
          "defending": 68,
          "physical": 73
        },
        "isStarting": false,
        "subOrder": 4
      },
      {
        "id": "gen-16",
        "name": "Enes Tepecik",
        "age": 20,
        "position": "MID",
        "specificRole": "CM",
        "overall": 70,
        "stamina": 87,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 68,
          "shooting": 65,
          "passing": 75,
          "defending": 65,
          "physical": 70
        },
        "isStarting": false,
        "subOrder": 5
      },
      {
        "id": "gen-17",
        "name": "Sedat Şahintürk",
        "age": 28,
        "position": "MID",
        "specificRole": "LM",
        "overall": 69,
        "stamina": 88,
        "form": 6.9,
        "marketValue": 8280000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 77,
          "shooting": 64,
          "passing": 71,
          "defending": 45,
          "physical": 69
        },
        "isStarting": false
      },
      {
        "id": "gen-18",
        "name": "Awer Mabil",
        "age": 30,
        "position": "FW",
        "specificRole": "LW",
        "overall": 74,
        "stamina": 90,
        "form": 7.4,
        "marketValue": 8880000,
        "nationality": "Avustralya",
        "attributes": {
          "pace": 80,
          "shooting": 78,
          "passing": 69,
          "defending": 35,
          "physical": 74
        },
        "isStarting": false
      },
      {
        "id": "gen-19",
        "name": "Elias Durmaz",
        "age": 26,
        "position": "FW",
        "specificRole": "RW",
        "overall": 70,
        "stamina": 85,
        "form": 7,
        "marketValue": 8400000,
        "nationality": "İsveç",
        "attributes": {
          "pace": 76,
          "shooting": 74,
          "passing": 65,
          "defending": 35,
          "physical": 70
        },
        "isStarting": false
      },
      {
        "id": "gen-20",
        "name": "Olarenwaju Kayode",
        "age": 33,
        "position": "FW",
        "specificRole": "ST",
        "overall": 73,
        "stamina": 90,
        "form": 7.3,
        "marketValue": 8760000,
        "nationality": "Nijerya",
        "attributes": {
          "pace": 79,
          "shooting": 77,
          "passing": 68,
          "defending": 35,
          "physical": 73
        },
        "isStarting": false
      },
      {
        "id": "gen-21",
        "name": "Zafer Göktuğ Erdem",
        "age": 22,
        "position": "FW",
        "specificRole": "ST",
        "overall": 66,
        "stamina": 92,
        "form": 6.6,
        "marketValue": 7920000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 72,
          "shooting": 70,
          "passing": 61,
          "defending": 35,
          "physical": 66
        },
        "isStarting": false
      },
      {
        "id": "gen-22",
        "name": "Arda Yılmaz",
        "age": 19,
        "position": "FW",
        "specificRole": "ST",
        "overall": 65,
        "stamina": 88,
        "form": 6.5,
        "marketValue": 7800000,
        "nationality": "Türkiye",
        "attributes": {
          "pace": 71,
          "shooting": 69,
          "passing": 60,
          "defending": 35,
          "physical": 65
        },
        "isStarting": false
      },
      {
        "id": "gen-23",
        "name": "Berat Kalkan",
        "age": 21,
        "position": "FW",
        "specificRole": "RW",
        "overall": 68,
        "stamina": 88,
        "form": 6.8,
        "marketValue": 8100000,
        "nationality": "Kuzey Makedonya",
        "attributes": {
          "pace": 78,
          "shooting": 67,
          "passing": 64,
          "defending": 35,
          "physical": 68
        },
        "isStarting": false
      }
    ]
  }
];

export const SUPER_LIG_TEAMS: Team[] = validateAndDeduplicateTeams(RAW_SUPER_LIG_TEAMS);

export const SUPER_LIG_LEAGUE_TABLE: LeagueRow[] = SUPER_LIG_TEAMS.map(team => ({
  teamId: team.id,
  teamName: team.name,
  played: 0,
  won: 0,
  drawn: 0,
  lost: 0,
  goalsFor: 0,
  goalsAgainst: 0,
  goalDifference: 0,
  points: 0,
  formHistory: []
}));
