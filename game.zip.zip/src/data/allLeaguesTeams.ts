import { SUPER_LIG_TEAMS } from './superLigTeams';
import { ENGLISH_TEAMS } from './englishTeams';
import { SPANISH_TEAMS } from './spanishTeams';
import { SERIE_A_TEAMS } from './serieATeams';
import { BUNDESLIGA_TEAMS } from './bundesligaTeams';
import { LIGUE1_TEAMS } from './ligue1Teams';
import { ADDITIONAL_EUROPEAN_TEAMS } from './europeanTeams';
import { UCL_TEAMS, UEL_TEAMS, UECL_TEAMS } from './europeanCompetitions';

export interface DevTeamInfo {
  id: string;
  name: string;
  shortName?: string;
  league: string;
  country?: string;
  badgeColor?: string;
}

export const getAllGameTeamsForDev = (): DevTeamInfo[] => {
  const list: DevTeamInfo[] = [];
  const seenIds = new Set<string>();

  // 1. Süper Lig
  SUPER_LIG_TEAMS.forEach((t) => {
    if (!seenIds.has(t.id)) {
      seenIds.add(t.id);
      list.push({
        id: t.id,
        name: t.name,
        shortName: t.shortName,
        league: 'Süper Lig (Türkiye)',
        country: 'Türkiye',
        badgeColor: t.badgeColor
      });
    }
  });

  // 2. English Premier League
  ENGLISH_TEAMS.forEach((t) => {
    if (!seenIds.has(t.id)) {
      seenIds.add(t.id);
      list.push({
        id: t.id,
        name: t.name,
        shortName: t.shortName,
        league: 'Premier League (İngiltere)',
        country: 'İngiltere',
        badgeColor: t.badgeColor
      });
    }
  });

  // 3. Spanish La Liga
  SPANISH_TEAMS.forEach((t) => {
    if (!seenIds.has(t.id)) {
      seenIds.add(t.id);
      list.push({
        id: t.id,
        name: t.name,
        shortName: t.shortName,
        league: 'La Liga (İspanya)',
        country: 'İspanya',
        badgeColor: t.badgeColor
      });
    }
  });

  // 4. Italian Serie A
  SERIE_A_TEAMS.forEach((t) => {
    if (!seenIds.has(t.id)) {
      seenIds.add(t.id);
      list.push({
        id: t.id,
        name: t.name,
        shortName: t.shortName,
        league: 'Serie A (İtalya)',
        country: 'İtalya',
        badgeColor: t.badgeColor
      });
    }
  });

  // 5. German Bundesliga
  BUNDESLIGA_TEAMS.forEach((t) => {
    if (!seenIds.has(t.id)) {
      seenIds.add(t.id);
      list.push({
        id: t.id,
        name: t.name,
        shortName: t.shortName,
        league: 'Bundesliga (Almanya)',
        country: 'Almanya',
        badgeColor: t.badgeColor
      });
    }
  });

  // 6. French Ligue 1
  LIGUE1_TEAMS.forEach((t) => {
    if (!seenIds.has(t.id)) {
      seenIds.add(t.id);
      list.push({
        id: t.id,
        name: t.name,
        shortName: t.shortName,
        league: 'Ligue 1 (Fransa)',
        country: 'Fransa',
        badgeColor: t.badgeColor
      });
    }
  });

  // 7. Additional European & Tournament Teams
  ADDITIONAL_EUROPEAN_TEAMS.forEach((t) => {
    if (!seenIds.has(t.id)) {
      seenIds.add(t.id);
      list.push({
        id: t.id,
        name: t.name,
        shortName: t.shortName,
        league: 'Avrupa & Dünya Kulüpleri',
        country: t.country || 'Avrupa',
        badgeColor: t.badgeColor
      });
    }
  });

  // 8. European Competitions Teams
  [...UCL_TEAMS, ...UEL_TEAMS, ...UECL_TEAMS].forEach((t) => {
    if (!seenIds.has(t.id)) {
      seenIds.add(t.id);
      list.push({
        id: t.id,
        name: t.name,
        shortName: t.shortName,
        league: 'UEFA Turnuva Kulüpleri',
        country: t.country || 'Avrupa',
        badgeColor: t.badgeColor
      });
    }
  });

  return list;
};
