import { ExternalTeamData } from '../components/WorldScoutModal';
import { Player, Team } from '../types';

export interface EuropeanTournamentConfig {
  id: 'ucl' | 'uel' | 'uecl';
  name: string;
  shortName: string;
  fullName: string;
  badge: string;
  badgeBg: string;
  logoUrl: string;
  themeColor: string;
  accentColor: string;
  description: string;
  totalTeams: number;
  prizeMoney: {
    qualification: number;
    matchWin: number;
    matchDraw: number;
    roundOf16: number;
    quarterFinal: number;
    semiFinal: number;
    runnerUp: number;
    champion: number;
  };
  rules: {
    directRoundOf16: number; // 1-8
    playoffRound: number;    // 9-24
    eliminated: number;      // 25-36
  };
}

export const UEFA_COMPETITIONS: EuropeanTournamentConfig[] = [
  {
    id: 'ucl',
    name: 'Şampiyonlar Ligi',
    shortName: 'UCL',
    fullName: 'UEFA Champions League',
    badge: '⭐',
    badgeBg: 'bg-blue-950/80 text-blue-300 border-blue-500/40',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/en/b/bf/UEFA_Champions_League_logo_2.svg',
    themeColor: 'from-[#001438] via-[#082057] to-[#000a1f]',
    accentColor: '#3b82f6',
    description: 'Avrupa kulüp futbolunun en prestijli turnuvası. Yeni 36 takımlı lig aşaması formatında zirve mücadelesi.',
    totalTeams: 36,
    prizeMoney: {
      qualification: 18620000,
      matchWin: 2100000,
      matchDraw: 700000,
      roundOf16: 11000000,
      quarterFinal: 12500000,
      semiFinal: 15000000,
      runnerUp: 18500000,
      champion: 25000000,
    },
    rules: {
      directRoundOf16: 8,
      playoffRound: 24,
      eliminated: 36,
    }
  },
  {
    id: 'uel',
    name: 'Avrupa Ligi',
    shortName: 'UEL',
    fullName: 'UEFA Europa League',
    badge: '🏆',
    badgeBg: 'bg-orange-950/80 text-orange-300 border-orange-500/40',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/en/0/03/UEFA_Europa_League_logo_%282024%29.svg',
    themeColor: 'from-[#2b1000] via-[#4d2100] to-[#170800]',
    accentColor: '#f97316',
    description: 'Avrupa nın zorlu ve dinamik ikinci büyük kupası. 36 takımlı lig aşaması ve kıyasıya eleme turları.',
    totalTeams: 36,
    prizeMoney: {
      qualification: 4310000,
      matchWin: 450000,
      matchDraw: 150000,
      roundOf16: 1750000,
      quarterFinal: 2500000,
      semiFinal: 4200000,
      runnerUp: 7000000,
      champion: 13000000,
    },
    rules: {
      directRoundOf16: 8,
      playoffRound: 24,
      eliminated: 36,
    }
  },
  {
    id: 'uecl',
    name: 'Konferans Ligi',
    shortName: 'UECL',
    fullName: 'UEFA Conference League',
    badge: '🛡️',
    badgeBg: 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/en/9/91/UEFA_Conference_League_logo_%282024%29.svg',
    themeColor: 'from-[#002411] via-[#014220] to-[#00170a]',
    accentColor: '#10b981',
    description: 'Avrupa nın en hızlı yükselen ve heyecan dolu turnuvası. Yeni şampiyonlukların doğduğu sahne.',
    totalTeams: 36,
    prizeMoney: {
      qualification: 3170000,
      matchWin: 400000,
      matchDraw: 133000,
      roundOf16: 800000,
      quarterFinal: 1300000,
      semiFinal: 2500000,
      runnerUp: 4000000,
      champion: 7000000,
    },
    rules: {
      directRoundOf16: 8,
      playoffRound: 24,
      eliminated: 36,
    }
  }
];

export interface EuropeanTournamentTeam {
  id: string;
  name: string;
  shortName: string;
  country: string;
  flag: string;
  overall: number;
  badgeColor: string;
}

// 36 Teams for UEFA Champions League
export const UCL_TEAMS: EuropeanTournamentTeam[] = [
  { id: 'real-madrid', name: 'Real Madrid', shortName: 'RMA', country: 'İspanya', flag: '🇪🇸', overall: 89, badgeColor: 'from-amber-400 to-slate-900' },
  { id: 'manchester-city', name: 'Manchester City', shortName: 'MCI', country: 'İngiltere', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', overall: 89, badgeColor: 'from-sky-400 to-blue-800' },
  { id: 'bayern-munich', name: 'Bayern München', shortName: 'BAY', country: 'Almanya', flag: '🇩🇪', overall: 88, badgeColor: 'from-red-600 to-blue-900' },
  { id: 'psg', name: 'Paris Saint-Germain', shortName: 'PSG', country: 'Fransa', flag: '🇫🇷', overall: 87, badgeColor: 'from-blue-900 to-red-600' },
  { id: 'liverpool', name: 'Liverpool FC', shortName: 'LIV', country: 'İngiltere', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', overall: 87, badgeColor: 'from-red-600 to-red-900' },
  { id: 'arsenal', name: 'Arsenal FC', shortName: 'ARS', country: 'İngiltere', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', overall: 87, badgeColor: 'from-red-600 to-white' },
  { id: 'inter-milan', name: 'Inter Milan', shortName: 'INT', country: 'İtalya', flag: '🇮🇹', overall: 86, badgeColor: 'from-blue-600 to-black' },
  { id: 'fc-barcelona', name: 'FC Barcelona', shortName: 'BAR', country: 'İspanya', flag: '🇪🇸', overall: 87, badgeColor: 'from-blue-700 to-red-600' },
  { id: 'bayer-leverkusen', name: 'Bayer Leverkusen', shortName: 'B04', country: 'Almanya', flag: '🇩🇪', overall: 86, badgeColor: 'from-red-600 to-black' },
  { id: 'atletico-madrid', name: 'Atlético Madrid', shortName: 'ATM', country: 'İspanya', flag: '🇪🇸', overall: 85, badgeColor: 'from-red-600 to-blue-800' },
  { id: 'borussia-dortmund', name: 'Borussia Dortmund', shortName: 'BVB', country: 'Almanya', flag: '🇩🇪', overall: 85, badgeColor: 'from-yellow-400 to-black' },
  { id: 'juventus', name: 'Juventus', shortName: 'JUV', country: 'İtalya', flag: '🇮🇹', overall: 84, badgeColor: 'from-black to-white' },
  { id: 'ac-milan', name: 'AC Milan', shortName: 'MIL', country: 'İtalya', flag: '🇮🇹', overall: 84, badgeColor: 'from-red-600 to-black' },
  { id: 'atalanta', name: 'Atalanta BC', shortName: 'ATA', country: 'İtalya', flag: '🇮🇹', overall: 83, badgeColor: 'from-blue-600 to-black' },
  { id: 'aston-villa', name: 'Aston Villa', shortName: 'AVL', country: 'İngiltere', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', overall: 83, badgeColor: 'from-purple-800 to-sky-400' },
  { id: 'sporting-cp', name: 'Sporting CP', shortName: 'SCP', country: 'Portekiz', flag: '🇵🇹', overall: 84, badgeColor: 'from-emerald-600 to-white' },
  { id: 'as-monaco', name: 'AS Monaco', shortName: 'ASM', country: 'Fransa', flag: '🇫🇷', overall: 83, badgeColor: 'from-red-600 to-white' },
  { id: 'losc-lille', name: 'LOSC Lille', shortName: 'LIL', country: 'Fransa', flag: '🇫🇷', overall: 82, badgeColor: 'from-red-600 to-blue-900' },
  { id: 'rb-leipzig', name: 'RB Leipzig', shortName: 'RBL', country: 'Almanya', flag: '🇩🇪', overall: 83, badgeColor: 'from-white to-red-600' },
  { id: 'vfb-stuttgart', name: 'VfB Stuttgart', shortName: 'VFB', country: 'Almanya', flag: '🇩🇪', overall: 82, badgeColor: 'from-red-600 to-white' },
  { id: 'eintracht-frankfurt', name: 'Eintracht Frankfurt', shortName: 'SGE', country: 'Almanya', flag: '🇩🇪', overall: 82, badgeColor: 'from-red-600 to-black' },
  { id: 'psv-eindhoven', name: 'PSV Eindhoven', shortName: 'PSV', country: 'Hollanda', flag: '🇳🇱', overall: 84, badgeColor: 'from-red-600 to-white' },
  { id: 'feyenoord', name: 'Feyenoord Rotterdam', shortName: 'FEY', country: 'Hollanda', flag: '🇳🇱', overall: 83, badgeColor: 'from-red-600 to-white' },
  { id: 'galatasaray', name: 'Galatasaray SK', shortName: 'GS', country: 'Türkiye', flag: '🇹🇷', overall: 83, badgeColor: 'from-red-600 to-amber-500' },
  { id: 'stade-brestois', name: 'Stade Brestois 29', shortName: 'SB29', country: 'Fransa', flag: '🇫🇷', overall: 79, badgeColor: 'from-red-600 to-white' },
  { id: 'bologna-fc', name: 'Bologna FC', shortName: 'BFC', country: 'İtalya', flag: '🇮🇹', overall: 81, badgeColor: 'from-blue-900 to-red-600' },
  { id: 'girona-fc', name: 'Girona FC', shortName: 'GIR', country: 'İspanya', flag: '🇪🇸', overall: 81, badgeColor: 'from-red-600 to-white' },
  { id: 'celtic-fc', name: 'Celtic FC', shortName: 'CEL', country: 'İskoçya', flag: '🏴󠁧󠁢󠁳󠁣󠁴󠁿', overall: 80, badgeColor: 'from-green-600 to-white' },
  { id: 'club-brugge', name: 'Club Brugge', shortName: 'CLU', country: 'Belçika', flag: '🇧🇪', overall: 80, badgeColor: 'from-blue-600 to-black' },
  { id: 'shakhtar-donetsk', name: 'Shakhtar Donetsk', shortName: 'SHK', country: 'Ukrayna', flag: '🇺🇦', overall: 80, badgeColor: 'from-orange-500 to-black' },
  { id: 'red-star-belgrade', name: 'Kızılyıldız', shortName: 'RSB', country: 'Sırbistan', flag: '🇷🇸', overall: 78, badgeColor: 'from-red-600 to-white' },
  { id: 'dinamo-zagreb', name: 'Dinamo Zagreb', shortName: 'DZG', country: 'Hırvatistan', flag: '🇭🇷', overall: 79, badgeColor: 'from-blue-600 to-white' },
  { id: 'rb-salzburg', name: 'RB Salzburg', shortName: 'RBS', country: 'Avusturya', flag: '🇦🇹', overall: 79, badgeColor: 'from-red-600 to-white' },
  { id: 'sparta-prague', name: 'Sparta Prag', shortName: 'SPA', country: 'Çekya', flag: '🇨🇿', overall: 79, badgeColor: 'from-red-600 to-blue-600' },
  { id: 'sturm-graz', name: 'Sturm Graz', shortName: 'STU', country: 'Avusturya', flag: '🇦🇹', overall: 78, badgeColor: 'from-black to-white' },
  { id: 'young-boys', name: 'Young Boys', shortName: 'YB', country: 'İsviçre', flag: '🇨🇭', overall: 78, badgeColor: 'from-yellow-400 to-black' }
];

// 36 Teams for UEFA Europa League
export const UEL_TEAMS: EuropeanTournamentTeam[] = [
  { id: 'manchester-united', name: 'Manchester United', shortName: 'MUN', country: 'İngiltere', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', overall: 85, badgeColor: 'from-red-600 to-yellow-500' },
  { id: 'tottenham-hotspur', name: 'Tottenham Hotspur', shortName: 'TOT', country: 'İngiltere', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', overall: 84, badgeColor: 'from-blue-900 to-white' },
  { id: 'as-roma', name: 'AS Roma', shortName: 'ASR', country: 'İtalya', flag: '🇮🇹', overall: 83, badgeColor: 'from-amber-600 to-red-800' },
  { id: 'ss-lazio', name: 'SS Lazio', shortName: 'LAZ', country: 'İtalya', flag: '🇮🇹', overall: 83, badgeColor: 'from-sky-400 to-white' },
  { id: 'athletic-bilbao', name: 'Athletic Bilbao', shortName: 'ATH', country: 'İspanya', flag: '🇪🇸', overall: 84, badgeColor: 'from-red-600 to-white' },
  { id: 'real-sociedad', name: 'Real Sociedad', shortName: 'RSO', country: 'İspanya', flag: '🇪🇸', overall: 83, badgeColor: 'from-blue-600 to-white' },
  { id: 'olympique-lyonnais', name: 'Olympique Lyonnais', shortName: 'OL', country: 'Fransa', flag: '🇫🇷', overall: 82, badgeColor: 'from-blue-700 to-red-600' },
  { id: 'olympique-marseille', name: 'Olympique de Marseille', shortName: 'OM', country: 'Fransa', flag: '🇫🇷', overall: 83, badgeColor: 'from-sky-400 to-white' },
  { id: 'fc-porto', name: 'FC Porto', shortName: 'FCP', country: 'Portekiz', flag: '🇵🇹', overall: 83, badgeColor: 'from-blue-700 to-white' },
  { id: 'sc-braga', name: 'SC Braga', shortName: 'SCB', country: 'Portekiz', flag: '🇵🇹', overall: 80, badgeColor: 'from-red-600 to-white' },
  { id: 'ajax', name: 'AFC Ajax', shortName: 'AJX', country: 'Hollanda', flag: '🇳🇱', overall: 82, badgeColor: 'from-red-600 to-white' },
  { id: 'az-alkmaar', name: 'AZ Alkmaar', shortName: 'AZ', country: 'Hollanda', flag: '🇳🇱', overall: 80, badgeColor: 'from-red-600 to-white' },
  { id: 'fc-twente', name: 'FC Twente', shortName: 'TWE', country: 'Hollanda', flag: '🇳🇱', overall: 79, badgeColor: 'from-red-600 to-white' },
  { id: 'fenerbahce', name: 'Fenerbahçe SK', shortName: 'FB', country: 'Türkiye', flag: '🇹🇷', overall: 83, badgeColor: 'from-yellow-400 to-blue-900' },
  { id: 'besiktas', name: 'Beşiktaş JK', shortName: 'BJK', country: 'Türkiye', flag: '🇹🇷', overall: 81, badgeColor: 'from-black to-white' },
  { id: 'tsg-hoffenheim', name: 'TSG Hoffenheim', shortName: 'TSG', country: 'Almanya', flag: '🇩🇪', overall: 80, badgeColor: 'from-blue-600 to-white' },
  { id: 'ogc-nice', name: 'OGC Nice', shortName: 'OGCN', country: 'Fransa', flag: '🇫🇷', overall: 80, badgeColor: 'from-red-600 to-black' },
  { id: 'olympiacos', name: 'Olympiakos', shortName: 'OLY', country: 'Yunanistan', flag: '🇬🇷', overall: 80, badgeColor: 'from-red-600 to-white' },
  { id: 'paok-fc', name: 'PAOK FC', shortName: 'PAO', country: 'Yunanistan', flag: '🇬🇷', overall: 79, badgeColor: 'from-black to-white' },
  { id: 'rangers-fc', name: 'Rangers FC', shortName: 'RAN', country: 'İskoçya', flag: '🏴󠁧󠁢󠁳󠁣󠁴󠁿', overall: 79, badgeColor: 'from-blue-600 to-red-600' },
  { id: 'slavia-prague', name: 'Slavia Prag', shortName: 'SLA', country: 'Çekya', flag: '🇨🇿', overall: 80, badgeColor: 'from-red-600 to-white' },
  { id: 'viktoria-plzen', name: 'Viktoria Plzen', shortName: 'PLZ', country: 'Çekya', flag: '🇨🇿', overall: 78, badgeColor: 'from-blue-600 to-red-600' },
  { id: 'anderlecht', name: 'RSC Anderlecht', shortName: 'AND', country: 'Belçika', flag: '🇧🇪', overall: 79, badgeColor: 'from-purple-800 to-white' },
  { id: 'union-saint-gilloise', name: 'Union Saint-Gilloise', shortName: 'USG', country: 'Belçika', flag: '🇧🇪', overall: 79, badgeColor: 'from-yellow-400 to-blue-600' },
  { id: 'dynamo-kyiv', name: 'Dinamo Kiev', shortName: 'DKI', country: 'Ukrayna', flag: '🇺🇦', overall: 78, badgeColor: 'from-blue-600 to-white' },
  { id: 'maccabi-tel-aviv', name: 'Maccabi Tel Aviv', shortName: 'MTA', country: 'İsrail', flag: '🇮🇱', overall: 77, badgeColor: 'from-yellow-400 to-blue-600' },
  { id: 'malmo-ff', name: 'Malmö FF', shortName: 'MFF', country: 'İsveç', flag: '🇸🇪', overall: 77, badgeColor: 'from-sky-400 to-white' },
  { id: 'bodo-glimt', name: 'Bodø/Glimt', shortName: 'BOD', country: 'Norveç', flag: '🇳🇴', overall: 78, badgeColor: 'from-yellow-400 to-black' },
  { id: 'midtjylland', name: 'FC Midtjylland', shortName: 'FCM', country: 'Danimarka', flag: '🇩🇰', overall: 78, badgeColor: 'from-red-600 to-black' },
  { id: 'elfsborg', name: 'IF Elfsborg', shortName: 'ELF', country: 'İsveç', flag: '🇸🇪', overall: 76, badgeColor: 'from-yellow-400 to-black' },
  { id: 'fcsb', name: 'FCSB (Steaua)', shortName: 'FCS', country: 'Romanya', flag: '🇷🇴', overall: 77, badgeColor: 'from-red-600 to-blue-600' },
  { id: 'qarabag-fk', name: 'Karabağ FK', shortName: 'QAR', country: 'Azerbaycan', flag: '🇦🇿', overall: 78, badgeColor: 'from-black to-white' },
  { id: 'ferencvaros', name: 'Ferencváros', shortName: 'FTC', country: 'Macaristan', flag: '🇭🇺', overall: 77, badgeColor: 'from-green-600 to-white' },
  { id: 'ludogorets', name: 'Ludogorets Razgrad', shortName: 'LUD', country: 'Bulgaristan', flag: '🇧🇬', overall: 76, badgeColor: 'from-green-600 to-white' },
  { id: 'maccabi-haifa', name: 'Maccabi Haifa', shortName: 'MHA', country: 'İsrail', flag: '🇮🇱', overall: 76, badgeColor: 'from-green-600 to-white' },
  { id: 'rfs-riga', name: 'RFS Riga', shortName: 'RFS', country: 'Letonya', flag: '🇱🇻', overall: 73, badgeColor: 'from-blue-600 to-white' }
];

// 36 Teams for UEFA Conference League
export const UECL_TEAMS: EuropeanTournamentTeam[] = [
  { id: 'chelsea', name: 'Chelsea FC', shortName: 'CHE', country: 'İngiltere', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', overall: 85, badgeColor: 'from-blue-600 to-blue-900' },
  { id: 'acf-fiorentina', name: 'ACF Fiorentina', shortName: 'FIO', country: 'İtalya', flag: '🇮🇹', overall: 82, badgeColor: 'from-purple-800 to-white' },
  { id: 'real-betis', name: 'Real Betis', shortName: 'BET', country: 'İspanya', flag: '🇪🇸', overall: 82, badgeColor: 'from-emerald-600 to-white' },
  { id: 'fc-heidenheim', name: '1. FC Heidenheim', shortName: 'FCH', country: 'Almanya', flag: '🇩🇪', overall: 78, badgeColor: 'from-red-600 to-blue-600' },
  { id: 'rc-lens', name: 'RC Lens', shortName: 'RCL', country: 'Fransa', flag: '🇫🇷', overall: 80, badgeColor: 'from-amber-400 to-red-600' },
  { id: 'basaksehir', name: 'İstanbul Başakşehir', shortName: 'IBFK', country: 'Türkiye', flag: '🇹🇷', overall: 79, badgeColor: 'from-orange-600 to-blue-900' },
  { id: 'trabzonspor', name: 'Trabzonspor', shortName: 'TS', country: 'Türkiye', flag: '🇹🇷', overall: 80, badgeColor: 'from-red-700 to-sky-500' },
  { id: 'samsunspor', name: 'Samsunspor', shortName: 'SAM', country: 'Türkiye', flag: '🇹🇷', overall: 77, badgeColor: 'from-red-600 to-white' },
  { id: 'vitoria-guimaraes', name: 'Vitória SC', shortName: 'VSC', country: 'Portekiz', flag: '🇵🇹', overall: 78, badgeColor: 'from-black to-white' },
  { id: 'gent', name: 'KAA Gent', shortName: 'GNT', country: 'Belçika', flag: '🇧🇪', overall: 79, badgeColor: 'from-blue-600 to-white' },
  { id: 'cercle-brugge', name: 'Cercle Brugge', shortName: 'CER', country: 'Belçika', flag: '🇧🇪', overall: 77, badgeColor: 'from-green-600 to-black' },
  { id: 'panathinaikos', name: 'Panathinaikos', shortName: 'PAO', country: 'Yunanistan', flag: '🇬🇷', overall: 79, badgeColor: 'from-green-600 to-white' },
  { id: 'rapid-wien', name: 'Rapid Wien', shortName: 'RAP', country: 'Avusturya', flag: '🇦🇹', overall: 78, badgeColor: 'from-green-600 to-white' },
  { id: 'lask', name: 'LASK Linz', shortName: 'LAS', country: 'Avusturya', flag: '🇦🇹', overall: 77, badgeColor: 'from-black to-white' },
  { id: 'legia-warsaw', name: 'Legia Varşova', shortName: 'LEG', country: 'Polonya', flag: '🇵🇱', overall: 78, badgeColor: 'from-green-600 to-black' },
  { id: 'jagiellonia', name: 'Jagiellonia Białystok', shortName: 'JAG', country: 'Polonya', flag: '🇵🇱', overall: 77, badgeColor: 'from-yellow-400 to-red-600' },
  { id: 'st-gallen', name: 'FC St. Gallen', shortName: 'STG', country: 'İsviçre', flag: '🇨🇭', overall: 77, badgeColor: 'from-green-600 to-white' },
  { id: 'lugano', name: 'FC Lugano', shortName: 'LUG', country: 'İsviçre', flag: '🇨🇭', overall: 77, badgeColor: 'from-black to-white' },
  { id: 'apoel-nicosia', name: 'APOEL Nicosia', shortName: 'APO', country: 'Kıbrıs', flag: '🇨🇾', overall: 76, badgeColor: 'from-yellow-400 to-blue-600' },
  { id: 'omonia-nicosia', name: 'Omonia Nicosia', shortName: 'OMO', country: 'Kıbrıs', flag: '🇨🇾', overall: 76, badgeColor: 'from-green-600 to-white' },
  { id: 'pafos-fc', name: 'Pafos FC', shortName: 'PAF', country: 'Kıbrıs', flag: '🇨🇾', overall: 76, badgeColor: 'from-blue-600 to-white' },
  { id: 'hearts', name: 'Heart of Midlothian', shortName: 'HEA', country: 'İskoçya', flag: '🏴󠁧󠁢󠁳󠁣󠁴󠁿', overall: 76, badgeColor: 'from-red-800 to-white' },
  { id: 'molde-fk', name: 'Molde FK', shortName: 'MOL', country: 'Norveç', flag: '🇳🇴', overall: 77, badgeColor: 'from-blue-600 to-white' },
  { id: 'djurgarden', name: 'Djurgårdens IF', shortName: 'DIF', country: 'İsveç', flag: '🇸🇪', overall: 76, badgeColor: 'from-blue-600 to-sky-400' },
  { id: 'helsinki', name: 'HJK Helsinki', shortName: 'HJK', country: 'Finlandiya', flag: '🇫🇮', overall: 75, badgeColor: 'from-blue-600 to-white' },
  { id: 'vikingur-reykjavik', name: 'Víkingur Reykjavík', shortName: 'VIK', country: 'İzlanda', flag: '🇮🇸', overall: 74, badgeColor: 'from-red-600 to-black' },
  { id: 'shamrock-rovers', name: 'Shamrock Rovers', shortName: 'SHA', country: 'İrlanda', flag: '🇮🇪', overall: 74, badgeColor: 'from-green-600 to-white' },
  { id: 'tns', name: 'The New Saints (TNS)', shortName: 'TNS', country: 'Galler', flag: '🏴󠁧󠁢󠁷󠁬󠁳󠁿', overall: 73, badgeColor: 'from-green-600 to-blue-600' },
  { id: 'larne-fc', name: 'Larne FC', shortName: 'LAR', country: 'Kuzey İrlanda', flag: '🇬🇧', overall: 72, badgeColor: 'from-red-600 to-white' },
  { id: 'astana', name: 'FC Astana', shortName: 'AST', country: 'Kazakistan', flag: '🇰🇿', overall: 75, badgeColor: 'from-yellow-400 to-sky-400' },
  { id: 'noah-yerevan', name: 'FC Noah', shortName: 'NOA', country: 'Ermenistan', flag: '🇦🇲', overall: 73, badgeColor: 'from-black to-white' },
  { id: 'borac-banja-luka', name: 'Borac Banja Luka', shortName: 'BOR', country: 'Bosna Hersek', flag: '🇧🇦', overall: 74, badgeColor: 'from-red-600 to-blue-600' },
  { id: 'celje', name: 'NK Celje', shortName: 'CEL', country: 'Slovenya', flag: '🇸🇮', overall: 75, badgeColor: 'from-blue-600 to-yellow-400' },
  { id: 'olimpija-ljubljana', name: 'Olimpija Ljubljana', shortName: 'OLI', country: 'Slovenya', flag: '🇸🇮', overall: 75, badgeColor: 'from-green-600 to-white' },
  { id: 'dinamo-minsk', name: 'Dinamo Minsk', shortName: 'DMI', country: 'Belarus', flag: '🇧🇾', overall: 74, badgeColor: 'from-blue-600 to-white' },
  { id: 'petrocub-hincesti', name: 'Petrocub Hîncești', shortName: 'PET', country: 'Moldova', flag: '🇲🇩', overall: 73, badgeColor: 'from-blue-600 to-white' }
];

export interface EuropeanMatchResult {
  id: string;
  competitionId: 'ucl' | 'uel' | 'uecl';
  week: number;
  homeTeam: EuropeanTournamentTeam;
  awayTeam: EuropeanTournamentTeam;
  homeScore: number;
  awayScore: number;
  played: boolean;
  scorers?: string[];
}

export interface EuropeanKnockoutMatch {
  id: string;
  round: 'PLAYOFF' | 'ROUND_OF_16' | 'QUARTER_FINAL' | 'SEMI_FINAL' | 'FINAL';
  roundName: string;
  homeTeam: EuropeanTournamentTeam;
  awayTeam: EuropeanTournamentTeam;
  leg1Score?: { home: number; away: number };
  leg2Score?: { home: number; away: number };
  aggregateHome?: number;
  aggregateAway?: number;
  winnerTeamId?: string;
  isCompleted?: boolean;
}
