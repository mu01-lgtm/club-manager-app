export const OFFICIAL_TEAM_LOGOS: Record<string, string> = {
  // --- SÜPER LİG & TURKEY (ALL 18 TEAMS IN EXACT ORDER) ---
  // 1. Galatasaray
  'galatasaray': '/logos/galatasaray.png',
  'gal': '/logos/galatasaray.png',
  'gs': '/logos/galatasaray.png',

  // 2. Fenerbahçe
  'fenerbahce': '/logos/fenerbahce.png',
  'fen': '/logos/fenerbahce.png',
  'fb': '/logos/fenerbahce.png',

  // 3. Beşiktaş
  'besiktas': '/logos/besiktas.png',
  'bjk': '/logos/besiktas.png',
  'bes': '/logos/besiktas.png',

  // 4. Trabzonspor
  'trabzonspor': '/logos/trabzonspor.png',
  'trabzon': '/logos/trabzonspor.png',
  'ts': '/logos/trabzonspor.png',

  // 5. RAMS Başakşehir / Başakşehir
  'basaksehir': '/logos/basaksehir.png',
  'ramsbasaksehir': '/logos/basaksehir.png',
  'istanbulbasaksehir': '/logos/basaksehir.png',
  'ibfk': '/logos/basaksehir.png',

  // 6. Samsunspor
  'samsunspor': '/logos/samsunspor.png',
  'samsun': '/logos/samsunspor.png',
  'sam': '/logos/samsunspor.png',

  // 7. Eyüpspor
  'eyupspor': '/logos/eyupspor.png',
  'eyup': '/logos/eyupspor.png',
  'eyu': '/logos/eyupspor.png',

  // 8. Göztepe
  'goztepe': '/logos/goztepe.png',
  'goz': '/logos/goztepe.png',

  // 9. Kasımpaşa
  'kasimpasa': '/logos/kasimpasa.png',
  'kas': '/logos/kasimpasa.png',

  // 10. Gaziantep FK
  'gaziantep': '/logos/gaziantep.png',
  'gaziantepfk': '/logos/gaziantep.png',
  'gfk': '/logos/gaziantep.png',

  // 11. TÜMOSAN Konyaspor / Konyaspor
  'konyaspor': '/logos/konyaspor.png',
  'tumosankonyaspor': '/logos/konyaspor.png',
  'konya': '/logos/konyaspor.png',
  'kny': '/logos/konyaspor.png',

  // 12. Corendon Alanyaspor / Alanyaspor
  'alanyaspor': '/logos/alanyaspor.png',
  'corendonalanyaspor': '/logos/alanyaspor.png',
  'alanya': '/logos/alanyaspor.png',
  'ala': '/logos/alanyaspor.png',

  // 13. Çaykur Rizespor / Rizespor
  'rizespor': '/logos/rizespor.png',
  'caykurrizespor': '/logos/rizespor.png',
  'rize': '/logos/rizespor.png',
  'riz': '/logos/rizespor.png',

  // 14. Kocaelispor
  'kocaelispor': '/logos/kocaelispor.png',
  'kocaeli': '/logos/kocaelispor.png',
  'koc': '/logos/kocaelispor.png',

  // 15. Erzurumspor FK
  'erzurumspor': '/logos/erzurumspor.png',
  'erzurumsporfk': '/logos/erzurumspor.png',
  'bberzurumspor': '/logos/erzurumspor.png',
  'erzurum': '/logos/erzurumspor.png',
  'erz': '/logos/erzurumspor.png',

  // 16. Amed SK / Amed SFK
  'amed': '/logos/amed.png',
  'amedsk': '/logos/amed.png',
  'amedsfk': '/logos/amed.png',
  'amedfk': '/logos/amed.png',
  'amd': '/logos/amed.png',

  // 17. Çorum FK / Ahlatcı Çorum FK
  'corum': '/logos/corum.png',
  'corumfk': '/logos/corum.png',
  'ahlatcicorumfk': '/logos/corum.png',
  'cor': '/logos/corum.png',

  // 18. Gençlerbirliği
  'genclerbirligi': '/logos/genclerbirligi.png',
  'gencler': '/logos/genclerbirligi.png',
  'gcb': '/logos/genclerbirligi.png',

  // Other Super Lig / Turkey
  'sivasspor': 'https://crests.football-data.org/602.png',
  'antalyaspor': 'https://crests.football-data.org/607.png',
  'kayserispor': 'https://crests.football-data.org/603.png',
  'hatayspor': 'https://crests.football-data.org/7317.png',
  'bodrum': 'https://upload.wikimedia.org/wikipedia/tr/f/f6/Bodrum_FK.png',
  'bodrumfk': 'https://upload.wikimedia.org/wikipedia/tr/f/f6/Bodrum_FK.png',
  'adanademirspor': 'https://crests.football-data.org/605.png',

  // --- İSPANYA (LA LIGA) ---
  'realmadrid': 'https://crests.football-data.org/86.png',
  'realmadridcf': 'https://crests.football-data.org/86.png',
  'barcelona': 'https://crests.football-data.org/81.png',
  'fcbarcelona': 'https://crests.football-data.org/81.png',
  'atleticomadrid': 'https://crests.football-data.org/78.png',
  'atleticodemadrid': 'https://crests.football-data.org/78.png',
  'atletico-madrid': 'https://crests.football-data.org/78.png',
  'atletico': 'https://crests.football-data.org/78.png',
  'atm': 'https://crests.football-data.org/78.png',
  'athleticbilbao': 'https://crests.football-data.org/77.png',
  'athletic-bilbao': 'https://crests.football-data.org/77.png',
  'athleticclub': 'https://crests.football-data.org/77.png',
  'athleticclubbilbao': 'https://crests.football-data.org/77.png',
  'realsociedad': 'https://crests.football-data.org/92.png',
  'villarreal': 'https://crests.football-data.org/94.png',
  'villarrealcf': 'https://crests.football-data.org/94.png',
  'sevilla': 'https://crests.football-data.org/559.png',
  'sevillafc': 'https://crests.football-data.org/559.png',
  'realbetis': 'https://crests.football-data.org/90.png',
  'girona': 'https://crests.football-data.org/298.png',
  'gironafc': 'https://crests.football-data.org/298.png',
  'valencia': 'https://crests.football-data.org/95.png',
  'valenciacf': 'https://crests.football-data.org/95.png',
  'getafe': 'https://crests.football-data.org/82.png',
  'getafecf': 'https://crests.football-data.org/82.png',
  'osasuna': 'https://crests.football-data.org/79.png',
  'caosasuna': 'https://crests.football-data.org/79.png',
  'celtavigo': 'https://crests.football-data.org/558.png',
  'rcdceltadevigo': 'https://crests.football-data.org/558.png',
  'rcceltadevigo': 'https://crests.football-data.org/558.png',
  'mallorca': 'https://crests.football-data.org/89.png',
  'rcdmallorca': 'https://crests.football-data.org/89.png',
  'espanyol': 'https://crests.football-data.org/80.png',
  'rcdespanyol': 'https://crests.football-data.org/80.png',
  'rayovallecano': 'https://crests.football-data.org/87.png',
  'laspalmas': 'https://crests.football-data.org/275.png',
  'udlaspalmas': 'https://crests.football-data.org/275.png',
  'realvalladolid': 'https://crests.football-data.org/250.png',
  'valladolid': 'https://crests.football-data.org/250.png',
  'cdleganes': 'https://crests.football-data.org/745.png',
  'leganes': 'https://crests.football-data.org/745.png',
  'alaves': 'https://crests.football-data.org/263.png',
  'deportivoalaves': 'https://crests.football-data.org/263.png',
  'deportivo-alaves': 'https://crests.football-data.org/263.png',
  'deportivoalavs': 'https://crests.football-data.org/263.png',
  'elche': 'https://crests.football-data.org/285.png',
  'elchecf': 'https://crests.football-data.org/285.png',
  'elche-cf': 'https://crests.football-data.org/285.png',
  'malaga': 'https://crests.football-data.org/321.png',
  'malagacf': 'https://crests.football-data.org/321.png',
  'malaga-cf': 'https://crests.football-data.org/321.png',
  'mlagacf': 'https://crests.football-data.org/321.png',
  'racingsantander': 'https://crests.football-data.org/272.png',
  'racingdesantander': 'https://crests.football-data.org/272.png',
  'racing-de-santander': 'https://crests.football-data.org/272.png',
  'deportivo': 'https://crests.football-data.org/264.png',
  'deportivolacoruna': 'https://crests.football-data.org/264.png',
  'deportivo-la-coruna': 'https://crests.football-data.org/264.png',
  'rcdeportivolacoruna': 'https://crests.football-data.org/264.png',
  'rcdeportivo': 'https://crests.football-data.org/264.png',
  'deportivolacoru': 'https://crests.football-data.org/264.png',
  'deportivolacorua': 'https://crests.football-data.org/264.png',
  'levante': 'https://crests.football-data.org/88.png',
  'levanteud': 'https://crests.football-data.org/88.png',
  'levante-ud': 'https://crests.football-data.org/88.png',

  // --- İNGİLTERE (PREMIER LEAGUE) ---
  'manchestercity': 'https://crests.football-data.org/65.png',
  'manchestercityfc': 'https://crests.football-data.org/65.png',
  'manchester-city': 'https://crests.football-data.org/65.png',
  'mancity': 'https://crests.football-data.org/65.png',
  'arsenal': 'https://crests.football-data.org/57.png',
  'arsenalfc': 'https://crests.football-data.org/57.png',
  'liverpool': 'https://crests.football-data.org/64.png',
  'liverpoolfc': 'https://crests.football-data.org/64.png',
  'chelsea': 'https://crests.football-data.org/61.png',
  'chelseafc': 'https://crests.football-data.org/61.png',
  'manchesterunited': 'https://crests.football-data.org/66.png',
  'manchesterunitedfc': 'https://crests.football-data.org/66.png',
  'manchester-united': 'https://crests.football-data.org/66.png',
  'manutd': 'https://crests.football-data.org/66.png',
  'tottenham': 'https://crests.football-data.org/73.png',
  'tottenhamhotspur': 'https://crests.football-data.org/73.png',
  'tottenhamhotspurfc': 'https://crests.football-data.org/73.png',
  'newcastle': 'https://crests.football-data.org/67.png',
  'newcastleunited': 'https://crests.football-data.org/67.png',
  'newcastleunitedfc': 'https://crests.football-data.org/67.png',
  'astonvilla': 'https://crests.football-data.org/58.png',
  'astonvillafc': 'https://crests.football-data.org/58.png',
  'aston-villa': 'https://crests.football-data.org/58.png',
  'brighton': 'https://crests.football-data.org/397.png',
  'brightonhovealbion': 'https://crests.football-data.org/397.png',
  'brightonhovealbionfc': 'https://crests.football-data.org/397.png',
  'brighton-hove-albion': 'https://crests.football-data.org/397.png',
  'hullcity': 'https://crests.football-data.org/322.png',
  'hull-city': 'https://crests.football-data.org/322.png',
  'hull': 'https://crests.football-data.org/322.png',
  'fulham': 'https://crests.football-data.org/63.png',
  'fulhamfc': 'https://crests.football-data.org/63.png',
  'bournemouth': 'https://crests.football-data.org/1044.png',
  'afcbournemouth': 'https://crests.football-data.org/1044.png',
  'brentford': 'https://crests.football-data.org/402.png',
  'brentfordfc': 'https://crests.football-data.org/402.png',
  'leedsunited': 'https://crests.football-data.org/341.png',
  'leeds-united': 'https://crests.football-data.org/341.png',
  'leeds': 'https://crests.football-data.org/341.png',
  'everton': 'https://crests.football-data.org/62.png',
  'evertonfc': 'https://crests.football-data.org/62.png',
  'crystalpalace': 'https://crests.football-data.org/354.png',
  'crystalpalacefc': 'https://crests.football-data.org/354.png',
  'crystal-palace': 'https://crests.football-data.org/354.png',
  'sunderland': 'https://crests.football-data.org/71.png',
  'sunderlandafc': 'https://crests.football-data.org/71.png',
  'nottinghamforest': 'https://crests.football-data.org/351.png',
  'nottinghamforestfc': 'https://crests.football-data.org/351.png',
  'nottingham-forest': 'https://crests.football-data.org/351.png',
  'ipswich': 'https://crests.football-data.org/349.png',
  'ipswichtown': 'https://crests.football-data.org/349.png',
  'ipswichtownfc': 'https://crests.football-data.org/349.png',
  'coventrycity': 'https://crests.football-data.org/1076.png',
  'coventry-city': 'https://crests.football-data.org/1076.png',
  'coventry': 'https://crests.football-data.org/1076.png',
  'westham': 'https://crests.football-data.org/563.png',
  'westhamunited': 'https://crests.football-data.org/563.png',
  'westhamunitedfc': 'https://crests.football-data.org/563.png',
  'wolverhampton': 'https://crests.football-data.org/76.png',
  'wolverhamptonwanderers': 'https://crests.football-data.org/76.png',
  'wolverhamptonwanderersfc': 'https://crests.football-data.org/76.png',
  'wolves': 'https://crests.football-data.org/76.png',
  'leicester': 'https://crests.football-data.org/338.png',
  'leicestercity': 'https://crests.football-data.org/338.png',
  'leicestercityfc': 'https://crests.football-data.org/338.png',
  'southampton': 'https://crests.football-data.org/340.png',
  'southamptonfc': 'https://crests.football-data.org/340.png',

  // --- ALMANYA (BUNDESLIGA) ---
  'bayernmunchen': '/logos/bayern-munich.png',
  'bayernmunich': '/logos/bayern-munich.png',
  'bayern': '/logos/bayern-munich.png',
  'fcbayernmunchen': '/logos/bayern-munich.png',
  'fcbayern': '/logos/bayern-munich.png',
  'bayerleverkusen': '/logos/bayer-leverkusen.png',
  'leverkusen': '/logos/bayer-leverkusen.png',
  'bayer04leverkusen': '/logos/bayer-leverkusen.png',
  'borussiadortmund': '/logos/borussia-dortmund.png',
  'dortmund': '/logos/borussia-dortmund.png',
  'bvb': '/logos/borussia-dortmund.png',
  'rbleipzig': '/logos/rb-leipzig.png',
  'leipzig': '/logos/rb-leipzig.png',
  'rasenballsportleipzig': '/logos/rb-leipzig.png',
  'eintrachtfrankfurt': '/logos/eintracht-frankfurt.png',
  'frankfurt': '/logos/eintracht-frankfurt.png',
  'sge': '/logos/eintracht-frankfurt.png',
  'vfbstuttgart': '/logos/vfb-stuttgart.png',
  'stuttgart': '/logos/vfb-stuttgart.png',
  'vfb': '/logos/vfb-stuttgart.png',
  'borussiamonchengladbach': '/logos/borussia-monchengladbach.png',
  'monchengladbach': '/logos/borussia-monchengladbach.png',
  'bmg': '/logos/borussia-monchengladbach.png',
  'scfreiburg': '/logos/sc-freiburg.png',
  'freiburg': '/logos/sc-freiburg.png',
  'tsghoffenheim': '/logos/tsg-hoffenheim.png',
  'tsg1899hoffenheim': '/logos/tsg-hoffenheim.png',
  'hoffenheim': '/logos/tsg-hoffenheim.png',
  'fsvmainz05': '/logos/fsv-mainz-05.png',
  '1fsvmainz05': '/logos/fsv-mainz-05.png',
  'mainz': '/logos/fsv-mainz-05.png',
  'mainz05': '/logos/fsv-mainz-05.png',
  'fcaugsburg': '/logos/fc-augsburg.png',
  'augsburg': '/logos/fc-augsburg.png',
  'svwerderbremen': '/logos/werder-bremen.png',
  'werderbremen': '/logos/werder-bremen.png',
  'bremen': '/logos/werder-bremen.png',
  'unionberlin': '/logos/union-berlin.png',
  '1fcunionberlin': '/logos/union-berlin.png',
  '1fckoln': '/logos/1-fc-koln.png',
  '1fc-koln': '/logos/1-fc-koln.png',
  'koln': '/logos/1-fc-koln.png',
  'fckoln': '/logos/1-fc-koln.png',
  'cologne': '/logos/1-fc-koln.png',
  'hamburgersv': '/logos/hamburger-sv.png',
  'hamburg': '/logos/hamburger-sv.png',
  'hsv': '/logos/hamburger-sv.png',
  'scpaderborn07': '/logos/sc-paderborn-07.png',
  'scpaderborn': '/logos/sc-paderborn-07.png',
  'paderborn': '/logos/sc-paderborn-07.png',
  'paderborn07': '/logos/sc-paderborn-07.png',
  'fcschalke04': '/logos/fc-schalke-04.png',
  'fcschalke': '/logos/fc-schalke-04.png',
  'schalke': '/logos/fc-schalke-04.png',
  'schalke04': '/logos/fc-schalke-04.png',
  's04': '/logos/fc-schalke-04.png',
  'sv07elversberg': '/logos/sv-07-elversberg.svg',
  'svelversberg': '/logos/sv-07-elversberg.svg',
  'elversberg': '/logos/sv-07-elversberg.svg',
  'vflwolfsburg': '/logos/vfl-wolfsburg.png',
  'wolfsburg': '/logos/vfl-wolfsburg.png',
  'fcstpauli': '/logos/fc-st-pauli.png',
  'stpauli': '/logos/fc-st-pauli.png',
  'holsteinkiel': '/logos/holstein-kiel.png',
  'kiel': '/logos/holstein-kiel.png',
  'fcheidenheim': '/logos/fc-heidenheim.png',
  '1fcheidenheim': '/logos/fc-heidenheim.png',
  '1fcheidenheim1846': '/logos/fc-heidenheim.png',
  'heidenheim': '/logos/fc-heidenheim.png',
  'vflbochum': '/logos/vfl-bochum.png',
  'vflbochum1848': '/logos/vfl-bochum.png',
  'bochum': '/logos/vfl-bochum.png',

  // --- İTALYA (SERIE A) ---
  'inter': '/logos/inter-milan.png',
  'intermilan': '/logos/inter-milan.png',
  'internazionale': '/logos/inter-milan.png',
  'acmilan': '/logos/ac-milan.png',
  'milan': '/logos/ac-milan.png',
  'juventus': '/logos/juventus.png',
  'juventusfc': '/logos/juventus.png',
  'atalanta': '/logos/atalanta.png',
  'atalantabc': '/logos/atalanta.png',
  'napoli': '/logos/ssc-napoli.png',
  'sscnapoli': '/logos/ssc-napoli.png',
  'asroma': '/logos/as-roma.png',
  'roma': '/logos/as-roma.png',
  'lazio': '/logos/ss-lazio.png',
  'sslazio': '/logos/ss-lazio.png',
  'fiorentina': '/logos/acf-fiorentina.png',
  'acffiorentina': '/logos/acf-fiorentina.png',
  'bologna': '/logos/bologna-fc.png',
  'bolognafc': '/logos/bologna-fc.png',
  'bolognafc1909': '/logos/bologna-fc.png',
  'torino': '/logos/torino-fc.png',
  'torinofc': '/logos/torino-fc.png',
  'monza': '/logos/ac-monza.png',
  'acmonza': '/logos/ac-monza.png',
  'genoa': '/logos/genoa-cfc.png',
  'genoacfc': '/logos/genoa-cfc.png',
  'udinese': '/logos/udinese-calcio.png',
  'udinesecalcio': '/logos/udinese-calcio.png',
  'verona': '/logos/hellas-verona.png',
  'hellasverona': '/logos/hellas-verona.png',
  'parma': '/logos/parma-calcio.png',
  'parmacalcio': '/logos/parma-calcio.png',
  'parmacalcio1913': '/logos/parma-calcio.png',
  'como': '/logos/como-1907.png',
  'como1907': '/logos/como-1907.png',
  'cagliari': '/logos/cagliari-calcio.png',
  'cagliaricalcio': '/logos/cagliari-calcio.png',
  'lecce': '/logos/us-lecce.png',
  'uslecce': '/logos/us-lecce.png',
  'frosinone': '/logos/frosinone-calcio.png',
  'frosinonecalcio': '/logos/frosinone-calcio.png',
  'sassuolo': '/logos/us-sassuolo.png',
  'ussassuolo': '/logos/us-sassuolo.png',
  'ussassuolocalcio': '/logos/us-sassuolo.png',
  'sassuolocalcio': '/logos/us-sassuolo.png',
  'empoli': '/logos/empoli-fc.png',
  'empolifc': '/logos/empoli-fc.png',
  'venezia': '/logos/venezia-fc.png',
  'veneziafc': '/logos/venezia-fc.png',

  // --- FRANSA (LIGUE 1) ---
  'parissaintgermain': '/logos/psg.png',
  'parissg': '/logos/psg.png',
  'psg': '/logos/psg.png',
  'asmonaco': '/logos/as-monaco.png',
  'asmonacofc': '/logos/as-monaco.png',
  'monaco': '/logos/as-monaco.png',
  'olympiquemarseille': '/logos/olympique-marseille.png',
  'marseille': '/logos/olympique-marseille.png',
  'om': '/logos/olympique-marseille.png',
  'lille': '/logos/losc-lille.png',
  'losclille': '/logos/losc-lille.png',
  'lilleosc': '/logos/losc-lille.png',
  'olympiquelyonnais': '/logos/olympique-lyonnais.png',
  'lyon': '/logos/olympique-lyonnais.png',
  'ol': '/logos/olympique-lyonnais.png',
  'ogcnice': '/logos/ogc-nice.png',
  'nice': '/logos/ogc-nice.png',
  'rclens': '/logos/rc-lens.png',
  'lens': '/logos/rc-lens.png',
  'staderennais': '/logos/stade-rennais.png',
  'staderennaisfc': '/logos/stade-rennais.png',
  'rennes': '/logos/stade-rennais.png',
  'stadebrestois': '/logos/stade-brestois.png',
  'stadebrestois29': '/logos/stade-brestois.png',
  'brest': '/logos/stade-brestois.png',
  'estactroyes': '/logos/estac-troyes.png',
  'troyes': '/logos/estac-troyes.png',
  'fclorient': '/logos/fc-lorient.png',
  'lorient': '/logos/fc-lorient.png',
  'lemansfc': '/logos/le-mans-fc.svg',
  'lemans': '/logos/le-mans-fc.svg',
  'le-mans-fc': '/logos/le-mans-fc.svg',
  'parisfc': '/logos/paris-fc.png',
  'stadedereims': '/logos/stade-de-reims.png',
  'reims': '/logos/stade-de-reims.png',
  'toulouse': '/logos/toulouse-fc.png',
  'toulousefc': '/logos/toulouse-fc.png',
  'rcstrasbourg': '/logos/rc-strasbourg.png',
  'rcstrasbourgalsace': '/logos/rc-strasbourg.png',
  'strasbourg': '/logos/rc-strasbourg.png',
  'montpellier': '/logos/montpellier-hsc.png',
  'montpellierhsc': '/logos/montpellier-hsc.png',
  'fcnantes': '/logos/fc-nantes.png',
  'nantes': '/logos/fc-nantes.png',
  'assaintetienne': '/logos/as-saint-etienne.png',
  'saintetienne': '/logos/as-saint-etienne.png',
  'asse': '/logos/as-saint-etienne.png',
  'as-saint-etienne': '/logos/as-saint-etienne.png',
  'ajauxerre': '/logos/aj-auxerre.png',
  'auxerre': '/logos/aj-auxerre.png',
  'angers': '/logos/angers-sco.png',
  'angerssco': '/logos/angers-sco.png',
  'lehavre': '/logos/le-havre.png',
  'lehavreac': '/logos/le-havre.png',
};

export const CUSTOM_LOGOS_STORAGE_KEY = 'fm_custom_team_logos_map';

// Helper to normalize team name/id for uniform lookup
export const normalizeTeamKey = (nameOrId?: string): string => {
  if (!nameOrId) return '';
  return nameOrId
    .toLowerCase()
    .trim()
    .replace(/ç/g, 'c')
    .replace(/ğ/g, 'g')
    .replace(/ı/g, 'i')
    .replace(/ö/g, 'o')
    .replace(/ş/g, 's')
    .replace(/ü/g, 'u')
    .replace(/[^a-z0-9]/g, '');
};

// In-memory cache for ultra-fast rendering without continuous JSON parses
let _customLogosCache: Record<string, string> | null = null;

export const getCustomTeamLogos = (): Record<string, string> => {
  if (_customLogosCache !== null) return _customLogosCache;
  try {
    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      const raw = localStorage.getItem(CUSTOM_LOGOS_STORAGE_KEY);
      if (raw) {
        _customLogosCache = JSON.parse(raw);
        return _customLogosCache || {};
      }
    }
  } catch (e) {
    console.error('Error loading custom team logos from storage:', e);
  }
  _customLogosCache = {};
  return _customLogosCache;
};

export const setCustomTeamLogo = (teamKeyOrName: string, logoUrl: string): void => {
  const normKey = normalizeTeamKey(teamKeyOrName);
  if (!normKey) return;

  const current = { ...getCustomTeamLogos() };
  if (!logoUrl || logoUrl.trim() === '') {
    delete current[normKey];
    delete current[teamKeyOrName.toLowerCase().trim()];
  } else {
    current[normKey] = logoUrl.trim();
    current[teamKeyOrName.toLowerCase().trim()] = logoUrl.trim();
  }

  _customLogosCache = current;
  try {
    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      localStorage.setItem(CUSTOM_LOGOS_STORAGE_KEY, JSON.stringify(current));
    }
  } catch (e) {
    console.error('Failed to save custom logo to localStorage:', e);
  }

  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('fm-team-logos-updated', { detail: { key: normKey, url: logoUrl } }));
  }
};

export const removeCustomTeamLogo = (teamKeyOrName: string): void => {
  const normKey = normalizeTeamKey(teamKeyOrName);
  const current = { ...getCustomTeamLogos() };
  delete current[normKey];
  delete current[teamKeyOrName.toLowerCase().trim()];
  _customLogosCache = current;

  try {
    localStorage.setItem(CUSTOM_LOGOS_STORAGE_KEY, JSON.stringify(current));
  } catch (e) {
    console.error('Failed to update custom logos in storage:', e);
  }

  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('fm-team-logos-updated', { detail: { key: normKey, removed: true } }));
  }
};

export const resetAllCustomTeamLogos = (): void => {
  _customLogosCache = {};
  try {
    localStorage.removeItem(CUSTOM_LOGOS_STORAGE_KEY);
  } catch (e) {
    console.error('Failed to clear custom logos:', e);
  }

  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('fm-team-logos-updated', { detail: { resetAll: true } }));
  }
};

export const exportCustomTeamLogosJson = (): string => {
  return JSON.stringify(getCustomTeamLogos(), null, 2);
};

export const importCustomTeamLogosJson = (jsonStr: string): boolean => {
  try {
    const parsed = JSON.parse(jsonStr);
    if (typeof parsed !== 'object' || parsed === null) return false;
    _customLogosCache = parsed;
    localStorage.setItem(CUSTOM_LOGOS_STORAGE_KEY, JSON.stringify(parsed));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('fm-team-logos-updated', { detail: { imported: true } }));
    }
    return true;
  } catch (e) {
    console.error('Failed to import custom team logos:', e);
    return false;
  }
};

export const getTeamLogoUrl = (nameOrId?: string): string | undefined => {
  if (!nameOrId) return undefined;

  const rawKey = nameOrId.toLowerCase().trim();
  const cleanKey = normalizeTeamKey(nameOrId);
  const withoutTeamPrefix = cleanKey.replace(/^team-?/g, '').replace(/^(fc|cf|ud|cd|sc|ac|bc|fk|sk)+/g, '');

  // 1. Check Custom Logos Override FIRST (takes highest precedence)
  const customLogos = getCustomTeamLogos();
  if (customLogos[cleanKey]) {
    return customLogos[cleanKey];
  }
  if (customLogos[rawKey]) {
    return customLogos[rawKey];
  }
  if (withoutTeamPrefix && customLogos[withoutTeamPrefix]) {
    return customLogos[withoutTeamPrefix];
  }

  // Strip common suffixes (fk, sk, cf, fc, etc.)
  const strippedKey = cleanKey
    .replace(/(fc|cf|ud|cd|sc|ac|bc|fk|sk|sfk|sad|1907|1909|1913|29|05)+$/g, '')
    .replace(/^(fc|cf|ud|cd|sc|ac|bc|fk|sk)+/g, '');

  if (strippedKey && customLogos[strippedKey]) {
    return customLogos[strippedKey];
  }

  // Substring search for custom logos
  for (const [k, url] of Object.entries(customLogos)) {
    const normK = normalizeTeamKey(k);
    if (normK.length >= 3) {
      if (
        cleanKey === normK ||
        cleanKey.includes(normK) ||
        normK.includes(cleanKey) ||
        (withoutTeamPrefix.length >= 3 && (withoutTeamPrefix.includes(normK) || normK.includes(withoutTeamPrefix))) ||
        (strippedKey.length >= 3 && (strippedKey.includes(normK) || normK.includes(strippedKey)))
      ) {
        return url;
      }
    }
  }

  // 2. Check Official Hardcoded Logos
  if (OFFICIAL_TEAM_LOGOS[cleanKey]) {
    return OFFICIAL_TEAM_LOGOS[cleanKey];
  }
  if (OFFICIAL_TEAM_LOGOS[rawKey]) {
    return OFFICIAL_TEAM_LOGOS[rawKey];
  }
  if (withoutTeamPrefix && OFFICIAL_TEAM_LOGOS[withoutTeamPrefix]) {
    return OFFICIAL_TEAM_LOGOS[withoutTeamPrefix];
  }
  if (strippedKey && OFFICIAL_TEAM_LOGOS[strippedKey]) {
    return OFFICIAL_TEAM_LOGOS[strippedKey];
  }

  // Substring search for official logos
  for (const [k, url] of Object.entries(OFFICIAL_TEAM_LOGOS)) {
    const normK = normalizeTeamKey(k);
    if (normK.length >= 3) {
      if (
        cleanKey === normK ||
        cleanKey.includes(normK) ||
        normK.includes(cleanKey) ||
        (withoutTeamPrefix.length >= 3 && (withoutTeamPrefix.includes(normK) || normK.includes(withoutTeamPrefix))) ||
        (strippedKey.length >= 3 && (strippedKey.includes(normK) || normK.includes(strippedKey)))
      ) {
        return url;
      }
    }
  }

  return undefined;
};
