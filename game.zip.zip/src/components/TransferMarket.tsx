import React, { useState, useMemo, useEffect } from 'react';
import { Team, Player } from '../types';
import { ShoppingCart, DollarSign, Check, UserPlus, AlertCircle, Search, SlidersHorizontal, X, RotateCcw, Star } from 'lucide-react';
import { INITIAL_MARKET_PLAYERS } from '../data/initialData';
import { TransferOfferModal } from './TransferOfferModal';
import { INTERNATIONAL_TEAMS } from './WorldScoutModal';
import { useTranslation } from '../utils/i18n';

interface TransferMarketProps {
  currentTeam: Team;
  allTeams?: Team[];
  favoritePlayerIds?: string[];
  onToggleFavorite?: (playerId: string) => void;
  onBuyPlayer: (player: Player) => void;
  onSelectPlayerProfile?: (player: Player, team?: Team) => void;
  onShowToast?: (type: 'success' | 'error' | 'info', title: string, message: string) => void;
}

export const TransferMarket: React.FC<TransferMarketProps> = ({
  currentTeam,
  allTeams = [],
  favoritePlayerIds: propFavs,
  onToggleFavorite,
  onBuyPlayer,
  onSelectPlayerProfile,
  onShowToast
}) => {
  const { t } = useTranslation();
  const [marketFreeAgents] = useState<Player[]>(INITIAL_MARKET_PLAYERS);
  const [boughtIds, setBoughtIds] = useState<string[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [selectedOfferItem, setSelectedOfferItem] = useState<{ player: Player; team?: Team } | null>(null);

  const [localFavs, setLocalFavs] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('fmm_favorites') || '[]');
    } catch {
      return [];
    }
  });

  const activeFavIds = propFavs || localFavs;

  const handleToggleStar = (e: React.MouseEvent, playerId: string) => {
    e.stopPropagation();
    if (onToggleFavorite) {
      onToggleFavorite(playerId);
    } else {
      const next = localFavs.includes(playerId) ? localFavs.filter(id => id !== playerId) : [...localFavs, playerId];
      setLocalFavs(next);
      try {
        localStorage.setItem('fmm_favorites', JSON.stringify(next));
      } catch (e) {
        console.error(e);
      }
    }
  };

  // Combine league active players + international teams + free agents into a single rich list with team metadata (EXCLUDING OWN TEAM)
  const combinedPlayerList = React.useMemo(() => {
    const list: { player: Player; team?: Team; teamName: string; isFreeAgent: boolean; leagueTag: string }[] = [];
    const userPlayerIds = new Set(currentTeam.players.map(p => p.id));
    const addedPlayerIds = new Set<string>();

    // 1. Add active players from Super Lig teams (excluding user's own team)
    allTeams.forEach(t => {
      if (t.id === currentTeam.id) return;
      t.players.forEach(p => {
        if (userPlayerIds.has(p.id) || addedPlayerIds.has(p.id)) return;
        addedPlayerIds.add(p.id);
        list.push({
          player: p,
          team: t,
          teamName: t.name,
          isFreeAgent: false,
          leagueTag: 'SUPERLIG'
        });
      });
    });

    // 2. Add international players from global leagues (Real Madrid, Barca, Man City, PSG, Al-Nassr, etc.)
    INTERNATIONAL_TEAMS.forEach(extTeam => {
      let leagueTag = 'OTHER';
      if (extTeam.country === 'İspanya') leagueTag = 'LALIGA';
      else if (extTeam.country === 'İngiltere') leagueTag = 'PREMIER';
      else if (extTeam.country === 'İtalya') leagueTag = 'SERIEA';
      else if (extTeam.country === 'Almanya') leagueTag = 'BUNDESLIGA';
      else if (extTeam.country === 'Fransa') leagueTag = 'LIGUE1';
      else if (extTeam.country === 'Suudi Arabistan') leagueTag = 'SAUDI';

      extTeam.players.forEach(p => {
        if (userPlayerIds.has(p.id) || addedPlayerIds.has(p.id)) return;
        addedPlayerIds.add(p.id);

        const mockTeam: Team = {
          id: extTeam.id,
          name: extTeam.name,
          shortName: extTeam.shortName,
          badgeColor: extTeam.badgeColor,
          badgeTextColor: 'text-white',
          secondaryColor: '#4f46e5',
          stadiumName: extTeam.stadium,
          budget: extTeam.budget,
          reputation: 5,
          formation: '4-3-3',
          tactic: 'BALANCED',
          players: extTeam.players
        };

        list.push({
          player: p,
          team: mockTeam,
          teamName: `${extTeam.name} (${extTeam.flag})`,
          isFreeAgent: false,
          leagueTag
        });
      });
    });

    // 3. Add free agent market players
    marketFreeAgents.forEach(p => {
      if (userPlayerIds.has(p.id) || addedPlayerIds.has(p.id)) return;
      addedPlayerIds.add(p.id);
      list.push({
        player: p,
        teamName: t('FREE_AGENT'),
        isFreeAgent: true,
        leagueTag: 'OTHER'
      });
    });

    return list;
  }, [allTeams, currentTeam, marketFreeAgents]);

  // Search Query
  const [searchQuery, setSearchQuery] = useState('');

  // Active Applied Filters State
  const [appliedPos, setAppliedPos] = useState<string>('ALL');
  const [appliedMinAge, setAppliedMinAge] = useState<number>(16);
  const [appliedMaxAge, setAppliedMaxAge] = useState<number>(40);
  const [appliedMinPrice, setAppliedMinPrice] = useState<number>(0);
  const [appliedMaxPrice, setAppliedMaxPrice] = useState<number>(100); // Millions €
  const [appliedNat, setAppliedNat] = useState<string>('ALL');
  const [appliedStatus, setAppliedStatus] = useState<string>('ALL'); // LIST STATUS FILTER

  // Filter Modal Popup Open/Close & Temp Form State
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  const [tempPos, setTempPos] = useState<string>('ALL');
  const [tempMinAge, setTempMinAge] = useState<number>(16);
  const [tempMaxAge, setTempMaxAge] = useState<number>(40);
  const [tempMinPrice, setTempMinPrice] = useState<number>(0);
  const [tempMaxPrice, setTempMaxPrice] = useState<number>(100);
  const [tempNat, setTempNat] = useState<string>('ALL');
  const [tempStatus, setTempStatus] = useState<string>('ALL');

  const openFilterModal = () => {
    setTempPos(appliedPos);
    setTempMinAge(appliedMinAge);
    setTempMaxAge(appliedMaxAge);
    setTempMinPrice(appliedMinPrice);
    setTempMaxPrice(appliedMaxPrice);
    setTempNat(appliedNat);
    setTempStatus(appliedStatus);
    setIsFilterModalOpen(true);
  };

  const handleApplyFilters = () => {
    setAppliedPos(tempPos);
    setAppliedMinAge(tempMinAge);
    setAppliedMaxAge(tempMaxAge);
    setAppliedMinPrice(tempMinPrice);
    setAppliedMaxPrice(tempMaxPrice);
    setAppliedNat(tempNat);
    setAppliedStatus(tempStatus);
    setIsFilterModalOpen(false);
  };

  const handleResetFilters = () => {
    setTempPos('ALL');
    setTempMinAge(16);
    setTempMaxAge(40);
    setTempMinPrice(0);
    setTempMaxPrice(100);
    setTempNat('ALL');
    setTempStatus('ALL');

    setAppliedPos('ALL');
    setAppliedMinAge(16);
    setAppliedMaxAge(40);
    setAppliedMinPrice(0);
    setAppliedMaxPrice(100);
    setAppliedNat('ALL');
    setAppliedStatus('ALL');
    setSearchQuery('');
  };

  const handleBuy = (player: Player) => {
    if (boughtIds.includes(player.id)) return;

    if (currentTeam.budget < player.marketValue) {
      const neededMsg = `Bütçe yetersiz! ${player.name} transferi için €${((player.marketValue - currentTeam.budget) / 1_000_000).toFixed(1)}M daha gerekiyor.`;
      setErrorMessage(neededMsg);
      if (onShowToast) {
        onShowToast('error', 'Transfer Başarısız! ❌', neededMsg);
      }
      setTimeout(() => setErrorMessage(null), 4000);
      return;
    }

    onBuyPlayer(player);
    setBoughtIds(prev => [...prev, player.id]);
    setErrorMessage(null);

    if (onShowToast) {
      onShowToast(
        'success',
        'Transfer Tamamlandı! ⚽',
        `${player.name} (${player.position} - ${player.overall} OVR) kadronuza katıldı!`
      );
    }
  };

  // Pagination state for ultra-fast rendering
  const [visibleCount, setVisibleCount] = useState<number>(30);

  // Reset pagination when filter or search changes
  useEffect(() => {
    setVisibleCount(30);
  }, [searchQuery, appliedPos, appliedMinAge, appliedMaxAge, appliedMinPrice, appliedMaxPrice, appliedNat, appliedStatus]);

  // Dynamic Filtering Logic across Combined Active League Players & Market Free Agents (Memoized)
  const filteredItems = useMemo(() => {
    return combinedPlayerList.filter(item => {
      const { player, teamName, isFreeAgent } = item;
      const query = searchQuery.trim().toLowerCase();
      
      const textMatch = !query || 
        player.name.toLowerCase().includes(query) ||
        teamName.toLowerCase().includes(query) ||
        (player.nationality && player.nationality.toLowerCase().includes(query)) ||
        player.position.toLowerCase().includes(query) ||
        (player.specificRole && player.specificRole.toLowerCase().includes(query));

      // Position match
      let posMatch = appliedPos === 'ALL';
      if (!posMatch) {
        if (appliedPos === 'GK') posMatch = player.position === 'GK';
        else if (appliedPos === 'DEF') posMatch = player.position === 'DEF';
        else if (appliedPos === 'MID') posMatch = player.position === 'MID' && player.specificRole !== 'CAM';
        else if (appliedPos === 'CAM') posMatch = player.specificRole === 'CAM';
        else if (appliedPos === 'FW') posMatch = player.position === 'FW';
      }

      // List Status Filter
      let statusMatch = true;
      if (appliedStatus === 'FAVORITES') {
        statusMatch = activeFavIds.includes(player.id);
      } else if (appliedStatus === 'SATILIK') {
        statusMatch = !isFreeAgent && (player.isTransferListed || player.marketValue > 0);
      } else if (appliedStatus === 'KIRALIK') {
        statusMatch = !isFreeAgent && (player.age <= 22 || player.overall <= 76);
      } else if (appliedStatus === 'SERBEST') {
        statusMatch = isFreeAgent || teamName === 'Serbest Oyuncu';
      } else if (appliedStatus === 'GOZDEN_CIKARILMIS') {
        statusMatch = !isFreeAgent && (player.form <= 7.2 || player.age >= 32);
      } else if (appliedStatus === 'SOZLESME_BITEN') {
        statusMatch = (player.contractUntil || 2026) <= 2026;
      }

      // Age filter
      const ageMatch = player.age >= appliedMinAge && player.age <= appliedMaxAge;

      // Price filter
      const priceInM = (player.marketValue || 5000000) / 1_000_000;
      const priceMatch = priceInM >= appliedMinPrice && priceInM <= appliedMaxPrice;

      // Nationality filter
      const natMatch = appliedNat === 'ALL' || (player.nationality && player.nationality.toLowerCase() === appliedNat.toLowerCase());

      return textMatch && posMatch && ageMatch && priceMatch && natMatch && statusMatch;
    });
  }, [combinedPlayerList, searchQuery, appliedPos, appliedMinAge, appliedMaxAge, appliedMinPrice, appliedMaxPrice, appliedNat, appliedStatus, activeFavIds]);

  // Sliced items for instant DOM render
  const visibleItems = useMemo(() => {
    return filteredItems.slice(0, visibleCount);
  }, [filteredItems, visibleCount]);

  const activeFilterCount = (appliedPos !== 'ALL' ? 1 : 0) +
    (appliedStatus !== 'ALL' ? 1 : 0) +
    (appliedMinAge !== 16 || appliedMaxAge !== 40 ? 1 : 0) +
    (appliedMinPrice !== 0 || appliedMaxPrice !== 100 ? 1 : 0) +
    (appliedNat !== 'ALL' ? 1 : 0);

  const nationalitiesList = [
    { code: 'ALL', label: 'Tüm Ülkeler', flag: '🌐' },
    { code: 'Türkiye', label: 'Türkiye', flag: '🇹🇷' },
    { code: 'Brezilya', label: 'Brezilya', flag: '🇧🇷' },
    { code: 'Arjantin', label: 'Arjantin', flag: '🇦🇷' },
    { code: 'Fransa', label: 'Fransa', flag: '🇫🇷' },
    { code: 'Almanya', label: 'Almanya', flag: '🇩🇪' },
    { code: 'İspanya', label: 'İspanya', flag: '🇪🇸' },
    { code: 'Portekiz', label: 'Portekiz', flag: '🇵🇹' },
    { code: 'İngiltere', label: 'İngiltere', flag: '🇬🇧' },
    { code: 'Hollanda', label: 'Hollanda', flag: '🇳🇱' },
    { code: 'İtalya', label: 'İtalya', flag: '🇮🇹' }
  ];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-2xl space-y-3 relative">
      
      {/* Compact Header Banner */}
      <div className="bg-slate-950 p-1.5 sm:p-2 rounded-xl border border-slate-800 flex flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          <div className="p-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 shrink-0">
            <ShoppingCart className="w-3.5 h-3.5" />
          </div>
          <div className="min-w-0">
            <h3 className="font-extrabold text-white text-xs truncate">{t('TRANSFER_MARKET_TITLE')}</h3>
            <p className="text-[9px] text-slate-400 font-semibold hidden sm:block truncate">{t('TRANSFER_MARKET_SUBTITLE')}</p>
          </div>
        </div>

        {/* Current Budget Display */}
        <div className="bg-slate-900 border border-slate-800 px-2.5 py-0.5 sm:py-1 rounded-lg flex items-center gap-1 shrink-0">
          <span className="text-[9px] font-bold text-slate-400">{t('BUDGET_LABEL')}:</span>
          <span className="text-[11px] font-black text-amber-300">
            €{(currentTeam.budget / 1_000_000).toFixed(1)}M
          </span>
        </div>
      </div>

      {/* Clean Top Bar: Search Input + Quick Tabs + ⚙️ Filter Modal Toggle Button */}
      <div className="bg-slate-950 p-2 rounded-xl border border-slate-800 space-y-2">
        <div className="flex items-center gap-1.5">
          <div className="relative flex-1 flex items-center">
            <Search className="w-3 h-3 text-slate-400 absolute left-2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('SEARCH_PLAYER_PLACEHOLDER')}
              className="w-full bg-slate-900 border border-slate-700 text-white pl-7 pr-2.5 py-1 rounded-lg text-[10px] sm:text-xs focus:outline-none focus:border-emerald-500 placeholder-slate-500"
            />
          </div>

          {/* ⚙️ [ Filtrele / Ayarlar ] Button */}
          <button
            onClick={openFilterModal}
            className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-[#7b2cbf] to-[#5b21b6] hover:from-[#8b31d4] hover:to-[#6d28d9] text-white font-black text-[10px] sm:text-xs border border-purple-400/40 flex items-center gap-1 shrink-0 cursor-pointer shadow active:scale-95 transition-all"
          >
            <SlidersHorizontal className="w-3 h-3 text-emerald-300" />
            <span>{t('FILTER_BUTTON')}</span>
            {activeFilterCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-emerald-400 text-slate-950 font-black text-[9px] min-w-[16px] text-center">
                {activeFilterCount}
              </span>
            )}
          </button>
        </div>

        {/* Quick Filter Tabs Row */}
        <div className="flex items-center gap-1 overflow-x-auto pb-0.5 custom-scrollbar text-[10px] sm:text-xs font-black">
          {[
            { id: 'ALL', label: t('ALL') },
            { id: 'FAVORITES', label: `⭐ Favoriler (${activeFavIds.length})` },
            { id: 'SATILIK', label: t('FOR_SALE') },
            { id: 'KIRALIK', label: t('FOR_LOAN') },
            { id: 'SERBEST', label: t('FREE_AGENT') }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setAppliedStatus(tab.id)}
              className={`px-2.5 py-1 rounded-lg border whitespace-nowrap shrink-0 transition-all ${
                appliedStatus === tab.id
                  ? 'bg-purple-600 border-purple-400 text-white shadow'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* FILTER MODAL POP-UP (Max Width 500px, Non-Fullscreen Half Window) */}
      {isFilterModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 animate-fadeIn">
          <div className="bg-[#18142a] border-2 border-[#3d2f63] rounded-2xl w-full max-w-[500px] shadow-2xl flex flex-col overflow-hidden max-h-[90vh]">
            
            {/* Modal Header */}
            <div className="bg-[#120e21] p-3.5 border-b border-[#2d244c] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-emerald-400" />
                <h3 className="font-extrabold text-sm text-white">{t('TRANSFER_FILTERS_TITLE')}</h3>
              </div>
              <button
                onClick={() => setIsFilterModalOpen(false)}
                className="p-1 rounded-lg bg-[#271f45] hover:bg-[#392e63] text-slate-300 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 overflow-y-auto space-y-4 custom-scrollbar text-xs">
              
              {/* 📋 0. Liste Durumu Seçimi */}
              <div className="space-y-1.5">
                <span className="font-extrabold text-slate-200 block text-[11px]">{t('LIST_STATUS_LABEL')}:</span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {[
                    { id: 'ALL', label: t('ALL') },
                    { id: 'SATILIK', label: t('FOR_SALE') },
                    { id: 'KIRALIK', label: t('FOR_LOAN') },
                    { id: 'SERBEST', label: t('FREE_AGENT') },
                    { id: 'GOZDEN_CIKARILMIS', label: t('SURPLUS') },
                    { id: 'SOZLESME_BITEN', label: t('EXPIRING_CONTRACT') }
                  ].map(st => (
                    <button
                      key={st.id}
                      onClick={() => setTempStatus(st.id)}
                      className={`py-1.5 px-2 rounded-lg font-extrabold text-[10px] border transition-all text-left truncate ${
                        tempStatus === st.id
                          ? 'bg-purple-600 border-purple-400 text-white shadow'
                          : 'bg-[#120e21] border-[#2f254f] text-slate-400 hover:text-white'
                      }`}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* ⚽ 1. Mevki Seçimi */}
              <div className="space-y-1.5">
                <span className="font-extrabold text-slate-200 block text-[11px]">{t('POSITION_LABEL')}:</span>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-1">
                  {[
                    { id: 'ALL', label: t('ALL') },
                    { id: 'GK', label: t('GK_SHORT') },
                    { id: 'DEF', label: t('DEF_SHORT') },
                    { id: 'MID', label: t('MID_SHORT') },
                    { id: 'CAM', label: t('CAM_SHORT') },
                    { id: 'FW', label: t('FW_SHORT') }
                  ].map(pos => (
                    <button
                      key={pos.id}
                      onClick={() => setTempPos(pos.id)}
                      className={`py-1.5 px-2 rounded-lg font-black text-[10px] border transition-all ${
                        tempPos === pos.id
                          ? 'bg-purple-600 border-purple-400 text-white shadow'
                          : 'bg-[#120e21] border-[#2f254f] text-slate-400 hover:text-white'
                      }`}
                    >
                      {pos.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 🎂 2. Yaş Aralığı */}
              <div className="space-y-1.5">
                <span className="font-extrabold text-slate-200 block text-[11px]">{t('AGE_RANGE_LABEL')}:</span>
                <div className="grid grid-cols-2 gap-3 bg-[#120e21] p-2.5 rounded-xl border border-[#2f254f]">
                  <div>
                    <label className="text-[10px] text-slate-400 font-bold block mb-1">{t('MIN_AGE')}:</label>
                    <input
                      type="number"
                      min="16"
                      max="40"
                      value={tempMinAge}
                      onChange={(e) => setTempMinAge(Number(e.target.value) || 16)}
                      className="w-full bg-[#1c1633] border border-[#3f3068] rounded-lg p-1.5 text-white font-extrabold focus:outline-none focus:border-purple-400"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 font-bold block mb-1">{t('MAX_AGE')}:</label>
                    <input
                      type="number"
                      min="16"
                      max="40"
                      value={tempMaxAge}
                      onChange={(e) => setTempMaxAge(Number(e.target.value) || 40)}
                      className="w-full bg-[#1c1633] border border-[#3f3068] rounded-lg p-1.5 text-white font-extrabold focus:outline-none focus:border-purple-400"
                    />
                  </div>
                </div>
              </div>

              {/* 💰 3. Piyasa Değeri Aralığı (€M) */}
              <div className="space-y-1.5">
                <span className="font-extrabold text-slate-200 block text-[11px]">{t('VALUE_RANGE_LABEL')}:</span>
                <div className="grid grid-cols-2 gap-3 bg-[#120e21] p-2.5 rounded-xl border border-[#2f254f]">
                  <div>
                    <label className="text-[10px] text-slate-400 font-bold block mb-1">{t('MIN_PRICE')}:</label>
                    <input
                      type="number"
                      min="0"
                      max="200"
                      value={tempMinPrice}
                      onChange={(e) => setTempMinPrice(Number(e.target.value) || 0)}
                      className="w-full bg-[#1c1633] border border-[#3f3068] rounded-lg p-1.5 text-amber-300 font-extrabold focus:outline-none focus:border-purple-400"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 font-bold block mb-1">{t('MAX_PRICE')}:</label>
                    <input
                      type="number"
                      min="1"
                      max="200"
                      value={tempMaxPrice}
                      onChange={(e) => setTempMaxPrice(Number(e.target.value) || 100)}
                      className="w-full bg-[#1c1633] border border-[#3f3068] rounded-lg p-1.5 text-amber-300 font-extrabold focus:outline-none focus:border-purple-400"
                    />
                  </div>
                </div>
              </div>

              {/* 🌍 4. Uyruk / Ülke Seçimi */}
              <div className="space-y-1.5">
                <span className="font-extrabold text-slate-200 block text-[11px]">{t('NATIONALITY_LABEL')}:</span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 max-h-[140px] overflow-y-auto p-1.5 bg-[#120e21] rounded-xl border border-[#2f254f] custom-scrollbar">
                  {nationalitiesList.map((nat) => (
                    <button
                      key={nat.code}
                      onClick={() => setTempNat(nat.code)}
                      className={`flex items-center gap-1.5 p-1.5 rounded-lg border text-[10px] font-extrabold transition-all text-left ${
                        tempNat === nat.code
                          ? 'bg-purple-600 border-purple-400 text-white'
                          : 'bg-[#18132b] border-[#2d234d] text-slate-300 hover:text-white'
                      }`}
                    >
                      <span className="text-sm">{nat.flag}</span>
                      <span className="truncate">{nat.label}</span>
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* Modal Footer Buttons */}
            <div className="p-3 bg-[#120e21] border-t border-[#2d244c] flex items-center justify-between gap-2">
              <button
                onClick={handleResetFilters}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-black text-xs flex items-center gap-1 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" /> {t('RESET_BUTTON')}
              </button>

              <button
                onClick={handleApplyFilters}
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1 shadow active:scale-95 transition-all"
              >
                <Check className="w-4 h-4" /> {t('APPLY_FILTERS_BUTTON')}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Error Alert Message */}
      {errorMessage && (
        <div className="p-2.5 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-center gap-2 text-rose-300 text-xs font-bold animate-shake">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Uniform Grid-Cols-2 Player Cards */}
      {filteredItems.length === 0 ? (
        <div className="p-8 text-center bg-slate-950 rounded-xl border border-slate-800 text-slate-400 text-xs font-semibold">
          {t('NO_PLAYERS_FOUND')}
        </div>
      ) : (
        <div className="space-y-2.5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[60vh] sm:max-h-[500px] overflow-y-auto pr-1 custom-scrollbar">
            {visibleItems.map((item) => {
              const { player, team, teamName, isFreeAgent } = item;
              const isBought = boughtIds.includes(player.id);
              const canAfford = currentTeam.budget >= player.marketValue;
              const isMyTeam = team?.id === currentTeam.id;

              return (
                <div
                  key={player.id}
                  className={`bg-slate-950 border rounded-xl p-3 flex flex-col justify-between gap-2 transition-all ${
                    isBought
                      ? 'border-emerald-500/30 bg-emerald-950/10 opacity-70'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {/* Player Header */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4
                          onClick={() => {
                            if (onSelectPlayerProfile) {
                              onSelectPlayerProfile(player, team);
                            }
                          }}
                          className="font-extrabold text-white text-sm hover:text-purple-300 transition-colors cursor-pointer truncate"
                          title={t('CLICK_PROFILE')}
                        >
                          {player.name}
                        </h4>
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-slate-800 border border-slate-700 text-emerald-400 shrink-0">
                          {player.position}
                        </span>
                      </div>

                      {/* Team Name & Nationality & Age & Loan Tag */}
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-medium mt-0.5 flex-wrap">
                        <span className="text-amber-300 font-bold bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/20">
                          🛡️ {isFreeAgent ? t('FREE_AGENT') : teamName}
                        </span>
                        {player.isLoaned && (
                          <span className="text-amber-400 font-extrabold bg-amber-500/20 px-1.5 py-0.2 rounded border border-amber-500/40">
                            🔄 {t('LOANED_TAG', { club: player.parentClubName || t('PERMANENT_CLUB') })}
                          </span>
                        )}
                        <span>•</span>
                        <span>{t('AGE_SUFFIX', { age: player.age })}</span>
                        <span>•</span>
                        <span>🌐 {player.nationality || 'Türkiye'}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={(e) => handleToggleStar(e, player.id)}
                        className="p-1 text-slate-400 hover:text-amber-400 transition-colors shrink-0 cursor-pointer active:scale-90"
                        title={activeFavIds.includes(player.id) ? "Favorilerden Cikar" : "Favorilere Ekle"}
                      >
                        <Star className={`w-4 h-4 ${activeFavIds.includes(player.id) ? 'fill-amber-400 text-amber-400' : ''}`} />
                      </button>

                      <div className="px-2 py-0.5 bg-emerald-500/20 border border-emerald-500/30 rounded-md text-emerald-300 font-black text-xs shrink-0">
                        {player.overall} OVR
                      </div>
                    </div>
                  </div>

                  {/* Compact Attributes Strip */}
                  <div className="grid grid-cols-5 gap-1 text-center py-1 bg-slate-900/60 rounded-lg border border-slate-800/80">
                    <div>
                      <span className="text-[8px] text-slate-500 uppercase font-extrabold block">PAC</span>
                      <span className="text-[11px] font-black text-slate-200">{player.attributes.pace}</span>
                    </div>
                    <div>
                      <span className="text-[8px] text-slate-500 uppercase font-extrabold block">SHO</span>
                      <span className="text-[11px] font-black text-slate-200">{player.attributes.shooting}</span>
                    </div>
                    <div>
                      <span className="text-[8px] text-slate-500 uppercase font-extrabold block">PAS</span>
                      <span className="text-[11px] font-black text-slate-200">{player.attributes.passing}</span>
                    </div>
                    <div>
                      <span className="text-[8px] text-slate-500 uppercase font-extrabold block">DEF</span>
                      <span className="text-[11px] font-black text-slate-200">{player.attributes.defending}</span>
                    </div>
                    <div>
                      <span className="text-[8px] text-slate-500 uppercase font-extrabold block">PHY</span>
                      <span className="text-[11px] font-black text-slate-200">{player.attributes.physical}</span>
                    </div>
                  </div>

                  {/* Price & Action Button */}
                  <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                    <div>
                      <span className="text-[9px] uppercase font-bold text-slate-500 block">{t('MARKET_VALUE_LABEL')}</span>
                      <span className="text-xs font-extrabold text-amber-300">
                        €{(player.marketValue / 1_000_000).toFixed(1)}M
                      </span>
                    </div>

                    {isMyTeam ? (
                      <span className="px-2 py-1 text-[10px] font-extrabold text-emerald-400 bg-emerald-950/50 rounded border border-emerald-500/30">
                        {t('OWN_TEAM_TAG')}
                      </span>
                    ) : player.isLoaned ? (
                      <button
                        onClick={() => {
                          if (onShowToast) {
                            onShowToast(
                              'error',
                              'Transfer Yapılamaz 🔒',
                              `${player.name} (${player.parentClubName || 'Bonservisli Kulüp'}) kulübünde kiralıktır. Kiralık süresi dolmadan transfer teklifi gönderilemez!`
                            );
                          } else {
                            setErrorMessage(`${player.name} (${player.parentClubName || 'Bonservisli Kulüp'}) kiralık oyuncusudur. Kiralık sözleşmesi bitmeden transfer edilemez.`);
                            setTimeout(() => setErrorMessage(null), 4000);
                          }
                        }}
                        className="px-3 py-1 rounded-lg font-extrabold text-xs flex items-center gap-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-all cursor-pointer"
                      >
                        <AlertCircle className="w-3.5 h-3.5 text-amber-400" /> {t('LOANED_OFFER_DISABLED')}
                      </button>
                    ) : (
                      <button
                        onClick={() => setSelectedOfferItem({ player, team })}
                        disabled={isBought}
                        className={`px-3 py-1 rounded-lg font-extrabold text-xs flex items-center gap-1 transition-all ${
                          isBought
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 cursor-default'
                            : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow active:scale-95'
                        }`}
                      >
                        {isBought ? (
                          <>
                            <Check className="w-3.5 h-3.5" /> {t('TRANSFERRED')}
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-3.5 h-3.5" /> {t('OFFER_TRANSFER')}
                          </>
                        )}
                      </button>
                    )}
                  </div>

                </div>
              );
            })}
          </div>

          {/* Load More Button */}
          {visibleCount < filteredItems.length && (
            <div className="flex justify-center pt-1">
              <button
                onClick={() => setVisibleCount(prev => prev + 30)}
                className="px-4 py-2 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-500/40 font-extrabold text-xs transition-all active:scale-95 shadow"
              >
                {t('LOAD_MORE_PLAYERS', { count: visibleItems.length, total: filteredItems.length })}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Transfer & Loan Negotiation Offer Modal */}
      {selectedOfferItem && (
        <TransferOfferModal
          isOpen={!!selectedOfferItem}
          onClose={() => setSelectedOfferItem(null)}
          player={selectedOfferItem.player}
          sellerTeam={selectedOfferItem.team}
          userTeam={currentTeam}
          onTransferSuccess={(pl, dealType, fee, updatedProps) => {
            const finalPlayer = updatedProps ? { ...pl, ...updatedProps } : pl;
            onBuyPlayer(finalPlayer);
            setBoughtIds(prev => [...prev, pl.id]);
          }}
          showToast={onShowToast}
        />
      )}

    </div>
  );
};
