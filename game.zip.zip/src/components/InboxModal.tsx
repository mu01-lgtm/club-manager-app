import React, { useState } from 'react';
import { X, Mail, ChevronDown, ChevronUp, Shield, CheckCheck, User } from 'lucide-react';
import { Team, InboxMessage, Player } from '../types';
import { INTERNATIONAL_TEAMS } from './WorldScoutModal';
import { useTranslation } from '../utils/i18n';
import { formatLocalizedDateString } from '../utils/dateHelper';

interface InboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  team: Team;
  allTeams?: Team[];
  messages: InboxMessage[];
  onToggleRead: (id: string) => void;
  onMarkAllRead: () => void;
  onGoToTacticsWithRecommended?: () => void;
  onOpenContractNegotiation?: (player: Player, sellerTeam?: Team, effectiveFee?: number) => void;
  onOpenPlayerProfile?: (player: Player, sellerTeam?: Team) => void;
  onOpenTeamModal?: (team: Team) => void;
}

const MessageTextWithLinks: React.FC<{
  content: string;
  actionData?: { player?: Player; sellerTeam?: Team };
  allPlayers: { player: Player; team?: Team }[];
  allTeamsList: Team[];
  onOpenPlayerProfile?: (player: Player, team?: Team) => void;
  onOpenTeamModal?: (team: Team) => void;
  onClose: () => void;
}> = ({ content, actionData, allPlayers, allTeamsList, onOpenPlayerProfile, onOpenTeamModal, onClose }) => {
  const matchedEntities: {
    name: string;
    type: 'PLAYER' | 'TEAM';
    playerObj?: Player;
    teamObj?: Team;
  }[] = [];

  const contentLower = content.toLowerCase();

  // If actionData contains explicit player/team, prioritize them
  if (actionData?.player) {
    matchedEntities.push({
      name: actionData.player.name,
      type: 'PLAYER',
      playerObj: actionData.player,
      teamObj: actionData.sellerTeam
    });
  }
  if (actionData?.sellerTeam) {
    matchedEntities.push({
      name: actionData.sellerTeam.name,
      type: 'TEAM',
      teamObj: actionData.sellerTeam
    });
  }

  // Find other matched players from text
  allPlayers.forEach(({ player, team }) => {
    if (player.name && player.name.length >= 3 && contentLower.includes(player.name.toLowerCase())) {
      if (!matchedEntities.some(m => m.name.toLowerCase() === player.name.toLowerCase())) {
        matchedEntities.push({
          name: player.name,
          type: 'PLAYER',
          playerObj: player,
          teamObj: team
        });
      }
    }
  });

  // Find other matched teams from text (including international teams)
  allTeamsList.forEach(t => {
    if (t.name && t.name.length >= 3 && contentLower.includes(t.name.toLowerCase())) {
      if (!matchedEntities.some(m => m.name.toLowerCase() === t.name.toLowerCase())) {
        matchedEntities.push({
          name: t.name,
          type: 'TEAM',
          teamObj: t
        });
      }
    }
  });

  if (matchedEntities.length === 0) {
    return (
      <div className="p-3 bg-[#110d21] rounded-lg border border-[#2a2145] text-xs leading-relaxed text-slate-200 font-medium whitespace-pre-line">
        {content}
      </div>
    );
  }

  // Sort entities by name length descending to match full names first
  matchedEntities.sort((a, b) => b.name.length - a.name.length);

  const escapedNames = matchedEntities.map(m => m.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  const pattern = new RegExp(`(${escapedNames.join('|')})`, 'gi');
  const parts = content.split(pattern);

  return (
    <div className="p-3 bg-[#110d21] rounded-lg border border-[#2a2145] text-xs leading-relaxed text-slate-200 font-medium whitespace-pre-line">
      {parts.map((part, idx) => {
        const entity = matchedEntities.find(m => m.name.toLowerCase() === part.toLowerCase());
        if (!entity) return part;

        if (entity.type === 'PLAYER' && entity.playerObj && onOpenPlayerProfile) {
          return (
            <button
              key={idx}
              onClick={(e) => {
                e.stopPropagation();
                onOpenPlayerProfile(entity.playerObj!, entity.teamObj);
              }}
              className="inline text-amber-300 font-black underline hover:text-amber-200 cursor-pointer transition-colors active:opacity-75"
              title={`${entity.playerObj.name}`}
            >
              {part}
            </button>
          );
        }

        if (entity.type === 'TEAM' && entity.teamObj && onOpenTeamModal) {
          return (
            <button
              key={idx}
              onClick={(e) => {
                e.stopPropagation();
                onOpenTeamModal(entity.teamObj!);
              }}
              className="inline text-purple-300 font-black underline hover:text-purple-200 cursor-pointer transition-colors active:opacity-75"
              title={`${entity.teamObj.name}`}
            >
              {part}
            </button>
          );
        }

        return part;
      })}
    </div>
  );
};

function getLocalizedInboxMessage(msg: InboxMessage, t: (key: string, params?: Record<string, string | number>) => string, userTeam?: Team) {
  let sender = msg.senderKey ? t(msg.senderKey, msg.senderParams) : (msg.sender || '');
  let subject = msg.subjectKey ? t(msg.subjectKey, msg.subjectParams) : (msg.subject || msg.title || '');
  let content = msg.contentKey ? t(msg.contentKey, msg.contentParams) : (msg.content || '');

  // Fallbacks for initial messages or known legacy patterns
  if (msg.id === 'm1') {
    sender = t('INBOX_INIT_1_SENDER');
    subject = t('INBOX_INIT_1_SUBJECT');
    content = t('INBOX_INIT_1_CONTENT');
  } else if (msg.id === 'm2') {
    sender = t('INBOX_INIT_2_SENDER');
    subject = t('INBOX_INIT_2_SUBJECT');
    content = t('INBOX_INIT_2_CONTENT');
  } else if (msg.id === 'm3') {
    sender = t('INBOX_INIT_3_SENDER');
    subject = t('INBOX_INIT_3_SUBJECT');
    content = t('INBOX_INIT_3_CONTENT');
  } else {
    // Translate sender if unlocalized
    if (sender.includes('Yönetim') || sender.includes('TFF') || sender.includes('Başkanlık')) sender = t('INBOX_INIT_1_SENDER');
    else if (sender.includes('Sağlık') || sender.includes('Medical')) sender = t('INBOX_INIT_2_SENDER');
    else if (sender.includes('Gözlemci') || sender.includes('Scout')) sender = t('INBOX_INIT_3_SENDER');
    else if (sender.includes('Taraftar') || sender.includes('Media') || sender.includes('Medya')) sender = t('INBOX_SENDER_FAN_MEDIA');
    else if (sender.includes('İdari İşler') || sender.includes('Admin')) sender = t('INBOX_SENDER_ADMIN_DESK');
    else if (sender.includes('Analiz') || sender.includes('Teknik') || sender.includes('Kadro') || sender.includes('Servisi')) sender = t('INBOX_SENDER_TECHNICAL_STAFF');
    else if (sender.includes('İnsan Kaynakları') || sender.includes('Sözleşme')) sender = t('INBOX_SENDER_HR_DESK');
    else if (sender.includes('Performans')) sender = t('INBOX_SENDER_PERFORMANCE');
    else if (sender.includes('Altyapı')) sender = t('INBOX_SENDER_YOUTH_DIRECTOR');
    else if (sender.includes('Taktik')) sender = t('INBOX_SENDER_TACTICAL_GROUP');

    // Parse unlocalized match result messages or keys formatted with spaces/lowercase
    const isMatchReportMsg = msg.category === 'MATCH_REPORT' || msg.tag === 'MAÇ_SONUCU' || !!msg.matchReport || 
      /INBOX_MSG_(?:VICTORY|DRAW|DEFEAT)_SUBJECT/i.test(subject) ||
      /inbox\s*msg\s*(?:victory|draw|defeat)\s*subject/i.test(subject) ||
      subject.includes('MAÇ SONUCU') || subject.includes('MATCH RESULT') || subject.includes('SPIELERGEBNIS') || subject.includes('RÉSULTAT') || subject.includes('RISULTATO') || subject.includes('RESULTADO');

    if (isMatchReportMsg) {
      const homeScore = msg.matchReport?.homeScore ?? 0;
      const awayScore = msg.matchReport?.awayScore ?? 0;
      const isUserHome = msg.matchReport && userTeam ? (msg.matchReport.homeTeam.name === userTeam.name || msg.matchReport.homeTeam.id === userTeam.id) : true;
      const userGoals = msg.subjectParams?.userGoals !== undefined ? Number(msg.subjectParams.userGoals) : (isUserHome ? homeScore : awayScore);
      const oppGoals = msg.subjectParams?.oppGoals !== undefined ? Number(msg.subjectParams.oppGoals) : (isUserHome ? awayScore : homeScore);
      const opponentName = msg.subjectParams?.opponent || (msg.matchReport ? (isUserHome ? msg.matchReport.awayTeam.name : msg.matchReport.homeTeam.name) : 'Rakip');
      const weekNum = msg.subjectParams?.week || (msg.matchReport as any)?.week || 1;

      if (userGoals > oppGoals) {
        subject = t('INBOX_MSG_VICTORY_SUBJECT', { userGoals, oppGoals, opponent: opponentName });
        content = t('INBOX_MSG_VICTORY_CONTENT', { userGoals, oppGoals, opponent: opponentName, week: weekNum });
      } else if (userGoals === oppGoals) {
        subject = t('INBOX_MSG_DRAW_SUBJECT', { userGoals, oppGoals, opponent: opponentName });
        content = t('INBOX_MSG_DRAW_CONTENT', { userGoals, oppGoals, opponent: opponentName, week: weekNum });
      } else {
        subject = t('INBOX_MSG_DEFEAT_SUBJECT', { userGoals, oppGoals, opponent: opponentName });
        content = t('INBOX_MSG_DEFEAT_CONTENT', { userGoals, oppGoals, opponent: opponentName, week: weekNum });
      }
    } else if (!msg.subjectKey) {
      if (subject.includes('HAVALİMANINDA BÜYÜK COŞKU') || subject.includes('AIRPORT') || subject.includes('GELİYOR!')) {
        const playerName = msg.actionData?.player?.name || subject.split(': ')[1]?.replace(' GELİYOR!', '').trim() || '';
        subject = t('INBOX_MSG_AIRPORT_SUBJECT', { player: playerName });
        content = t('INBOX_MSG_AIRPORT_CONTENT', { player: playerName });
      } else if (subject.includes('Transfer Teklifi Kabul Edildi') || subject.includes('Transfer Offer Accepted')) {
        const playerName = msg.actionData?.player?.name || subject.split(': ')[1] || '';
        subject = t('INBOX_MSG_TRANSFER_ACCEPTED_SUBJECT', { player: playerName });
        content = t('INBOX_MSG_TRANSFER_ACCEPTED_CONTENT', { player: playerName });
      } else if (subject.includes('Transfer Teklifi Reddedildi') || subject.includes('Transfer Offer Rejected')) {
        const playerName = msg.actionData?.player?.name || subject.split(': ')[1] || '';
        subject = t('INBOX_MSG_TRANSFER_REJECTED_SUBJECT', { player: playerName });
        content = t('INBOX_MSG_TRANSFER_REJECTED_CONTENT', { player: playerName });
      } else if (subject.includes('Kiralama Kabul Edildi') || subject.includes('Kiralık Kabul Edildi') || subject.includes('KİRALAMA KABUL') || subject.includes('Loan Offer Accepted')) {
        const playerName = msg.actionData?.player?.name || subject.split(': ')[1] || '';
        subject = t('INBOX_MSG_LOAN_ACCEPTED_SUBJECT', { player: playerName });
        content = t('INBOX_MSG_LOAN_ACCEPTED_CONTENT', { player: playerName });
      } else if (subject.includes('Kiralama Reddedildi') || subject.includes('Kiralık Reddedildi') || subject.includes('KİRALIK REDDEDİLDİ') || subject.includes('KİRALAMA REDDEDİLDİ') || subject.includes('Loan Offer Rejected')) {
        const playerName = msg.actionData?.player?.name || subject.split(': ')[1] || '';
        subject = t('INBOX_MSG_LOAN_REJECTED_SUBJECT', { player: playerName });
        content = t('INBOX_MSG_LOAN_REJECTED_CONTENT', { player: playerName });
      } else if (subject.includes('Resmi Anlaşma İmzalandı') || subject.includes('Official Agreement Signed')) {
        const playerName = msg.actionData?.player?.name || subject.split(': ')[1] || '';
        subject = t('INBOX_MSG_PENDING_TR_SUBJECT', { player: playerName });
        content = t('INBOX_MSG_PENDING_TR_CONTENT', { player: playerName });
      } else if (subject.includes('YENİ TRANSFER TAKIMA KATILDI') || subject.includes('NEW SIGNING JOINED')) {
        const playerName = msg.actionData?.player?.name || subject.split(': ')[1] || '';
        subject = t('INBOX_MSG_ARRIVAL_SUBJECT', { player: playerName });
        content = t('INBOX_MSG_ARRIVAL_CONTENT', { player: playerName });
      } else if (subject.includes('SEZON TAMAMLANDI') || subject.includes('SEASON') && subject.includes('COMPLETED')) {
        const seasonNum = msg.subjectParams?.season || 1;
        const champ = msg.subjectParams?.champion || '';
        subject = t('INBOX_MSG_SEASON_END_1_SUBJECT', { season: seasonNum, champion: champ });
        content = t('INBOX_MSG_SEASON_END_1_CONTENT', { season: seasonNum, champion: champ, team: userTeam?.name || '', rank: msg.contentParams?.rank || 1, prize: msg.contentParams?.prize || 15 });
      } else if (subject.includes('YAZ TATİLİ') || subject.includes('SUMMER BREAK')) {
        subject = t('INBOX_MSG_SEASON_END_2_SUBJECT');
        content = t('INBOX_MSG_SEASON_END_2_CONTENT');
      } else if (subject.includes('YENİ SEZON FİKSTÜRÜ') || subject.includes('NEW SEASON FIXTURES')) {
        const seasonNum = msg.subjectParams?.season || 2;
        subject = t('INBOX_MSG_SEASON_END_3_SUBJECT', { season: seasonNum });
        content = t('INBOX_MSG_SEASON_END_3_CONTENT', { season: seasonNum });
      } else if (
        subject.includes('MAÇ GÜNÜ BİLDİRİMİ') ||
        subject.includes('MATCHDAY NOTIFICATION') ||
        subject.includes('DÍA DE PARTIDO') ||
        subject.includes('DIA DE JOGO') ||
        subject.includes('GIORNO DELLA PARTITA') ||
        subject.includes('JOUR DE MATCH') ||
        subject.includes('SPIELTAG')
      ) {
        let homeName = msg.subjectParams?.home || '';
        let awayName = msg.subjectParams?.away || '';
        if (!homeName || !awayName) {
          const rawTeams = subject.replace(/^[^\:]*:\s*/, '').split(/\s+(?:vs\.?|-)\s+/i);
          if (rawTeams.length >= 2) {
            homeName = rawTeams[0].trim();
            awayName = rawTeams[1].trim();
          }
        }
        if (!homeName) homeName = 'Home';
        if (!awayName) awayName = 'Away';

        let weekNum = msg.contentParams?.week || '';
        if (!weekNum) {
          const wMatch = content.match(/(\d+)/);
          if (wMatch) weekNum = wMatch[1];
        }
        if (!weekNum) weekNum = '1';

        subject = t('INBOX_MSG_MATCH_DAY_SUBJECT', { home: homeName, away: awayName });
        content = t('INBOX_MSG_MATCH_DAY_CONTENT', { week: weekNum, home: homeName, away: awayName });
      } else if (subject.includes('Rakip TD Açıklaması') || subject.includes('Basın Toplantısı') || subject.includes('PRESS')) {
        subject = t('INBOX_REPORT_PRESS_SUBJECT', { team: msg.subjectParams?.team || '' });
        content = t('INBOX_REPORT_PRESS_BODY', { team: msg.contentParams?.team || '' });
      } else if (subject.includes('Antrenmanda Öne Çıkan İsimler') || subject.includes('STANDOUT')) {
        const names = msg.subjectParams?.names || subject.split(': ')[1] || '';
        subject = t('INBOX_REPORT_STANDOUT_SUBJECT', { names });
        content = t('INBOX_REPORT_STANDOUT_BODY', { names });
      } else if (subject.includes('Gelecek Maç İçin Umut Vadeden Yetenekler') || subject.includes('YOUTH')) {
        const names = msg.subjectParams?.names || subject.split(': ')[1] || '';
        subject = t('INBOX_REPORT_YOUTH_SUBJECT', { names });
        content = t('INBOX_REPORT_YOUTH_BODY', { names });
      } else if (subject.includes('Takım Sağlık & Kondisyon Raporu') || subject.includes('HEALTH')) {
        subject = t('INBOX_REPORT_HEALTH_SUBJECT', { date: msg.date || 'Today' });
        content = t('INBOX_REPORT_HEALTH_BODY');
      } else if (subject.includes('Set Oyunları ve Form Yükseliş Raporu') || subject.includes('TACTICS')) {
        subject = t('INBOX_REPORT_TACTICS_SUBJECT');
        content = t('INBOX_REPORT_TACTICS_BODY');
      } else if (subject.includes('AYLIK BİLDİRİM') || subject.includes('Sözleşmesi 1 Yıldan Az')) {
        const countVal = msg.subjectParams?.count || 1;
        const locSub = t('INBOX_MSG_EXPIRING_CONTRACT_SUBJECT', { count: countVal });
        if (locSub && !locSub.includes('INBOX_MSG_')) subject = locSub;
        if (msg.contentParams?.playerList) {
          const locBody = t('INBOX_MSG_EXPIRING_CONTRACT_CONTENT', { count: countVal, list: msg.contentParams.playerList });
          if (locBody && !locBody.includes('INBOX_MSG_')) {
            content = locBody;
          } else {
            content = msg.content || '';
          }
        } else {
          content = msg.content || '';
        }
      } else if (subject.includes('FIRSAT BİLDİRİMİ') || subject.includes('Sözleşmesi Sona Eriyor')) {
        const starName = msg.actionData?.player?.name || subject.split(': ')[1]?.split(' (')[0] || '';
        subject = t('INBOX_MSG_RIVAL_STAR_SUBJECT', { player: starName, team: msg.actionData?.sellerTeam?.name || '' });
        content = t('INBOX_MSG_RIVAL_STAR_BODY', { player: starName, team: msg.actionData?.sellerTeam?.name || '', age: msg.actionData?.player?.age || 25, pos: msg.actionData?.player?.position || 'FW', ovr: msg.actionData?.player?.overall || 80 });
      }
    }
  }

  return { sender, subject, content };
}

export const InboxModal: React.FC<InboxModalProps> = ({
  isOpen,
  onClose,
  team,
  allTeams = [],
  messages,
  onToggleRead,
  onMarkAllRead,
  onGoToTacticsWithRecommended,
  onOpenContractNegotiation,
  onOpenPlayerProfile,
  onOpenTeamModal
}) => {
  const { t, language } = useTranslation();

  if (!isOpen) return null;

  const [expandedMsgIds, setExpandedMsgIds] = useState<string[]>(
    messages.length > 0 ? [messages[0].id] : []
  );

  const toggleExpand = (id: string) => {
    setExpandedMsgIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
    onToggleRead(id);
  };

  const tagColors: Record<string, string> = {
    YÖNETİM: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
    SAĞLIK: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
    SCOUT: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    MEDYA: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    TAKTIK: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
    TRANSFER: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    MAÇ_SONUCU: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    MAÇ: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
  };

  const tagLabel = (tagType: string) => {
    switch (tagType) {
      case 'YÖNETİM': return t('TAG_BOARD');
      case 'SAĞLIK': return t('TAG_HEALTH');
      case 'SCOUT': return t('TAG_SCOUT');
      case 'MEDYA': return t('TAG_MEDIA');
      case 'TAKTIK': return t('TAG_TACTICS');
      case 'TRANSFER': return t('TAG_TRANSFER');
      case 'MAÇ_SONUCU':
      case 'MAÇ': return t('TAG_MATCH') || 'MAÇ';
      case 'KONTRAK': return t('TAG_CONTRACT');
      case 'KULÜP': return t('TAG_CLUB');
      default: return t('TAG_NOTIFICATION');
    }
  };

  const unreadCount = messages.filter(m => !m.isRead).length;

  // Combine league teams and international teams for team lookups
  const combinedTeamsList: Team[] = [...allTeams];
  INTERNATIONAL_TEAMS.forEach(it => {
    if (!combinedTeamsList.some(ct => ct.id === it.id || ct.name.toLowerCase() === it.name.toLowerCase())) {
      combinedTeamsList.push({
        id: it.id,
        name: it.name,
        shortName: it.shortName,
        badgeColor: it.badgeColor,
        overall: it.overall,
        budget: it.budget,
        stadium: it.stadium,
        manager: it.manager,
        players: it.players,
        formation: '4-4-2',
        tactic: 'BALANCED'
      });
    }
  });

  // Flatten all available players for search lookup
  const allPlayersList: { player: Player; team?: Team }[] = [];
  team.players.forEach(p => allPlayersList.push({ player: p, team }));
  combinedTeamsList.forEach(t => {
    t.players.forEach(p => {
      if (!allPlayersList.some(ap => ap.player.id === p.id)) {
        allPlayersList.push({ player: p, team: t });
      }
    });
  });

  const handlePlayerClick = (playerName?: string, playerId?: string, teamName?: string) => {
    if (!onOpenPlayerProfile || (!playerName && !playerId)) return;
    if (playerId) {
      const foundById = allPlayersList.find(p => p.player.id === playerId);
      if (foundById) {
        onOpenPlayerProfile(foundById.player, foundById.team);
        return;
      }
    }
    if (playerName) {
      const cleanName = playerName.trim().toLowerCase();
      const foundByName = allPlayersList.find(p => p.player.name.trim().toLowerCase() === cleanName);
      if (foundByName) {
        onOpenPlayerProfile(foundByName.player, foundByName.team);
        return;
      }
      for (const t of combinedTeamsList) {
        const p = t.players.find(pl => pl.name.trim().toLowerCase() === cleanName || (playerId && pl.id === playerId));
        if (p) {
          onOpenPlayerProfile(p, t);
          return;
        }
      }
    }
  };

  const handleTeamClick = (teamName?: string, teamId?: string) => {
    if (!onOpenTeamModal || (!teamName && !teamId)) return;
    const found = combinedTeamsList.find(t => (teamId && t.id === teamId) || (teamName && t.name.toLowerCase() === teamName.toLowerCase()));
    if (found) {
      onOpenTeamModal(found);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-[#181528] border-2 border-[#332b50] rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[88vh] text-slate-100 font-sans my-auto">
        
        {/* Header */}
        <div className="bg-[#120f21] p-3.5 sm:p-4 border-b border-[#2d2547] flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <Mail className="w-5 h-5 text-amber-400 shrink-0" />
            <h3 className="font-extrabold text-sm sm:text-base text-white truncate">
              {t('INBOX_TITLE')}
            </h3>
            {unreadCount > 0 ? (
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-extrabold border border-amber-500/30 shrink-0">
                {unreadCount} {t('UNREAD_MESSAGES_COUNT')}
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-extrabold border border-emerald-500/30 shrink-0">
                {t('ALL_MESSAGES_READ')}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {unreadCount > 0 && (
              <button
                onClick={onMarkAllRead}
                className="px-2.5 py-1 rounded-xl bg-[#251d3d] hover:bg-[#382b5e] text-purple-200 text-xs font-bold transition-all flex items-center gap-1 border border-purple-500/30 cursor-pointer"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{t('MARK_ALL_READ')}</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 rounded-xl bg-[#251d3d] hover:bg-[#382b5e] text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Message List */}
        <div className="p-3 sm:p-4 overflow-y-auto flex-1 space-y-2.5 custom-scrollbar bg-[#18142a]">
          {messages.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs space-y-2">
              <Mail className="w-8 h-8 text-slate-600 mx-auto" />
              <p>{t('NO_MESSAGES')}</p>
            </div>
          ) : (
            messages.map((msg) => {
              const isExpanded = expandedMsgIds.includes(msg.id);
              const tagStyle = tagColors[msg.type] || 'bg-purple-500/20 text-purple-300 border-purple-500/40';
              const locMsg = getLocalizedInboxMessage(msg, t, team);

              return (
                <div
                  key={msg.id}
                  onClick={() => toggleExpand(msg.id)}
                  className={`border rounded-xl transition-all cursor-pointer overflow-hidden ${
                    !msg.isRead
                      ? 'bg-[#1e1736] border-amber-500/50 shadow-md'
                      : 'bg-[#120f21] border-[#292044] hover:border-purple-500/40'
                  }`}
                >
                  {/* Summary Bar */}
                  <div className="p-3 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      {!msg.isRead && (
                        <div className="w-2 h-2 rounded-full bg-amber-400 shrink-0 animate-pulse" />
                      )}
                      <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase border shrink-0 ${tagStyle}`}>
                        {tagLabel(msg.type || msg.tag || '')}
                      </span>
                      <h4 className={`text-xs sm:text-sm line-clamp-2 leading-snug break-words ${!msg.isRead ? 'font-black text-white' : 'font-extrabold text-slate-200'}`}>
                        {locMsg.subject || 'Inbox Message'}
                      </h4>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-[10px] text-slate-400 font-semibold">{formatLocalizedDateString(msg.date, language)}</span>
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4 text-purple-300" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                  </div>

                  {/* Body Content */}
                  {isExpanded && (
                    <div className="px-3 pb-3 pt-2 border-t border-[#292044] space-y-3 bg-[#161228]/80 animate-fadeIn">
                      
                      {/* Expanded Sender Info Header */}
                      {locMsg.sender && (
                        <div className="flex items-center justify-end pb-1.5 border-b border-[#292044] gap-2">
                          <span className="text-[10px] text-slate-400 font-extrabold shrink-0 bg-[#1f1938] px-2 py-0.5 rounded-md border border-[#33295c]">
                            {t('SENDER_LABEL')}: {locMsg.sender}
                          </span>
                        </div>
                      )}

                      {/* Parsed Message Content with Interactive Inline Links */}
                      <MessageTextWithLinks
                        content={locMsg.content}
                        actionData={msg.actionData}
                        allPlayers={allPlayersList}
                        allTeamsList={combinedTeamsList}
                        onOpenPlayerProfile={onOpenPlayerProfile}
                        onOpenTeamModal={onOpenTeamModal}
                        onClose={onClose}
                      />

                      {/* Visual Match Report Card if present */}
                      {msg.matchReport && (
                        <div className="bg-[#120e24] border border-[#3b2a68] rounded-xl p-3 space-y-3 shadow-lg">
                          
                          {/* Scoreboard & Badges */}
                          <div className="flex items-center justify-between bg-[#191333] p-2.5 rounded-lg border border-[#2e2154]">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleTeamClick(msg.matchReport?.homeTeam.name, msg.matchReport?.homeTeam.id);
                              }}
                              className="flex items-center gap-2 flex-1 min-w-0 text-left hover:opacity-85 transition-opacity cursor-pointer group"
                              title={`${msg.matchReport.homeTeam.name} - Takım Profilini Aç`}
                            >
                              <div
                                style={{ backgroundColor: msg.matchReport.homeTeam.badgeColor || '#7b2cbf' }}
                                className="w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs text-white shadow shrink-0 group-hover:ring-2 ring-purple-400"
                              >
                                {msg.matchReport.homeTeam.shortName || msg.matchReport.homeTeam.name.substring(0, 3).toUpperCase()}
                              </div>
                              <span className="font-extrabold text-xs text-white group-hover:text-purple-300 transition-colors truncate">
                                {msg.matchReport.homeTeam.name}
                              </span>
                            </button>

                            <div className="px-3 py-1 bg-[#281b4f] rounded-lg border border-purple-500/40 text-sm font-black text-amber-300 tracking-widest shrink-0 mx-2 shadow">
                              {msg.matchReport.homeScore} - {msg.matchReport.awayScore}
                            </div>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleTeamClick(msg.matchReport?.awayTeam.name, msg.matchReport?.awayTeam.id);
                              }}
                              className="flex items-center justify-end gap-2 flex-1 min-w-0 text-right hover:opacity-85 transition-opacity cursor-pointer group"
                              title={`${msg.matchReport.awayTeam.name} - Takım Profilini Aç`}
                            >
                              <span className="font-extrabold text-xs text-white group-hover:text-purple-300 transition-colors truncate">
                                {msg.matchReport.awayTeam.name}
                              </span>
                              <div
                                style={{ backgroundColor: msg.matchReport.awayTeam.badgeColor || '#ef4444' }}
                                className="w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs text-white shadow shrink-0 group-hover:ring-2 ring-purple-400"
                              >
                                {msg.matchReport.awayTeam.shortName || msg.matchReport.awayTeam.name.substring(0, 3).toUpperCase()}
                              </div>
                            </button>
                          </div>

                          {/* Scorers List with Assists */}
                          {msg.matchReport.scorers && msg.matchReport.scorers.length > 0 && (
                            <div className="bg-[#17122e] p-2 rounded-lg border border-[#2b1f4c] text-[10.5px]">
                              <div className="text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                                <span>⚽ {t('GOAL_SCORERS_TITLE') || 'Goller & Önemli Anlar'}</span>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                                {msg.matchReport.scorers.map((s, sIdx) => {
                                  const scorerName = s.player || s.name || 'Oyuncu';
                                  const teamName = s.team || (s.isHome ? msg.matchReport?.homeTeam.name : msg.matchReport?.awayTeam.name);
                                  
                                  let assistName = s.assistantName;
                                  if (!assistName && (s as any).text && (s as any).text.includes('Asist:')) {
                                    assistName = (s as any).text.split('Asist:')[1]?.replace(')', '')?.trim();
                                  }

                                  return (
                                    <div key={sIdx} className="flex items-center gap-1.5 text-slate-200 bg-[#1f173d]/70 px-2 py-1 rounded border border-[#35265e]/60 flex-wrap">
                                      <span className="text-amber-400 font-black text-[9.5px] shrink-0">{s.minute}'</span>
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handlePlayerClick(scorerName, s.scorerId, teamName);
                                        }}
                                        className="font-extrabold text-white hover:text-amber-300 underline cursor-pointer transition-colors text-left flex items-center gap-1"
                                        title={`${scorerName} - Oyuncu Profilini Aç`}
                                      >
                                        <span>{scorerName}</span>
                                        {s.isPenaltyMissed ? (
                                          <span className="text-rose-400 font-black text-[9px] px-1 py-0.2 rounded bg-rose-950/80 border border-rose-500/50">
                                            (P ❌)
                                          </span>
                                        ) : s.isPenalty ? (
                                          <span className="text-amber-300 font-black text-[9px] px-1 py-0.2 rounded bg-amber-950/80 border border-amber-500/50">
                                            (P)
                                          </span>
                                        ) : null}
                                      </button>

                                      {assistName && (
                                        <span className="text-[9px] text-sky-300 flex items-center gap-0.5">
                                          <span>(🅰️</span>
                                          <button
                                            type="button"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              handlePlayerClick(assistName, s.assistantId, teamName);
                                            }}
                                            className="font-bold text-sky-300 hover:text-sky-100 underline cursor-pointer transition-colors"
                                            title={`${assistName} - Asist Yapan Oyuncu Profili`}
                                          >
                                            {assistName}
                                          </button>
                                          <span>)</span>
                                        </span>
                                      )}

                                      {teamName && (
                                        <button
                                          type="button"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            handleTeamClick(teamName);
                                          }}
                                          className="text-[8.5px] text-slate-400 hover:text-purple-300 cursor-pointer transition-colors ml-auto truncate max-w-[100px]"
                                          title={`${teamName} - Takım Profilini Aç`}
                                        >
                                          ({teamName})
                                        </button>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                          {/* Standout Player Ratings - Top 4 Players (Eski halindeki gibi 4 en iyi oyuncu) */}
                          {(msg.matchReport.playerRatings || msg.matchReport.standoutPlayers || msg.matchReport.motm) && (() => {
                            const top4Players = msg.matchReport.playerRatings && msg.matchReport.playerRatings.length > 0
                              ? [...msg.matchReport.playerRatings].sort((a, b) => b.rating - a.rating).slice(0, 4)
                              : (msg.matchReport.standoutPlayers || []).slice(0, 4).map(sp => ({
                                  name: sp.name,
                                  teamName: sp.teamName,
                                  rating: sp.rating,
                                  goals: 0,
                                  assists: 0,
                                  playerId: undefined
                                }));

                            return (
                              <div className="bg-[#17122e] p-2.5 rounded-lg border border-[#2b1f4c] text-[10.5px] space-y-2">
                                <div className="text-[9px] font-black text-purple-300 uppercase tracking-wider flex items-center justify-between flex-wrap gap-1">
                                  <span>⭐ {t('PLAYER_RATINGS') || 'Öne Çıkan Oyuncu Reytingleri'}</span>
                                  {msg.matchReport.motm && (
                                    <div className="flex items-center gap-1 text-[9.5px]">
                                      <span className="text-slate-400 font-bold">{t('MOTM') || 'Maçın Adamı'}:</span>
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handlePlayerClick(msg.matchReport?.motm?.name, undefined, msg.matchReport?.motm?.teamName);
                                        }}
                                        className="text-amber-300 font-black hover:underline cursor-pointer transition-colors"
                                        title={`${msg.matchReport.motm.name} - Profilini Aç`}
                                      >
                                        {msg.matchReport.motm.name} ({msg.matchReport.motm.rating.toFixed(1)})
                                      </button>
                                      {msg.matchReport.motm.goals ? <span className="text-amber-300 font-bold">• {msg.matchReport.motm.goals} ⚽</span> : null}
                                    </div>
                                  )}
                                </div>

                                {/* Top 4 Player Ratings Grid */}
                                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                                  {top4Players.map((pr, pIdx) => {
                                    const playerCard = msg.matchReport?.cards?.find(c => c.name === pr.name);
                                    return (
                                      <div
                                        key={pIdx}
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handlePlayerClick(pr.name, pr.playerId, pr.teamName);
                                        }}
                                        className="bg-[#1f173d] hover:bg-[#2a1f52] p-2 rounded-xl border border-[#35265e] flex items-center justify-between cursor-pointer transition-all hover:border-purple-400 group shadow-sm"
                                        title={`${pr.name} - Oyuncu Profilini Aç`}
                                      >
                                        <div className="min-w-0 pr-1">
                                          <div className="font-extrabold text-[10.5px] text-white group-hover:text-amber-300 transition-colors truncate flex items-center gap-1">
                                            <span>{pr.name}</span>
                                            {playerCard && <span>{playerCard.type === 'RED' ? '🟥' : '🟨'}</span>}
                                          </div>
                                          <div className="text-[8.5px] text-slate-400 truncate flex items-center gap-1">
                                            <span>{pr.teamName}</span>
                                            {(pr.goals || 0) > 0 && <span className="text-amber-300 font-bold">• {pr.goals} ⚽</span>}
                                            {(pr.assists || 0) > 0 && <span className="text-sky-300 font-bold">• {pr.assists} 🅰️</span>}
                                          </div>
                                        </div>
                                        <span className={`px-1.5 py-0.5 rounded font-black text-[9.5px] border shrink-0 ${
                                          pr.rating >= 8.0 ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40' :
                                          pr.rating >= 6.8 ? 'bg-teal-950 text-teal-300 border-teal-500/40' :
                                          pr.rating >= 6.0 ? 'bg-amber-950 text-amber-300 border-amber-500/40' :
                                          'bg-rose-950 text-rose-300 border-rose-600/70'
                                        }`}>
                                          {pr.rating.toFixed(1)}
                                        </span>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            );
                          })()}

                          {/* Yellow and Red Cards */}
                          {msg.matchReport.cards && msg.matchReport.cards.length > 0 && (
                            <div className="bg-[#17122e] p-2 rounded-lg border border-[#2b1f4c] text-[10.5px]">
                              <div className="text-[9px] font-black text-rose-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                                <span>🟨🟥 {t('CARDS_TITLE') || 'Sarı ve Kırmızı Kartlar'}</span>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                                {msg.matchReport.cards.map((c, cIdx) => (
                                  <div key={cIdx} className="flex items-center gap-1.5 text-slate-200 bg-[#1f173d]/70 px-2 py-1 rounded border border-[#35265e]/60">
                                    <span className="text-[11px]">{c.type === 'RED' ? '🟥' : '🟨'}</span>
                                    <span className="text-amber-400 font-bold text-[9.5px] shrink-0">{c.minute}'</span>
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handlePlayerClick(c.name, (c as any).playerId, c.teamName);
                                      }}
                                      className="font-extrabold text-white text-[10px] hover:text-amber-300 underline cursor-pointer transition-colors"
                                      title={`${c.name} - Oyuncu Profilini Aç`}
                                    >
                                      {c.name}
                                    </button>
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleTeamClick(c.teamName);
                                      }}
                                      className="text-[8.5px] text-slate-400 hover:text-purple-300 cursor-pointer transition-colors ml-auto"
                                      title={`${c.teamName} - Takım Profilini Aç`}
                                    >
                                      ({c.teamName})
                                    </button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Key Match Stats */}
                          {msg.matchReport.stats && (() => {
                            const st = msg.matchReport.stats;
                            const hShots = st.shotsHome;
                            const aShots = st.shotsAway;
                            const hTarget = st.shotsOnTargetHome;
                            const aTarget = st.shotsOnTargetAway;
                            const hPoss = st.possessionHome;
                            const aPoss = st.possessionAway;
                            const hPass = st.passAccuracyHome ?? Math.min(93, Math.max(68, Math.round(72 + hPoss * 0.25)));
                            const aPass = st.passAccuracyAway ?? Math.min(93, Math.max(68, Math.round(72 + aPoss * 0.25)));
                            const hCorners = st.cornersHome;
                            const aCorners = st.cornersAway;
                            const hFouls = st.foulsHome;
                            const aFouls = st.foulsAway;
                            const hYellow = st.yellowCardsHome ?? Math.round(hFouls * 0.15);
                            const aYellow = st.yellowCardsAway ?? Math.round(aFouls * 0.15);
                            const hSaves = st.savesHome ?? Math.max(0, aTarget - msg.matchReport.awayScore);
                            const aSaves = st.savesAway ?? Math.max(0, hTarget - msg.matchReport.homeScore);
                            const hXG = st.xGHome || (hShots * 0.08 + hTarget * 0.22 + msg.matchReport.homeScore * 0.4).toFixed(2);
                            const aXG = st.xGAway || (aShots * 0.08 + aTarget * 0.22 + msg.matchReport.awayScore * 0.4).toFixed(2);

                            const statRows = [
                              { label: t('XG_EXPECTED_GOALS') || 'xG (Beklenen Gol)', hVal: hXG, aVal: aXG, hNum: parseFloat(hXG) || 1, aNum: parseFloat(aXG) || 1 },
                              { label: t('POSSESSION') || 'Topla Oynama', hVal: `%${hPoss}`, aVal: `%${aPoss}`, hNum: hPoss, aNum: aPoss },
                              { label: t('SHOTS') || 'Toplam Şut', hVal: hShots, aVal: aShots, hNum: hShots, aNum: aShots },
                              { label: t('SHOTS_ON_TARGET') || 'İsabetli Şut', hVal: hTarget, aVal: aTarget, hNum: hTarget, aNum: aTarget },
                              { label: t('PASS_ACCURACY') || 'Pas İsabeti', hVal: `%${hPass}`, aVal: `%${aPass}`, hNum: hPass, aNum: aPass },
                              { label: t('SET_PIECES') || 'Kornerler', hVal: hCorners, aVal: aCorners, hNum: hCorners, aNum: aCorners },
                              { label: t('FOULS') || 'Fauller', hVal: hFouls, aVal: aFouls, hNum: hFouls, aNum: aFouls },
                              { label: t('YELLOW_CARDS') || 'Sarı Kartlar', hVal: hYellow, aVal: aYellow, hNum: hYellow, aNum: aYellow },
                              { label: t('SAVES') || 'Kurtarışlar', hVal: hSaves, aVal: aSaves, hNum: hSaves, aNum: aSaves }
                            ];

                            return (
                              <div className="bg-[#17122e] p-2.5 rounded-lg border border-[#2b1f4c] text-[10px] space-y-2">
                                <div className="text-[9px] font-black text-amber-400 uppercase tracking-wider text-center border-b border-[#2b1f4c] pb-1">
                                  📊 {t('DETAILED_STATS') || 'Maç İstatistikleri'}
                                </div>

                                <div className="space-y-1.5">
                                  {statRows.map((r, rIdx) => {
                                    const total = (r.hNum + r.aNum) || 1;
                                    const hPercent = Math.max(10, Math.min(90, Math.round((r.hNum / total) * 100)));
                                    const aPercent = 100 - hPercent;

                                    return (
                                      <div key={rIdx} className="space-y-0.5">
                                        <div className="flex justify-between items-center text-[9.5px] font-extrabold">
                                          <span className="text-emerald-400">{r.hVal}</span>
                                          <span className="text-slate-300 font-semibold">{r.label}</span>
                                          <span className="text-sky-400">{r.aVal}</span>
                                        </div>
                                        <div className="w-full bg-[#241a45] h-1.5 rounded-full flex overflow-hidden">
                                          <div className="bg-emerald-500 h-full transition-all" style={{ width: `${hPercent}%` }} />
                                          <div className="bg-sky-500 h-full transition-all" style={{ width: `${aPercent}%` }} />
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            );
                          })()}

                        </div>
                      )}

                      {/* Visual Media Reviews & Commentary if present */}
                      {msg.mediaReview && (
                        <div className="bg-[#120e24] border border-amber-500/30 rounded-xl p-3 space-y-2.5 shadow-lg">
                          <div className="text-[10px] font-black text-amber-400 uppercase tracking-wider flex items-center justify-between border-b border-[#2e2154] pb-1">
                            <span>📰 Basın & Yorumcu Değerlendirmeleri</span>
                            <span className="text-[8.5px] text-slate-400 font-semibold">Ulusal & Dış Basın</span>
                          </div>

                          {msg.mediaReview.matchSummary && (
                            <p className="text-[11px] text-slate-300 italic font-medium">
                              "{msg.mediaReview.matchSummary}"
                            </p>
                          )}

                          <div className="space-y-2 pt-1">
                            {msg.mediaReview.reviews.map((r, rIdx) => (
                              <div key={rIdx} className="bg-[#181330] p-2.5 rounded-lg border border-[#2b1f4c] space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="text-[10px] font-extrabold text-white flex items-center gap-1.5">
                                    <span className="text-amber-400">●</span> {r.author}
                                  </span>
                                  <span className="text-[8px] font-black uppercase px-1.5 py-0.2 rounded bg-[#241a45] text-purple-300 border border-[#3b2a6b]">
                                    {r.source}
                                  </span>
                                </div>
                                <p className="text-[10.5px] text-slate-200 leading-snug">
                                  {r.comment}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Action Cards (Excluded for Match Reports) */}
                      {msg.category !== 'MATCH_REPORT' && !msg.matchReport && msg.tag !== 'MAÇ_SONUCU' && msg.tag !== 'MAÇ' && (msg.actionType === 'GOTO_TACTICS' || msg.tag === 'TAKTIK' || msg.type === 'TAKTIK' || (msg.subject && (msg.subject.includes('Kadro') || msg.subject.includes('Diziliş'))) || (msg.content && (msg.content.includes('diziliş') || msg.content.includes('Önerilen')))) && onGoToTacticsWithRecommended && (
                        <div className="pt-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onClose();
                              onGoToTacticsWithRecommended();
                            }}
                            className="w-full py-2.5 bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:from-purple-500 hover:to-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-98 cursor-pointer flex items-center justify-center gap-1.5 border border-purple-400"
                          >
                            <span>{t('GO_TO_TACTICS_APPLY')}</span>
                          </button>
                        </div>
                      )}

                      {msg.actionType === 'OPEN_CONTRACT_NEGOTIATION' && msg.actionData?.player && onOpenContractNegotiation && (
                        <div className="pt-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onClose();
                              onOpenContractNegotiation(
                                msg.actionData!.player!,
                                msg.actionData?.sellerTeam,
                                msg.actionData?.effectiveFee
                              );
                            }}
                            className="w-full py-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all active:scale-98 cursor-pointer flex items-center justify-center gap-1.5 border border-amber-300"
                          >
                            <span>{t('START_CONTRACT_NEGOTIATION')}</span>
                          </button>
                        </div>
                      )}

                      {/* Explicit Interactive Profile Card if actionData has player */}
                      {msg.actionData?.player && onOpenPlayerProfile && (
                        <div className="p-2.5 bg-[#120f21] border border-[#332657] rounded-xl flex items-center justify-between gap-2 shadow-inner">
                          <div className="flex items-center gap-2 min-w-0">
                            <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center font-black text-amber-300 text-xs shrink-0">
                              {msg.actionData.player.overall}
                            </div>
                            <div className="min-w-0">
                              <span className="font-extrabold text-xs text-white truncate block">
                                {msg.actionData.player.name}
                              </span>
                              <span className="text-[10px] text-slate-400 font-semibold block truncate">
                                {msg.actionData.player.position} • {msg.actionData.player.age} • {t('MARKET_VALUE_LABEL')}: €{((msg.actionData.player.marketValue || 5000000) / 1_000_000).toFixed(1)}M
                              </span>
                            </div>
                          </div>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onOpenPlayerProfile(msg.actionData!.player!, msg.actionData?.sellerTeam);
                            }}
                            className="px-3 py-1 rounded-lg bg-purple-600/30 hover:bg-purple-600 border border-purple-400/50 text-purple-200 hover:text-white font-extrabold text-[10px] transition-all shrink-0 cursor-pointer"
                          >
                            {t('OPEN_PROFILE')}
                          </button>
                        </div>
                      )}

                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

      </div>
    </div>
  );
};

