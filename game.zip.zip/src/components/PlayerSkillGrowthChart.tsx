import React, { useState } from 'react';
import { Player } from '../types';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ReferenceLine
} from 'recharts';
import { TrendingUp, User, Sparkles, Zap, Shield, Target } from 'lucide-react';
import { CustomSelect, CustomSelectOption } from './CustomSelect';
import { useTranslation } from '../utils/i18n';

interface PlayerSkillGrowthChartProps {
  player: Player;
  players?: Player[];
  onSelectPlayer?: (playerId: string) => void;
}

export const PlayerSkillGrowthChart: React.FC<PlayerSkillGrowthChartProps> = ({
  player,
  players = [],
  onSelectPlayer
}) => {
  const { t, language } = useTranslation();
  const isTr = language === 'TR';

  const [chartView, setChartView] = useState<'PROGRESSION' | 'RADAR'>('PROGRESSION');

  const age = player.age || 22;
  const currentOvr = player.overall;
  
  // Calculate realistic potential ceiling
  const potentialCeiling = player.potential || (
    age <= 19 ? Math.min(99, currentOvr + 12) :
    age <= 22 ? Math.min(99, currentOvr + 8) :
    age <= 25 ? Math.min(99, currentOvr + 4) :
    age <= 28 ? Math.min(99, currentOvr + 2) :
    currentOvr
  );

  const potentialDiff = Math.max(0, potentialCeiling - currentOvr);

  // Growth Pace Category
  const getGrowthCategory = () => {
    if (age <= 20 && potentialDiff >= 6) {
      return { label: '⭐ Yüksek Gelişim (Genç Yetenek)', color: 'text-amber-300', bg: 'bg-amber-500/20 border-amber-500/40', rate: 'Hızlı (%4-6 / Hafta)' };
    }
    if (age <= 24 && potentialDiff > 0) {
      return { label: '📈 Dengeli Gelişim (Gelişmekte)', color: 'text-emerald-300', bg: 'bg-emerald-500/20 border-emerald-500/40', rate: 'Normal (%2-3 / Hafta)' };
    }
    if (age <= 29) {
      return { label: '⚡ Zirve Dönemi (Prime Seviye)', color: 'text-sky-300', bg: 'bg-sky-500/20 border-sky-500/40', rate: 'Durağan / Koruma (%1 / Hafta)' };
    }
    return { label: '🛡️ Tecrübeli Veteran', color: 'text-purple-300', bg: 'bg-purple-500/20 border-purple-500/40', rate: 'Maksimum Seviye (Fizik Koruma)' };
  };

  const growthCat = getGrowthCategory();

  // Realistic Trajectory over weeks (based on age, potential headroom, and intensity)
  // Young players develop steadily over multiple weeks, older players stay flat
  const intensityMultiplier = player.trainingIntensity === 'Ağır' ? 1.25 : player.trainingIntensity === 'Hafif' ? 0.75 : 1.0;
  
  const generateTrajectoryData = () => {
    const data = [];
    const weeks = [1, 5, 10, 15, 20, 25, 30, 38];

    weeks.forEach(w => {
      let projectedGain = 0;
      if (age <= 20) {
        projectedGain = (w / 38) * Math.min(4, potentialDiff) * intensityMultiplier;
      } else if (age <= 23) {
        projectedGain = (w / 38) * Math.min(2.5, potentialDiff) * intensityMultiplier;
      } else if (age <= 26) {
        projectedGain = (w / 38) * Math.min(1.5, potentialDiff) * intensityMultiplier;
      } else if (age <= 29) {
        projectedGain = (w / 38) * Math.min(0.5, potentialDiff) * intensityMultiplier;
      } else {
        projectedGain = 0;
      }

      const ovrVal = Number((currentOvr + projectedGain).toFixed(1));
      const formVal = Math.min(98, Math.max(65, (player.form || 8) * 10 + Math.sin(w) * 5));

      data.push({
        name: `${w}. Hf`,
        ovr: ovrVal,
        tavan: potentialCeiling,
        form: Math.round(formVal)
      });
    });

    return data;
  };

  const dataProgress = generateTrajectoryData();

  // Attribute Radar Data
  const radarData = [
    { subject: t('RADAR_PACE') || 'HIZ', value: player.attributes.pace, fullMark: 99 },
    { subject: t('RADAR_SHOOTING') || 'ŞUT', value: player.attributes.shooting, fullMark: 99 },
    { subject: t('RADAR_PASSING') || 'PAS', value: player.attributes.passing, fullMark: 99 },
    { subject: t('RADAR_DEFENDING') || 'DEF', value: player.attributes.defending, fullMark: 99 },
    { subject: t('RADAR_PHYSICAL') || 'FİZ', value: player.attributes.physical, fullMark: 99 }
  ];

  const getFocusShortTranslated = (focusVal?: string) => {
    switch (focusVal) {
      case 'Hücum': return isTr ? 'Hücum' : 'Attacking';
      case 'Pas': return isTr ? 'Pas' : 'Passing';
      case 'Defans': return isTr ? 'Defans' : 'Defending';
      case 'Fizik': return isTr ? 'Fizik' : 'Physical';
      case 'Yeni Pozisyon': return isTr ? 'Yeni Pozisyon' : 'New Role';
      case 'Genel':
      default:
        return isTr ? 'Genel' : 'General';
    }
  };

  const focusText = getFocusShortTranslated(player.trainingFocus);

  // Options for player switcher dropdown
  const playerSelectOptions: CustomSelectOption[] = players.map(p => ({
    value: p.id,
    label: `${p.name} (${p.position})`,
    player: p,
    badge: p.position,
    ovr: p.overall
  }));

  return (
    <div className="bg-[#120e24] border border-[#2b224d] rounded-2xl p-3 sm:p-4 space-y-3 shadow-2xl">
      
      {/* Top Header & Player Switcher Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-[#2d2252] pb-3">
        <div className="flex items-center gap-2.5 flex-1 min-w-0">
          <div className="p-2 rounded-xl bg-gradient-to-tr from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 text-emerald-400 shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h4 className="font-black text-white text-xs sm:text-sm tracking-wide truncate">
                {t('GROWTH_CURVE_TITLE') || 'OYUNCU GELİŞİM & POTANSİYEL ANALİZİ'}
              </h4>
              <span className="px-2 py-0.2 rounded bg-amber-500/20 border border-amber-500/30 text-amber-300 font-extrabold text-[9px] uppercase shrink-0">
                {t('FOCUS_LABEL') || 'ODAK:'} {focusText}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium mt-0.5 truncate">
              {player.name} &bull; {player.position} ({player.specificRole || t('PLAYER_FALLBACK')}) - OVR: <strong className="text-emerald-400">{player.overall}</strong> &bull; {t('AGE_LABEL') || 'Yaş:'} <strong className="text-amber-300">{age}</strong>
            </p>
          </div>
        </div>

        {/* Player Selection Dropdown & Chart View Controls */}
        <div className="flex items-center gap-2 w-full sm:w-auto shrink-0 justify-between sm:justify-end">
          {players.length > 0 && onSelectPlayer && (
            <div className="flex items-center gap-1 min-w-[170px]">
              <User className="w-3.5 h-3.5 text-purple-400 shrink-0" />
              <CustomSelect
                value={player.id}
                onChange={(pId) => onSelectPlayer(pId)}
                options={playerSelectOptions}
                dropdownAlign="right"
              />
            </div>
          )}

          <div className="flex items-center bg-[#1c1638] p-1 rounded-xl border border-[#372b63] shrink-0">
            <button
              onClick={() => setChartView('PROGRESSION')}
              className={`px-2.5 py-1 rounded-lg font-extrabold text-[10px] sm:text-xs transition-all cursor-pointer ${
                chartView === 'PROGRESSION'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t('FORM_OVR_CURVE_BTN') || 'Gelişim Eğrisi'}
            </button>
            <button
              onClick={() => setChartView('RADAR')}
              className={`px-2.5 py-1 rounded-lg font-extrabold text-[10px] sm:text-xs transition-all cursor-pointer ${
                chartView === 'RADAR'
                  ? 'bg-purple-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t('ATTRIBUTE_RADAR_BTN') || 'Radar Analizi'}
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards: Current OVR, Potential Ceiling, Headroom, Category */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <div className="bg-[#171233] p-2 rounded-xl border border-[#2d2250] flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-black text-xs shrink-0">
            <Zap className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[8px] uppercase font-bold text-slate-400 block">Mevcut Güç (CA)</span>
            <span className="text-sm font-black text-emerald-400">{currentOvr} OVR</span>
          </div>
        </div>

        <div className="bg-[#171233] p-2 rounded-xl border border-[#2d2250] flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-300 flex items-center justify-center font-black text-xs shrink-0">
            <Target className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[8px] uppercase font-bold text-slate-400 block">Tavan Potansiyel (PA)</span>
            <span className="text-sm font-black text-amber-300">{potentialCeiling} POT</span>
          </div>
        </div>

        <div className="bg-[#171233] p-2 rounded-xl border border-[#2d2250] flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-purple-500/20 border border-purple-500/40 text-purple-300 flex items-center justify-center font-black text-xs shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[8px] uppercase font-bold text-slate-400 block">Gelişim Alanı</span>
            <span className="text-sm font-black text-purple-300">
              {potentialDiff > 0 ? `+${potentialDiff} OVR Kapasite` : 'Maksimum Zirve'}
            </span>
          </div>
        </div>

        <div className="bg-[#171233] p-2 rounded-xl border border-[#2d2250] flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-sky-500/20 border border-sky-500/40 text-sky-300 flex items-center justify-center font-black text-xs shrink-0">
            <Shield className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[8px] uppercase font-bold text-slate-400 block">Gelişim Hızı</span>
            <span className="text-[10px] font-black text-white truncate block">{growthCat.rate}</span>
          </div>
        </div>
      </div>

      {/* Main Chart Area */}
      {chartView === 'PROGRESSION' && (
        <div className="bg-[#0b0817] p-3 sm:p-4 rounded-xl border border-[#231b42] animate-fadeIn space-y-2">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="text-[11px] uppercase font-black text-emerald-400 tracking-wider">
                Sezonluk Gelişim & Potansiyel Eğrisi
              </span>
              <span className={`px-2 py-0.2 rounded text-[8.5px] font-black border ${growthCat.bg} ${growthCat.color}`}>
                {growthCat.label}
              </span>
            </div>

            <div className="flex items-center gap-3 text-[10px] font-bold">
              <span className="flex items-center gap-1 text-emerald-400">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" /> OVR Gelişimi
              </span>
              <span className="flex items-center gap-1 text-amber-400">
                <span className="w-2.5 h-0.5 bg-amber-400 inline-block" /> Tavan Potansiyel ({potentialCeiling})
              </span>
              <span className="flex items-center gap-1 text-purple-400">
                <span className="w-2.5 h-0.5 border-t border-dashed border-purple-400 inline-block" /> Form Eğrisi
              </span>
            </div>
          </div>

          <div className="h-64 sm:h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={dataProgress} margin={{ top: 10, right: 15, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#231b42" />
                <XAxis dataKey="name" stroke="#8b5cf6" tick={{ fontSize: 11, fontWeight: 'bold' }} />
                <YAxis domain={[Math.max(45, currentOvr - 5), Math.min(99, Math.max(potentialCeiling + 2, currentOvr + 5))]} stroke="#64748b" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#120e24',
                    borderColor: '#4c3b80',
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px'
                  }}
                />
                <ReferenceLine y={potentialCeiling} stroke="#f59e0b" strokeDasharray="3 3" label={{ value: `Tavan (${potentialCeiling})`, fill: '#f59e0b', fontSize: 10, position: 'insideTopRight' }} />
                <Line
                  type="monotone"
                  dataKey="ovr"
                  name="OVR Güç Seviyesi"
                  stroke="#10b981"
                  strokeWidth={3}
                  dot={{ r: 4, fill: '#10b981' }}
                  activeDot={{ r: 7, fill: '#34d399' }}
                />
                <Line
                  type="monotone"
                  dataKey="form"
                  name="Maç Formu"
                  stroke="#c084fc"
                  strokeWidth={1.5}
                  strokeDasharray="4 4"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <p className="text-[9px] text-slate-400 font-medium text-center">
            * OVR artışı oyuncunun yaşına ({age} Yaş) ve potansiyeline ({potentialCeiling} POT) göre dengeli şekilde ilerler. Genç yetenekler düzenli antrenman ve maç tecrübesiyle daha hızlı gelişir.
          </p>
        </div>
      )}

      {/* Radar View */}
      {chartView === 'RADAR' && (
        <div className="bg-[#0b0817] p-3 sm:p-4 rounded-xl border border-[#231b42] flex flex-col items-center animate-fadeIn">
          <span className="text-[11px] uppercase font-black text-amber-300 tracking-wider block mb-1">
            {t('RADAR_CHART_HEADER') || '5 TEMEL YETENEK RADAR DAĞILIMI'}
          </span>
          <div className="h-64 sm:h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="75%" data={radarData}>
                <PolarGrid stroke="#2e2454" />
                <PolarAngleAxis dataKey="subject" stroke="#a78bfa" tick={{ fontSize: 11, fontWeight: 'bold' }} />
                <PolarRadiusAxis angle={30} domain={[0, 99]} stroke="#4c3b80" tick={{ fontSize: 9 }} />
                <Radar
                  name={player.name}
                  dataKey="value"
                  stroke="#10b981"
                  fill="#10b981"
                  fillOpacity={0.45}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#120e24',
                    borderColor: '#4c3b80',
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px'
                  }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

    </div>
  );
};
