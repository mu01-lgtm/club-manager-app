import React from 'react';
import { Team, Fixture, LeagueRow, InboxMessage, FormationType, Player } from '../types';
import { useTranslation } from '../utils/i18n';
import { Brain, FlaskConical, HeartPulse, BarChart3, ChevronDown, MoveUpRight, Palmtree } from 'lucide-react';
import { TeamBadge } from './TeamBadge';
import { SoccerJersey } from './SoccerJersey';
import { calculateBoardConfidence } from '../utils/teamGoalsHelper';

interface HomeDashboardProps {
  currentTeam: Team;
  opponentTeam: Team;
  currentWeek: number;
  currentSeason: number;
  managerName: string;
  allTeams: Team[];
  standings: LeagueRow[];
  currentWeekFixture?: Fixture;
  inboxMessages?: InboxMessage[];
  onOpenPreMatch: () => void;
  onOpenMatchComparison: () => void;
  onOpenVacationModal: () => void;
  onOpenBoardConfidenceModal: () => void;
  onOpenFinancesModal: () => void;
  onOpenFullSquadModal: () => void;
  onNavigateTab: (tab: string) => void;
  onChangeFormation?: (f: FormationType) => void;
}

// Helper to determine accurate team kit colors matching official club identities
export const getTeamKitDetails = (team: Team) => {
  const name = (team.name || '').toLowerCase();
  const id = (team.id || '').toLowerCase();
  
  // Manchester City (Vibrant Sky Blue & White)
  if (name.includes('manchester city') || id.includes('manchester-city') || id === 'mci') {
    return { primary: '#38bdf8', secondary: '#ffffff', gk: '#10b981' };
  }
  // Arsenal (Vibrant Red & White)
  if (name.includes('arsenal') || id.includes('arsenal') || id === 'ars') {
    return { primary: '#ef4444', secondary: '#ffffff', gk: '#f59e0b' };
  }
  // Liverpool (Crimson Red)
  if (name.includes('liverpool') || id.includes('liverpool') || id === 'liv') {
    return { primary: '#dc2626', secondary: '#ffffff', gk: '#10b981' };
  }
  // Chelsea (Royal Blue)
  if (name.includes('chelsea') || id.includes('chelsea') || id === 'che') {
    return { primary: '#2563eb', secondary: '#ffffff', gk: '#f59e0b' };
  }
  // Manchester United (Red & White)
  if (name.includes('manchester united') || id.includes('manchester-united') || id === 'mun') {
    return { primary: '#dc2626', secondary: '#ffffff', gk: '#10b981' };
  }
  // Tottenham (White & Navy)
  if (name.includes('tottenham') || id.includes('tottenham') || id === 'tot') {
    return { primary: '#f8fafc', secondary: '#1e293b', gk: '#10b981' };
  }
  // Real Madrid (Pure White & Gold)
  if (name.includes('real madrid') || id.includes('real-madrid') || id === 'rma') {
    return { primary: '#f8fafc', secondary: '#eab308', gk: '#10b981' };
  }
  // Barcelona (Blaugrana / Deep Blue & Crimson)
  if (name.includes('barcelona') || id.includes('barcelona') || id === 'bar') {
    return { primary: '#1e40af', secondary: '#dc2626', gk: '#10b981' };
  }
  // Bayern Munich (Red)
  if (name.includes('bayern') || id.includes('bayern') || id === 'bay') {
    return { primary: '#dc2626', secondary: '#ffffff', gk: '#10b981' };
  }
  // Dortmund (Bumblebee Yellow)
  if (name.includes('dortmund') || id.includes('dortmund') || id === 'bvb') {
    return { primary: '#eab308', secondary: '#000000', gk: '#10b981' };
  }
  // PSG (Navy & Red)
  if (name.includes('paris') || name.includes('psg') || id.includes('psg')) {
    return { primary: '#1e3a8a', secondary: '#dc2626', gk: '#10b981' };
  }
  // Galatasaray (Yellow / Red)
  if (name.includes('galatasaray') || id.includes('galatasaray') || id === 'gs') {
    return { primary: '#ea580c', secondary: '#facc15', gk: '#10b981' };
  }
  // Fenerbahçe (Navy / Yellow)
  if (name.includes('fenerbahce') || name.includes('fenerbahçe') || id.includes('fenerbahce') || id === 'fb') {
    return { primary: '#1d4ed8', secondary: '#facc15', gk: '#10b981' };
  }
  // Beşiktaş (Black & White)
  if (name.includes('besiktas') || name.includes('beşiktaş') || id.includes('besiktas') || id === 'bjk') {
    return { primary: '#f8fafc', secondary: '#000000', gk: '#10b981' };
  }
  // Trabzonspor (Claret & Blue)
  if (name.includes('trabzon') || id.includes('trabzon') || id === 'ts') {
    return { primary: '#831843', secondary: '#0284c7', gk: '#10b981' };
  }
  // Southampton (Red & White)
  if (name.includes('southampton') || id.includes('southampton') || id === 'sou') {
    return { primary: '#ef4444', secondary: '#ffffff', gk: '#10b981' };
  }

  // Fallback to team badge color
  let primary = '#38bdf8';
  if (team.badgeColor) {
    if (team.badgeColor.startsWith('#')) {
      primary = team.badgeColor;
    } else if (team.badgeColor.includes('sky')) {
      primary = '#38bdf8';
    } else if (team.badgeColor.includes('red')) {
      primary = '#ef4444';
    } else if (team.badgeColor.includes('blue')) {
      primary = '#2563eb';
    } else if (team.badgeColor.includes('yellow') || team.badgeColor.includes('amber')) {
      primary = '#eab308';
    } else if (team.badgeColor.includes('green') || team.badgeColor.includes('emerald')) {
      primary = '#10b981';
    } else if (team.badgeColor.includes('purple')) {
      primary = '#a855f7';
    }
  }

  return { primary, secondary: '#ffffff', gk: '#10b981' };
};

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  currentTeam,
  opponentTeam,
  currentWeek,
  currentSeason,
  managerName,
  allTeams,
  standings,
  currentWeekFixture,
  onOpenMatchComparison,
  onOpenVacationModal,
  onOpenBoardConfidenceModal,
  onOpenFinancesModal,
  onOpenFullSquadModal,
  onNavigateTab,
  onChangeFormation
}) => {
  const { t, language } = useTranslation();

  // Find user's rank
  const currentTeamStanding = standings.find(s => s.teamId === currentTeam.id);
  const currentRank = currentTeamStanding
    ? standings
        .slice()
        .sort((a, b) => b.points - a.points || (b.goalsFor - b.goalsAgainst) - (a.goalsFor - a.goalsAgainst))
        .findIndex(s => s.teamId === currentTeam.id) + 1
    : 1;

  // Calculate dynamic board confidence %
  const boardConfidence = calculateBoardConfidence(
    currentRank,
    standings.length,
    currentTeamStanding?.played || 0,
    currentTeam,
    currentTeamStanding?.won || 0,
    currentTeamStanding?.drawn || 0,
    currentTeamStanding?.lost || 0,
    currentTeamStanding?.form || []
  );
  const kitDetails = getTeamKitDetails(currentTeam);

  // Sync starting 11 directly from active team starterIndex slots (matching TacticalPitch lineup order)
  const starting11 = React.useMemo(() => {
    const slots: (Player | null)[] = new Array(11).fill(null);
    const assigned = new Set<string>();

    // 1. Explicit starterIndex (0..10)
    (currentTeam.players || []).forEach(p => {
      if (p.isStarting && p.starterIndex !== undefined && p.starterIndex >= 0 && p.starterIndex < 11) {
        if (!slots[p.starterIndex]) {
          slots[p.starterIndex] = p;
          assigned.add(p.id);
        }
      }
    });

    // 2. Any other isStarting players without starterIndex placed into first empty slot
    (currentTeam.players || []).forEach(p => {
      if (p.isStarting && !assigned.has(p.id)) {
        const nextEmpty = slots.findIndex(s => s === null);
        if (nextEmpty !== -1) {
          slots[nextEmpty] = p;
          assigned.add(p.id);
        }
      }
    });

    return slots;
  }, [currentTeam.players]);

  // Clean, crisp player last name helper (e.g., GREALISH, HAALAND, SILVA, KOVAČIĆ, RODRI, DE BRUYNE, GVARDIOL, DIAS, AKANJI, WALKER, EDERSON)
  const getLastName = (fullName: string): string => {
    if (!fullName) return '';
    const trimmed = fullName.trim().toUpperCase();
    if (trimmed.includes('DE BRUYNE')) return 'DE BRUYNE';
    if (trimmed.includes('VAN DIJK')) return 'VAN DIJK';
    if (trimmed.includes('DEL CASTILLO')) return 'DEL CASTILLO';
    if (trimmed.includes('KOVACIC') || trimmed.includes('KOVAČIĆ')) return 'KOVAČIĆ';
    if (trimmed.includes('GÜNDOGAN') || trimmed.includes('GUNDOGAN') || trimmed.includes('GÜNDOĞAN')) return 'GÜNDOĞAN';
    if (trimmed.includes('-')) {
      const parts = trimmed.split('-');
      return parts[parts.length - 1].trim();
    }
    const parts = trimmed.split(' ');
    return parts[parts.length - 1] || trimmed;
  };

  // Jersey shirt number helper matching authentic player numbers
  const getShirtNumber = (p: Player | null, index: number): number => {
    if (!p) return index + 1;
    if (p.number && p.number > 0) return p.number;

    const name = (p.name || '').toUpperCase();
    if (name.includes('EDERSON')) return 31;
    if (name.includes('HAALAND')) return 9;
    if (name.includes('GREALISH')) return 10;
    if (name.includes('DE BRUYNE')) return 17;
    if (name.includes('RODRI')) return 16;
    if (name.includes('SILVA')) return 20;
    if (name.includes('FODEN')) return 47;
    if (name.includes('DOKU')) return 11;
    if (name.includes('KOVACIC') || name.includes('KOVAČIĆ')) return 8;
    if (name.includes('GVARDIOL')) return 24;
    if (name.includes('DIAS')) return 3;
    if (name.includes('AKANJI')) return 25;
    if (name.includes('WALKER')) return 2;
    if (name.includes('STONES')) return 5;
    if (name.includes('GÜNDO') || name.includes('GUNDO')) return 19;

    // Fallback based on slot
    if (index === 0) return 1;
    if (index === 1) return 3;
    if (index === 2) return 4;
    if (index === 3) return 5;
    if (index === 4) return 2;
    if (index === 5) return 8;
    if (index === 6) return 6;
    if (index === 7) return 10;
    if (index === 8) return 11;
    if (index === 9) return 9;
    if (index === 10) return 7;

    return index + 1;
  };

  // Precise coordinates for 2.5D Perspective Pitch (Crystal Sharp, No GPU Texture Blur)
  // Top: Forwards (distant, high Y), Bottom: Goalkeeper (near, low Y)
  const getPitchCoords = (index: number, formation: FormationType = '4-3-3') => {
    // Index 0: Goalkeeper (Bottom Center)
    if (index === 0) return { top: '80%', left: '50%' };

    switch (formation) {
      case '4-3-3':
        // Defenders: LB, LCB, RCB, RB
        if (index === 1) return { top: '63%', left: '16%' };
        if (index === 2) return { top: '65%', left: '38%' };
        if (index === 3) return { top: '65%', left: '62%' };
        if (index === 4) return { top: '63%', left: '84%' };
        // Midfielders: LCM, CDM, RCM
        if (index === 5) return { top: '44%', left: '26%' };
        if (index === 6) return { top: '48%', left: '50%' };
        if (index === 7) return { top: '44%', left: '74%' };
        // Forwards: LW, ST, RW
        if (index === 8) return { top: '23%', left: '20%' };
        if (index === 9) return { top: '16%', left: '50%' };
        if (index === 10) return { top: '23%', left: '80%' };
        break;

      case '4-2-3-1':
        if (index === 1) return { top: '63%', left: '16%' };
        if (index === 2) return { top: '65%', left: '38%' };
        if (index === 3) return { top: '65%', left: '62%' };
        if (index === 4) return { top: '63%', left: '84%' };
        if (index === 5) return { top: '48%', left: '34%' };
        if (index === 6) return { top: '48%', left: '66%' };
        if (index === 7) return { top: '30%', left: '18%' };
        if (index === 8) return { top: '30%', left: '50%' };
        if (index === 9) return { top: '30%', left: '82%' };
        if (index === 10) return { top: '16%', left: '50%' };
        break;

      case '4-4-2':
        if (index === 1) return { top: '63%', left: '16%' };
        if (index === 2) return { top: '65%', left: '38%' };
        if (index === 3) return { top: '65%', left: '62%' };
        if (index === 4) return { top: '63%', left: '84%' };
        if (index === 5) return { top: '42%', left: '16%' };
        if (index === 6) return { top: '44%', left: '38%' };
        if (index === 7) return { top: '44%', left: '62%' };
        if (index === 8) return { top: '42%', left: '84%' };
        if (index === 9) return { top: '17%', left: '36%' };
        if (index === 10) return { top: '17%', left: '64%' };
        break;

      case '3-5-2':
        if (index === 1) return { top: '63%', left: '25%' };
        if (index === 2) return { top: '65%', left: '50%' };
        if (index === 3) return { top: '63%', left: '75%' };
        if (index === 4) return { top: '42%', left: '14%' };
        if (index === 5) return { top: '48%', left: '34%' };
        if (index === 6) return { top: '32%', left: '50%' };
        if (index === 7) return { top: '48%', left: '66%' };
        if (index === 8) return { top: '42%', left: '86%' };
        if (index === 9) return { top: '17%', left: '36%' };
        if (index === 10) return { top: '17%', left: '64%' };
        break;

      case '5-3-2':
        if (index === 1) return { top: '60%', left: '14%' };
        if (index === 2) return { top: '63%', left: '32%' };
        if (index === 3) return { top: '65%', left: '50%' };
        if (index === 4) return { top: '63%', left: '68%' };
        if (index === 5) return { top: '60%', left: '86%' };
        if (index === 6) return { top: '44%', left: '30%' };
        if (index === 7) return { top: '48%', left: '50%' };
        if (index === 8) return { top: '44%', left: '70%' };
        if (index === 9) return { top: '17%', left: '36%' };
        if (index === 10) return { top: '17%', left: '64%' };
        break;

      default:
        if (index === 1) return { top: '63%', left: '16%' };
        if (index === 2) return { top: '65%', left: '38%' };
        if (index === 3) return { top: '65%', left: '62%' };
        if (index === 4) return { top: '63%', left: '84%' };
        if (index === 5) return { top: '44%', left: '26%' };
        if (index === 6) return { top: '48%', left: '50%' };
        if (index === 7) return { top: '44%', left: '74%' };
        if (index === 8) return { top: '23%', left: '20%' };
        if (index === 9) return { top: '16%', left: '50%' };
        if (index === 10) return { top: '23%', left: '80%' };
        break;
    }
    return { top: '50%', left: '50%' };
  };

  const isHomeMatch = currentWeekFixture?.homeTeamId === currentTeam.id;

  return (
    <div className="flex flex-col gap-2.5 w-full text-slate-200 select-none pb-4">
      
      {/* 1. TOP 2x2 COMPACT GRID CARDS */}
      <div className="grid grid-cols-2 gap-1.5 shrink-0">
        
        {/* Card 1: RANK (Trophy Watermark) */}
        <div
          onClick={() => onNavigateTab('STANDINGS')}
          className="bg-[#120e24] hover:bg-[#1a1433] border border-[#231b40] hover:border-emerald-500/70 rounded-xl px-3 py-1.5 flex flex-col justify-center shadow cursor-pointer transition-all relative overflow-hidden group min-h-[44px] sm:min-h-[48px]"
        >
          <span className="text-[9px] sm:text-[10px] font-black text-slate-400 group-hover:text-emerald-400 uppercase tracking-wider leading-none z-10">
            {language === 'TR' ? 'SIRALAMA' : 'RANK'}
          </span>
          
          <div className="flex items-baseline gap-1.5 z-10 mt-0.5">
            <span className="text-base sm:text-lg font-black text-emerald-400 leading-none">#{currentRank}</span>
            <span className="text-[9px] sm:text-[10px] text-slate-400 font-bold">/ {allTeams.length} {language === 'TR' ? 'Takım' : 'Teams'}</span>
          </div>

          {/* Enlarged Trophy Watermark Graphic */}
          <div className="absolute -right-2 top-1/2 -translate-y-1/2 text-white/[0.09] group-hover:text-emerald-400/20 transition-colors pointer-events-none">
            <svg viewBox="0 0 64 64" className="w-14 h-14 sm:w-16 sm:h-16 fill-none stroke-current stroke-[1.7]">
              <path d="M18 10 H46 V28 C46 36 39 42 32 42 C25 42 18 36 18 28 Z" fill="currentColor" fillOpacity="0.04" />
              <path d="M18 16 H10 C7 16 6 22 10 26 C13 29 18 29 18 29" />
              <path d="M46 16 H54 C57 16 58 22 54 26 C51 29 46 29 46 29" />
              <path d="M32 42 V52 M22 56 H42" />
              <circle cx="32" cy="24" r="5" fill="currentColor" fillOpacity="0.08" />
            </svg>
          </div>
        </div>

        {/* Card 2: BOARD CONFIDENCE (Shield Watermark) */}
        <div
          onClick={onOpenBoardConfidenceModal}
          className="bg-[#120e24] hover:bg-[#1a1433] border border-[#231b40] hover:border-amber-400/70 rounded-xl px-3 py-1.5 flex flex-col justify-center shadow cursor-pointer transition-all relative overflow-hidden group min-h-[44px] sm:min-h-[48px]"
        >
          <span className="text-[9px] sm:text-[10px] font-black text-slate-400 group-hover:text-amber-400 uppercase tracking-wider leading-none z-10">
            {language === 'TR' ? 'YÖNETİM GÜVENİ' : 'BOARD CONFIDENCE'}
          </span>

          <div className="flex items-baseline gap-2 z-10 mt-0.5">
            <span className="text-base sm:text-lg font-black text-amber-300 leading-none">%{boardConfidence}</span>
            <span className="text-[9px] sm:text-[10px] text-emerald-400 font-black">
              {boardConfidence >= 85 ? (language === 'TR' ? 'Tam Güven' : 'Full Trust') : boardConfidence >= 70 ? (language === 'TR' ? 'Güvende' : 'Safe') : (language === 'TR' ? 'İzleniyor' : 'Monitored')}
            </span>
          </div>

          {/* Enlarged Shield Watermark Graphic */}
          <div className="absolute -right-2 top-1/2 -translate-y-1/2 text-white/[0.09] group-hover:text-amber-400/20 transition-colors pointer-events-none">
            <svg viewBox="0 0 64 64" className="w-14 h-14 sm:w-16 sm:h-16 fill-none stroke-current stroke-[1.7]">
              <path d="M32 8 L50 14 V30 C50 44 32 54 32 54 C32 54 14 44 14 30 V14 Z" fill="currentColor" fillOpacity="0.04" />
              <circle cx="32" cy="30" r="8" fill="currentColor" fillOpacity="0.08" />
              <path d="M28 30 L31 33 L37 27" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>

        {/* Card 3: BUDGET (Coins Watermark) */}
        <div
          onClick={onOpenFinancesModal}
          className="bg-[#120e24] hover:bg-[#1a1433] border border-[#231b40] hover:border-sky-500/70 rounded-xl px-3 py-1.5 flex flex-col justify-center shadow cursor-pointer transition-all relative overflow-hidden group min-h-[44px] sm:min-h-[48px]"
        >
          <span className="text-[9px] sm:text-[10px] font-black text-slate-400 group-hover:text-sky-400 uppercase tracking-wider leading-none z-10">
            {language === 'TR' ? 'BÜTÇE' : 'BUDGET'}
          </span>

          <div className="flex items-baseline gap-2 z-10 mt-0.5">
            <span className="text-base sm:text-lg font-black text-sky-400 leading-none">€{(currentTeam.budget / 1_000_000).toFixed(1)}M</span>
            <span className="text-[9px] sm:text-[10px] text-slate-400 font-bold group-hover:text-sky-300 transition-colors">
              {language === 'TR' ? 'Finans' : 'Finances'} &rarr;
            </span>
          </div>

          {/* Enlarged Coins Watermark Graphic */}
          <div className="absolute -right-2 top-1/2 -translate-y-1/2 text-white/[0.09] group-hover:text-sky-400/20 transition-colors pointer-events-none">
            <svg viewBox="0 0 64 64" className="w-14 h-14 sm:w-16 sm:h-16 fill-none stroke-current stroke-[1.7]">
              <ellipse cx="26" cy="22" rx="14" ry="6" fill="currentColor" fillOpacity="0.04" />
              <path d="M12 22 V32 C12 35 18 38 26 38 C34 38 40 35 40 32 V22" />
              <path d="M12 32 V42 C12 45 18 48 26 48 C34 48 40 45 40 42 V32" />
              <ellipse cx="44" cy="18" rx="13" ry="5.5" fill="currentColor" fillOpacity="0.04" />
              <path d="M31 18 V28 C31 31 37 33.5 44 33.5 C51 33.5 57 31 57 28 V18" />
              <path d="M31 28 V38 C31 41 37 43.5 44 43.5 C51 43.5 57 41 57 38 V28" />
            </svg>
          </div>
        </div>

        {/* Card 4: SQUAD (Jersey Watermark) - Clicking opens Full Squad List modal */}
        <div
          onClick={() => onOpenFullSquadModal ? onOpenFullSquadModal() : onNavigateTab('SQUAD')}
          className="bg-[#120e24] hover:bg-[#1a1433] border border-[#231b40] hover:border-purple-500/70 rounded-xl px-3 py-1.5 flex flex-col justify-center shadow cursor-pointer transition-all relative overflow-hidden group min-h-[44px] sm:min-h-[48px]"
        >
          <div className="flex items-center justify-between z-10">
            <span className="text-[9px] sm:text-[10px] font-black text-purple-400 group-hover:text-purple-300 uppercase tracking-wider leading-none">
              {language === 'TR' ? 'TAKIM KADROSU' : 'TEAM SQUAD'}
            </span>
          </div>

          <div className="flex items-baseline gap-2 z-10 mt-0.5">
            <span className="text-base sm:text-lg font-black text-white leading-none">{currentTeam.players.length}</span>
            <span className="text-[9px] sm:text-[10px] text-slate-400 font-bold group-hover:text-purple-300 transition-colors">
              {language === 'TR' ? 'Kadro Listesini Gör' : 'View Squad List'} &rarr;
            </span>
          </div>

          {/* Enlarged Jersey #10 Watermark Graphic */}
          <div className="absolute -right-2 top-1/2 -translate-y-1/2 text-white/[0.09] group-hover:text-purple-400/20 transition-colors pointer-events-none">
            <svg viewBox="0 0 64 64" className="w-14 h-14 sm:w-16 sm:h-16 fill-none stroke-current stroke-[1.7]">
              <path d="M22 14 L12 22 L17 32 L22 28 V52 H42 V28 L47 32 L52 22 L42 14 C38 18 26 18 22 14 Z" fill="currentColor" fillOpacity="0.04" />
              <text x="32" y="39" textAnchor="middle" fill="currentColor" stroke="none" fontSize="14" fontWeight="900">10</text>
            </svg>
          </div>
        </div>

      </div>

      {/* 2. MAIN CENTER CARD: TEAM OVERVIEW & 2.5D TACTICAL PITCH (Clicking switches to TACTICS tab) */}
      <div className="bg-[#120e24] border border-[#231b40] rounded-2xl p-2.5 sm:p-3 shadow-xl flex-1 flex flex-col justify-center relative overflow-hidden min-h-0">
        
        {/* Main 2-Column Split: Left Side (Club Details & 3 Badges), Right Side (Crisp Vector Pitch) */}
        <div className="grid grid-cols-12 gap-2 sm:gap-3 items-center h-full min-h-0">
          
          {/* Left Column (5 cols, ~42% width) */}
          <div className="col-span-5 flex flex-col justify-between h-full py-0.5 gap-1 min-h-0">
            
            {/* Header with Club Badge and Title */}
            <div className="flex items-center gap-2 shrink-0">
              <TeamBadge
                team={currentTeam}
                size="sm"
                className="w-5 h-5 sm:w-5.5 sm:h-5.5 rounded shadow shrink-0"
              />
              <h3 className="text-[11px] sm:text-[12px] font-black text-white uppercase tracking-wider leading-tight">
                {language === 'TR' ? 'TAKIM GENEL BAKIŞ' : 'TEAM OVERVIEW'}
              </h3>
            </div>

            {/* Story Narrative Text - Full Team Names */}
            <div className="text-[9.5px] sm:text-[10px] text-slate-300 font-medium leading-snug shrink-0">
              <p className="leading-tight">
                {language === 'TR' ? 'Menajer ' : 'Manager '}
                <strong className="text-purple-300 font-bold">{managerName}</strong>
                {language === 'TR' ? ' önderliğinde ' : ' under leadership of '}
                <strong className="text-amber-300 font-bold">{currentTeam.name}</strong>
                {language === 'TR' ? ' kulübü,' : ' club,'}
              </p>
              <p className="text-slate-400 mt-0.5 leading-tight">
                {language === 'TR' ? `${currentSeason}. Sezon ${currentWeek}. Hafta devam ediyor. Rakip: ` : `Season ${currentSeason} Week ${currentWeek} season continues. Next Opponent: `}
                <strong className="text-emerald-400 font-bold">{opponentTeam.name}</strong>
              </p>
            </div>

            {/* 3 Status Items: Tactics (Clickable to Squad List), Team Chemistry, Fitness */}
            <div className="flex flex-col gap-1.5 shrink-0">
              
              {/* Status 1: SQUAD & TACTICS -> Opens Tactics & Lineup Screen */}
              <div 
                onClick={() => onNavigateTab('TACTICS')}
                className="flex items-center justify-between p-1 rounded-lg bg-[#0d2818]/60 hover:bg-[#0d2818] border border-[#1b6b38]/70 hover:border-emerald-400 cursor-pointer group transition-all"
                title={language === 'TR' ? 'Diziliş Ekranını Aç' : 'Open Formation & Tactics'}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-5 h-5 sm:w-5.5 sm:h-5.5 rounded-md bg-[#091a10] border border-[#1b6b38] flex items-center justify-center text-emerald-400 shrink-0 shadow-sm group-hover:scale-105 transition-transform">
                    <Brain className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-[7.5px] sm:text-[8px] font-extrabold text-slate-300 group-hover:text-emerald-400 uppercase tracking-wider block leading-none">
                      {language === 'TR' ? 'KADRO & DİZİLİŞ' : 'SQUAD & LINEUP'}
                    </span>
                    <span className="text-[9.5px] sm:text-[10px] font-bold text-white truncate block leading-none mt-0.5">
                      {currentTeam.formation} {currentTeam.tactic === 'ATTACKING' ? (language === 'TR' ? 'Hücum' : 'Attacking') : currentTeam.tactic === 'DEFENSIVE' ? (language === 'TR' ? 'Savunma' : 'Defensive') : (language === 'TR' ? 'Dengeli' : 'Balanced')}
                    </span>
                  </div>
                </div>
                <MoveUpRight className="w-3 h-3 text-emerald-400/70 group-hover:text-emerald-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform shrink-0 mr-1" />
              </div>

              {/* Status 2: TEAM CHEMISTRY */}
              <div className="flex items-center gap-2 group px-1">
                <div className="w-5 h-5 sm:w-5.5 sm:h-5.5 rounded-md bg-[#0b2432] border border-[#16607e] flex items-center justify-center text-cyan-400 shrink-0 shadow-sm group-hover:scale-105 transition-transform">
                  <FlaskConical className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                </div>
                <div className="min-w-0">
                  <span className="text-[7.5px] sm:text-[8px] font-extrabold text-slate-400 uppercase tracking-wider block leading-none">
                    {language === 'TR' ? 'TAKIM KİMYASI' : 'TEAM CHEMISTRY'}
                  </span>
                  <span className="text-[9.5px] sm:text-[10px] font-bold text-white truncate block leading-none mt-0.5">
                    {language === 'TR' ? 'İyi' : 'Good'}
                  </span>
                </div>
              </div>

              {/* Status 3: FITNESS */}
              <div className="flex items-center gap-2 group px-1">
                <div className="w-5 h-5 sm:w-5.5 sm:h-5.5 rounded-md bg-[#2b101c] border border-[#78233f] flex items-center justify-center text-rose-400 shrink-0 shadow-sm group-hover:scale-105 transition-transform">
                  <HeartPulse className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                </div>
                <div className="min-w-0">
                  <span className="text-[7.5px] sm:text-[8px] font-extrabold text-slate-400 uppercase tracking-wider block leading-none">
                    {language === 'TR' ? 'KONDİSYON' : 'FITNESS'}
                  </span>
                  <span className="text-[9.5px] sm:text-[10px] font-bold text-white truncate block leading-none mt-0.5">
                    {language === 'TR' ? 'Zirve Kondisyon' : 'Top Condition'}
                  </span>
                </div>
              </div>

            </div>

          </div>

          {/* Right Column (7 cols, ~58% width): Pixel-Perfect Crisp Vector Pitch */}
          {/* Entire pitch card is clickable to open Tactics & Lineup */}
          <div 
            onClick={() => onNavigateTab('TACTICS')}
            title={language === 'TR' ? 'Diziliş ekranını açmak için tıklayın' : 'Click to open formation & tactics'}
            className="col-span-7 flex justify-center items-center h-full min-h-0 overflow-visible relative cursor-pointer group"
          >
            
            {/* Crisp Pitch Stage Container - Clean Stadium Canvas without Neon Side Lines */}
            <div className="w-full max-w-[440px] h-[165px] sm:h-[180px] md:h-[195px] relative rounded-2xl overflow-hidden shadow-xl bg-[#0c1f13] border border-[#231b40] transition-all">
              
              {/* SVG Crisp High-DPI Perspective Pitch */}
              <svg 
                viewBox="0 0 400 240" 
                className="w-full h-full absolute inset-0 block select-none pointer-events-none"
                preserveAspectRatio="none"
              >
                <defs>
                  {/* Natural Tactical Pitch Turf Gradient (Matte, Deep, Professional Grass) */}
                  <linearGradient id="pitchGrassGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#145222" />
                    <stop offset="45%" stopColor="#175d27" />
                    <stop offset="100%" stopColor="#10451d" />
                  </linearGradient>

                  {/* Soft Floodlight Spotlight */}
                  <radialGradient id="stadiumSpotlight" cx="50%" cy="45%" r="55%">
                    <stop offset="0%" stopColor="#ffffff" stopOpacity="0.10" />
                    <stop offset="60%" stopColor="#ffffff" stopOpacity="0.02" />
                    <stop offset="100%" stopColor="#000000" stopOpacity="0.2" />
                  </radialGradient>
                </defs>

                {/* Main Angled Pitch Surface - No harsh stroke borders */}
                <polygon 
                  points="45,10 355,10 388,230 12,230" 
                  fill="url(#pitchGrassGrad)" 
                  stroke="none"
                />

                {/* Alternating Mowing Grass Stripes */}
                <g opacity="0.08">
                  <polygon points="45,10 355,10 359,38 41,38" fill="#ffffff" />
                  <polygon points="41,38 359,38 363,66 37,66" fill="#000000" />
                  <polygon points="37,66 363,66 368,96 32,96" fill="#ffffff" />
                  <polygon points="32,96 368,96 373,128 27,128" fill="#000000" />
                  <polygon points="27,128 373,128 378,162 22,162" fill="#ffffff" />
                  <polygon points="22,162 378,162 383,196 17,196" fill="#000000" />
                  <polygon points="17,196 383,196 388,230 12,230" fill="#ffffff" />
                </g>

                {/* Floodlight Spotlight Layer */}
                <polygon points="45,10 355,10 388,230 12,230" fill="url(#stadiumSpotlight)" />

                {/* Outer Boundary White Lines */}
                <polygon 
                  points="50,15 350,15 382,225 18,225" 
                  fill="none" 
                  stroke="rgba(255,255,255,0.72)" 
                  strokeWidth="1.6" 
                />

                {/* Halfway Line */}
                <line x1="34" y1="120" x2="366" y2="120" stroke="rgba(255,255,255,0.72)" strokeWidth="1.6" />

                {/* Center Circle & Spot */}
                <ellipse cx="200" cy="120" rx="46" ry="26" fill="none" stroke="rgba(255,255,255,0.72)" strokeWidth="1.6" />
                <circle cx="200" cy="120" r="2.2" fill="rgba(255,255,255,0.9)" />

                {/* Far (Top) Goal & Net */}
                <polygon points="172,4 228,4 228,10 172,10" fill="none" stroke="rgba(255,255,255,0.85)" strokeWidth="1.6" />
                <polygon points="174,4 226,4 228,10 172,10" fill="rgba(255,255,255,0.15)" />

                {/* Far (Top) Penalty Box */}
                <polygon points="125,15 275,15 282,52 118,52" fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth="1.5" />
                {/* Far 6-yard Box */}
                <polygon points="160,15 240,15 244,28 156,28" fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth="1.3" />
                {/* Far Penalty Arc */}
                <path d="M 172 52 A 30 14 0 0 0 228 52" fill="none" stroke="rgba(255,255,255,0.65)" strokeWidth="1.3" />

                {/* Near (Bottom) Penalty Box */}
                <polygon points="110,188 290,188 300,225 100,225" fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth="1.5" />
                {/* Near 6-yard Box */}
                <polygon points="148,206 252,206 258,225 142,225" fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth="1.3" />
                {/* Near Penalty Arc */}
                <path d="M 168 188 A 34 16 0 0 1 232 188" fill="none" stroke="rgba(255,255,255,0.65)" strokeWidth="1.3" />

                {/* Near (Bottom) Goal & Net */}
                <polygon points="165,225 235,225 235,233 165,233" fill="none" stroke="rgba(255,255,255,0.85)" strokeWidth="1.6" />
                <polygon points="166,225 234,225 235,233 165,233" fill="rgba(255,255,255,0.15)" />

                {/* Corner Arcs */}
                <path d="M 50 24 A 9 6 0 0 0 59 15" fill="none" stroke="rgba(255,255,255,0.65)" strokeWidth="1.3" />
                <path d="M 350 24 A 9 6 0 0 1 341 15" fill="none" stroke="rgba(255,255,255,0.65)" strokeWidth="1.3" />
                <path d="M 18 214 A 12 8 0 0 1 30 225" fill="none" stroke="rgba(255,255,255,0.65)" strokeWidth="1.3" />
                <path d="M 382 214 A 12 8 0 0 0 370 225" fill="none" stroke="rgba(255,255,255,0.65)" strokeWidth="1.3" />
              </svg>

              {/* 11 Players Crisp 2D Overlay - Static (No hover wobble/jiggle) */}
              {starting11.map((p, idx) => {
                const coords = getPitchCoords(idx, currentTeam.formation);
                const shirtNum = getShirtNumber(p, idx);
                const lName = p ? getLastName(p.name) : (language === 'TR' ? 'BOŞ' : 'EMPTY');
                const isGk = idx === 0;
                const isEmpty = !p;

                return (
                  <div
                    key={p ? p.id : `empty-${idx}`}
                    style={{ 
                      top: coords.top, 
                      left: coords.left,
                      transform: 'translate(-50%, -50%)'
                    }}
                    className="absolute flex flex-col items-center z-10 pointer-events-none"
                  >
                    {/* Vibrant 3D Jersey Shape */}
                    <SoccerJersey
                      number={shirtNum}
                      color={kitDetails.primary}
                      secondaryColor={kitDetails.secondary}
                      isGk={isGk}
                      isEmpty={isEmpty}
                      className="w-5 h-5 sm:w-5.5 sm:h-5.5"
                    />

                    {/* Razor Sharp High-Resolution Player Name Tag */}
                    <span 
                      className={`text-[7.5px] sm:text-[8px] font-black uppercase tracking-tight px-1.5 py-[0.5px] rounded -mt-0.5 whitespace-nowrap leading-none text-center ${
                        isEmpty 
                          ? 'text-slate-400 bg-[#0e0a1e]/90 border border-dashed border-white/30' 
                          : 'text-white bg-[#0e0a1e]/85 border border-white/30 shadow-md'
                      }`}
                      style={{
                        letterSpacing: '-0.2px'
                      }}
                    >
                      {lName}
                    </span>
                  </div>
                );
              })}

            </div>

          </div>

        </div>

      </div>

      {/* 3. MATCH FIXTURE CARD (Cleanly Separated Bottom Bar) */}
      <div className="bg-[#120e24] border border-[#231b40] rounded-xl px-3 py-1.5 sm:py-2 flex items-center justify-between gap-2 shadow-lg shrink-0 min-h-[42px] sm:min-h-[46px]">
        
        <div className="flex items-center gap-2 min-w-0">
          {/* Week Badge */}
          <div className="w-5.5 h-5.5 sm:w-6 sm:h-6 rounded-lg bg-[#1a1233] border border-purple-500/40 flex items-center justify-center text-purple-300 font-black text-[9.5px] sm:text-[10px] shrink-0 shadow">
            {currentWeek}W
          </div>

          {/* Team Badges & Match Title */}
          <div className="flex items-center gap-1.5 min-w-0">
            <TeamBadge team={currentTeam} size="sm" className="w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0" />
            
            <div className="min-w-0">
              <h4 className="text-[10.5px] sm:text-[11.5px] font-extrabold text-white truncate leading-tight">
                {currentTeam.name} <span className="text-purple-400 font-normal">vs</span> {opponentTeam.name}
              </h4>
              <span className="text-[8px] sm:text-[8.5px] text-slate-400 block truncate leading-none mt-0.5">
                {isHomeMatch ? (language === 'TR' ? 'Ev Sahibi' : 'Home') : (language === 'TR' ? 'Deplasman' : 'Away')} • {currentTeam.stadiumName || 'Etihad Stadium'}
              </span>
            </div>

            <TeamBadge team={opponentTeam} size="sm" className="w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0" />
          </div>
        </div>

        {/* Right Compare & Analyze Button */}
        <button
          type="button"
          onClick={onOpenMatchComparison}
          className="px-2.5 sm:px-3.5 py-1 bg-gradient-to-r from-purple-700 to-indigo-600 hover:from-purple-600 hover:to-indigo-500 text-white font-extrabold text-[9.5px] sm:text-[10.5px] rounded-xl shadow-md hover:shadow-purple-700/30 flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-95 shrink-0"
        >
          <BarChart3 className="w-3 h-3" />
          <span>{language === 'TR' ? 'Karşılaştır & Analiz Et' : 'Compare & Analyze'} &rarr;</span>
        </button>

      </div>

      {/* 4. GO ON VACATION (TATİLE ÇIK) FULL FEATURED CARD */}
      <div className="bg-[#120e24] border border-[#231b40] hover:border-amber-500/40 rounded-2xl p-3 sm:p-3.5 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 transition-all relative overflow-hidden group">
        <div className="flex items-center gap-3 z-10 min-w-0">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-600/20 border border-amber-500/40 flex items-center justify-center text-amber-300 shrink-0 shadow-md group-hover:scale-105 transition-transform">
            <Palmtree className="w-5 h-5 sm:w-5.5 sm:h-5.5" />
          </div>
          
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h4 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider">
                {language === 'TR' ? 'TATİLE ÇIK (ASİSTAN MENAJER)' : 'GO ON VACATION (ASSISTANT MANAGER)'}
              </h4>
              <span className="px-2 py-0.5 text-[8.5px] sm:text-[9px] font-black bg-amber-500/15 border border-amber-500/30 text-amber-300 rounded-full">
                {language === 'TR' ? 'Otomatik Simülasyon' : 'Auto Simulation'}
              </span>
            </div>
            <p className="text-[10px] sm:text-[10.5px] text-slate-300 font-medium leading-tight mt-0.5">
              {language === 'TR' 
                ? 'Belirli bir tarihe kadar lig maçlarını ve takımı asistan menajere devrederek takvimi otomatik simüle edin.'
                : 'Delegate matches and squad duties to your assistant manager and automatically advance the calendar.'}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenVacationModal}
          className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-black text-xs rounded-xl shadow-lg hover:shadow-amber-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 shrink-0 z-10"
        >
          <Palmtree className="w-3.5 h-3.5" />
          <span>{language === 'TR' ? 'Tatile Çık' : 'Go on Vacation'} &rarr;</span>
        </button>

        {/* Subtle Palmtree Background Watermark */}
        <div className="absolute -right-2 -bottom-2 text-white/[0.03] group-hover:text-amber-500/[0.06] transition-colors pointer-events-none">
          <Palmtree className="w-24 h-24 stroke-[1]" />
        </div>
      </div>

    </div>
  );
};
