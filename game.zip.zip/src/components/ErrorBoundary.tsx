import React, { ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  state: State = {
    hasError: false,
    error: null,
  };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Unhandled UI Exception caught by ErrorBoundary:', error, errorInfo);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen w-full bg-[#0b0819] text-white flex flex-col items-center justify-center p-4">
          <div className="max-w-md w-full bg-[#150f2a] border border-purple-500/30 rounded-2xl p-6 shadow-2xl text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center">
              <AlertTriangle className="w-8 h-8 text-rose-400" />
            </div>
            
            <h2 className="text-xl font-black text-white">Sistem Kurtarma Modu</h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Geçici bir arayüz hatası tespit edildi. Oyun verileriniz korundu. Aşağıdaki butona tıklayarak oyunu hemen devam ettirebilirsiniz.
            </p>

            {this.state.error && (
              <div className="bg-[#0e0a1c] border border-slate-800 rounded-lg p-2 text-left font-mono text-[10px] text-rose-300 overflow-x-auto max-h-24">
                {this.state.error.message}
              </div>
            )}

            <button
              onClick={this.handleReset}
              className="w-full py-3 px-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-extrabold text-sm rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-purple-900/30 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4 animate-spin-slow" />
              Sistemi Yeniden Başlat ve Devam Et
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
