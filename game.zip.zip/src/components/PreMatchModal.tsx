import React, { useState } from 'react';
import { useTranslation } from '../utils/i18n';
import { Team, ManagerProfile, Player, FormationType } from '../types';
import { 
  Play, Settings, Shield, User, Trophy, Sparkles, ChevronLeft, X, Eye, 
  Target, Crosshair, Plus, Trash2, CheckCircle2, Sliders, Activity, Zap, 
  Compass, BarChart3, AlertCircle, Sun, CloudRain, Wind, Users, Award, 
  Flame, ArrowRight, Check, MapPin, Calendar, Clock, CloudSun, ExternalLink
} from 'lucide-react';
import { TeamBadge } from './TeamBadge';
import { getSimulatedRealDate } from '../utils/dateHelper';

interface PreMatchModalProps {
  isOpen?: boolean;
  homeTeam?: Team;
  awayTeam?: Team;
  currentTeam?: Team;
  opponentTeam?: Team;
  manager: ManagerProfile;
  currentWeek: number;
  currentSeason?: number;
  allTeams?: Team[];
  onStartMatch: (isQuickSim?: boolean) => void;
  onEditTactics: () => void;
  onClose: () => void;
  onOpenPlayerProfile?: (player: Player, team?: Team) => void;
  onOpenTeamModal?: (team: Team) => void;
}

export const PreMatchModal: React.FC<PreMatchModalProps> = ({
  homeTeam,
  awayTeam,
  currentTeam: propsCurrentTeam,
  opponentTeam: propsOpponentTeam,
  manager,
  currentWeek,
  currentSeason = 1,
  allTeams = [],
  onStartMatch,
  onEditTactics,
  onClose,
  onOpenPlayerProfile,
  onOpenTeamModal
}) => {
  const { t, language } = useTranslation();
  const isTr = (language || 'TR').toUpperCase() === 'TR';

  const getLocalizedText = (tr: string, en: string, es: string, fr: string, it: string, de: string, pt: string) => {
    const lang = (language || 'TR').toUpperCase();
    if (lang === 'EN') return en;
    if (lang === 'ES') return es;
    if (lang === 'FR') return fr;
    if (lang === 'IT') return it;
    if (lang === 'DE') return de;
    if (lang === 'PT') return pt;
    return tr;
  };

  // Navigation Tabs matching bottom bar
  const [activeBottomTab, setActiveBottomTab] = useState<'OVERVIEW' | 'OPPONENT_ANALYSIS' | 'COMPARISON'>('OVERVIEW');
  
  // Sub-modal states for action cards
  const [activeSubModal, setActiveSubModal] = useState<'INSTRUCTIONS' | 'SCOUT_REPORT' | 'MATCH_DETAILS' | null>(null);

  // Quick tactics adjustment state
  const [selectedFormation, setSelectedFormation] = useState<FormationType>('4-2-3-1');
  const [selectedMentality, setSelectedMentality] = useState<'HÜCUM' | 'DENGELİ' | 'SAVUNMA' | 'KONTRA'>('DENGELİ');
  const [selectedPressing, setSelectedPressing] = useState<'YÜKSEK' | 'STANDART' | 'GERİDE'>('STANDART');

  // Individual player marking state inside Opponent Analysis
  const [markedPlayerIds, setMarkedPlayerIds] = useState<string[]>(() => {
    return (propsCurrentTeam as any)?.tactics?.markedPlayerIds || (propsCurrentTeam as any)?.tacticalDetails?.markedPlayerIds || [];
  });
  const [markingType, setMarkingType] = useState<Record<string, 'TIGHT' | 'DOUBLE' | 'PRESS'>>(() => {
    return ((propsCurrentTeam as any)?.tactics?.markingType as any) || ((propsCurrentTeam as any)?.tacticalDetails?.markingType as any) || {};
  });

  // Toggle mark on opponent player
  const toggleMarkPlayer = (playerId: string) => {
    setMarkedPlayerIds(prev => {
      const next = prev.includes(playerId) ? prev.filter(id => id !== playerId) : [...prev, playerId];
      if ((propsCurrentTeam as any)?.tactics) {
        (propsCurrentTeam as any).tactics.markedPlayerIds = next;
      }
      return next;
    });
    if (!markingType[playerId]) {
      setMarkingType(prev => {
        const next = { ...prev, [playerId]: 'TIGHT' as const };
        if ((propsCurrentTeam as any)?.tactics) {
          (propsCurrentTeam as any).tactics.markingType = next;
        }
        return next;
      });
    }
  };

  const handleSetMarkingType = (playerId: string, type: 'TIGHT' | 'DOUBLE' | 'PRESS') => {
    setMarkingType(prev => {
      const next = { ...prev, [playerId]: type };
      if ((propsCurrentTeam as any)?.tactics) {
        (propsCurrentTeam as any).tactics.markingType = next;
      }
      return next;
    });
  };

  // Freeze Home and Away teams on mount
  const [frozenTeams] = useState(() => ({
    first: homeTeam || propsCurrentTeam,
    second: awayTeam || propsOpponentTeam
  }));

  const firstTeam = frozenTeams.first;
  const secondTeam = frozenTeams.second;

  if (!firstTeam || !secondTeam) {
    return null;
  }

  // Extract starting 11 for both teams matching TacticalPitch slot structure
  const getStarting11 = (team: Team): (Player | null)[] => {
    const slots: (Player | null)[] = new Array(11).fill(null);
    const assignedIds = new Set<string>();

    // 1. Assign players with explicit starterIndex (0..10)
    (team.players || []).forEach(p => {
      if (p.isStarting && p.starterIndex !== undefined && p.starterIndex >= 0 && p.starterIndex < 11) {
        if (!slots[p.starterIndex]) {
          slots[p.starterIndex] = p;
          assignedIds.add(p.id);
        }
      }
    });

    // 2. Assign other starting players to empty slots
    (team.players || []).forEach(p => {
      if (p.isStarting && !assignedIds.has(p.id)) {
        const nextEmpty = slots.findIndex(s => s === null);
        if (nextEmpty !== -1) {
          slots[nextEmpty] = p;
          assignedIds.add(p.id);
        }
      }
    });

    // 3. Fallback: if fewer than 11 starters are marked, fill remaining slots from squad
    if (slots.some(s => s === null)) {
      (team.players || []).forEach(p => {
        if (!assignedIds.has(p.id)) {
          const nextEmpty = slots.findIndex(s => s === null);
          if (nextEmpty !== -1) {
            slots[nextEmpty] = p;
            assignedIds.add(p.id);
          }
        }
      });
    }

    return slots;
  };

  const getBenchPlayers = (team: Team): Player[] => {
    const starters = getStarting11(team).filter((p): p is Player => p !== null);
    const starterIds = new Set(starters.map(p => p.id));
    const nonStarters = (team.players || []).filter(p => !starterIds.has(p.id));
    return nonStarters.slice(0, 7);
  };

  const homeStarters = getStarting11(firstTeam);
  const awayStarters = getStarting11(secondTeam);

  const homeBench = getBenchPlayers(firstTeam);
  const awayBench = getBenchPlayers(secondTeam);

  // Dynamic League Name
  const getLeagueName = (team: Team): string => {
    const c = (team.country || '').toLowerCase();
    const n = (team.name || '').toLowerCase();
    if (
      c.includes('ingiltere') || c.includes('england') || c.includes('united kingdom') || c.includes('uk') ||
      n.includes('arsenal') || n.includes('chelsea') || n.includes('liverpool') || n.includes('city') ||
      n.includes('united') || n.includes('tottenham') || n.includes('aston villa') || n.includes('newcastle') ||
      n.includes('brighton') || n.includes('everton') || n.includes('wolves') || n.includes('fulham') ||
      n.includes('west ham') || n.includes('brentford') || n.includes('palace') || n.includes('nottingham') ||
      n.includes('bournemouth') || n.includes('leicester') || n.includes('ipswich') || n.includes('southampton')
    ) {
      return 'Premier Lig';
    }
    if (c.includes('ispanya') || c.includes('spain') || n.includes('madrid') || n.includes('barcelona') || n.includes('sevilla') || n.includes('betis') || n.includes('valencia') || n.includes('sociedad') || n.includes('bilbao') || n.includes('villarreal')) {
      return 'La Liga';
    }
    if (c.includes('almanya') || c.includes('germany') || n.includes('bayern') || n.includes('dortmund') || n.includes('leipzig') || n.includes('leverkusen') || n.includes('frankfurt') || n.includes('stuttgart')) {
      return 'Bundesliga';
    }
    if (c.includes('italya') || c.includes('italy') || n.includes('milan') || n.includes('juventus') || n.includes('inter') || n.includes('napoli') || n.includes('roma') || n.includes('lazio') || n.includes('atalanta') || n.includes('fiorentina')) {
      return 'Serie A';
    }
    if (c.includes('fransa') || c.includes('france') || n.includes('paris') || n.includes('psg') || n.includes('marseille') || n.includes('monaco') || n.includes('lyon') || n.includes('lille') || n.includes('nice') || n.includes('rennes')) {
      return 'Ligue 1';
    }
    if (c.includes('hollanda') || c.includes('netherlands') || n.includes('ajax') || n.includes('psv') || n.includes('feyenoord')) {
      return 'Eredivisie';
    }
    if (c.includes('portekiz') || c.includes('portugal') || n.includes('benfica') || n.includes('porto') || n.includes('sporting') || n.includes('braga')) {
      return 'Liga Portugal';
    }
    return 'Trendyol Süper Lig';
  };

  const currentLeagueName = getLeagueName(firstTeam);

  // Calculate team overall ratings accurately based on starting 11 and team rating
  const getTeamOvr = (team: Team, starters: (Player | null)[]) => {
    const rawOvr = team.overall || (team as any).rating;
    if (rawOvr && rawOvr > 0) return rawOvr;
    const validStarters = starters.filter((p): p is Player => p !== null);
    if (validStarters.length === 0) return 75;
    const avg = Math.round(validStarters.reduce((acc, p) => acc + (p.overall || 75), 0) / validStarters.length);
    return avg;
  };

  const homeOvr = getTeamOvr(firstTeam, homeStarters);
  const awayOvr = getTeamOvr(secondTeam, awayStarters);

  // Dynamic stadium names mapping
  const getTeamStadium = (team: Team): { name: string; capacity: string; city: string; pitchType: string } => {
    const n = (team.name || '').toLowerCase();
    const c = team.country || 'Türkiye';

    // English teams
    if (n.includes('arsenal')) return { name: 'Emirates Stadium', capacity: '60.704', city: 'Londra', pitchType: 'Hibrit Çim' };
    if (n.includes('manchester city')) return { name: 'Etihad Stadium', capacity: '53.400', city: 'Manchester', pitchType: 'Hibrit Çim' };
    if (n.includes('manchester united')) return { name: 'Old Trafford', capacity: '74.310', city: 'Manchester', pitchType: 'Hibrit Çim' };
    if (n.includes('liverpool')) return { name: 'Anfield', capacity: '61.276', city: 'Liverpool', pitchType: 'Hibrit Çim' };
    if (n.includes('chelsea')) return { name: 'Stamford Bridge', capacity: '40.341', city: 'Londra', pitchType: 'Hibrit Çim' };
    if (n.includes('tottenham')) return { name: 'Tottenham Hotspur Stadium', capacity: '62.850', city: 'Londra', pitchType: 'Hibrit Çim' };
    if (n.includes('aston villa')) return { name: 'Villa Park', capacity: '42.640', city: 'Birmingham', pitchType: 'Hibrit Çim' };
    if (n.includes('newcastle')) return { name: "St. James' Park", capacity: '52.305', city: 'Newcastle', pitchType: 'Hibrit Çim' };
    
    // Spanish teams
    if (n.includes('real madrid')) return { name: 'Santiago Bernabéu', capacity: '81.044', city: 'Madrid', pitchType: 'Hibrit Çim' };
    if (n.includes('barcelona')) return { name: 'Spotify Camp Nou', capacity: '99.354', city: 'Barselona', pitchType: 'Hibrit Çim' };
    if (n.includes('atletico') || n.includes('atlético')) return { name: 'Cívitas Metropolitano', capacity: '70.460', city: 'Madrid', pitchType: 'Hibrit Çim' };

    // German teams
    if (n.includes('bayern')) return { name: 'Allianz Arena', capacity: '75.024', city: 'Münih', pitchType: 'Hibrit Çim' };
    if (n.includes('dortmund')) return { name: 'Signal Iduna Park', capacity: '81.365', city: 'Dortmund', pitchType: 'Hibrit Çim' };

    // Italian teams
    if (n.includes('inter') || n.includes('milan')) return { name: 'San Siro', capacity: '75.817', city: 'Milano', pitchType: 'Hibrit Çim' };
    if (n.includes('juventus')) return { name: 'Allianz Stadium', capacity: '41.507', city: 'Torino', pitchType: 'Hibrit Çim' };

    // French teams
    if (n.includes('psg') || n.includes('paris')) return { name: 'Parc des Princes', capacity: '47.929', city: 'Paris', pitchType: 'Hibrit Çim' };

    // Turkish Süper Lig teams
    if (n.includes('galatasaray')) return { name: 'RAMS Park', capacity: '52.280', city: 'İstanbul', pitchType: 'Hibrit Çim' };
    if (n.includes('fenerbahçe') || n.includes('fenerbahce')) return { name: 'Ülker Stadyumu Şükrü Saracoğlu', capacity: '50.530', city: 'İstanbul', pitchType: 'Hibrit Çim' };
    if (n.includes('beşiktaş') || n.includes('besiktas')) return { name: 'Tüpraş Stadyumu', capacity: '42.590', city: 'İstanbul', pitchType: 'Hibrit Çim' };
    if (n.includes('trabzon')) return { name: 'Papara Park', capacity: '40.782', city: 'Trabzon', pitchType: 'Hibrit Çim' };
    if (n.includes('başakşehir') || n.includes('basaksehir')) return { name: 'Başakşehir Fatih Terim Stadyumu', capacity: '17.300', city: 'İstanbul', pitchType: 'Doğal Çim' };
    if (n.includes('samsun')) return { name: 'Samsun 19 Mayıs Stadyumu', capacity: '33.919', city: 'Samsun', pitchType: 'Doğal Çim' };
    if (n.includes('göztepe') || n.includes('goztepe')) return { name: 'Gürsel Aksel Stadyumu', capacity: '20.040', city: 'İzmir', pitchType: 'Hibrit Çim' };
    if (n.includes('eyüp') || n.includes('eyup')) return { name: 'Eyüp Stadyumu', capacity: '2.500', city: 'İstanbul', pitchType: 'Doğal Çim' };
    if (n.includes('konya')) return { name: 'Medaş Konya Büyükşehir Stadyumu', capacity: '42.000', city: 'Konya', pitchType: 'Hibrit Çim' };
    if (n.includes('sivas')) return { name: 'BG Grup 4 Eylül Stadyumu', capacity: '27.532', city: 'Sivas', pitchType: 'Doğal Çim' };
    if (n.includes('antalya')) return { name: 'Corendon Airlines Park', capacity: '32.537', city: 'Antalya', pitchType: 'Doğal Çim' };
    if (n.includes('kasımpaşa') || n.includes('kasimpasa')) return { name: 'Recep Tayyip Erdoğan Stadyumu', capacity: '14.234', city: 'İstanbul', pitchType: 'Doğal Çim' };
    if (n.includes('alanya')) return { name: 'GAİN Park Stadyumu', capacity: '10.128', city: 'Alanya', pitchType: 'Doğal Çim' };
    if (n.includes('rize')) return { name: 'Çaykur Didi Stadyumu', capacity: '15.558', city: 'Rize', pitchType: 'Doğal Çim' };
    if (n.includes('gaziantep')) return { name: 'Kalyon Stadyumu', capacity: '33.502', city: 'Gaziantep', pitchType: 'Doğal Çim' };
    if (n.includes('kayseri')) return { name: 'RHG Enertürk Enerji Stadyumu', capacity: '32.864', city: 'Kayseri', pitchType: 'Doğal Çim' };
    if (n.includes('hatay')) return { name: 'Mersin Stadyumu', capacity: '25.000', city: 'Mersin', pitchType: 'Doğal Çim' };
    if (n.includes('bodrum')) return { name: 'Bodrum İlçe Stadyumu', capacity: '4.563', city: 'Bodrum', pitchType: 'Doğal Çim' };
    if (n.includes('adana demir')) return { name: 'Yeni Adana Stadyumu', capacity: '33.543', city: 'Adana', pitchType: 'Doğal Çim' };
    if (n.includes('gençlerbirliği') || n.includes('genclerbirligi')) return { name: 'Eryaman Stadyumu', capacity: '20.560', city: 'Ankara', pitchType: 'Hibrit Çim' };
    if (n.includes('ankaragücü') || n.includes('ankaragucu')) return { name: 'Eryaman Stadyumu', capacity: '20.560', city: 'Ankara', pitchType: 'Hibrit Çim' };
    
    return { name: `${team.name} Stadyumu`, capacity: '35.000', city: c, pitchType: 'Hibrit Çim' };
  };

  const stadiumInfo = getTeamStadium(firstTeam);

  // Dynamic match form calculation:
  // If first match of the season (currentWeek <= 1), form is empty!
  // After matches played, shows recent match results (e.g. at match 5, shows matches 2-3-4).
  const getDynamicTeamForm3 = (team: Team): ('G' | 'B' | 'M')[] => {
    if (currentWeek <= 1) {
      return [];
    }
    const anyTeam = team as any;
    if (anyTeam.form && Array.isArray(anyTeam.form) && anyTeam.form.length > 0) {
      return anyTeam.form.slice(-3) as ('G' | 'B' | 'M')[];
    }
    const won = anyTeam.won ?? 0;
    const drawn = anyTeam.drawn ?? 0;
    const lost = anyTeam.lost ?? 0;
    const total = won + drawn + lost;
    if (total === 0) return [];
    
    // Generate slice based on matches played
    const resList: ('G' | 'B' | 'M')[] = [];
    for (let i = 0; i < won; i++) resList.push('G');
    for (let i = 0; i < drawn; i++) resList.push('B');
    for (let i = 0; i < lost; i++) resList.push('M');
    return resList.slice(-3);
  };

  const homeTrend = getDynamicTeamForm3(firstTeam);
  const awayTrend = getDynamicTeamForm3(secondTeam);

  // Simulated date
  const realDateObj = getSimulatedRealDate(currentSeason, currentWeek, 4, language);
  const simDateStr = realDateObj.dateStr;

  // Surname / Single name formatting helper
  const getLastName = (fullName: string): string => {
    if (!fullName) return '';
    const trimmed = fullName.trim();
    if (trimmed.includes('-')) {
      const parts = trimmed.split('-');
      return parts[parts.length - 1].trim();
    }
    const parts = trimmed.split(' ');
    return parts[parts.length - 1] || trimmed;
  };

  // Jersey number helper
  const getShirtNumber = (player: Player, index: number): number => {
    if (player.number) return player.number;
    const nameLower = player.name.toLowerCase();
    if (nameLower.includes('osimhen') || nameLower.includes('icardi') || nameLower.includes('džeko') || nameLower.includes('immobile')) return 9;
    if (nameLower.includes('mertens') || nameLower.includes('tadić') || nameLower.includes('rafa')) return 10;
    if (nameLower.includes('sara') || nameLower.includes('ziyech') || nameLower.includes('kerem')) return 7;
    if (nameLower.includes('torreira') || nameLower.includes('amrabat')) return 34;
    if (nameLower.includes('muslera') || nameLower.includes('livaković') || nameLower.includes('günok')) return 1;
    return index + 1;
  };

  // Formation coordinates matching TacticalPitch exactly (% top, % left)
  const getPitchCoords = (index: number, formation: FormationType = '4-2-3-1') => {
    if (index === 0) return { top: '88%', left: '50%' };

    switch (formation) {
      case '4-2-3-1':
        if (index === 1) return { top: '70%', left: '16%' };
        if (index === 2) return { top: '72%', left: '38%' };
        if (index === 3) return { top: '72%', left: '62%' };
        if (index === 4) return { top: '70%', left: '84%' };
        if (index === 5) return { top: '53%', left: '35%' };
        if (index === 6) return { top: '53%', left: '65%' };
        if (index === 7) return { top: '32%', left: '18%' };
        if (index === 8) return { top: '32%', left: '50%' };
        if (index === 9) return { top: '32%', left: '82%' };
        if (index === 10) return { top: '12%', left: '50%' };
        break;

      case '4-3-3':
        if (index === 1) return { top: '70%', left: '16%' };
        if (index === 2) return { top: '72%', left: '38%' };
        if (index === 3) return { top: '72%', left: '62%' };
        if (index === 4) return { top: '70%', left: '84%' };
        if (index === 5) return { top: '52%', left: '28%' };
        if (index === 6) return { top: '54%', left: '50%' };
        if (index === 7) return { top: '52%', left: '72%' };
        if (index === 8) return { top: '22%', left: '20%' };
        if (index === 9) return { top: '12%', left: '50%' };
        if (index === 10) return { top: '22%', left: '80%' };
        break;

      case '4-4-2':
        if (index === 1) return { top: '70%', left: '16%' };
        if (index === 2) return { top: '72%', left: '38%' };
        if (index === 3) return { top: '72%', left: '62%' };
        if (index === 4) return { top: '70%', left: '84%' };
        if (index === 5) return { top: '48%', left: '18%' };
        if (index === 6) return { top: '50%', left: '38%' };
        if (index === 7) return { top: '50%', left: '62%' };
        if (index === 8) return { top: '48%', left: '82%' };
        if (index === 9) return { top: '14%', left: '36%' };
        if (index === 10) return { top: '14%', left: '64%' };
        break;

      case '3-5-2':
        if (index === 1) return { top: '72%', left: '25%' };
        if (index === 2) return { top: '74%', left: '50%' };
        if (index === 3) return { top: '72%', left: '75%' };
        if (index === 4) return { top: '48%', left: '15%' };
        if (index === 5) return { top: '52%', left: '35%' };
        if (index === 6) return { top: '34%', left: '50%' };
        if (index === 7) return { top: '52%', left: '65%' };
        if (index === 8) return { top: '48%', left: '85%' };
        if (index === 9) return { top: '14%', left: '36%' };
        if (index === 10) return { top: '14%', left: '64%' };
        break;

      case '5-3-2':
        if (index === 1) return { top: '68%', left: '14%' };
        if (index === 2) return { top: '72%', left: '32%' };
        if (index === 3) return { top: '74%', left: '50%' };
        if (index === 4) return { top: '72%', left: '68%' };
        if (index === 5) return { top: '68%', left: '86%' };
        if (index === 6) return { top: '46%', left: '30%' };
        if (index === 7) return { top: '50%', left: '50%' };
        if (index === 8) return { top: '46%', left: '70%' };
        if (index === 9) return { top: '12%', left: '36%' };
        if (index === 10) return { top: '12%', left: '64%' };
        break;

      case '4-1-4-1':
        if (index === 1) return { top: '70%', left: '15%' };
        if (index === 2) return { top: '72%', left: '37%' };
        if (index === 3) return { top: '72%', left: '63%' };
        if (index === 4) return { top: '70%', left: '85%' };
        if (index === 5) return { top: '54%', left: '50%' };
        if (index === 6) return { top: '34%', left: '18%' };
        if (index === 7) return { top: '34%', left: '38%' };
        if (index === 8) return { top: '34%', left: '62%' };
        if (index === 9) return { top: '34%', left: '82%' };
        if (index === 10) return { top: '11%', left: '50%' };
        break;

      case '3-4-3':
        if (index === 1) return { top: '72%', left: '25%' };
        if (index === 2) return { top: '74%', left: '50%' };
        if (index === 3) return { top: '72%', left: '75%' };
        if (index === 4) return { top: '48%', left: '15%' };
        if (index === 5) return { top: '50%', left: '38%' };
        if (index === 6) return { top: '50%', left: '62%' };
        if (index === 7) return { top: '48%', left: '85%' };
        if (index === 8) return { top: '18%', left: '20%' };
        if (index === 9) return { top: '11%', left: '50%' };
        if (index === 10) return { top: '18%', left: '80%' };
        break;

      default:
        if (index === 1) return { top: '70%', left: '16%' };
        if (index === 2) return { top: '72%', left: '38%' };
        if (index === 3) return { top: '72%', left: '62%' };
        if (index === 4) return { top: '70%', left: '84%' };
        if (index === 5) return { top: '53%', left: '35%' };
        if (index === 6) return { top: '53%', left: '65%' };
        if (index === 7) return { top: '32%', left: '18%' };
        if (index === 8) return { top: '32%', left: '50%' };
        if (index === 9) return { top: '32%', left: '82%' };
        if (index === 10) return { top: '12%', left: '50%' };
        break;
    }
    return { top: '50%', left: '50%' };
  };

  // Top Key Players (Select best stars from both teams)
  const homeKeyPlayer = [...firstTeam.players].sort((a, b) => (b.overall || 75) - (a.overall || 75))[0] || homeStarters[0];
  const awayKeyPlayer = [...secondTeam.players].sort((a, b) => (b.overall || 75) - (a.overall || 75))[0] || awayStarters[0];

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#080514] text-white h-screen max-h-screen overflow-hidden select-none animate-in fade-in duration-200">
      
      {/* 1. TOP HEADER BAR */}
      <header className="shrink-0 bg-[#0c081e]/95 backdrop-blur-md border-b border-[#291e4b] px-3 sm:px-6 py-2 flex items-center justify-between shadow-xl">
        
        {/* Left: Back Button & Title */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          <button
            type="button"
            onClick={onClose}
            title={getLocalizedText('Geri Dön', 'Go Back', 'Volver', 'Retour', 'Indietro', 'Zurück', 'Voltar')}
            className="w-8 h-8 rounded-xl bg-[#1d1538] hover:bg-[#2d2157] text-slate-300 hover:text-white border border-[#3b2c6d] flex items-center justify-center transition-all cursor-pointer shadow"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          
          <h1 className="font-black text-xs sm:text-base text-white uppercase tracking-wider">
            {getLocalizedText('MAÇ ÖNCESİ HAZIRLIK', 'PRE-MATCH PREPARATION', 'PREPARACIÓN PREVIA AL PARTIDO', 'PRÉPARATION DU MATCH', 'PREPARAZIONE PRE-PARTITA', 'SPIELVORBEREITUNG', 'PREPARAÇÃO PRÉ-JOGO')}
          </h1>
        </div>

        {/* Right: MAÇA BAŞLA Action Button */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onStartMatch(false)}
            className="px-3.5 sm:px-5 py-1.5 sm:py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wider flex items-center gap-1.5 sm:gap-2 shadow-lg shadow-emerald-500/30 hover:scale-102 active:scale-98 transition-all cursor-pointer"
          >
            <span>{getLocalizedText('MAÇA BAŞLA', 'START MATCH', 'COMENZAR PARTIDO', 'DÉMARRER MATCH', 'INIZIA PARTITA', 'SPIEL STARTEN', 'INICIAR PARTIDA')}</span>
            <Play className="w-4 h-4 fill-slate-950" />
          </button>
        </div>
      </header>

      {/* 2. MAIN CONTENT CONTAINER */}
      <main className="flex-1 min-h-0 p-1.5 sm:p-2.5 max-w-[1700px] w-full mx-auto flex flex-col justify-between gap-1.5 sm:gap-2 overflow-hidden">
        
        {/* ======================================================== */}
        {/* TAB 1: OVERVIEW (GENEL BAKIŞ) */}
        {/* ======================================================== */}
        {activeBottomTab === 'OVERVIEW' && (
          <div className="flex flex-col gap-1 min-h-0 flex-1 overflow-hidden justify-between">
            
            {/* Top 3-Column Match Preview Grid */}
            <div className="grid grid-cols-12 gap-1 sm:gap-2 items-stretch flex-1 min-h-0">
              
              {/* ======================================================== */}
              {/* LEFT COLUMN: HOME TEAM CARD (5 Cols) */}
              {/* ======================================================== */}
              <div className="col-span-5 bg-[#120d28]/95 border border-[#2b1f4e] rounded-xl p-1 sm:p-2 flex flex-col justify-between shadow-xl relative overflow-hidden min-h-0 gap-1">
                
                {/* Header: Home Team Info & OVR Badge */}
                <div className="flex items-center justify-between border-b border-[#261b45] pb-0.5 sm:pb-1 shrink-0">
                  <div 
                    onClick={() => onOpenTeamModal?.(firstTeam)}
                    className="flex items-center gap-1 sm:gap-1.5 min-w-0 cursor-pointer group hover:opacity-90 transition-opacity"
                    title={getLocalizedText('Kulüp Detaylarını Aç', 'Open Club Details', 'Abrir Detalles del Club', 'Ouvrir Détails du Club', 'Apri Dettagli Club', 'Vereinsdetails Öffnen', 'Abrir Detalhes do Clube')}
                  >
                    <TeamBadge team={firstTeam} size="sm" className="shrink-0 drop-shadow-md w-5 h-5 sm:w-7 sm:h-7 group-hover:scale-105 transition-transform" />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <h2 className="font-black text-[9px] sm:text-xs md:text-sm text-white group-hover:text-purple-300 uppercase tracking-tight truncate">
                          {firstTeam.name}
                        </h2>
                        <ExternalLink className="w-2.5 h-2.5 text-purple-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                      <div className="flex items-center gap-1 mt-0.2">
                        <span className="text-[7.5px] sm:text-[9px] font-extrabold text-slate-300">{firstTeam.formation || '4-2-3-1'}</span>
                        <span className="px-1 py-0.2 rounded bg-emerald-950/90 border border-emerald-500/60 text-emerald-400 font-black text-[6.5px] sm:text-[7.5px] uppercase tracking-wider">
                          {getLocalizedText('EV SAHİBİ', 'HOME', 'LOCAL', 'DOMICILE', 'CASA', 'HEIM', 'CASA')}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* OVR Shield Badge */}
                  <div className="flex flex-col items-center justify-center bg-gradient-to-b from-[#3a206f] to-[#1e133d] border border-purple-400/60 rounded-lg px-1.5 py-0.2 sm:py-0.5 shadow-md shrink-0">
                    <span className="text-[6px] sm:text-[7px] font-black text-purple-300 tracking-wider">OVR</span>
                    <span className="font-black text-[11px] sm:text-sm md:text-base text-white leading-none">{homeOvr}</span>
                  </div>
                </div>

                {/* Mini Pitch Visualizer (Interactive Starters) */}
                <div className="w-full flex-1 min-h-[65px] sm:min-h-[100px] md:min-h-[130px] max-h-[160px] md:max-h-[200px] relative rounded-lg overflow-hidden border border-emerald-800/80 shadow-inner bg-[#061d11] select-none my-0.5">
                  {/* Grass Pattern */}
                  <div className="absolute inset-0 bg-gradient-to-b from-[#0a351b] via-[#0d4223] to-[#0a351b]" />
                  <div className="absolute inset-0 flex flex-col opacity-30 pointer-events-none">
                    {[...Array(6)].map((_, i) => (
                      <div key={i} className={`flex-1 w-full ${i % 2 === 0 ? 'bg-[#0f4423]' : 'bg-[#0b351b]'}`} />
                    ))}
                  </div>

                  {/* Field Markings */}
                  <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-40" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 100">
                    <rect x="3" y="3" width="94" height="94" rx="2" fill="none" stroke="#fff" strokeWidth="0.8" />
                    <line x1="3" y1="50" x2="97" y2="50" stroke="#fff" strokeWidth="0.8" />
                    <circle cx="50" cy="50" r="12" fill="none" stroke="#fff" strokeWidth="0.8" />
                    <rect x="25" y="3" width="50" height="15" fill="none" stroke="#fff" strokeWidth="0.8" />
                    <rect x="25" y="82" width="50" height="15" fill="none" stroke="#fff" strokeWidth="0.8" />
                  </svg>

                  {/* 11 Home Player Pins (Clickable to open profile) */}
                  {homeStarters.map((p, idx) => {
                    const coords = getPitchCoords(idx, firstTeam.formation);
                    if (!p) {
                      return (
                        <div
                          key={`empty-home-${idx}`}
                          style={{ top: coords.top, left: coords.left }}
                          className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center opacity-60"
                        >
                          <div className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 rounded-full border border-dashed border-white/60 bg-black/40 text-slate-400 font-bold text-[6px] sm:text-[7px] flex items-center justify-center">
                            +
                          </div>
                        </div>
                      );
                    }
                    const shirtNum = getShirtNumber(p, idx);
                    const lName = getLastName(p.name);

                    return (
                      <div
                        key={p.id}
                        onClick={() => onOpenPlayerProfile?.(p, firstTeam)}
                        style={{ top: coords.top, left: coords.left }}
                        className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group cursor-pointer transition-transform hover:scale-115 active:scale-95"
                        title={`${p.name} (${p.position} - ${p.overall} OVR) - ${getLocalizedText('Profili Aç', 'Open Profile', 'Abrir Perfil', 'Ouvrir Profil', 'Apri Profilo', 'Profil Öffnen', 'Abrir Perfil')}`}
                      >
                        <div className="relative">
                          <div className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 rounded-full bg-gradient-to-br from-red-600 via-red-500 to-amber-600 border border-white/80 text-white font-black text-[6px] sm:text-[7.5px] md:text-[9px] flex items-center justify-center shadow-md group-hover:ring-2 group-hover:ring-amber-300">
                            {shirtNum}
                          </div>
                          {p.isInjured ? (
                            <span className="absolute -top-1 -right-1 text-[6px] sm:text-[7.5px]">🚑</span>
                          ) : p.isSuspended ? (
                            <span className="absolute -top-1 -right-1 text-[6px] sm:text-[7.5px]">🟥</span>
                          ) : null}
                        </div>
                        <span className="text-[5.5px] sm:text-[7px] md:text-[8px] font-extrabold text-white bg-black/75 px-0.5 sm:px-1 py-0.1 rounded mt-0.1 tracking-tight shadow backdrop-blur-xs whitespace-nowrap group-hover:bg-purple-900 group-hover:text-amber-300 transition-colors">
                          {lName}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* YEDEKLER CARD (Bench Players - Clickable to open profile) */}
                <div className="bg-[#181233] border border-[#2d2152] rounded-lg p-1 space-y-0.5 shrink-0">
                  <div className="flex items-center justify-between border-b border-[#2a1e4d] pb-0.5">
                    <span className="font-black text-[7.5px] sm:text-[9px] text-slate-300 uppercase tracking-wider">
                      {getLocalizedText('YEDEKLER', 'SUBSTITUTES', 'SUPLENTES', 'REMPLAÇANTS', 'SOSTITUTI', 'BANK', 'RESERVAS')}
                    </span>
                    <span className="px-1 py-0.1 rounded bg-emerald-950 border border-emerald-500/50 text-emerald-400 font-black text-[6.5px] sm:text-[7.5px]">
                      {homeBench.length}/7
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-x-1 gap-y-0.5 max-h-[48px] sm:max-h-none overflow-y-auto custom-scrollbar">
                    {homeBench.map((p, idx) => {
                      const shirtNum = p.number || (idx + 12);
                      return (
                        <div 
                          key={p.id} 
                          onClick={() => onOpenPlayerProfile?.(p, firstTeam)}
                          className="flex items-center justify-between bg-[#120d28] hover:bg-[#20173e] border border-[#271b46] hover:border-purple-400/50 px-1 py-0.2 rounded cursor-pointer transition-colors group"
                          title={`${p.name} - ${getLocalizedText('Profili Aç', 'Open Profile', 'Abrir Perfil', 'Ouvrir Profil', 'Apri Profilo', 'Profil Öffnen', 'Abrir Perfil')}`}
                        >
                          <div className="flex items-center gap-0.5 sm:gap-1 min-w-0">
                            <span className="text-[7px] sm:text-[8px] font-black text-slate-400 w-2.5">{shirtNum}</span>
                            <span className="text-[7px] sm:text-[8px] font-bold text-white group-hover:text-purple-300 truncate max-w-[45px] sm:max-w-[70px]">{p.name}</span>
                            {p.isInjured ? <span className="text-[6px]">🚑</span> : p.isSuspended ? <span className="text-[6px]">🟥</span> : null}
                          </div>
                          <span className="px-0.5 py-0.1 rounded bg-[#2b1f4e] text-purple-200 font-black text-[6.5px] sm:text-[7.5px]">
                            {p.overall}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>

              {/* ======================================================== */}
              {/* MIDDLE COLUMN: TREND, MATCH DETAILS & PLAYERS (2 Cols) */}
              {/* ======================================================== */}
              <div className="col-span-2 flex flex-col justify-between gap-1 min-h-0 h-full overflow-hidden">
                
                {/* FORM (SON 3 MAÇ) - Clean Form Display */}
                <div className="bg-[#120d28]/95 border border-[#2b1f4e] rounded-lg p-1 flex flex-col items-center gap-0.5 shadow-md shrink-0">
                  <div className="flex items-center justify-between w-full px-0.5">
                    <span className="text-[6.5px] sm:text-[8px] font-black text-slate-300 uppercase tracking-wider">
                      {getLocalizedText('FORM (SON 3)', 'FORM (LAST 3)', 'FORMA (ÚLT. 3)', 'FORME (3 DER.)', 'FORMA (ULT. 3)', 'FORM (LETZTE 3)', 'FORMA (ÚLT. 3)')}
                    </span>
                    <span className="text-[5.5px] sm:text-[6.5px] text-slate-400 font-bold">{isTr ? '(G/B/M)' : '(W/D/L)'}</span>
                  </div>

                  <div className="flex items-center justify-between w-full px-0.5">
                    {/* Home Form */}
                    <div className="flex items-center gap-0.5 min-h-[12px]">
                      {homeTrend.length > 0 ? (
                        homeTrend.map((res, i) => (
                          <span
                            key={i}
                            className={`w-2.5 h-2.5 sm:w-3 sm:h-3 rounded text-[5.5px] sm:text-[6.5px] font-black flex items-center justify-center text-slate-950 ${
                              res === 'G' ? 'bg-emerald-400 font-extrabold shadow-sm' : res === 'B' ? 'bg-amber-400' : 'bg-rose-500 text-white'
                            }`}
                          >
                            {res}
                          </span>
                        ))
                      ) : (
                        <span className="text-[6.5px] sm:text-[7px] text-slate-500 font-extrabold px-0.5">- - -</span>
                      )}
                    </div>

                    <span className="text-[6px] sm:text-[7px] text-slate-500 font-bold">vs</span>

                    {/* Away Form */}
                    <div className="flex items-center gap-0.5 min-h-[12px]">
                      {awayTrend.length > 0 ? (
                        awayTrend.map((res, i) => (
                          <span
                            key={i}
                            className={`w-2.5 h-2.5 sm:w-3 sm:h-3 rounded text-[5.5px] sm:text-[6.5px] font-black flex items-center justify-center text-slate-950 ${
                              res === 'G' ? 'bg-emerald-400 font-extrabold shadow-sm' : res === 'B' ? 'bg-amber-400' : 'bg-rose-500 text-white'
                            }`}
                          >
                            {res}
                          </span>
                        ))
                      ) : (
                        <span className="text-[6.5px] sm:text-[7px] text-slate-500 font-extrabold px-0.5">- - -</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* League & Match Details Box */}
                <div 
                  onClick={() => setActiveSubModal('MATCH_DETAILS')}
                  className="bg-[#120d28]/95 hover:bg-[#1a1338] border border-[#2b1f4e] hover:border-purple-500/60 rounded-lg p-1 flex flex-col items-center text-center space-y-0.5 shadow-md shrink-0 cursor-pointer transition-all group overflow-hidden"
                  title={getLocalizedText('Detaylı Maç ve Stadyum Bilgilerini Gör', 'View Match & Stadium Details', 'Ver Detalles del Partido y Estadio', 'Voir Détails du Match et Stade', 'Vedi Dettagli Partita e Stadio', 'Spiel- und Stadiondetails anzeigen', 'Ver Detalhes do Jogo e Estádio')}
                >
                  <div className="w-4 h-4 rounded-full bg-purple-600/20 group-hover:bg-purple-600/40 border border-purple-500/40 flex items-center justify-center text-purple-300 transition-colors shrink-0">
                    <Trophy className="w-2 h-2 sm:w-2.5 sm:h-2.5" />
                  </div>
                  <div className="w-full px-0.5">
                    <span className="font-black text-[6.5px] sm:text-[7.5px] md:text-[8.5px] text-white group-hover:text-purple-300 uppercase block tracking-tight truncate max-w-full">
                      {currentLeagueName} • {currentWeek}. {getLocalizedText('HAFTA', 'WEEK', 'JORNADA', 'JOURNÉE', 'GIORNATA', 'SPIELTAG', 'RODADA')}
                    </span>
                  </div>

                  <div className="w-full border-t border-[#261b45] pt-0.5 space-y-0.1 text-left text-[6px] sm:text-[7.5px]">
                    <div className="flex items-center gap-0.5 text-slate-300 truncate">
                      <span className="text-[6.5px] sm:text-[7.5px] shrink-0">📍</span>
                      <span className="font-extrabold text-white truncate">{stadiumInfo.name}</span>
                    </div>

                    <div className="flex items-center gap-0.5 text-slate-300 truncate">
                      <span className="text-[6.5px] sm:text-[7.5px] shrink-0">⛅</span>
                      <span className="font-extrabold text-white truncate">16°C / {getLocalizedText('Parçalı Bulutlu', 'Partly Cloudy', 'Parcialmente Nublado', 'Partiellement Nuageux', 'Parzialmente Nuvoloso', 'Teilweise Bewölkt', 'Parcialmente Nublado')}</span>
                    </div>

                    <div className="flex items-center gap-0.5 text-slate-300 truncate">
                      <span className="text-[6.5px] sm:text-[7.5px] shrink-0">📅</span>
                      <span className="font-extrabold text-white truncate">20:00 / {simDateStr}</span>
                    </div>
                  </div>
                </div>

                {/* OYUNCU (Oyuncu Box - Full name visible, no truncation to 'mba...') */}
                <div className="bg-[#120d28]/95 border border-purple-500/50 rounded-lg p-1 space-y-0.5 shadow-lg shrink-0 overflow-hidden">
                  <div className="flex items-center justify-center gap-0.5 pb-0.5 border-b border-[#2b1f4e] text-center w-full">
                    <span className="text-[6.5px] sm:text-[7.5px] text-amber-300 shrink-0">⭐</span>
                    <span className="font-black text-[7px] sm:text-[8.5px] text-amber-300 uppercase tracking-wider text-center truncate">
                      {getLocalizedText('OYUNCU', 'PLAYERS', 'JUGADORES', 'JOUEURS', 'GIOCATORI', 'SPIELER', 'JOGADORES')}
                    </span>
                    <span className="text-[6.5px] sm:text-[7.5px] text-amber-300 shrink-0">⭐</span>
                  </div>

                  <div className="space-y-0.5">
                    {[
                      { player: homeKeyPlayer, team: firstTeam, isHome: true },
                      { player: awayKeyPlayer, team: secondTeam, isHome: false }
                    ].filter(item => Boolean(item.player)).map(({ player, team, isHome }, pIdx) => {
                      return (
                        <div
                          key={player.id || pIdx}
                          onClick={() => onOpenPlayerProfile?.(player, team)}
                          className="bg-[#181135] hover:bg-[#231749] border border-[#302157] hover:border-purple-400/60 p-0.5 sm:p-1 rounded flex items-center justify-between gap-1 shadow transition-colors cursor-pointer group"
                          title={`${player.name} (${player.position}) - ${getLocalizedText('Profili Aç', 'Open Profile', 'Abrir Perfil', 'Ouvrir Profil', 'Apri Profilo', 'Profil Öffnen', 'Abrir Perfil')}`}
                        >
                          <div className="flex items-center gap-1 min-w-0 flex-1">
                            {/* Compact Avatar */}
                            <div className={`w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 rounded text-white font-black text-[6.5px] sm:text-[8px] flex items-center justify-center shrink-0 shadow-inner border ${
                              isHome ? 'bg-gradient-to-br from-purple-700 to-indigo-800 border-purple-400/50' : 'bg-gradient-to-br from-rose-800 to-amber-800 border-rose-400/50'
                            }`}>
                              {player.name.charAt(0)}
                            </div>
                            
                            {/* Player Name */}
                            <div className="min-w-0 flex-1">
                              <span className="font-extrabold text-[8px] sm:text-[9.5px] text-white group-hover:text-purple-300 block truncate leading-tight" title={player.name}>
                                {player.name}
                              </span>
                              <span className="px-0.5 py-0.05 rounded bg-purple-950 text-[5.5px] sm:text-[6.5px] font-black text-purple-200 border border-purple-500/40 inline-block">
                                {player.position === 'FW' ? 'SNT' : player.position}
                              </span>
                            </div>
                          </div>

                          {/* Compact OVR Badge */}
                          <div className="flex flex-col items-center justify-center bg-[#251849] border border-purple-400/60 rounded px-1 py-0.1 shrink-0">
                            <span className="text-[4.5px] sm:text-[5px] font-black text-purple-300">OVR</span>
                            <span className="font-black text-[7.5px] sm:text-[9px] text-white leading-none">{player.overall}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* MAÇ ÖNCESİ RAPORU BUTTON (Always visible in single screen layout) */}
                <button
                  type="button"
                  onClick={() => setActiveSubModal('SCOUT_REPORT')}
                  className="p-1 sm:p-1.5 rounded-lg bg-gradient-to-r from-[#1b1238] to-[#25194f] hover:from-[#25194f] hover:to-[#352370] border border-purple-500/50 hover:border-purple-400 flex items-center gap-1 sm:gap-1.5 transition-all text-left group shadow-lg cursor-pointer shrink-0"
                >
                  <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-md bg-purple-600/40 border border-purple-400 text-purple-200 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <BarChart3 className="w-2.5 h-2.5 sm:w-3.5 sm:h-3.5 text-purple-300" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="font-black text-[7px] sm:text-[9px] md:text-[10px] text-white block uppercase tracking-tight leading-tight truncate">
                      {getLocalizedText('MAÇ ÖNCESİ RAPORU', 'PRE-MATCH REPORT', 'INFORME PREVIO', 'RAPPORT MATCH', 'REPORT PARTITA', 'SPIELBERICHT', 'RELATÓRIO JOGO')}
                    </span>
                    <span className="text-[5.5px] sm:text-[7px] text-purple-200 font-bold block truncate">
                      {getLocalizedText('Rakip Analizi & Scout', 'Opponent Scout Report', 'Análisis del Rival', 'Analyse Adversaire', 'Analisi Avversario', 'Gegneranalyse', 'Análise Adversário')}
                    </span>
                  </div>
                </button>

              </div>

              {/* ======================================================== */}
              {/* RIGHT COLUMN: AWAY TEAM CARD (5 Cols) */}
              {/* ======================================================== */}
              <div className="col-span-5 bg-[#120d28]/95 border border-[#2b1f4e] rounded-xl p-1 sm:p-2 flex flex-col justify-between shadow-xl relative overflow-hidden min-h-0 gap-1">
                
                {/* Header: OVR Badge & Away Team Info */}
                <div className="flex items-center justify-between border-b border-[#261b45] pb-0.5 sm:pb-1 shrink-0">
                  {/* OVR Shield Badge */}
                  <div className="flex flex-col items-center justify-center bg-gradient-to-b from-[#3a206f] to-[#1e133d] border border-purple-400/60 rounded-lg px-1.5 py-0.2 sm:py-0.5 shadow-md shrink-0">
                    <span className="text-[6px] sm:text-[7px] font-black text-purple-300 tracking-wider">OVR</span>
                    <span className="font-black text-[11px] sm:text-sm md:text-base text-white leading-none">{awayOvr}</span>
                  </div>

                  <div 
                    onClick={() => onOpenTeamModal?.(secondTeam)}
                    className="flex items-center gap-1 sm:gap-1.5 min-w-0 text-right cursor-pointer group hover:opacity-90 transition-opacity"
                    title={getLocalizedText('Kulüp Detaylarını Aç', 'Open Club Details', 'Abrir Detalles del Club', 'Ouvrir Détails du Club', 'Apri Dettagli Club', 'Vereinsdetails Öffnen', 'Abrir Detalhes do Clube')}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center justify-end gap-1">
                        <ExternalLink className="w-2.5 h-2.5 text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <h2 className="font-black text-[9px] sm:text-xs md:text-sm text-white group-hover:text-rose-300 uppercase tracking-tight truncate">
                          {secondTeam.name}
                        </h2>
                      </div>
                      <div className="flex items-center justify-end gap-1 mt-0.2">
                        <span className="text-[7.5px] sm:text-[9px] font-extrabold text-slate-300">{secondTeam.formation || '4-2-3-1'}</span>
                        <span className="px-1 py-0.2 rounded bg-rose-950/90 border border-rose-500/60 text-rose-400 font-black text-[6.5px] sm:text-[7.5px] uppercase tracking-wider">
                          {getLocalizedText('DEPLASMAN', 'AWAY', 'VISITANTE', 'EXTÉRIEUR', 'TRASFERTA', 'AUSWÄRTS', 'FORA')}
                        </span>
                      </div>
                    </div>
                    <TeamBadge team={secondTeam} size="sm" className="shrink-0 drop-shadow-md w-5 h-5 sm:w-7 sm:h-7 group-hover:scale-105 transition-transform" />
                  </div>
                </div>

                {/* Mini Pitch Visualizer (Interactive Starters) */}
                <div className="w-full flex-1 min-h-[65px] sm:min-h-[100px] md:min-h-[130px] max-h-[160px] md:max-h-[200px] relative rounded-lg overflow-hidden border border-emerald-800/80 shadow-inner bg-[#061d11] select-none my-0.5">
                  <div className="absolute inset-0 bg-gradient-to-b from-[#0a351b] via-[#0d4223] to-[#0a351b]" />
                  <div className="absolute inset-0 flex flex-col opacity-30 pointer-events-none">
                    {[...Array(6)].map((_, i) => (
                      <div key={i} className={`flex-1 w-full ${i % 2 === 0 ? 'bg-[#0f4423]' : 'bg-[#0b351b]'}`} />
                    ))}
                  </div>

                  <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-40" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 100">
                    <rect x="3" y="3" width="94" height="94" rx="2" fill="none" stroke="#fff" strokeWidth="0.8" />
                    <line x1="3" y1="50" x2="97" y2="50" stroke="#fff" strokeWidth="0.8" />
                    <circle cx="50" cy="50" r="12" fill="none" stroke="#fff" strokeWidth="0.8" />
                    <rect x="25" y="3" width="50" height="15" fill="none" stroke="#fff" strokeWidth="0.8" />
                    <rect x="25" y="82" width="50" height="15" fill="none" stroke="#fff" strokeWidth="0.8" />
                  </svg>

                  {/* 11 Away Player Pins (Clickable to open profile) */}
                  {awayStarters.map((p, idx) => {
                    const coords = getPitchCoords(idx, secondTeam.formation);
                    if (!p) {
                      return (
                        <div
                          key={`empty-away-${idx}`}
                          style={{ top: coords.top, left: coords.left }}
                          className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center opacity-60"
                        >
                          <div className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 rounded-full border border-dashed border-white/60 bg-black/40 text-slate-400 font-bold text-[6px] sm:text-[7px] flex items-center justify-center">
                            +
                          </div>
                        </div>
                      );
                    }
                    const shirtNum = getShirtNumber(p, idx);
                    const lName = getLastName(p.name);

                    return (
                      <div
                        key={p.id}
                        onClick={() => onOpenPlayerProfile?.(p, secondTeam)}
                        style={{ top: coords.top, left: coords.left }}
                        className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group cursor-pointer transition-transform hover:scale-115 active:scale-95"
                        title={`${p.name} (${p.position} - ${p.overall} OVR) - ${getLocalizedText('Profili Aç', 'Open Profile', 'Abrir Perfil', 'Ouvrir Profil', 'Apri Profilo', 'Profil Öffnen', 'Abrir Perfil')}`}
                      >
                        <div className="relative">
                          <div className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 rounded-full bg-gradient-to-br from-[#1e3a2b] via-[#2d5a3f] to-[#12281c] border border-white/60 text-white font-black text-[6px] sm:text-[7.5px] md:text-[9px] flex items-center justify-center shadow-md group-hover:ring-2 group-hover:ring-emerald-300">
                            {shirtNum}
                          </div>
                          {p.isInjured ? (
                            <span className="absolute -top-1 -right-1 text-[6px] sm:text-[7.5px]">🚑</span>
                          ) : p.isSuspended ? (
                            <span className="absolute -top-1 -right-1 text-[6px] sm:text-[7.5px]">🟥</span>
                          ) : null}
                        </div>
                        <span className="text-[5.5px] sm:text-[7px] md:text-[8px] font-extrabold text-white bg-black/75 px-0.5 sm:px-1 py-0.1 rounded mt-0.1 tracking-tight shadow backdrop-blur-xs whitespace-nowrap group-hover:bg-emerald-950 group-hover:text-emerald-300 transition-colors">
                          {lName}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* YEDEKLER CARD (Bench Players - Clickable to open profile) */}
                <div className="bg-[#181233] border border-[#2d2152] rounded-lg p-1 space-y-0.5 shrink-0">
                  <div className="flex items-center justify-between border-b border-[#2a1e4d] pb-0.5">
                    <span className="font-black text-[7.5px] sm:text-[9px] text-slate-300 uppercase tracking-wider">
                      {getLocalizedText('YEDEKLER', 'SUBSTITUTES', 'SUPLENTES', 'REMPLAÇANTS', 'SOSTITUTI', 'BANK', 'RESERVAS')}
                    </span>
                    <span className="px-1 py-0.1 rounded bg-emerald-950 border border-emerald-500/50 text-emerald-400 font-black text-[6.5px] sm:text-[7.5px]">
                      {awayBench.length}/7
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-x-1 gap-y-0.5 max-h-[48px] sm:max-h-none overflow-y-auto custom-scrollbar">
                    {awayBench.map((p, idx) => {
                      const shirtNum = p.number || (idx + 12);
                      return (
                        <div 
                          key={p.id} 
                          onClick={() => onOpenPlayerProfile?.(p, secondTeam)}
                          className="flex items-center justify-between bg-[#120d28] hover:bg-[#20173e] border border-[#271b46] hover:border-purple-400/50 px-1 py-0.2 rounded cursor-pointer transition-colors group"
                          title={`${p.name} - ${getLocalizedText('Profili Aç', 'Open Profile', 'Abrir Perfil', 'Ouvrir Profil', 'Apri Profilo', 'Profil Öffnen', 'Abrir Perfil')}`}
                        >
                          <div className="flex items-center gap-0.5 sm:gap-1 min-w-0">
                            <span className="text-[7px] sm:text-[8px] font-black text-slate-400 w-2.5">{shirtNum}</span>
                            <span className="text-[7px] sm:text-[8px] font-bold text-white group-hover:text-purple-300 truncate max-w-[45px] sm:max-w-[70px]">{p.name}</span>
                            {p.isInjured ? <span className="text-[6px]">🚑</span> : p.isSuspended ? <span className="text-[6px]">🟥</span> : null}
                          </div>
                          <span className="px-0.5 py-0.1 rounded bg-[#2b1f4e] text-purple-200 font-black text-[6.5px] sm:text-[7.5px]">
                            {p.overall}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 2: OPPONENT ANALYSIS (RAKİP ANALİZİ & BİREYSEL MARKAJ) */}
        {/* ======================================================== */}
        {activeBottomTab === 'OPPONENT_ANALYSIS' && (
          <div className="flex-1 min-h-0 bg-[#120d28] border border-[#2b1f4e] rounded-xl p-2.5 sm:p-3.5 shadow-xl flex flex-col gap-2.5 sm:gap-3 overflow-y-auto custom-scrollbar">
            
            {/* Header */}
            <div className="flex items-center justify-between border-b border-[#2e2154] pb-2 shrink-0">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-rose-400" />
                <h3 className="font-black text-xs sm:text-sm text-white uppercase">
                  {secondTeam.name} - {getLocalizedText('Detaylı Rakip Analizi & Bireysel Markaj', 'Detailed Opponent Breakdown & Marking', 'Análisis Detallado del Rival y Marcaje', 'Analyse Détaillée de l\'Adversaire et Marquage', 'Analisi Dettagliata Avversario e Marcatura', 'Gegneranalyse & Manndeckung', 'Análise Detalhada do Adversário e Marcação')}
                </h3>
              </div>
              <span className="text-[10px] sm:text-xs font-black text-rose-300 bg-rose-950/80 border border-rose-500/40 px-2 py-0.5 rounded">
                {getLocalizedText('Tehlike Seviyesi: Yüksek', 'Threat Level: High', 'Nivel de Amenaza: Alto', 'Niveau de Menace: Élevé', 'Livello di Rischio: Alto', 'Gefahrenstufe: Hoch', 'Nível de Ameaça: Alto')}
              </span>
            </div>

            {/* Bireysel Oyuncu Markajı (Individual Player Marking Section integrated directly) */}
            <div className="bg-[#171133] border border-purple-500/40 rounded-xl p-2.5 sm:p-3 space-y-2 shrink-0">
              <div className="flex items-center justify-between border-b border-[#2a1e4d] pb-1.5">
                <div className="flex items-center gap-1.5">
                  <Target className="w-4 h-4 text-purple-400" />
                  <span className="font-black text-xs text-purple-300 uppercase tracking-wide">
                    {getLocalizedText('Bireysel Oyuncu Markajı (Özel Önlemler)', 'Individual Player Marking (Special Focus)', 'Marcaje Individual a Jugadores', 'Marquage Individuel des Joueurs', 'Marcatura Individuale Giocatori', 'Individuelle Manndeckung', 'Marcação Individual de Jogadores')}
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-bold">
                  {getLocalizedText('Markaj Uygulanacak Oyuncuları Seçin', 'Select Players to Mark', 'Seleccionar Jugadores para Marcar', 'Sélectionner les Joueurs à Marquer', 'Seleziona Giocatori da Marcare', 'Spieler für Deckung wählen', 'Selecionar Jogadores para Marcar')}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                {awayStarters.slice(0, 6).map((p) => {
                  const isMarked = markedPlayerIds.includes(p.id);
                  const curType = markingType[p.id] || 'TIGHT';

                  return (
                    <div 
                      key={p.id}
                      className={`p-2 rounded-xl border transition-all flex flex-col justify-between gap-1.5 ${
                        isMarked 
                          ? 'bg-[#20153f] border-purple-400 shadow-md ring-1 ring-purple-400/50' 
                          : 'bg-[#120d28] border-[#2b1f4e] hover:border-purple-500/40'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div 
                          onClick={() => onOpenPlayerProfile?.(p, secondTeam)}
                          className="flex items-center gap-1.5 min-w-0 cursor-pointer group"
                        >
                          <div className="w-6 h-6 rounded-md bg-purple-900/60 border border-purple-500/50 text-purple-200 font-black text-[10px] flex items-center justify-center shrink-0">
                            {p.position}
                          </div>
                          <div className="min-w-0">
                            <span className="font-extrabold text-xs text-white group-hover:text-purple-300 block truncate">{p.name}</span>
                            <span className="text-[9px] text-amber-300 font-bold">{p.overall} OVR</span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => toggleMarkPlayer(p.id)}
                          className={`px-2 py-1 rounded-lg text-[10px] font-black cursor-pointer transition-all ${
                            isMarked
                              ? 'bg-purple-600 text-white shadow'
                              : 'bg-[#1c1439] text-slate-300 hover:text-white border border-[#3b2a68]'
                          }`}
                        >
                          {isMarked ? getLocalizedText('✓ Markajda', '✓ Marked', '✓ Marcado', '✓ Marqué', '✓ Marcato', '✓ Gedeckt', '✓ Marcado') : getLocalizedText('+ Markaj Ekle', '+ Mark', '+ Marcar', '+ Marquer', '+ Marca', '+ Decken', '+ Marcar')}
                        </button>
                      </div>

                      {isMarked && (
                        <div className="flex items-center gap-1 pt-1 border-t border-purple-500/30">
                          {[
                            { id: 'TIGHT' as const, label: getLocalizedText('Sıkı', 'Tight', 'Pegada', 'Serré', 'Stretta', 'Eng', 'Firme') },
                            { id: 'DOUBLE' as const, label: getLocalizedText('İkili', 'Double', 'Doble', 'Double', 'Doppia', 'Doppel', 'Dupla') },
                            { id: 'PRESS' as const, label: getLocalizedText('Pres', 'Press', 'Presión', 'Pressing', 'Pressing', 'Press', 'Pressão') },
                          ].map(tType => (
                            <button
                              key={tType.id}
                              type="button"
                              onClick={() => handleSetMarkingType(p.id, tType.id)}
                              className={`flex-1 py-0.5 rounded text-[8.5px] font-black cursor-pointer transition-all border ${
                                curType === tType.id
                                  ? 'bg-purple-500 text-white border-purple-300'
                                  : 'bg-[#130e29] text-slate-400 border-transparent hover:text-white'
                              }`}
                            >
                              {tType.label}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Tactical Weaknesses & Key Threats */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 sm:gap-3 text-xs">
              <div className="bg-[#171133] border border-[#2d2152] rounded-xl p-3 space-y-2">
                <span className="font-black text-emerald-400 uppercase block flex items-center gap-1.5">
                  <span>🟢</span>
                  <span>{getLocalizedText('Rakibin Zayıf Noktaları', 'Opponent Weaknesses', 'Puntos Débiles del Rival', 'Faiblesses de l\'Adversaire', 'Punti Deboli dell\'Avversario', 'Schwächen des Gegners', 'Pontos Fracos do Adversário')}</span>
                </span>
                <ul className="list-disc list-inside text-slate-300 font-bold space-y-1 text-[11px] sm:text-xs">
                  <li>{getLocalizedText('Bek oyuncuları hücuma çıktığında savunma arkasında geniş boşluklar bırakıyor.', 'Fullbacks leave open spaces behind when attacking.', 'Los laterales dejan espacios libres a la espalda al atacar.', 'Les latéraux laissent des espaces dans leur dos en attaquant.', 'I terzini lasciano spazi scoperti alle spalle quando avanzano.', 'Die Außenverteidiger lassen beim Aufrücken große Räume offen.', 'Os laterais deixam espaços nas costas ao subir para o ataque.')}</li>
                  <li>{getLocalizedText('Hızlı kanat forvetlerimizle çizgiye inip yerden sert ortalar gol getirebilir.', 'Low crosses from quick wingers will exploit defensive gaps.', 'Centros rasos de extremos rápidos pueden crear ocasiones de gol.', 'Des centres à ras de terre par nos ailiers rapides peuvent créer des buts.', 'Cross bassi dalle ali veloci possono creare occasioni da gol.', 'Flache Hereingaben über schnelle Flügel können zu Toren führen.', 'Cruzamentos rasteiros de pontas velozes podem gerar gols.')}</li>
                  <li>{getLocalizedText('Stoper tandemi ağır, süratli oyunculara karşı zorlanıyor.', 'Central defenders lack pace against rapid attackers.', 'Los centrales sufren ante delanteros veloces.', 'La charnière centrale manque de vitesse face aux attaquants rapides.', 'I difensori centrali soffrono contro giocatori scattanti.', 'Die Innenverteidiger sind anfällig gegen schnelle Stürmer.', 'A zaga central tem dificuldade contra atacantes rápidos.')}</li>
                </ul>
              </div>

              <div className="bg-[#171133] border border-[#2d2152] rounded-xl p-3 space-y-2">
                <span className="font-black text-rose-400 uppercase block flex items-center gap-1.5">
                  <span>🔴</span>
                  <span>{getLocalizedText('Rakibin En Tehlikeli Silahları', 'Key Opponent Threats', 'Amenazas Principales del Rival', 'Menaces Majeures de l\'Adversaire', 'Minacce Principali dell\'Avversario', 'Hauptgefahren des Gegners', 'Principais Ameaças do Adversário')}</span>
                </span>
                <ul className="list-disc list-inside text-slate-300 font-bold space-y-1 text-[11px] sm:text-xs">
                  <li>{getLocalizedText(`${awayKeyPlayer?.name || 'Rakip Yıldız'} ceza sahası çevresinde topla buluştuğunda çok etkili.`, `${awayKeyPlayer?.name || 'Star Player'} is dangerous around the penalty area.`, `${awayKeyPlayer?.name || 'La Estrella'} es muy peligroso cerca del área.`, `${awayKeyPlayer?.name || 'Le Joueur Clé'} est redoutable aux abords de la surface.`, `${awayKeyPlayer?.name || 'La Stella'} è letale al limite dell'area.`, `${awayKeyPlayer?.name || 'Der Starspieler'} ist am Strafraum brandgefährlich.`, `${awayKeyPlayer?.name || 'O Craque'} é muito perigoso perto da grande área.`)}</li>
                  <li>{getLocalizedText('Duran toplarda ve kornerlerde ön direk organizasyonları tehlikeli.', 'Dangerous near-post set piece and corner routines.', 'Jugadas a balón parado y saques de esquina peligrosos al primer palo.', 'Coups de pied arrêtés dangereux au premier poteau.', 'Calci piazzati e corner pericolosi sul primo palo.', 'Gefährliche Standardsituationen und Ecken am kurzen Pfosten.', 'Bolas paradas e escanteios perigosos na primeira trave.')}</li>
                  <li>{getLocalizedText('Top kayıplarımızda 3 saniye içinde kaleye dikine geçiş yapıyorlar.', 'Fast direct transitions within seconds of turnovers.', 'Transiciones verticales rápidas tras pérdidas de balón.', 'Transitions directes rapides en quelques secondes après perte de balle.', 'Transizioni verticali rapide dopo recupero palla.', 'Blitzschnelles Umschaltspiel nach Ballgewinnen.', 'Transições verticais rápidas em poucos segundos após recuperação.')}</li>
                </ul>
              </div>
            </div>

          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 3: PLAYER COMPARISON (OYUNCU KIYASLAMA) */}
        {/* ======================================================== */}
        {activeBottomTab === 'COMPARISON' && (
          <div className="flex-1 min-h-0 bg-[#120d28] border border-[#2b1f4e] rounded-xl p-3 shadow-xl flex flex-col gap-3 overflow-y-auto custom-scrollbar">
            <div className="flex items-center justify-between border-b border-[#2e2154] pb-2">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-sm text-white uppercase">
                  {getLocalizedText('Bölgesel Güç & Yıldız Kıyaslaması', 'Positional & Star Comparison', 'Comparativa Posicional y de Estrellas', 'Comparaison Positionnelle et des Étoiles', 'Confronto Posizionale e Stelle', 'Positions- & Star-Vergleich', 'Comparação Posicional e de Estrelas')}
                </h3>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Star vs Star Showdown (Clickable Players) */}
              <div className="bg-[#171133] border border-[#2d2152] rounded-xl p-3 space-y-2">
                <span className="font-black text-xs text-amber-300 uppercase block text-center">
                  ⭐ {getLocalizedText('YILDIZ OYUNCU DÜELLOSU', 'STAR DUEL', 'DUELO DE ESTRELLAS', 'DUEL DE STARS', 'DUELLO DI STELLE', 'STAR-DUELL', 'DUELO DE CRAQUES')}
                </span>
                <div className="flex items-center justify-between bg-[#110c26] p-2.5 rounded-xl border border-[#291e4b]">
                  <div 
                    onClick={() => onOpenPlayerProfile?.(homeKeyPlayer, firstTeam)}
                    className="text-left min-w-0 cursor-pointer group"
                    title={getLocalizedText('Profili Aç', 'Open Profile', 'Abrir Perfil', 'Ouvrir Profil', 'Apri Profilo', 'Profil Öffnen', 'Abrir Perfil')}
                  >
                    <span className="text-xs font-black text-emerald-400 group-hover:text-emerald-300 block truncate">{homeKeyPlayer?.name || firstTeam.name}</span>
                    <span className="text-[9px] text-slate-400 font-bold">{firstTeam.name} • {homeKeyPlayer?.position}</span>
                  </div>
                  <div className="px-3 py-1 bg-gradient-to-r from-emerald-600 to-rose-600 rounded-lg text-white font-black text-xs shadow">
                    {homeKeyPlayer?.overall || 80} vs {awayKeyPlayer?.overall || 80}
                  </div>
                  <div 
                    onClick={() => onOpenPlayerProfile?.(awayKeyPlayer, secondTeam)}
                    className="text-right min-w-0 cursor-pointer group"
                    title={getLocalizedText('Profili Aç', 'Open Profile', 'Abrir Perfil', 'Ouvrir Profil', 'Apri Profilo', 'Profil Öffnen', 'Abrir Perfil')}
                  >
                    <span className="text-xs font-black text-rose-400 group-hover:text-rose-300 block truncate">{awayKeyPlayer?.name || secondTeam.name}</span>
                    <span className="text-[9px] text-slate-400 font-bold">{secondTeam.name} • {awayKeyPlayer?.position}</span>
                  </div>
                </div>
              </div>

              {/* Positional Rating Bars */}
              <div className="bg-[#171133] border border-[#2d2152] rounded-xl p-3 space-y-2.5 text-xs">
                <span className="font-black text-xs text-purple-300 uppercase block">
                  {getLocalizedText('Bölgesel Güç Dağılımı', 'Squad Balance Comparison', 'Balance de Plantilla', 'Équilibre des Postes', 'Bilanciamento Ruoli', 'Kader-Balance', 'Equilíbrio do Elenco')}
                </span>
                
                {/* Forvet */}
                <div>
                  <div className="flex justify-between text-[10px] font-bold text-slate-300 mb-0.5">
                    <span>{firstTeam.name} {getLocalizedText('Hücum', 'Attack', 'Ataque', 'Attaque', 'Attacco', 'Angriff', 'Ataque')}: {homeOvr + 2}</span>
                    <span>{secondTeam.name} {getLocalizedText('Hücum', 'Attack', 'Ataque', 'Attaque', 'Attacco', 'Angriff', 'Ataque')}: {awayOvr + 1}</span>
                  </div>
                  <div className="w-full bg-[#100b24] h-2 rounded-full overflow-hidden flex">
                    <div className="bg-emerald-500 h-full" style={{ width: `${(homeOvr / (homeOvr + awayOvr)) * 100}%` }} />
                    <div className="bg-rose-500 h-full" style={{ width: `${(awayOvr / (homeOvr + awayOvr)) * 100}%` }} />
                  </div>
                </div>

                {/* Savunma */}
                <div>
                  <div className="flex justify-between text-[10px] font-bold text-slate-300 mb-0.5">
                    <span>{firstTeam.name} {getLocalizedText('Savunma', 'Defense', 'Defensa', 'Défense', 'Difesa', 'Abwehr', 'Defesa')}: {homeOvr - 1}</span>
                    <span>{secondTeam.name} {getLocalizedText('Savunma', 'Defense', 'Defensa', 'Défense', 'Difesa', 'Abwehr', 'Defesa')}: {awayOvr}</span>
                  </div>
                  <div className="w-full bg-[#100b24] h-2 rounded-full overflow-hidden flex">
                    <div className="bg-emerald-500 h-full" style={{ width: `${(homeOvr / (homeOvr + awayOvr)) * 100}%` }} />
                    <div className="bg-rose-500 h-full" style={{ width: `${(awayOvr / (homeOvr + awayOvr)) * 100}%` }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 3. BOTTOM NAVIGATION TABS (Taktik & Kadro directly opens formation screen!) */}
        <div className="shrink-0 w-full bg-[#100b24] border border-[#291e4b] rounded-lg p-0.5 flex items-center justify-around overflow-x-auto custom-scrollbar shadow-xl">
          {[
            { id: 'OVERVIEW', label: getLocalizedText('GENEL BAKIŞ', 'OVERVIEW', 'GENERAL', 'VUE D\'ENSEMBLE', 'PANORAMICA', 'ÜBERSICHT', 'VISÃO GERAL') },
            { id: 'TACTICS', label: getLocalizedText('TAKTIK & KADRO', 'TACTICS & LINEUP', 'TÁCTICA Y PLANTILLA', 'TACTIQUE ET EFFECTIF', 'TATTICA E FORMAZIONE', 'TAKTIK & KADER', 'TÁTICA E ESCALAÇÃO'), isDirectAction: true },
            { id: 'OPPONENT_ANALYSIS', label: getLocalizedText('RAKİP ANALİZİ', 'OPPONENT ANALYSIS', 'ANÁLISIS RIVAL', 'ANALYSE ADVERSAIRE', 'ANALISI AVVERSARIO', 'GEGNERANALYSE', 'ANÁLISE ADVERSÁRIO') },
            { id: 'COMPARISON', label: getLocalizedText('OYUNCU KIYASLAMA', 'COMPARISON', 'COMPARACIÓN', 'COMPARAISON', 'CONFRONTO', 'VERGLEICH', 'COMPARAÇÃO') }
          ].map((tab) => {
            const isActive = activeBottomTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  if (tab.isDirectAction) {
                    onEditTactics();
                  } else {
                    setActiveBottomTab(tab.id as any);
                  }
                }}
                className={`flex-1 py-1.5 px-2 text-center font-black text-[9.5px] sm:text-xs uppercase tracking-wider relative transition-all whitespace-nowrap cursor-pointer ${
                  isActive ? 'text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.label}
                {isActive && (
                  <div className="absolute bottom-0 left-3 right-3 h-0.5 bg-gradient-to-r from-purple-500 to-indigo-400 shadow-[0_0_8px_#a855f7] rounded-full" />
                )}
              </button>
            );
          })}
        </div>

      </main>

      {/* ======================================================== */}
      {/* SUB-MODAL 1: TAKIM TALİMATLARI MODAL */}
      {/* ======================================================== */}
      {activeSubModal === 'INSTRUCTIONS' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
          <div className="bg-[#15102a] border border-purple-500/40 rounded-2xl p-4 sm:p-6 max-w-xl w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#2d2150] pb-3">
              <div className="flex items-center gap-2">
                <Compass className="w-5 h-5 text-purple-400" />
                <h3 className="font-black text-base text-white uppercase">
                  {getLocalizedText('Takım Talimatları & Oyun Mentalitesi', 'Team Instructions & Mentality', 'Instrucciones del Equipo y Mentalidad', 'Consignes d\'Équipe et Mentalité', 'Istruzioni Squadra e Mentalità', 'Team-Anweisungen & Mentalität', 'Instruções da Equipe e Mentalidade')}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveSubModal(null)}
                className="w-7 h-7 rounded-lg bg-[#231a44] text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-[#1a1334] p-3 rounded-xl border border-[#2d2152] space-y-2">
                <span className="font-black text-purple-300 uppercase block">⚔️ {getLocalizedText('Hücum Mentalitesi', 'Attacking Mentality', 'Mentalidad Ofensiva', 'Mentalité Offensive', 'Mentalità Offensiva', 'Offensiv-Mentalität', 'Mentalidade Ofensiva')}</span>
                <p className="text-slate-300 font-bold">{getLocalizedText('Takım topa sahip olduğunda geniş alana yayılarak ceza sahasına dikine paslarla hızlı geçiş yapacaktır.', 'Fast vertical transitions with wide width when in possession.', 'Transiciones verticales rápidas y amplitud en posesión de balón.', 'Transitions verticales rapides avec de la largeur en possession.', 'Transizioni verticali rapide con ampiezza in possesso palla.', 'Schnelles Umschaltspiel mit Breite bei Ballbesitz.', 'Transições verticais rápidas com amplitude na posse de bola.')}</p>
              </div>

              <div className="bg-[#1a1334] p-3 rounded-xl border border-[#2d2152] space-y-2">
                <span className="font-black text-purple-300 uppercase block">🛡️ {getLocalizedText('Savunma & Pres Hattı', 'Defensive & Pressing Line', 'Línea Defensiva y de Presión', 'Ligne Défensive et Pressing', 'Linea Difensiva e Pressing', 'Abwehr- & Pressinglinie', 'Linha Defensiva e de Pressão')}</span>
                <p className="text-slate-300 font-bold">{getLocalizedText('Orta saha bloğunda rakip oyun kurucuya şok pres uygulanacak, dönen toplar hızlı hücuma dönüştürülecektir.', 'High pressing on opponent playmakers in midfield.', 'Presión intensa sobre creadores de juego rivales en mediocampo.', 'Pressing haut sur les meneurs de jeu adverses au milieu.', 'Pressing alto sui registi avversari a centrocampo.', 'Hohes Pressing gegen gegnerische Spielmacher im Mittelfeld.', 'Pressão alta nos armadores adversários no meio-campo.')}</p>
              </div>

              <div className="bg-[#1a1334] p-3 rounded-xl border border-[#2d2152] space-y-2">
                <span className="font-black text-purple-300 uppercase block">⚡ {getLocalizedText('Tempo & Pas Dağılımı', 'Tempo & Passing Distribution', 'Ritmo y Distribución de Pases', 'Tempo et Distribution des Passes', 'Ritmo e Distribuzione Passaggi', 'Tempo & Passspiel', 'Ritmo e Distribuição de Passes')}</span>
                <p className="text-slate-300 font-bold">{getLocalizedText('Yüksek tempolu ve kısa pas kombinasyonlarıyla rakip defans hattında açıklar aranacaktır.', 'High tempo short passing combinations to find defensive gaps.', 'Combinaciones cortas a ritmo alto para abrir huecos defensivos.', 'Combinaisons courtes à rythme élevé pour créer des brèches.', 'Scambi corti ad alto ritmo per trovare varchi nella difesa.', 'Schnelle Kurzpasskombinationen zur Lückenfindung.', 'Combinações curtas em ritmo acelerado para encontrar espaços.')}</p>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setActiveSubModal(null)}
                className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs cursor-pointer shadow"
              >
                {getLocalizedText('Kaydet ve Kapat', 'Save & Close', 'Guardar y Cerrar', 'Enregistrer et Fermer', 'Salva e Chiudi', 'Speichern & Schließen', 'Salvar e Fechar')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SUB-MODAL 2: MAÇ ÖNCESİ RAPORU (Scout & Notlar) */}
      {/* ======================================================== */}
      {activeSubModal === 'SCOUT_REPORT' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
          <div className="bg-[#15102a] border border-purple-500/40 rounded-2xl p-4 sm:p-6 max-w-2xl w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#2d2150] pb-3">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-sky-400" />
                <h3 className="font-black text-base text-white uppercase">
                  {getLocalizedText('Maç Öncesi Analiz & Scout Raporu', 'Pre-Match Scout Analysis', 'Análisis Previo del Ojeador', 'Rapport de Scout d\'Avant-Match', 'Report Scout Pre-Partita', 'Scouting-Bericht vor dem Spiel', 'Relatório do Olheiro Pré-Jogo')}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveSubModal(null)}
                className="w-7 h-7 rounded-lg bg-[#231a44] text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-[#1a1334] p-3 rounded-xl border border-[#2d2152] space-y-2">
                <span className="font-black text-emerald-400 uppercase block">🟢 {getLocalizedText('Takımımızın Güçlü Yönleri', 'Our Team Strengths', 'Puntos Fuertes de Nuestro Equipo', 'Forces de Notre Équipe', 'Punti di Forza della Nostra Squadra', 'Stärken unseres Teams', 'Pontos Fortes da Nossa Equipe')}</span>
                <ul className="list-disc list-inside text-slate-300 space-y-1 font-bold">
                  <li>{getLocalizedText('Yüksek bitiricilik oranına sahip forvet hattı', 'High clinical finishing from attacking line', 'Gran eficacia goleadora de la delantera', 'Excellente finition de la ligne d\'attaque', 'Grande concretezza del reparto offensivo', 'Hohe Chancenverwertung im Sturm', 'Alta taxa de finalização do ataque')}</li>
                  <li>{getLocalizedText('Orta alanda dinamik ikili mücadele üstünlüğü', 'Midfield physical duel dominance', 'Superioridad en duelos en mediocampo', 'Domination dans les duels au milieu', 'Dominio nei duelli a centrocampo', 'Zweikampfstärke im Mittelfeld', 'Domínio nos duelos no meio-campo')}</li>
                  <li>{getLocalizedText('Duran toplarda etkili stoper kafa vuruşları', 'Strong aerial presence on set pieces', 'Poderío aéreo en jugadas a balón parado', 'Impact aérien sur les phases arrêtées', 'Pericolosità aerea sui calci piazzati', 'Gefahr bei Standardsituationen', 'Forte presença aérea em bolas paradas')}</li>
                </ul>
              </div>

              <div className="bg-[#1a1334] p-3 rounded-xl border border-[#2d2152] space-y-2">
                <span className="font-black text-rose-400 uppercase block">🔴 {getLocalizedText('Rakibin Tehlikeli Yönleri', 'Opponent Dangerous Aspects', 'Aspectos Peligrosos del Rival', 'Dangers de l\'Adversaire', 'Pericoli dell\'Avversario', 'Gefahren durch den Gegner', 'Aspectos Perigosos do Adversário')}</span>
                <ul className="list-disc list-inside text-slate-300 space-y-1 font-bold">
                  <li>{getLocalizedText('Hızlı kanat oyuncularıyla kontra atak tehdidi', 'Fast wingers counter attacking threat', 'Amenaza de contragolpe con extremos veloces', 'Menace de contre-attaque par des ailiers rapides', 'Pericolo contropiede con ali veloci', 'Kontergefahr über schnelle Flügel', 'Ameaça de contra-ataque com pontas rápidos')}</li>
                  <li>{getLocalizedText('Ceza sahası dışından sert ve isabetli şutlar', 'Long range shot threat', 'Disparos peligrosos de media distancia', 'Tirs puissants de loin', 'Tiri potenti da fuori area', 'Fernschussgefahr aus der zweiten Reihe', 'Chutes perigosos de longa distância')}</li>
                  <li>{getLocalizedText('Derin savunma bloğu kurarak alanı daraltma', 'Compact deep defensive line', 'Bloque bajo compacto para cerrar espacios', 'Bloc bas compact réduisant les espaces', 'Blocco difensivo basso e compatto', 'Kompakte tiefe Staffelung', 'Linha defensiva baixa e compacta')}</li>
                </ul>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setActiveSubModal(null)}
                className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-black text-xs cursor-pointer shadow"
              >
                {getLocalizedText('Raporu İnceledim', 'Close Report', 'Cerrar Informe', 'Fermer le Rapport', 'Chiudi Report', 'Bericht Schließen', 'Fechar Relatório')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SUB-MODAL 3: MAÇ VE STADYUM DETAYLARI MODAL (Top Box Click) */}
      {/* ======================================================== */}
      {activeSubModal === 'MATCH_DETAILS' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-3 bg-black/80 backdrop-blur-md animate-in fade-in duration-150 overflow-y-auto">
          <div className="bg-[#15102a] border border-purple-500/50 rounded-2xl p-3 sm:p-4 max-w-lg w-full max-h-[92vh] flex flex-col justify-between shadow-2xl space-y-2.5 overflow-hidden">
            
            <div className="flex items-center justify-between border-b border-[#2d2150] pb-2 shrink-0">
              <div className="flex items-center gap-2 min-w-0">
                <div className="p-1.5 rounded-lg bg-purple-600/20 border border-purple-500/40 text-purple-300 shrink-0">
                  <MapPin className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-black text-xs sm:text-sm md:text-base text-white uppercase truncate">
                    {getLocalizedText('Maç Detayları & Stadyum', 'Match & Stadium Details', 'Detalles del Partido y Estadio', 'Détails du Match et Stade', 'Dettagli Partita e Stadio', 'Spiel- & Stadioninformationen', 'Detalhes do Jogo e Estádio')}
                  </h3>
                  <p className="text-[10px] sm:text-[11px] text-slate-400 truncate">
                    {firstTeam.name} vs {secondTeam.name}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveSubModal(null)}
                className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg bg-[#231a44] text-slate-400 hover:text-white flex items-center justify-center cursor-pointer shrink-0"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs overflow-y-auto custom-scrollbar flex-1 pr-0.5">
              
              {/* Stadium & City */}
              <div className="bg-[#1a1334] p-2 sm:p-2.5 rounded-xl border border-[#2d2152] space-y-0.5">
                <div className="flex items-center gap-1 text-purple-300 font-extrabold text-[10px] sm:text-[11px]">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{getLocalizedText('Stadyum & Konum', 'Stadium & Location', 'Estadio y Ubicación', 'Stade et Emplacement', 'Stadio e Posizione', 'Stadion & Standort', 'Estádio e Localização')}</span>
                </div>
                <p className="text-white font-black text-xs sm:text-sm truncate">{stadiumInfo.name}</p>
                <p className="text-slate-400 text-[10px] sm:text-[11px] font-bold">{stadiumInfo.city} • {getLocalizedText('Kapasite:', 'Capacity:', 'Capacidad:', 'Capacité:', 'Capienza:', 'Kapazität:', 'Capacidade:')} {stadiumInfo.capacity}</p>
                <p className="text-emerald-400 text-[9.5px] sm:text-[10px] font-bold">🌱 {getLocalizedText('Zemin:', 'Pitch:', 'Césped:', 'Pelouse:', 'Terreno:', 'Rasen:', 'Gramado:')} {stadiumInfo.pitchType === 'Hibrit Çim' ? getLocalizedText('Hibrit Çim', 'Hybrid Grass', 'Césped Híbrido', 'Pelouse Hybride', 'Erba Ibrida', 'Hybridrasen', 'Grama Híbrida') : getLocalizedText('Doğal Çim', 'Natural Grass', 'Césped Natural', 'Pelouse Naturelle', 'Erba Naturale', 'Naturrasen', 'Grama Natural')}</p>
              </div>

              {/* Date & Time */}
              <div className="bg-[#1a1334] p-2 sm:p-2.5 rounded-xl border border-[#2d2152] space-y-0.5">
                <div className="flex items-center gap-1 text-amber-300 font-extrabold text-[10px] sm:text-[11px]">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>{getLocalizedText('Tarih & Saat', 'Date & Time', 'Fecha y Hora', 'Date et Heure', 'Data e Ora', 'Datum & Uhrzeit', 'Data e Hora')}</span>
                </div>
                <p className="text-white font-black text-xs sm:text-sm">{simDateStr}</p>
                <p className="text-slate-400 text-[10px] sm:text-[11px] font-bold">⏰ {getLocalizedText('Saat: 20:00 (Canlı)', 'Time: 20:00 (Live)', 'Hora: 20:00 (En Directo)', 'Heure: 20:00 (En Direct)', 'Ora: 20:00 (Diretta TV)', 'Uhrzeit: 20:00 (Live)', 'Horário: 20:00 (Ao Vivo)')}</p>
                <p className="text-purple-300 text-[9.5px] sm:text-[10px] font-bold">🏆 {currentLeagueName} • {currentWeek}. {getLocalizedText('Hafta', 'Week', 'Jornada', 'Semaine', 'Giornata', 'Spieltag', 'Rodada')}</p>
              </div>

              {/* Weather & Conditions */}
              <div className="bg-[#1a1334] p-2 sm:p-2.5 rounded-xl border border-[#2d2152] space-y-0.5">
                <div className="flex items-center gap-1 text-sky-300 font-extrabold text-[10px] sm:text-[11px]">
                  <CloudSun className="w-3.5 h-3.5" />
                  <span>{getLocalizedText('Hava & Çevre', 'Weather & Conditions', 'Clima y Condiciones', 'Météo et Conditions', 'Meteo e Condizioni', 'Wetter & Bedingungen', 'Clima e Condições')}</span>
                </div>
                <p className="text-white font-black text-xs sm:text-sm">16°C • {getLocalizedText('Parçalı Bulutlu', 'Partly Cloudy', 'Parcialmente Nublado', 'Partiellement Nuageux', 'Parzialmente Nuvoloso', 'Teilweise Bewölkt', 'Parcialmente Nublado')}</p>
                <p className="text-slate-400 text-[10px] sm:text-[11px] font-bold">💨 {getLocalizedText('Rüzgar: 12 km/s', 'Wind: 12 km/h', 'Viento: 12 km/h', 'Vent: 12 km/h', 'Vento: 12 km/h', 'Wind: 12 km/h', 'Vento: 12 km/h')} • 💧 {getLocalizedText('Nem: %55', 'Humidity: 55%', 'Humedad: 55%', 'Humidité: 55%', 'Umidità: 55%', 'Luftfeuchtigkeit: 55%', 'Umidade: 55%')}</p>
              </div>

              {/* Atmosphere */}
              <div className="bg-[#1a1334] p-2 sm:p-2.5 rounded-xl border border-[#2d2152] space-y-0.5">
                <div className="flex items-center gap-1 text-rose-300 font-extrabold text-[10px] sm:text-[11px]">
                  <Flame className="w-3.5 h-3.5" />
                  <span>{getLocalizedText('Tribün & Atmosfer', 'Stands & Atmosphere', 'Gradas y Ambiente', 'Tribunes et Ambiance', 'Tribune e Atmosfera', 'Tribünen & Atmosphäre', 'Arquibancadas e Ambiente')}</span>
                </div>
                <p className="text-white font-black text-xs sm:text-sm truncate">🔥 {getLocalizedText('Kapalı Gişe & Ateşli Taraftar', 'Sold Out & Electric Crowd', 'Estadio Lleno y Ambiente Caliente', 'Guichets Fermés et Ambiance Électrique', 'Tutto Esaurito e Tifo Caldo', 'Ausverkauft & Tolle Kulisse', 'Lotado e Torcida Apaixonada')}</p>
                <p className="text-slate-400 text-[10px] sm:text-[11px] font-bold">🏟️ {getLocalizedText('Doluluk: %100', 'Attendance: 100%', 'Asistencia: 100%', 'Affluence: 100%', 'Presenze: 100%', 'Auslastung: 100%', 'Lotação: 100%')}</p>
              </div>

            </div>

            <div className="flex justify-end pt-1 shrink-0">
              <button
                type="button"
                onClick={() => setActiveSubModal(null)}
                className="px-4 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs cursor-pointer shadow active:scale-95 transition-all"
              >
                {getLocalizedText('Kapat', 'Close', 'Cerrar', 'Fermer', 'Chiudi', 'Schließen', 'Fechar')}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
