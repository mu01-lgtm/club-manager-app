import React, { useState } from 'react';
import { Player, Team, Scout, ScoutReport } from '../types';
import { useTranslation } from '../utils/i18n';
import { generatePlayerCareerHistory, TransfermarktCareerRow } from '../data/playerCareers';
import { getPlayerFootAndSkills } from '../utils/playerFootSkills';
import { SUPER_LIG_TEAMS } from '../data/superLigTeams';
import { SPANISH_TEAMS } from '../data/spanishTeams';
import { ENGLISH_TEAMS } from '../data/englishTeams';
import { BUNDESLIGA_TEAMS } from '../data/bundesligaTeams';
import { SERIE_A_TEAMS } from '../data/serieATeams';
import { LIGUE1_TEAMS } from '../data/ligue1Teams';
import { ADDITIONAL_EUROPEAN_TEAMS } from '../data/europeanTeams';
import { ensureTeamHas20Players } from '../utils/squadExpander';
import {
  X,
  ArrowLeft,
  Star,
  Search,
  TrendingUp
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  AreaChart,
  Area
} from 'recharts';

interface PlayerProfileModalProps {
  player: Player | null;
  team: Team;
  userTeamId?: string;
  scouts?: Scout[];
  scoutReports?: ScoutReport[];
  favoritePlayerIds?: string[];
  onToggleFavorite?: (playerId: string) => void;
  onClose: () => void;
  onOpenContractModal?: (player: Player) => void;
  onOpenCountryModal?: (countryName: string) => void;
  onOpenTeamModal?: (team: Team) => void;
  onAssignScout?: (playerId: string, playerName: string) => void;
  onOpenScoutManagement?: () => void;
  onOpenOfferModal?: (player: Player, team: Team, initialType: 'BUY' | 'LOAN') => void;
}

// Mini Pitch SVG position visualizer with Dark Green (Primary) & Light Green (Secondary)
const PositionPitch: React.FC<{ player: Player }> = ({ player }) => {
  const pos = (player.position || 'RW').toUpperCase();
  const role = (player.specificRole || pos).toUpperCase();
  let primaryDots: { x: number; y: number }[] = [];
  let secondaryDots: { x: number; y: number }[] = [];

  if (role === 'RW' || role === 'RM' || (pos === 'FW' && role.includes('RW'))) {
    primaryDots = [{ x: 80, y: 30 }, { x: 80, y: 55 }];
    secondaryDots = [{ x: 20, y: 30 }, { x: 50, y: 42 }, { x: 50, y: 22 }];
  } else if (role === 'LW' || role === 'LM' || (pos === 'FW' && role.includes('LW'))) {
    primaryDots = [{ x: 20, y: 30 }, { x: 20, y: 55 }];
    secondaryDots = [{ x: 80, y: 30 }, { x: 50, y: 42 }, { x: 50, y: 22 }];
  } else if (pos === 'FW' || role === 'ST' || role === 'CF') {
    primaryDots = [{ x: 50, y: 20 }];
    secondaryDots = [{ x: 50, y: 38 }, { x: 20, y: 30 }, { x: 80, y: 30 }];
  } else if (role === 'CAM' || role === 'AM') {
    primaryDots = [{ x: 50, y: 42 }];
    secondaryDots = [{ x: 50, y: 60 }, { x: 20, y: 30 }, { x: 80, y: 30 }, { x: 50, y: 22 }];
  } else if (role === 'CDM' || role === 'DM') {
    primaryDots = [{ x: 50, y: 72 }];
    secondaryDots = [{ x: 50, y: 58 }, { x: 50, y: 88 }];
  } else if (pos === 'MID' || role === 'CM') {
    primaryDots = [{ x: 50, y: 58 }];
    secondaryDots = [{ x: 30, y: 58 }, { x: 70, y: 58 }, { x: 50, y: 42 }, { x: 50, y: 72 }];
  } else if (role === 'LB' || role === 'LWB') {
    primaryDots = [{ x: 18, y: 88 }];
    secondaryDots = [{ x: 20, y: 55 }, { x: 35, y: 88 }];
  } else if (role === 'RB' || role === 'RWB') {
    primaryDots = [{ x: 82, y: 88 }];
    secondaryDots = [{ x: 80, y: 55 }, { x: 65, y: 88 }];
  } else if (pos === 'DEF' || role === 'CB') {
    primaryDots = [{ x: 50, y: 88 }, { x: 35, y: 88 }, { x: 65, y: 88 }];
    secondaryDots = [{ x: 50, y: 72 }, { x: 18, y: 88 }, { x: 82, y: 88 }];
  } else if (pos === 'GK') {
    primaryDots = [{ x: 50, y: 104 }];
    secondaryDots = [];
  } else {
    primaryDots = [{ x: 50, y: 50 }];
    secondaryDots = [];
  }

  return (
    <div className="relative w-full h-full min-h-0 bg-[#0c0919] border border-[#231b38] rounded-md overflow-hidden flex flex-col items-center justify-between p-1">
      <div className="flex-1 w-full min-h-0 flex items-center justify-center">
        <svg viewBox="0 0 100 120" className="w-full h-full max-h-[90px] stroke-slate-500/60 fill-none stroke-[1.2] object-contain">
          {/* Pitch Boundary */}
          <rect x="5" y="5" width="90" height="110" rx="3" />
          {/* Halfway line */}
          <line x1="5" y1="60" x2="95" y2="60" />
          {/* Center circle */}
          <circle cx="50" cy="60" r="14" />
          <circle cx="50" cy="60" r="1.5" className="fill-slate-500" />
          {/* Top Penalty Box */}
          <rect x="25" y="5" width="50" height="22" />
          <rect x="35" y="5" width="30" height="8" />
          {/* Bottom Penalty Box */}
          <rect x="25" y="93" width="50" height="22" />
          <rect x="35" y="107" width="30" height="8" />

          {/* Secondary Positions (Light Green) */}
          {secondaryDots.map((d, i) => (
            <circle
              key={`sec-${i}`}
              cx={d.x}
              cy={d.y}
              r="3.5"
              className="fill-emerald-500/80 stroke-emerald-300/60 stroke-0.5"
            />
          ))}

          {/* Primary Natural Positions (Dark Green + Glowing Pulse) */}
          {primaryDots.map((d, i) => (
            <g key={`pri-${i}`}>
              <circle cx={d.x} cy={d.y} r="7" className="fill-emerald-500/30 animate-pulse" />
              <circle
                cx={d.x}
                cy={d.y}
                r="4.5"
                className="fill-emerald-400 stroke-emerald-100 stroke-1 shadow-lg"
              />
            </g>
          ))}
        </svg>
      </div>
      <div className="flex items-center justify-center gap-1.5 text-[6px] sm:text-[6.5px] text-slate-400 font-bold shrink-0 leading-none pt-0.5">
        <span className="flex items-center gap-0.5"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block"></span> Ana Mevki</span>
        <span className="flex items-center gap-0.5"><span className="w-1.5 h-1.5 rounded-full bg-emerald-600 inline-block"></span> Yan Mevki</span>
      </div>
    </div>
  );
};

// Circular Rating Gauge for Average Match Rating
const RatingCircularGauge: React.FC<{ rating: number }> = ({ rating }) => {
  const radius = 15;
  const circumference = 2 * Math.PI * radius;
  const normalizedRating = Math.min(10, Math.max(0, rating));
  const strokeDashoffset = circumference - (normalizedRating / 10) * circumference;

  return (
    <div className="relative w-8 h-8 sm:w-10 sm:h-10 landscape:w-8 landscape:h-8 flex items-center justify-center shrink-0">
      <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 40 40">
        <circle
          cx="20"
          cy="20"
          r={radius}
          className="stroke-[#1d2736]"
          strokeWidth="3.5"
          fill="transparent"
        />
        <circle
          cx="20"
          cy="20"
          r={radius}
          className="stroke-emerald-400 transition-all duration-1000 ease-out"
          strokeWidth="3.5"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          fill="transparent"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <span className="text-[8.5px] sm:text-[10px] font-black text-white leading-none">
          {normalizedRating.toFixed(2)}
        </span>
        <span className="text-[5px] font-black text-slate-400 tracking-wider uppercase leading-none mt-0.5">
          ORT PUA
        </span>
      </div>
    </div>
  );
};

// Star Rating Component (5-Star)
const StarRating: React.FC<{ rating: number }> = ({ rating }) => {
  const stars = [1, 2, 3, 4, 5];
  return (
    <div className="flex items-center gap-0.5 text-amber-400 text-[8px] sm:text-[9px]">
      {stars.map((s) => (
        <span key={s}>{s <= rating ? '★' : '☆'}</span>
      ))}
    </div>
  );
};

// Helper for FM style attribute color coding
const getAttributeBadgeStyle = (score: number) => {
  if (score >= 16) {
    return {
      pillBg: 'bg-emerald-500 text-slate-950 font-black shadow-sm shadow-emerald-500/40 ring-1 ring-emerald-300/50',
      barGrad: 'bg-gradient-to-r from-emerald-400 via-green-300 to-emerald-200',
      labelColor: 'text-emerald-300 font-extrabold'
    };
  }
  if (score >= 13) {
    return {
      pillBg: 'bg-teal-500/25 border border-teal-400/60 text-teal-300 font-black',
      barGrad: 'bg-gradient-to-r from-teal-500 to-emerald-400',
      labelColor: 'text-slate-200 font-bold'
    };
  }
  if (score >= 10) {
    return {
      pillBg: 'bg-amber-500/20 border border-amber-400/50 text-amber-300 font-extrabold',
      barGrad: 'bg-gradient-to-r from-amber-500 to-yellow-400',
      labelColor: 'text-slate-300 font-medium'
    };
  }
  return {
    pillBg: 'bg-slate-800/80 border border-slate-700/60 text-slate-400 font-bold',
    barGrad: 'bg-gradient-to-r from-slate-600 to-slate-500',
    labelColor: 'text-slate-400 font-normal'
  };
};





/* const REAL_PLAYER_CAREER_MAP: Record<string, TransfermarktCareerRow[]> = {
  // Victor Osimhen
  'victorosimhen': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.2 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Kiralık (Napoli)', caps: 32, goals: 26, assists: 5, rating: 8.1 },
    { season: '2023/24', club: 'Napoli', league: 'Serie A', transferType: 'Sözleşme', caps: 32, goals: 17, assists: 4, rating: 7.7 },
    { season: '2022/23', club: 'Napoli', league: 'Serie A', transferType: 'Sözleşme', caps: 39, goals: 31, assists: 5, rating: 8.3 },
    { season: '2021/22', club: 'Napoli', league: 'Serie A', transferType: 'Sözleşme', caps: 32, goals: 18, assists: 6, rating: 7.6 },
    { season: '2020/21', club: 'Napoli', league: 'Serie A', transferType: '€77.5M', caps: 30, goals: 10, assists: 3, rating: 7.2 },
    { season: '2019/20', club: 'Lille', league: 'Ligue 1', transferType: '€22.4M', caps: 38, goals: 18, assists: 6, rating: 7.5 },
    { season: '2018/19', club: 'Charleroi', league: 'Pro League', transferType: '€3.5M', caps: 36, goals: 20, assists: 4, rating: 7.4 }
  ],
  // Mauro Icardi
  'mauroicardi': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.0 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 14, goals: 6, assists: 2, rating: 7.6 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: '€10.0M', caps: 47, goals: 32, assists: 12, rating: 8.2 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Kiralık (PSG)', caps: 26, goals: 23, assists: 8, rating: 8.4 },
    { season: '2021/22', club: 'Paris SG', league: 'Ligue 1', transferType: 'Sözleşme', caps: 30, goals: 5, assists: 0, rating: 6.9 },
    { season: '2020/21', club: 'Paris SG', league: 'Ligue 1', transferType: '€50.0M', caps: 28, goals: 13, assists: 6, rating: 7.3 },
    { season: '2019/20', club: 'Paris SG', league: 'Ligue 1', transferType: 'Kiralık (Inter)', caps: 34, goals: 20, assists: 4, rating: 7.5 },
    { season: '2018/19', club: 'Inter', league: 'Serie A', transferType: 'Sözleşme', caps: 37, goals: 17, assists: 5, rating: 7.4 }
  ],
  // Edin Dzeko
  'edindzeko': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 38, goals: 21, assists: 6, rating: 7.7 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 46, goals: 25, assists: 10, rating: 7.9 },
    { season: '2022/23', club: 'Inter', league: 'Serie A', transferType: 'Sözleşme', caps: 52, goals: 14, assists: 5, rating: 7.3 },
    { season: '2021/22', club: 'Inter', league: 'Serie A', transferType: '€2.8M', caps: 49, goals: 17, assists: 10, rating: 7.4 },
    { season: '2020/21', club: 'AS Roma', league: 'Serie A', transferType: 'Sözleşme', caps: 38, goals: 13, assists: 5, rating: 7.1 },
    { season: '2019/20', club: 'AS Roma', league: 'Serie A', transferType: 'Sözleşme', caps: 43, goals: 19, assists: 14, rating: 7.6 }
  ],
  // Fernando Muslera
  'fernandomuslera': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme Yenilendi', caps: 37, goals: 0, assists: 0, rating: 7.6 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 52, goals: 0, assists: 0, rating: 7.8 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 35, goals: 0, assists: 0, rating: 7.8 },
    { season: '2021/22', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 36, goals: 0, assists: 0, rating: 7.2 },
    { season: '2020/21', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 22, goals: 0, assists: 0, rating: 7.4 },
    { season: '2019/20', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 35, goals: 0, assists: 0, rating: 7.6 }
  ],
  // Dusan Tadic
  'dusantadic': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.9 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 38, goals: 12, assists: 15, rating: 7.8 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 56, goals: 16, assists: 16, rating: 8.0 },
    { season: '2022/23', club: 'Ajax', league: 'Eredivisie', transferType: 'Sözleşme', caps: 47, goals: 13, assists: 21, rating: 8.1 },
    { season: '2021/22', club: 'Ajax', league: 'Eredivisie', transferType: 'Sözleşme', caps: 45, goals: 16, assists: 22, rating: 8.2 },
    { season: '2020/21', club: 'Ajax', league: 'Eredivisie', transferType: 'Sözleşme', caps: 51, goals: 22, assists: 26, rating: 8.3 }
  ],
  // Fred
  'fred': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 35, goals: 4, assists: 8, rating: 7.6 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€9.7M', caps: 35, goals: 3, assists: 8, rating: 7.8 },
    { season: '2022/23', club: 'Manchester Utd', league: 'Premier League', transferType: 'Sözleşme', caps: 56, goals: 6, assists: 6, rating: 7.2 },
    { season: '2021/22', club: 'Manchester Utd', league: 'Premier League', transferType: 'Sözleşme', caps: 36, goals: 4, assists: 6, rating: 7.1 }
  ],
  // Lucas Torreira
  'lucastorreira': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 36, goals: 1, assists: 3, rating: 7.7 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 47, goals: 1, assists: 3, rating: 7.8 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: '€6.0M', caps: 34, goals: 0, assists: 1, rating: 7.7 },
    { season: '2021/22', club: 'Fiorentina', league: 'Serie A', transferType: 'Kiralık (Arsenal)', caps: 35, goals: 5, assists: 2, rating: 7.4 }
  ],
  // Baris Alper Yilmaz
  'barisalperyilmaz': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 37, goals: 9, assists: 7, rating: 7.7 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 55, goals: 7, assists: 12, rating: 7.8 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 30, goals: 4, assists: 2, rating: 7.2 },
    { season: '2021/22', club: 'Galatasaray', league: 'Süper Lig', transferType: '€2.1M', caps: 23, goals: 0, assists: 1, rating: 6.8 },
    { season: '2020/21', club: 'Keçiörengücü', league: '1. Lig', transferType: 'Transfer', caps: 36, goals: 8, assists: 5, rating: 7.4 }
  ],
  // Davinson Sanchez
  'davinsonsanchez': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.9 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 32, goals: 3, assists: 2, rating: 7.8 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: '€9.5M', caps: 32, goals: 3, assists: 2, rating: 7.9 },
    { season: '2022/23', club: 'Tottenham', league: 'Premier League', transferType: 'Sözleşme', caps: 24, goals: 0, assists: 0, rating: 7.0 },
    { season: '2021/22', club: 'Tottenham', league: 'Premier League', transferType: 'Sözleşme', caps: 32, goals: 2, assists: 1, rating: 7.2 }
  ],
  // Kerem Akturkoglu
  'keremakturkoglu': [
    { season: '2025/26', club: 'Benfica', league: 'Liga Portugal', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Benfica', league: 'Liga Portugal', transferType: '€12.0M', caps: 35, goals: 11, assists: 8, rating: 7.7 },
    { season: '2023/24', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 54, goals: 15, assists: 9, rating: 7.6 },
    { season: '2022/23', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 38, goals: 10, assists: 12, rating: 7.8 },
    { season: '2021/22', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Sözleşme', caps: 52, goals: 13, assists: 13, rating: 7.6 }
  ],
  // Arda Guler
  'ardaguler': [
    { season: '2025/26', club: 'Real Madrid', league: 'La Liga', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Real Madrid', league: 'La Liga', transferType: 'Sözleşme', caps: 26, goals: 6, assists: 5, rating: 7.6 },
    { season: '2023/24', club: 'Real Madrid', league: 'La Liga', transferType: '€20.0M', caps: 12, goals: 6, assists: 0, rating: 7.9 },
    { season: '2022/23', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'A Takım', caps: 35, goals: 6, assists: 7, rating: 8.0 },
    { season: '2021/22', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Altyapı / Pro', caps: 16, goals: 3, assists: 5, rating: 7.7 }
  ],
  // Ugurcan Cakir
  'ugurcancakir': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Sözleşme', caps: 38, goals: 0, assists: 0, rating: 7.7 },
    { season: '2023/24', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Kaptan', caps: 40, goals: 0, assists: 0, rating: 7.6 },
    { season: '2022/23', club: 'Trabzonspor', league: 'Süper Lig', transferType: 'Kaptan', caps: 44, goals: 0, assists: 0, rating: 7.8 }
  ],
  // Semih Kilicsoy
  'semihkilicsoy': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 30, goals: 8, assists: 4, rating: 7.5 },
    { season: '2023/24', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'A Takım', caps: 35, goals: 12, assists: 3, rating: 7.8 }
  ],
  // Ciro Immobile
  'ciroimmobile': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 32, goals: 14, assists: 3, rating: 7.7 },
    { season: '2023/24', club: 'Lazio', league: 'Serie A', transferType: 'Sözleşme', caps: 43, goals: 11, assists: 1, rating: 7.2 },
    { season: '2022/23', club: 'Lazio', league: 'Serie A', transferType: 'Sözleşme', caps: 38, goals: 14, assists: 5, rating: 7.4 }
  ],
  // Rafa Silva
  'rafasilva': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.9 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 35, goals: 11, assists: 9, rating: 7.8 },
    { season: '2023/24', club: 'Benfica', league: 'Liga Portugal', transferType: 'Sözleşme', caps: 52, goals: 22, assists: 15, rating: 8.2 },
    { season: '2022/23', club: 'Benfica', league: 'Liga Portugal', transferType: 'Sözleşme', caps: 47, goals: 14, assists: 14, rating: 8.0 }
  ],
  // Gedson Fernandes
  'gedsonfernandes': [
    { season: '2025/26', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 36, goals: 7, assists: 5, rating: 7.6 },
    { season: '2023/24', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Sözleşme', caps: 45, goals: 3, assists: 6, rating: 7.5 },
    { season: '2022/23', club: 'Beşiktaş', league: 'Süper Lig', transferType: '€6.0M', caps: 36, goals: 3, assists: 7, rating: 7.6 },
    { season: '2021/22', club: 'Rizespor', league: 'Süper Lig', transferType: 'Kiralık (Benfica)', caps: 11, goals: 3, assists: 3, rating: 7.8 },
    { season: '2020/21', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Kiralık (Benfica)', caps: 18, goals: 1, assists: 3, rating: 7.5 }
  ],
  // Sofyan Amrabat
  'sofyanamrabat': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Kiralık (Fiorentina)', caps: 31, goals: 2, assists: 3, rating: 7.6 },
    { season: '2023/24', club: 'Manchester Utd', league: 'Premier League', transferType: 'Kiralık (Fiorentina)', caps: 30, goals: 0, assists: 0, rating: 7.1 },
    { season: '2022/23', club: 'Fiorentina', league: 'Serie A', transferType: 'Sözleşme', caps: 49, goals: 0, assists: 1, rating: 7.4 }
  ],
  // Youssef En-Nesyri
  'youssefennesyri': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€19.5M', caps: 36, goals: 16, assists: 3, rating: 7.7 },
    { season: '2023/24', club: 'Sevilla FC', league: 'La Liga', transferType: 'Sözleşme', caps: 41, goals: 20, assists: 3, rating: 7.6 },
    { season: '2022/23', club: 'Sevilla FC', league: 'La Liga', transferType: 'Sözleşme', caps: 48, goals: 18, assists: 2, rating: 7.5 }
  ],
  // Dominik Livakovic
  'dominiklivakovic': [
    { season: '2025/26', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 35, goals: 0, assists: 0, rating: 7.6 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€6.6M', caps: 40, goals: 0, assists: 0, rating: 7.7 },
    { season: '2022/23', club: 'Dinamo Zagreb', league: 'HNL', transferType: 'Kaptan', caps: 49, goals: 0, assists: 0, rating: 7.8 }
  ],
  // Gabriel Sara
  'gabrielsara': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.8 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: '€18.0M', caps: 35, goals: 5, assists: 8, rating: 7.7 },
    { season: '2023/24', club: 'Norwich City', league: 'Championship', transferType: 'Sözleşme', caps: 53, goals: 14, assists: 12, rating: 8.0 },
    { season: '2022/23', club: 'Norwich City', league: 'Championship', transferType: '€10.5M', caps: 43, goals: 7, assists: 4, rating: 7.5 }
  ],
  // Roland Sallai
  'rolandsallai': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.6 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: '€6.0M', caps: 28, goals: 4, assists: 3, rating: 7.4 },
    { season: '2023/24', club: 'SC Freiburg', league: 'Bundesliga', transferType: 'Sözleşme', caps: 37, goals: 8, assists: 4, rating: 7.5 }
  ],
  // Michy Batshuayi
  'michybatshuayi': [
    { season: '2025/26', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 7.7 },
    { season: '2024/25', club: 'Galatasaray', league: 'Süper Lig', transferType: 'Bonservissiz', caps: 32, goals: 8, assists: 3, rating: 7.5 },
    { season: '2023/24', club: 'Fenerbahçe', league: 'Süper Lig', transferType: 'Sözleşme', caps: 43, goals: 24, assists: 3, rating: 7.9 },
    { season: '2022/23', club: 'Fenerbahçe', league: 'Süper Lig', transferType: '€3.5M', caps: 32, goals: 20, assists: 2, rating: 7.8 },
    { season: '2021/22', club: 'Beşiktaş', league: 'Süper Lig', transferType: 'Kiralık (Chelsea)', caps: 42, goals: 14, assists: 5, rating: 7.3 }
  ],
  // Kylian Mbappe
  'kylianmbappe': [
    { season: '2025/26', club: 'Real Madrid', league: 'La Liga', transferType: 'Mevcut Kulüp', caps: 0, goals: 0, assists: 0, rating: 8.5 },
    { season: '2024/25', club: 'Real Madrid', league: 'La Liga', transferType: 'Bonservissiz', caps: 38, goals: 28, assists: 8, rating: 8.4 },
    { season: '2023/24', club: 'Paris SG', league: 'Ligue 1', transferType: 'Sözleşme', caps: 48, goals: 44, assists: 10, rating: 8.6 },
    { season: '2022/23', club: 'Paris SG', league: 'Ligue 1', transferType: 'Sözleşme', caps: 43, goals: 41, assists: 10, rating: 8.5 }
  ]
}; */



// Known player height and weight lookup (Height in cm, Weight in kg)
const KNOWN_PLAYER_PHYSICALS: Record<string, { height: number; weight: number }> = {
  'victorosimhen': { height: 185, weight: 78 },
  'mauroicardi': { height: 181, weight: 75 },
  'ugurcancakir': { height: 191, weight: 84 },
  'wilfriedsingo': { height: 190, weight: 81 },
  'davinsonsanchez': { height: 187, weight: 81 },
  'abdulkerimbardakci': { height: 185, weight: 82 },
  'erenelmali': { height: 181, weight: 74 },
  'lucastorreira': { height: 166, weight: 65 },
  'ilkaygundogan': { height: 180, weight: 80 },
  'gabrielsara': { height: 177, weight: 76 },
  'leroysane': { height: 183, weight: 80 },
  'barisalperyilmaz': { height: 186, weight: 80 },
  'fernandomuslera': { height: 190, weight: 84 },
  'gunayguvenc': { height: 187, weight: 83 },
  'victornelsson': { height: 185, weight: 81 },
  'kaanayhan': { height: 185, weight: 80 },
  'eliasjelert': { height: 178, weight: 70 },
  'ismailjakobs': { height: 184, weight: 77 },
  'mariolemina': { height: 184, weight: 85 },
  'yunusakgun': { height: 173, weight: 68 },
  'rolandsallai': { height: 183, weight: 75 },
  'michybatshuayi': { height: 185, weight: 88 },
  'berkankutlu': { height: 186, weight: 80 },
  'hakanziyech': { height: 181, weight: 73 },
  'driesmertens': { height: 169, weight: 61 },
  'keremdemirbay': { height: 183, weight: 78 },
  'edindzeko': { height: 193, weight: 84 },
  'dusantadic': { height: 181, weight: 76 },
  'fred': { height: 169, weight: 64 },
  'sofyanamrabat': { height: 185, weight: 86 },
  'youssefennesyri': { height: 192, weight: 84 },
  'dominiklivakovic': { height: 188, weight: 79 },
  'ederson': { height: 188, weight: 86 },
  'nelsonsemedo': { height: 177, weight: 69 },
  'milanskriniar': { height: 188, weight: 82 },
  'alexanderdjiku': { height: 182, weight: 81 },
  'caglarsoyuncu': { height: 187, weight: 82 },
  'jaydenoosterwolde': { height: 189, weight: 83 },
  'rodrigobecao': { height: 191, weight: 84 },
  'sebastianszymanski': { height: 174, weight: 68 },
  'ismailyuksek': { height: 183, weight: 75 },
  'irfancankahveci': { height: 176, weight: 71 },
  'allansaintmaximin': { height: 173, weight: 72 },
  'andersontalisca': { height: 191, weight: 80 },
  'cengizunder': { height: 173, weight: 66 },
  'cenktosun': { height: 183, weight: 78 },
  'oguzaydin': { height: 181, weight: 75 },
  'brightosayisamuel': { height: 175, weight: 73 },
  'mertgunok': { height: 196, weight: 92 },
  'gabrielpaulista': { height: 187, weight: 82 },
  'felixuduokhai': { height: 193, weight: 89 },
  'jonassvensson': { height: 170, weight: 70 },
  'arthurmasuaku': { height: 179, weight: 79 },
  'gedsonfernandes': { height: 183, weight: 71 },
  'almusrati': { height: 189, weight: 83 },
  'rafasilva': { height: 172, weight: 62 },
  'milotrashica': { height: 177, weight: 73 },
  'joaomario': { height: 179, weight: 73 },
  'semihkilicsoy': { height: 178, weight: 78 },
  'ciroimmobile': { height: 185, weight: 85 },
  'ernestmuci': { height: 180, weight: 73 },
  'stefansavic': { height: 187, weight: 79 },
  'pedromalheiro': { height: 179, weight: 72 },
  'bornabarisic': { height: 186, weight: 80 },
  'johnlundstram': { height: 183, weight: 80 },
  'batistamendy': { height: 191, weight: 82 },
  'edinvisca': { height: 172, weight: 63 },
  'anthonynwakaeme': { height: 185, weight: 84 },
  'denisdragus': { height: 185, weight: 78 },
  'simonbanza': { height: 189, weight: 82 },
  'ozantufan': { height: 182, weight: 80 },
  'okayyokuslu': { height: 191, weight: 86 },
  'krzysztofpiatek': { height: 183, weight: 77 },
  'mamethiam': { height: 185, weight: 80 },
  'reymanaj': { height: 182, weight: 76 },
  'ardaguler': { height: 175, weight: 70 },
  'keremakturkoglu': { height: 173, weight: 68 },
  'ferdikadioglu': { height: 174, weight: 68 },
  'hakancalhanoglu': { height: 178, weight: 73 },
  'kenanyildiz': { height: 185, weight: 78 },
  'yusufyazici': { height: 183, weight: 78 },
  'merihdemiral': { height: 190, weight: 85 },
  'zekicelik': { height: 180, weight: 78 },
  'enesunal': { height: 187, weight: 83 },
  'orkunkokcu': { height: 175, weight: 70 },
  'salihozcan': { height: 182, weight: 78 },
  'kylianmbappe': { height: 178, weight: 75 },
  'viniciusjunior': { height: 176, weight: 73 },
  'judebellingham': { height: 186, weight: 75 },
  'erlinghaaland': { height: 195, weight: 88 },
  'kevindebruyne': { height: 181, weight: 75 },
  'mohamedsalah': { height: 175, weight: 71 },
  'robertlewandowski': { height: 185, weight: 81 },
  'lamineyamal': { height: 180, weight: 72 }
};

// Known player annual salary lookup (in € / year)
const KNOWN_PLAYER_WAGES: Record<string, number> = {
  'victorosimhen': 12000000,
  'mauroicardi': 10000000,
  'ugurcancakir': 3800000,
  'wilfriedsingo': 3000000,
  'davinsonsanchez': 4500000,
  'abdulkerimbardakci': 2800000,
  'erenelmali': 1800000,
  'lucastorreira': 4500000,
  'ilkaygundogan': 10000000,
  'gabrielsara': 4000000,
  'leroysane': 15000000,
  'barisalperyilmaz': 3500000,
  'fernandomuslera': 4000000,
  'gunayguvenc': 900000,
  'victornelsson': 2200000,
  'kaanayhan': 1800000,
  'eliasjelert': 1600000,
  'ismailjakobs': 2000000,
  'mariolemina': 3000000,
  'yunusakgun': 2500000,
  'rolandsallai': 3000000,
  'michybatshuayi': 4000000,
  'berkankutlu': 1400000,
  'hakanziyech': 5000000,
  'driesmertens': 4500000,
  'keremdemirbay': 2500000,
  'edindzeko': 6500000,
  'dusantadic': 6500000,
  'fred': 6000000,
  'sofyanamrabat': 4500000,
  'youssefennesyri': 6500000,
  'dominiklivakovic': 3500000,
  'ederson': 8500000,
  'nelsonsemedo': 4500000,
  'milanskriniar': 7000000,
  'alexanderdjiku': 2800000,
  'caglarsoyuncu': 4000000,
  'jaydenoosterwolde': 2200000,
  'rodrigobecao': 2800000,
  'sebastianszymanski': 4000000,
  'ismailyuksek': 2000000,
  'irfancankahveci': 3500000,
  'allansaintmaximin': 8500000,
  'andersontalisca': 11000000,
  'cengizunder': 4000000,
  'cenktosun': 3000000,
  'oguzaydin': 1800000,
  'brightosayisamuel': 2200000,
  'mertgunok': 2200000,
  'gabrielpaulista': 3500000,
  'felixuduokhai': 2500000,
  'jonassvensson': 1500000,
  'arthurmasuaku': 2000000,
  'gedsonfernandes': 3500000,
  'almusrati': 3500000,
  'rafasilva': 8000000,
  'milotrashica': 3000000,
  'joaomario': 3500000,
  'semihkilicsoy': 2000000,
  'ciroimmobile': 8000000,
  'ernestmuci': 2800000,
  'stefansavic': 3500000,
  'pedromalheiro': 1400000,
  'bornabarisic': 1800000,
  'johnlundstram': 2200000,
  'batistamendy': 2200000,
  'edinvisca': 2800000,
  'anthonynwakaeme': 2200000,
  'denisdragus': 1800000,
  'simonbanza': 2800000,
  'ozantufan': 2000000,
  'okayyokuslu': 2200000,
  'krzysztofpiatek': 3200000,
  'mamethiam': 1800000,
  'reymanaj': 1800000,
  'ardaguler': 6000000,
  'keremakturkoglu': 3800000,
  'ferdikadioglu': 4500000,
  'hakancalhanoglu': 8000000,
  'kenanyildiz': 3500000,
  'kylianmbappe': 25000000,
  'viniciusjunior': 20000000,
  'judebellingham': 18000000,
  'erlinghaaland': 24000000,
  'kevindebruyne': 20000000,
  'mohamedsalah': 20000000,
  'robertlewandowski': 15000000,
  'lamineyamal': 6000000
};

const getPlayerPhysicals = (player: Player) => {
  const pAny = player as any;
  if (pAny.height && pAny.weight) {
    return { height: pAny.height, weight: pAny.weight };
  }
  const nameNorm = player.name
    .toLowerCase()
    .trim()
    .replace(/ı/g, 'i').replace(/ğ/g, 'g').replace(/ş/g, 's').replace(/ç/g, 'c').replace(/ö/g, 'o').replace(/ü/g, 'u')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
  if (KNOWN_PLAYER_PHYSICALS[nameNorm]) {
    return KNOWN_PLAYER_PHYSICALS[nameNorm];
  }
  let hash = 0;
  for (let i = 0; i < player.name.length; i++) hash = (hash << 5) - hash + player.name.charCodeAt(i);
  const seed = Math.abs(hash);

  let baseHeight = 178;
  if (player.position === 'GK') {
    baseHeight = 187 + (seed % 9);
  } else if (player.position === 'DEF') {
    if (player.specificRole === 'CB') baseHeight = 184 + (seed % 9);
    else baseHeight = 174 + (seed % 9);
  } else if (player.position === 'FW') {
    if (player.specificRole === 'ST' || player.specificRole === 'CF') baseHeight = 180 + (seed % 12);
    else baseHeight = 172 + (seed % 10);
  } else {
    baseHeight = 172 + (seed % 12);
  }

  const baseWeight = Math.round((baseHeight - 100) * 0.9 + ((seed % 7) - 3));
  return { height: baseHeight, weight: Math.max(60, Math.min(95, baseWeight)) };
};

// Detailed Player Stats Generator per player
const generatePlayerDetailedStats = (player: Player) => {
  let hash = 0;
  const seedStr = player.id + player.name + player.overall;
  for (let i = 0; i < seedStr.length; i++) hash = (hash << 5) - hash + seedStr.charCodeAt(i);
  const seed = Math.abs(hash);

  const appearances = player.appearances ?? 0;
  const goals = player.goalsScored ?? 0;
  const assists = player.assists ?? 0;

  // When 0 appearances (at start of game/season)
  if (appearances === 0) {
    return {
      shotAcc: 0,
      passAcc: 0,
      keyPasses: "0.0",
      dribbles: "0.0",
      tackles: "0.0",
      duelsWonPct: 0,
      aerialWonPct: 0,
      motmCount: 0,
      xG: "0.00",
      xA: "0.00",
      distKm: "0.0",
      yellowCards: player.yellowCards ?? 0,
      redCards: player.redCards ?? 0,
      appearances: 0,
      goals: 0,
      assists: 0,
      cleanSheets: 0,
      goalsConceded: 0,
      savePct: 0,
      savesPerMatch: "0.0",
      avgRating: "-"
    };
  }

  const shotAcc = Math.min(88, Math.max(48, Math.round(player.attributes.shooting * 0.72 + (seed % 12))));
  const passAcc = Math.min(94, Math.max(68, Math.round(player.attributes.passing * 0.82 + (seed % 10))));
  const keyPasses = ((player.attributes.passing / 100) * 2.8 + (seed % 8) * 0.1).toFixed(1);
  const dribbles = ((player.attributes.pace / 100) * 3.2 + (seed % 6) * 0.1).toFixed(1);
  const tackles = ((player.attributes.defending / 100) * 3.5 + (seed % 5) * 0.1).toFixed(1);
  const duelsWonPct = Math.min(82, Math.max(42, Math.round(player.attributes.physical * 0.75 + (seed % 10))));
  const aerialWonPct = Math.min(85, Math.max(38, Math.round(player.attributes.physical * 0.78 + ((seed + 3) % 10))));
  const motmCount = Math.min(appearances, Math.round((goals + assists) * 0.6 + (seed % 2)));

  const xG = (goals * 0.9 + 0.15 * (seed % 4)).toFixed(2);
  const xA = (assists * 0.85 + 0.12 * (seed % 3)).toFixed(2);
  const distKm = (10.2 + (player.stamina / 100) * 1.5 + (seed % 5) * 0.1).toFixed(1);

  // GK specific
  const cleanSheets = Math.min(appearances, Math.round(appearances * 0.38));
  const goalsConceded = Math.round(appearances * 0.92);
  const savePct = Math.min(88, Math.max(64, Math.round(72 + (player.overall - 75) * 0.6)));
  const savesPerMatch = (3.1 + (player.overall / 100) * 0.7 + (seed % 4) * 0.1).toFixed(1);
  const avgRating = appearances > 0 ? (player.averageRating ? player.averageRating.toFixed(2) : (player.form || 7.2).toFixed(2)) : '0.00';

  return {
    shotAcc,
    passAcc,
    keyPasses,
    dribbles,
    tackles,
    duelsWonPct,
    aerialWonPct,
    motmCount: Math.max(0, motmCount),
    xG,
    xA,
    distKm,
    yellowCards: player.yellowCards ?? 0,
    redCards: player.redCards ?? 0,
    appearances,
    goals,
    assists,
    cleanSheets,
    goalsConceded,
    savePct,
    savesPerMatch,
    avgRating
  };
};

export const PlayerProfileModal: React.FC<PlayerProfileModalProps> = ({
  player,
  team,
  userTeamId,
  scouts = [],
  scoutReports = [],
  favoritePlayerIds,
  onToggleFavorite,
  onClose,
  onOpenContractModal,
  onOpenCountryModal,
  onOpenTeamModal,
  onAssignScout,
  onOpenScoutManagement,
  onOpenOfferModal
}) => {
  const { t } = useTranslation();
  const [showScoutPrompt, setShowScoutPrompt] = useState(false);
  const [showPastSeasonsModal, setShowPastSeasonsModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'GENEL' | 'DETAYLAR' | 'KARİYER' | 'İSTATİSTİKLER'>('GENEL');
  const [localFavs, setLocalFavs] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('fmm_favorites') || '[]');
    } catch {
      return [];
    }
  });

  const isShortlisted = player ? (favoritePlayerIds ? favoritePlayerIds.includes(player.id) : localFavs.includes(player.id)) : false;

  const handleToggleStar = () => {
    if (!player) return;
    if (onToggleFavorite) {
      onToggleFavorite(player.id);
    } else {
      const next = localFavs.includes(player.id) ? localFavs.filter(id => id !== player.id) : [...localFavs, player.id];
      setLocalFavs(next);
      try {
        localStorage.setItem('fmm_favorites', JSON.stringify(next));
      } catch (e) {
        console.error(e);
      }
    }
  };

  const [activeRoleKey, setActiveRoleKey] = useState<string>('ROLE_WING_FORWARD');

  if (!player) return null;

  const handleOpenCareerClub = (clubName: string, leagueName?: string) => {
    if (!onOpenTeamModal || !clubName) return;

    // Normalize helper
    const clean = (s: string) =>
      s
        .toLowerCase()
        .replace(/ç/g, 'c')
        .replace(/ğ/g, 'g')
        .replace(/ı/g, 'i')
        .replace(/ö/g, 'o')
        .replace(/ş/g, 's')
        .replace(/ü/g, 'u')
        .replace(/[^a-z0-9]/g, '');

    const cleanTarget = clean(clubName);

    const getCoreBrand = (s: string) => {
      let c = clean(s);
      const fillers = ['sk', 'fk', 'sc', 'cf', 'fc', 'vfl', 'vfb', 'sv', '1fc', 'cd', 'rc', 'ud', 'as', 'ogc', 'ss', 'ac', 'us', 'altyapi', 'atakim', 'bbonusr', 'spor', 'kulubu'];
      for (const f of fillers) {
        if (c.endsWith(f) && c.length > f.length + 3) {
          c = c.slice(0, -f.length);
        }
      }
      return c;
    };

    const targetCore = getCoreBrand(clubName);

    // List of all known predefined teams
    const allKnownTeams: Team[] = [
      ...SUPER_LIG_TEAMS,
      ...[...SPANISH_TEAMS, ...ENGLISH_TEAMS, ...BUNDESLIGA_TEAMS, ...SERIE_A_TEAMS, ...LIGUE1_TEAMS, ...ADDITIONAL_EUROPEAN_TEAMS].map(ext => ({
        id: ext.id,
        name: ext.name,
        shortName: ext.shortName,
        badgeColor: ext.badgeColor || 'from-blue-900 to-indigo-900',
        budget: ext.budget,
        overall: ext.overall,
        stadiumName: ext.stadium,
        managerName: ext.manager,
        country: ext.country,
        players: ext.players,
        formation: '4-3-3' as const,
        tactic: 'ATTACKING' as const
      }))
    ];

    let foundTeam: Team | undefined = undefined;

    // 1. Exact full name match
    foundTeam = allKnownTeams.find(t => clean(t.name) === cleanTarget);

    // 2. Core brand name match
    if (!foundTeam) {
      foundTeam = allKnownTeams.find(t => getCoreBrand(t.name) === targetCore);
    }

    // 3. Short name exact match
    if (!foundTeam) {
      foundTeam = allKnownTeams.find(t => t.shortName && clean(t.shortName) === cleanTarget);
    }

    // 4. Known aliases map
    if (!foundTeam) {
      const ALIASES: Record<string, string[]> = {
        'parissg': ['paris sg', 'paris saint germain', 'psg'],
        'realmadrid': ['real madrid', 'r. madrid', 'real madrid cf'],
        'realsociedad': ['real sociedad', 'r. sociedad'],
        'realbetis': ['real betis', 'r. betis'],
        'inter': ['inter', 'inter milan', 'internazionale'],
        'keciorengucu': ['keçiörengücü', 'ankara keçiörengücü', 'keçiörengücü altyapı'],
        'manchesterunited': ['manchester utd', 'man utd', 'manchester united'],
        'manchestercity': ['manchester city', 'man city'],
        'borussiadortmund': ['borussia dortmund', 'dortmund', 'bvb'],
        'bayernmunchen': ['bayern münchen', 'bayern munich', 'bayern'],
        'atleticomadrid': ['atlético madrid', 'atletico madrid', 'atlético'],
        'lazio': ['lazio', 'ss lazio'],
        'asroma': ['roma', 'as roma'],
        'juventus': ['juventus', 'juve'],
        'acmilan': ['ac milan', 'milan'],
        'barcelona': ['fc barcelona', 'barcelona', 'barca'],
        'arsenal': ['arsenal fc', 'arsenal'],
        'chelsea': ['chelsea fc', 'chelsea'],
        'liverpool': ['liverpool fc', 'liverpool'],
        'tottenham': ['tottenham hotspur', 'tottenham', 'spurs'],
        'galatasaray': ['galatasaray', 'galatasaray altyapı', 'gs'],
        'fenerbahce': ['fenerbahçe', 'fenerbahçe altyapı', 'fb'],
        'besiktas': ['beşiktaş', 'beşiktaş altyapı', 'bjk'],
        'trabzonspor': ['trabzonspor', 'trabzonspor altyapı', 'ts'],
      };

      for (const t of allKnownTeams) {
        const key = clean(t.name);
        if (ALIASES[key]) {
          if (ALIASES[key].some(alias => clean(alias) === cleanTarget || clean(alias) === targetCore)) {
            foundTeam = t;
            break;
          }
        }
      }
    }

    // 5. User's current team match
    if (!foundTeam && team) {
      if (clean(team.name) === cleanTarget || getCoreBrand(team.name) === targetCore) {
        foundTeam = team;
      }
    }

    // 6. If found in predefined teams, ensure it has 20 players and open
    if (foundTeam) {
      const populated = ensureTeamHas20Players(foundTeam);
      onOpenTeamModal(populated);
      return;
    }

    // 7. Fallback: generate dynamic team with exact requested club name, inferred country & guaranteed 20 players
    let country = leagueName || 'Avrupa';
    const lowerClub = clubName.toLowerCase();
    if (lowerClub.includes('süper lig') || lowerClub.includes('1. lig') || lowerClub.includes('keçiören') || lowerClub.includes('kasımpaşa') || lowerClub.includes('kayseri') || lowerClub.includes('sivas') || lowerClub.includes('adana') || lowerClub.includes('rize') || lowerClub.includes('gaziantep')) {
      country = 'Türkiye';
    } else if (lowerClub.includes('premier') || lowerClub.includes('championship') || lowerClub.includes('norwich') || lowerClub.includes('brighton') || lowerClub.includes('west brom') || lowerClub.includes('hull') || lowerClub.includes('everton') || lowerClub.includes('bournemouth')) {
      country = 'İngiltere';
    } else if (lowerClub.includes('la liga') || lowerClub.includes('sevill') || lowerClub.includes('getafe') || lowerClub.includes('valenc') || lowerClub.includes('betis')) {
      country = 'İspanya';
    } else if (lowerClub.includes('serie a') || lowerClub.includes('roma') || lowerClub.includes('lazio') || lowerClub.includes('sassuol') || lowerClub.includes('verona') || lowerClub.includes('parma')) {
      country = 'İtalya';
    } else if (lowerClub.includes('bundesliga') || lowerClub.includes('freiburg') || lowerClub.includes('wolfsburg') || lowerClub.includes('mainz') || lowerClub.includes('hoffenheim')) {
      country = 'Almanya';
    } else if (lowerClub.includes('ligue 1') || lowerClub.includes('lille') || lowerClub.includes('monaco') || lowerClub.includes('nice') || lowerClub.includes('strasbourg') || lowerClub.includes('marseille')) {
      country = 'Fransa';
    } else if (lowerClub.includes('liga portugal') || lowerClub.includes('benfica') || lowerClub.includes('braga') || lowerClub.includes('porto') || lowerClub.includes('sporting')) {
      country = 'Portekiz';
    } else if (lowerClub.includes('eredivisie') || lowerClub.includes('feyenoord') || lowerClub.includes('ajax') || lowerClub.includes('nijmegen')) {
      country = 'Hollanda';
    } else if (lowerClub.includes('pro league') || lowerClub.includes('charleroi') || lowerClub.includes('standard')) {
      country = 'Belçika';
    }

    const shortName = clubName.replace(/[^a-zA-Z]/g, '').slice(0, 3).toUpperCase() || 'KUL';
    const baseSynth: Team = {
      id: `career-club-${cleanTarget}`,
      name: clubName,
      shortName,
      badgeColor: 'from-slate-800 to-indigo-900',
      budget: 45000000,
      overall: 80,
      country,
      stadiumName: `${clubName} Stadyumu`,
      managerName: 'Teknik Direktör',
      players: [],
      formation: '4-3-3',
      tactic: 'ATTACKING'
    };

    const synthPopulated = ensureTeamHas20Players(baseSynth);
    onOpenTeamModal(synthPopulated);
  };

  const isUserTeam = userTeamId ? team.id === userTeamId : true;
  const activeReport = scoutReports.find((r) => r.playerId === player.id);
  const activeScout = scouts.find((s) => s.assignedPlayerId === player.id);

  // Individual Max Potential Calculation (PA) per player
  const getPlayerMaxPotential = (p: Player) => {
    if (p.potential) return p.potential;
    let hash = 0;
    const str = p.id + p.name;
    for (let i = 0; i < str.length; i++) hash = (hash << 5) - hash + str.charCodeAt(i);
    const mod = Math.abs(hash) % 7;

    if (p.age <= 21) {
      return Math.min(99, p.overall + 6 + mod);
    } else if (p.age <= 25) {
      return Math.min(99, p.overall + 2 + (mod % 5));
    } else if (p.age <= 29) {
      return Math.min(99, Math.max(p.overall, p.overall + (mod % 3)));
    } else {
      return p.overall;
    }
  };

  const calculatedPotential = getPlayerMaxPotential(player);

  // Convert stats to FM 1-20 scale
  const scale20 = (val: number, isDirect20: boolean = false) => {
    if (isDirect20) return Math.max(1, Math.min(20, Math.round(val)));
    if (val >= 94) return 19 + (val >= 97 ? 1 : 0);
    if (val >= 88) return 17 + Math.floor((val - 88) / 3);
    if (val >= 83) return 15 + Math.floor((val - 83) / 2.5);
    if (val >= 78) return 13 + Math.floor((val - 78) / 2.5);
    if (val >= 72) return 11 + Math.floor((val - 72) / 3);
    if (val >= 65) return 9 + Math.floor((val - 65) / 3.5);
    if (val >= 58) return 7 + Math.floor((val - 58) / 3.5);
    if (val >= 50) return 5 + Math.floor((val - 50) / 4);
    return Math.max(1, Math.floor(val / 10));
  };

  const playerPhys = getPlayerPhysicals(player);
  const heightCm = playerPhys.height;
  const weightKg = playerPhys.weight;

  const formattedMarketValue = player.marketValue && player.marketValue >= 1_000_000
    ? `€${(player.marketValue / 1_000_000).toFixed(1)}M`
    : player.marketValue
    ? `€${Math.round(player.marketValue / 1000)}K`
    : '€2.5M';

  const calculateWageStr = (p: Player) => {
    const yrSuffix = t('PER_YEAR_SUFFIX') || 'YIL';
    if (p.wage) {
      const annual = p.wage >= 100000 ? p.wage : (p.wage * 52);
      if (annual >= 1_000_000) return `€${(annual / 1_000_000).toFixed(1)}M/${yrSuffix}`;
      return `€${Math.round(annual / 1000)}K/${yrSuffix}`;
    }
    const normKey = p.name
      .toLowerCase()
      .trim()
      .replace(/ı/g, 'i').replace(/ğ/g, 'g').replace(/ş/g, 's').replace(/ç/g, 'c').replace(/ö/g, 'o').replace(/ü/g, 'u')
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
    if (KNOWN_PLAYER_WAGES[normKey]) {
      const annual = KNOWN_PLAYER_WAGES[normKey];
      if (annual >= 1_000_000) return `€${(annual / 1_000_000).toFixed(1)}M/${yrSuffix}`;
      return `€${Math.round(annual / 1000)}K/${yrSuffix}`;
    }
    const mv = p.marketValue || 1500000;
    let annualWage = Math.round(mv * 0.12);
    if (p.overall >= 88) annualWage = Math.max(12000000, annualWage);
    else if (p.overall >= 85) annualWage = Math.max(7500000, annualWage);
    else if (p.overall >= 82) annualWage = Math.max(4500000, annualWage);
    else if (p.overall >= 78) annualWage = Math.max(2200000, annualWage);
    else if (p.overall >= 74) annualWage = Math.max(1000000, annualWage);
    else if (p.overall >= 70) annualWage = Math.max(450000, annualWage);
    else annualWage = Math.max(120000, annualWage);

    if (annualWage >= 1_000_000) return `€${(annualWage / 1_000_000).toFixed(1)}M/${yrSuffix}`;
    return `€${Math.round(annualWage / 1000)}K/${yrSuffix}`;
  };

  const formattedWage = calculateWageStr(player);

  const isGk = player.position === 'GK';

  // Technical Attributes
  const technicals = isGk
    ? [
        { label: t('ATTR_REFLEXES'), score: scale20(player.overall) },
        { label: t('ATTR_HANDLING'), score: scale20(player.overall - 2) },
        { label: t('ATTR_KICKING'), score: scale20(player.attributes.passing) },
        { label: t('ATTR_ONE_ON_ONE'), score: scale20(player.overall - 1) },
        { label: t('ATTR_AERIAL_REACH'), score: scale20(player.overall - 3) },
        { label: t('ATTR_COMMUNICATION'), score: scale20(player.age > 26 ? 14 : 10, true) },
        { label: t('ATTR_PUNCHING'), score: scale20(player.attributes.physical) },
        { label: t('ATTR_PENALTY_SAVING'), score: scale20(player.overall - 2) }
      ]
    : [
        { label: t('ATTR_FINISHING'), score: scale20(player.position === 'FW' ? player.attributes.shooting : Math.round(player.attributes.shooting * 0.85)) },
        { label: t('ATTR_PASSING'), score: scale20(player.attributes.passing) },
        { label: t('ATTR_DRIBBLING'), score: scale20(player.attributes.pace) },
        { label: t('ATTR_FIRST_TOUCH'), score: scale20(player.overall - 2) },
        { label: t('ATTR_HEADING'), score: scale20(player.attributes.physical) },
        { label: t('ATTR_LONG_SHOTS'), score: scale20(player.attributes.shooting) },
        { label: t('ATTR_FREE_KICKS'), score: scale20(Math.round((player.attributes.shooting + player.attributes.passing) / 2)) },
        { label: t('ATTR_PENALTIES'), score: scale20(player.attributes.shooting - 1) }
      ];

  // Mental Attributes
  const mentals = [
    { label: t('ATTR_POSITIONING'), score: scale20(player.overall - 2) },
    { label: t('ATTR_VISION'), score: scale20(player.attributes.passing) },
    { label: t('ATTR_DECISIONS'), score: scale20(player.attributes.defending || player.overall - 1) },
    { label: t('ATTR_ANTICIPATION'), score: scale20(player.overall - 2) },
    { label: t('ATTR_COMPOSURE'), score: scale20(player.overall - 1) },
    { label: t('ATTR_CONCENTRATION'), score: scale20(player.overall) },
    { label: t('ATTR_LEADERSHIP'), score: scale20(player.age > 28 ? 15 : 10, true) },
    { label: t('ATTR_BRAVERY'), score: scale20(player.attributes.physical - 1) }
  ];

  // Physical Attributes
  const paceScore = scale20(player.attributes.pace);
  const rawAccel = player.attributes.pace + ((player.id.charCodeAt(0) % 2 === 0) ? 1 : -1);
  const accelScore = scale20(rawAccel);

  const physicals = [
    { label: t('ATTR_PACE'), score: paceScore },
    { label: t('ATTR_ACCELERATION'), score: accelScore },
    { label: t('ATTR_STRENGTH'), score: scale20(player.attributes.physical) },
    { label: t('ATTR_STAMINA'), score: scale20(player.stamina) },
    { label: t('ATTR_BALANCE'), score: scale20(player.attributes.physical - 2) },
    { label: t('ATTR_AGILITY'), score: scale20(player.attributes.pace - 1) },
    { label: t('ATTR_JUMPING'), score: scale20(player.attributes.physical - 3) },
    { label: t('ATTR_NATURAL_FITNESS'), score: scale20(player.attributes.physical - 1) }
  ];

  // Preferred foot & Skills
  const footSkills = getPlayerFootAndSkills(player);
  const prefFoot = footSkills.preferredFoot;
  const skillStars = footSkills.skillMoves;
  const weakFootStars = footSkills.weakFoot;

  // Role options per position
  const positionRoles: Record<string, string[]> = {
    FW: ['ROLE_WING_FORWARD', 'ROLE_INSIDE_FORWARD', 'ROLE_INVERTED_WINGER'],
    RW: ['ROLE_WING_FORWARD', 'ROLE_INSIDE_FORWARD', 'ROLE_INVERTED_WINGER'],
    LW: ['ROLE_WING_FORWARD', 'ROLE_INVERTED_WINGER', 'ROLE_WIDE_PLAYMAKER'],
    ST: ['ROLE_STRIKER', 'ROLE_POACHER', 'ROLE_TARGET_FORWARD'],
    MID: ['ROLE_PLAYMAKER', 'ROLE_BOX_TO_BOX', 'ROLE_ATTACKING_MID'],
    DEF: ['ROLE_CENTRE_BACK', 'ROLE_BALL_PLAYING_DEFENDER', 'ROLE_NO_NONSENSE_DEFENDER'],
    GK: ['ROLE_GOALKEEPER', 'ROLE_SWEEPER_KEEPER']
  };

  const currentRoleKeys = positionRoles[player.position] || ['ROLE_WING_FORWARD', 'ROLE_INSIDE_FORWARD', 'ROLE_INVERTED_WINGER'];

  // Form history ratings (6 matches)
  const seed = (player.id || player.name).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const hasPlayedMatches = !!(player.appearances && player.appearances > 0);
  const currentAvgRating = player.averageRating || player.form || 7.2;
  const formRatings = hasPlayedMatches
    ? [
        { match: '1', score: Number((currentAvgRating - 0.2 + (seed % 3) * 0.1).toFixed(1)) },
        { match: '2', score: Number((currentAvgRating + 0.1 - (seed % 2) * 0.1).toFixed(1)) },
        { match: '3', score: Number((currentAvgRating + 0.3 - (seed % 4) * 0.1).toFixed(1)) },
        { match: '4', score: Number((currentAvgRating - 0.1 + (seed % 2) * 0.1).toFixed(1)) },
        { match: '5', score: Number((currentAvgRating + 0.2 - (seed % 3) * 0.1).toFixed(1)) },
        { match: '6', score: Number(currentAvgRating.toFixed(1)) }
      ]
    : [
        { match: '1', score: 0 },
        { match: '2', score: 0 },
        { match: '3', score: 0 },
        { match: '4', score: 0 },
        { match: '5', score: 0 },
        { match: '6', score: 0 }
      ];

  const avgMatchRating = hasPlayedMatches ? (player.averageRating || player.form || 7.2) : 0.00;

  // 5-Week OVR Growth calculation
  const getPlayerOvrGrowth = (p: Player, maxPot: number) => {
    let hash = 0;
    const str = p.name + p.id;
    for (let i = 0; i < str.length; i++) hash = (hash << 5) - hash + str.charCodeAt(i);
    const seed = Math.abs(hash);

    let netChange = p.age <= 21 ? (seed % 4) + 1 : p.age <= 28 ? 1 : 0;
    const startOvr = p.overall - netChange;
    const wLabel = t('WEEK_LABEL') || 'Hafta';
    return {
      netOvrChange: netChange,
      data: [
        { week: `1. ${wLabel}`, ovr: startOvr },
        { week: `2. ${wLabel}`, ovr: Math.round(startOvr + netChange * 0.25) },
        { week: `3. ${wLabel}`, ovr: Math.round(startOvr + netChange * 0.5) },
        { week: `4. ${wLabel}`, ovr: Math.round(startOvr + netChange * 0.75) },
        { week: `5. ${wLabel}`, ovr: p.overall }
      ]
    };
  };

  const { netOvrChange, data: ovrGrowthData } = getPlayerOvrGrowth(player, calculatedPotential);
  const careerHistory = generatePlayerCareerHistory(player, team);
  const playerStats = generatePlayerDetailedStats(player);

  const totalCareerCaps = careerHistory.reduce((acc, r) => acc + r.caps, 0);
  const totalCareerGoals = careerHistory.reduce((acc, r) => acc + r.goals, 0);
  const totalCareerAssists = careerHistory.reduce((acc, r) => acc + r.assists, 0);
  const totalCareerYellowCards = careerHistory.reduce((acc, r) => acc + (r.yellowCards || 0), 0);
  const totalCareerRedCards = careerHistory.reduce((acc, r) => acc + (r.redCards || 0), 0);

  return (
    <div className="fixed inset-0 z-[9990] bg-[#0a0816]/95 backdrop-blur-md flex flex-col justify-center items-center w-full h-full overflow-hidden p-1.5 sm:p-2 text-slate-100 select-none font-sans">
      
      {/* OUTER MODAL CONTAINER - Strictly fits viewport height */}
      <div className="w-full max-w-5xl h-full max-h-[96vh] flex flex-col justify-between gap-1.5 min-h-0 overflow-hidden">
        
        {/* 1. TOP HEADER BAR */}
        <div className="bg-[#0f0b20] border border-[#231b38] px-2.5 py-0.5 flex items-center justify-between rounded-lg shadow-lg shrink-0 h-6 sm:h-7">
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-0.5 rounded bg-[#211938] hover:bg-[#322654] text-slate-200 hover:text-white transition-colors flex items-center gap-1 text-[9px] sm:text-[10px] font-bold cursor-pointer"
            >
              <ArrowLeft className="w-3 h-3" />
            </button>
            <h2 className="text-[10px] sm:text-[11px] font-black tracking-wider text-white uppercase leading-none">
              {t('PLAYER_PROFILE_TITLE') || 'OYUNCU PROFİLİ'}
            </h2>
          </div>

          {/* Top Right Controls (Close) */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={onClose}
              className="p-0.5 rounded bg-rose-500/20 border border-rose-500/40 text-rose-300 hover:bg-rose-500 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* 2. FULL-WIDTH PLAYER INFO BANNER */}
        <div className="bg-[#141026] border border-[#261f3f] rounded-lg p-1 sm:p-1.5 flex flex-col gap-0.5 sm:gap-1 shadow-xl shrink-0">
          
          {/* Top Row: OVR Box + Name + Star + Oyuncuyu İzle Button & Bio */}
          <div className="flex items-center gap-1.5 min-w-0">
            {/* OVR Badge */}
            <div className="bg-gradient-to-b from-purple-700 via-purple-900 to-indigo-950 rounded-lg border border-purple-400/30 px-2 sm:px-2.5 py-0.5 text-center min-w-[40px] sm:min-w-[48px] shadow shrink-0">
              <span className="text-lg sm:text-xl font-black text-white block leading-none">
                {player.overall}
              </span>
              <span className="text-[7.5px] sm:text-[8.5px] font-black text-purple-200 block uppercase tracking-tight mt-0.5">
                {player.specificRole || player.position}
              </span>
            </div>

            <div className="min-w-0 flex-1 flex flex-col justify-center">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="text-xs sm:text-sm font-black text-white leading-tight uppercase tracking-tight truncate max-w-[200px] sm:max-w-none">
                  {player.name}
                </h3>
                <button
                  onClick={handleToggleStar}
                  className="text-slate-400 hover:text-amber-400 transition-colors p-0.5 shrink-0 active:scale-90"
                  title={isShortlisted ? (t('REMOVE_FROM_FAVORITES') || "Favorilerden Çıkar") : (t('ADD_TO_FAVORITES') || "Favorilere Ekle")}
                >
                  <Star className={`w-3 h-3 ${isShortlisted ? 'fill-amber-400 text-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.5)]' : ''}`} />
                </button>

                {/* Oyuncuyu İzle Button placed right next to Star icon - ONLY for opponent players */}
                {!isUserTeam && (
                  <button
                    onClick={() => {
                      if (!activeReport && !activeScout) {
                        if (onAssignScout) {
                          onAssignScout(player.id, player.name);
                        } else {
                          setShowScoutPrompt(true);
                        }
                      } else if (activeReport) {
                        if (onOpenScoutManagement) {
                          onOpenScoutManagement();
                        } else if (onAssignScout) {
                          onAssignScout(player.id, player.name);
                        }
                      } else if (activeScout && onOpenScoutManagement) {
                        onOpenScoutManagement();
                      }
                    }}
                    className="bg-gradient-to-r from-purple-700 via-purple-600 to-indigo-600 hover:from-purple-600 hover:to-indigo-500 text-white font-black text-[6.5px] sm:text-[7.5px] py-0.5 px-1.5 rounded shadow transition-all uppercase tracking-wider cursor-pointer active:scale-95 whitespace-nowrap flex items-center gap-1 border border-purple-400/50"
                    title={t('SCOUT_PLAYER_TITLE') || "Oyuncuyu İzle (Gözlemci Raporu İste)"}
                  >
                    <Search className="w-2.5 h-2.5" />
                    <span>{activeReport ? (t('REPORT_READY') || 'RAPOR HAZIR') : activeScout ? (t('SCOUTING_IN_PROGRESS') || 'İZLENİYOR') : (t('SCOUT_PLAYER') || 'OYUNCUYU İZLE')}</span>
                  </button>
                )}
              </div>

              <div className="flex items-center gap-1 text-[7px] sm:text-[8px] font-bold text-slate-300 flex-wrap mt-0.5 leading-none">
                <span>{player.age} {t('AGE_SUFFIX_SHORT') || 'YAŞ'}</span>
                <span className="text-slate-500">•</span>
                <span>{heightCm} CM</span>
                <span className="text-slate-500">•</span>
                <span>{weightKg} KG</span>
                <span className="text-slate-500">•</span>
                <span className="text-emerald-400 font-extrabold flex items-center gap-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block"></span>
                  {prefFoot.toLowerCase() === 'sol' ? (t('FOOT_LEFT') || 'SOL') : (prefFoot.toLowerCase() === 'sağ' || prefFoot.toLowerCase() === 'sag') ? (t('FOOT_RIGHT') || 'SAĞ') : (t('FOOT_BOTH') || 'HER İKİSİ')} {t('FOOT_LABEL') || 'AYAK'}
                </span>
              </div>
            </div>
          </div>

          {/* Bottom Row: 5 Badges (Takım, Sözleşme, Form, Değer, Maaş) Side by Side */}
          <div className="grid grid-cols-5 gap-1 w-full">
            <button
              onClick={() => onOpenTeamModal?.(team)}
              className="bg-[#081729] hover:bg-[#0d223c] border border-cyan-500/60 hover:border-cyan-400 px-1.5 py-0.5 rounded text-center transition-all group cursor-pointer shadow-sm shadow-cyan-500/20 flex flex-col justify-center items-center min-w-0"
              title={`${team.name} takım detaylarını görüntüle`}
            >
              <span className="text-[6px] sm:text-[6.5px] font-black text-cyan-400 uppercase tracking-wider block leading-none flex items-center justify-center gap-0.5">
                <span>{t('DEFAULT_TEAM') || 'TAKIM'}</span>
                <span className="text-[6.5px] text-cyan-300 group-hover:translate-x-0.5 transition-transform">↗</span>
              </span>
              <span className="text-[7px] sm:text-[8px] font-black text-cyan-200 group-hover:text-cyan-100 group-hover:underline block mt-0.5 leading-tight truncate w-full">
                {team.name.toUpperCase()}
              </span>
            </button>

            <button
              onClick={() => {
                if (isUserTeam) onOpenContractModal?.(player);
                else if (onOpenOfferModal) onOpenOfferModal(player, team, 'BUY');
              }}
              className="bg-[#140b2a] hover:bg-[#201242] border border-purple-500/60 hover:border-purple-400 px-1.5 py-0.5 rounded text-center transition-all group cursor-pointer shadow-sm shadow-purple-500/20 flex flex-col justify-center items-center min-w-0"
              title="Sözleşme detaylarını gör veya yenile"
            >
              <span className="text-[6px] sm:text-[6.5px] font-black text-purple-400 uppercase tracking-wider block leading-none flex items-center justify-center gap-0.5">
                <span>{t('CONTRACT_BADGE') || 'SÖZLEŞME'}</span>
                <span className="text-[6.5px] text-purple-300 group-hover:translate-x-0.5 transition-transform">↗</span>
              </span>
              <span className="text-[7px] sm:text-[8px] font-black text-purple-200 group-hover:text-purple-100 group-hover:underline block mt-0.5 truncate w-full">
                {player.contractUntil ? `20${player.contractUntil}` : '2028'}
              </span>
            </button>

            <div className="bg-[#0e0a1a] border border-[#211a36] px-1.5 py-0.5 rounded text-center flex flex-col justify-center items-center min-w-0">
              <span className="text-[6px] sm:text-[6.5px] font-extrabold text-slate-400 uppercase block leading-none">{t('FORM_BADGE') || 'FORM'}</span>
              <span className="text-[7px] sm:text-[8px] font-black text-emerald-400 block mt-0.5">
                {hasPlayedMatches ? `${(player.form || 7.5).toFixed(1)}` : '-'}
              </span>
            </div>

            <div className="bg-[#0e0a1a] border border-[#211a36] px-1.5 py-0.5 rounded text-center flex flex-col justify-center items-center min-w-0">
              <span className="text-[6px] sm:text-[6.5px] font-extrabold text-slate-400 uppercase block leading-none">{t('VALUE_BADGE') || 'DEĞER'}</span>
              <span className="text-[7px] sm:text-[8px] font-black text-amber-300 block mt-0.5 truncate w-full">
                {formattedMarketValue}
              </span>
            </div>

            <div className="bg-[#0e0a1a] border border-[#211a36] px-1.5 py-0.5 rounded text-center flex flex-col justify-center items-center min-w-0">
              <span className="text-[6px] sm:text-[6.5px] font-extrabold text-slate-400 uppercase block leading-none">{t('WAGE_BADGE') || 'MAAŞ'}</span>
              <span className="text-[7px] sm:text-[8px] font-black text-sky-300 block mt-0.5 truncate w-full">
                {formattedWage}
              </span>
            </div>
          </div>
        </div>

        {/* 3. MAIN TABBED CONTENT BODY */}
        <div className="bg-[#141026] border border-[#261f3f] rounded-lg p-1.5 flex-1 flex flex-col min-h-0 shadow-xl overflow-hidden justify-between">
            
            {/* Top Navigation Tabs */}
            <div className="flex items-center gap-1 border-b border-[#231b38] pb-0.5 shrink-0">
              {([
                { key: 'GENEL' as const, label: t('TAB_GENERAL') || 'GENEL' },
                { key: 'DETAYLAR' as const, label: t('TAB_DETAILS') || 'DETAYLAR' },
                { key: 'KARİYER' as const, label: t('TAB_CAREER') || 'KARİYER' },
                { key: 'İSTATİSTİKLER' as const, label: t('TAB_STATISTICS') || 'İSTATİSTİKLER' }
              ]).map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`px-2 py-0.5 rounded text-[7.5px] sm:text-[8.5px] font-black transition-all whitespace-nowrap cursor-pointer leading-none ${
                    activeTab === tab.key
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-[#1a1430]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* TAB CONTENT 1: GENEL (MAIN ATTRIBUTES & POSITION GRID - 4 COLUMNS SIDE BY SIDE) */}
            {activeTab === 'GENEL' && (
              <div className="grid grid-cols-4 gap-1 sm:gap-1.5 py-0.5 flex-1 min-h-0 items-stretch">
                
                {/* COL 1: TEKNİK */}
                <div className="bg-[#0e0a1a] border border-[#211a36] rounded-lg p-1 sm:p-1.5 flex flex-col justify-between shadow-sm min-h-0 overflow-hidden">
                  <div className="flex items-center justify-between border-b border-[#211a36] pb-0.5 leading-none shrink-0 mb-0.5">
                    <span className="text-[7.5px] sm:text-[8px] font-black text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                      <span>⚽</span> {t('ATTR_TECHNICAL') || 'TEKNİK'}
                    </span>
                    <span className="text-[6.5px] sm:text-[7px] font-extrabold text-slate-400 bg-[#16102b] px-1 py-0.2 rounded">
                      {t('AVG_ABBR') || 'Ort:'} {(technicals.reduce((a, b) => a + b.score, 0) / technicals.length).toFixed(1)}
                    </span>
                  </div>
                  <div className="flex flex-col gap-[2px] flex-1 justify-between min-h-0">
                    {technicals.map((attr, idx) => {
                      const style = getAttributeBadgeStyle(attr.score);
                      return (
                        <div key={idx} className="flex items-center justify-between gap-0.5 py-[1px] px-1 rounded bg-[#130d24]/60 border border-[#1d1633] hover:border-purple-500/30 transition-all leading-none">
                          <span className={`text-[6.5px] sm:text-[7.5px] truncate flex-1 min-w-0 pr-0.5 ${style.labelColor}`}>
                            {attr.label}
                          </span>
                          <div className="flex items-center gap-1 shrink-0">
                            <div className="w-3 sm:w-4 h-1 bg-[#0a0714] rounded-full overflow-hidden p-0.2">
                              <div
                                className={`h-full rounded-full transition-all ${style.barGrad}`}
                                style={{ width: `${(attr.score / 20) * 100}%` }}
                              />
                            </div>
                            <span className={`w-3.5 text-center text-[6.5px] sm:text-[7.5px] font-black py-0.2 rounded leading-none ${style.pillBg}`}>
                              {attr.score}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* COL 2: ZİHNİSEL */}
                <div className="bg-[#0e0a1a] border border-[#211a36] rounded-lg p-1 sm:p-1.5 flex flex-col justify-between shadow-sm min-h-0 overflow-hidden">
                  <div className="flex items-center justify-between border-b border-[#211a36] pb-0.5 leading-none shrink-0 mb-0.5">
                    <span className="text-[7.5px] sm:text-[8px] font-black text-purple-400 uppercase tracking-wider flex items-center gap-1">
                      <span>🧠</span> {t('ATTR_MENTAL') || 'ZİHNİSEL'}
                    </span>
                    <span className="text-[6.5px] sm:text-[7px] font-extrabold text-slate-400 bg-[#16102b] px-1 py-0.2 rounded">
                      {t('AVG_ABBR') || 'Ort:'} {(mentals.reduce((a, b) => a + b.score, 0) / mentals.length).toFixed(1)}
                    </span>
                  </div>
                  <div className="flex flex-col gap-[2px] flex-1 justify-between min-h-0">
                    {mentals.map((attr, idx) => {
                      const style = getAttributeBadgeStyle(attr.score);
                      return (
                        <div key={idx} className="flex items-center justify-between gap-0.5 py-[1px] px-1 rounded bg-[#130d24]/60 border border-[#1d1633] hover:border-purple-500/30 transition-all leading-none">
                          <span className={`text-[6.5px] sm:text-[7.5px] truncate flex-1 min-w-0 pr-0.5 ${style.labelColor}`}>
                            {attr.label}
                          </span>
                          <div className="flex items-center gap-1 shrink-0">
                            <div className="w-3 sm:w-4 h-1 bg-[#0a0714] rounded-full overflow-hidden p-0.2">
                              <div
                                className={`h-full rounded-full transition-all ${style.barGrad}`}
                                style={{ width: `${(attr.score / 20) * 100}%` }}
                              />
                            </div>
                            <span className={`w-3.5 text-center text-[6.5px] sm:text-[7.5px] font-black py-0.2 rounded leading-none ${style.pillBg}`}>
                              {attr.score}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* COL 3: FİZİKSEL */}
                <div className="bg-[#0e0a1a] border border-[#211a36] rounded-lg p-1 sm:p-1.5 flex flex-col justify-between shadow-sm min-h-0 overflow-hidden">
                  <div className="flex items-center justify-between border-b border-[#211a36] pb-0.5 leading-none shrink-0 mb-0.5">
                    <span className="text-[7.5px] sm:text-[8px] font-black text-sky-400 uppercase tracking-wider flex items-center gap-1">
                      <span>🏋️</span> {t('ATTR_CAT_PHYSICAL') || 'FİZİKSEL'}
                    </span>
                    <span className="text-[6.5px] sm:text-[7px] font-extrabold text-slate-400 bg-[#16102b] px-1 py-0.2 rounded">
                      {t('AVG_ABBR') || 'Ort:'} {(physicals.reduce((a, b) => a + b.score, 0) / physicals.length).toFixed(1)}
                    </span>
                  </div>
                  <div className="flex flex-col gap-[2px] flex-1 justify-between min-h-0">
                    {physicals.map((attr, idx) => {
                      const style = getAttributeBadgeStyle(attr.score);
                      return (
                        <div key={idx} className="flex items-center justify-between gap-0.5 py-[1px] px-1 rounded bg-[#130d24]/60 border border-[#1d1633] hover:border-purple-500/30 transition-all leading-none">
                          <span className={`text-[6.5px] sm:text-[7.5px] truncate flex-1 min-w-0 pr-0.5 ${style.labelColor}`}>
                            {attr.label}
                          </span>
                          <div className="flex items-center gap-1 shrink-0">
                            <div className="w-3 sm:w-4 h-1 bg-[#0a0714] rounded-full overflow-hidden p-0.2">
                              <div
                                className={`h-full rounded-full transition-all ${style.barGrad}`}
                                style={{ width: `${(attr.score / 20) * 100}%` }}
                              />
                            </div>
                            <span className={`w-3.5 text-center text-[6.5px] sm:text-[7.5px] font-black py-0.2 rounded leading-none ${style.pillBg}`}>
                              {attr.score}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* COL 4: MEVKİ & POZİSYON */}
                <div className="bg-[#0e0a1a] border border-[#211a36] rounded-lg p-1 sm:p-1.5 flex flex-col justify-between shadow-sm min-h-0 overflow-hidden gap-0.5">
                  <div className="shrink-0 border-b border-[#211a36] pb-0.5">
                    <span className="text-[7.5px] sm:text-[8px] font-black text-emerald-400 uppercase tracking-wider flex items-center gap-1 leading-none">
                      <span>📍</span> {t('POSITION_TITLE') || 'MEVKİ'}
                    </span>
                    <span className="text-[7.5px] sm:text-[8.5px] font-black text-white block mt-0.5 leading-none truncate">
                      {player.specificRole || player.position} ({player.position})
                    </span>
                  </div>

                  {/* Pitch Diagram */}
                  <div className="flex-1 min-h-0 flex items-center justify-center overflow-hidden">
                    <PositionPitch player={player} />
                  </div>

                  {/* Foot & Skill stars summary */}
                  <div className="flex items-center justify-between text-[6px] sm:text-[6.5px] bg-[#130d24] border border-[#1d1633] px-1 py-0.5 rounded shrink-0 text-slate-300 leading-none">
                    <span>{t('FOOT_LABEL_PREFIX') || 'Ayak:'} <strong className="text-emerald-400">{prefFoot.toLowerCase() === 'sol' ? (t('FOOT_LEFT') || 'SOL') : (prefFoot.toLowerCase() === 'sağ' || prefFoot.toLowerCase() === 'sag') ? (t('FOOT_RIGHT') || 'SAĞ') : (t('FOOT_BOTH') || 'HER İKİSİ')}</strong></span>
                    <span className="flex items-center gap-0.5">{t('SKILL_LABEL') || 'Yetenek:'} <StarRating rating={skillStars} /></span>
                  </div>
                </div>

              </div>
            )}

            {/* TAB CONTENT 2: DETAYLAR */}
            {activeTab === 'DETAYLAR' && (
              <div className="h-full flex flex-col justify-between gap-1 overflow-hidden py-0.5">
                <div className="bg-[#0e0a1a] border border-[#211a36] rounded-lg p-1.5 flex-1 flex flex-col justify-between min-h-0">
                  <div className="flex justify-between items-center shrink-0">
                    <div className="flex items-center gap-1">
                      <TrendingUp className="w-3 h-3 text-emerald-400" />
                      <span className="text-[8.5px] sm:text-[9.5px] font-black text-white uppercase leading-none">{t('OVR_GROWTH_TITLE') || '5 HAFTALIK OVR GELİŞİMİ'}</span>
                    </div>
                    <div className="bg-amber-500/20 border border-amber-500/40 text-amber-300 px-1 py-0.2 rounded text-[8px] font-black leading-none">
                      ⭐ {t('POTENTIAL_BADGE') || 'Potansiyel'}: {calculatedPotential}
                    </div>
                  </div>

                  <div className="flex-1 w-full pt-0.5 min-h-0">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={ovrGrowthData} margin={{ top: 5, right: 10, left: -25, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#211a36" />
                        <XAxis dataKey="week" stroke="#a78bfa" tick={{ fontSize: 7 }} />
                        <YAxis domain={['dataMin - 1', 'dataMax + 1']} stroke="#64748b" tick={{ fontSize: 7 }} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#120f21',
                            borderColor: '#3b315e',
                            borderRadius: '6px',
                            color: '#fff',
                            fontSize: '8px'
                          }}
                        />
                        <Line
                          type="monotone"
                          dataKey="ovr"
                          name="OVR"
                          stroke="#10b981"
                          strokeWidth={1.5}
                          dot={{ r: 2, fill: '#10b981' }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-1 text-[8px] sm:text-[9px] shrink-0">
                  <div className="bg-[#0e0a1a] border border-[#211a36] rounded-lg p-1 space-y-0.5">
                    <span className="text-purple-400 font-extrabold uppercase text-[7.5px] block leading-none">{t('PERSONALITY_MENTALITY_TITLE') || 'KİŞİLİK & MANTALİTE'}</span>
                    <div className="flex justify-between text-slate-300 leading-none">
                      <span>{t('TEMPERAMENT_LABEL') || 'Mizaç:'}</span>
                      <strong className="text-white">{t('TEMPERAMENT_VALUE') || 'Hırslı & Profesyonel'}</strong>
                    </div>
                    <div className="flex justify-between text-slate-300 leading-none">
                      <span>{t('LOYALTY_LABEL') || 'Sadakat:'}</span>
                      <strong className="text-emerald-400">{t('LOYALTY_VALUE') || 'Yüksek (%85)'}</strong>
                    </div>
                  </div>

                  <div className="bg-[#0e0a1a] border border-[#211a36] rounded-lg p-1 space-y-0.5">
                    <span className="text-sky-400 font-extrabold uppercase text-[7.5px] block leading-none">{t('HEALTH_FITNESS_TITLE') || 'SAĞLIK & KONDİSYON'}</span>
                    <div className="flex justify-between text-slate-300 leading-none">
                      <span>{t('INJURY_RISK_LABEL') || 'Sakatlık Riski:'}</span>
                      <strong className="text-emerald-400">{t('INJURY_RISK_LOW') || 'Düşük'}</strong>
                    </div>
                    <div className="flex justify-between text-slate-300 leading-none">
                      <span>{t('FITNESS_LABEL') || 'Kondisyon:'}</span>
                      <strong className="text-white">%{player.stamina ?? 100}</strong>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB CONTENT 3: KARİYER */}
            {activeTab === 'KARİYER' && (
              <div className="bg-[#0e0a1a] border border-[#211a36] rounded-lg p-1.5 h-full flex flex-col overflow-hidden py-0.5">
                <div className="flex items-center justify-between mb-1 pb-0.5 border-b border-[#211a36] shrink-0">
                  <div className="flex items-center gap-1.5">
                    <h4 className="text-[8.5px] sm:text-[9.5px] font-black text-slate-200 uppercase leading-none">
                      {player.name} - {t('ALL_CAREER_TRANSFER_HISTORY') || 'TÜM KARİYER & TRANSFER GEÇMİŞİ'}
                    </h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowPastSeasonsModal(true)}
                    className="text-[7.5px] text-amber-300 hover:text-amber-200 bg-amber-500/10 hover:bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30 font-extrabold flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <span>📊 {t('DETAILED_SEASON_STATS') || 'Detaylı Sezon İstatistikleri'}</span> ↗
                  </button>
                </div>

                <div className="w-full text-[8px] sm:text-[9px] text-left flex-1 overflow-y-auto custom-scrollbar">
                  <div className="grid grid-cols-8 text-slate-400 font-bold border-b border-[#211a36] pb-1 px-1 bg-[#120e24] sticky top-0 z-10 text-[7.5px] sm:text-[8.5px]">
                    <span>{t('TH_SEASON') || 'SEZON'}</span>
                    <span className="col-span-2">{t('TH_CLUB_LEAGUE') || 'KULÜP & LİG'}</span>
                    <span className="text-center">{t('TH_TRANSFER_FEE') || 'BONSERVİS'}</span>
                    <span className="text-center">{t('TH_CAPS') || 'MAÇ'}</span>
                    <span className="text-center">{t('TH_GOALS_AST') || 'GOL / AST'}</span>
                    <span className="text-center">{t('TH_CARDS') || 'KART (🟨/🟥)'}</span>
                    <span className="text-center">{t('TH_AVG') || 'ORT'}</span>
                  </div>
                  {careerHistory.map((row, i) => {
                    const isPreviousRowSameClub = (i < careerHistory.length - 1 && careerHistory[i + 1].club === row.club);
                    const isRepetitiveContract = (row.transferType === 'Sözleşme' || row.transferType === 'Sözleşme Uzatma' || row.transferType === '-') && isPreviousRowSameClub && i !== 0;
                    const isVisibleTransfer = !isRepetitiveContract && row.transferType && row.transferType !== '-' && row.transferType !== 'Sözleşme';

                    return (
                      <div key={i} className="grid grid-cols-8 py-1 px-1 border-b border-[#1b152d] font-semibold text-slate-200 hover:bg-[#181033] transition-colors items-center text-[7.5px] sm:text-[8.5px]">
                        <span className="text-purple-300 font-extrabold">{row.season}</span>
                        <div className="col-span-2 min-w-0 pr-1">
                          <button
                            type="button"
                            onClick={() => handleOpenCareerClub(row.club, row.league)}
                            className="text-left font-black text-cyan-300 hover:text-cyan-100 hover:underline cursor-pointer group flex items-center gap-1 transition-all leading-tight"
                            title={`${row.club} takım bilgilerini aç`}
                          >
                            <span className="truncate">{row.club}</span>
                            <span className="text-[8px] text-cyan-400 group-hover:translate-x-0.5 transition-transform font-bold">↗</span>
                          </button>
                          <span className="text-[6.5px] text-slate-400 block truncate leading-none mt-0.5">{row.league}</span>
                        </div>
                        <span className="text-center">
                          {isVisibleTransfer ? (
                            <span className={`px-1.5 py-0.5 rounded text-[7px] sm:text-[8px] font-extrabold inline-block shadow-sm ${
                              row.transferType.includes('€') ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                              row.transferType.includes('Kiralık') ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40' :
                              row.transferType.includes('Bonservissiz') || row.transferType.includes('A Takım') ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                              'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                            }`}>
                              {row.transferType}
                            </span>
                          ) : (
                            <span className="text-slate-600 font-extrabold text-[9px]">-</span>
                          )}
                        </span>
                        <span className="text-center font-black">
                          <span className="bg-[#181230] text-slate-100 px-1.5 py-0.5 rounded border border-[#2d2252] text-[7.5px] sm:text-[8.5px]">
                            {row.caps} {t('MATCH_SHORT') || 'Maç'}
                          </span>
                        </span>
                        <span className="text-center font-extrabold flex items-center justify-center gap-1">
                          <span className="text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-1 py-0.2 rounded">{row.goals} {t('GOAL_SHORT') || 'G'}</span>
                          <span className="text-sky-400 bg-sky-950/40 border border-sky-500/30 px-1 py-0.2 rounded">{row.assists} {t('ASSIST_SHORT') || 'A'}</span>
                        </span>
                        <span className="text-center font-extrabold flex items-center justify-center gap-1 text-[7.5px]">
                          <span className="text-amber-300 bg-amber-950/40 border border-amber-500/30 px-1 py-0.2 rounded font-black">{row.yellowCards || 0}🟨</span>
                          <span className="text-rose-400 bg-rose-950/40 border border-rose-500/30 px-1 py-0.2 rounded font-black">{row.redCards || 0}🟥</span>
                        </span>
                        <span className="text-center">
                          <span className="font-black text-amber-300 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/30">
                            {row.rating.toFixed(2)}
                          </span>
                        </span>
                      </div>
                    );
                  })}

                  {/* Career Totals */}
                  <div className="grid grid-cols-8 py-1 px-1 bg-[#18122d] border-t-2 border-purple-500/40 font-black text-white text-[8px] sm:text-[9px] mt-1 rounded items-center">
                    <span>{t('TOTAL_LABEL') || 'TOPLAM'}</span>
                    <span className="col-span-2 text-purple-300">{careerHistory.length} {t('CLUB_SPELL') || 'Kulüp Dönemi'}</span>
                    <span className="text-center text-slate-400">-</span>
                    <span className="text-center text-white">{totalCareerCaps} {t('MATCH_SHORT') || 'Maç'}</span>
                    <span className="text-center">
                      <span className="text-emerald-400">{totalCareerGoals} {t('GOAL_SHORT') || 'Gol'}</span>
                      <span className="text-slate-400 mx-0.5">/</span>
                      <span className="text-sky-400">{totalCareerAssists} {t('ASSIST_SHORT') || 'Ast'}</span>
                    </span>
                    <span className="text-center text-amber-300">
                      {totalCareerYellowCards}🟨 / {totalCareerRedCards}🟥
                    </span>
                    <span className="text-center text-amber-400">
                      {(careerHistory.reduce((a, b) => a + b.rating, 0) / Math.max(1, careerHistory.length)).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* TAB CONTENT 4: İSTATİSTİKLER (OYUNCUYA ÖZEL PERFORMANS METRİKLERİ) */}
            {activeTab === 'İSTATİSTİKLER' && (
              <div className="bg-[#0e0a1a] border border-[#211a36] rounded-lg p-1.5 h-full flex flex-col justify-between text-[8px] sm:text-[9px] py-0.5 overflow-hidden">
                <div className="flex items-center justify-between shrink-0 mb-1">
                  <h4 className="text-[8.5px] sm:text-[9.5px] font-black text-slate-200 uppercase leading-none">
                    {player.name} - 2025/26 {t('SEASON_DETAILED_PERFORMANCE') || 'SEZON DETAYLI PERFORMANSI'}
                  </h4>
                  <span className="bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-500/40 text-[7.5px] font-bold">
                    {playerStats.appearances} {t('OFFICIAL_MATCHES') || 'Resmî Maç'}
                  </span>
                </div>

                {isGk ? (
                  /* GOALKEEPER SPECIFIC STATS */
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1 flex-1 overflow-y-auto custom-scrollbar">
                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_CLEAN_SHEETS') || 'GOL YEMEDİĞİ MAÇ'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-emerald-400">{playerStats.cleanSheets} {t('MATCH_SHORT') || 'Maç'}</span>
                        <span className="text-[7px] text-slate-400">Clean Sheet</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_SAVE_PCT') || 'KURTARIŞ ORANI %'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-sky-400">%{playerStats.savePct}</span>
                        <span className="text-[7px] text-slate-400">İsabetli Şut</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_SAVES_PER_MATCH') || 'MAÇ BAŞI KURTARIŞ'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-purple-300">{playerStats.savesPerMatch}</span>
                        <span className="text-[7px] text-slate-400">Kurtarış/Maç</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_GOALS_CONCEDED') || 'KALEDE YENEN GOL'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-rose-400">{playerStats.goalsConceded}</span>
                        <span className="text-[7px] text-slate-400">Toplam Gol</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_PASS_ACC_PCT') || 'PAS İSABET %'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-emerald-400">%{playerStats.passAcc}</span>
                        <span className="text-[7px] text-slate-400">Degaj / Oyun Kurma</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_MOTM') || 'MAÇIN ADAMI'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-amber-300">{playerStats.motmCount} {t('TIMES_LABEL') || 'Kez'}</span>
                        <span className="text-[7px] text-slate-400">MVP</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_DUELS_WON_PCT') || 'İKİLİ MÜCADELE %'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-indigo-300">%{playerStats.aerialWonPct}</span>
                        <span className="text-[7px] text-slate-400">Hava Topu Hakimiyeti</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_DISTANCE_COVERED') || 'KAT EDİLEN MESAFE'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-amber-400">{playerStats.distKm} km</span>
                        <span className="text-[7px] text-slate-400">Ort. Koşu / Maç</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* OUTFIELD PLAYER STATS */
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1 flex-1 overflow-y-auto custom-scrollbar">
                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_SHOT_ACC_PCT') || 'İSABETLİ ŞUT %'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-emerald-400">%{playerStats.shotAcc}</span>
                        <span className="text-[7px] text-slate-400">{playerStats.goals} {t('GOAL_SHORT') || 'Gol'}</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_PASS_ACC_PCT') || 'PAS İSABET %'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-sky-400">%{playerStats.passAcc}</span>
                        <span className="text-[7px] text-slate-400">{playerStats.keyPasses} Kilit Pas/Maç</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_DRIBBLES_PER_MATCH') || 'DRİBLİNG / MAÇ'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-purple-300">{playerStats.dribbles}</span>
                        <span className="text-[7px] text-slate-400">Çalım Başarısı</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_MOTM') || 'MAÇIN ADAMI'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-amber-300">{playerStats.motmCount} {t('TIMES_LABEL') || 'Kez'}</span>
                        <span className="text-[7px] text-slate-400">MVP</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_XG') || 'GOL BEKLENTİSİ (xG)'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-emerald-400">{playerStats.xG}</span>
                        <span className="text-[7px] text-slate-400">Gereken Gol Poz.</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_XA') || 'ASİST BEKLENTİSİ (xA)'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-sky-300">{playerStats.xA}</span>
                        <span className="text-[7px] text-slate-400">Üretilen Fırsatlar</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_DUELS_WON_PCT') || 'İKİLİ MÜCADELE %'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-indigo-300">%{playerStats.duelsWonPct}</span>
                        <span className="text-[7px] text-slate-400">{playerStats.tackles} Müdahale/Maç</span>
                      </div>
                    </div>

                    <div className="bg-[#141026] p-1.5 rounded border border-[#261f3f] flex flex-col justify-between">
                      <span className="text-[7px] text-slate-400 font-bold uppercase block">{t('STAT_DISTANCE_COVERED') || 'KAT EDİLEN MESAFE'}</span>
                      <div className="flex items-end justify-between mt-0.5">
                        <span className="text-sm font-black text-amber-400">{playerStats.distKm} km</span>
                        <span className="text-[7px] text-slate-400">Ort. Koşu / Maç</span>
                      </div>
                    </div>
                  </div>
                )}

                <div className="bg-[#141026] p-1 rounded border border-[#261f3f] shrink-0 mt-1 flex items-center justify-between text-[7.5px] sm:text-[8.5px]">
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-400 font-bold">{t('STAT_DISCIPLINE_REPORT') || 'DİSİPLİN RAPORU:'}</span>
                    <span className="text-amber-300 font-black">{playerStats.yellowCards} {t('YELLOW_CARD_LABEL') || 'Sarı Kart'}</span>
                    <span className="text-slate-500">•</span>
                    <span className="text-rose-400 font-black">{playerStats.redCards} {t('RED_CARD_LABEL') || 'Kırmızı Kart'}</span>
                  </div>
                  <span className="text-emerald-400 font-black">
                    {t('STAT_DISCIPLINE_SCORE') || 'Disiplin Puanı:'} %94
                  </span>
                </div>
              </div>
            )}

          </div>

        {/* 4. BOTTOM ROW: 3 CARDS (ROL & GÖREV, FORM GRAFİĞİ, SEZON İSTATİSTİKLERİ) */}
        <div className="h-[62px] sm:h-[70px] grid grid-cols-3 gap-1.5 shrink-0">
          
          {/* CARD 1: ROL & GÖREV */}
          <div className="bg-[#141026] border border-[#261f3f] rounded-lg p-1 sm:p-1.5 flex flex-col justify-between shadow overflow-hidden">
            <span className="text-[7.5px] sm:text-[8.5px] font-black text-slate-300 uppercase tracking-wider block leading-none shrink-0">
              {t('ROLE_TASK_TITLE') || 'ROL & GÖREV'}
            </span>
            <div className="flex flex-col gap-0.5 flex-1 justify-center">
              {currentRoleKeys.slice(0, 3).map((rKey, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveRoleKey(rKey)}
                  className={`w-full text-left py-0.5 px-1 rounded text-[7px] sm:text-[8px] font-black transition-all cursor-pointer leading-tight truncate ${
                    activeRoleKey === rKey
                      ? 'bg-emerald-600/30 border border-emerald-500 text-emerald-300 shadow'
                      : 'bg-[#0e0a1a] border border-[#211a36] text-slate-300 hover:border-purple-500/50 hover:text-white'
                  }`}
                >
                  {t(rKey) || rKey}
                </button>
              ))}
            </div>
          </div>

          {/* CARD 2: FORM GRAFİĞİ */}
          <div className="bg-[#141026] border border-[#261f3f] rounded-lg p-1 sm:p-1.5 flex flex-col justify-between shadow overflow-hidden">
            <span className="text-[7.5px] sm:text-[8.5px] font-black text-slate-300 uppercase tracking-wider block leading-none shrink-0">
              {t('FORM_GRAPH_TITLE') || 'FORM GRAFİĞİ (SON 6 MAÇ)'}
            </span>

            <div className="flex items-center gap-1 flex-1 min-h-0 my-0.5">
              <div className="flex-1 h-full min-h-[16px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={formRatings} margin={{ top: 1, right: 2, left: -25, bottom: 0 }}>
                    <defs>
                      <linearGradient id="formGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <YAxis domain={[5, 10]} hide />
                    <Area
                      type="monotone"
                      dataKey="score"
                      stroke="#10b981"
                      strokeWidth={1.5}
                      fillOpacity={1}
                      fill="url(#formGrad)"
                      dot={{ r: 1.5, fill: '#10b981', stroke: '#0e0a1a', strokeWidth: 1 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <div className="text-right pl-1 border-l border-[#231b38] shrink-0">
                <span className="text-xs sm:text-sm font-black text-emerald-400 block leading-none">
                  {hasPlayedMatches ? (player.averageRating ? player.averageRating.toFixed(1) : (player.form || 7.5).toFixed(1)) : '-'}
                </span>
                <span className="text-[6px] sm:text-[7px] font-black text-slate-400 uppercase tracking-wider mt-0.5 block leading-none">
                  {t('AVERAGE_TITLE') || 'ORTALAMA'}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between gap-0.5 shrink-0">
              {formRatings.map((f, i) => (
                <span
                  key={i}
                  className="px-0.5 py-0.2 rounded bg-[#0e0a1a] border border-emerald-500/30 text-emerald-300 font-extrabold text-[6.5px] sm:text-[7px] text-center flex-1 leading-none"
                >
                  {f.score > 0 ? f.score : '-'}
                </span>
              ))}
            </div>
          </div>

          {/* CARD 3: SEZON İSTATİSTİKLERİ */}
          <div
            onClick={() => setShowPastSeasonsModal(true)}
            className="bg-[#141026] border border-[#261f3f] hover:border-amber-400/80 hover:bg-[#191333] transition-all rounded-lg p-1 sm:p-1.5 flex flex-col justify-between shadow overflow-hidden cursor-pointer group"
            title="Tıkla: Geçmiş Sezonlar Detaylı İstatistiklerini Aç"
          >
            <div className="flex items-center justify-between shrink-0 leading-none">
              <span className="text-[7.5px] sm:text-[8.5px] font-black text-slate-300 group-hover:text-amber-300 transition-colors uppercase tracking-wider block">
                {t('SEASON_STATS_TITLE') || 'SEZON İSTATİSTİKLERİ'}
              </span>
              <span className="text-[6.5px] text-amber-400 bg-amber-400/10 px-1 py-0.2 rounded border border-amber-400/30 font-extrabold flex items-center gap-0.5">
                <span>{t('PAST_SEASONS_LINK') || 'Geçmiş Sezonlar'}</span> ↗
              </span>
            </div>

            <div className="flex items-center justify-between gap-1 flex-1 min-h-0">
              <div className="grid grid-cols-2 gap-0.5 flex-1 text-[7.5px] sm:text-[8.5px]">
                <div className="bg-[#0e0a1a] border border-[#211a36] p-0.5 rounded flex items-center gap-0.5">
                  <span className="text-[10px]">🛡️</span>
                  <div>
                    <span className="text-[6px] font-bold text-slate-400 uppercase block leading-none">{t('STAT_MATCH_SHORT') || 'MAÇ'}</span>
                    <strong className="text-[9px] font-black text-white leading-none">{player.appearances ?? 0}</strong>
                  </div>
                </div>

                <div className="bg-[#0e0a1a] border border-[#211a36] p-0.5 rounded flex items-center gap-0.5">
                  <span className="text-[10px]">⚽</span>
                  <div>
                    <span className="text-[6px] font-bold text-slate-400 uppercase block leading-none">{t('STAT_GOAL_SHORT') || 'GOL'}</span>
                    <strong className="text-[9px] font-black text-emerald-400 leading-none">{player.goalsScored ?? 0}</strong>
                  </div>
                </div>

                <div className="bg-[#0e0a1a] border border-[#211a36] p-0.5 rounded flex items-center gap-0.5">
                  <span className="text-[10px]">🅰️</span>
                  <div>
                    <span className="text-[6px] font-bold text-slate-400 uppercase block leading-none">{t('STAT_ASSIST_SHORT') || 'ASİST'}</span>
                    <strong className="text-[9px] font-black text-sky-400 leading-none">{player.assists ?? 0}</strong>
                  </div>
                </div>

                <div className="bg-[#0e0a1a] border border-[#211a36] p-0.5 rounded flex items-center gap-0.5">
                  <span className="text-[10px]">👕</span>
                  <div>
                    <span className="text-[6px] font-bold text-slate-400 uppercase block leading-none">{t('STAT_STARTING_XI') || 'MAÇA 11'}</span>
                    <strong className="text-[9px] font-black text-purple-300 leading-none">
                      {Math.round((player.appearances ?? 0) * 0.85)}
                    </strong>
                  </div>
                </div>
              </div>

              <div className="text-right pl-1 border-l border-[#231b38] shrink-0">
                <span className="text-xs sm:text-sm font-black text-emerald-400 block leading-none">
                  {avgMatchRating > 0 ? avgMatchRating.toFixed(2) : '0.00'}
                </span>
                <span className="text-[6px] sm:text-[7px] font-black text-slate-400 uppercase tracking-wider mt-0.5 block leading-none">
                  {t('STAT_AVG_RATING_SHORT') || 'ORT PUA'}
                </span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* PAST SEASONS DETAILED STATS MODAL */}
      {showPastSeasonsModal && (
        <div className="fixed inset-0 z-[9999] bg-black/85 backdrop-blur-md flex items-center justify-center p-3 animate-fadeIn">
          <div className="bg-[#130f24] border border-[#3b2d63] rounded-2xl p-4 max-w-2xl w-full space-y-3 text-white shadow-2xl flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between border-b border-[#2b2247] pb-2.5 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-base">
                  📊
                </div>
                <div>
                  <h4 className="font-black text-sm text-white flex items-center gap-2">
                    <span>{player.name}</span>
                    <span className="text-amber-300 text-xs font-extrabold bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/30">
                      {t('PAST_SEASONS_MODAL_TITLE') || 'Geçmiş Sezonlar İstatistikleri'}
                    </span>
                  </h4>
                  <span className="text-[10px] text-slate-400 font-semibold">
                    {team.name} • {player.position} ({player.specificRole || player.position}) • {t('TOTAL_LABEL') || 'Toplam'} {careerHistory.length} {t('SEASON_COUNT_SUFFIX') || 'Sezon'}
                  </span>
                </div>
              </div>
              <button 
                onClick={() => setShowPastSeasonsModal(false)}
                className="w-8 h-8 rounded-lg bg-[#20183b] hover:bg-[#2e2354] text-slate-300 hover:text-white flex items-center justify-center font-bold text-sm cursor-pointer transition-colors border border-[#34275c]"
              >
                ✕
              </button>
            </div>

            {/* Quick KPI Cards */}
            <div className="grid grid-cols-5 gap-2 shrink-0">
              <div className="bg-[#1a1433] p-2 rounded-xl border border-[#2e2354] text-center">
                <span className="text-[9px] text-slate-400 font-bold uppercase block">{t('TOTAL_MATCHES') || 'Toplam Maç'}</span>
                <span className="text-base font-black text-white">{totalCareerCaps}</span>
              </div>
              <div className="bg-[#1a1433] p-2 rounded-xl border border-[#2e2354] text-center">
                <span className="text-[9px] text-slate-400 font-bold uppercase block">{t('TOTAL_GOALS') || 'Toplam Gol'}</span>
                <span className="text-base font-black text-emerald-400">{totalCareerGoals}</span>
              </div>
              <div className="bg-[#1a1433] p-2 rounded-xl border border-[#2e2354] text-center">
                <span className="text-[9px] text-slate-400 font-bold uppercase block">{t('TOTAL_ASSISTS') || 'Toplam Asist'}</span>
                <span className="text-base font-black text-sky-400">{totalCareerAssists}</span>
              </div>
              <div className="bg-[#1a1433] p-2 rounded-xl border border-[#2e2354] text-center">
                <span className="text-[9px] text-slate-400 font-bold uppercase block">{t('CARDS_YELLOW_RED') || 'Kartlar (S/K)'}</span>
                <span className="text-base font-black text-amber-300">{totalCareerYellowCards} / {totalCareerRedCards}</span>
              </div>
              <div className="bg-[#1a1433] p-2 rounded-xl border border-[#2e2354] text-center">
                <span className="text-[9px] text-slate-400 font-bold uppercase block">{t('CAREER_AVG') || 'Kariyer Ort.'}</span>
                <span className="text-base font-black text-purple-300">
                  {(careerHistory.reduce((a, b) => a + b.rating, 0) / Math.max(1, careerHistory.length)).toFixed(2)}
                </span>
              </div>
            </div>

            {/* Detailed Table */}
            <div className="flex-1 overflow-y-auto custom-scrollbar border border-[#241c3d] rounded-xl bg-[#0c0917]">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="sticky top-0 bg-[#17122b] text-slate-400 font-black text-[10px] border-b border-[#2b2247] z-10">
                  <tr>
                    <th className="py-2 px-3">{t('TH_SEASON') || 'SEZON'}</th>
                    <th className="py-2 px-3">{t('TH_CLUB_LEAGUE') || 'KULÜP & LİG'}</th>
                    <th className="py-2 px-2 text-center">{t('TH_CAPS') || 'MAÇ'}</th>
                    <th className="py-2 px-2 text-center text-emerald-400">{t('STAT_GOAL_SHORT') || 'GOL'}</th>
                    <th className="py-2 px-2 text-center text-sky-400">{t('STAT_ASSIST_SHORT') || 'ASİST'}</th>
                    <th className="py-2 px-2 text-center text-amber-400">{t('TH_YELLOW_CARDS') || 'SARI KART'}</th>
                    <th className="py-2 px-2 text-center text-rose-400">{t('TH_RED_CARDS') || 'KIRMIZI KART'}</th>
                    <th className="py-2 px-3 text-center text-amber-300">{t('TH_AVG_RATING') || 'ORT. REYTİNG'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1b1530] text-slate-200 text-xs font-semibold">
                  {careerHistory.map((row, idx) => (
                    <tr key={idx} className="hover:bg-[#181330] transition-colors">
                      <td className="py-2 px-3 font-extrabold text-purple-300">{row.season}</td>
                      <td className="py-2 px-3">
                        <button
                          type="button"
                          onClick={() => {
                            setShowPastSeasonsModal(false);
                            handleOpenCareerClub(row.club, row.league);
                          }}
                          className="font-black text-cyan-300 hover:text-cyan-100 hover:underline cursor-pointer flex items-center gap-1"
                        >
                          <span>{row.club}</span>
                          <span className="text-[9px] text-slate-400">({row.league})</span>
                        </button>
                      </td>
                      <td className="py-2 px-2 text-center font-bold text-white">{row.caps}</td>
                      <td className="py-2 px-2 text-center font-black text-emerald-400">{row.goals}</td>
                      <td className="py-2 px-2 text-center font-black text-sky-400">{row.assists}</td>
                      <td className="py-2 px-2 text-center font-bold text-amber-300">{row.yellowCards || 0}</td>
                      <td className="py-2 px-2 text-center font-bold text-rose-400">{row.redCards || 0}</td>
                      <td className="py-2 px-3 text-center">
                        <span className="bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded font-black border border-amber-500/30">
                          {row.rating.toFixed(2)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="sticky bottom-0 bg-[#191333] border-t-2 border-purple-500/50 font-black text-white text-xs">
                  <tr>
                    <td className="py-2 px-3 text-purple-300">{t('TOTAL_LABEL') || 'TOPLAM'}</td>
                    <td className="py-2 px-3 text-slate-300">{careerHistory.length} {t('CLUB_SPELL') || 'Kulüp Dönemi'}</td>
                    <td className="py-2 px-2 text-center text-white">{totalCareerCaps}</td>
                    <td className="py-2 px-2 text-center text-emerald-400">{totalCareerGoals}</td>
                    <td className="py-2 px-2 text-center text-sky-400">{totalCareerAssists}</td>
                    <td className="py-2 px-2 text-center text-amber-300">{totalCareerYellowCards}</td>
                    <td className="py-2 px-2 text-center text-rose-400">{totalCareerRedCards}</td>
                    <td className="py-2 px-3 text-center text-amber-400">
                      {(careerHistory.reduce((a, b) => a + b.rating, 0) / Math.max(1, careerHistory.length)).toFixed(2)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            <div className="flex justify-end pt-1 shrink-0">
              <button
                onClick={() => setShowPastSeasonsModal(false)}
                className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs uppercase tracking-wider cursor-pointer shadow transition-all"
              >
                {t('CLOSE') || 'Kapat'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SCOUT PROMPT MODAL */}
      {showScoutPrompt && (
        <div className="fixed inset-0 z-[9999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 animate-fadeIn">
          <div className="bg-[#18142b] border border-[#3b2d63] rounded-2xl p-4 max-w-sm w-full space-y-3 text-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#2b2247] pb-2">
              <h4 className="font-extrabold text-sm text-amber-300 flex items-center gap-1.5">
                <Search className="w-4 h-4 text-amber-400" /> {t('SEND_SCOUT_MODAL_TITLE')}
              </h4>
              <button onClick={() => setShowScoutPrompt(false)} className="text-slate-400 hover:text-white font-bold cursor-pointer">✕</button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              {t('SEND_SCOUT_MODAL_DESC', { player: player.name })}
            </p>

            <div className="bg-[#120f21] p-3 rounded-xl border border-[#2b2247] text-xs space-y-1.5">
              <div className="flex justify-between items-center">
                <span className="text-slate-400 font-semibold">{t('TOTAL_SCOUTS_LABEL')}</span>
                <span className="font-black text-amber-300">{scouts.length} / 5</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 font-semibold">{t('IDLE_SCOUTS_LABEL')}</span>
                <span className="font-black text-emerald-400">{scouts.filter((s) => !s.assignedPlayerId).length}</span>
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-1">
              {scouts.filter((s) => !s.assignedPlayerId).length > 0 ? (
                <button
                  onClick={() => {
                    onAssignScout?.(player.id, player.name);
                    setShowScoutPrompt(false);
                  }}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-extrabold text-xs uppercase tracking-wider shadow cursor-pointer"
                >
                  {t('SEND_SCOUT_1_WEEK_BTN')}
                </button>
              ) : (
                <button
                  onClick={() => {
                    setShowScoutPrompt(false);
                    onOpenScoutManagement?.();
                  }}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-extrabold text-xs uppercase tracking-wider shadow flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {t('NO_FREE_SCOUT_HIRE')}
                </button>
              )}
              <button
                onClick={() => setShowScoutPrompt(false)}
                className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
              >
                {t('CANCEL')}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
