import React from 'react';
import { Player, Team, MatchStats, CustomPlayerAvatar } from '../types';
import { PlayerAvatarRenderer } from './PlayerAvatarRenderer';
import { useTranslation } from '../utils/i18n';
import {
  Trophy,
  Zap,
  Flame,
  Award,
  Target,
  ChevronRight,
  TrendingUp,
  UserCheck,
  ShieldAlert,
  Sparkles,
  Calendar,
  Briefcase
} from 'lucide-react';

interface PlayerHomeViewProps {
  player: Player;
  currentTeam: Team;
  opponentTeam: Team;
  currentWeek: number;
  avatar?: CustomPlayerAvatar;
  onPlayMatch: () => void;
  onOpenMyPlayerTab: () => void;
  onOpenNewsTab: () => void;
}

export const PlayerHomeView: React.FC<PlayerHomeViewProps> = ({
  player,
  currentTeam,
  opponentTeam,
  currentWeek,
  avatar,
  onPlayMatch,
  onOpenMyPlayerTab,
  onOpenNewsTab
}) => {
  const { t } = useTranslation();
  const goals = player.goalsScored || 0;
  const assists = player.assists || 0;
  const matches = currentWeek - 1 > 0 ? currentWeek - 1 : 1;
  const avgRating = player.lastRating || 7.6;
  const valueFormatted = (player.marketValue / 1_000_000).toFixed(1);
  const wageFormatted = player.wage ? player.wage.toLocaleString('tr-TR') : '15,000';

  return (
    <div className="flex flex-col gap-3.5 h-full overflow-y-auto custom-scrollbar pb-2">
      
      {/* 1. HERO CARD: Interactive 3D Player Showcase & Star Badge */}
      <div className="relative bg-gradient-to-r from-[#1c1438] via-[#150f2d] to-[#0c081e] border border-purple-500/40 rounded-3xl p-4 sm:p-5 shadow-2xl overflow-hidden">
        
        {/* Background Ambient Lighting */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-60 h-60 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-5">
          
          {/* Left: Player Info & Attributes */}
          <div className="flex items-center gap-4 sm:gap-6 w-full md:w-auto">
            
            {/* Live 3D Rotatable Player Avatar */}
            <div className="shrink-0 scale-90 sm:scale-100">
              <PlayerAvatarRenderer
                avatar={avatar || {
                  skinTone: 'Buğday',
                  hairStyle: 'Fade',
                  hairColor: 'Siyah',
                  eyeColor: 'Kahverengi',
                  sleeveLength: 'Uzun Kol',
                  bootColor: 'Neon Sarı',
                }}
                jerseyColor={currentTeam.badgeColor ? '#7b2cbf' : '#3b82f6'}
                size={135}
                show3DControls={true}
                interactiveRotation={true}
              />
            </div>

            {/* Player Details */}
            <div className="flex flex-col gap-1.5 flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-300 font-black text-xs uppercase tracking-wider flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-400" /> {t('STAR_PLAYER')}
                </span>
                <span className="px-2 py-0.5 rounded-md bg-purple-900/60 text-purple-200 text-[10px] font-bold border border-purple-500/30">
                  {player.specificRole || player.position}
                </span>
                <span className="text-xs text-slate-400 font-semibold">{player.age} {t('YEARS_OLD')}</span>
              </div>

              <h2 className="text-xl sm:text-2xl font-black text-white tracking-wide truncate drop-shadow">
                {player.name}
              </h2>

              <p className="text-xs font-semibold text-purple-300/90 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                {currentTeam.name} • {t('FORM')}: <span className="text-emerald-400 font-black">%96 ({t('EXCELLENT')})</span>
              </p>

              {/* Form & Fitness Mini Status Bars */}
              <div className="grid grid-cols-2 gap-2 mt-1 max-w-xs">
                <div className="bg-[#100c22] p-1.5 rounded-xl border border-purple-900/40">
                  <div className="flex justify-between items-center text-[10px] text-slate-300 font-bold mb-1">
                    <span className="flex items-center gap-1"><Zap className="w-2.5 h-2.5 text-amber-400" /> {t('STAMINA')}</span>
                    <span className="text-amber-300 font-black">{player.stamina || 98}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-gradient-to-r from-amber-500 to-emerald-400 h-full rounded-full" style={{ width: `${player.stamina || 98}%` }} />
                  </div>
                </div>

                <div className="bg-[#100c22] p-1.5 rounded-xl border border-purple-900/40">
                  <div className="flex justify-between items-center text-[10px] text-slate-300 font-bold mb-1">
                    <span className="flex items-center gap-1"><Flame className="w-2.5 h-2.5 text-rose-400" /> {t('MORALE')}</span>
                    <span className="text-rose-300 font-black">{t('HIGH')}</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-gradient-to-r from-rose-500 to-purple-400 h-full rounded-full" style={{ width: '92%' }} />
                  </div>
                </div>
              </div>

            </div>

          </div>

          {/* Right: Big Overall Rating Badge & Value Box */}
          <div className="flex md:flex-col items-center justify-between md:justify-center gap-3 w-full md:w-auto pt-3 md:pt-0 border-t md:border-t-0 border-purple-500/20">
            <div className="flex items-center gap-3">
              <div className="flex flex-col items-center justify-center bg-gradient-to-br from-amber-400 via-amber-500 to-amber-700 p-3 sm:p-4 rounded-2xl shadow-[0_0_25px_rgba(245,158,11,0.4)] text-slate-950 font-black min-w-[75px] sm:min-w-[85px]">
                <span className="text-3xl sm:text-4xl leading-none tracking-tight">{player.overall}</span>
                <span className="text-[9px] uppercase tracking-wider font-extrabold opacity-90 mt-0.5">{t('OVERALL')}</span>
              </div>
              
              <div className="flex flex-col text-left">
                <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-wider">{t('MARKET_VALUE')}</span>
                <span className="text-lg sm:text-xl font-black text-emerald-400">€{valueFormatted}M</span>
                <span className="text-[11px] text-purple-300 font-bold">€{wageFormatted} / {t('WEEKLY_WAGE')}</span>
              </div>
            </div>

            <button
              onClick={onOpenMyPlayerTab}
              className="px-3.5 py-2 rounded-xl bg-purple-600/80 hover:bg-purple-500 text-white text-xs font-black transition-all flex items-center gap-1 border border-purple-400/30 active:scale-95 shadow-lg"
            >
              <span>{t('DEVELOPMENT_DETAILS')}</span>
              <ChevronRight className="w-3.5 h-3.5 text-amber-300" />
            </button>
          </div>

        </div>

      </div>

      {/* 2. NEXT MATCH & INDIVIDUAL MATCH CHALLENGE */}
      <div className="bg-gradient-to-br from-[#181232] via-[#120e26] to-[#0d091d] border border-[#332657] rounded-3xl p-4 sm:p-5 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Match Info Header */}
        <div className="flex flex-col gap-2 w-full md:w-7/12">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
              <Calendar className="w-3 h-3 text-emerald-400" /> {t('LEAGUE_MATCH_WEEK').replace('{week}', String(currentWeek))}
            </span>
            <span className="text-xs text-slate-400 font-bold">{t('STADIUM')}: {currentTeam.stadiumName}</span>
          </div>

          <div className="flex items-center gap-3 bg-[#0f0b21] p-3 rounded-2xl border border-purple-900/40">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${currentTeam.badgeColor} flex items-center justify-center font-black text-sm text-white shadow`}>
              {currentTeam.shortName}
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-black text-white">{currentTeam.name} vs {opponentTeam.name}</span>
              <span className="text-xs font-semibold text-purple-300">
                {t('TOUGH_NEXT_OPPONENT')}: <strong className="text-amber-300">{opponentTeam.name}</strong>
              </span>
            </div>
          </div>

          {/* Personal Match Objectives */}
          <div className="space-y-1.5 mt-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-amber-400 flex items-center gap-1">
              <Target className="w-3 h-3 text-amber-400" /> {t('MATCH_OBJECTIVES')}:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs text-slate-200">
              <div className="bg-[#16102e] px-2.5 py-1.5 rounded-xl border border-purple-800/40 flex items-center gap-2">
                <span className="text-emerald-400 font-bold">⚽</span>
                <span>{t('OBJECTIVE_GOAL_ASSIST')} <strong className="text-emerald-400">(+100 XP)</strong></span>
              </div>
              <div className="bg-[#16102e] px-2.5 py-1.5 rounded-xl border border-purple-800/40 flex items-center gap-2">
                <span className="text-amber-400 font-bold">⭐</span>
                <span>{t('OBJECTIVE_RATING')} <strong className="text-amber-400">(+50 XP)</strong></span>
              </div>
            </div>
          </div>
        </div>

        {/* Big Action CTA Button */}
        <div className="w-full md:w-5/12 flex flex-col items-center justify-center p-2">
          <button
            onClick={onPlayMatch}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-emerald-600 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black text-base sm:text-lg uppercase tracking-wider shadow-[0_0_30px_rgba(16,185,129,0.4)] transition-all transform hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 border border-emerald-300/40 cursor-pointer"
          >
            <Sparkles className="w-5 h-5 text-slate-950 animate-bounce" />
            <span>{t('ENTER_PITCH_PLAY')}</span>
          </button>
          <span className="text-[10px] text-slate-400 font-extrabold mt-2 text-center">
            {t('PLAY_KEY_ROLE_SLOGAN')}
          </span>
        </div>

      </div>

      {/* 3. SEASON STATS & COACH'S TRUST DASHBOARD */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        
        {/* Season Stats Box */}
        <div className="bg-[#181232] border border-[#2e234e] rounded-2xl p-3.5 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-black text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Trophy className="w-4 h-4 text-amber-400" /> {t('SEASON_STATS')}
            </span>
            <span className="text-[10px] font-extrabold text-purple-300 bg-purple-900/40 px-2 py-0.5 rounded-md">
              {t('MATCHES_PLAYED_COUNT').replace('{count}', String(matches))}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="bg-[#100c22] p-2 rounded-xl border border-purple-900/30">
              <span className="text-xl font-black text-emerald-400 block">{goals}</span>
              <span className="text-[10px] font-extrabold text-slate-400 uppercase">{t('GOALS_SHORT')}</span>
            </div>
            <div className="bg-[#100c22] p-2 rounded-xl border border-purple-900/30">
              <span className="text-xl font-black text-sky-400 block">{assists}</span>
              <span className="text-[10px] font-extrabold text-slate-400 uppercase">{t('ASSISTS_SHORT')}</span>
            </div>
            <div className="bg-[#100c22] p-2 rounded-xl border border-purple-900/30">
              <span className="text-xl font-black text-amber-400 block">{avgRating}</span>
              <span className="text-[10px] font-extrabold text-slate-400 uppercase">{t('AVG_RATING')}</span>
            </div>
          </div>
        </div>

        {/* Coach Trust Box */}
        <div className="bg-[#181232] border border-[#2e234e] rounded-2xl p-3.5 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-black text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <UserCheck className="w-4 h-4 text-emerald-400" /> {t('HEAD_COACH_TRUST')}
            </span>
            <span className="text-xs font-black text-emerald-400">%94</span>
          </div>

          <p className="text-xs text-slate-300 font-medium leading-tight mb-2">
            {t('YOUR_ROLE')}: <strong className="text-amber-300 font-bold">{t('UNDISPUTED_STARTER')}</strong>. {t('COACH_SATISFIED_TEXT')}
          </p>

          <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden border border-purple-900/40">
            <div className="bg-gradient-to-r from-emerald-500 to-teal-300 h-full rounded-full" style={{ width: '94%' }} />
          </div>
        </div>

        {/* Agent & Rumors Banner */}
        <div
          onClick={onOpenNewsTab}
          className="bg-[#181232] border border-[#2e234e] hover:border-purple-500/50 rounded-2xl p-3.5 flex flex-col justify-between shadow-lg cursor-pointer group transition-all"
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-black text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Briefcase className="w-4 h-4 text-purple-400" /> {t('AGENT_RUMORS')}
            </span>
            <span className="text-[10px] font-black text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-md">
              {t('NEWS_LINK')}
            </span>
          </div>

          <p className="text-xs text-purple-200/90 font-medium line-clamp-2">
            {t('AGENT_RUMORS_TEXT')}
          </p>
        </div>

      </div>

    </div>
  );
};
