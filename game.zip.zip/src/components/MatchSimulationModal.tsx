import React, { useState, useEffect, useRef } from 'react';
import { Team, MatchEvent, MatchStats, PlayerRating, Player, FormationType, TacticType } from '../types';
import { generateMatchEvents, InjuredPlayerInfo } from '../utils/matchEngine';
import { useTranslation } from '../utils/i18n';
import { soundFx } from '../utils/soundEffects';
import { AttackAnimationCanvas } from './AttackAnimationCanvas';
import { TacticalPitch } from './TacticalPitch';
import { TeamBadge } from './TeamBadge';
import confetti from 'canvas-confetti';
import {
  Play,
  Pause,
  FastForward,
  SkipForward,
  X,
  Trophy,
  Shield,
  Activity,
  Flame,
  DollarSign,
  CheckCircle2,
  BarChart2,
  Star,
  AlertTriangle,
  HeartPulse,
  UserCheck,
  Clock,
  Sliders
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';

// Formation coordinates for in-match tactical pitch view
const getPitchPosition = (index: number, formationStr: string = '4-4-2') => {
  if (index === 0) return { top: '86%', left: '50%' }; // GK
  switch (formationStr) {
    case '4-3-3':
      if (index === 1) return { top: '70%', left: '16%' };
      if (index === 2) return { top: '72%', left: '38%' };
      if (index === 3) return { top: '72%', left: '62%' };
      if (index === 4) return { top: '70%', left: '84%' };

      if (index === 5) return { top: '46%', left: '28%' };
      if (index === 6) return { top: '48%', left: '50%' };
      if (index === 7) return { top: '46%', left: '72%' };

      if (index === 8) return { top: '20%', left: '20%' };
      if (index === 9) return { top: '12%', left: '50%' };
      if (index === 10) return { top: '20%', left: '80%' };
      break;

    case '4-4-2':
      if (index === 1) return { top: '70%', left: '16%' };
      if (index === 2) return { top: '72%', left: '38%' };
      if (index === 3) return { top: '72%', left: '62%' };
      if (index === 4) return { top: '70%', left: '84%' };

      if (index === 5) return { top: '46%', left: '16%' };
      if (index === 6) return { top: '48%', left: '38%' };
      if (index === 7) return { top: '48%', left: '62%' };
      if (index === 8) return { top: '46%', left: '84%' };

      if (index === 9) return { top: '14%', left: '36%' };
      if (index === 10) return { top: '14%', left: '64%' };
      break;

    case '3-5-2':
      if (index === 1) return { top: '72%', left: '25%' };
      if (index === 2) return { top: '74%', left: '50%' };
      if (index === 3) return { top: '72%', left: '75%' };

      if (index === 4) return { top: '46%', left: '12%' };
      if (index === 5) return { top: '48%', left: '34%' };
      if (index === 6) return { top: '50%', left: '50%' };
      if (index === 7) return { top: '48%', left: '66%' };
      if (index === 8) return { top: '46%', left: '88%' };

      if (index === 9) return { top: '14%', left: '36%' };
      if (index === 10) return { top: '14%', left: '64%' };
      break;

    default:
      if (index === 1) return { top: '70%', left: '16%' };
      if (index === 2) return { top: '72%', left: '38%' };
      if (index === 3) return { top: '72%', left: '62%' };
      if (index === 4) return { top: '70%', left: '84%' };

      if (index === 5) return { top: '48%', left: '28%' };
      if (index === 6) return { top: '48%', left: '50%' };
      if (index === 7) return { top: '48%', left: '72%' };

      if (index === 8) return { top: '22%', left: '22%' };
      if (index === 9) return { top: '12%', left: '50%' };
      if (index === 10) return { top: '22%', left: '78%' };
      break;
  }
  return { top: '50%', left: '50%' };
};

interface MatchSimulationModalProps {
  homeTeam: Team;
  awayTeam: Team;
  weekNumber: number;
  userTeamId?: string;
  initialQuickSim?: boolean;
  onClose: () => void;
  onMatchCompleted: (homeScore: number, awayScore: number, prizeMoney: number, playerRatings?: PlayerRating[], matchStats?: MatchStats | null, matchEvents?: MatchEvent[]) => void;
  onOpenPlayerProfile?: (player: Player, team?: Team) => void;
  onOpenTeamModal?: (team: Team) => void;
}

export const MatchSimulationModal: React.FC<MatchSimulationModalProps> = ({
  homeTeam,
  awayTeam,
  weekNumber,
  userTeamId,
  initialQuickSim = false,
  onClose,
  onMatchCompleted,
  onOpenPlayerProfile,
  onOpenTeamModal
}) => {
  const { t, language } = useTranslation();
  const lang = (language || 'TR').toUpperCase();
  const [activeTab, setActiveTab] = useState<'LOGS' | 'STATS' | 'RATINGS' | 'REPORT'>('LOGS');

  // Multi-language commentary translator for match events
  const formatMatchEventText = (ev: MatchEvent): string => {
    const pName = ev.playerName;
    const aName = ev.assistantName;
    const gName = ev.gkName;
    const dName = ev.defenderName;

    if (ev.type === 'GOAL') {
      if (ev.isPenalty) {
        if (lang === 'EN') return `🎯 GOAL! ${pName} scores from the penalty spot!`;
        if (lang === 'ES') return `🎯 ¡GOL! ¡${pName} marca desde el punto de penalti!`;
        if (lang === 'FR') return `🎯 BUT ! ${pName} transforme le penalty !`;
        if (lang === 'IT') return `🎯 GOL! ${pName} realizza dal dischetto!`;
        if (lang === 'PT') return `🎯 GOL! ${pName} converte o pênalti!`;
        if (lang === 'DE') return `🎯 TOR! ${pName} verwandelt den Elfmeter!`;
        return `🎯 GOLL! ${pName} penaltıyı gole çevirdi!`;
      }
      if (aName) {
        if (lang === 'EN') return `⚽ GOAL! ${pName} scores with a great assist by ${aName}!`;
        if (lang === 'ES') return `⚽ ¡GOL! ¡${pName} anota con una gran asistencia de ${aName}!`;
        if (lang === 'FR') return `⚽ BUT ! ${pName} marque sur une superbe passe décisive de ${aName} !`;
        if (lang === 'IT') return `⚽ GOL! ${pName} segna su magnifico assist di ${aName}!`;
        if (lang === 'PT') return `⚽ GOL! ${pName} marca após lindo passe de ${aName}!`;
        if (lang === 'DE') return `⚽ TOR! ${pName} trifft nach glänzender Vorarbeit von ${aName}!`;
        return `⚽ GOLL! ${pName}, ${aName}'ın harika pasıyla topu ağlara gönderdi!`;
      }
      if (lang === 'EN') return `⚽ GOAL! ${pName} finishes with a stunning strike!`;
      if (lang === 'ES') return `⚽ ¡GOL! ¡${pName} remata con gran clase al fondo de la red!`;
      if (lang === 'FR') return `⚽ BUT ! ${pName} trompe le gardien d'une superbe frappe !`;
      if (lang === 'IT') return `⚽ GOL! ${pName} trafigge il portiere con una conclusione perfetta!`;
      if (lang === 'PT') return `⚽ GOL! ${pName} finaliza com categoria!`;
      if (lang === 'DE') return `⚽ TOR! ${pName} schließt gekonnt ab!`;
      return `⚽ GOLL! ${pName} harika bir vuruşla golü attı!`;
    }

    if (ev.type === 'YELLOW_CARD') {
      if (lang === 'EN') return `🟨 YELLOW CARD! ${pName} is booked for a foul.`;
      if (lang === 'ES') return `🟨 ¡TARJETA AMARILLA! ${pName} ve la cartulina por falta.`;
      if (lang === 'FR') return `🟨 CARTON JAUNE ! ${pName} est averti pour une faute.`;
      if (lang === 'IT') return `🟨 CARTELLINO GIALLO! ${pName} viene ammonito.`;
      if (lang === 'PT') return `🟨 CARTÃO AMARELO! ${pName} é advertido pelo árbitro.`;
      if (lang === 'DE') return `🟨 GELBE KARTE! ${pName} wird verwarnt.`;
      return `🟨 SARI KART! ${pName} yaptığı faul sonucu sarı kart gördü.`;
    }

    if (ev.type === 'RED_CARD') {
      if (lang === 'EN') return `🟥 RED CARD! ${pName} is sent off!`;
      if (lang === 'ES') return `🟥 ¡TARJETA ROJA! ¡${pName} es expulsado del campo!`;
      if (lang === 'FR') return `🟥 CARTON ROUGE ! ${pName} est expulsé !`;
      if (lang === 'IT') return `🟥 CARTELLINO ROSSO! ${pName} viene espulso!`;
      if (lang === 'PT') return `🟥 CARTÃO VERMELHO! ${pName} é expulso!`;
      if (lang === 'DE') return `🟥 ROTE KARTE! ${pName} fliegt vom Platz!`;
      return `🟥 KIRMIZI KART! ${pName} kırmızı kart görerek oyundan atıldı!`;
    }

    if (ev.type === 'INJURY') {
      if (lang === 'EN') return `🚑 INJURY! ${pName} is injured and substituted off.`;
      if (lang === 'ES') return `🚑 ¡LESIÓN! ${pName} cae lesionado y pide el cambio.`;
      if (lang === 'FR') return `🚑 BLESSURE ! ${pName} se blesse et doit céder sa place.`;
      if (lang === 'IT') return `🚑 INFORTUNIO! ${pName} si fa male e deve uscire.`;
      if (lang === 'PT') return `🚑 LESÃO! ${pName} se lesiona e precisa ser substituído.`;
      if (lang === 'DE') return `🚑 VERLETZUNG! ${pName} verletzt sich und muss ausgewechselt werden.`;
      return `🚑 SAKATLIK! ${pName} sakatlanarak oyundan çıkmak zorunda kaldı.`;
    }

    if (ev.type === 'SAVE') {
      if (lang === 'EN') return `🧤 SAVE! ${gName || 'Goalkeeper'} denies ${pName}'s dangerous attempt!`;
      if (lang === 'ES') return `🧤 ¡PARADÓN! ${gName || 'El portero'} evita el gol tras el remate de ${pName}!`;
      if (lang === 'FR') return `🧤 BEL ARRÊT ! ${gName || 'Le gardien'} s'interpose devant le tir de ${pName} !`;
      if (lang === 'IT') return `🧤 CHE PARATA! ${gName || 'Il portiere'} neutralizza il tiro di ${pName}!`;
      if (lang === 'PT') return `🧤 DEFESONA! ${gName || 'O goleiro'} espalma o chute perigoso de ${pName}!`;
      if (lang === 'DE') return `🧤 GLANZPARADE! ${gName || 'Der Torwart'} pariert den Schuss von ${pName}!`;
      return `🧤 KURTARIŞ! ${gName || 'Kaleci'}, ${pName}'ın tehlikeli şutunu kurtardı!`;
    }

    if (ev.type === 'POST') {
      if (lang === 'EN') return `💥 WOODWORK! ${pName}'s shot rattles the post!`;
      if (lang === 'ES') return `💥 ¡AL PALO! ¡El remate de ${pName} pega en el poste!`;
      if (lang === 'FR') return `💥 SUR LE POTEAU ! La frappe de ${pName} heurte le montant !`;
      if (lang === 'IT') return `💥 PALO! Il tiro di ${pName} colpisce il legno!`;
      if (lang === 'PT') return `💥 NA TRAVE! O chute de ${pName} carimba a trave!`;
      if (lang === 'DE') return `💥 PFOSTEN! Der Abschluss von ${pName} prallt vom Aluminium ab!`;
      return `💥 DİREK! ${pName}'ın şutu direkten döndü!`;
    }

    if (ev.type === 'BLOCK') {
      if (lang === 'EN') return `🛡️ BLOCKED! ${dName || 'Defender'} makes a crucial block on ${pName}!`;
      if (lang === 'ES') return `🛡️ ¡BLOQUEO! ${dName || 'La defensa'} desvía el remate de ${pName}!`;
      if (lang === 'FR') return `🛡️ CONTRÉ ! ${dName || 'Le défenseur'} bloque la frappe de ${pName} !`;
      if (lang === 'IT') return `🛡️ MURATO! ${dName || 'Il difensore'} devia la conclusione di ${pName}!`;
      if (lang === 'PT') return `🛡️ BLOQUEADO! ${dName || 'A zaga'} corta o chute de ${pName}!`;
      if (lang === 'DE') return `🛡️ GEBLOCKT! ${dName || 'Die Abwehr'} fängt den Schuss von ${pName} ab!`;
      return `🛡️ SAVUNMA! ${dName || 'Savunma'}, ${pName}'ın şutunu engelledi!`;
    }

    if (ev.type === 'CORNER') {
      if (lang === 'EN') return `🚩 CORNER! Attacking pressure leads to a corner kick.`;
      if (lang === 'ES') return `🚩 ¡CÓRNER! La presión ofensiva provoca un saque de esquina.`;
      if (lang === 'FR') return `🚩 CORNER ! La pression offensive débouche sur un corner.`;
      if (lang === 'IT') return `🚩 CALCIO D'ANGOLO! L'azione d'attacco porta a un corner.`;
      if (lang === 'PT') return `🚩 ESCANTEIO! A pressão ofensiva resulta em tiro de canto.`;
      if (lang === 'DE') return `🚩 ECKBALL! Druckvoller Angriff führt zur Ecke.`;
      return `🚩 KORNER! Gelişen atakta top kornere çıktı.`;
    }

    if (ev.type === 'MISS') {
      if (lang === 'EN') return `❌ MISS! ${pName}'s shot goes wide of the target.`;
      if (lang === 'ES') return `❌ ¡FUERA! El disparo de ${pName} se marcha desviado.`;
      if (lang === 'FR') return `❌ RATÉ ! Le tir de ${pName} passe à côté.`;
      if (lang === 'IT') return `❌ FUORI! Il tiro di ${pName} si spegne sul fondo.`;
      if (lang === 'PT') return `❌ PRA FORA! O chute de ${pName} sai pela linha de fundo.`;
      if (lang === 'DE') return `❌ VERBEI! Der Schuss von ${pName} verfehlt das Tor.`;
      return `❌ AUT! ${pName}'ın şutu auta gitti.`;
    }

    return ev.text;
  };
  
  const [events, setEvents] = useState<MatchEvent[]>([]);
  const [stats, setStats] = useState<MatchStats | null>(null);
  const [injuredList, setInjuredList] = useState<InjuredPlayerInfo[]>([]);
  const [playerRatings, setPlayerRatings] = useState<PlayerRating[]>([]);
  
  const [visibleEvents, setVisibleEvents] = useState<MatchEvent[]>([]);
  
  const [currentMinute, setCurrentMinute] = useState(0);
  const [scoreHome, setScoreHome] = useState(0);
  const [scoreAway, setScoreAway] = useState(0);
  
  const [isPlaying, setIsPlaying] = useState(!initialQuickSim);
  const [isHalftime, setIsHalftime] = useState(false);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);
  const [isFinished, setIsFinished] = useState(initialQuickSim);
  const [prizeEarned, setPrizeEarned] = useState<number>(0);
  const [isAttackAnimating, setIsAttackAnimating] = useState(false);

  // Mid-match tactical changes & substitutions state
  const [isTacticsModalOpen, setIsTacticsModalOpen] = useState(false);
  const [tacticalMentality, setTacticalMentality] = useState<string>('DENGELİ');
  const [subsMade, setSubsMade] = useState(0);
  const [subStarterId, setSubStarterId] = useState<string | null>(null);
  const [subBenchId, setSubBenchId] = useState<string | null>(null);

  // In-match Injury Sideline Intervention Decision state
  interface InjuryDecisionInfo {
    player: Player;
    team: Team;
    isUserTeam: boolean;
    injuryType: string;
    weeks: number;
    minute: number;
  }
  const [activeInjuryDecision, setActiveInjuryDecision] = useState<InjuryDecisionInfo | null>(null);
  const [handledInjuryIds, setHandledInjuryIds] = useState<string[]>([]);
  const [isInjurySubSelectionOpen, setIsInjurySubSelectionOpen] = useState(false);
  const [selectedInjurySubId, setSelectedInjurySubId] = useState<string | null>(null);
  // Freeze homeTeam and awayTeam on mount so match display never changes if currentWeek updates
  const [frozenMatchTeams] = useState(() => ({
    home: homeTeam,
    away: awayTeam
  }));
  const homeTeamFixed = frozenMatchTeams.home;
  const awayTeamFixed = frozenMatchTeams.away;

  const [matchLineups, setMatchLineups] = useState<{ home: Team; away: Team }>({ home: homeTeamFixed, away: awayTeamFixed });

  const logsContainerRef = useRef<HTMLDivElement>(null);

  const hasCompletedRef = useRef(false);

  // Initialize match generation
  useEffect(() => {
    if (hasCompletedRef.current) return;

    const generated = generateMatchEvents(homeTeamFixed, awayTeamFixed, undefined, userTeamId);
    setEvents(generated.events);
    setStats(generated.stats);
    setInjuredList(generated.injuredPlayers);
    setPlayerRatings(generated.playerRatings);
    setMatchLineups({ home: homeTeamFixed, away: awayTeamFixed });

    if (initialQuickSim) {
      hasCompletedRef.current = true;
      setScoreHome(generated.finalHomeScore);
      setScoreAway(generated.finalAwayScore);
      setVisibleEvents(generated.events);
      setIsFinished(true);
      setIsPlaying(false);
      setActiveTab('REPORT');

      let reward = 500000;
      if (generated.finalHomeScore > generated.finalAwayScore) reward = 1500000;
      else if (generated.finalHomeScore < generated.finalAwayScore) reward = 200000;
      setPrizeEarned(reward);

      onMatchCompleted(generated.finalHomeScore, generated.finalAwayScore, reward);
    }
  }, [homeTeamFixed, awayTeamFixed, userTeamId, initialQuickSim]);

  // Calculate Stoppage Time dynamically based on match events in 1st and 2nd half (Cap at +8 minutes max)
  const stoppage1stHalf = React.useMemo(() => {
    if (events.length === 0) return 2;
    const h1Events = events.filter(e => e.minute <= 45);
    const foulsAndCards = h1Events.filter(e => e.type === 'YELLOW_CARD' || e.type === 'RED_CARD' || e.type === 'FOUL').length;
    const goalsAndSubs = h1Events.filter(e => e.type === 'GOAL' || (e.type as string) === 'SUBSTITUTION' || (e.type as string) === 'INJURY' || (e.type as string) === 'PENALTY').length;
    const calculated = Math.round(foulsAndCards * 0.4 + goalsAndSubs * 1.0 + (h1Events.length % 3));
    return Math.min(8, Math.max(1, calculated || 2));
  }, [events]);

  const stoppage2ndHalf = React.useMemo(() => {
    if (events.length === 0) return 3;
    const h2Events = events.filter(e => e.minute > 45);
    const foulsAndCards = h2Events.filter(e => e.type === 'YELLOW_CARD' || e.type === 'RED_CARD' || e.type === 'FOUL').length;
    const goalsAndSubs = h2Events.filter(e => e.type === 'GOAL' || (e.type as string) === 'SUBSTITUTION' || (e.type as string) === 'INJURY' || (e.type as string) === 'PENALTY').length;
    const calculated = Math.round(foulsAndCards * 0.4 + goalsAndSubs * 1.1 + (h2Events.length % 4));
    return Math.min(8, Math.max(2, calculated || 3));
  }, [events]);

  // Format minute for display (including 45+X and 90+X)
  const getDisplayMinuteStr = (minIndex: number) => {
    if (minIndex <= 0) return "0'";
    if (minIndex <= 45) return `${minIndex}'`;
    if (minIndex <= 45 + stoppage1stHalf) {
      const extra = minIndex - 45;
      return `45+${extra}'`;
    }
    const real2ndMin = minIndex - stoppage1stHalf; // scale 46..90
    if (real2ndMin <= 90) return `${real2ndMin}'`;
    const extra2 = real2ndMin - 90;
    return `90+${extra2}'`;
  };

  // Map simulation index to game minute (1..45, 46..90) for event filtering
  const getGameMinuteFromIndex = (minIndex: number) => {
    if (minIndex <= 45) return minIndex;
    if (minIndex <= 45 + stoppage1stHalf) return 45;
    const m = minIndex - stoppage1stHalf;
    if (m <= 90) return m;
    return 90;
  };

  // Simulation Ticker
  useEffect(() => {
    if (!isPlaying || isFinished || isHalftime || events.length === 0 || isAttackAnimating) return;

    const intervalMs = Math.max(80, Math.round(1000 / speedMultiplier));

    const timer = setInterval(() => {
      setCurrentMinute((prev) => {
        const halftimeThreshold = 45 + stoppage1stHalf;

        // Trigger Halftime pause when 1st half stoppage ends or reached
        if (prev < halftimeThreshold) {
          const next = prev + 1;
          if (next >= halftimeThreshold) {
            setIsHalftime(true);
            setIsPlaying(false);
            setIsTacticsModalOpen(true); // Automatically open halftime lineup screen
            return halftimeThreshold;
          }
          return next;
        }

        // Second half progression
        const next = prev + 1;
        const totalMax = 90 + stoppage1stHalf + stoppage2ndHalf;
        if (next >= totalMax) {
          return totalMax;
        }
        return next;
      });
    }, intervalMs);

    return () => clearInterval(timer);
  }, [isPlaying, isFinished, isHalftime, events, speedMultiplier, stoppage1stHalf, stoppage2ndHalf, isAttackAnimating]);

  // Start Second Half Handler
  const handleStartSecondHalf = () => {
    setIsHalftime(false);
    setIsTacticsModalOpen(false);
    setIsAttackAnimating(false);
    setCurrentMinute(prev => Math.max(prev + 1, 45 + stoppage1stHalf + 1));
    setIsPlaying(true);
  };

  // Handler: When goal/save/miss animation reaches RESULT stage
  const handleAnimationResultReached = (evt: MatchEvent) => {
    if (evt.type === 'GOAL') {
      setScoreHome(evt.scoreHome);
      setScoreAway(evt.scoreAway);

      const isUserGoal = userTeamId ? evt.teamId === userTeamId : evt.teamId === homeTeamFixed.id;
      if (isUserGoal) {
        soundFx.playGoalScored();
      } else {
        soundFx.playGoalConceded();
      }
    }
  };

  // Handle minute tick side-effects
  useEffect(() => {
    if (currentMinute === 0 || events.length === 0) return;

    const gameMin = getGameMinuteFromIndex(currentMinute);
    const matchedEvents = events.filter(e => e.minute === gameMin);

    if (matchedEvents.length > 0) {
      const existingIds = new Set(visibleEvents.map(e => e.id));
      const newEvents = matchedEvents.filter(e => !existingIds.has(e.id));

      if (newEvents.length > 0) {
        setVisibleEvents((prevLogs) => {
          const ids = new Set(prevLogs.map(e => e.id));
          const uniqueNew = newEvents.filter(e => !ids.has(e.id));
          return uniqueNew.length > 0 ? [...prevLogs, ...uniqueNew] : prevLogs;
        });
        
        // Check for Injury event to trigger sideline intervention decision
        const injuryEvt = newEvents.find(e => e.type === 'INJURY');
        if (injuryEvt && !handledInjuryIds.includes(injuryEvt.id) && !initialQuickSim) {
          setHandledInjuryIds(prev => [...prev, injuryEvt.id]);
          const isHomeInjured = !!injuryEvt.isHomeTeamEvent;
          const targetTeam = isHomeInjured ? homeTeamFixed : awayTeamFixed;
          const pName = injuryEvt.playerName;
          const targetPlayer = targetTeam.players.find(p => p.name === pName || p.id === injuryEvt.playerId) || 
                               targetTeam.players.find(p => p.isStarting) || 
                               targetTeam.players[0];
          const injItem = injuredList.find(inj => inj.playerId === targetPlayer?.id || inj.playerName === pName);
          const isUser = userTeamId ? targetTeam.id === userTeamId : isHomeInjured;

          if (targetPlayer) {
            setActiveInjuryDecision({
              player: targetPlayer,
              team: targetTeam,
              isUserTeam: isUser,
              injuryType: injItem?.injuryType || 'Adale Zorlanması',
              weeks: injItem?.weeks || 2,
              minute: injuryEvt.minute
            });
            setIsInjurySubSelectionOpen(false);
            setSelectedInjurySubId(null);
            setIsPlaying(false);
            soundFx.playWhistle();
          }
        }

        // For non-goal events, update scoreboard directly.
        // Goal events will update scoreboard at RESULT stage via onResultReached.
        const lastEvent = newEvents[newEvents.length - 1];
        if (lastEvent.type !== 'GOAL') {
          setScoreHome(lastEvent.scoreHome);
          setScoreAway(lastEvent.scoreAway);
        }

        // Only pause simulation for animations on real match actions (not HALF_TIME or non-attack logs)
        const hasAnimatableAction = newEvents.some(e => 
          e.type === 'GOAL' || 
          e.type === 'SAVE' || 
          e.type === 'CORNER' || 
          e.type === 'YELLOW_CARD' || 
          e.type === 'RED_CARD' ||
          (e.text && (e.text.includes('DİREK') || e.text.includes('direk') || e.text.includes('auta') || e.text.includes('blok') || e.text.includes('PENALTI') || e.text.includes('Penaltı')))
        );

        if (hasAnimatableAction && !isFinished && !initialQuickSim && !injuryEvt) {
          setIsAttackAnimating(true);
        }
      }
    }
  }, [currentMinute, events, userTeamId, homeTeamFixed.id, isFinished, initialQuickSim, handledInjuryIds, injuredList, visibleEvents]);

  const formatCurrency = (amount: number) => {
    return `€${(amount / 1_000_000).toFixed(1)}M`;
  };

  // Real-time live stats calculation
  // Dynamic Real-time Player Ratings Calculation
  const calculateLiveTeamRatings = (team: Team, oppScore: number, myScore: number, isHomeTeam: boolean) => {
    const starters = team.players.filter(p => p.isStarting);
    const scoreDiff = myScore - oppScore;

    // Identify faulty player(s) if opponent scored goals
    // The player with cards or specific defensive role with lowest defensive rating or carded gets the blunder flag
    const teamEvents = visibleEvents.filter(e => (e.teamId ? e.teamId === team.id : isHomeTeam === !!e.isHomeTeamEvent));
    const oppGoalEvents = visibleEvents.filter(e => e.type === 'GOAL' && (e.teamId ? e.teamId !== team.id : isHomeTeam !== !!e.isHomeTeamEvent));

    return starters.map((p, idx) => {
      // Unique organic variation seed per player
      const charSum = p.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
      const playerSeed = (charSum + idx * 11) % 9;
      const organicVariance = ((playerSeed - 4) * 0.06);
      
      let base = 6.4 + (p.overall - 75) * 0.02 + organicVariance;

      const pGoals = visibleEvents.filter(e => e.type === 'GOAL' && (e.scorerId === p.id || (e.playerName && e.playerName.includes(p.name)))).length;
      const pAssists = visibleEvents.filter(e => e.type === 'GOAL' && (e.assistantId === p.id || (e.assistantName && e.assistantName.includes(p.name)))).length;
      const pShots = visibleEvents.filter(e => (e.type === 'SHOT' || e.type === 'GOAL') && (e.playerName && e.playerName.includes(p.name))).length;
      const pYellow = visibleEvents.some(e => e.type === 'YELLOW_CARD' && (e.playerName && e.playerName.includes(p.name)));
      const pRed = visibleEvents.some(e => e.type === 'RED_CARD' && (e.playerName && e.playerName.includes(p.name)));
      const pSaves = p.position === 'GK' ? visibleEvents.filter(e => e.type === 'SAVE' && (e.teamId ? e.teamId === team.id : isHomeTeam === !!e.isHomeTeamEvent)).length : 0;

      // Positive contributions
      base += pGoals * 1.45;
      base += pAssists * 1.10;
      base += Math.max(0, pShots - pGoals) * 0.22;
      base += pSaves * 0.55;

      // Conceded goals impact
      if (oppScore > 0) {
        if (p.position === 'GK') {
          base -= oppScore * 0.45;
        } else if (p.position === 'DEF') {
          base -= oppScore * 0.38;
        } else if (p.position === 'MID') {
          base -= oppScore * 0.20;
        } else {
          base -= oppScore * 0.10;
        }
      }

      // Check if this player made a critical error / blunder on conceded goals
      // A defender or GK who has a card or is the designated culprit for a conceded goal gets a severe blunder penalty
      let hasBlunder = false;
      if (oppGoalEvents.length > 0) {
        if (pRed) {
          hasBlunder = true;
          base -= 2.2;
        } else if (pYellow && (p.position === 'DEF' || p.position === 'GK')) {
          hasBlunder = true;
          base -= 1.4;
        } else if ((p.position === 'DEF' || p.position === 'GK') && (idx === ((oppGoalEvents.length * 3 + playerSeed) % starters.filter(s => s.position === 'DEF' || s.position === 'GK').length))) {
          hasBlunder = true;
          base -= (1.3 + (oppGoalEvents.length * 0.3));
        }
      }

      // Match outcome / scoreboard momentum
      if (scoreDiff > 0) {
        base += Math.min(1.0, scoreDiff * 0.28);
      } else if (scoreDiff < 0) {
        base -= Math.min(1.1, Math.abs(scoreDiff) * 0.28);
      }

      if (pYellow) base -= 0.4;
      if (pRed) base -= 2.4;

      // Natural spread - prevent static repetitive numbers
      const decimalSpread = ((charSum * 3 + currentMinute) % 7) * 0.04;
      base += (decimalSpread - 0.12);

      const finalRating = Math.min(9.9, Math.max(3.4, Math.round(base * 10) / 10));

      return {
        playerId: p.id,
        playerName: p.name,
        position: p.specificRole || p.position,
        teamId: team.id,
        rating: finalRating,
        goals: pGoals,
        assists: pAssists,
        hasBlunder
      };
    });
  };

  const rawHomeRatings = playerRatings.filter(pr => pr.teamId === homeTeamFixed.id);
  const homeRatings = calculateLiveTeamRatings(homeTeamFixed, scoreAway, scoreHome, true);

  const rawAwayRatings = playerRatings.filter(pr => pr.teamId === awayTeamFixed.id);
  const awayRatings = calculateLiveTeamRatings(awayTeamFixed, scoreHome, scoreAway, false);

  const liveCombinedRatings = React.useMemo(() => {
    return [...homeRatings, ...awayRatings];
  }, [homeRatings, awayRatings]);

  const liveStats = React.useMemo(() => {
    const fraction = Math.min(1, Math.max(0.06, currentMinute / 90));
    
    // Direct synchronicity with live commentary visible events
    let hShots = visibleEvents.filter(e => (e.type === 'SHOT' || e.type === 'GOAL' || e.type === 'MISS' || e.type === 'SAVE') && (e.teamId ? e.teamId === homeTeamFixed.id : !!e.isHomeTeamEvent)).length;
    let aShots = visibleEvents.filter(e => (e.type === 'SHOT' || e.type === 'GOAL' || e.type === 'MISS' || e.type === 'SAVE') && (e.teamId ? e.teamId === awayTeamFixed.id : !e.isHomeTeamEvent)).length;
    
    hShots = Math.max(hShots, scoreHome);
    aShots = Math.max(aShots, scoreAway);

    let hTarget = visibleEvents.filter(e => (e.type === 'GOAL' || e.type === 'SAVE') && (e.teamId ? e.teamId === homeTeamFixed.id : !!e.isHomeTeamEvent)).length;
    let aTarget = visibleEvents.filter(e => (e.type === 'GOAL' || e.type === 'SAVE') && (e.teamId ? e.teamId === awayTeamFixed.id : !e.isHomeTeamEvent)).length;
    
    hTarget = Math.max(scoreHome, Math.min(hShots, hTarget));
    aTarget = Math.max(scoreAway, Math.min(aShots, aTarget));

    const hCorners = visibleEvents.filter(e => e.type === 'CORNER' && (e.teamId ? e.teamId === homeTeamFixed.id : !!e.isHomeTeamEvent)).length;
    const aCorners = visibleEvents.filter(e => e.type === 'CORNER' && (e.teamId ? e.teamId === awayTeamFixed.id : !e.isHomeTeamEvent)).length;

    const hYellow = visibleEvents.filter(e => e.type === 'YELLOW_CARD' && (e.teamId ? e.teamId === homeTeamFixed.id : !!e.isHomeTeamEvent)).length;
    const aYellow = visibleEvents.filter(e => e.type === 'YELLOW_CARD' && (e.teamId ? e.teamId === awayTeamFixed.id : !e.isHomeTeamEvent)).length;

    const hRed = visibleEvents.filter(e => e.type === 'RED_CARD' && (e.teamId ? e.teamId === homeTeamFixed.id : !!e.isHomeTeamEvent)).length;
    const aRed = visibleEvents.filter(e => e.type === 'RED_CARD' && (e.teamId ? e.teamId === awayTeamFixed.id : !e.isHomeTeamEvent)).length;

    const hFouls = visibleEvents.filter(e => (e.type === 'FOUL' || e.type === 'YELLOW_CARD' || e.type === 'RED_CARD') && (e.teamId ? e.teamId === homeTeamFixed.id : !!e.isHomeTeamEvent)).length;
    const aFouls = visibleEvents.filter(e => (e.type === 'FOUL' || e.type === 'YELLOW_CARD' || e.type === 'RED_CARD') && (e.teamId ? e.teamId === awayTeamFixed.id : !e.isHomeTeamEvent)).length;

    // Organic possession calculation based on live event momentum
    const momentumDelta = (hShots - aShots) * 2;
    const basePoss = stats?.possessionHome || 50;
    const currentPoss = Math.max(30, Math.min(70, Math.round(basePoss + momentumDelta)));
    const awayPoss = 100 - currentPoss;

    const hSaves = Math.max(0, aTarget - scoreAway);
    const aSaves = Math.max(0, hTarget - scoreHome);

    const hPassAcc = Math.min(92, Math.max(68, Math.round(72 + currentPoss * 0.25)));
    const aPassAcc = Math.min(92, Math.max(68, Math.round(72 + awayPoss * 0.25)));

    const hXG = (hShots * 0.08 + hTarget * 0.22 + scoreHome * 0.4).toFixed(2);
    const aXG = (aShots * 0.08 + aTarget * 0.22 + scoreAway * 0.4).toFixed(2);

    return {
      possessionHome: currentPoss,
      possessionAway: awayPoss,
      shotsHome: hShots,
      shotsAway: aShots,
      shotsOnTargetHome: hTarget,
      shotsOnTargetAway: aTarget,
      cornersHome: hCorners,
      cornersAway: aCorners,
      foulsHome: hFouls,
      foulsAway: aFouls,
      yellowCardsHome: hYellow,
      yellowCardsAway: aYellow,
      yellowHome: hYellow,
      yellowAway: aYellow,
      redHome: hRed,
      redAway: aRed,
      savesHome: hSaves,
      savesAway: aSaves,
      passAccuracyHome: hPassAcc,
      passAccuracyAway: aPassAcc,
      xGHome: hXG,
      xGAway: aXG
    };
  }, [stats, currentMinute, visibleEvents, scoreHome, scoreAway, homeTeamFixed.id, awayTeamFixed.id]);

  const activeStats: MatchStats = liveStats || stats || {
    possessionHome: 50,
    possessionAway: 50,
    shotsHome: scoreHome,
    shotsAway: scoreAway,
    shotsOnTargetHome: scoreHome,
    shotsOnTargetAway: scoreAway,
    cornersHome: 3,
    cornersAway: 3,
    foulsHome: 5,
    foulsAway: 5,
    yellowCardsHome: 0,
    yellowCardsAway: 0,
    yellowHome: 0,
    yellowAway: 0,
    redHome: 0,
    redAway: 0,
    savesHome: 0,
    savesAway: 0,
    passAccuracyHome: 78,
    passAccuracyAway: 78,
    xGHome: (scoreHome * 0.5).toFixed(2),
    xGAway: (scoreAway * 0.5).toFixed(2)
  };

  useEffect(() => {
    const totalMax = 90 + stoppage1stHalf + stoppage2ndHalf;

    if (currentMinute >= totalMax && !isFinished) {
      if (hasCompletedRef.current) return;
      hasCompletedRef.current = true;
      setIsFinished(true);
      setIsPlaying(false);
      setActiveTab('REPORT');
      soundFx.playWhistle();

      let reward = 500000;
      if (scoreHome > scoreAway) {
        reward = 1500000;
        confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
      } else if (scoreHome < scoreAway) {
        reward = 200000;
      }
      setPrizeEarned(reward);

      onMatchCompleted(scoreHome, scoreAway, reward, liveCombinedRatings, activeStats, events);
    }
  }, [currentMinute, events, isFinished, scoreHome, scoreAway, stoppage1stHalf, stoppage2ndHalf, onMatchCompleted, liveCombinedRatings, activeStats]);

  useEffect(() => {
    if (logsContainerRef.current) {
      logsContainerRef.current.scrollTop = logsContainerRef.current.scrollHeight;
    }
  }, [visibleEvents]);

  const handleFinishInstantly = () => {
    if (hasCompletedRef.current) return;
    hasCompletedRef.current = true;

    const totalMax = 90 + stoppage1stHalf + stoppage2ndHalf;
    setCurrentMinute(totalMax);
    setIsHalftime(false);
    setIsAttackAnimating(false);
    setVisibleEvents(events);
    let finalHome = scoreHome;
    let finalAway = scoreAway;
    if (events.length > 0) {
      const last = events[events.length - 1];
      finalHome = last.scoreHome;
      finalAway = last.scoreAway;
      setScoreHome(finalHome);
      setScoreAway(finalAway);
    }
    setIsFinished(true);
    setIsPlaying(false);
    setActiveTab('REPORT');

    let reward = 500000;
    if (finalHome > finalAway) reward = 1500000;
    else if (finalHome < finalAway) reward = 200000;
    setPrizeEarned(reward);

    const finalRatings = calculateLiveTeamRatings(homeTeamFixed, finalAway, finalHome, true)
      .concat(calculateLiveTeamRatings(awayTeamFixed, finalHome, finalAway, false));

    onMatchCompleted(finalHome, finalAway, reward, finalRatings, stats || activeStats, events);
  };

  // Goal Scorers List for Header & Report
  const homeGoalEvents = visibleEvents.filter(e => e.type === 'GOAL' && (e.teamId ? e.teamId === homeTeamFixed.id : !!e.isHomeTeamEvent));
  const awayGoalEvents = visibleEvents.filter(e => e.type === 'GOAL' && (e.teamId ? e.teamId === awayTeamFixed.id : !e.isHomeTeamEvent));

  const homeCardEvents = visibleEvents.filter(e => (e.type === 'YELLOW_CARD' || e.type === 'RED_CARD') && (e.teamId ? e.teamId === homeTeamFixed.id : !!e.isHomeTeamEvent));
  const awayCardEvents = visibleEvents.filter(e => (e.type === 'YELLOW_CARD' || e.type === 'RED_CARD') && (e.teamId ? e.teamId === awayTeamFixed.id : !e.isHomeTeamEvent));

  // Missed penalties for summary
  const homeMissedPenalties = visibleEvents.filter(e => (e.isPenaltyMissed || (e.text && e.text.includes('PENALTI KAÇTI'))) && (e.teamId ? e.teamId === homeTeamFixed.id : !!e.isHomeTeamEvent));
  const awayMissedPenalties = visibleEvents.filter(e => (e.isPenaltyMissed || (e.text && e.text.includes('PENALTI KAÇTI'))) && (e.teamId ? e.teamId === awayTeamFixed.id : !e.isHomeTeamEvent));

  const userTeamKey: 'home' | 'away' = userTeamId && awayTeamFixed.id === userTeamId ? 'away' : 'home';
  const activeUserTeam = matchLineups[userTeamKey];

  const renderGoalScorersList = (goalEvs: MatchEvent[], teamObj: Team, missedEvs: MatchEvent[] = []) => {
    if (goalEvs.length === 0 && missedEvs.length === 0) return null;
    const map: Record<string, { items: { minute: number; isPenalty?: boolean; isMissed?: boolean }[]; playerObj?: Player }> = {};
    
    goalEvs.forEach(e => {
      const pName = e.playerName || e.text.split(' ')[0] || 'Oyuncu';
      if (!map[pName]) {
        const found = teamObj.players.find(p => p.name === pName || p.id === e.scorerId || p.id === e.playerId);
        map[pName] = { items: [], playerObj: found };
      }
      const isPen = !!e.isPenalty || e.text.includes('PENALTI GOLÜ') || e.text.includes('penaltı noktasından');
      map[pName].items.push({ minute: e.minute, isPenalty: isPen, isMissed: false });
    });

    missedEvs.forEach(e => {
      const pName = e.playerName || e.text.split(' ')[0] || 'Oyuncu';
      if (!map[pName]) {
        const found = teamObj.players.find(p => p.name === pName || p.id === e.scorerId || p.id === e.playerId);
        map[pName] = { items: [], playerObj: found };
      }
      map[pName].items.push({ minute: e.minute, isPenalty: true, isMissed: true });
    });

    return (
      <div className="flex flex-wrap gap-1 mt-1 max-h-16 overflow-y-auto custom-scrollbar">
        {Object.entries(map).map(([pName, data]) => (
          <button
            key={pName}
            type="button"
            onClick={() => {
              if (data.playerObj && onOpenPlayerProfile) {
                onOpenPlayerProfile(data.playerObj, teamObj);
              }
            }}
            className="px-1.5 py-0.5 rounded-md bg-[#251d3d] hover:bg-purple-900/80 border border-[#3c2f61] text-[9.5px] font-bold text-amber-300 flex items-center gap-1 shrink-0 cursor-pointer transition-all active:scale-95 hover:border-amber-400/50"
            title={`${pName} - ${t('VIEW_PROFILE') || 'Profili Görüntüle'}`}
          >
            <span>⚽ {pName}</span>
            <span className="text-slate-300 font-medium">
              ({data.items.map(it => `${it.minute}'${it.isMissed ? ' (P ❌)' : it.isPenalty ? ' (P)' : ''}`).join(', ')})
            </span>
          </button>
        ))}
      </div>
    );
  };

  const renderCardEventsList = (cardEvs: MatchEvent[], teamObj: Team) => {
    if (cardEvs.length === 0) return null;
    return (
      <div className="flex flex-wrap gap-1 mt-0.5 max-h-12 overflow-y-auto custom-scrollbar">
        {cardEvs.map((e, idx) => {
          const isRed = e.type === 'RED_CARD';
          const pName = e.playerName || 'Oyuncu';
          const playerObj = teamObj.players.find(p => p.name === pName || p.id === e.playerId || p.id === e.scorerId);
          return (
            <button
              key={idx}
              type="button"
              onClick={() => {
                if (playerObj && onOpenPlayerProfile) {
                  onOpenPlayerProfile(playerObj, teamObj);
                }
              }}
              className={`px-1.5 py-0.5 rounded-md text-[9px] font-bold flex items-center gap-1 shrink-0 cursor-pointer transition-all active:scale-95 ${
                isRed
                  ? 'bg-rose-950/80 hover:bg-rose-900 border border-rose-600/80 text-rose-200 hover:border-rose-400'
                  : 'bg-amber-950/80 hover:bg-amber-900 border border-amber-600/80 text-amber-200 hover:border-amber-400'
              }`}
              title={`${pName} - ${t('VIEW_PROFILE') || 'Profili Görüntüle'}`}
            >
              <span>{isRed ? '🟥' : '🟨'} {pName}</span>
              <span className="text-slate-400 font-normal">({e.minute}')</span>
            </button>
          );
        })}
      </div>
    );
  };

  // Tactical Pitch integration in Match Simulation
  const [tacticsSelectedPlayer, setTacticsSelectedPlayer] = useState<Player | null>(null);
  const [sessionSubs, setSessionSubs] = useState<{ outPlayer: string; inPlayer: string; minute: number }[]>([]);
  const [subWarning, setSubWarning] = useState<string | null>(null);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [pendingConfirmAction, setPendingConfirmAction] = useState<'RESUME' | 'START_SECOND_HALF'>('RESUME');

  const handleTacticsSwapPlayers = (p1: Player, p2: Player) => {
    // ALWAYS deselect player immediately after swap so no accidental secondary swap happens
    setTacticsSelectedPlayer(null);

    const isP1Starter = p1.isStarting;
    const isP2Starter = p2.isStarting;
    const isActualSub = (isP1Starter && !isP2Starter) || (!isP1Starter && isP2Starter);

    if (isActualSub && subsMade >= 5) {
      setSubWarning('⚠️ Maksimum 5 oyuncu değişikliği hakkınızı doldurdunuz! (5/5)');
      setTimeout(() => setSubWarning(null), 4000);
      return;
    }

    setMatchLineups((prev) => {
      const teamObj = prev[userTeamKey];
      const playersCopy = [...teamObj.players];
      const idx1 = playersCopy.findIndex(p => p.id === p1.id);
      const idx2 = playersCopy.findIndex(p => p.id === p2.id);

      if (idx1 !== -1 && idx2 !== -1) {
        const pl1 = { ...playersCopy[idx1] };
        const pl2 = { ...playersCopy[idx2] };

        const tempStarting = pl1.isStarting;
        pl1.isStarting = pl2.isStarting;
        pl2.isStarting = tempStarting;

        playersCopy[idx1] = pl2;
        playersCopy[idx2] = pl1;
      }

      return {
        ...prev,
        [userTeamKey]: { ...teamObj, players: playersCopy }
      };
    });

    if (isActualSub) {
      const newSubCount = subsMade + 1;
      setSubsMade(newSubCount);
      const outPlayer = isP1Starter ? p1 : p2;
      const inPlayer = isP1Starter ? p2 : p1;

      setSessionSubs(prev => [
        ...prev,
        { outPlayer: outPlayer.name, inPlayer: inPlayer.name, minute: getGameMinuteFromIndex(currentMinute) }
      ]);

      if (newSubCount >= 5) {
        setSubWarning('ℹ️ 5 oyuncu değişikliği hakkınızın tamamını kullandınız. (5/5)');
        setTimeout(() => setSubWarning(null), 4000);
      }

      const subEvent: MatchEvent = {
        id: `sub-${Date.now()}`,
        minute: getGameMinuteFromIndex(currentMinute),
        text: `🔄 OYUNCU DEĞİŞİKLİĞİ (${activeUserTeam.name}): ${outPlayer.name} ➔ ${inPlayer.name} oyuna girdi!`,
        type: 'SUBSTITUTION',
        teamId: activeUserTeam.id,
        playerName: `${outPlayer.name} ➔ ${inPlayer.name}`,
        isHomeTeamEvent: userTeamKey === 'home',
        scoreHome,
        scoreAway
      };
      setEvents(prev => [...prev, subEvent].sort((a, b) => a.minute - b.minute));
      setVisibleEvents(prev => [...prev, subEvent]);
    }
  };

  const handleRequestCloseTactics = (action: 'RESUME' | 'START_SECOND_HALF') => {
    const effectiveAction = isHalftime ? 'START_SECOND_HALF' : action;
    if (sessionSubs.length > 0) {
      setPendingConfirmAction(effectiveAction);
      setIsConfirmModalOpen(true);
    } else {
      if (effectiveAction === 'START_SECOND_HALF' || isHalftime) {
        handleStartSecondHalf();
      } else {
        setIsTacticsModalOpen(false);
        setIsPlaying(true);
      }
    }
  };

  const handleConfirmChanges = () => {
    setIsConfirmModalOpen(false);
    setSessionSubs([]);
    if (pendingConfirmAction === 'START_SECOND_HALF' || isHalftime) {
      handleStartSecondHalf();
    } else {
      setIsTacticsModalOpen(false);
      setIsPlaying(true);
    }
  };

  const handleTacticsChangeFormation = (newFormation: FormationType) => {
    setMatchLineups((prev) => ({
      ...prev,
      [userTeamKey]: { ...prev[userTeamKey], formation: newFormation }
    }));
  };

  const handleTacticsChangeTactic = (newTactic: TacticType) => {
    setMatchLineups((prev) => ({
      ...prev,
      [userTeamKey]: { ...prev[userTeamKey], tactic: newTactic }
    }));
  };

  const handleTacticsUpdateDetails = (details: Team['tacticalDetails']) => {
    setMatchLineups((prev) => ({
      ...prev,
      [userTeamKey]: { ...prev[userTeamKey], tacticalDetails: details }
    }));
  };

  // Substitution Handler
  const handlePerformSubstitution = () => {
    if (!subStarterId || !subBenchId) return;
    if (subsMade >= 5) {
      setSubWarning('⚠️ Maksimum 5 oyuncu değişikliği hakkınızı doldurdunuz! (5/5)');
      setTimeout(() => setSubWarning(null), 4000);
      return;
    }

    setMatchLineups((prev) => {
      const teamObj = prev[userTeamKey];
      const playersCopy = [...teamObj.players];
      const starterIdx = playersCopy.findIndex(p => p.id === subStarterId);
      const benchIdx = playersCopy.findIndex(p => p.id === subBenchId);

      if (starterIdx !== -1 && benchIdx !== -1) {
        const s = playersCopy[starterIdx];
        const b = playersCopy[benchIdx];
        playersCopy[starterIdx] = { ...b, isStarting: true };
        playersCopy[benchIdx] = { ...s, isStarting: false };
      }

      return {
        ...prev,
        [userTeamKey]: { ...teamObj, players: playersCopy }
      };
    });

    const newSubCount = subsMade + 1;
    setSubsMade(newSubCount);
    const sName = activeUserTeam.players.find(p => p.id === subStarterId)?.name || 'Oyuncu';
    const bName = activeUserTeam.players.find(p => p.id === subBenchId)?.name || 'Oyuncu';

    setSessionSubs(prev => [
      ...prev,
      { outPlayer: sName, inPlayer: bName, minute: getGameMinuteFromIndex(currentMinute) }
    ]);

    setSubStarterId(null);
    setSubBenchId(null);
    setTacticsSelectedPlayer(null);

    // Add substitution event to visible commentary and full event log
    const subEvent: MatchEvent = {
      id: `sub-${Date.now()}`,
      minute: getGameMinuteFromIndex(currentMinute),
      text: `🔄 OYUNCU DEĞİŞİKLİĞİ (${activeUserTeam.name}): ${sName} ➔ ${bName} oyuna girdi!`,
      type: 'SUBSTITUTION',
      teamId: activeUserTeam.id,
      playerName: `${sName} ➔ ${bName}`,
      isHomeTeamEvent: userTeamKey === 'home',
      scoreHome,
      scoreAway
    };
    setEvents(prev => [...prev, subEvent].sort((a, b) => a.minute - b.minute));
    setVisibleEvents(prev => [...prev, subEvent]);
    setIsTacticsModalOpen(false);
  };

  // Sideline Injury Intervention Decision Handlers
  const handleInjuryDecisionContinue = () => {
    if (!activeInjuryDecision) return;
    const p = activeInjuryDecision.player;
    const team = activeInjuryDecision.team;

    const resumeEvent: MatchEvent = {
      id: `inj-continue-${Date.now()}`,
      minute: getGameMinuteFromIndex(currentMinute),
      text: `🩹 SAHA KENARI MÜDAHALESİ: Sağlık ekibi ${p.name}'a buz ve bandaj uyguladı. Oyuncu fedakarlık yaparak maça devam ediyor!`,
      type: 'FOUL',
      teamId: team.id,
      playerName: p.name,
      isHomeTeamEvent: team.id === homeTeamFixed.id,
      scoreHome,
      scoreAway
    };

    setEvents(prev => [...prev, resumeEvent].sort((a, b) => a.minute - b.minute));
    setVisibleEvents(prev => [...prev, resumeEvent]);
    setActiveInjuryDecision(null);
    setIsInjurySubSelectionOpen(false);
    setSelectedInjurySubId(null);
    setIsPlaying(true);
  };

  const handleInjuryDecisionSubstitute = (subPlayer: Player) => {
    if (!activeInjuryDecision || !subPlayer) return;
    const injuredP = activeInjuryDecision.player;
    const team = activeInjuryDecision.team;
    const teamKey: 'home' | 'away' = team.id === homeTeamFixed.id ? 'home' : 'away';

    // Apply lineup change in match
    setMatchLineups((prev) => {
      const currentTeam = prev[teamKey];
      const updatedPlayers = currentTeam.players.map(p => {
        if (p.id === injuredP.id) {
          return { ...p, isStarting: false, isInjured: true, injuryDuration: activeInjuryDecision.weeks };
        }
        if (p.id === subPlayer.id) {
          return { ...p, isStarting: true };
        }
        return p;
      });
      return {
        ...prev,
        [teamKey]: { ...currentTeam, players: updatedPlayers }
      };
    });

    if (activeInjuryDecision.isUserTeam) {
      setSubsMade(prev => Math.min(5, prev + 1));
    }

    const subEvent: MatchEvent = {
      id: `inj-sub-${Date.now()}`,
      minute: getGameMinuteFromIndex(currentMinute),
      text: `🔄 ZORUNLU DEĞİŞİKLİK (${team.name}): Sakatlanan ${injuredP.name} kenara gelirken yerine ${subPlayer.name} oyuna giriyor!`,
      type: 'SUBSTITUTION',
      teamId: team.id,
      playerName: `${injuredP.name} ➔ ${subPlayer.name}`,
      isHomeTeamEvent: team.id === homeTeamFixed.id,
      scoreHome,
      scoreAway
    };

    setEvents(prev => [...prev, subEvent].sort((a, b) => a.minute - b.minute));
    setVisibleEvents(prev => [...prev, subEvent]);
    soundFx.playWhistle();
    setActiveInjuryDecision(null);
    setIsInjurySubSelectionOpen(false);
    setSelectedInjurySubId(null);
    setIsPlaying(true);
  };

  return (
    <div className="fixed inset-0 z-[9990] bg-slate-950/95 backdrop-blur-md flex flex-col items-center justify-center p-0 sm:p-3 w-full h-full h-screen max-h-screen overflow-hidden select-none">
      
      <div className="bg-[#181528] border-0 sm:border border-[#2d2547] rounded-none sm:rounded-2xl w-full max-w-4xl overflow-hidden shadow-2xl flex flex-col h-full max-h-screen relative">
        
        {/* Top Right Tactics & Panoya Dön Button */}
        {isFinished ? (
          <button
            onClick={onClose}
            className="absolute top-2 right-2 sm:top-2.5 sm:right-3.5 z-40 px-3 py-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs uppercase shadow-lg flex items-center gap-1.5 border border-purple-400 cursor-pointer transition-transform active:scale-95"
          >
            <CheckCircle2 className="w-4 h-4 text-amber-300" />
            <span>Panoya Dön</span>
          </button>
        ) : (
          <button
            onClick={() => {
              setIsPlaying(false);
              setIsTacticsModalOpen(true);
            }}
            className="absolute top-2 right-2 sm:top-2.5 sm:right-3.5 z-40 px-2.5 py-1 rounded-lg bg-purple-600/40 hover:bg-purple-600/70 text-purple-200 text-[9.5px] font-black flex items-center gap-1 border border-purple-400/50 shadow-lg cursor-pointer transition-all active:scale-95"
            title={t('TACTICS_FORMATION')}
          >
            <Sliders className="w-3 h-3 text-purple-300" />
            <span>{t('TACTICS_FORMATION')}</span>
          </button>
        )}

        {/* Halftime Interactive Top Banner */}
        {isHalftime && (
          <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 text-slate-950 px-3 py-2 font-black text-xs sm:text-sm flex items-center justify-between shadow-xl shrink-0 z-40 border-b-2 border-amber-300 animate-pulse">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-950" />
              <span>⏸️ İLK YARI BİTTİ ({getDisplayMinuteStr(45 + stoppage1stHalf)}) — DİZİLİŞ & TAKTİKLERİNİZİ GÖZDEN GEÇİRİN</span>
            </div>
            <button
              onClick={handleStartSecondHalf}
              className="px-3.5 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-900 text-amber-300 font-black text-xs uppercase tracking-wide shadow-md cursor-pointer transition-transform active:scale-95 flex items-center gap-1 border border-amber-400"
            >
              <span>▶️ 2. Yarıya Başla</span>
            </button>
          </div>
        )}

        {/* Scoreboard Header */}
        <div className="bg-gradient-to-r from-[#120f21] via-[#1d1835] to-[#120f21] p-1.5 sm:p-2 border-b border-[#2d2547] relative shrink-0 z-30 shadow-md">
          
          {/* Teams & Live Score - Locked Horizontal Baseline Grid */}
          <div className="grid grid-cols-12 items-center max-w-lg mx-auto gap-1 sm:gap-2 pt-0.5">
            
            {/* Home Team (Cols 1-5) */}
            <button
              type="button"
              onClick={() => onOpenTeamModal?.(homeTeamFixed)}
              className="col-span-5 flex items-center justify-end gap-1.5 min-w-0 group hover:opacity-85 transition cursor-pointer text-right"
              title={`${homeTeamFixed.name} - ${t('VIEW_TEAM') || 'Takım Detayı'}`}
            >
              <span className="font-extrabold text-white group-hover:text-emerald-300 transition-colors text-[9.5px] sm:text-xs text-right truncate">
                {homeTeamFixed.name}
              </span>
              <TeamBadge team={homeTeamFixed} size="md" className="group-hover:scale-105 transition-transform" />
            </button>

            {/* Score Center Box (Cols 6-7) */}
            <div className="col-span-2 flex flex-col items-center justify-center shrink-0">
              <div className="px-2 sm:px-2.5 py-0.5 bg-[#120f21] border border-[#2e264f] rounded-lg flex items-center gap-1 shadow-inner">
                <span className="text-sm sm:text-base font-black text-emerald-400">{scoreHome}</span>
                <span className="text-slate-600 font-bold text-xs">-</span>
                <span className="text-sm sm:text-base font-black text-sky-400">{scoreAway}</span>
              </div>
              <div className="mt-0.5 flex items-center gap-1">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                <span className="text-[8.5px] sm:text-[9.5px] font-black text-amber-300">
                  {getDisplayMinuteStr(currentMinute)}
                </span>
              </div>
            </div>

            {/* Away Team (Cols 8-12) */}
            <button
              type="button"
              onClick={() => onOpenTeamModal?.(awayTeamFixed)}
              className="col-span-5 flex items-center justify-start gap-1.5 min-w-0 group hover:opacity-85 transition cursor-pointer text-left"
              title={`${awayTeamFixed.name} - ${t('VIEW_TEAM') || 'Takım Detayı'}`}
            >
              <TeamBadge team={awayTeamFixed} size="md" className="group-hover:scale-105 transition-transform" />
              <span className="font-extrabold text-white group-hover:text-sky-300 transition-colors text-[9.5px] sm:text-xs text-left truncate">
                {awayTeamFixed.name}
              </span>
            </button>

          </div>

          {/* Goal Scorers & Cards Balanced Sub-Tray (Below Fixed Team Bar) */}
          {(homeGoalEvents.length > 0 || awayGoalEvents.length > 0 || homeCardEvents.length > 0 || awayCardEvents.length > 0 || homeMissedPenalties.length > 0 || awayMissedPenalties.length > 0) && (
            <div className="grid grid-cols-12 max-w-lg mx-auto gap-2 pt-1 mt-1 border-t border-[#2d2547]/50">
              <div className="col-span-6 flex flex-col items-end min-w-0 pr-1 border-r border-[#2d2547]/40">
                {renderGoalScorersList(homeGoalEvents, homeTeamFixed, homeMissedPenalties)}
                {renderCardEventsList(homeCardEvents, homeTeamFixed)}
              </div>
              <div className="col-span-6 flex flex-col items-start min-w-0 pl-1">
                {renderGoalScorersList(awayGoalEvents, awayTeamFixed, awayMissedPenalties)}
                {renderCardEventsList(awayCardEvents, awayTeamFixed)}
              </div>
            </div>
          )}

          {/* Controls Bar */}
          {!isFinished && (
            <div className="flex items-center justify-center gap-1.5 sm:gap-2 mt-1.5 pt-1.5 border-t border-[#2d2547] flex-nowrap overflow-x-auto">
              <button
                onClick={() => {
                  if (isHalftime) {
                    handleStartSecondHalf();
                  } else {
                    setIsPlaying(!isPlaying);
                  }
                }}
                className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 text-[9.5px] font-bold flex items-center gap-1 border border-emerald-500/30 shrink-0 cursor-pointer"
              >
                {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                <span>{isHalftime ? t('START_SECOND_HALF') : isPlaying ? t('PAUSE_SIMULATION') : t('RESUME_SIMULATION')}</span>
              </button>

              <button
                onClick={() => setSpeedMultiplier(prev => prev === 1 ? 2 : prev === 2 ? 5 : 1)}
                className="px-2.5 py-1 rounded-lg bg-[#282142] hover:bg-[#372e5b] text-slate-300 text-[9.5px] font-bold flex items-center gap-1 border border-[#3b3261] shrink-0 cursor-pointer"
              >
                <FastForward className="w-3 h-3 text-amber-400" />
                <span>{t('SPEED')}: {speedMultiplier}x</span>
              </button>

              <button
                onClick={handleFinishInstantly}
                className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-[9.5px] font-bold flex items-center gap-1 border border-amber-500/30 shrink-0 cursor-pointer"
              >
                <SkipForward className="w-3 h-3" />
                <span>{t('SIM_QUICK_FINISH')}</span>
              </button>
            </div>
          )}

        </div>

        {/* Modal Navigation Sub-Tabs (Clean text without emojis) */}
        <div className="flex items-center gap-1 bg-[#120f21] p-1 border-b border-[#2d2547] px-2 sm:px-4 shrink-0 overflow-x-auto whitespace-nowrap custom-fmm-scrollbar">
          <button
            onClick={() => setActiveTab('LOGS')}
            className={`px-3 py-1 rounded-lg text-[10px] sm:text-xs font-black transition-all ${
              activeTab === 'LOGS'
                ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/50'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t('MATCH_LOGS')}
          </button>
          
          <button
            onClick={() => setActiveTab('STATS')}
            className={`px-3 py-1 rounded-lg text-[10px] sm:text-xs font-black transition-all ${
              activeTab === 'STATS'
                ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/50'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t('MATCH_STATS')}
          </button>

          <button
            onClick={() => setActiveTab('RATINGS')}
            className={`px-3 py-1 rounded-lg text-[10px] sm:text-xs font-black transition-all ${
              activeTab === 'RATINGS'
                ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/50'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t('PLAYER_RATINGS_TAB')}
          </button>

          <button
            onClick={() => setActiveTab('REPORT')}
            className={`px-3 py-1 rounded-lg text-[10px] sm:text-xs font-black transition-all flex items-center gap-1 ${
              activeTab === 'REPORT'
                ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/50'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>{t('MATCH_REPORT')}</span>
            {isFinished && <Star className="w-3 h-3 text-amber-300 fill-amber-300" />}
          </button>
        </div>

        {/* Tab Content Area (Scrollable on Mobile) */}
        <div className="p-2 sm:p-3 overflow-y-auto max-h-[460px] flex-1 flex flex-col bg-[#181528] custom-fmm-scrollbar">
          
          {/* TAB 1: Live Commentary (FMM Style Canlı Spiker Paneli) */}
          {activeTab === 'LOGS' && (
            <div className="flex-1 min-h-0 flex flex-col gap-2 overflow-y-auto custom-scrollbar">
              
              {/* Animated Match Simulation Pitch Attack Canvas (Radar on top) */}
              <div className="shrink-0">
                <AttackAnimationCanvas
                  latestEvent={visibleEvents.length > 0 ? visibleEvents[visibleEvents.length - 1] : null}
                  homeTeam={homeTeam}
                  awayTeam={awayTeam}
                  userTeamId={userTeamId}
                  speedMultiplier={speedMultiplier}
                  onResultReached={handleAnimationResultReached}
                  onAnimationFinished={() => setIsAttackAnimating(false)}
                />
              </div>

              {/* Canlı Spiker Featured Ticker Box */}
              {visibleEvents.length > 0 && (() => {
                const latestEvent = visibleEvents[visibleEvents.length - 1];
                return (
                  <div className="bg-[#120e21] border border-[#2d234d] p-2 rounded-xl flex items-center gap-2 shadow-inner shrink-0">
                    <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center font-black text-amber-300 text-xs shrink-0">
                      {latestEvent.minute}'
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className="text-[8.5px] font-black uppercase text-amber-400 block truncate">
                        {latestEvent.playerName ? `🎯 ${t('ATTACK_OR_KICKOFF')}: ${latestEvent.playerName}` : `📢 ${t('SPEAKER_LIVE_COMMENTARY')}`}
                      </span>
                      <p className="text-[11px] sm:text-xs text-white font-black truncate">
                        {latestEvent.text}
                      </p>
                    </div>
                  </div>
                );
              })()}

              {/* Commentary Feed List */}
              <div ref={logsContainerRef} className="min-h-[100px] max-h-[160px] overflow-y-auto bg-[#120f21] border border-[#2d2547] rounded-xl p-2 space-y-1 custom-scrollbar shrink-0">
                {visibleEvents.length === 0 ? (
                  <p className="text-center text-slate-500 text-[11px] py-4">{t('COMMENTARY_PREPARING')}</p>
                ) : (
                  visibleEvents.map((ev) => (
                    <div
                      key={ev.id}
                      className={`p-1.5 sm:p-2 rounded-lg text-[10.5px] sm:text-xs font-semibold flex items-center justify-between gap-2 border ${
                        ev.type === 'GOAL'
                          ? 'bg-emerald-950/80 border-emerald-500/60 text-emerald-200'
                          : ev.type === 'YELLOW_CARD' || ev.type === 'RED_CARD'
                          ? 'bg-amber-950/80 border-amber-500/60 text-amber-200'
                          : ev.type === 'SUBSTITUTION'
                          ? 'bg-purple-950/80 border-purple-500/60 text-purple-200'
                          : 'bg-[#18142a] border-[#2d244c] text-slate-200'
                      }`}
                    >
                      <span className="font-black text-amber-400 shrink-0 w-7">{ev.minute}'</span>
                      <p className="flex-1 leading-snug">{formatMatchEventText(ev)}</p>
                      <span className="font-black text-[9.5px] text-slate-400 shrink-0">{ev.scoreHome} - {ev.scoreAway}</span>
                    </div>
                  ))
                )}
              </div>

            </div>
          )}

          {/* TAB 2: DETAYLI MAÇ İSTATİSTİKLERİ */}
          {activeTab === 'STATS' && activeStats && (() => {
            const hShots = activeStats.shotsHome || 0;
            const aShots = activeStats.shotsAway || 0;
            const hTarget = activeStats.shotsOnTargetHome || 0;
            const aTarget = activeStats.shotsOnTargetAway || 0;
            const hPoss = activeStats.possessionHome || 50;
            const aPoss = activeStats.possessionAway || 50;
            const hFouls = activeStats.foulsHome || Math.round(hShots * 0.8 + 2);
            const aFouls = activeStats.foulsAway || Math.round(aShots * 0.8 + 2);
            const hCorners = activeStats.cornersHome || Math.round(hShots * 0.4 + 1);
            const aCorners = activeStats.cornersAway || Math.round(aShots * 0.4 + 1);
            const hYellows = activeStats.yellowCardsHome || 0;
            const aYellows = activeStats.yellowCardsAway || 0;
            const hSaves = activeStats.savesHome || Math.max(0, aTarget - scoreAway);
            const aSaves = activeStats.savesAway || Math.max(0, hTarget - scoreHome);

            const hXG = (hShots * 0.08 + hTarget * 0.22 + scoreHome * 0.4).toFixed(2);
            const aXG = (aShots * 0.08 + aTarget * 0.22 + scoreAway * 0.4).toFixed(2);
            const hPassAcc = Math.min(92, Math.max(70, Math.round(72 + hPoss * 0.25)));
            const aPassAcc = Math.min(92, Math.max(70, Math.round(72 + aPoss * 0.25)));

            const metricsList = [
              { label: t('XG_EXPECTED_GOALS'), homeVal: hXG, awayVal: aXG, homeNum: parseFloat(hXG), awayNum: parseFloat(aXG) },
              { label: t('POSSESSION'), homeVal: `%${hPoss}`, awayVal: `%${aPoss}`, homeNum: hPoss, awayNum: aPoss },
              { label: t('SHOTS'), homeVal: hShots, awayVal: aShots, homeNum: hShots, awayNum: aShots },
              { label: t('SHOTS_ON_TARGET'), homeVal: hTarget, awayVal: aTarget, homeNum: hTarget, awayNum: aTarget },
              { label: t('PASS_ACCURACY'), homeVal: `%${hPassAcc}`, awayVal: `%${aPassAcc}`, homeNum: hPassAcc, awayNum: aPassAcc },
              { label: t('SET_PIECES'), homeVal: hCorners, awayVal: aCorners, homeNum: hCorners, awayNum: aCorners },
              { label: t('FOULS'), homeVal: hFouls, awayVal: aFouls, homeNum: hFouls, awayNum: aFouls },
              { label: t('YELLOW_CARDS'), homeVal: hYellows, awayVal: aYellows, homeNum: hYellows, awayNum: aYellows },
              { label: t('GOALKEEPER_SAVES') || 'Kaleci Kurtarışları', homeVal: hSaves, awayVal: aSaves, homeNum: hSaves, awayNum: aSaves }
            ];

            return (
              <div className="space-y-3">
                {/* Header Matchup Banner */}
                <div className="bg-[#120f21] border border-[#2d2547] p-3 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${homeTeamFixed.badgeColor} flex items-center justify-center font-black text-white text-xs`}>
                      {homeTeamFixed.shortName}
                    </div>
                    <span className="font-extrabold text-xs text-emerald-400">{homeTeamFixed.name}</span>
                  </div>
                  <span className="font-black text-xs text-amber-400 uppercase tracking-widest">📊 {t('DETAILED_STATS')}</span>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-xs text-sky-400">{awayTeamFixed.name}</span>
                    <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${awayTeamFixed.badgeColor} flex items-center justify-center font-black text-white text-xs`}>
                      {awayTeamFixed.shortName}
                    </div>
                  </div>
                </div>

                {/* xG Highlight Box */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-[#120f21] border border-[#2d2547] p-2.5 rounded-xl text-center border-l-4 border-l-emerald-500">
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">{homeTeamFixed.name} xG</span>
                    <span className="text-xl font-black text-emerald-400">{hXG}</span>
                  </div>
                  <div className="bg-[#120f21] border border-[#2d2547] p-2.5 rounded-xl text-center border-r-4 border-r-sky-500">
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">{awayTeamFixed.name} xG</span>
                    <span className="text-xl font-black text-sky-400">{aXG}</span>
                  </div>
                </div>

                {/* Comparative Metric Progress Bars */}
                <div className="bg-[#120f21] border border-[#2d2547] p-3 rounded-xl space-y-2.5">
                  {metricsList.map((m, idx) => {
                    const total = (m.homeNum + m.awayNum) || 1;
                    const hPct = Math.round((m.homeNum / total) * 100);
                    const aPct = 100 - hPct;

                    return (
                      <div key={idx} className="space-y-1">
                        <div className="flex items-center justify-between text-[11px] font-extrabold">
                          <span className="text-emerald-400">{m.homeVal}</span>
                          <span className="text-slate-300">{m.label}</span>
                          <span className="text-sky-400">{m.awayVal}</span>
                        </div>
                        <div className="w-full h-2 bg-[#1b1531] rounded-full overflow-hidden flex">
                          <div style={{ width: `${hPct}%` }} className="bg-emerald-500 h-full transition-all duration-500" />
                          <div style={{ width: `${aPct}%` }} className="bg-sky-500 h-full transition-all duration-500" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}

          {/* TAB 3: RATINGS */}
          {activeTab === 'RATINGS' && (
            <div className="space-y-2">
              {/* Header Matchup Banner for Ratings */}
              <div className="bg-[#120f21] border border-[#2d2547] p-1.5 sm:p-2 rounded-lg flex items-center justify-between text-[10px] sm:text-xs">
                <div className="flex items-center gap-1.5 min-w-0">
                  <TeamBadge team={homeTeamFixed} size="sm" />
                  <span className="font-extrabold text-[10px] sm:text-xs text-emerald-400 truncate">{homeTeamFixed.name}</span>
                </div>
                <span className="font-black text-[9.5px] sm:text-[10.5px] text-amber-400 uppercase tracking-wider shrink-0 px-1">⭐ {t('PLAYER_RATINGS') || 'REYTİNGLER'}</span>
                <div className="flex items-center gap-1.5 min-w-0 justify-end">
                  <span className="font-extrabold text-[10px] sm:text-xs text-sky-400 truncate text-right">{awayTeamFixed.name}</span>
                  <TeamBadge team={awayTeamFixed} size="sm" />
                </div>
              </div>

              {/* Side-by-Side Player Ratings Grid */}
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-[#120f21] border border-[#2d2547] p-1.5 sm:p-2 rounded-xl space-y-1.5">
                  <div className="flex items-center justify-between border-b border-[#241c3b] pb-1">
                    <button
                      type="button"
                      onClick={() => onOpenTeamModal?.(homeTeamFixed)}
                      className="font-extrabold text-[10px] sm:text-[11px] text-emerald-400 hover:text-emerald-300 truncate text-left cursor-pointer transition-colors"
                      title={`${homeTeamFixed.name} - ${t('VIEW_TEAM') || 'Kulüp Profili'}`}
                    >
                      {homeTeamFixed.name}
                    </button>
                    <span className="text-[9px] text-slate-400 font-bold shrink-0">{t('PLAYER_RATINGS_TAB') || 'Reyting'}</span>
                  </div>
                  <div className="space-y-1 max-h-52 sm:max-h-60 overflow-y-auto custom-scrollbar pr-0.5">
                    {homeRatings.map((r, i) => {
                      const pObj = homeTeamFixed.players.find(p => p.id === r.playerId || p.name === r.playerName);
                      return (
                        <button
                          key={i}
                          type="button"
                          onClick={() => {
                            if (pObj && onOpenPlayerProfile) {
                              onOpenPlayerProfile(pObj, homeTeamFixed);
                            }
                          }}
                          className="w-full flex items-center justify-between p-1 sm:p-1.5 bg-[#18142a] hover:bg-[#251f3e] rounded-md text-[10px] sm:text-xs border border-[#282042] hover:border-purple-500/50 cursor-pointer transition-all active:scale-[0.99] text-left"
                          title={`${r.playerName} - ${t('VIEW_PROFILE') || 'Profili Görüntüle'}`}
                        >
                          <div className="flex items-center gap-1 min-w-0">
                            <span className={`px-1 py-0.2 rounded text-[8px] font-black shrink-0 ${
                              r.position === 'GK' ? 'bg-amber-500/20 text-amber-300' :
                              r.position === 'DEF' ? 'bg-blue-500/20 text-blue-300' :
                              r.position === 'MID' ? 'bg-emerald-500/20 text-emerald-300' :
                              'bg-rose-500/20 text-rose-300'
                            }`}>
                              {r.position}
                            </span>
                            <span className="font-bold text-slate-100 truncate text-[10px] sm:text-[11px]">{r.playerName}</span>
                          </div>
                          <span className={`font-black px-1.5 py-0.2 rounded text-[9.5px] shrink-0 ml-1 transition-all ${
                            r.rating >= 8.5 ? 'bg-emerald-400/25 text-emerald-200 border border-emerald-400/60 shadow-[0_0_8px_rgba(52,211,153,0.3)]' :
                            r.rating >= 7.8 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                            r.rating >= 6.8 ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40' :
                            r.rating >= 6.0 ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                            r.rating >= 5.0 ? 'bg-rose-950/80 text-rose-300 border border-rose-600/70 shadow-[0_0_8px_rgba(244,63,94,0.25)]' :
                            'bg-red-950 text-red-300 border border-red-500 font-black animate-pulse shadow-[0_0_12px_rgba(239,68,68,0.4)]'
                          }`}>
                            {r.rating.toFixed(1)}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="bg-[#120f21] border border-[#2d2547] p-1.5 sm:p-2 rounded-xl space-y-1.5">
                  <div className="flex items-center justify-between border-b border-[#241c3b] pb-1">
                    <button
                      type="button"
                      onClick={() => onOpenTeamModal?.(awayTeamFixed)}
                      className="font-extrabold text-[10px] sm:text-[11px] text-sky-400 hover:text-sky-300 truncate text-left cursor-pointer transition-colors"
                      title={`${awayTeamFixed.name} - ${t('VIEW_TEAM') || 'Kulüp Profili'}`}
                    >
                      {awayTeamFixed.name}
                    </button>
                    <span className="text-[9px] text-slate-400 font-bold shrink-0">{t('PLAYER_RATINGS_TAB') || 'Reyting'}</span>
                  </div>
                  <div className="space-y-1 max-h-52 sm:max-h-60 overflow-y-auto custom-scrollbar pr-0.5">
                    {awayRatings.map((r, i) => {
                      const pObj = awayTeamFixed.players.find(p => p.id === r.playerId || p.name === r.playerName);
                      return (
                        <button
                          key={i}
                          type="button"
                          onClick={() => {
                            if (pObj && onOpenPlayerProfile) {
                              onOpenPlayerProfile(pObj, awayTeamFixed);
                            }
                          }}
                          className="w-full flex items-center justify-between p-1 sm:p-1.5 bg-[#18142a] hover:bg-[#251f3e] rounded-md text-[10px] sm:text-xs border border-[#282042] hover:border-purple-500/50 cursor-pointer transition-all active:scale-[0.99] text-left"
                          title={`${r.playerName} - ${t('VIEW_PROFILE') || 'Profili Görüntüle'}`}
                        >
                          <div className="flex items-center gap-1 min-w-0">
                            <span className={`px-1 py-0.2 rounded text-[8px] font-black shrink-0 ${
                              r.position === 'GK' ? 'bg-amber-500/20 text-amber-300' :
                              r.position === 'DEF' ? 'bg-blue-500/20 text-blue-300' :
                              r.position === 'MID' ? 'bg-emerald-500/20 text-emerald-300' :
                              'bg-rose-500/20 text-rose-300'
                            }`}>
                              {r.position}
                            </span>
                            <span className="font-bold text-slate-100 truncate text-[10px] sm:text-[11px]">{r.playerName}</span>
                          </div>
                          <span className={`font-black px-1.5 py-0.2 rounded text-[9.5px] shrink-0 ml-1 transition-all ${
                            r.rating >= 8.5 ? 'bg-emerald-400/25 text-emerald-200 border border-emerald-400/60 shadow-[0_0_8px_rgba(52,211,153,0.3)]' :
                            r.rating >= 7.8 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                            r.rating >= 6.8 ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40' :
                            r.rating >= 6.0 ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                            r.rating >= 5.0 ? 'bg-rose-950/80 text-rose-300 border border-rose-600/70 shadow-[0_0_8px_rgba(244,63,94,0.25)]' :
                            'bg-red-950 text-red-300 border border-red-500 font-black animate-pulse shadow-[0_0_12px_rgba(239,68,68,0.4)]'
                          }`}>
                            {r.rating.toFixed(1)}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: REPORT */}
          {activeTab === 'REPORT' && (
            !isFinished ? (
              <div className="space-y-3">
                <div className="bg-[#120f21] border border-[#2d2547] p-5 rounded-xl text-center space-y-3 my-2">
                  <div className="w-12 h-12 rounded-full bg-purple-600/20 border border-purple-500/40 flex items-center justify-center mx-auto text-purple-300 animate-spin text-xl">
                    ⏱️
                  </div>
                  <h3 className="font-black text-base text-white">
                    {t('MATCH_IN_PROGRESS_TITLE') || 'Maç Devam Ediyor'} ({getDisplayMinuteStr(currentMinute)})
                  </h3>
                  <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                    {t('MATCH_IN_PROGRESS_REPORT_DESC') || 'Maç henüz tamamlanmadı. Son düdük çalıp maç bittiğinde maç raporu, galibiyet primi ve ödül özeti bu ekranda görüntülenecektir.'}
                  </p>
                  
                  {/* Live Goals So Far */}
                  <div className="pt-3 border-t border-[#231b3b] text-left space-y-2">
                    <span className="font-extrabold text-xs text-amber-300 block">
                      ⚽ {t('LIVE_GOALS_SO_FAR') || 'Şu Ana Kadarki Goller'} ({scoreHome} - {scoreAway}):
                    </span>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="bg-[#18142a] p-2.5 rounded-xl border border-[#2c234a]">
                        <span className="font-extrabold text-emerald-400 block text-[11px] mb-1">{homeTeamFixed.name}:</span>
                        {visibleEvents.filter(e => e.type === 'GOAL' && e.teamId === homeTeamFixed.id).length > 0 ? (
                          renderGoalScorersList(visibleEvents.filter(e => e.type === 'GOAL' && e.teamId === homeTeamFixed.id), homeTeamFixed)
                        ) : (
                          <span className="text-slate-600 font-bold text-[11px]">-</span>
                        )}
                      </div>
                      <div className="bg-[#18142a] p-2.5 rounded-xl border border-[#2c234a]">
                        <span className="font-extrabold text-sky-400 block text-[11px] mb-1">{awayTeamFixed.name}:</span>
                        {visibleEvents.filter(e => e.type === 'GOAL' && e.teamId === awayTeamFixed.id).length > 0 ? (
                          renderGoalScorersList(visibleEvents.filter(e => e.type === 'GOAL' && e.teamId === awayTeamFixed.id), awayTeamFixed)
                        ) : (
                          <span className="text-slate-600 font-bold text-[11px]">-</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="bg-[#120f21] border border-[#2d2547] p-4 rounded-xl text-center space-y-2">
                  <Trophy className="w-10 h-10 text-amber-400 mx-auto animate-bounce" />
                  <h3 className="font-black text-lg text-white">{t('MATCH_RESULT_REVENUE_REPORT')}</h3>
                  <p className="text-xs text-slate-300">
                    {scoreHome > scoreAway
                      ? '🎉'
                      : scoreHome < scoreAway
                      ? '❌'
                      : t('MATCH_DRAW_NOTE')}
                  </p>
                  <div className="p-2.5 bg-[#18142a] border border-[#30264f] rounded-xl inline-block mt-2">
                    <span className="text-[10px] font-bold text-slate-400 block uppercase">{t('MATCH_BONUS_PRIZE')}</span>
                    <span className="text-lg font-black text-emerald-400">{formatCurrency(prizeEarned)}</span>
                  </div>
                </div>

                {/* Goal Scorers Card in Match Report */}
                <div className="bg-[#120f21] border border-[#2d2547] p-3.5 rounded-xl space-y-2">
                  <h4 className="font-black text-xs text-amber-300 uppercase tracking-wider flex items-center gap-1.5 border-b border-[#261f3b] pb-1.5">
                    ⚽ {t('GOAL_SCORERS_TITLE')}
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="bg-[#18142a] p-2.5 rounded-xl border border-[#2c234a]">
                      <span className="font-extrabold text-emerald-400 block text-[11px] mb-1">{homeTeamFixed.name}:</span>
                      {homeGoalEvents.length > 0 || homeMissedPenalties.length > 0 ? (
                        renderGoalScorersList(homeGoalEvents, homeTeamFixed, homeMissedPenalties)
                      ) : (
                        <span className="text-slate-600 font-bold text-[11px]">-</span>
                      )}
                    </div>
                    <div className="bg-[#18142a] p-2.5 rounded-xl border border-[#2c234a]">
                      <span className="font-extrabold text-sky-400 block text-[11px] mb-1">{awayTeamFixed.name}:</span>
                      {awayGoalEvents.length > 0 || awayMissedPenalties.length > 0 ? (
                        renderGoalScorersList(awayGoalEvents, awayTeamFixed, awayMissedPenalties)
                      ) : (
                        <span className="text-slate-600 font-bold text-[11px]">-</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Mini Statistics Panel */}
                <div className="bg-[#120f21] border border-[#2d2547] p-3.5 rounded-xl space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-[#261f3b]">
                    <div className="flex items-center gap-1.5 font-black text-xs text-emerald-400">
                      <div className={`w-3.5 h-3.5 rounded-full bg-gradient-to-br ${homeTeamFixed.badgeColor} flex items-center justify-center text-[7px] text-white font-black`} />
                      <span className="truncate max-w-[110px] sm:max-w-[150px]">{homeTeamFixed.name}</span>
                    </div>
                    <span className="text-[10px] sm:text-[11px] font-black uppercase text-amber-400 tracking-wider">📊 {t('MATCH_STATS')}</span>
                    <div className="flex items-center gap-1.5 font-black text-xs text-sky-400">
                      <span className="truncate max-w-[110px] sm:max-w-[150px]">{awayTeamFixed.name}</span>
                      <div className={`w-3.5 h-3.5 rounded-full bg-gradient-to-br ${awayTeamFixed.badgeColor} flex items-center justify-center text-[7px] text-white font-black`} />
                    </div>
                  </div>

                  <div className="space-y-2.5 text-xs">
                    {/* Topla Oynama (Possession) */}
                    <div>
                      <div className="flex justify-between text-[11px] font-extrabold mb-1">
                        <span className="text-emerald-400">%{stats?.possessionHome ?? 50}</span>
                        <span className="text-slate-300">{t('POSSESSION')}</span>
                        <span className="text-sky-400">%{stats?.possessionAway ?? 50}</span>
                      </div>
                      <div className="w-full h-2 bg-[#1b1531] rounded-full overflow-hidden flex">
                        <div style={{ width: `${stats?.possessionHome ?? 50}%` }} className="bg-emerald-500 h-full transition-all duration-500" />
                        <div style={{ width: `${stats?.possessionAway ?? 50}%` }} className="bg-sky-500 h-full transition-all duration-500" />
                      </div>
                    </div>

                    {/* Toplam Şut */}
                    <div>
                      <div className="flex justify-between text-[11px] font-extrabold mb-1">
                        <span className="text-emerald-400">{stats?.shotsHome ?? 0}</span>
                        <span className="text-slate-300">{t('TOTAL_SHOTS')}</span>
                        <span className="text-sky-400">{stats?.shotsAway ?? 0}</span>
                      </div>
                      <div className="w-full h-2 bg-[#1b1531] rounded-full overflow-hidden flex">
                        <div
                          style={{
                            width: `${((stats?.shotsHome || 0) + (stats?.shotsAway || 0)) === 0 ? 50 : ((stats?.shotsHome || 0) / ((stats?.shotsHome || 0) + (stats?.shotsAway || 0))) * 100}%`
                          }}
                          className="bg-emerald-500 h-full transition-all duration-500"
                        />
                        <div
                          style={{
                            width: `${((stats?.shotsHome || 0) + (stats?.shotsAway || 0)) === 0 ? 50 : ((stats?.shotsAway || 0) / ((stats?.shotsHome || 0) + (stats?.shotsAway || 0))) * 100}%`
                          }}
                          className="bg-sky-500 h-full transition-all duration-500"
                        />
                      </div>
                    </div>

                    {/* İsabetli Şut */}
                    <div>
                      <div className="flex justify-between text-[11px] font-extrabold mb-1">
                        <span className="text-emerald-400">{stats?.shotsOnTargetHome ?? 0}</span>
                        <span className="text-slate-300">{t('SHOTS_ON_TARGET')}</span>
                        <span className="text-sky-400">{stats?.shotsOnTargetAway ?? 0}</span>
                      </div>
                      <div className="w-full h-2 bg-[#1b1531] rounded-full overflow-hidden flex">
                        <div
                          style={{
                            width: `${((stats?.shotsOnTargetHome || 0) + (stats?.shotsOnTargetAway || 0)) === 0 ? 50 : ((stats?.shotsOnTargetHome || 0) / ((stats?.shotsOnTargetHome || 0) + (stats?.shotsOnTargetAway || 0))) * 100}%`
                          }}
                          className="bg-emerald-500 h-full transition-all duration-500"
                        />
                        <div
                          style={{
                            width: `${((stats?.shotsOnTargetHome || 0) + (stats?.shotsOnTargetAway || 0)) === 0 ? 50 : ((stats?.shotsOnTargetAway || 0) / ((stats?.shotsOnTargetHome || 0) + (stats?.shotsOnTargetAway || 0))) * 100}%`
                          }}
                          className="bg-sky-500 h-full transition-all duration-500"
                        />
                      </div>
                    </div>

                    {/* Korner & Faul & Kartlar */}
                    <div className="grid grid-cols-2 gap-2 pt-1 border-t border-[#261f3b] text-[11px]">
                      <div className="flex justify-between bg-[#18142a] p-1.5 rounded-lg border border-[#2d244c]">
                        <span className="text-slate-400 font-bold">{t('CORNERS')}:</span>
                        <span className="font-extrabold text-slate-200">{stats?.cornersHome ?? stats?.cornerKicksHome ?? 0} - {stats?.cornersAway ?? stats?.cornerKicksAway ?? 0}</span>
                      </div>
                      <div className="flex justify-between bg-[#18142a] p-1.5 rounded-lg border border-[#2d244c]">
                        <span className="text-slate-400 font-bold">{t('FOULS')}:</span>
                        <span className="font-extrabold text-slate-200">{stats?.foulsHome ?? 0} - {stats?.foulsAway ?? 0}</span>
                      </div>
                      <div className="flex justify-between bg-[#18142a] p-1.5 rounded-lg border border-[#2d244c]">
                        <span className="text-amber-400 font-bold flex items-center gap-1">🟨 {t('YELLOW_CARDS')}:</span>
                        <span className="font-extrabold text-amber-300">{stats?.yellowHome ?? 0} - {stats?.yellowAway ?? 0}</span>
                      </div>
                      <div className="flex justify-between bg-[#18142a] p-1.5 rounded-lg border border-[#2d244c]">
                        <span className="text-rose-400 font-bold flex items-center gap-1">🟥 {t('RED_CARDS')}:</span>
                        <span className="font-extrabold text-rose-300">{stats?.redHome ?? 0} - {stats?.redAway ?? 0}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )
          )}

        </div>

      </div>
      {isTacticsModalOpen && (
        <div className="fixed inset-0 z-[9995] bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-1 sm:p-2.5 animate-fadeIn">
          <div className="bg-[#120d24] border-2 border-[#3d2f63] rounded-2xl w-full max-w-6xl h-[98vh] sm:h-[94vh] flex flex-col shadow-2xl overflow-hidden p-1.5 sm:p-2.5 text-slate-100 space-y-1.5 relative">
            
            {/* 5-Substitution Warning Toast Banner */}
            {subWarning && (
              <div className="absolute top-12 left-1/2 -translate-x-1/2 z-50 bg-amber-500/95 border-2 border-amber-300 text-slate-950 px-3 py-1.5 rounded-xl shadow-2xl font-black text-xs sm:text-sm flex items-center gap-2 animate-bounce">
                <span>{subWarning}</span>
              </div>
            )}

            {/* Compact Header (Reduced height to expand the pitch upwards) */}
            <div className="flex items-center justify-between px-2 py-1 bg-[#181230] rounded-lg border border-[#2d2250] shrink-0">
              <div className="flex items-center gap-1.5 min-w-0">
                <Sliders className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <div className="min-w-0 flex items-center gap-1.5 flex-wrap">
                  <h3 className="font-extrabold text-xs text-white flex items-center gap-1 truncate">
                    <span className="truncate">{isHalftime ? `⏸️ ${t('HALFTIME')}` : `⚽ ${t('TACTICS_FORMATION')}`}</span>
                    <span className="text-[8.5px] font-bold px-1.5 py-0.2 rounded-full bg-purple-950/80 border border-purple-500/40 text-purple-300 shrink-0">
                      {activeUserTeam.name}
                    </span>
                  </h3>
                  <span className="text-[8.5px] text-slate-400">
                    Dakika: {getDisplayMinuteStr(currentMinute)} • Değişiklik: <span className="text-amber-300 font-bold">{subsMade}/5</span>
                  </span>
                </div>
              </div>

              {/* Action Buttons Right in Header (Compact) */}
              <div className="flex items-center gap-1 shrink-0 ml-1">
                {isHalftime ? (
                  <button
                    onClick={() => handleRequestCloseTactics('START_SECOND_HALF')}
                    className="px-2.5 py-1 rounded-md bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-[10.5px] uppercase shadow-md cursor-pointer transition-transform active:scale-95 flex items-center gap-1 shrink-0"
                  >
                    <span>▶️ 2. Yarıya Başla</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleRequestCloseTactics('RESUME')}
                    className="px-2.5 py-1 rounded-md bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-[10.5px] uppercase shadow-md cursor-pointer transition-transform active:scale-95 flex items-center gap-1 shrink-0"
                  >
                    <span>UYGULA & DEVAM ET &rarr;</span>
                  </button>
                )}

                <button
                  onClick={() => handleRequestCloseTactics(isHalftime ? 'START_SECOND_HALF' : 'RESUME')}
                  className="p-1 rounded-md bg-[#271f45] hover:bg-[#392e63] text-slate-300 hover:text-white transition-colors cursor-pointer shrink-0"
                  title="Kapat"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Tactical Pitch Component (Maximized Pitch Area & Independent In-Match View) */}
            <div className="flex-1 min-h-0 w-full overflow-hidden flex flex-col bg-[#0d091a] rounded-xl border border-[#271d44]">
              <TacticalPitch
                team={activeUserTeam}
                selectedPlayer={tacticsSelectedPlayer}
                onSelectPlayer={setTacticsSelectedPlayer}
                onSwapPlayers={handleTacticsSwapPlayers}
                onChangeFormation={handleTacticsChangeFormation}
                onChangeTactic={handleTacticsChangeTactic}
                onUpdateTacticalDetails={handleTacticsUpdateDetails}
                onOpenPlayerProfile={onOpenPlayerProfile}
                hideTeamBalance={true}
                hidePlayerDetailBox={true}
                isInMatchTactics={true}
              />
            </div>

          </div>
        </div>
      )}

      {/* Confirmation Modal For In-Game Tactics & Subs */}
      {isConfirmModalOpen && (
        <div className="fixed inset-0 z-[9999] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-2.5 sm:p-4 animate-fadeIn">
          <div className="bg-[#17112c] border-2 border-purple-500/60 rounded-xl w-full max-w-sm sm:max-w-md max-h-[90vh] overflow-y-auto shadow-2xl p-3 sm:p-4 text-slate-100 space-y-2.5">
            <div className="flex items-center gap-2 pb-2 border-b border-[#2d2250]">
              <div className="w-7 h-7 rounded-lg bg-purple-950/80 border border-purple-400 flex items-center justify-center text-purple-300 text-sm shadow-inner shrink-0">
                📋
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="font-extrabold text-sm sm:text-base text-white truncate">Değişiklikleri Onayla</h3>
                <p className="text-[10px] text-slate-400 truncate">
                  Değişiklikleri gözden geçirip maça devam edin.
                </p>
              </div>
            </div>

            <div className="space-y-1.5 text-xs bg-[#110c22] p-2.5 rounded-lg border border-[#2b2049]">
              <div className="flex items-center justify-between text-slate-300 border-b border-[#241940] pb-1">
                <span className="font-bold text-[11px]">Takım:</span>
                <span className="font-extrabold text-purple-300 text-[11px] truncate max-w-[150px]">{activeUserTeam.name}</span>
              </div>
              <div className="flex items-center justify-between text-slate-300 border-b border-[#241940] pb-1">
                <span className="font-bold text-[11px]">Diziliş & Taktik:</span>
                <span className="font-extrabold text-emerald-400 text-[11px]">{activeUserTeam.formation} • {activeUserTeam.tactic}</span>
              </div>
              <div className="space-y-1 pt-0.5">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="font-bold text-amber-300">Yapılan Değişiklikler:</span>
                  <span className="font-extrabold text-slate-400">Toplam: {subsMade}/5</span>
                </div>
                {sessionSubs.length === 0 ? (
                  <div className="text-[10px] text-slate-400 italic text-center py-1">
                    Oyuncu değişikliği yapılmadı.
                  </div>
                ) : (
                  sessionSubs.map((sub, idx) => (
                    <div key={idx} className="bg-[#1b1435] px-2 py-1 rounded border border-[#37285c] flex items-center justify-between text-[10px]">
                      <span className="text-rose-300 font-bold truncate max-w-[100px] sm:max-w-[130px]">Çıkan: {sub.outPlayer}</span>
                      <span className="text-slate-400 font-black px-1">➔</span>
                      <span className="text-emerald-300 font-bold truncate max-w-[100px] sm:max-w-[130px]">Giren: {sub.inPlayer}</span>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 pt-0.5">
              <button
                onClick={() => setIsConfirmModalOpen(false)}
                className="flex-1 py-2 px-2.5 bg-[#241c3d] hover:bg-[#342757] text-slate-300 hover:text-white font-bold text-xs rounded-lg border border-[#3c2b64] transition-all cursor-pointer truncate"
              >
                ✏️ Düzenlemeye Dön
              </button>
              <button
                onClick={handleConfirmChanges}
                className="flex-1 py-2 px-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs rounded-lg uppercase shadow-lg transition-transform active:scale-95 cursor-pointer flex items-center justify-center gap-1 truncate"
              >
                <span>{pendingConfirmAction === 'START_SECOND_HALF' ? '▶️ 2. Yarıya Başla' : '✅ Onayla'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Sideline Injury Intervention Modal */}
      {activeInjuryDecision && (
        <div className="fixed inset-0 z-[9999] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-2.5 sm:p-4 animate-fadeIn">
          <div className="bg-[#150f26] border-2 border-rose-500/70 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden p-3.5 sm:p-5 text-slate-100 space-y-3.5 relative">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-2.5 border-b border-rose-900/40">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-rose-950/90 border border-rose-500/80 flex items-center justify-center text-base shadow-inner animate-pulse">
                  🚑
                </div>
                <div>
                  <h3 className="font-black text-sm sm:text-base text-rose-300">SAHA KENARI SAĞLIK RAPORU</h3>
                  <p className="text-[10px] text-slate-400">
                    Dakika {getDisplayMinuteStr(activeInjuryDecision.minute)} • {activeInjuryDecision.team.name}
                  </p>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-300 font-extrabold text-[10px] border border-rose-500/40 animate-pulse">
                ACİL MÜDAHALE
              </span>
            </div>

            {/* Injured Player Card */}
            <div className="bg-[#1d1435] p-3 rounded-xl border border-[#3c2a63] flex items-center justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-rose-700 to-purple-900 flex items-center justify-center text-xs font-black text-white border border-rose-400 shrink-0">
                  {activeInjuryDecision.player.position}
                </div>
                <div className="min-w-0">
                  <div className="font-black text-xs sm:text-sm text-white truncate">
                    {activeInjuryDecision.player.name}
                  </div>
                  <div className="text-[10px] text-slate-300 flex items-center gap-1.5 mt-0.5">
                    <span className="font-bold text-amber-300">{activeInjuryDecision.player.specificRole || activeInjuryDecision.player.position}</span>
                    <span>•</span>
                    <span>Genel Güç: <strong className="text-white">{activeInjuryDecision.player.overall}</strong></span>
                  </div>
                </div>
              </div>
              <div className="text-right shrink-0">
                <span className="text-[10px] font-black text-rose-400 block">⚠️ {activeInjuryDecision.injuryType}</span>
                <span className="text-[9px] text-slate-400">Tahmini: {activeInjuryDecision.weeks} Hafta</span>
              </div>
            </div>

            {/* Doctor Note */}
            <div className="bg-rose-950/30 border border-rose-600/30 p-2.5 rounded-xl text-xs text-rose-200 leading-relaxed flex items-start gap-2">
              <span className="text-base shrink-0">🩺</span>
              <div>
                <strong className="block text-rose-300 font-black text-[11px] mb-0.5">Kulüp Doktoru Raporu:</strong>
                <p className="text-[10.5px] text-slate-300">
                  Oyuncumuz acı hissediyor ancak soğutucu sprey ve sıkı bandaj ile sahada kalabilir veya riske etmeyip taze bir yedekle değiştirebilirsiniz.
                </p>
              </div>
            </div>

            {/* Sub View or Decision Buttons */}
            {isInjurySubSelectionOpen ? (
              <div className="space-y-2 pt-1">
                <div className="flex items-center justify-between">
                  <span className="font-black text-xs text-emerald-400">🔄 Oyuna Girecek Yedeği Seçin:</span>
                  <button
                    onClick={() => setIsInjurySubSelectionOpen(false)}
                    className="text-[10px] text-slate-400 hover:text-white font-bold cursor-pointer"
                  >
                    ← Geri Dön
                  </button>
                </div>

                {/* Available Bench Players */}
                {(() => {
                  const benchPlayers = activeInjuryDecision.team.players.filter(p => !p.isStarting && !p.isInjured && p.id !== activeInjuryDecision.player.id);
                  const samePosPlayers = benchPlayers.filter(p => p.position === activeInjuryDecision.player.position);
                  const otherPlayers = benchPlayers.filter(p => p.position !== activeInjuryDecision.player.position);
                  const sortedBench = [...samePosPlayers, ...otherPlayers];

                  if (sortedBench.length === 0) {
                    return (
                      <div className="p-3 bg-[#18112d] rounded-xl text-center text-xs text-slate-400">
                        Yedek kulübesinde müsait oyuncu kalmadı!
                      </div>
                    );
                  }

                  return (
                    <div className="space-y-1.5 max-h-48 overflow-y-auto custom-scrollbar pr-0.5">
                      {sortedBench.map((benchP) => {
                        const isSelected = selectedInjurySubId === benchP.id;
                        const isMatchPos = benchP.position === activeInjuryDecision.player.position;
                        return (
                          <button
                            key={benchP.id}
                            type="button"
                            onClick={() => setSelectedInjurySubId(benchP.id)}
                            className={`w-full p-2 rounded-xl border flex items-center justify-between text-left transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-emerald-950/80 border-emerald-400 text-emerald-100 shadow-md scale-[0.99]'
                                : 'bg-[#1a1232] hover:bg-[#251b42] border-[#36275c] text-slate-200'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <span className={`px-1.5 py-0.5 rounded text-[8.5px] font-black shrink-0 ${
                                benchP.position === 'GK' ? 'bg-amber-500/20 text-amber-300' :
                                benchP.position === 'DEF' ? 'bg-blue-500/20 text-blue-300' :
                                benchP.position === 'MID' ? 'bg-emerald-500/20 text-emerald-300' :
                                'bg-rose-500/20 text-rose-300'
                              }`}>
                                {benchP.position}
                              </span>
                              <div className="min-w-0">
                                <div className="font-bold text-xs truncate flex items-center gap-1.5">
                                  <span>{benchP.name}</span>
                                  {isMatchPos && (
                                    <span className="text-[8px] font-black px-1 rounded bg-amber-400/20 text-amber-300 border border-amber-400/40">
                                      ⭐ Önerilen
                                    </span>
                                  )}
                                </div>
                                <span className="text-[9.5px] text-slate-400">
                                  {benchP.specificRole || benchP.position} • Yaş: {benchP.age}
                                </span>
                              </div>
                            </div>
                            <span className="font-black text-xs text-amber-300 px-2 py-0.5 rounded bg-black/30 shrink-0 ml-1">
                              {benchP.overall}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  );
                })()}

                {/* Confirm Sub Button */}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsInjurySubSelectionOpen(false)}
                    className="flex-1 py-2 px-2.5 bg-[#241c3d] hover:bg-[#342757] text-slate-300 font-bold text-xs rounded-xl border border-[#3c2b64] cursor-pointer"
                  >
                    Vazgeç
                  </button>
                  <button
                    type="button"
                    disabled={!selectedInjurySubId}
                    onClick={() => {
                      const selectedObj = activeInjuryDecision.team.players.find(p => p.id === selectedInjurySubId);
                      if (selectedObj) {
                        handleInjuryDecisionSubstitute(selectedObj);
                      }
                    }}
                    className={`flex-1 py-2 px-2.5 rounded-xl font-black text-xs uppercase shadow-lg transition-transform flex items-center justify-center gap-1 cursor-pointer ${
                      selectedInjurySubId
                        ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 active:scale-95'
                        : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                    }`}
                  >
                    <span>✅ Değişikliği Uygula</span>
                  </button>
                </div>
              </div>
            ) : (
              /* Two Main Decision Buttons */
              <div className="space-y-2 pt-1">
                <button
                  type="button"
                  onClick={handleInjuryDecisionContinue}
                  className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-black text-xs uppercase tracking-wide shadow-lg cursor-pointer transition-transform active:scale-95 flex items-center justify-center gap-2 border border-amber-300"
                >
                  <span>🩹 Sahada Kal (Bandajla Devam Et)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsInjurySubSelectionOpen(true)}
                  className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white font-black text-xs uppercase tracking-wide shadow-lg cursor-pointer transition-transform active:scale-95 flex items-center justify-center gap-2 border border-rose-400"
                >
                  <span>🔄 Oyuncuyu Değiştir (Yedek Kulübesinden Al)</span>
                </button>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
};
