import React, { useState, useEffect } from 'react';
import { DevImageConfig, getStoredDevConfig } from './DevPanelModal';

interface PlayersAndManagerGroupProps {
  className?: string;
  config?: DevImageConfig;
}

export const PlayersAndManagerGroup: React.FC<PlayersAndManagerGroupProps> = ({ 
  className = '',
  config: propConfig 
}) => {
  const [config, setConfig] = useState<DevImageConfig>(propConfig || getStoredDevConfig());
  const [currentSrc, setCurrentSrc] = useState<string>(config.customImageUrl);
  const [hasFailed, setHasFailed] = useState<boolean>(false);

  useEffect(() => {
    if (propConfig) {
      setConfig(propConfig);
      setCurrentSrc(propConfig.customImageUrl);
      setHasFailed(false);
    }
  }, [propConfig]);

  const handleError = () => {
    if (currentSrc.startsWith('/')) {
      setCurrentSrc(currentSrc.substring(1));
    } else if (currentSrc !== 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=1200&auto=format&fit=crop') {
      setCurrentSrc('https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=1200&auto=format&fit=crop');
    } else {
      setHasFailed(true);
    }
  };

  const opacityStyle = (config.opacity ?? 100) / 100;
  const brightnessStyle = (config.brightness ?? 100) / 100;
  const contrastStyle = (config.contrast ?? 100) / 100;
  const zoom = (config.zoomScale ?? 100) / 100;
  const offsetY = config.offsetY ?? 0;
  const offsetX = config.offsetX ?? 0;
  const heightVh = config.scaleVh ?? 70;

  return (
    <div 
      className={`relative w-full h-full flex items-center justify-center select-none pointer-events-none transition-all duration-150 ${className}`}
      style={{
        height: '100%',
        maxHeight: '100%',
        opacity: opacityStyle,
        transform: `translate(${offsetX}px, ${offsetY}px) scale(${zoom})`,
        transformOrigin: 'center center',
        filter: `brightness(${brightnessStyle}) contrast(${contrastStyle}) drop-shadow(0 20px 35px rgba(0,0,0,0.95))`
      }}
    >
      {!hasFailed ? (
        <img
          src={currentSrc}
          alt="Teknik Direktör ve Futbolcular"
          onError={handleError}
          className="w-full h-full object-cover object-center"
          style={{
            maxWidth: '100%',
            maxHeight: '100%',
            objectFit: 'cover',
            objectPosition: config.objectPosition || 'center center'
          }}
        />
      ) : (
        /* Backup Image */
        <div className="w-full h-full flex items-center justify-center">
          <img
            src="https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=1200&auto=format&fit=crop"
            alt="Football Team"
            className="w-full h-full object-cover object-center"
          />
        </div>
      )}
    </div>
  );
};
