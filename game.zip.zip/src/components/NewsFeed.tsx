import React, { useState } from 'react';
import { Team, Player, Fixture, LeagueRow } from '../types';
import { Newspaper, Trophy, Shield, Activity, ChevronRight, Check } from 'lucide-react';
import { useTranslation, LanguageCode } from '../utils/i18n';

interface NewsFeedProps {
  currentTeam: Team;
  opponentTeam: Team;
  currentWeek: number;
  allTeams: Team[];
  fixtures?: Fixture[];
  standings?: LeagueRow[];
}

export type NewsCategory = 'ALL' | 'LEAGUE' | 'DERBY' | 'SQUAD' | 'SCOUT' | 'INJURY' | 'PRESS';

export interface NewsItem {
  id: string;
  category: 'LEAGUE' | 'DERBY' | 'SQUAD' | 'SCOUT' | 'INJURY' | 'PRESS';
  title: string;
  summary: string;
  fullContent?: string;
  timestamp: string;
  badgeTag: string;
  badgeColor: string;
  teamId?: string;
  author?: string;
  playerData?: Partial<Player>;
  matchData?: {
    homeTeam: string;
    awayTeam: string;
    homeScore?: number;
    awayScore?: number;
    played: boolean;
    week: number;
    scorers?: string[];
  };
}

// Known major derbies in Turkish football
const DERBY_PAIRS = [
  ['galatasaray', 'fenerbahce'],
  ['fenerbahce', 'galatasaray'],
  ['besiktas', 'fenerbahce'],
  ['fenerbahce', 'besiktas'],
  ['galatasaray', 'besiktas'],
  ['besiktas', 'galatasaray'],
  ['trabzonspor', 'galatasaray'],
  ['galatasaray', 'trabzonspor'],
  ['trabzonspor', 'fenerbahce'],
  ['fenerbahce', 'trabzonspor'],
  ['trabzonspor', 'besiktas'],
  ['besiktas', 'trabzonspor'],
  ['goztepe', 'eyupspor'],
  ['eyupspor', 'goztepe'],
  ['samsunspor', 'trabzonspor'],
  ['adana-demirspor', 'antalyaspor'],
  ['kayserispor', 'sivasspor']
];

export const generateNewsFeed = (
  language: LanguageCode,
  currentTeam: Team,
  opponentTeam: Team,
  currentWeek: number,
  allTeams: Team[],
  fixtures: Fixture[] = [],
  standings: LeagueRow[] = []
): NewsItem[] => {
  const isTr = language === 'TR';
  const isDe = language === 'DE';
  const isEs = language === 'ES';
  const isFr = language === 'FR';
  const isIt = language === 'IT';
  const isPt = language === 'PT';

  const news: NewsItem[] = [];
  const getTeamObj = (id: string): Team | undefined => allTeams.find(t => t.id === id);

  // =========================================================================
  // 1. GERÇEK DERBİLER & FİKSTÜR MAÇLARI (Sadece ligde oynanan veya bu hafta oynanacak olanlar)
  // =========================================================================
  
  // A) Oynanmış Gerçek Derbiler (Played Derbies)
  const playedDerbyFixtures = fixtures.filter(f => {
    if (!f.played) return false;
    return DERBY_PAIRS.some(([t1, t2]) => 
      (f.homeTeamId === t1 && f.awayTeamId === t2) || (f.homeTeamId === t2 && f.awayTeamId === t1)
    );
  });

  // En son oynanan derbileri al
  playedDerbyFixtures.slice(-3).reverse().forEach((f, idx) => {
    const home = getTeamObj(f.homeTeamId);
    const away = getTeamObj(f.awayTeamId);
    if (!home || !away) return;

    const homeScore = f.homeScore ?? 0;
    const awayScore = f.awayScore ?? 0;
    const isHomeWinner = homeScore > awayScore;
    const isAwayWinner = awayScore > homeScore;
    const isDraw = homeScore === awayScore;

    let derbyHeadline = '';
    let derbySummary = '';
    let derbyFull = '';

    if (isDraw) {
      derbyHeadline = isTr
        ? `⚔️ DERBİDE PUANLAR PAYLAŞILDI: ${home.name} ${homeScore} - ${awayScore} ${away.name}`
        : isDe
        ? `⚔️ DERBY ENDET REMIS: ${home.name} ${homeScore} - ${awayScore} ${away.name}`
        : isEs
        ? `⚔️ EMPATE EN EL DERBI: ${home.name} ${homeScore} - ${awayScore} ${away.name}`
        : isFr
        ? `⚔️ PARTAGE DES POINTS DANS LE DERBY: ${home.name} ${homeScore} - ${awayScore} ${away.name}`
        : isIt
        ? `⚔️ DERBY IN PARITÀ: ${home.name} ${homeScore} - ${awayScore} ${away.name}`
        : isPt
        ? `⚔️ EMPATE NO DÉRBI: ${home.name} ${homeScore} - ${awayScore} ${away.name}`
        : `⚔️ DERBY ENDS IN DRAW: ${home.name} ${homeScore} - ${awayScore} ${away.name}`;

      derbySummary = isTr
        ? `Süper Lig'in ${f.week}. haftasında oynanan dev derbide iki ezeli rakip yenişemedi (${homeScore}-${awayScore}).`
        : isDe
        ? `Im Duell der Erzrivalen in Woche ${f.week} gab es ein ${homeScore}:${awayScore} Unentschieden.`
        : isEs
        ? `En la jornada ${f.week}, los eternos rivales empataron ${homeScore}-${awayScore} en un duelo intenso.`
        : isFr
        ? `Lors de la journée ${f.week}, les deux rivaux historiques se sont neutralisés (${homeScore}-${awayScore}).`
        : isIt
        ? `Nella ${f.week}ª giornata, il derby infuocato si è chiuso sul punteggio di ${homeScore}-${awayScore}.`
        : isPt
        ? `Na jornada ${f.week}, os rivais históricos empataram ${homeScore}-${awayScore} num duelo eletrizante.`
        : `In Week ${f.week} of the league, the fierce derby ended level (${homeScore}-${awayScore}).`;

      derbyFull = isTr
        ? `Ligin ${f.week}. haftasında karşı karşıya gelen ${home.name} ile ${away.name}, kıran kırana geçen 90 dakika sonunda ${homeScore}-${awayScore} beraberlikle sahadan ayrıldı. İki takımın da zirve yarışında 1'er puan aldığı karşılaşmada tribünlerde unutulmaz bir atmosfer vardı.`
        : isDe
        ? `In einem packenden 90-minütigen Kampf trennten sich ${home.name} und ${away.name} mit ${homeScore}:${awayScore}. Beide Teams nehmen jeweils einen Punkt mit.`
        : isEs
        ? `En un choque trepidante de 90 minutos, ${home.name} y ${away.name} firmaron las tablas (${homeScore}-${awayScore}). Ambos equipos suman un punto valioso.`
        : isFr
        ? `Au terme de 90 minutes intenses, ${home.name} et ${away.name} se quittent sur un score de ${homeScore}-${awayScore}. Chaque équipe empoche 1 point.`
        : isIt
        ? `Dopo 90 minuti di fuoco, ${home.name} e ${away.name} dividono la posta con un ${homeScore}-${awayScore}. Un punto guadagnato per entrambe.`
        : isPt
        ? `Após 90 minutos de pura emoção, ${home.name} e ${away.name} dividiram os pontos (${homeScore}-${awayScore}).`
        : `Week ${f.week} clash between ${home.name} and ${away.name} ended in a hard-fought ${homeScore}-${awayScore} draw. Both teams claimed 1 point in the league standings.`;
    } else {
      const winner = isHomeWinner ? home : away;
      const loser = isHomeWinner ? away : home;
      const winScore = isHomeWinner ? homeScore : awayScore;
      const loseScore = isHomeWinner ? awayScore : homeScore;

      derbyHeadline = isTr
        ? `🔥 DERBİ ZAFERİ ${winner.name.toUpperCase()}'İN! ${home.name} ${homeScore} - ${awayScore} ${away.name}`
        : isDe
        ? `🔥 DERBYSIEG FÜR ${winner.name.toUpperCase()}! ${home.name} ${homeScore} - ${awayScore} ${away.name}`
        : isEs
        ? `🔥 ¡VICTORIA EN EL DERBI PARA ${winner.name.toUpperCase()}! ${home.name} ${homeScore} - ${awayScore} ${away.name}`
        : isFr
        ? `🔥 VICTOIRE DANS LE DERBY POUR ${winner.name.toUpperCase()}! ${home.name} ${homeScore} - ${awayScore} ${away.name}`
        : isIt
        ? `🔥 TRIONFO NEL DERBY PER ${winner.name.toUpperCase()}! ${home.name} ${homeScore} - ${awayScore} ${away.name}`
        : isPt
        ? `🔥 VITÓRIA NO DÉRBI PARA O ${winner.name.toUpperCase()}! ${home.name} ${homeScore} - ${awayScore} ${away.name}`
        : `🔥 DERBY GLORY FOR ${winner.name.toUpperCase()}! ${home.name} ${homeScore} - ${awayScore} ${away.name}`;

      derbySummary = isTr
        ? `${f.week}. hafta derbisinde ${winner.name}, rakibi ${loser.name}'i ${winScore}-${loseScore} yenerek şehri sevince boğdu.`
        : isDe
        ? `In Spielwoche ${f.week} triumphierte ${winner.name} mit ${winScore}:${loseScore} über ${loser.name}.`
        : isEs
        ? `En la jornada ${f.week}, ${winner.name} venció ${winScore}-${loseScore} a su eterno rival ${loser.name}.`
        : isFr
        ? `Lors de la journée ${f.week}, ${winner.name} s'est imposé ${winScore}-${loseScore} face à ${loser.name}.`
        : isIt
        ? `Nella ${f.week}ª giornata, ${winner.name} ha sconfitto ${loser.name} per ${winScore}-${loseScore}.`
        : isPt
        ? `Na jornada ${f.week}, o ${winner.name} superou o ${loser.name} por ${winScore}-${loseScore}.`
        : `In Week ${f.week}, ${winner.name} triumphed over ${loser.name} with a ${winScore}-${loseScore} scoreline.`;

      derbyFull = isTr
        ? `Süper Lig'in ${f.week}. haftasında oynanan dev derbide ${winner.name}, ezeli rakibi ${loser.name} karşısında sahadan ${winScore}-${loseScore} galip ayrıldı. Maç boyunca üstün bir futbol sergileyen ${winner.name}, lig tablosundaki yerini perçinledi.`
        : isDe
        ? `Im großen Derby der ${f.week}. Spielwoche holte ${winner.name} gegen ${loser.name} einen ${winScore}:${loseScore}-Sieg und sicherte sich 3 wichtige Punkte.`
        : isEs
        ? `${winner.name} se llevó los 3 puntos frente a ${loser.name} en el derbi de la jornada ${f.week} (${winScore}-${loseScore}) con una exhibición memorable.`
        : isFr
        ? `${winner.name} a empoché les 3 points face à ${loser.name} lors du derby de la journée ${f.week} (${winScore}-${loseScore}).`
        : isIt
        ? `${winner.name} conquista 3 punti d'oro contro ${loser.name} nel derby della ${f.week}ª giornata (${winScore}-${loseScore}).`
        : isPt
        ? `O ${winner.name} conquistou os 3 pontos frente ao ${loser.name} no dérbi da jornada ${f.week} (${winScore}-${loseScore}).`
        : `${winner.name} claimed all 3 points against ${loser.name} in their Week ${f.week} derby showdown (${winScore}-${loseScore}).`;
    }

    const badgeTag = isTr ? '🏆 SÜPER LİG DERBİSİ' : isDe ? '🏆 LIGA DERBY' : isEs ? '🏆 DERBI DE LIGA' : isFr ? '🏆 DERBY DE LIGUE' : isIt ? '🏆 DERBY DI CAMPIONATO' : isPt ? '🏆 DÉRBI DO CAMPEONATO' : '🏆 LEAGUE DERBY';
    const timestampStr = isTr ? `${f.week}. Hafta Maçı` : isDe ? `Spieltag ${f.week}` : isEs ? `Jornada ${f.week}` : isFr ? `Journée ${f.week}` : isIt ? `Giornata ${f.week}` : isPt ? `Jornada ${f.week}` : `Week ${f.week} Match`;

    news.push({
      id: `real-derby-${f.id || idx}-${f.week}`,
      category: 'DERBY',
      title: derbyHeadline,
      summary: derbySummary,
      fullContent: derbyFull,
      timestamp: timestampStr,
      badgeTag,
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
      matchData: {
        homeTeam: home.name,
        awayTeam: away.name,
        homeScore,
        awayScore,
        played: true,
        week: f.week
      }
    });
  });

  // B) Bu Hafta veya Gelecek Hafta Oynanacak Gerçek Derbi Önizlemesi (Upcoming Derby in Calendar)
  const upcomingDerbies = fixtures.filter(f => {
    if (f.played) return false;
    if (f.week !== currentWeek && f.week !== currentWeek + 1) return false;
    return DERBY_PAIRS.some(([t1, t2]) => 
      (f.homeTeamId === t1 && f.awayTeamId === t2) || (f.homeTeamId === t2 && f.awayTeamId === t1)
    );
  });

  if (upcomingDerbies.length > 0) {
    const upF = upcomingDerbies[0];
    const home = getTeamObj(upF.homeTeamId);
    const away = getTeamObj(upF.awayTeamId);
    if (home && away) {
      const upTitle = isTr
        ? `⚡ DEV DERBİ HEYECANI KAPIDA: ${home.name} vs ${away.name} (${upF.week}. Hafta)`
        : isDe
        ? `⚡ GROSSES DERBY VORAUS: ${home.name} vs ${away.name} (Woche ${upF.week})`
        : isEs
        ? `⚡ GRAN DERBI EN CAMINO: ${home.name} vs ${away.name} (Jornada ${upF.week})`
        : isFr
        ? `⚡ CHOC DE DERBY À VENIR: ${home.name} vs ${away.name} (Journée ${upF.week})`
        : isIt
        ? `⚡ GRANDE DERBY IN ARRIVO: ${home.name} vs ${away.name} (Giornata ${upF.week})`
        : isPt
        ? `⚡ GRANDE DÉRBI À VISTA: ${home.name} vs ${away.name} (Jornada ${upF.week})`
        : `⚡ MASSIVE DERBY AHEAD: ${home.name} vs ${away.name} (Week ${upF.week})`;

      const upSum = isTr
        ? `Ligin ${upF.week}. haftasında iki dev kulüp kozlarını paylaşacak. Biletler tükendi, tüm gözler bu maçta!`
        : isDe
        ? `In Spielwoche ${fWeekLabel(upF.week, language)} treffen zwei Giganten aufeinander. Das Stadion ist ausverkauft!`
        : isEs
        ? `En la jornada ${upF.week}, dos gigantes del fútbol se verán las caras. ¡Estadio lleno!`
        : isFr
        ? `Lors de la journée ${upF.week}, deux géants s'affronteront. Tous les regards sont tournés vers ce choc !`
        : isIt
        ? `Nella ${upF.week}ª giornata, due colossi si affronteranno. Biglietti esauriti, attesa alle stelle!`
        : isPt
        ? `Na jornada ${upF.week}, dois gigantes defrontam-se num jogo com lotação esgotada!`
        : `In Week ${upF.week}, two football powerhouses will lock horns. Tickets are sold out!`;

      const upFull = isTr
        ? `Süper Lig'de nefesler tutuldu! ${upF.week}. haftada ${home.name} sahasında ${away.name}'i ağırlayacak. İki takımın teknik heyeti taktik hazırlıklarını tamamladı. Zirve yarışını doğrudan etkileyecek olan randevuda tüm spor kamuoyu bu maça odaklandı.`
        : `All eyes on Week ${upF.week} as ${home.name} hosts ${away.name} in a crucial league fixture affecting the championship battle.`;

      news.push({
        id: `upcoming-derby-${upF.id || 'w' + upF.week}`,
        category: 'DERBY',
        title: upTitle,
        summary: upSum,
        fullContent: upFull,
        timestamp: isTr ? `${upF.week}. Hafta Öncesi` : `Ahead of Week ${upF.week}`,
        badgeTag: isTr ? '🔥 HAFTANIN MAÇI' : isDe ? '🔥 SPIEL DER WOCHE' : isEs ? '🔥 PARTIDO DE LA SEMANA' : isFr ? '🔥 MATCH DE LA SEMAINE' : isIt ? '🔥 PARTITA DELLA SETTIMANA' : isPt ? '🔥 JOGO DA SEMANA' : '🔥 MATCH OF THE WEEK',
        badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
        matchData: {
          homeTeam: home.name,
          awayTeam: away.name,
          played: false,
          week: upF.week
        }
      });
    }
  }

  // =========================================================================
  // 2. GERÇEK PUAN DURUMU & LİG ZİRVE HABERLERİ (Real Standings & Leader)
  // =========================================================================
  if (standings.length > 0) {
    const leaderRow = standings[0];
    const leaderTeam = getTeamObj(leaderRow.teamId);
    const userRow = standings.find(r => r.teamId === currentTeam.id);

    if (leaderTeam) {
      const leaderTitle = isTr
        ? `👑 ZİRVENİN SAHİBİ: ${leaderTeam.name} ${leaderRow.points} Puanla Liderliğini Sürdürüyor!`
        : isDe
        ? `👑 TABELLENFÜHRER: ${leaderTeam.name} führt mit ${leaderRow.points} Punkten!`
        : isEs
        ? `👑 LÍDER DE LA TABLA: ¡${leaderTeam.name} en la cima con ${leaderRow.points} pts!`
        : isFr
        ? `👑 LEADER DU CLASSEMENT: ${leaderTeam.name} en tête avec ${leaderRow.points} pts !`
        : isIt
        ? `👑 CAPOLISTA: ${leaderTeam.name} in vetta con ${leaderRow.points} punti!`
        : isPt
        ? `👑 LÍDER ISOLADO: ${leaderTeam.name} lidera com ${leaderRow.points} pontos!`
        : `👑 LEAGUE LEADERS: ${leaderTeam.name} Tops Standings with ${leaderRow.points} Pts!`;

      const leaderSummary = isTr
        ? `${currentWeek}. hafta itibariyle ${leaderRow.won} galibiyet ve ${leaderRow.points} puan toplayan ${leaderTeam.name} şampiyonluk yarışında önde.`
        : isDe
        ? `Mit ${leaderRow.won} Siegen und ${leaderRow.points} Punkten steht ${leaderTeam.name} an der Spitze.`
        : isEs
        ? `Con ${leaderRow.won} victorias y ${leaderRow.points} puntos, ${leaderTeam.name} lidera la carrera por el título.`
        : isFr
        ? `Avec ${leaderRow.won} victoires et ${leaderRow.points} points, ${leaderTeam.name} domine la course au titre.`
        : isIt
        ? `Con ${leaderRow.won} vittorie e ${leaderRow.points} punti, ${leaderTeam.name} guida la classifica.`
        : isPt
        ? `Com ${leaderRow.won} vitórias e ${leaderRow.points} pontos, o ${leaderTeam.name} comanda a tabela.`
        : `With ${leaderRow.won} wins and ${leaderRow.points} points, ${leaderTeam.name} sits comfortably atop the league table.`;

      news.push({
        id: `leader-news-w${currentWeek}`,
        category: 'LEAGUE',
        title: leaderTitle,
        summary: leaderSummary,
        fullContent: `${leaderTeam.name} (${leaderRow.points} pts, GD: ${leaderRow.goalsFor - leaderRow.goalsAgainst})`,
        timestamp: isTr ? 'Güncel Durum' : isDe ? 'Aktuell' : isEs ? 'Actual' : isFr ? 'Actuel' : isIt ? 'Attuale' : isPt ? 'Atual' : 'Latest Standings',
        badgeTag: isTr ? '📊 PUAN DURUMU' : isDe ? '📊 TABELLE' : isEs ? '📊 CLASIFICACIÓN' : isFr ? '📊 CLASSEMENT' : isIt ? '📊 CLASSIFICA' : isPt ? '📊 CLASSIFICAÇÃO' : '📊 STANDINGS',
        badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/40'
      });
    }

    if (userRow && userRow.teamId !== leaderRow.teamId) {
      const userRank = standings.findIndex(r => r.teamId === currentTeam.id) + 1;
      const userTitle = isTr
        ? `📈 ${currentTeam.name} Ligde ${userRank}. Sırada (${userRow.points} Puan)`
        : isDe
        ? `📈 ${currentTeam.name} auf Platz ${userRank} (${userRow.points} Pkt.)`
        : isEs
        ? `📈 ${currentTeam.name} en el puesto ${userRank} (${userRow.points} pts)`
        : isFr
        ? `📈 ${currentTeam.name} à la ${userRank}e place (${userRow.points} pts)`
        : isIt
        ? `📈 ${currentTeam.name} al ${userRank}° posto (${userRow.points} pt)`
        : isPt
        ? `📈 ${currentTeam.name} no ${userRank}º lugar (${userRow.points} pts)`
        : `📈 ${currentTeam.name} in Position ${userRank} (${userRow.points} Pts)`;

      const userSummary = isTr
        ? `Teknik heyetimiz ve oyuncularımız önümüzdeki haftalarda üst sıralara tırmanmak için hazırlıklarını sürdürüyor.`
        : isDe
        ? `Unser Team trainiert fokussiert, um in den nächsten Wochen weiter nach oben zu klettern.`
        : isEs
        ? `Nuestra plantilla se prepara a fondo para escalar posiciones en las próximas jornadas.`
        : isFr
        ? `Notre effectif redouble d'efforts pour remonter au classement lors des prochains matchs.`
        : isIt
        ? `La nostra squadra si allena duramente per scalare posizioni nelle prossime sfide.`
        : isPt
        ? `O nosso plantel continua a trabalhar no duro para subir na classificação.`
        : `Our squad is training hard to climb further up the table in the upcoming fixtures.`;

      news.push({
        id: `user-team-status-w${currentWeek}`,
        category: 'LEAGUE',
        title: userTitle,
        summary: userSummary,
        fullContent: `${currentTeam.name}: ${userRow.played} games, ${userRow.won}W - ${userRow.drawn}D - ${userRow.lost}L (${userRow.points} pts)`,
        timestamp: isTr ? 'Bu Hafta' : isDe ? 'Diese Woche' : isEs ? 'Esta Semana' : isFr ? 'Cette Semaine' : isIt ? 'Questa Settimana' : isPt ? 'Esta Semana' : 'This Week',
        badgeTag: isTr ? '🎯 KULÜP ANALİZİ' : isDe ? '🎯 VEREINSANALYSE' : isEs ? '🎯 ANÁLISIS DEL CLUB' : isFr ? '🎯 ANALYSE DU CLUB' : isIt ? '🎯 ANALISI CLUB' : isPt ? '🎯 ANÁLISE DO CLUBE' : '🎯 CLUB ANALYSIS',
        badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
      });
    }
  }

  // =========================================================================
  // 3. GERÇEK GOL KRALLIĞI VE YILDIZ OYUNCULAR (Real in-game top performers)
  // =========================================================================
  const allPlayersInGame: { player: Player; team: Team }[] = [];
  allTeams.forEach(t => {
    t.players.forEach(p => {
      allPlayersInGame.push({ player: p, team: t });
    });
  });

  const topScorers = [...allPlayersInGame]
    .filter(x => (x.player.goalsScored || 0) > 0)
    .sort((a, b) => (b.player.goalsScored || 0) - (a.player.goalsScored || 0));

  if (topScorers.length > 0) {
    const leaderScorer = topScorers[0];
    const scorerTitle = isTr
      ? `⚽ GOL KRALLIĞI ZİRVESİ: ${leaderScorer.player.name} (${leaderScorer.team.name}) - ${leaderScorer.player.goalsScored} Gol!`
      : isDe
      ? `⚽ TORSCHÜTZENKÖNIG: ${leaderScorer.player.name} (${leaderScorer.team.name}) - ${leaderScorer.player.goalsScored} Tore!`
      : isEs
      ? `⚽ MÁXIMO GOLEADOR: ${leaderScorer.player.name} (${leaderScorer.team.name}) - ${leaderScorer.player.goalsScored} Goles!`
      : isFr
      ? `⚽ MEILLEUR BUTEUR: ${leaderScorer.player.name} (${leaderScorer.team.name}) - ${leaderScorer.player.goalsScored} Buts !`
      : isIt
      ? `⚽ CAPOCANNONIERE: ${leaderScorer.player.name} (${leaderScorer.team.name}) - ${leaderScorer.player.goalsScored} Gol!`
      : isPt
      ? `⚽ MELHOR MARCADOR: ${leaderScorer.player.name} (${leaderScorer.team.name}) - ${leaderScorer.player.goalsScored} Golos!`
      : `⚽ TOP GOALSCORER: ${leaderScorer.player.name} (${leaderScorer.team.name}) - ${leaderScorer.player.goalsScored} Goals!`;

    const scorerSummary = isTr
      ? `${leaderScorer.team.name} formasıyla ${leaderScorer.player.goalsScored} gole ulaşan ${leaderScorer.player.name}, ligin en skorer ismi konumunda.`
      : isDe
      ? `Mit ${leaderScorer.player.goalsScored} Treffern für ${leaderScorer.team.name} führt ${leaderScorer.player.name} die Torschützenliste an.`
      : isEs
      ? `Con ${leaderScorer.player.goalsScored} goles con el ${leaderScorer.team.name}, ${leaderScorer.player.name} encabeza la tabla de goleadores.`
      : isFr
      ? `Auteur de ${leaderScorer.player.goalsScored} buts avec ${leaderScorer.team.name}, ${leaderScorer.player.name} est en tête des buteurs.`
      : isIt
      ? `Con ${leaderScorer.player.goalsScored} gol con ${leaderScorer.team.name}, ${leaderScorer.player.name} guida la classifica marcatori.`
      : isPt
      ? `Com ${leaderScorer.player.goalsScored} golos pelo ${leaderScorer.team.name}, ${leaderScorer.player.name} lidera a lista de marcadores.`
      : `With ${leaderScorer.player.goalsScored} goals for ${leaderScorer.team.name}, ${leaderScorer.player.name} leads the Golden Boot race.`;

    news.push({
      id: `top-scorer-w${currentWeek}`,
      category: 'LEAGUE',
      title: scorerTitle,
      summary: scorerSummary,
      fullContent: `${leaderScorer.player.name} (${leaderScorer.player.position}, ${leaderScorer.player.overall} OVR) - ${leaderScorer.player.goalsScored} goals.`,
      timestamp: isTr ? 'Bu Hafta' : isDe ? 'Diese Woche' : isEs ? 'Esta Semana' : isFr ? 'Cette Semaine' : isIt ? 'Questa Settimana' : isPt ? 'Esta Semana' : 'This Week',
      badgeTag: isTr ? '🥇 GOL KRALLIĞI' : isDe ? '🥇 TORSCHÜTZEN' : isEs ? '🥇 BOTA DE ORO' : isFr ? '🥇 SOULIER D\'OR' : isIt ? '🥇 CAPOCANNONIERE' : isPt ? '🥇 BOTA DE OURO' : '🥇 GOLDEN BOOT',
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
      playerData: leaderScorer.player
    });
  }

  // =========================================================================
  // 4. KULÜBÜMÜZÜN SAĞLIK & SAKATLIK DURUMU (Real Squad Health)
  // =========================================================================
  const injuredPlayer = currentTeam.players.find(p => p.isInjured);
  if (injuredPlayer) {
    const injWeeks = injuredPlayer.injuryWeeksLeft || 2;
    const injTitle = isTr
      ? `🚨 Sağlık Heyetinden Bilgilendirme: ${injuredPlayer.name} Sakatlandı!`
      : isDe
      ? `🚨 Medizinischer Bericht: ${injuredPlayer.name} fällt aus!`
      : isEs
      ? `🚨 Parte Médico: ¡${injuredPlayer.name} lesionado!`
      : isFr
      ? `🚨 Point Médical: ${injuredPlayer.name} blessé !`
      : isIt
      ? `🚨 Comunicato Medico: ${injuredPlayer.name} infortunato!`
      : isPt
      ? `🚨 Boletim Médico: ${injuredPlayer.name} lesionado!`
      : `🚨 Medical Update: ${injuredPlayer.name} Sidelined!`;

    const injSummary = isTr
      ? `Sakatlanan oyuncumuz ${injuredPlayer.name} (${injuredPlayer.position}, ${injuredPlayer.overall} OVR) ${injWeeks} hafta sahalardan uzak kalacak.`
      : isDe
      ? `${injuredPlayer.name} (${injuredPlayer.position}, ${injuredPlayer.overall} OVR) fällt für ca. ${injWeeks} Wochen aus.`
      : isEs
      ? `${injuredPlayer.name} (${injuredPlayer.position}, ${injuredPlayer.overall} OVR) causará baja durante ${injWeeks} semanas.`
      : isFr
      ? `${injuredPlayer.name} (${injuredPlayer.position}, ${injuredPlayer.overall} OVR) sera indisponible pendant ${injWeeks} semaines.`
      : isIt
      ? `${injuredPlayer.name} (${injuredPlayer.position}, ${injuredPlayer.overall} OVR) rimarrà fuori per ${injWeeks} settimane.`
      : isPt
      ? `${injuredPlayer.name} (${injuredPlayer.position}, ${injuredPlayer.overall} OVR) ficará de fora por ${injWeeks} semanas.`
      : `Injured player ${injuredPlayer.name} (${injuredPlayer.position}, ${injuredPlayer.overall} OVR) will miss ${injWeeks} weeks.`;

    news.push({
      id: `injury-${injuredPlayer.id}-w${currentWeek}`,
      category: 'INJURY',
      title: injTitle,
      summary: injSummary,
      fullContent: isTr
        ? `Kulüp Sağlık Kurulu Başkanı tarafından yapılan resmi açıklamada: "${injuredPlayer.name} son antrenmanda darbe aldı. Çekilen tetkikler sonucunda ${injWeeks} hafta sürecek fizik tedavi ve rehabilitasyon programı uygulanacaktır." denildi.`
        : `Official medical statement: "${injuredPlayer.name} suffered an injury and is undergoing a ${injWeeks}-week rehabilitation program."`,
      timestamp: isTr ? '2 saat önce' : isDe ? 'Vor 2 Std.' : isEs ? 'Hace 2 h' : isFr ? 'Il y a 2h' : isIt ? '2 ore fa' : isPt ? 'Há 2h' : '2 hours ago',
      badgeTag: isTr ? '🚨 SAKATLIK RAPORU' : isDe ? '🚨 VERLETZUNG' : isEs ? '🚨 PARTE MÉDICO' : isFr ? '🚨 POINT MÉDICAL' : isIt ? '🚨 REPORT INFORTUNIO' : isPt ? '🚨 BOLETIM MÉDICO' : '🚨 INJURY REPORT',
      badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
      playerData: injuredPlayer
    });
  } else {
    const starPlayer = currentTeam.players.find(p => p.isStarting && (p.overall >= 80 || p.growthProgress > 60)) || currentTeam.players[0];
    if (starPlayer) {
      const fitTitle = isTr
        ? `✅ Sağlık Heyetinden Müjde: ${starPlayer.name} %100 Formda!`
        : isDe
        ? `✅ Topfit: ${starPlayer.name} zu 100% einsatzbereit!`
        : isEs
        ? `✅ Alta Médica: ¡${starPlayer.name} al 100% de forma!`
        : isFr
        ? `✅ Feu Vert Médical: ${starPlayer.name} à 100% de sa forme !`
        : isIt
        ? `✅ Idoneità Medica: ${starPlayer.name} al 100% della condizione!`
        : isPt
        ? `✅ Aptidão Médica: ${starPlayer.name} a 100% para o jogo!`
        : `✅ Medical Clearance: ${starPlayer.name} 100% Fit!`;

      const fitSummary = isTr
        ? `Sağlık heyetimiz ${starPlayer.name} için tam performans onayı verdi. Oyuncumuz maça hazır.`
        : isDe
        ? `Das Ärzteteam bestätigt absolute Topform für ${starPlayer.name}. Bereit für den Spieltag.`
        : isEs
        ? `El cuerpo médico confirma que ${starPlayer.name} está en óptimas condiciones para competir.`
        : isFr
        ? `Le staff médical a donné son accord complet pour ${starPlayer.name}. Prêt pour le match.`
        : isIt
        ? `Lo staff medico ha dato il via libera per ${starPlayer.name}. Pronto per scendere in campo.`
        : isPt
        ? `O departamento médico deu luz verde a ${starPlayer.name}. Pronto para a partida.`
        : `Medical board gave full performance clearance for ${starPlayer.name}. Ready for matchday.`;

      news.push({
        id: `health-fit-${starPlayer.id}-w${currentWeek}`,
        category: 'SQUAD',
        title: fitTitle,
        summary: fitSummary,
        fullContent: `${starPlayer.name} (${starPlayer.position}, ${starPlayer.overall} OVR, Stamina: ${starPlayer.stamina || 100}%)`,
        timestamp: isTr ? 'Dün' : isDe ? 'Gestern' : isEs ? 'Ayer' : isFr ? 'Hier' : isIt ? 'Ieri' : isPt ? 'Ontem' : 'Yesterday',
        badgeTag: isTr ? '✅ KADRO RAPORU' : isDe ? '✅ KADERFITNESS' : isEs ? '✅ ESTADO FÍSICO' : isFr ? '✅ FORME DU GROUPE' : isIt ? '✅ CONDIZIONE' : isPt ? '✅ FORMA FÍSICA' : '✅ SQUAD FITNESS',
        badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
        playerData: starPlayer
      });
    }
  }

  // =========================================================================
  // 5. GERÇEK GÖZLEMCİ (SCOUT) VE GENÇ YETENEK KEŞİFLERİ (Real In-game Talents)
  // =========================================================================
  let youngTalentObj: { player: Player; team: Team } | null = null;
  for (const t of allTeams) {
    if (t.id !== currentTeam.id) {
      const found = t.players.find(p => p.age <= 22 && (p.potential || p.overall) >= 73);
      if (found) {
        youngTalentObj = { player: found, team: t };
        break;
      }
    }
  }

  if (youngTalentObj) {
    const { player: talent, team: sellerTeam } = youngTalentObj;
    const pot = talent.potential || (talent.overall + 5);
    const valM = ((talent.marketValue || 4500000) / 1000000).toFixed(1);

    const scoutTitle = isTr
      ? `🔍 Scout Raporu: ${talent.name} (${talent.age} Yaş, ${talent.position}) - ${sellerTeam.name}`
      : isDe
      ? `🔍 Scouting-Bericht: ${talent.name} (${talent.age} J., ${talent.position}) - ${sellerTeam.name}`
      : isEs
      ? `🔍 Informe de Ojeador: ${talent.name} (${talent.age} años, ${talent.position}) - ${sellerTeam.name}`
      : isFr
      ? `🔍 Rapport de Scout: ${talent.name} (${talent.age} ans, ${talent.position}) - ${sellerTeam.name}`
      : isIt
      ? `🔍 Report Osservatore: ${talent.name} (${talent.age} anni, ${talent.position}) - ${sellerTeam.name}`
      : isPt
      ? `🔍 Relatório de Observação: ${talent.name} (${talent.age} anos, ${talent.position}) - ${sellerTeam.name}`
      : `🔍 Scouting Discovery: ${talent.name} (${talent.age} Y/O, ${talent.position}) - ${sellerTeam.name}`;

    const scoutSummary = isTr
      ? `Gözlemci ekibimiz ${sellerTeam.name} forması giyen genç yetenek ${talent.name} için olumlu rapor sundu. Potansiyel: ${pot} OVR.`
      : isDe
      ? `Unsere Scouts haben ein Auge auf ${talent.name} von ${sellerTeam.name} geworfen. Potenzial: ${pot} OVR.`
      : isEs
      ? `Nuestros ojeadores recomiendan a la joven promesa ${talent.name} del ${sellerTeam.name}. Potencial: ${pot} OVR.`
      : isFr
      ? `Nos recruteurs ont repéré la pépite ${talent.name} de ${sellerTeam.name}. Potentiel: ${pot} OVR.`
      : isIt
      ? `I nostri scout segnalano il talento ${talent.name} del ${sellerTeam.name}. Potenziale: ${pot} OVR.`
      : isPt
      ? `Os nossos olheiros destacam o jovem prodígio ${talent.name} do ${sellerTeam.name}. Potencial: ${pot} OVR.`
      : `Our scouting team filed a glowing report on ${sellerTeam.name}'s talent ${talent.name}. Potential: ${pot} OVR.`;

    news.push({
      id: `scout-talent-${talent.id}-w${currentWeek}`,
      category: 'SCOUT',
      title: scoutTitle,
      summary: scoutSummary,
      fullContent: `${talent.name} | ${talent.position} | ${talent.age} y/o | OVR: ${talent.overall} | Potential: ${pot} | Est. Value: €${valM}M (${sellerTeam.name})`,
      timestamp: isTr ? 'Bu Hafta' : isDe ? 'Diese Woche' : isEs ? 'Esta Semana' : isFr ? 'Cette Semaine' : isIt ? 'Questa Settimana' : isPt ? 'Esta Semana' : 'This Week',
      badgeTag: isTr ? '🔎 GENÇ YETENEK' : isDe ? '🔎 TALENTSCOUT' : isEs ? '🔎 JOVEN PROMESA' : isFr ? '🔎 JEUNE TALENT' : isIt ? '🔎 GIOVANE TALENTO' : isPt ? '🔎 JOVEM PROMESSA' : '🔎 WONDERKID SCOUT',
      badgeColor: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
      playerData: talent
    });
  }

  // =========================================================================
  // 6. MENAJER & BASIN TOPLANTISI ANALİZİ (Press & Next Match Preview)
  // =========================================================================
  const pressTitle = isTr
    ? `🎙️ ${currentWeek}. Hafta Maç Önü Basın Değerlendirmesi: ${currentTeam.name} - ${opponentTeam.name}`
    : isDe
    ? `🎙️ Pressekonferenz vor Spieltag ${currentWeek}: ${currentTeam.name} vs ${opponentTeam.name}`
    : isEs
    ? `🎙️ Rueda de Prensa Previa (Jornada ${currentWeek}): ${currentTeam.name} vs ${opponentTeam.name}`
    : isFr
    ? `🎙️ Conférence de Presse d'Avant-Match (Journée ${currentWeek}): ${currentTeam.name} vs ${opponentTeam.name}`
    : isIt
    ? `🎙️ Conferenza Stampa Pre-Partita (${currentWeek}ª Giornata): ${currentTeam.name} vs ${opponentTeam.name}`
    : isPt
    ? `🎙️ Conferência de Imprensa Pré-Jogo (Jornada ${currentWeek}): ${currentTeam.name} vs ${opponentTeam.name}`
    : `🎙️ Week ${currentWeek} Pre-Match Press Briefing: ${currentTeam.name} vs ${opponentTeam.name}`;

  const pressSummary = isTr
    ? `Teknik heyetimiz zorlu ${opponentTeam.name} karşılaşması öncesi galibiyete kenetlendi.`
    : isDe
    ? `Unser Trainerteam ist vor dem Duell gegen ${opponentTeam.name} voll auf Sieg fokussiert.`
    : isEs
    ? `El cuerpo técnico se concentra al máximo para el partido crucial ante el ${opponentTeam.name}.`
    : isFr
    ? `Le staff technique est pleinement concentré sur la victoire face à ${opponentTeam.name}.`
    : isIt
    ? `La guida tecnica è determinata a conquistare i 3 punti contro ${opponentTeam.name}.`
    : isPt
    ? `A equipa técnica está totalmente focada em somar os 3 pontos diante do ${opponentTeam.name}.`
    : `Our tactical team is fully locked in ahead of the showdown against ${opponentTeam.name}.`;

  news.push({
    id: `press-preview-w${currentWeek}`,
    category: 'PRESS',
    title: pressTitle,
    summary: pressSummary,
    fullContent: `${currentTeam.name} vs ${opponentTeam.name}`,
    timestamp: isTr ? '1 saat önce' : isDe ? 'Vor 1 Std.' : isEs ? 'Hace 1 h' : isFr ? 'Il y a 1h' : isIt ? '1 ora fa' : isPt ? 'Há 1h' : '1 hour ago',
    badgeTag: isTr ? '🎙️ BASIN TOPLANTISI' : isDe ? '🎙️ PRESSEKONFERENZ' : isEs ? '🎙️ RUEDA DE PRENSA' : isFr ? '🎙️ CONFÉRENCE DE PRESSE' : isIt ? '🎙️ CONFERENZA STAMPA' : isPt ? '🎙️ CONFERÊNCIA DE IMPRENSA' : '🎙️ PRESS BRIEFING',
    badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40'
  });

  return news;
};

function fWeekLabel(week: number, lang: LanguageCode): string {
  if (lang === 'TR') return `${week}. Hafta`;
  if (lang === 'DE') return `${week}. Spieltag`;
  if (lang === 'ES' || lang === 'FR' || lang === 'PT') return `Jornada ${week}`;
  if (lang === 'IT') return `${week}ª Giornata`;
  return `Week ${week}`;
}

export const NewsFeed: React.FC<NewsFeedProps> = ({
  currentTeam,
  opponentTeam,
  currentWeek,
  allTeams,
  fixtures = [],
  standings = []
}) => {
  const { language, t } = useTranslation();
  const isTr = language === 'TR';
  const isDe = language === 'DE';
  const isEs = language === 'ES';
  const isFr = language === 'FR';
  const isIt = language === 'IT';
  const isPt = language === 'PT';

  const [selectedCategory, setSelectedCategory] = useState<NewsCategory>('ALL');
  const [selectedArticle, setSelectedArticle] = useState<NewsItem | null>(null);

  const newsItems = generateNewsFeed(language, currentTeam, opponentTeam, currentWeek, allTeams, fixtures, standings);

  const filteredNews = selectedCategory === 'ALL'
    ? newsItems
    : newsItems.filter(item => item.category === selectedCategory);

  const categories: { key: NewsCategory; label: string; icon: string }[] = [
    { key: 'ALL', label: isTr ? 'Tüm Haberler' : isDe ? 'Alle News' : isEs ? 'Todas las Noticias' : isFr ? 'Toutes les Actualités' : isIt ? 'Tutte le Notizie' : isPt ? 'Todas as Notícias' : 'All News', icon: '📰' },
    { key: 'DERBY', label: isTr ? 'Süper Lig Derbileri' : isDe ? 'Derbys' : isEs ? 'Derbis' : isFr ? 'Derbys' : isIt ? 'Derby' : isPt ? 'Dérbis' : 'Derbies', icon: '⚔️' },
    { key: 'LEAGUE', label: isTr ? 'Puan & Zirve' : isDe ? 'Tabelle' : isEs ? 'Clasificación' : isFr ? 'Classement' : isIt ? 'Classifica' : isPt ? 'Classificação' : 'League & Table', icon: '🏆' },
    { key: 'SQUAD', label: isTr ? 'Kadro & Form' : isDe ? 'Kader & Form' : isEs ? 'Plantilla & Forma' : isFr ? 'Effectif & Forme' : isIt ? 'Rosa & Forma' : isPt ? 'Plantel & Forma' : 'Squad & Form', icon: '👥' },
    { key: 'SCOUT', label: isTr ? 'Scout Keşifleri' : isDe ? 'Scouting' : isEs ? 'Ojeador' : isFr ? 'Recrutement' : isIt ? 'Osservatori' : isPt ? 'Prospeção' : 'Scouting', icon: '🔍' },
    { key: 'INJURY', label: isTr ? 'Sakatlık Raporu' : isDe ? 'Verletzungen' : isEs ? 'Lesiones' : isFr ? 'Blessures' : isIt ? 'Infortuni' : isPt ? 'Lesões' : 'Injuries', icon: '🚨' },
    { key: 'PRESS', label: isTr ? 'Basın Odası' : isDe ? 'Presseraum' : isEs ? 'Sala de Prensa' : isFr ? 'Salle de Presse' : isIt ? 'Sala Stampa' : isPt ? 'Sala de Imprensa' : 'Press Room', icon: '🎙️' },
  ];

  return (
    <div className="flex flex-col h-full space-y-2.5">
      {/* Header Bar */}
      <div className="flex items-center justify-between border-b border-[#2d2150] pb-2 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-purple-600/20 border border-purple-500/40 text-purple-300 flex items-center justify-center shadow">
            <Newspaper className="w-4 h-4 text-purple-400" />
          </div>
          <div>
            <h2 className="font-black text-xs sm:text-sm text-white uppercase tracking-wider">
              {isTr ? 'MEDYA HABER AKIŞI' : isDe ? 'MEDIEN & NACHRICHTEN' : isEs ? 'NOTICIAS Y MEDIOS' : isFr ? 'FIL D\'ACTUALITÉS' : isIt ? 'NOTIZIE E MEDIA' : isPt ? 'NOTÍCIAS E IMPRENSA' : 'MEDIA NEWS FEED'}
            </h2>
            <p className="text-[9px] sm:text-[10px] text-slate-400 font-semibold">
              {isTr ? 'Süper Lig & Kulüp Gündemi' : isDe ? 'Süper Lig & Vereinsgeschehen' : isEs ? 'Süper Lig y Actualidad del Club' : isFr ? 'Süper Lig & Actualités du Club' : isIt ? 'Süper Lig & Novità dal Club' : isPt ? 'Süper Lig & Atualidade do Clube' : 'Super Lig & Club Highlights'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="px-2.5 py-0.5 rounded-full bg-[#20183e] border border-purple-500/40 text-purple-300 font-extrabold text-[9.5px] sm:text-[10.5px]">
            {fWeekLabel(currentWeek, language)}
          </span>
        </div>
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto custom-scrollbar pb-1 shrink-0">
        {categories.map(cat => (
          <button
            key={cat.key}
            onClick={() => setSelectedCategory(cat.key)}
            className={`px-2.5 py-1 rounded-lg text-[10.5px] font-black border transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              selectedCategory === cat.key
                ? 'bg-purple-600 border-purple-400 text-white shadow-md'
                : 'bg-[#15102a] border-[#2d2150] text-slate-400 hover:text-white hover:border-purple-500/50'
            }`}
          >
            <span>{cat.icon}</span>
            <span>{cat.label}</span>
          </button>
        ))}
      </div>

      {/* Main Grid: Articles List & Expandable Detail Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 flex-1 min-h-0">
        {/* News Stream Cards */}
        <div className={`space-y-2.5 overflow-y-auto custom-scrollbar pr-1 ${selectedArticle ? 'lg:col-span-6' : 'lg:col-span-12'}`}>
          {filteredNews.length === 0 ? (
            <div className="bg-[#15102a] border border-[#2d2150] rounded-2xl p-8 text-center text-slate-400">
              <Newspaper className="w-10 h-10 mx-auto mb-2 opacity-50 text-purple-400" />
              <p className="font-bold">
                {isTr ? 'Henüz güncel haber bulunmuyor.' : isDe ? 'Keine aktuellen Nachrichten gefunden.' : isEs ? 'No hay noticias recientes.' : isFr ? 'Aucune actualité disponible.' : isIt ? 'Nessuna notizia recente.' : isPt ? 'Nenhuma notícia recente.' : 'No news found.'}
              </p>
            </div>
          ) : (
            filteredNews.map(item => (
              <div
                key={item.id}
                onClick={() => setSelectedArticle(item)}
                className={`bg-[#171133] hover:bg-[#1f1742] border rounded-2xl p-3.5 transition-all cursor-pointer shadow group ${
                  selectedArticle?.id === item.id
                    ? 'border-purple-500 bg-[#22194a] ring-1 ring-purple-400'
                    : 'border-[#2d2150] hover:border-purple-500/50'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`px-2.5 py-0.5 rounded-full text-[9.5px] font-black border uppercase tracking-wide ${item.badgeColor}`}>
                    {item.badgeTag}
                  </span>
                  <span className="text-[10px] font-bold text-slate-400">
                    {item.timestamp}
                  </span>
                </div>

                <h3 className="font-black text-sm text-white group-hover:text-purple-200 transition-colors line-clamp-2 mb-1.5">
                  {item.title}
                </h3>

                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed font-medium">
                  {item.summary}
                </p>

                {item.matchData && (
                  <div className="mt-2.5 pt-2 border-t border-[#291e4b] flex items-center justify-between text-[11px] font-extrabold text-amber-300">
                    <span>{item.matchData.homeTeam} vs {item.matchData.awayTeam}</span>
                    {item.matchData.played && (
                      <span className="bg-purple-950 px-2 py-0.5 rounded border border-purple-500/40 text-purple-200">
                        {item.matchData.homeScore} - {item.matchData.awayScore}
                      </span>
                    )}
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Right Column: Full Article Reader Panel */}
        {selectedArticle && (
          <div className="lg:col-span-6 bg-[#171133] border border-purple-500/50 rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-2xl overflow-y-auto custom-scrollbar animate-in fade-in duration-200">
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-[#2d2150] pb-2.5">
                <span className={`px-3 py-1 rounded-full text-[10px] font-black border uppercase ${selectedArticle.badgeColor}`}>
                  {selectedArticle.badgeTag}
                </span>
                <button
                  onClick={() => setSelectedArticle(null)}
                  className="w-7 h-7 rounded-lg bg-[#231a44] text-slate-400 hover:text-white flex items-center justify-center cursor-pointer text-xs font-black"
                >
                  ✕
                </button>
              </div>

              <h2 className="text-base sm:text-lg font-black text-white leading-snug">
                {selectedArticle.title}
              </h2>

              <div className="flex items-center gap-2 text-[10.5px] text-slate-400 font-bold">
                <span>{selectedArticle.timestamp}</span>
                <span>•</span>
                <span className="text-purple-300">
                  {isTr ? 'Süper Lig Medya Masası' : isDe ? 'Süper Lig Medienzentrum' : isEs ? 'Mesa de Medios de la Süper Lig' : isFr ? 'Bureau des Médias Süper Lig' : isIt ? 'Redazione Media Süper Lig' : isPt ? 'Gabinete de Imprensa da Süper Lig' : 'Super Lig Media Desk'}
                </span>
              </div>

              {selectedArticle.matchData && selectedArticle.matchData.played && (
                <div className="bg-[#110c26] p-3 rounded-xl border border-[#2d2150] text-center my-2">
                  <span className="text-[10px] font-black text-slate-400 block mb-1 uppercase tracking-wider">
                    {isTr ? 'MAÇ SKORU' : isDe ? 'SPIELERGEBNIS' : isEs ? 'RESULTADO' : isFr ? 'SCORE DU MATCH' : isIt ? 'RISULTATO FINALE' : isPt ? 'RESULTADO FINAL' : 'MATCH SCORE'}
                  </span>
                  <div className="flex items-center justify-center gap-4 text-sm font-black text-white">
                    <span className="text-right flex-1">{selectedArticle.matchData.homeTeam}</span>
                    <span className="px-3 py-1 bg-purple-900 border border-purple-400 text-amber-300 rounded-lg text-base">
                      {selectedArticle.matchData.homeScore} - {selectedArticle.matchData.awayScore}
                    </span>
                    <span className="text-left flex-1">{selectedArticle.matchData.awayTeam}</span>
                  </div>
                </div>
              )}

              {selectedArticle.playerData && (
                <div className="bg-[#110c26] p-2.5 rounded-xl border border-[#2d2150] flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-purple-900 text-purple-200 font-black flex items-center justify-center text-xs">
                      {selectedArticle.playerData.position || 'OY'}
                    </div>
                    <div>
                      <span className="font-black text-white block">{selectedArticle.playerData.name}</span>
                      <span className="text-[10px] text-slate-400 font-bold">
                        {selectedArticle.playerData.age} {isTr ? 'Yaş' : isDe ? 'Jahre' : isEs ? 'Años' : isFr ? 'Ans' : isIt ? 'Anni' : isPt ? 'Anos' : 'Y/O'} • {selectedArticle.playerData.position}
                      </span>
                    </div>
                  </div>
                  <span className="font-black text-amber-300 text-sm">{selectedArticle.playerData.overall} OVR</span>
                </div>
              )}

              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-normal pt-2 whitespace-pre-line">
                {selectedArticle.fullContent || selectedArticle.summary}
              </p>
            </div>

            <div className="pt-4 border-t border-[#291e4b] flex justify-end">
              <button
                onClick={() => setSelectedArticle(null)}
                className="px-4 py-1.5 rounded-xl bg-[#251b47] hover:bg-[#2e2257] text-white font-black text-xs cursor-pointer"
              >
                {isTr ? 'Kapat' : isDe ? 'Schließen' : isEs ? 'Cerrar' : isFr ? 'Fermer' : isIt ? 'Chiudi' : isPt ? 'Fechar' : 'Close'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
