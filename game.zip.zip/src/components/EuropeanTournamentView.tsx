import React, { useState } from 'react';
import { 
  UEFA_COMPETITIONS, 
  UCL_TEAMS, 
  UEL_TEAMS, 
  UECL_TEAMS, 
  EuropeanTournamentConfig, 
  EuropeanTournamentTeam,
  EuropeanKnockoutMatch
} from '../data/europeanCompetitions';
import { Trophy, Shield, Award, DollarSign, ChevronRight, CheckCircle, Flame, Star } from 'lucide-react';
import { TeamBadge } from './TeamBadge';

interface EuropeanTournamentViewProps {
  currentWeek?: number;
  userTeamId?: string;
  onSelectTeam?: (team: EuropeanTournamentTeam) => void;
  initialCompId?: 'ucl' | 'uel' | 'uecl';
  onCompChange?: (compId: 'ucl' | 'uel' | 'uecl') => void;
}

export const EuropeanTournamentView: React.FC<EuropeanTournamentViewProps> = ({
  currentWeek = 1,
  userTeamId,
  onSelectTeam,
  initialCompId = 'ucl',
  onCompChange
}) => {
  const [selectedCompId, setSelectedCompId] = useState<'ucl' | 'uel' | 'uecl'>(initialCompId);
  const [subTab, setSubTab] = useState<'LEAGUE_PHASE' | 'KNOCKOUT' | 'PRIZES' | 'SCORERS'>('LEAGUE_PHASE');

  React.useEffect(() => {
    if (initialCompId) {
      setSelectedCompId(initialCompId);
    }
  }, [initialCompId]);

  const handleSelectComp = (compId: 'ucl' | 'uel' | 'uecl') => {
    setSelectedCompId(compId);
    if (onCompChange) {
      onCompChange(compId);
    }
  };

  const activeComp: EuropeanTournamentConfig = UEFA_COMPETITIONS.find(c => c.id === selectedCompId) || UEFA_COMPETITIONS[0];

  const getCompTeams = (id: 'ucl' | 'uel' | 'uecl'): EuropeanTournamentTeam[] => {
    if (id === 'ucl') return UCL_TEAMS;
    if (id === 'uel') return UEL_TEAMS;
    return UECL_TEAMS;
  };

  const compTeams = getCompTeams(selectedCompId);

  // Generate simulated 36-team standings based on team overall ratings and currentWeek
  const simulatedStandings = React.useMemo(() => {
    const totalMatchdays = selectedCompId === 'uecl' ? 6 : 8;
    const played = Math.min(totalMatchdays, Math.max(0, Math.floor(currentWeek / 4)));

    if (played === 0) {
      return compTeams.map(team => ({
        ...team,
        played: 0,
        won: 0,
        drawn: 0,
        lost: 0,
        goalsFor: 0,
        goalsAgainst: 0,
        goalDiff: 0,
        points: 0,
        form: []
      }));
    }

    return compTeams.map((team, idx) => {
      // High overall gives higher win chance
      const basePower = (team.overall - 68) / 24; // 0 to 1
      const won = Math.min(played, Math.max(0, Math.round(played * (basePower * 0.75 + (0.15 - (idx % 5) * 0.03)))));
      const drawn = Math.min(played - won, Math.max(0, Math.floor((played - won) * 0.45)));
      const lost = Math.max(0, played - won - drawn);
      const points = won * 3 + drawn;
      const goalsFor = Math.round(won * 2.2 + drawn * 1.0 + lost * 0.5 + (team.overall > 85 ? 3 : 0));
      const goalsAgainst = Math.round(lost * 2.0 + drawn * 1.0 + won * 0.6);
      const goalDiff = goalsFor - goalsAgainst;

      return {
        ...team,
        played,
        won,
        drawn,
        lost,
        goalsFor,
        goalsAgainst,
        goalDiff,
        points,
        form: ['W', 'W', 'D', 'W', 'L'].slice(0, Math.min(5, played))
      };
    }).sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      if (b.goalDiff !== a.goalDiff) return b.goalDiff - a.goalDiff;
      return b.goalsFor - a.goalsFor;
    });
  }, [compTeams, currentWeek, selectedCompId]);

  // Generate Knockout matches (Son 16, Çeyrek Final, Yarı Final, Final)
  const knockoutMatches: EuropeanKnockoutMatch[] = React.useMemo(() => {
    const top16 = simulatedStandings.slice(0, 16);
    const rounds: EuropeanKnockoutMatch[] = [];

    // Round of 16 (8 pairs)
    for (let i = 0; i < 8; i++) {
      const home = top16[i];
      const away = top16[15 - i] || top16[i + 1];
      const homeWins = (home.overall + Math.sin(i * 3)) >= (away.overall);
      const leg1Home = homeWins ? 2 : 1;
      const leg1Away = homeWins ? 1 : 2;
      const leg2Home = homeWins ? 2 : 0;
      const leg2Away = homeWins ? 0 : 2;
      const aggHome = leg1Home + leg2Home;
      const aggAway = leg1Away + leg2Away;

      rounds.push({
        id: `r16-${i}`,
        round: 'ROUND_OF_16',
        roundName: 'Son 16 Turu',
        homeTeam: home,
        awayTeam: away,
        leg1Score: { home: leg1Home, away: leg1Away },
        leg2Score: { home: leg2Home, away: leg2Away },
        aggregateHome: aggHome,
        aggregateAway: aggAway,
        winnerTeamId: aggHome >= aggAway ? home.id : away.id,
        isCompleted: currentWeek >= 20
      });
    }

    // Quarter finals (4 pairs)
    const qfTeams = simulatedStandings.slice(0, 8);
    for (let i = 0; i < 4; i++) {
      const home = qfTeams[i * 2];
      const away = qfTeams[i * 2 + 1] || qfTeams[0];
      rounds.push({
        id: `qf-${i}`,
        round: 'QUARTER_FINAL',
        roundName: 'Çeyrek Final',
        homeTeam: home,
        awayTeam: away,
        leg1Score: { home: 2, away: 1 },
        leg2Score: { home: 1, away: 1 },
        aggregateHome: 3,
        aggregateAway: 2,
        winnerTeamId: home.id,
        isCompleted: currentWeek >= 28
      });
    }

    // Semi finals (2 pairs)
    const sfTeams = simulatedStandings.slice(0, 4);
    for (let i = 0; i < 2; i++) {
      const home = sfTeams[i * 2];
      const away = sfTeams[i * 2 + 1] || sfTeams[0];
      rounds.push({
        id: `sf-${i}`,
        round: 'SEMI_FINAL',
        roundName: 'Yarı Final',
        homeTeam: home,
        awayTeam: away,
        leg1Score: { home: 2, away: 2 },
        leg2Score: { home: 3, away: 1 },
        aggregateHome: 5,
        aggregateAway: 3,
        winnerTeamId: home.id,
        isCompleted: currentWeek >= 34
      });
    }

    // Final
    rounds.push({
      id: `final-1`,
      round: 'FINAL',
      roundName: '🏆 Büyük Final',
      homeTeam: simulatedStandings[0],
      awayTeam: simulatedStandings[1],
      leg1Score: { home: 2, away: 1 },
      aggregateHome: 2,
      aggregateAway: 1,
      winnerTeamId: simulatedStandings[0].id,
      isCompleted: currentWeek >= 38
    });

    return rounds;
  }, [simulatedStandings, currentWeek]);

  // European Top Scorers List
  const playedEuropeanWeeks = Math.min(8, Math.max(0, Math.floor(currentWeek / 4)));
  const topEuropeanScorers = React.useMemo(() => {
    if (playedEuropeanWeeks === 0) return [];
    const scale = playedEuropeanWeeks / 8;
    return [
      { name: 'Kylian Mbappé', team: 'Real Madrid', goals: Math.max(1, Math.round(9 * scale)), assists: Math.round(3 * scale), matches: playedEuropeanWeeks, flag: '🇫🇷' },
      { name: 'Erling Haaland', team: 'Manchester City', goals: Math.max(1, Math.round(8 * scale)), assists: Math.round(1 * scale), matches: playedEuropeanWeeks, flag: '🇳🇴' },
      { name: 'Harry Kane', team: 'Bayern München', goals: Math.max(1, Math.round(8 * scale)), assists: Math.round(2 * scale), matches: playedEuropeanWeeks, flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿' },
      { name: 'Viktor Gyökeres', team: 'Sporting CP', goals: Math.max(1, Math.round(7 * scale)), assists: Math.round(2 * scale), matches: playedEuropeanWeeks, flag: '🇸🇪' },
      { name: 'Vinícius Júnior', team: 'Real Madrid', goals: Math.max(1, Math.round(6 * scale)), assists: Math.round(5 * scale), matches: playedEuropeanWeeks, flag: '🇧🇷' },
      { name: 'Robert Lewandowski', team: 'FC Barcelona', goals: Math.max(1, Math.round(6 * scale)), assists: Math.round(1 * scale), matches: playedEuropeanWeeks, flag: '🇵🇱' },
      { name: 'Raphinha', team: 'FC Barcelona', goals: Math.max(1, Math.round(5 * scale)), assists: Math.round(4 * scale), matches: playedEuropeanWeeks, flag: '🇧🇷' },
      { name: 'Mauro Icardi', team: 'Galatasaray SK', goals: Math.max(1, Math.round(5 * scale)), assists: Math.round(2 * scale), matches: playedEuropeanWeeks, flag: '🇦🇷' },
      { name: 'Bradley Barcola', team: 'Paris Saint-Germain', goals: Math.max(1, Math.round(4 * scale)), assists: Math.round(3 * scale), matches: playedEuropeanWeeks, flag: '🇫🇷' },
      { name: 'Florian Wirtz', team: 'Bayer Leverkusen', goals: Math.max(1, Math.round(4 * scale)), assists: Math.round(4 * scale), matches: playedEuropeanWeeks, flag: '🇩🇪' },
    ];
  }, [playedEuropeanWeeks]);

  return (
    <div className="flex flex-col h-full space-y-3 overflow-hidden">
      {/* UEFA TOURNAMENTS SELECTOR BAR */}
      <div className="grid grid-cols-3 gap-2 shrink-0">
        {UEFA_COMPETITIONS.map((comp) => {
          const isSelected = selectedCompId === comp.id;
          return (
            <button
              key={comp.id}
              onClick={() => handleSelectComp(comp.id)}
              className={`relative overflow-hidden p-2.5 sm:p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between text-left ${
                isSelected
                  ? `border-[${comp.accentColor}] bg-gradient-to-r ${comp.themeColor} shadow-lg ring-2 ring-[${comp.accentColor}]/40`
                  : 'bg-[#151128] border-[#2d244c] hover:border-slate-600 opacity-75 hover:opacity-100'
              }`}
              style={{
                borderColor: isSelected ? comp.accentColor : undefined
              }}
            >
              <div className="flex items-center gap-2.5">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg border font-black shadow ${comp.badgeBg}`}>
                  {comp.badge}
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-black text-white leading-tight">
                    {comp.name}
                  </h4>
                  <p className="text-[10px] text-slate-400 font-semibold truncate max-w-[140px] sm:max-w-none">
                    {comp.fullName}
                  </p>
                </div>
              </div>
              <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider hidden sm:inline-block ${
                isSelected ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400'
              }`}>
                36 Takım
              </span>
            </button>
          );
        })}
      </div>

      {/* SUB-TABS NAVIGATION */}
      <div className="flex items-center justify-between bg-[#130f24] p-1.5 rounded-xl border border-[#2d244c] shrink-0 gap-1 overflow-x-auto custom-scrollbar">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setSubTab('LEAGUE_PHASE')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              subTab === 'LEAGUE_PHASE'
                ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/40'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            Lig Aşaması Puan Durumu (36 Takım)
          </button>

          <button
            onClick={() => setSubTab('KNOCKOUT')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              subTab === 'KNOCKOUT'
                ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/40'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            Eleme Aşaması & Eşleşmeler
          </button>

          <button
            onClick={() => setSubTab('SCORERS')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              subTab === 'SCORERS'
                ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/40'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-orange-400" />
            Gol & Asist Krallığı
          </button>

          <button
            onClick={() => setSubTab('PRIZES')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              subTab === 'PRIZES'
                ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/40'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            Ödül Havuzu & Format Kuralları
          </button>
        </div>

        <div className="text-[11px] font-bold text-slate-400 hidden md:flex items-center gap-2 pr-2">
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span> 1-8: Son 16</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block"></span> 9-24: Play-off</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-red-500/80 inline-block"></span> 25-36: Elendi</span>
        </div>
      </div>

      {/* CONTENT AREA */}
      <div className="flex-1 min-h-0 bg-[#161228] border border-[#2d244c] rounded-2xl overflow-hidden flex flex-col">
        {/* TAB 1: 36-TEAM LEAGUE PHASE STANDINGS */}
        {subTab === 'LEAGUE_PHASE' && (
          <div className="flex-1 overflow-y-auto custom-scrollbar p-2 sm:p-3">
            <div className="w-full overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-[#2d244c] text-slate-400 font-extrabold uppercase text-[10px] tracking-wider">
                    <th className="py-2.5 px-3 w-12 text-center">Sıra</th>
                    <th className="py-2.5 px-3">Kulüp</th>
                    <th className="py-2.5 px-2 text-center">Ülke</th>
                    <th className="py-2.5 px-2 text-center">Güç</th>
                    <th className="py-2.5 px-2 text-center">O</th>
                    <th className="py-2.5 px-2 text-center">G</th>
                    <th className="py-2.5 px-2 text-center">B</th>
                    <th className="py-2.5 px-2 text-center">M</th>
                    <th className="py-2.5 px-2 text-center">AG</th>
                    <th className="py-2.5 px-2 text-center">YG</th>
                    <th className="py-2.5 px-2 text-center">AV</th>
                    <th className="py-2.5 px-3 text-center font-black text-amber-400">Puan</th>
                    <th className="py-2.5 px-3 text-center">Durum</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#221c3b]">
                  {simulatedStandings.map((row, index) => {
                    const rank = index + 1;
                    const isDirectR16 = rank <= 8;
                    const isPlayoff = rank > 8 && rank <= 24;
                    const isEliminated = rank > 24;
                    const isUser = row.id === userTeamId;

                    return (
                      <tr
                        key={row.id}
                        onClick={() => onSelectTeam && onSelectTeam(row)}
                        className={`transition-colors cursor-pointer hover:bg-[#20183b] ${
                          isUser ? 'bg-purple-950/60 font-black ring-1 ring-purple-500/50' : ''
                        }`}
                      >
                        {/* RANK */}
                        <td className="py-2 px-3 text-center font-black">
                          <div className="flex items-center justify-center">
                            <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-black shadow-sm ${
                              isDirectR16 
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
                                : isPlayoff 
                                ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40' 
                                : 'bg-red-500/10 text-slate-400 border border-red-500/20'
                            }`}>
                              {rank}
                            </span>
                          </div>
                        </td>

                        {/* CLUB NAME & BADGE */}
                        <td className="py-2 px-3">
                          <div className="flex items-center gap-2">
                            <TeamBadge team={{ name: row.name, id: row.id, badgeColor: row.badgeColor, shortName: row.shortName, logoUrl: (row as any).logoUrl }} size="sm" />
                            <span className="font-extrabold text-white text-xs sm:text-sm">
                              {row.name}
                            </span>
                            {isUser && (
                              <span className="bg-amber-400 text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded-full ml-1">
                                SENİN TAKIMIN
                              </span>
                            )}
                          </div>
                        </td>

                        {/* COUNTRY */}
                        <td className="py-2 px-2 text-center text-sm">
                          {row.flag}
                        </td>

                        {/* OVERALL */}
                        <td className="py-2 px-2 text-center">
                          <span className={`text-[10px] font-black px-1.5 py-0.5 rounded ${
                            row.overall >= 86 ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                            row.overall >= 82 ? 'bg-purple-500/20 text-purple-300' :
                            'bg-slate-800 text-slate-300'
                          }`}>
                            {row.overall}
                          </span>
                        </td>

                        {/* STATS */}
                        <td className="py-2 px-2 text-center text-slate-300 font-semibold">{row.played}</td>
                        <td className="py-2 px-2 text-center text-emerald-400 font-bold">{row.won}</td>
                        <td className="py-2 px-2 text-center text-amber-400 font-medium">{row.drawn}</td>
                        <td className="py-2 px-2 text-center text-red-400 font-medium">{row.lost}</td>
                        <td className="py-2 px-2 text-center text-slate-300">{row.goalsFor}</td>
                        <td className="py-2 px-2 text-center text-slate-400">{row.goalsAgainst}</td>
                        <td className={`py-2 px-2 text-center font-bold ${row.goalDiff > 0 ? 'text-emerald-400' : row.goalDiff < 0 ? 'text-red-400' : 'text-slate-400'}`}>
                          {row.goalDiff > 0 ? `+${row.goalDiff}` : row.goalDiff}
                        </td>

                        {/* POINTS */}
                        <td className="py-2 px-3 text-center font-black text-sm text-amber-300">
                          {row.points}
                        </td>

                        {/* STATUS BADGE */}
                        <td className="py-2 px-3 text-center">
                          {isDirectR16 ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/40">
                              <Star className="w-2.5 h-2.5 fill-emerald-400 text-emerald-400" /> Son 16
                            </span>
                          ) : isPlayoff ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-black px-2 py-0.5 rounded-full bg-blue-950/80 text-blue-300 border border-blue-500/40">
                              Play-off
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full bg-red-950/40 text-red-400/80">
                              Elendi
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: KNOCKOUT STAGE BRACKET & MATCHUPS */}
        {subTab === 'KNOCKOUT' && (
          <div className="flex-1 overflow-y-auto custom-scrollbar p-3 sm:p-4 space-y-4">
            <div className="bg-[#1a1433] p-3 rounded-xl border border-[#372b5c] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-400" />
                <div>
                  <h4 className="text-sm font-black text-white">{activeComp.fullName} Eleme Turları</h4>
                  <p className="text-[11px] text-slate-400">Çift maçlı eleme sistemi (Deplasman golü kuralı kaldırılmıştır).</p>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-black">
                Hafta {currentWeek} / 38
              </span>
            </div>

            {/* KNOCKOUT ROUNDS DISPLAY */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              {/* SON 16 */}
              <div className="space-y-2">
                <div className="flex items-center justify-between pb-1 border-b border-[#2d244c]">
                  <span className="text-xs font-black text-emerald-400 uppercase tracking-wider">Son 16 Turu</span>
                  <span className="text-[10px] text-slate-400">8 Eşleşme</span>
                </div>
                <div className="space-y-2 max-h-[460px] overflow-y-auto custom-scrollbar pr-1">
                  {knockoutMatches.filter(m => m.round === 'ROUND_OF_16').map((match) => (
                    <div key={match.id} className="bg-[#120e24] p-2.5 rounded-xl border border-[#2b2247] space-y-1.5 hover:border-purple-500/50 transition-all">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5 font-bold text-white truncate max-w-[130px]">
                          <span>{match.homeTeam.flag}</span>
                          <span className="truncate">{match.homeTeam.name}</span>
                        </div>
                        <span className="font-black text-amber-400 bg-slate-900 px-1.5 py-0.5 rounded text-[11px]">
                          {match.aggregateHome}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5 font-bold text-white truncate max-w-[130px]">
                          <span>{match.awayTeam.flag}</span>
                          <span className="truncate">{match.awayTeam.name}</span>
                        </div>
                        <span className="font-black text-amber-400 bg-slate-900 px-1.5 py-0.5 rounded text-[11px]">
                          {match.aggregateAway}
                        </span>
                      </div>
                      <div className="pt-1 border-t border-[#221c3b] flex items-center justify-between text-[9px] text-slate-400">
                        <span>1. Maç: {match.leg1Score?.home}-{match.leg1Score?.away}</span>
                        <span>2. Maç: {match.leg2Score?.home}-{match.leg2Score?.away}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* ÇEYREK FİNAL */}
              <div className="space-y-2">
                <div className="flex items-center justify-between pb-1 border-b border-[#2d244c]">
                  <span className="text-xs font-black text-blue-400 uppercase tracking-wider">Çeyrek Final</span>
                  <span className="text-[10px] text-slate-400">4 Eşleşme</span>
                </div>
                <div className="space-y-2">
                  {knockoutMatches.filter(m => m.round === 'QUARTER_FINAL').map((match) => (
                    <div key={match.id} className="bg-[#120e24] p-2.5 rounded-xl border border-[#2b2247] space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5 font-bold text-white truncate max-w-[130px]">
                          <span>{match.homeTeam.flag}</span>
                          <span className="truncate">{match.homeTeam.name}</span>
                        </div>
                        <span className="font-black text-amber-400 bg-slate-900 px-1.5 py-0.5 rounded text-[11px]">
                          {match.aggregateHome}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5 font-bold text-white truncate max-w-[130px]">
                          <span>{match.awayTeam.flag}</span>
                          <span className="truncate">{match.awayTeam.name}</span>
                        </div>
                        <span className="font-black text-amber-400 bg-slate-900 px-1.5 py-0.5 rounded text-[11px]">
                          {match.aggregateAway}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* YARI FİNAL */}
              <div className="space-y-2">
                <div className="flex items-center justify-between pb-1 border-b border-[#2d244c]">
                  <span className="text-xs font-black text-purple-400 uppercase tracking-wider">Yarı Final</span>
                  <span className="text-[10px] text-slate-400">2 Eşleşme</span>
                </div>
                <div className="space-y-2">
                  {knockoutMatches.filter(m => m.round === 'SEMI_FINAL').map((match) => (
                    <div key={match.id} className="bg-[#120e24] p-2.5 rounded-xl border border-[#2b2247] space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5 font-bold text-white truncate max-w-[130px]">
                          <span>{match.homeTeam.flag}</span>
                          <span className="truncate">{match.homeTeam.name}</span>
                        </div>
                        <span className="font-black text-amber-400 bg-slate-900 px-1.5 py-0.5 rounded text-[11px]">
                          {match.aggregateHome}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5 font-bold text-white truncate max-w-[130px]">
                          <span>{match.awayTeam.flag}</span>
                          <span className="truncate">{match.awayTeam.name}</span>
                        </div>
                        <span className="font-black text-amber-400 bg-slate-900 px-1.5 py-0.5 rounded text-[11px]">
                          {match.aggregateAway}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* BÜYÜK FİNAL */}
              <div className="space-y-2">
                <div className="flex items-center justify-between pb-1 border-b border-[#2d244c]">
                  <span className="text-xs font-black text-amber-400 uppercase tracking-wider flex items-center gap-1">
                    <Trophy className="w-3.5 h-3.5" /> Büyük Final
                  </span>
                  <span className="text-[10px] text-amber-300 font-bold">Kupa Maçı</span>
                </div>
                {knockoutMatches.filter(m => m.round === 'FINAL').map((match) => (
                  <div key={match.id} className="bg-gradient-to-b from-[#241a4a] to-[#140e2b] p-3.5 rounded-2xl border-2 border-amber-500/40 shadow-xl space-y-3">
                    <div className="text-center">
                      <span className="text-[10px] uppercase font-black text-amber-300 tracking-wider">
                        UEFA Şampiyonluk Karşılaşması
                      </span>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-2 rounded-xl bg-[#120e24]/80 border border-amber-500/20">
                        <div className="flex items-center gap-2">
                          <span className="text-base">{match.homeTeam.flag}</span>
                          <span className="font-black text-white text-xs">{match.homeTeam.name}</span>
                        </div>
                        <span className="text-base font-black text-amber-300">{match.aggregateHome}</span>
                      </div>

                      <div className="flex items-center justify-between p-2 rounded-xl bg-[#120e24]/80 border border-amber-500/20">
                        <div className="flex items-center gap-2">
                          <span className="text-base">{match.awayTeam.flag}</span>
                          <span className="font-black text-white text-xs">{match.awayTeam.name}</span>
                        </div>
                        <span className="text-base font-black text-amber-300">{match.aggregateAway}</span>
                      </div>
                    </div>

                    <div className="bg-amber-500/10 border border-amber-500/30 p-2 rounded-xl text-center">
                      <p className="text-[11px] font-black text-amber-300">
                        🏆 Şampiyonluk Ödülü: +€{(activeComp.prizeMoney.champion / 1000000).toFixed(1)}M
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: SCORERS & STATS */}
        {subTab === 'SCORERS' && (
          <div className="flex-1 overflow-y-auto custom-scrollbar p-3 sm:p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* TOP SCORERS */}
              <div className="bg-[#120e24] p-3 rounded-xl border border-[#2d244c] space-y-2">
                <div className="flex items-center justify-between pb-2 border-b border-[#2d244c]">
                  <span className="font-black text-white text-xs sm:text-sm flex items-center gap-1.5">
                    <Flame className="w-4 h-4 text-orange-400" /> Gol Krallığı
                  </span>
                  <span className="text-[10px] text-slate-400">Avrupa Kupaları</span>
                </div>
                <div className="divide-y divide-[#221c3b]">
                  {topEuropeanScorers.map((player, idx) => (
                    <div key={idx} className="py-2 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2.5">
                        <span className="w-5 font-black text-slate-500 text-center">{idx + 1}</span>
                        <span>{player.flag}</span>
                        <div>
                          <p className="font-bold text-white">{player.name}</p>
                          <p className="text-[10px] text-slate-400">{player.team}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-black text-amber-400 text-sm">{player.goals} Gol</span>
                        <p className="text-[10px] text-slate-400">{player.matches} Maç</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* TOP ASSISTS */}
              <div className="bg-[#120e24] p-3 rounded-xl border border-[#2d244c] space-y-2">
                <div className="flex items-center justify-between pb-2 border-b border-[#2d244c]">
                  <span className="font-black text-white text-xs sm:text-sm flex items-center gap-1.5">
                    <Award className="w-4 h-4 text-purple-400" /> Asist Krallığı
                  </span>
                  <span className="text-[10px] text-slate-400">Avrupa Kupaları</span>
                </div>
                <div className="divide-y divide-[#221c3b]">
                  {[...topEuropeanScorers].sort((a, b) => b.assists - a.assists).map((player, idx) => (
                    <div key={idx} className="py-2 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2.5">
                        <span className="w-5 font-black text-slate-500 text-center">{idx + 1}</span>
                        <span>{player.flag}</span>
                        <div>
                          <p className="font-bold text-white">{player.name}</p>
                          <p className="text-[10px] text-slate-400">{player.team}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-black text-purple-400 text-sm">{player.assists} Asist</span>
                        <p className="text-[10px] text-slate-400">{player.matches} Maç</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: PRIZES & RULES */}
        {subTab === 'PRIZES' && (
          <div className="flex-1 overflow-y-auto custom-scrollbar p-3 sm:p-4 space-y-4">
            <div className="bg-gradient-to-r from-[#1b143b] to-[#120e24] p-4 rounded-2xl border border-purple-500/30 shadow-lg space-y-2">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm sm:text-base font-black text-white">{activeComp.fullName} - Resmi UEFA Ödül Havuzu</h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {activeComp.description}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="bg-[#120e24] p-3 rounded-xl border border-[#2d244c] space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400">Lig Aşamasına Katılım</span>
                <p className="text-base font-black text-emerald-400">€{(activeComp.prizeMoney.qualification / 1000000).toFixed(2)}M</p>
                <p className="text-[10px] text-slate-500">Grup / Lig tablosuna kalan kulüplere peşin ödenir.</p>
              </div>

              <div className="bg-[#120e24] p-3 rounded-xl border border-[#2d244c] space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400">Maç Başı Galibiyet</span>
                <p className="text-base font-black text-amber-400">€{(activeComp.prizeMoney.matchWin / 1000000).toFixed(2)}M</p>
                <p className="text-[10px] text-slate-500">Beraberlik ödülü: €{(activeComp.prizeMoney.matchDraw / 1000).toFixed(0)}K</p>
              </div>

              <div className="bg-[#120e24] p-3 rounded-xl border border-[#2d244c] space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400">Son 16 & Çeyrek Final</span>
                <p className="text-base font-black text-blue-400">€{((activeComp.prizeMoney.roundOf16 + activeComp.prizeMoney.quarterFinal) / 1000000).toFixed(2)}M</p>
                <p className="text-[10px] text-slate-500">Tur atladıkça kulüp kasasına aktarılır.</p>
              </div>

              <div className="bg-[#120e24] p-3 rounded-xl border border-amber-500/30 space-y-1 bg-amber-950/10">
                <span className="text-[10px] uppercase font-bold text-amber-400">🏆 Şampiyonluk Primi</span>
                <p className="text-base font-black text-amber-300">€{(activeComp.prizeMoney.champion / 1000000).toFixed(2)}M</p>
                <p className="text-[10px] text-slate-400">Kupayı kaldıran takıma verilen nihai prim.</p>
              </div>
            </div>

            {/* FORMAT RULES EXPLANATION */}
            <div className="bg-[#140f2b] p-3.5 rounded-xl border border-[#2e2350] space-y-2">
              <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> Yeni 36 Takımlı UEFA Sistemi Kuralları
              </h4>
              <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                <li><strong className="text-white">Lig Tablosu:</strong> 36 takım tek bir genel tabloda yarışır. Her takım 8 farklı rakiple (4 iç saha, 4 deplasman) karşılaşır.</li>
                <li><strong className="text-emerald-400">İlk 8 Takım (1 - 8):</strong> Doğrudan Son 16 turuna katılmaya hak kazanır ve eleme turlarında seri başı olurlar.</li>
                <li><strong className="text-blue-400">Play-off Aşaması (9 - 24):</strong> 9. ile 24. sıra arasındaki 16 takım, Son 16 ya kalabilmek için iki ayaklı eleme maçı oynar.</li>
                <li><strong className="text-red-400">Elenenler (25 - 36):</strong> Alt lige veya alt turnuvaya geçiş kaldırılmıştır; doğrudan Avrupa macerası sona erer.</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
