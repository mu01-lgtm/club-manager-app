import React, { useState } from 'react';
import { Player, Team } from '../types';
import { Dumbbell, TrendingUp, ShieldAlert, Sparkles, Activity, HeartPulse, Clock, AlertTriangle, CheckCircle2, User, Stethoscope } from 'lucide-react';
import { PlayerSkillGrowthChart } from './PlayerSkillGrowthChart';
import { CustomSelect, CustomSelectOption } from './CustomSelect';
import { useTranslation } from '../utils/i18n';

interface TrainingCenterProps {
  currentTeam: Team;
  currentWeek?: number;
  onUpdatePlayerTraining?: (playerId: string, focus: string, intensity: string) => void;
  onUpdatePlayerAttributes?: (playerId: string, updates: Partial<Player>) => void;
  onOpenPlayerProfile?: (player: Player) => void;
  onRestoreStaminaAll?: () => void;
  daysSinceLastRestore?: number;
  onShowToast?: (type: 'success' | 'error' | 'info', title: string, message: string) => void;
}

export const TrainingCenter: React.FC<TrainingCenterProps> = ({
  currentTeam,
  currentWeek = 1,
  onUpdatePlayerTraining,
  onUpdatePlayerAttributes,
  onOpenPlayerProfile,
  onShowToast
}) => {
  const { t, language } = useTranslation();
  const isTr = language === 'TR';

  const [activeSubTab, setActiveSubTab] = useState<'TRAINING' | 'GROWTH_CHART' | 'INJURY_REPORT'>('TRAINING');
  const [selectedPlayerId, setSelectedPlayerId] = useState<string>(currentTeam.players[0]?.id || '');
  const [injuryListFilter, setInjuryListFilter] = useState<'ALL' | 'INJURED_ONLY' | 'HIGH_RISK'>('ALL');

  const selectedPlayer = currentTeam.players.find(p => p.id === selectedPlayerId) || currentTeam.players[0];

  // Injured players in the team
  const injuredPlayers = currentTeam.players.filter(p => p.isInjured || (p.injuryWeeksLeft && p.injuryWeeksLeft > 0));

  // High risk players (age >= 30 on heavy training, or low stamina)
  const highRiskPlayers = currentTeam.players.filter(p => 
    !p.isInjured && (
      (p.trainingIntensity === 'Ağır' && p.age >= 29) ||
      (p.stamina < 65)
    )
  );

  // Average Squad Stamina
  const avgSquadStamina = Math.round(
    currentTeam.players.reduce((acc, p) => acc + (p.stamina ?? 100), 0) / Math.max(1, currentTeam.players.length)
  );

  const focusOptions: CustomSelectOption[] = React.useMemo(() => {
    const getFocusLabels = () => {
      if (language === 'TR') {
        return [
          { value: 'Genel', label: 'Genel Gelişim', subLabel: 'Tüm özellikler dengeli gelişir' },
          { value: 'Hücum', label: 'Hücum Antrenmanı', subLabel: 'Şut, bitiricilik ve hız öncelikli' },
          { value: 'Pas', label: 'Pas & Vizyon', subLabel: 'Paslaşma, vizyon ve oyun kurma' },
          { value: 'Defans', label: 'Defans & Markaj', subLabel: 'Savunma, top kapma ve müdahale' },
          { value: 'Fizik', label: 'Fizik & Kondisyon', subLabel: 'Dayanıklılık, güç ve tempo' }
        ];
      }
      if (language === 'DE') {
        return [
          { value: 'Genel', label: 'Allgemeines Training', subLabel: 'Ausgewogene Entwicklung aller Werte' },
          { value: 'Hücum', label: 'Angriffstraining', subLabel: 'Schuss, Abschluss & Tempo' },
          { value: 'Pas', label: 'Passspiel & Übersicht', subLabel: 'Passen, Übersicht & Spielaufbau' },
          { value: 'Defans', label: 'Verteidigung & Zweikampf', subLabel: 'Tackling & Manndeckung' },
          { value: 'Fizik', label: 'Fitness & Physis', subLabel: 'Ausdauer, Kraft & Tempo' }
        ];
      }
      if (language === 'ES') {
        return [
          { value: 'Genel', label: 'Desarrollo General', subLabel: 'Progreso equilibrado de atributos' },
          { value: 'Hücum', label: 'Entrenamiento Ofensivo', subLabel: 'Tiro, definición y ritmo' },
          { value: 'Pas', label: 'Pase y Visión', subLabel: 'Pase corto, visión y creación' },
          { value: 'Defans', label: 'Defensa y Marcaje', subLabel: 'Robo, entradas y colocación' },
          { value: 'Fizik', label: 'Físico y Resistencia', subLabel: 'Fuerza, fondo y aceleración' }
        ];
      }
      if (language === 'FR') {
        return [
          { value: 'Genel', label: 'Entraînement Général', subLabel: 'Progression équilibrée' },
          { value: 'Hücum', label: 'Attaque & Tir', subLabel: 'Finition, puissance & vitesse' },
          { value: 'Pas', label: 'Passe & Création', subLabel: 'Passes, vision de jeu & relance' },
          { value: 'Defans', label: 'Défense & Marquage', subLabel: 'Tacles, interception & placement' },
          { value: 'Fizik', label: 'Physique & Endurance', subLabel: 'Puissance, endurance & duel' }
        ];
      }
      if (language === 'IT') {
        return [
          { value: 'Genel', label: 'Generale', subLabel: 'Crescita bilanciata delle statistiche' },
          { value: 'Hücum', label: 'Attacco & Tiro', subLabel: 'Finalizzazione, tiro e velocità' },
          { value: 'Pas', label: 'Passaggi & Visione', subLabel: 'Passaggi, regia e visione' },
          { value: 'Defans', label: 'Difesa & Marcatura', subLabel: 'Contrasti, intercettazioni e marcatura' },
          { value: 'Fizik', label: 'Fisico & Resistenza', subLabel: 'Resistenza, forza e velocità' }
        ];
      }
      if (language === 'PT') {
        return [
          { value: 'Genel', label: 'Desenvolvimento Geral', subLabel: 'Evolução equilibrada de atributos' },
          { value: 'Hücum', label: 'Treino Ofensivo', subLabel: 'Finalização, remate e velocidade' },
          { value: 'Pas', label: 'Passe e Visão', subLabel: 'Passe curto, visão e criação' },
          { value: 'Defans', label: 'Defesa e Marcação', subLabel: 'Desarmes, marcação e posicionamento' },
          { value: 'Fizik', label: 'Físico e Resistência', subLabel: 'Força, resistência e ritmo' }
        ];
      }
      return [
        { value: 'Genel', label: 'General Growth', subLabel: 'All attributes develop evenly' },
        { value: 'Hücum', label: 'Attacking Drill', subLabel: 'Shooting & finishing priority' },
        { value: 'Pas', label: 'Passing & Vision', subLabel: 'Passing & playmaking priority' },
        { value: 'Defans', label: 'Defending & Tackling', subLabel: 'Tackling & marking priority' },
        { value: 'Fizik', label: 'Physical & Fitness', subLabel: 'Stamina, strength & tempo' }
      ];
    };

    const baseOptions: CustomSelectOption[] = getFocusLabels();

    // Hide "Yeni Pozisyon" (New Position) for Goalkeepers
    if (selectedPlayer && selectedPlayer.position !== 'GK') {
      const newPosLabel = language === 'TR' ? 'Yeni Pozisyon (Mevki Eğitimi)' :
        language === 'DE' ? 'Neue Position (Rollen-Training)' :
        language === 'ES' ? 'Nueva Posición (Entrenamiento de Rol)' :
        language === 'FR' ? 'Nouveau Poste (Entraînement de Rôle)' :
        language === 'IT' ? 'Nuovo Ruolo (Addestramento Posizione)' :
        language === 'PT' ? 'Nova Posição (Treino de Função)' :
        'New Position (Role Training)';
      
      const newPosSub = language === 'TR' ? 'Farklı bir taktiksel role adaptasyon' :
        language === 'DE' ? 'Anpassung an eine neue taktische Rolle' :
        language === 'ES' ? 'Adaptación a una nueva función táctica' :
        language === 'FR' ? 'Adaptation à un nouveau rôle tactique' :
        language === 'IT' ? 'Adattamento a un nuovo ruolo tattico' :
        language === 'PT' ? 'Adaptação a uma nova função tática' :
        'Adapt to a new tactical role';

      baseOptions.push({
        value: 'Yeni Pozisyon',
        label: newPosLabel,
        subLabel: newPosSub
      });
    }

    return baseOptions;
  }, [language, selectedPlayer]);

  const intensityOptions: CustomSelectOption[] = React.useMemo(() => {
    if (language === 'TR') {
      return [
        { value: 'Hafif', label: 'Hafif Yük', subLabel: 'Minimum sakatlık riski, sakin gelişim' },
        { value: 'Normal', label: 'Normal Tempo', subLabel: 'Dengeli çalışma temposu ve olağan risk' },
        { value: 'Ağır', label: 'Ağır Antrenman', subLabel: '+%30 Hızlı gelişim (Yaşlılarda sakatlık riski!)' }
      ];
    }
    if (language === 'DE') {
      return [
        { value: 'Hafif', label: 'Leichte Belastung', subLabel: 'Minimales Verletzungsrisiko' },
        { value: 'Normal', label: 'Normales Tempo', subLabel: 'Ausgewogene Trainingsbelastung' },
        { value: 'Ağır', label: 'Schwere Belastung', subLabel: '+30% Schnelleres Wachstum (Höheres Risiko!)' }
      ];
    }
    if (language === 'ES') {
      return [
        { value: 'Hafif', label: 'Carga Ligera', subLabel: 'Mínimo riesgo de lesión' },
        { value: 'Normal', label: 'Carga Normal', subLabel: 'Ritmo equilibrado y riesgo estándar' },
        { value: 'Ağır', label: 'Carga Pesada', subLabel: '+30% Desarrollo rápido (¡Riesgo elevado en veteranos!)' }
      ];
    }
    if (language === 'FR') {
      return [
        { value: 'Hafif', label: 'Charge Légère', subLabel: 'Risque de blessure minimal' },
        { value: 'Normal', label: 'Charge Normale', subLabel: 'Rythme équilibré et risque modéré' },
        { value: 'Ağır', label: 'Charge Lourde', subLabel: '+30% Progression rapide (Attention aux vétérans !)' }
      ];
    }
    if (language === 'IT') {
      return [
        { value: 'Hafif', label: 'Carico Leggero', subLabel: 'Rischio infortuni minimo' },
        { value: 'Normal', label: 'Carico Normale', subLabel: 'Ritmo equilibrato e rischio standard' },
        { value: 'Ağır', label: 'Carico Intenso', subLabel: '+30% Crescita rapida (Rischio per i veterani!)' }
      ];
    }
    if (language === 'PT') {
      return [
        { value: 'Hafif', label: 'Carga Leve', subLabel: 'Risco mínimo de lesão' },
        { value: 'Normal', label: 'Carga Normal', subLabel: 'Ritmo equilibrado e risco moderado' },
        { value: 'Ağır', label: 'Carga Pesada', subLabel: '+30% Evolução rápida (Atenção aos veteranos!)' }
      ];
    }
    return [
      { value: 'Hafif', label: 'Light Load', subLabel: 'Minimal injury risk, safe training' },
      { value: 'Normal', label: 'Normal Load', subLabel: 'Standard tempo and balanced risk' },
      { value: 'Ağır', label: 'Heavy Load', subLabel: '+30% fast growth (Higher injury risk for older players)' }
    ];
  }, [language]);

  const getFocusShortTranslated = (focusVal?: string) => {
    switch (focusVal) {
      case 'Hücum':
        return language === 'TR' ? 'Hücum' : language === 'DE' ? 'Angriff' : language === 'ES' ? 'Ataque' : language === 'FR' ? 'Attaque' : language === 'IT' ? 'Attacco' : language === 'PT' ? 'Ataque' : 'Attacking';
      case 'Pas':
        return language === 'TR' ? 'Pas' : language === 'DE' ? 'Passspiel' : language === 'ES' ? 'Pase' : language === 'FR' ? 'Passe' : language === 'IT' ? 'Passaggi' : language === 'PT' ? 'Passe' : 'Passing';
      case 'Defans':
        return language === 'TR' ? 'Defans' : language === 'DE' ? 'Abwehr' : language === 'ES' ? 'Defensa' : language === 'FR' ? 'Défense' : language === 'IT' ? 'Difesa' : language === 'PT' ? 'Defesa' : 'Defending';
      case 'Fizik':
        return language === 'TR' ? 'Fizik' : language === 'DE' ? 'Physis' : language === 'ES' ? 'Físico' : language === 'FR' ? 'Physique' : language === 'IT' ? 'Fisico' : language === 'PT' ? 'Físico' : 'Physical';
      case 'Yeni Pozisyon':
        return language === 'TR' ? 'Yeni Pozisyon' : language === 'DE' ? 'Neue Position' : language === 'ES' ? 'Nueva Posición' : language === 'FR' ? 'Nouveau Poste' : language === 'IT' ? 'Nuovo Ruolo' : language === 'PT' ? 'Nova Posição' : 'New Role';
      case 'Genel':
      default:
        return language === 'TR' ? 'Genel' : language === 'DE' ? 'Allgemein' : language === 'ES' ? 'General' : language === 'FR' ? 'Général' : language === 'IT' ? 'Generale' : language === 'PT' ? 'Geral' : 'General';
    }
  };

  // Realistic Position Conversion Options based on natural role
  const getCompatiblePositions = (player: Player) => {
    const mainPos = player.position;
    if (mainPos === 'GK') return []; // Cannot convert goalkeepers
    if (mainPos === 'DEF') {
      return ['CB', 'LB', 'RB', 'LWB', 'RWB', 'CDM'];
    }
    if (mainPos === 'MID') {
      return ['CM', 'CDM', 'CAM', 'LM', 'RM', 'LB', 'RB', 'RW', 'LW'];
    }
    if (mainPos === 'FW') {
      return ['ST', 'CF', 'RW', 'LW', 'CAM', 'LM', 'RM'];
    }
    return ['CM', 'ST', 'CB'];
  };

  const handleFocusChange = (newFocus: string) => {
    if (!selectedPlayer) return;
    if (onUpdatePlayerTraining) {
      onUpdatePlayerTraining(selectedPlayer.id, newFocus, selectedPlayer.trainingIntensity || 'Normal');
    }
    if (onShowToast) {
      onShowToast('info', t('FOCUS_UPDATED_TITLE'), t('FOCUS_UPDATED_MSG', { name: selectedPlayer.name, focus: newFocus }));
    }
  };

  const handleIntensityChange = (newIntensity: string) => {
    if (!selectedPlayer) return;
    if (onUpdatePlayerTraining) {
      onUpdatePlayerTraining(selectedPlayer.id, selectedPlayer.trainingFocus || 'Genel', newIntensity);
    }
    if (onShowToast) {
      onShowToast('info', t('INTENSITY_UPDATED_TITLE'), t('INTENSITY_UPDATED_MSG', { name: selectedPlayer.name, intensity: newIntensity }));
    }
  };

  const handleSelectTargetPosition = (posRole: string) => {
    if (!selectedPlayer || !onUpdatePlayerAttributes) return;
    onUpdatePlayerAttributes(selectedPlayer.id, {
      targetPosition: posRole,
      targetPosProgress: 10
    });
    if (onShowToast) {
      onShowToast('success', t('TARGET_POSITION_SET_TITLE'), t('TARGET_POSITION_SET_MSG', { name: selectedPlayer.name, role: posRole }));
    }
  };

  const getPlayerInjuryDiagnosis = (p: Player) => {
    if (p.injuryType) return p.injuryType;
    const numId = Number(p.id.replace(/\D/g, '') || 1);
    
    if (language === 'TR') {
      const diagnoses = [
        'Hamstring Adele Zorlanması (Grade 2)',
        'Ayak Bileği Dış Yan Bağ Burkulması',
        'Kasık Çekmesi & Ödem (Adduktor)',
        'Diz Menisküs Aşınması & Esneme',
        'Baldır Kası Yırtığı (Soleus)',
        'Uyluk Ön Kası Aşırı Yüklenme Zedelenmesi'
      ];
      return diagnoses[numId % diagnoses.length];
    }
    if (language === 'DE') {
      const diagnoses = [
        'Hamstring-Muskelzerrung (Grad 2)',
        'Sprunggelenk-Außenbanddehnung',
        'Leistenzerrung & Adduktorenödem',
        'Meniskusreizung & Bänderdehnung',
        'Wadenmuskelfaserriss (Soleus)',
        'Oberschenkelüberlastung & Prellung'
      ];
      return diagnoses[numId % diagnoses.length];
    }
    if (language === 'ES') {
      const diagnoses = [
        'Distensión de Isquiotibiales (Grado 2)',
        'Esguince de Ligamento Lateral de Tobillo',
        'Sobrecarga de Aductores e Inflamación',
        'Distensión Meniscal de Rodilla',
        'Rotura Fibrilar de Gemelo (Sóleo)',
        'Sobrecarga Muscular en Cuádriceps'
      ];
      return diagnoses[numId % diagnoses.length];
    }
    if (language === 'FR') {
      const diagnoses = [
        'Élongation des Ischio-jambiers (Grade 2)',
        'Entorse du Ligament Latéral de la Cheville',
        'Tension des Adducteurs & Œdème',
        'Lésion Meniscale & Étirement du Genou',
        'Déchirure Musculaire du Mollet (Soléaire)',
        'Surcharge Musculaire du Quadriceps'
      ];
      return diagnoses[numId % diagnoses.length];
    }
    if (language === 'IT') {
      const diagnoses = [
        'Stiramento ai Flessori (Grado 2)',
        'Distorsione al Legamento della Caviglia',
        'Affaticamento agli Adduttori ed Edema',
        'Infiammazione Meniscale al Ginocchio',
        'Lesione Muscolare al Polpaccio (Soleo)',
        'Sovraccarico Muscolare al Quadricipite'
      ];
      return diagnoses[numId % diagnoses.length];
    }
    if (language === 'PT') {
      const diagnoses = [
        'Estiramento nos Isquiotibiais (Grau 2)',
        'Entorse de Ligamento no Tornozelo',
        'Sobrecarga nos Adutores e Edema',
        'Desgaste do Menisco no Joelho',
        'Rutura Muscular na Gémeo (Sóleo)',
        'Sobrecarga Muscular no Quadríceps'
      ];
      return diagnoses[numId % diagnoses.length];
    }
    const diagnoses = [
      'Hamstring Muscle Strain (Grade 2)',
      'Ankle Lateral Ligament Sprain',
      'Groin Pull & Adductor Edema',
      'Knee Meniscus Irritation & Strain',
      'Calf Muscle Tear (Soleus)',
      'Thigh Muscle Overload Contusion'
    ];
    return diagnoses[numId % diagnoses.length];
  };

  // Categorize injury into Kas (Muscle), Eklem (Joint/Ligament), Kırık (Fracture/Bone)
  const getInjuryCategory = (p: Player): {
    category: 'KAS' | 'EKLEM' | 'KIRIK';
    title: string;
    icon: string;
    color: string;
    badgeBg: string;
    avgWeeks: string;
    recoverySpeed: string;
    description: string;
  } => {
    const raw = (p.injuryType || '').toLowerCase() + ' ' + (p.name || '').toLowerCase();
    const isFracture = raw.includes('kırık') || raw.includes('çatlak') || raw.includes('metatars') || raw.includes('kemik') || raw.includes('fracture') || raw.includes('bruch') || raw.includes('fractura') || raw.includes('frattura');
    const isJoint = raw.includes('eklem') || raw.includes('bağ') || raw.includes('diz') || raw.includes('menisküs') || raw.includes('çapraz') || raw.includes('bilek') || raw.includes('omuz') || raw.includes('kalça') || raw.includes('ligament') || raw.includes('joint') || raw.includes('band') || raw.includes('kniegelenk');

    if (isFracture) {
      const title = language === 'TR' ? 'Kırık & Kemik Zedelenmesi' :
        language === 'DE' ? 'Knochenbruch & Fissur' :
        language === 'ES' ? 'Fractura y Fisura Ósea' :
        language === 'FR' ? 'Fracture & Lésion Osseuse' :
        language === 'IT' ? 'Frattura & Lesione Ossea' :
        language === 'PT' ? 'Fratura e Lesão Óssea' :
        'Fracture & Bone Damage';

      const avgWeeks = language === 'TR' ? '4 - 8 Hafta' :
        language === 'DE' ? '4 - 8 Wochen' :
        language === 'ES' ? '4 - 8 Semanas' :
        language === 'FR' ? '4 - 8 Semaines' :
        language === 'IT' ? '4 - 8 Settimane' :
        language === 'PT' ? '4 - 8 Semanas' :
        '4 - 8 Weeks';

      const speed = language === 'TR' ? 'Yavaş (Kemik Kaynaması & Kalsifikasyon)' :
        language === 'DE' ? 'Langsam (Knochenheilung & Verknöcherung)' :
        language === 'ES' ? 'Lento (Consolidación ósea)' :
        language === 'FR' ? 'Lent (Consolidation osseuse)' :
        language === 'IT' ? 'Lento (Consolidamento osseo)' :
        language === 'PT' ? 'Lento (Consolidação óssea)' :
        'Slow (Bone Consolidation & Calcification)';

      const desc = language === 'TR' ? 'Tarak kemiği veya kaburga/stres kırıkları. Kemik dokusu tam kaynamadan yük bindirilemez.' :
        language === 'DE' ? 'Mittelfuß- oder Rippen-Stressfraktur. Vollständige Heilung vor Belastung erforderlich.' :
        language === 'ES' ? 'Fractura por estrés en metatarso o costilla. Requiere unión ósea completa.' :
        language === 'FR' ? 'Fracture de fatigue métatarsienne ou costale. Repos complet obligatoire.' :
        language === 'IT' ? 'Frattura da stress al metatarso o costale. Necessaria completa calcificazione.' :
        language === 'PT' ? 'Fratura por stress no metatarso ou costelas. Requer consolidação total.' :
        'Metatarsal or rib stress fracture. Full bone consolidation required before training.';

      return {
        category: 'KIRIK',
        title,
        icon: '🦴',
        color: 'text-purple-400',
        badgeBg: 'bg-purple-950/80 text-purple-300 border-purple-500/60',
        avgWeeks,
        recoverySpeed: speed,
        description: desc
      };
    }
    if (isJoint) {
      const title = language === 'TR' ? 'Eklem & Bağ Sakatlığı' :
        language === 'DE' ? 'Gelenk- & Bänderverletzung' :
        language === 'ES' ? 'Lesión Articular y de Ligamentos' :
        language === 'FR' ? 'Lésion Articulaire & Ligamentaire' :
        language === 'IT' ? 'Infortunio Articolare e Legamentoso' :
        language === 'PT' ? 'Lesão Articular e de Ligamentos' :
        'Joint & Ligament Injury';

      const avgWeeks = language === 'TR' ? '2 - 5 Hafta' :
        language === 'DE' ? '2 - 5 Wochen' :
        language === 'ES' ? '2 - 5 Semanas' :
        language === 'FR' ? '2 - 5 Semaines' :
        language === 'IT' ? '2 - 5 Settimane' :
        language === 'PT' ? '2 - 5 Semanas' :
        '2 - 5 Weeks';

      const speed = language === 'TR' ? 'Orta (Bağ Dokusu & Kıkırdak Onarımı)' :
        language === 'DE' ? 'Mittel (Bänder- & Knorpelregeneration)' :
        language === 'ES' ? 'Moderado (Reparación de ligamentos)' :
        language === 'FR' ? 'Moyen (Régénération ligamentaire)' :
        language === 'IT' ? 'Medio (Rigenerazione legamentosa)' :
        language === 'PT' ? 'Médio (Reparação de ligamentos)' :
        'Moderate (Ligament & Cartilage Repair)';

      const desc = language === 'TR' ? 'Bağ esnemesi ve eklem zorlanmaları. Özel denge tahtası ve güçlendirme egzersizleri uygulanır.' :
        language === 'DE' ? 'Bänderdehnung und Gelenkverstauchung. Spezielle Stabilitätsübungen erforderlich.' :
        language === 'ES' ? 'Esguinces y distensiones articulares. Ejercicios de propiocepción y fortalecimiento.' :
        language === 'FR' ? 'Étirements ligamentaires et entorses. Exercices de proprioception ciblés.' :
        language === 'IT' ? 'Distorsioni e stiramenti articolari. Lavoro propriocettivo e potenziamento.' :
        language === 'PT' ? 'Entorses e estiramentos articulares. Exercícios de equilíbrio e reforço.' :
        'Ligament sprains and joint hyperextension. Balance board and stabilization drills applied.';

      return {
        category: 'EKLEM',
        title,
        icon: '🦵',
        color: 'text-amber-400',
        badgeBg: 'bg-amber-950/80 text-amber-300 border-amber-500/60',
        avgWeeks,
        recoverySpeed: speed,
        description: desc
      };
    }

    const title = language === 'TR' ? 'Kas & Adele Sakatlığı' :
      language === 'DE' ? 'Muskelverletzung & Zerrung' :
      language === 'ES' ? 'Lesión Muscular' :
      language === 'FR' ? 'Lésion Musculaire' :
      language === 'IT' ? 'Infortunio Muscolare' :
      language === 'PT' ? 'Lesão Muscular' :
      'Muscle & Soft Tissue Injury';

    const avgWeeks = language === 'TR' ? '1 - 3 Hafta' :
      language === 'DE' ? '1 - 3 Wochen' :
      language === 'ES' ? '1 - 3 Semanas' :
      language === 'FR' ? '1 - 3 Semaines' :
      language === 'IT' ? '1 - 3 Settimane' :
      language === 'PT' ? '1 - 3 Semanas' :
      '1 - 3 Weeks';

    const speed = language === 'TR' ? 'Hızlı (Adele Rejenerasyonu & Masaj)' :
      language === 'DE' ? 'Schnell (Muskelregeneration & Physiotherapie)' :
      language === 'ES' ? 'Rápido (Regeneración muscular)' :
      language === 'FR' ? 'Rapide (Régénération musculaire)' :
      language === 'IT' ? 'Rapido (Rigenerazione muscolare)' :
      language === 'PT' ? 'Rápido (Regeneração muscular)' :
      'Fast (Muscle Fiber Regeneration)';

    const desc = language === 'TR' ? 'Hamstring, adduktor kasık veya baldır yırtığı/zorlanması. Dinlenme ve fizyoterapi ile hızla toparlar.' :
      language === 'DE' ? 'Hamstring-, Adduktoren- oder Wadenzerrung. Schnelle Erholung durch Ruhe und Physio.' :
      language === 'ES' ? 'Distensión de isquiotibiales, aductores o gemelo. Recuperación ágil con reposo y fisio.' :
      language === 'FR' ? 'Élongation ischios, adducteurs ou mollet. Récupération rapide avec soins et repos.' :
      language === 'IT' ? 'Stiramento flessori, adduttori o polpaccio. Recupero rapido con massaggi e riposo.' :
      language === 'PT' ? 'Estiramento isquiotibiais, adutores ou gémeo. Recuperação rápida com fisioterapia.' :
      'Hamstring, adductor groin or calf strain. Fast recovery with rest and targeted physiotherapy.';

    return {
      category: 'KAS',
      title,
      icon: '⚡',
      color: 'text-rose-400',
      badgeBg: 'bg-rose-950/80 text-rose-300 border-rose-500/60',
      avgWeeks,
      recoverySpeed: speed,
      description: desc
    };
  };

  // Facility and Recovery Modifiers
  const getRecoveryFactors = (p?: Player) => {
    const age = p?.age || 25;
    const isYoung = age <= 23;
    const isVeteran = age >= 30;

    const ageLabel = isYoung
      ? (language === 'TR' ? 'Genç Metabolizma (+%20 Hızlı İyileşme)' :
         language === 'DE' ? 'Junger Stoffwechsel (+20% Schnellere Heilung)' :
         language === 'ES' ? 'Metabolismo Joven (+20% Recuperación Rápida)' :
         language === 'FR' ? 'Métabolisme Jeune (+20% Guérison Rapide)' :
         language === 'IT' ? 'Metabolismo Giovane (+20% Guarigione Rapida)' :
         language === 'PT' ? 'Metabolismo Jovem (+20% Recuperação Rápida)' :
         'Young Metabolism (+20% Fast Healing)')
      : isVeteran
      ? (language === 'TR' ? 'Tecrübeli / Yavaş Doku Rejenerasyonu (-%15)' :
         language === 'DE' ? 'Erfahrener / Langsamere Regeneration (-15%)' :
         language === 'ES' ? 'Veterano / Regeneración Lenta (-15%)' :
         language === 'FR' ? 'Vétéran / Régénération Ralentie (-15%)' :
         language === 'IT' ? 'Veterano / Rigenerazione Rallentata (-15%)' :
         language === 'PT' ? 'Veterano / Regeneração Lenta (-15%)' :
         'Veteran / Slower Tissue Regeneration (-15%)')
      : (language === 'TR' ? 'Optimum Atletik İyileşme Formu (Standart)' :
         language === 'DE' ? 'Optimale Regeneration (Standard)' :
         language === 'ES' ? 'Forma Atlética Óptima (Estándar)' :
         language === 'FR' ? 'Forme Athlétique Optimale (Standard)' :
         language === 'IT' ? 'Forma Atletica Ottimale (Standard)' :
         language === 'PT' ? 'Forma Atlética Ideal (Padrão)' :
         'Optimal Athletic Recovery Form (Standard)');

    const ageDetail = isYoung
      ? (language === 'TR' ? 'Genç futbolcu hücre yenilenmesi dokuların erken toparlanmasını sağlar.' :
         language === 'DE' ? 'Rasche Zellerneuerung sorgt für frühe Einsatzfähigkeit.' :
         language === 'ES' ? 'La rápida regeneración celular permite una vuelta temprana.' :
         language === 'FR' ? 'Le renouvellement cellulaire rapide favorise une reprise précoce.' :
         language === 'IT' ? 'Il rapido ricambio cellulare accelera i tempi di rientro.' :
         language === 'PT' ? 'A rápida regeneração celular acelera o regresso aos relvados.' :
         'Rapid cell renewal enables early return to active training.')
      : (language === 'TR' ? 'İleri yaşta kas dokusunun esnekliği azaldığından temkinli saha çalışmaları gereklidir.' :
         language === 'DE' ? 'Im Alter sinkt die Muskelelastizität, behutsamer Aufbau ist nötig.' :
         language === 'ES' ? 'La menor elasticidad muscular aconseja prudencia en la reincorporación.' :
         language === 'FR' ? 'La perte d’élasticité musculaire impose une reprise très progressive.' :
         language === 'IT' ? 'La minore elasticità muscolare richiede prudenza nel recupero.' :
         language === 'PT' ? 'A menor elasticidade muscular exige prudência na reintegração.' :
         'Reduced muscle elasticity requires careful, gradual return to full intensity.');

    return [
      {
        title: language === 'TR' ? 'Kulüp Sağlık & Antrenman Tesisleri' :
          language === 'DE' ? 'Vereins-Gesundheits- & Trainingszentrum' :
          language === 'ES' ? 'Instalaciones Médicas y de Entrenamiento' :
          language === 'FR' ? 'Installations Médicales & Centre d’Entraînement' :
          language === 'IT' ? 'Strutture Mediche & Centro d’Allenamento' :
          language === 'PT' ? 'Instalações Médicas e Centro de Treino' :
          'Club Medical & Training Facilities',
        level: language === 'TR' ? '⭐⭐⭐⭐⭐ 5 Yıldız (Elit Seviye)' :
          language === 'DE' ? '⭐⭐⭐⭐⭐ 5 Sterne (Elite-Niveau)' :
          language === 'ES' ? '⭐⭐⭐⭐⭐ 5 Estrellas (Nivel Élite)' :
          language === 'FR' ? '⭐⭐⭐⭐⭐ 5 Étoiles (Niveau Élite)' :
          language === 'IT' ? '⭐⭐⭐⭐⭐ 5 Stelle (Livello Élite)' :
          language === 'PT' ? '⭐⭐⭐⭐⭐ 5 Estrelas (Nível Elite)' :
          '⭐⭐⭐⭐⭐ 5-Star (Elite Level)',
        detail: language === 'TR' ? 'Kriyoterapi soğuk odaları, hidroterapi havuzları ve lazer rehabilitasyon donanımları devrede.' :
          language === 'DE' ? 'Kältekammern, Hydrotherapie-Becken und Laser-Rehabilitation im Einsatz.' :
          language === 'ES' ? 'Cámaras de crioterapia, piscinas de hidroterapia y láser de rehabilitación activos.' :
          language === 'FR' ? 'Cryothérapie, bassins d’hydrothérapie et rééducation laser actifs.' :
          language === 'IT' ? 'Crioterapia, vasche idroterapiche e laserterapia operativi.' :
          language === 'PT' ? 'Criocâmaras, piscinas de hidroterapia e laser de reabilitação ativos.' :
          'Cryotherapy chambers, hydrotherapy pools, and laser rehab active.',
        icon: '🏥',
        color: 'text-emerald-400'
      },
      {
        title: language === 'TR' ? 'Medikal Kadro & Baş Fizyoterapist' :
          language === 'DE' ? 'Ärzteteam & Chef-Physiotherapeut' :
          language === 'ES' ? 'Cuerpo Médico y Fisioterapeuta Jefe' :
          language === 'FR' ? 'Staff Médical & Chef Kinésithérapeute' :
          language === 'IT' ? 'Staff Medico & Capo Fisioterapista' :
          language === 'PT' ? 'Equipa Médica e Fisioterapeuta Chefe' :
          'Medical Staff & Head Physiotherapist',
        level: language === 'TR' ? 'Uzman Sağlık Heyeti' :
          language === 'DE' ? 'Fachärzte-Gremium' :
          language === 'ES' ? 'Equipo Especializado' :
          language === 'FR' ? 'Experts Médicaux' :
          language === 'IT' ? 'Équipe Specializzata' :
          language === 'PT' ? 'Equipa Especializada' :
          'Specialist Medical Board',
        detail: language === 'TR' ? 'Günlük kas tonusu izleme ve özel fizyoterapi seansları ile sakatlığın tekrarlaması engelleniyor.' :
          language === 'DE' ? 'Tägliches Muskel-Monitoring und gezielte Physio-Sitzungen verhindern Rückfälle.' :
          language === 'ES' ? 'Monitoreo diario del tono muscular y sesiones continuas para evitar recaídas.' :
          language === 'FR' ? 'Suivi quotidien du tonus musculaire et soins ciblés pour éviter les rechutes.' :
          language === 'IT' ? 'Monitoraggio quotidiano del tono muscolare e sedute continue per evitare ricadute.' :
          language === 'PT' ? 'Monitorização diária do tónus muscular e sessões contínuas para prevenir recaídas.' :
          'Daily muscle tone monitoring and dedicated physiotherapy sessions prevent re-injury.',
        icon: '👨‍⚕️',
        color: 'text-sky-400'
      },
      {
        title: language === 'TR' ? 'Bireysel Yaş & Fiziksel Direnç Faktörü' :
          language === 'DE' ? 'Individuelles Alter & Physische Belastbarkeit' :
          language === 'ES' ? 'Edad Individual y Resistencia Física' :
          language === 'FR' ? 'Âge Individuel & Résistance Physique' :
          language === 'IT' ? 'Età Individuale & Resistenza Fisica' :
          language === 'PT' ? 'Idade Individual e Resistência Física' :
          'Age Factor & Physical Resilience',
        level: `${age} ${language === 'TR' ? 'Yaş' : language === 'DE' ? 'Jahre' : language === 'ES' ? 'Años' : language === 'FR' ? 'Ans' : language === 'IT' ? 'Anni' : language === 'PT' ? 'Anos' : 'Yrs'} (${isYoung ? '+20%' : isVeteran ? '-15%' : '±0%'})`,
        detail: ageDetail,
        icon: '🧬',
        color: isYoung ? 'text-emerald-400' : isVeteran ? 'text-amber-400' : 'text-sky-400'
      },
      {
        title: language === 'TR' ? 'Uygulanan Tedavi & Dinlenme Protokolü' :
          language === 'DE' ? 'Behandlungs- & Ruheprotokoll' :
          language === 'ES' ? 'Protocolo de Tratamiento y Descanso' :
          language === 'FR' ? 'Protocole de Soins & Repos' :
          language === 'IT' ? 'Protocollo di Terapia & Riposo' :
          language === 'PT' ? 'Protocolo de Tratamento e Repouso' :
          'Treatment & Recovery Protocol',
        level: language === 'TR' ? 'Aktif Klinik Tedavi + Havuz Egzersizi' :
          language === 'DE' ? 'Klinische Therapie + Aqua-Training' :
          language === 'ES' ? 'Terapia Clínica + Ejercicio en Piscina' :
          language === 'FR' ? 'Thérapie Clinique + Travail en Bassin' :
          language === 'IT' ? 'Terapia Clinica + Lavoro in Vasca' :
          language === 'PT' ? 'Terapia Clínica + Exercício na Piscina' :
          'Active Clinical Therapy + Pool Training',
        detail: language === 'TR' ? 'Darbe almadan kondisyonu korumak için havuzda kardiyo ve fizyoterapist eşliğinde esneme yapılıyor.' :
          language === 'DE' ? 'Gelenkschonendes Ausdauertraining im Wasser und begleitetes Dehnen.' :
          language === 'ES' ? 'Cardio en piscina sin impacto y estiramientos con el fisioterapeuta.' :
          language === 'FR' ? 'Cardio sans impact en piscine et étirements avec le kinésithérapeute.' :
          language === 'IT' ? 'Cardio a basso impatto in piscina e stretching con il fisioterapeuta.' :
          language === 'PT' ? 'Cardio na piscina sem impacto e alongamentos assistidos pelo fisioterapeuta.' :
          'Low-impact pool cardio and assisted stretching protect stamina while avoiding stress.',
        icon: '🧊',
        color: 'text-teal-400'
      }
    ];
  };

  const getMedicalStaffRecommendation = (p: Player) => {
    const weeksLeft = p.injuryWeeksLeft || 1;
    if (weeksLeft <= 1) {
      if (language === 'TR') return 'Fizyoterapist kontrolünde saha düz koşularına başladı. Bir sonraki hafta takımla çalışabilir.';
      if (language === 'DE') return 'Leichtes Einzeltraining auf dem Platz begonnen. Rückkehr ins Mannschaftstraining nächste Woche erwartet.';
      if (language === 'ES') return 'Ha comenzado carreras continuas sobre el césped. Se espera su vuelta al grupo la próxima semana.';
      if (language === 'FR') return 'A repris la course légère sur le terrain. Retour à l’entraînement collectif prévu la semaine prochaine.';
      if (language === 'IT') return 'Ha iniziato la corsa leggera sul campo. Rientro in gruppo previsto la prossima settimana.';
      if (language === 'PT') return 'Iniciou corrida ligeira no relvado. Regresso aos treinos coletivos previsto para a próxima semana.';
      return 'Began light individual running on the pitch. Expected to rejoin team training next week.';
    } else if (weeksLeft <= 2) {
      if (language === 'TR') return 'Klinik tedavi ve havuz egzersizleri sürdürülüyor. Sakatlığın nüksetmemesi için dinlendiriliyor.';
      if (language === 'DE') return 'Klinische Therapie und Aqua-Gymnastik laufen. Schonung zur Vermeidung von Rückschlägen.';
      if (language === 'ES') return 'Continúa con sesiones de hidroterapia y clínica. Se le cuida para evitar recaídas.';
      if (language === 'FR') return 'Poursuit les soins en clinique et en piscine. Préservé pour éviter toute rechute.';
      if (language === 'IT') return 'Prosegue le terapie e il lavoro in acqua. Gestito con cautela per evitare ricadute.';
      if (language === 'PT') return 'Continua o tratamento clínico e na piscina. Gerido com cuidado para prevenir recaídas.';
      return 'Ongoing clinical therapy and pool drills. Managed carefully to prevent any relapse.';
    } else {
      if (language === 'TR') return 'İstirahat aşamasında. Kulüp doktorları eşliğinde yoğun fizyoterapi ve masaj programı uygulanıyor.';
      if (language === 'DE') return 'Ruhephase. Intensives Physio- und Behandlungsprogramm unter ärztlicher Aufsicht.';
      if (language === 'ES') return 'Fase de reposo. Programa intensivo de fisioterapia bajo supervisión médica.';
      if (language === 'FR') return 'Phase de repos. Programme intensif de kinésithérapie sous supervision médicale.';
      if (language === 'IT') return 'Fase di riposo. Trattamento intensivo di fisioterapia sotto controllo medico.';
      if (language === 'PT') return 'Fase de repouso. Programa intensivo de fisioterapia sob supervisão médica.';
      return 'Rest phase. Intensive physiotherapy and rehab program under club doctor supervision.';
    }
  };

  const getPlayerRiskAssessment = (p: Player) => {
    const isInjured = p.isInjured || (p.injuryWeeksLeft && p.injuryWeeksLeft > 0);
    if (isInjured) {
      const badge = language === 'TR' ? 'SAKAT' :
        language === 'DE' ? 'VERLETZT' :
        language === 'ES' ? 'LESIONADO' :
        language === 'FR' ? 'BLESSÉ' :
        language === 'IT' ? 'INFORTUNATO' :
        language === 'PT' ? 'LESIONADO' :
        'INJURED';

      const label = language === 'TR' ? `${p.injuryWeeksLeft || 1} Hafta Kalan Süre` :
        language === 'DE' ? `${p.injuryWeeksLeft || 1} Wochen verbleibend` :
        language === 'ES' ? `${p.injuryWeeksLeft || 1} Semanas restantes` :
        language === 'FR' ? `${p.injuryWeeksLeft || 1} Semaines restantes` :
        language === 'IT' ? `${p.injuryWeeksLeft || 1} Settimane rimanenti` :
        language === 'PT' ? `${p.injuryWeeksLeft || 1} Semanas restantes` :
        `${p.injuryWeeksLeft || 1} Weeks Remaining`;

      return {
        level: 'INJURED',
        badge,
        badgeColor: 'bg-rose-500/30 text-rose-300 border-rose-500/50',
        dotColor: 'bg-rose-500 animate-pulse',
        label
      };
    }

    const isHighIntensity = p.trainingIntensity === 'Ağır';
    const isLowStamina = (p.stamina ?? 100) < 65;
    const isVeteran = p.age >= 30;

    if ((isHighIntensity && isVeteran) || (isLowStamina && isHighIntensity)) {
      const badge = language === 'TR' ? 'YÜKSEK RİSK' :
        language === 'DE' ? 'HOHES RISIKO' :
        language === 'ES' ? 'ALTO RIESGO' :
        language === 'FR' ? 'RISQUE ÉLEVÉ' :
        language === 'IT' ? 'ALTO RISCHIO' :
        language === 'PT' ? 'ALTO RISCO' :
        'HIGH RISK';

      return {
        level: 'HIGH',
        badge,
        badgeColor: 'bg-rose-950/80 text-rose-300 border-rose-600/50',
        dotColor: 'bg-rose-400 animate-ping',
        label: language === 'TR' ? 'Aşırı Yüklenme & Yaş/Kondisyon Riski' : 'Overload & Fatigue Risk'
      };
    }

    if (isHighIntensity || isLowStamina || (isVeteran && (p.stamina ?? 100) < 80)) {
      const badge = language === 'TR' ? 'ORTA RİSK' :
        language === 'DE' ? 'MITTLERES RISIKO' :
        language === 'ES' ? 'RIESGO MEDIO' :
        language === 'FR' ? 'RISQUE MOYEN' :
        language === 'IT' ? 'RISCHIO MEDIO' :
        language === 'PT' ? 'RISCO MÉDIO' :
        'MEDIUM RISK';

      return {
        level: 'MEDIUM',
        badge,
        badgeColor: 'bg-amber-950/80 text-amber-300 border-amber-600/50',
        dotColor: 'bg-amber-400',
        label: language === 'TR' ? 'Dikkatli Yükleme Gerekir' : 'Careful Load Required'
      };
    }

    const badge = language === 'TR' ? 'DÜŞÜK RİSK' :
      language === 'DE' ? 'GERINGES RISIKO' :
      language === 'ES' ? 'BAJO RIESGO' :
      language === 'FR' ? 'FAIBLE RISQUE' :
      language === 'IT' ? 'BASSO RISCHIO' :
      language === 'PT' ? 'BAIXO RISCO' :
      'LOW RISK';

    return {
      level: 'LOW',
      badge,
      badgeColor: 'bg-emerald-950/80 text-emerald-300 border-emerald-600/50',
      dotColor: 'bg-emerald-400',
      label: language === 'TR' ? 'İdeal Atletik Durum' : 'Optimal Athletic State'
    };
  };

  const filteredSquadList = currentTeam.players.filter(p => {
    if (injuryListFilter === 'INJURED_ONLY') return p.isInjured || (p.injuryWeeksLeft && p.injuryWeeksLeft > 0);
    if (injuryListFilter === 'HIGH_RISK') {
      return (p.isInjured || (p.injuryWeeksLeft && p.injuryWeeksLeft > 0)) ||
             ((p.trainingIntensity === 'Ağır' && p.age >= 29) || p.stamina < 65);
    }
    return true;
  });

  return (
    <div className="bg-[#18142a] border border-[#2d244c] rounded-2xl shadow-2xl p-2 sm:p-2.5 space-y-1.5 overflow-hidden flex flex-col h-full min-h-0">
      
      {/* Top Header & Tab Selector Bar */}
      <div className="bg-[#130f24] px-2 py-1.5 rounded-xl border border-[#2d244c] flex flex-col sm:flex-row items-center justify-between gap-1.5 shrink-0">
        
        {/* Sub-Tab Navigation */}
        <div className="flex items-center gap-1 bg-[#1f1838] p-0.5 rounded-xl border border-[#362b5c] w-full sm:w-auto shrink-0">
          <button
            onClick={() => setActiveSubTab('TRAINING')}
            className={`flex-1 sm:flex-none px-3 py-1 rounded-lg font-black text-[10px] sm:text-[11px] flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeSubTab === 'TRAINING'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-[#2c224e]'
            }`}
          >
            <Dumbbell className="w-3.5 h-3.5" />
            <span>{t('TRAINING_CENTER_TITLE') || 'ANTRENMAN MERKEZİ'}</span>
          </button>

          <button
            onClick={() => setActiveSubTab('GROWTH_CHART')}
            className={`flex-1 sm:flex-none px-3 py-1 rounded-lg font-black text-[10px] sm:text-[11px] flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeSubTab === 'GROWTH_CHART'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-[#2c224e]'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>{t('GROWTH_CHART_TITLE') || 'GELİŞİM GRAFİĞİ'}</span>
          </button>

          <button
            onClick={() => setActiveSubTab('INJURY_REPORT')}
            className={`flex-1 sm:flex-none px-3 py-1 rounded-lg font-black text-[10px] sm:text-[11px] flex items-center justify-center gap-1.5 transition-all cursor-pointer relative ${
              activeSubTab === 'INJURY_REPORT'
                ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-[#2c224e]'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>
              {language === 'TR' ? 'SAĞLIK & SAKATLIK' :
               language === 'DE' ? 'GESUNDHEIT & VERLETZUNGEN' :
               language === 'ES' ? 'SALUD Y LESIONES' :
               language === 'FR' ? 'SANTÉ & BLESSURES' :
               language === 'IT' ? 'SALUTE & INFORTUNI' :
               language === 'PT' ? 'SAÚDE & LESÕES' :
               'HEALTH & INJURIES'}
            </span>
            {injuredPlayers.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-rose-500 text-white font-black text-[8px] flex items-center justify-center border border-white/40 shadow-sm ml-0.5">
                {injuredPlayers.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* TAB 1: MAIN TRAINING CONSOLE */}
      {activeSubTab === 'TRAINING' && (
        <div className="flex flex-row gap-2 shrink-0 items-stretch w-full flex-1 min-h-0 animate-fadeIn">
          
          {/* Player Selector List - Compact & Left-aligned (%26 Width) */}
          <div className="w-[28%] sm:w-[25%] min-w-[95px] bg-[#130f24] p-1 sm:p-1.5 rounded-xl border border-[#2d244c] space-y-1 overflow-y-auto max-h-[calc(100vh-160px)] custom-fmm-scrollbar shrink-0 text-left">
            <span className="text-[8.5px] font-black uppercase text-slate-400 tracking-wider block px-1 truncate">
              {t('SQUAD_COUNT', { count: currentTeam.players.length })}
            </span>

            {currentTeam.players.map((p) => {
              const isSelected = p.id === selectedPlayerId;
              const progress = p.growthProgress || 0;
              const isInj = p.isInjured || (p.injuryWeeksLeft && p.injuryWeeksLeft > 0);

              return (
                <div
                  key={p.id}
                  onClick={() => setSelectedPlayerId(p.id)}
                  className={`p-1 sm:p-1.5 rounded-lg border cursor-pointer transition-all flex flex-col gap-0.5 select-none text-left ${
                    isSelected
                      ? 'bg-emerald-500/20 border-emerald-500/60 text-white font-bold shadow'
                      : isInj
                      ? 'bg-rose-950/30 border-rose-800/40 text-slate-300 hover:bg-rose-950/50'
                      : 'bg-[#1a1430] border-[#2c224a] text-slate-300 hover:bg-[#231b3e]'
                  }`}
                >
                  <div className="flex items-center justify-between min-w-0">
                    <div className="min-w-0 flex-1 pr-0.5 text-left">
                      <div className="flex items-center gap-1">
                        <span className="block text-[10px] font-extrabold text-white truncate leading-tight">{p.name}</span>
                        {isInj && <span className="text-[8px]" title="Sakat">🚑</span>}
                      </div>
                      <span className="block text-[8px] text-slate-400 truncate">{p.position} ({p.specificRole || t('POSITION_FALLBACK')})</span>
                    </div>
                    <span className="px-1 py-0.2 rounded bg-[#292044] border border-[#3e3263] text-emerald-400 text-[8.5px] font-black shrink-0">
                      {p.overall}
                    </span>
                  </div>

                  {/* Growth Progress Bar */}
                  <div className="w-full space-y-0.5">
                    <div className="flex justify-between text-[7px] font-bold text-slate-400">
                      <span>{t('GROWTH_LABEL')}</span>
                      <span className="text-emerald-400">{progress}%</span>
                    </div>
                    <div className="w-full h-1 bg-[#120f21] rounded-full overflow-hidden border border-[#282042]">
                      <div
                        style={{ width: `${progress}%` }}
                        className="h-full bg-gradient-to-r from-emerald-400 via-teal-400 to-amber-400 rounded-full"
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Selected Player Dashboard (%74 Width) - Generous spacing for focus and intensity */}
          {selectedPlayer && (
            <div className="w-[72%] sm:w-[75%] bg-[#130f24] p-2 sm:p-2.5 rounded-xl border border-[#2d244c] flex flex-col justify-between space-y-1.5 min-w-0 flex-1 overflow-y-auto custom-fmm-scrollbar">
              
              <div className="space-y-1.5">
                {/* Header */}
                <div className="flex items-center justify-between border-b border-[#2d244c] pb-1">
                  <div>
                    <h4 className="text-xs font-black text-white leading-tight flex items-center gap-1.5">
                      {selectedPlayer.name}
                      <span className="text-[9px] text-amber-300 font-extrabold px-1.5 py-0.2 rounded bg-amber-500/20 border border-amber-500/30">
                        {getFocusShortTranslated(selectedPlayer.trainingFocus)} {t('FOCUS_SUFFIX')}
                      </span>
                      {(selectedPlayer.isInjured || (selectedPlayer.injuryWeeksLeft && selectedPlayer.injuryWeeksLeft > 0)) && (
                        <span className="text-[9px] text-rose-300 font-extrabold px-1.5 py-0.2 rounded bg-rose-500/20 border border-rose-500/40 animate-pulse">
                          🚑 SAKAT ({selectedPlayer.injuryWeeksLeft || 1} Hafta)
                        </span>
                      )}
                    </h4>
                    <span className="text-[9px] text-slate-400 font-semibold block mt-0.5">
                      {t('CURRENT_ROLE_LABEL')} {selectedPlayer.position} ({selectedPlayer.specificRole || t('POSITION_FALLBACK')}) • {selectedPlayer.age} Yaş
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="text-center px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 rounded-lg shrink-0">
                      <span className="text-[7.5px] uppercase font-extrabold text-slate-400 block">{t('OVERALL_POWER')}</span>
                      <span className="text-xs font-black text-emerald-400">{selectedPlayer.overall} OVR</span>
                    </div>
                  </div>
                </div>

                {/* Training Focus & Intensity Controls */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-[#18132e] p-2 rounded-xl border border-[#2e2450] relative">
                  
                  {/* Focus Custom Dropdown */}
                  <div className="space-y-1 relative">
                    <label className="text-[8.5px] font-black uppercase text-amber-300 block">
                      {t('TRAINING_FOCUS_LABEL')}
                    </label>
                    <CustomSelect
                      value={selectedPlayer.trainingFocus || 'Genel'}
                      onChange={handleFocusChange}
                      options={focusOptions}
                      dropdownAlign="left"
                    />
                  </div>

                  {/* Intensity Custom Dropdown (Right-aligned to avoid clipping) */}
                  <div className="space-y-1 relative">
                    <label className="text-[8.5px] font-black uppercase text-amber-300 block">
                      {t('TRAINING_INTENSITY_LABEL')}
                    </label>
                    <CustomSelect
                      value={selectedPlayer.trainingIntensity || 'Normal'}
                      onChange={handleIntensityChange}
                      options={intensityOptions}
                      dropdownAlign="right"
                      dropdownClassName="right-0 left-auto w-full min-w-full"
                    />
                  </div>

                </div>

                {/* POSITION CONVERSION SECTION (When 'Yeni Pozisyon' is selected) */}
                {selectedPlayer.trainingFocus === 'Yeni Pozisyon' && (
                  <div className="bg-[#100c21] p-2 sm:p-2.5 rounded-xl border border-purple-500/40 space-y-2">
                    <div className="flex items-center justify-between border-b border-[#2d2350] pb-1">
                      <span className="text-[10px] font-black text-purple-300 uppercase tracking-wider flex items-center gap-1">
                        {t('POSITION_CONVERSION_TITLE')}
                      </span>
                      {selectedPlayer.position === 'GK' && (
                        <span className="text-[9px] text-rose-400 font-bold">{t('GK_CANNOT_CONVERT')}</span>
                      )}
                    </div>

                    {selectedPlayer.position === 'GK' ? (
                      <p className="text-[10px] text-slate-400 font-medium">
                        {t('GK_CONVERT_WARNING')}
                      </p>
                    ) : (
                      <div className="space-y-1.5">
                        <span className="text-[9px] font-bold text-slate-300 block">
                          {t('COMPATIBLE_POSITIONS_FOR', { name: selectedPlayer.name })}
                        </span>
                        <div className="grid grid-cols-3 sm:grid-cols-6 gap-1">
                          {getCompatiblePositions(selectedPlayer).map(role => {
                            const isCurrent = selectedPlayer.specificRole === role;
                            const isTarget = selectedPlayer.targetPosition === role;

                            return (
                              <button
                                key={role}
                                onClick={() => handleSelectTargetPosition(role)}
                                disabled={isCurrent}
                                className={`p-1 rounded-lg border font-black text-[10px] text-center transition-all cursor-pointer ${
                                  isCurrent
                                    ? 'bg-slate-800 border-slate-700 text-slate-500 cursor-not-allowed'
                                    : isTarget
                                    ? 'bg-emerald-500 border-emerald-300 text-slate-950 shadow ring-2 ring-emerald-400/50'
                                    : 'bg-[#1e173b] border-[#382b61] text-purple-200 hover:bg-purple-600 hover:text-white'
                                }`}
                              >
                                {role}
                                <span className="block text-[7.5px] font-semibold opacity-80">
                                  {isCurrent ? t('ROLE_CURRENT') : isTarget ? t('ROLE_TARGET') : t('ROLE_COMPATIBLE')}
                                </span>
                              </button>
                            );
                          })}
                        </div>

                        {selectedPlayer.targetPosition && (
                          <div className="bg-[#171233] p-1.5 rounded-lg border border-[#342759] space-y-1">
                            <div className="flex justify-between text-[9px] font-extrabold">
                              <span className="text-purple-300 flex items-center gap-1">
                                <Sparkles className="w-3 h-3 text-amber-400" />
                                {t('TARGET_ROLE_LABEL')} {selectedPlayer.targetPosition}
                              </span>
                              <span className="text-emerald-400">
                                {t('ADAPTATION_PROGRESS', { progress: selectedPlayer.targetPosProgress || 10 })}
                              </span>
                            </div>
                            <div className="w-full h-1.5 bg-[#0e0a1f] rounded-full overflow-hidden border border-[#2e2350]">
                              <div
                                style={{ width: `${selectedPlayer.targetPosProgress || 10}%` }}
                                className="h-full bg-gradient-to-r from-purple-500 via-indigo-400 to-emerald-400 rounded-full"
                              />
                            </div>
                            <p className="text-[8px] text-slate-400 font-medium">
                              {t('DRILL_POSITION_NOTE')}
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Injury Risk Indicator */}
                {(() => {
                  const currentIntensity = selectedPlayer.trainingIntensity || 'Normal';
                  const isHigh = currentIntensity === 'Ağır';
                  const isLow = currentIntensity === 'Hafif';

                  const riskColor = isHigh
                    ? 'bg-rose-950/60 border-rose-500/60 text-rose-200'
                    : isLow
                    ? 'bg-emerald-950/60 border-emerald-500/60 text-emerald-200'
                    : 'bg-amber-950/60 border-amber-500/60 text-amber-200';

                  const badgeBg = isHigh
                    ? 'bg-rose-500 text-slate-950'
                    : isLow
                    ? 'bg-emerald-500 text-slate-950'
                    : 'bg-amber-400 text-slate-950';

                  const riskPercent = isHigh 
                    ? selectedPlayer.age >= 30 ? '%45 - %70 (Yaşlı Oyuncu)' : '%20 - %35' 
                    : isLow ? '%2 - %5' : '%10 - %15';

                  const riskTitle = isHigh
                    ? t('INJURY_RISK_HIGH_TITLE')
                    : isLow
                    ? t('INJURY_RISK_LOW_TITLE')
                    : t('INJURY_RISK_BALANCED_TITLE');

                  const riskDesc = isHigh
                    ? (selectedPlayer.age >= 30 
                        ? 'Dikkat: 30 yaş ve üstü oyuncular ağır antrenman yükünde ciddi sakatlık riski taşır.' 
                        : t('INJURY_RISK_HIGH_DESC'))
                    : isLow
                    ? t('INJURY_RISK_LOW_DESC')
                    : t('INJURY_RISK_BALANCED_DESC');

                  return (
                    <div className={`p-2 rounded-xl border flex items-start gap-2 shadow-lg transition-all ${riskColor}`}>
                      <div className="p-1 rounded-lg bg-slate-950/50 shrink-0">
                        <ShieldAlert className={`w-4 h-4 ${isHigh ? 'text-rose-400 animate-pulse' : isLow ? 'text-emerald-400' : 'text-amber-400'}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1 flex-wrap">
                          <span className="text-[10px] font-black uppercase tracking-wider">
                            {riskTitle}
                          </span>
                          <span className={`px-2 py-0.2 rounded-full font-black text-[8.5px] uppercase tracking-wide ${badgeBg}`}>
                            {t('INJURY_CHANCE_LABEL')} {riskPercent}
                          </span>
                        </div>
                        <p className="text-[9px] font-medium leading-tight mt-0.5 opacity-90">
                          {riskDesc}
                        </p>
                      </div>
                    </div>
                  );
                })()}

                {/* Growth Progress Bar */}
                <div className="bg-[#120f21] p-2 rounded-xl border border-[#2a2145] space-y-1">
                  <div className="flex items-center justify-between text-[11px] font-black">
                    <span className="text-slate-200 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      {t('GROWTH_PROGRESS_BAR_TITLE')}
                    </span>
                    <span className="text-emerald-400 font-extrabold">
                      {selectedPlayer.growthProgress || 0}% / 100%
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-[#1a1430] rounded-full overflow-hidden border border-[#342857]">
                    <div
                      style={{ width: `${selectedPlayer.growthProgress || 0}%` }}
                      className="h-full rounded-full transition-all duration-500 bg-gradient-to-r from-emerald-500 via-teal-400 to-amber-400"
                    />
                  </div>
                  <p className="text-[8.5px] text-slate-400 font-medium leading-tight">
                    {t('GROWTH_BAR_NOTE', { focus: getFocusShortTranslated(selectedPlayer.trainingFocus) })}
                  </p>
                </div>

                {/* Attributes Progress */}
                <div className="space-y-1 pt-0.5">
                  <span className="text-[8.5px] font-black uppercase text-slate-400 tracking-wider block">
                    {t('CURRENT_ATTRIBUTE_POINTS')}
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1">
                    {Object.entries(selectedPlayer.attributes).map(([key, val]) => {
                      const labels: Record<string, string> = {
                        pace: t('ATTR_PACE_LABEL'),
                        shooting: t('ATTR_SHOOTING_LABEL'),
                        passing: t('ATTR_PASSING_LABEL'),
                        defending: t('ATTR_DEFENDING_LABEL'),
                        physical: t('ATTR_PHYSICAL_LABEL')
                      };

                      const focus = selectedPlayer.trainingFocus || 'Genel';
                      const isFocused =
                        (focus === 'Hücum' && key === 'shooting') ||
                        (focus === 'Pas' && key === 'passing') ||
                        (focus === 'Defans' && key === 'defending') ||
                        (focus === 'Fizik' && key === 'physical') ||
                        (focus === 'Genel' && key === 'pace');

                      return (
                        <div
                          key={key}
                          className={`space-y-0.5 text-[9px] font-bold p-1 rounded-lg border transition-all ${
                            isFocused
                              ? 'bg-amber-500/10 border-amber-500/40 text-amber-200 ring-1 ring-amber-500/30'
                              : 'bg-[#120e24] border-[#281f44] text-slate-300'
                          }`}
                        >
                          <div className="flex justify-between text-[9px]">
                            <span className="flex items-center gap-1">
                              {labels[key] || key}
                              {isFocused && <span className="text-[7.5px] text-amber-300 font-black">{t('FOCUS_BADGE')}</span>}
                            </span>
                            <span className={isFocused ? 'text-amber-300 font-black' : 'text-emerald-400 font-black'}>
                              {val} / 99
                            </span>
                          </div>
                          <div className="w-full h-1 bg-[#1f1938] rounded-full overflow-hidden border border-[#362b5c]">
                            <div
                              style={{ width: `${val}%` }}
                              className={`h-full rounded-full ${
                                isFocused
                                  ? 'bg-gradient-to-r from-amber-400 to-amber-200'
                                  : 'bg-gradient-to-r from-emerald-500 to-teal-400'
                              }`}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>
      )}

      {/* TAB 2: SKILL GROWTH CHART */}
      {activeSubTab === 'GROWTH_CHART' && selectedPlayer && (
        <div className="animate-fadeIn w-full flex-1 min-h-0 overflow-y-auto custom-fmm-scrollbar">
          <PlayerSkillGrowthChart
            player={selectedPlayer}
            players={currentTeam.players}
            onSelectPlayer={setSelectedPlayerId}
          />
        </div>
      )}

      {/* TAB 3: INJURY & MEDICAL CENTER DASHBOARD (SAKATLIK PENCERESİ) */}
      {activeSubTab === 'INJURY_REPORT' && (
        <div className="animate-fadeIn w-full flex-1 min-h-0 overflow-y-auto custom-fmm-scrollbar space-y-2.5">
          
          {/* Top Medical Overview Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            
            {/* Card 1: Injured Count */}
            <div className={`p-2.5 rounded-xl border flex items-center justify-between shadow ${
              injuredPlayers.length > 0 
                ? 'bg-rose-950/40 border-rose-700/60' 
                : 'bg-emerald-950/30 border-emerald-700/40'
            }`}>
              <div className="space-y-0.5">
                <span className="text-[9px] uppercase font-black tracking-wider text-slate-400 block">
                  {language === 'TR' ? 'Aktif Sakat Oyuncular' :
                   language === 'DE' ? 'Aktive Verletzte' :
                   language === 'ES' ? 'Jugadores Lesionados' :
                   language === 'FR' ? 'Joueurs Blessés' :
                   language === 'IT' ? 'Giocatori Infortunati' :
                   language === 'PT' ? 'Jogadores Lesionados' :
                   'Active Injured Players'}
                </span>
                <span className={`text-base font-black flex items-center gap-1.5 ${
                  injuredPlayers.length > 0 ? 'text-rose-400' : 'text-emerald-400'
                }`}>
                  {injuredPlayers.length > 0 
                    ? `🚑 ${injuredPlayers.length} ${
                        language === 'TR' ? 'Oyuncu Sakat' :
                        language === 'DE' ? 'Spieler verletzt' :
                        language === 'ES' ? 'Lesionados' :
                        language === 'FR' ? 'Blessés' :
                        language === 'IT' ? 'Infortunati' :
                        language === 'PT' ? 'Lesionados' :
                        'Players Injured'}` 
                    : (
                        language === 'TR' ? '✓ Revir Boş (0 Sakat)' :
                        language === 'DE' ? '✓ Lazarett leer (0 Verletzte)' :
                        language === 'ES' ? '✓ Enfermería Vacía (0 Lesionados)' :
                        language === 'FR' ? '✓ Infirmerie vide (0 Blessé)' :
                        language === 'IT' ? '✓ Infermeria vuota (0 Infortunati)' :
                        language === 'PT' ? '✓ Enfermaria vazia (0 Lesões)' :
                        '✓ Medical Room Empty (0 Injured)'
                      )}
                </span>
                <p className="text-[8.5px] text-slate-400 font-medium">
                  {injuredPlayers.length > 0 
                    ? (
                        language === 'TR' ? 'Sakat oyuncular maç kadrosuna alınamaz.' :
                        language === 'DE' ? 'Verletzte Spieler können nicht nominiert werden.' :
                        language === 'ES' ? 'Los jugadores lesionados no pueden ser convocados.' :
                        language === 'FR' ? 'Les joueurs blessés ne peuvent pas être alignés.' :
                        language === 'IT' ? 'I giocatori infortunati non sono convocabili.' :
                        language === 'PT' ? 'Jogadores lesionados não podem ser convocados.' :
                        'Injured players cannot be named in the match squad.'
                      )
                    : (
                        language === 'TR' ? 'Tüm futbolcular takımla maça hazır.' :
                        language === 'DE' ? 'Alle Spieler sind einsatzbereit.' :
                        language === 'ES' ? 'Todos los jugadores están disponibles.' :
                        language === 'FR' ? 'Tous les joueurs sont aptes à jouer.' :
                        language === 'IT' ? 'Tutti i giocatori sono disponibili per la gara.' :
                        language === 'PT' ? 'Todos os jogadores estão disponíveis para o jogo.' :
                        'All players are fully fit and available.'
                      )}
                </p>
              </div>
              <div className={`p-2 rounded-xl border shrink-0 ${
                injuredPlayers.length > 0 ? 'bg-rose-900/40 border-rose-500/50 text-rose-300' : 'bg-emerald-900/40 border-emerald-500/50 text-emerald-300'
              }`}>
                <Stethoscope className="w-5 h-5" />
              </div>
            </div>

            {/* Card 2: High Risk Count */}
            <div className="bg-[#15102a] p-2.5 rounded-xl border border-[#2e2354] flex items-center justify-between shadow">
              <div className="space-y-0.5">
                <span className="text-[9px] uppercase font-black tracking-wider text-slate-400 block">
                  {language === 'TR' ? 'Yüksek Sakatlık Riski' :
                   language === 'DE' ? 'Hohes Verletzungsrisiko' :
                   language === 'ES' ? 'Alto Riesgo de Lesión' :
                   language === 'FR' ? 'Risque Élevé de Blessure' :
                   language === 'IT' ? 'Alto Rischio Infortuni' :
                   language === 'PT' ? 'Alto Risco de Lesão' :
                   'High Injury Risk'}
                </span>
                <span className="text-base font-black text-amber-400 flex items-center gap-1.5">
                  ⚠️ {highRiskPlayers.length} {
                    language === 'TR' ? 'Oyuncu Risk Altında' :
                    language === 'DE' ? 'Spieler gefährdet' :
                    language === 'ES' ? 'En Riesgo' :
                    language === 'FR' ? 'Joueurs à risque' :
                    language === 'IT' ? 'A Rischio' :
                    language === 'PT' ? 'Em Risco' :
                    'Players at Risk'
                  }
                </span>
                <p className="text-[8.5px] text-slate-400 font-medium">
                  {language === 'TR' ? 'Ağır antrenman veya düşük kondisyondaki isimler.' :
                   language === 'DE' ? 'Hohe Belastung oder geringe Ausdauer.' :
                   language === 'ES' ? 'Entrenamiento duro o baja resistencia.' :
                   language === 'FR' ? 'Charge lourde ou faible endurance.' :
                   language === 'IT' ? 'Carico pesante o bassa resistenza.' :
                   language === 'PT' ? 'Treino pesado ou baixa condição física.' :
                   'Heavy training load or low stamina players.'}
                </p>
              </div>
              <div className="p-2 rounded-xl bg-amber-900/30 border border-amber-500/40 text-amber-300 shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
            </div>

            {/* Card 3: Medical Staff Status */}
            <div className="bg-[#15102a] p-2.5 rounded-xl border border-[#2e2354] flex items-center justify-between shadow">
              <div className="space-y-0.5">
                <span className="text-[9px] uppercase font-black tracking-wider text-slate-400 block">
                  {language === 'TR' ? 'Kulüp Sağlık & Fizyoterapi Servisi' :
                   language === 'DE' ? 'Medizinischer Dienst & Physio' :
                   language === 'ES' ? 'Servicio Médico y Fisioterapia' :
                   language === 'FR' ? 'Service Médical & Kiné' :
                   language === 'IT' ? 'Servizio Medico & Fisioterapia' :
                   language === 'PT' ? 'Serviço Médico & Fisioterapia' :
                   'Club Medical & Physio Service'}
                </span>
                <span className="text-base font-black text-sky-400 flex items-center gap-1.5">
                  🏥 {
                    language === 'TR' ? 'Tesisler Aktif' :
                    language === 'DE' ? 'Einrichtungen Aktiv' :
                    language === 'ES' ? 'Instalaciones Activas' :
                    language === 'FR' ? 'Installations Actives' :
                    language === 'IT' ? 'Strutture Attive' :
                    language === 'PT' ? 'Instalações Ativas' :
                    'Facilities Active'
                  }
                </span>
                <p className="text-[8.5px] text-slate-400 font-medium">
                  {language === 'TR' ? 'Haftalık maç ve antrenman sonrası otomatik tedavi.' :
                   language === 'DE' ? 'Automatische Regeneration nach Spielen und Training.' :
                   language === 'ES' ? 'Tratamiento automático postpartido y entrenamiento.' :
                   language === 'FR' ? 'Soins automatisés après les matchs et entraînements.' :
                   language === 'IT' ? 'Recupero automatico dopo partite e allenamenti.' :
                   language === 'PT' ? 'Recuperação automática após jogos e treinos.' :
                   'Automated rehab following weekly matches and training.'}
                </p>
              </div>
              <div className="p-2 rounded-xl bg-sky-900/30 border border-sky-500/40 text-sky-300 shrink-0">
                <HeartPulse className="w-5 h-5" />
              </div>
            </div>

          </div>

          {/* Section 1: CURRENTLY INJURED PLAYERS (DETAILED BREAKDOWN) */}
          <div className="bg-[#120e24] p-2.5 sm:p-3 rounded-xl border border-[#2b214f] space-y-2">
            <div className="flex items-center justify-between border-b border-[#2a204e] pb-1.5">
              <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                <span className="text-rose-400">🚑</span>
                <span>
                  {language === 'TR' ? 'Revirdeki Sakat Oyuncular ve İyileşme Durumları' :
                   language === 'DE' ? 'Verletzte Spieler & Genesungsverlauf' :
                   language === 'ES' ? 'Jugadores en Enfermería y Recuperación' :
                   language === 'FR' ? 'Joueurs Blessés & État de Récupération' :
                   language === 'IT' ? 'Giocatori Infortunati & Decorso Clinico' :
                   language === 'PT' ? 'Jogadores na Enfermaria & Recuperação' :
                   'Injured Players & Recovery Status'}
                </span>
              </h4>
              <span className="text-[9px] px-2 py-0.2 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 font-black">
                {injuredPlayers.length} {
                  language === 'TR' ? 'Futbolcu' :
                  language === 'DE' ? 'Spieler' :
                  language === 'ES' ? 'Jugadores' :
                  language === 'FR' ? 'Joueurs' :
                  language === 'IT' ? 'Giocatori' :
                  language === 'PT' ? 'Jogadores' :
                  'Players'
                }
              </span>
            </div>

            {injuredPlayers.length === 0 ? (
              <div className="p-6 text-center bg-[#181330]/50 rounded-xl border border-dashed border-[#342759] flex flex-col items-center justify-center gap-1.5">
                <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <span className="text-sm font-black text-white">
                  {language === 'TR' ? 'Revirde Sakat Oyuncu Bulunmuyor!' :
                   language === 'DE' ? 'Keine verletzten Spieler im Lazarett!' :
                   language === 'ES' ? '¡No hay jugadores en la enfermería!' :
                   language === 'FR' ? 'Aucun joueur blessé à l’infirmerie !' :
                   language === 'IT' ? 'Nessun giocatore infortunato in infermeria!' :
                   language === 'PT' ? 'Nenhum jogador lesionado na enfermaria!' :
                   'No Injured Players in Medical Center!'}
                </span>
                <p className="text-xs text-slate-400 max-w-md">
                  {language === 'TR' ? 'Takımdaki tüm futbolcular sağlıklı durumda. Maç dizilişi ve antrenman programlarına tam kadro dahil edilebilirler.' :
                   language === 'DE' ? 'Alle Spieler im Kader sind fit. Sie können uneingeschränkt an Taktik und Training teilnehmen.' :
                   language === 'ES' ? 'Todos los futbolistas están sanos y listos para jugar o entrenar con normalidad.' :
                   language === 'FR' ? 'Tous les joueurs sont en parfaite santé et disponibles pour les matchs et entraînements.' :
                   language === 'IT' ? 'Tutti i calciatori sono in perfetta salute e a disposizione per formazione e allenamenti.' :
                   language === 'PT' ? 'Todos os jogadores estão saudáveis e totalmente disponíveis para convocatórias e treinos.' :
                   'All squad players are fully fit and available for match selection and full training regimens.'}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
                {injuredPlayers.map(p => {
                  const weeksLeft = p.injuryWeeksLeft || 1;
                  const estimatedReturnWeek = currentWeek + weeksLeft;
                  const diagnosis = getPlayerInjuryDiagnosis(p);
                  const medicalNote = getMedicalStaffRecommendation(p);

                  return (
                    <div 
                      key={p.id}
                      className="bg-[#191233] border border-rose-700/60 rounded-xl p-2.5 flex flex-col justify-between gap-2 shadow-lg hover:border-rose-500 transition-all"
                    >
                      {/* Top Player Details */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-rose-700 to-amber-700 text-white font-black text-xs flex items-center justify-center border border-rose-400/60 shadow shrink-0">
                            {p.position}
                          </div>
                          <div className="min-w-0">
                            <button
                              type="button"
                              onClick={() => onOpenPlayerProfile?.(p)}
                              className="font-black text-xs text-white hover:text-amber-300 transition-colors block truncate text-left cursor-pointer hover:underline"
                            >
                              {p.name}
                            </button>
                            <span className="text-[9px] text-slate-400 font-bold block">
                              {p.age} {language === 'TR' ? 'Yaş' : 'Yrs'} • {t('OVR_LABEL') || 'GEN'}: <strong className="text-amber-300">{p.overall}</strong> • {t('FITNESS_LABEL') || 'Kondisyon'}: <strong className="text-emerald-400">%{p.stamina}</strong>
                            </span>
                          </div>
                        </div>

                        {/* Weeks Badge */}
                        <div className="text-right shrink-0">
                          <span className="px-2 py-0.5 rounded-lg bg-rose-600 text-white font-black text-[9.5px] border border-rose-300 shadow flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {weeksLeft} {
                              language === 'TR' ? 'Hafta Kaldı' :
                              language === 'DE' ? 'Wochen verbleibend' :
                              language === 'ES' ? 'Sem. Restantes' :
                              language === 'FR' ? 'Sem. Restantes' :
                              language === 'IT' ? 'Sett. Rimanenti' :
                              language === 'PT' ? 'Sem. Restantes' :
                              'Weeks Left'
                            }
                          </span>
                          <span className="text-[8.5px] text-purple-300 font-extrabold block mt-0.5">
                            {language === 'TR' ? `Dönüş: ${estimatedReturnWeek}. Hafta` :
                             language === 'DE' ? `Rückkehr: Woche ${estimatedReturnWeek}` :
                             language === 'ES' ? `Regreso: Sem ${estimatedReturnWeek}` :
                             language === 'FR' ? `Retour: Sem ${estimatedReturnWeek}` :
                             language === 'IT' ? `Rientro: Sett ${estimatedReturnWeek}` :
                             language === 'PT' ? `Regresso: Sem ${estimatedReturnWeek}` :
                             `Return: Week ${estimatedReturnWeek}`}
                          </span>
                        </div>
                      </div>

                      {/* Diagnosis & Medical Note */}
                      <div className="bg-[#110d24] p-2 rounded-lg border border-[#2b1f4c] space-y-1.5">
                        {(() => {
                          const cat = getInjuryCategory(p);
                          return (
                            <div className="flex items-center justify-between gap-1 flex-wrap">
                              <span className={`px-2 py-0.5 rounded text-[8.5px] font-black border flex items-center gap-1 ${cat.badgeBg}`}>
                                <span>{cat.icon}</span>
                                <span>{cat.title}</span>
                              </span>
                              <span className="text-[8px] font-bold text-slate-400">
                                {language === 'TR' ? 'Tipik İyileşme:' :
                                 language === 'DE' ? 'Typische Heilung:' :
                                 language === 'ES' ? 'Recuperación típica:' :
                                 language === 'FR' ? 'Guérison typique :' :
                                 language === 'IT' ? 'Guarigione tipica:' :
                                 language === 'PT' ? 'Recuperação típica:' :
                                 'Typical Rehab:'} <strong className="text-white">{cat.avgWeeks}</strong> ({cat.recoverySpeed.split(' ')[0]})
                              </span>
                            </div>
                          );
                        })()}

                        <div className="flex items-center justify-between text-[9.5px]">
                          <span className="font-extrabold text-rose-300 flex items-center gap-1">
                            ⚠️ {language === 'TR' ? 'Teşhis:' :
                                language === 'DE' ? 'Diagnose:' :
                                language === 'ES' ? 'Diagnóstico:' :
                                language === 'FR' ? 'Diagnostic :' :
                                language === 'IT' ? 'Diagnosi:' :
                                language === 'PT' ? 'Diagnóstico:' :
                                'Diagnosis:'} <strong>{diagnosis}</strong>
                          </span>
                        </div>
                        <p className="text-[8.5px] text-slate-300 font-medium leading-relaxed">
                          🏥 <strong>{
                            language === 'TR' ? 'Sağlık Heyeti Raporu:' :
                            language === 'DE' ? 'Ärztlicher Bericht:' :
                            language === 'ES' ? 'Informe Médico:' :
                            language === 'FR' ? 'Rapport Médical :' :
                            language === 'IT' ? 'Referto Medico:' :
                            language === 'PT' ? 'Relatório Médico:' :
                            'Medical Staff Report:'
                          }</strong> {medicalNote}
                        </p>
                      </div>

                      {/* Recovery Progress Bar */}
                      <div className="space-y-0.5">
                        <div className="flex justify-between text-[8px] font-extrabold text-slate-400">
                          <span>
                            {language === 'TR' ? 'İyileşme / Tedavi Süreci' :
                             language === 'DE' ? 'Heilungs- & Behandlungsverlauf' :
                             language === 'ES' ? 'Proceso de Recuperación' :
                             language === 'FR' ? 'Processus de Rééducation' :
                             language === 'IT' ? 'Processo di Guarigione' :
                             language === 'PT' ? 'Processo de Recuperação' :
                             'Recovery & Rehab Process'}
                          </span>
                          <span className="text-emerald-400">
                            {weeksLeft === 1 
                              ? (language === 'TR' ? '%75 Tamamlandı (Son Düzlük)' : language === 'DE' ? '75% Abgeschlossen (Endphase)' : '75% Completed (Final Phase)')
                              : weeksLeft === 2 
                              ? (language === 'TR' ? '%50 Tedavi Aşaması' : language === 'DE' ? '50% Behandlungsphase' : '50% Treatment Phase') 
                              : (language === 'TR' ? '%25 Başlangıç Aşaması' : language === 'DE' ? '25% Anfangsphase' : '25% Initial Phase')}
                          </span>
                        </div>
                        <div className="w-full h-1.5 bg-[#100c22] rounded-full overflow-hidden border border-[#2d2250]">
                          <div 
                            style={{ width: `${weeksLeft === 1 ? 75 : weeksLeft === 2 ? 50 : 25}%` }}
                            className="h-full bg-gradient-to-r from-rose-500 via-amber-400 to-emerald-400 rounded-full"
                          />
                        </div>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Section 2: DEDICATED INJURY CLASSIFICATION & RECOVERY SPEED FACTORS PANEL */}
          <div className="bg-[#120e24] p-2.5 sm:p-3 rounded-xl border border-[#2b214f] space-y-2.5">
            <div className="flex items-center justify-between border-b border-[#2a204e] pb-1.5">
              <div>
                <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                  <span className="text-sky-400">🩺</span>
                  <span>
                    {language === 'TR' ? 'Sakatlık Türü Sınıflandırması & İyileşme Hızını Etkileyen Faktörler' :
                     language === 'DE' ? 'Verletzungsklassifizierung & Genesungsfaktoren' :
                     language === 'ES' ? 'Clasificación de Lesiones y Factores de Recuperación' :
                     language === 'FR' ? 'Classification des Blessures & Facteurs de Récupération' :
                     language === 'IT' ? 'Classificazione Infortuni e Fattori di Guarigione' :
                     language === 'PT' ? 'Classificação de Lesões e Fatores de Recuperação' :
                     'Injury Classification & Recovery Speed Factors'}
                  </span>
                </h4>
                <p className="text-[9px] text-slate-400">
                  {language === 'TR' ? 'Futbolcuların sakatlık çeşitleri, ortalama iyileşme süreleri ve kulüp tesisleri/tıbbi heyet çarpanları.' :
                   language === 'DE' ? 'Verletzungsarten, durchschnittliche Ausfallzeiten und Vereinseinrichtungs-Multiplikatoren.' :
                   language === 'ES' ? 'Tipos de lesión, tiempos promedio de baja y multiplicadores médicos del club.' :
                   language === 'FR' ? 'Types de blessures, durées moyennes de convalescence et multiplicateurs du staff.' :
                   language === 'IT' ? 'Tipologie di infortunio, tempi medi di recupero e moltiplicatori dello staff medico.' :
                   language === 'PT' ? 'Tipos de lesões, tempos médios de paragem e multiplicadores do corpo clínico.' :
                   'Injury categories, average recovery durations, and club facility/medical multipliers.'}
                </p>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-sky-950 text-sky-300 border border-sky-600/40 text-[8.5px] font-black hidden sm:inline-block">
                {language === 'TR' ? 'Medikal Rehber & Analiz' : 'Medical Guide & Analysis'}
              </span>
            </div>

            {/* 3 Major Injury Types Grid (Kas, Eklem, Kırık) */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
              
              {/* Type 1: Kas & Adele */}
              <div className="bg-[#17112e] p-2.5 rounded-xl border border-rose-800/40 space-y-1.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-rose-300 flex items-center gap-1">
                      ⚡ 1. {
                        language === 'TR' ? 'KAS SAKATLIKLARI' :
                        language === 'DE' ? 'MUSKELVERLETZUNGEN' :
                        language === 'ES' ? 'LESIONES MUSCULARES' :
                        language === 'FR' ? 'BLESSURES MUSCULAIRES' :
                        language === 'IT' ? 'LESIONI MUSCOLARI' :
                        language === 'PT' ? 'LESÕES MUSCULARES' :
                        'MUSCLE INJURIES'
                      }
                    </span>
                    <span className="text-[8px] font-black px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40">
                      {language === 'TR' ? 'Hızlı Rejenerasyon' : language === 'DE' ? 'Schnelle Regeneration' : 'Fast Regeneration'}
                    </span>
                  </div>
                  <span className="text-[8.5px] text-slate-400 font-bold block mt-0.5">
                    {language === 'TR' ? 'Hamstring, Kasık (Adduktor), Baldır / Soleus' :
                     language === 'DE' ? 'Oberschenkel, Adduktoren, Wade / Soleus' :
                     language === 'ES' ? 'Isquiotibiales, Aductor, Gemelo / Sóleo' :
                     language === 'FR' ? 'Ischio-jambiers, Adducteurs, Mollet' :
                     language === 'IT' ? 'Flessori, Adduttori, Polpaccio' :
                     language === 'PT' ? 'Isquiotibiais, Adutor, Gémeo / Solear' :
                     'Hamstring, Groin (Adductor), Calf / Soleus'}
                  </span>
                  <p className="text-[8.5px] text-slate-300 mt-1 leading-relaxed">
                    {language === 'TR' ? 'Aşırı yüklenme ve sprint zorlanmaları sonucu oluşur. Adele lifleri kan dolaşımı yüksek olduğu için doğru masaj ve dinlenme ile en hızlı toparlanan dokudur.' :
                     language === 'DE' ? 'Entsteht durch Überlastung und Sprintantritte. Hohe Durchblutung ermöglicht rasche Regeneration bei adäquater Schonung.' :
                     language === 'ES' ? 'Causada por sobrecargas y sprints. Su alta vascularización permite una pronta recuperación con fisioterapia y descanso.' :
                     language === 'FR' ? 'Provoquée par les surcharges et sprints intenses. Sa forte vascularisation permet une récupération rapide avec repos adapté.' :
                     language === 'IT' ? 'Causata da sovraccarico e scatti. L’elevata vascolarizzazione consente una rapida rigenerazione con riposo adeguato.' :
                     language === 'PT' ? 'Provocada por sobrecargas e sprints. A alta vascularização permite uma regeneração rápida com repouso adequado.' :
                     'Caused by overloading and sprint strains. High blood supply enables the fastest recovery when managed with targeted rest.'}
                  </p>
                </div>
                <div className="pt-1.5 border-t border-[#261d47] flex items-center justify-between text-[8px] font-black">
                  <span className="text-slate-400">
                    {language === 'TR' ? 'Ortalama Tedavi:' :
                     language === 'DE' ? 'Durchschnittliche Ausfallzeit:' :
                     language === 'ES' ? 'Tratamiento Medio:' :
                     language === 'FR' ? 'Traitement Moyen :' :
                     language === 'IT' ? 'Trattamento Medio:' :
                     language === 'PT' ? 'Tratamento Médio:' :
                     'Average Recovery:'}
                  </span>
                  <span className="text-emerald-400 font-extrabold">1 - 3 {language === 'TR' ? 'Hafta' : language === 'DE' ? 'Wochen' : 'Weeks'}</span>
                </div>
              </div>

              {/* Type 2: Eklem & Bağ */}
              <div className="bg-[#17112e] p-2.5 rounded-xl border border-amber-800/40 space-y-1.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-amber-300 flex items-center gap-1">
                      🦵 2. {
                        language === 'TR' ? 'EKLEM & BAĞ SAKATLIKLARI' :
                        language === 'DE' ? 'GELENK- & BÄNDERVERLETZUNGEN' :
                        language === 'ES' ? 'LESIONES ARTICULARES Y DE LIGAMENTOS' :
                        language === 'FR' ? 'LÉSIONS ARTICULAIRES & LIGAMENTAIRES' :
                        language === 'IT' ? 'LESIONI ARTICOLARI E LEGAMENTOSE' :
                        language === 'PT' ? 'LESÕES ARTICULARES E DE LIGAMENTOS' :
                        'JOINT & LIGAMENT INJURIES'
                      }
                    </span>
                    <span className="text-[8px] font-black px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                      {language === 'TR' ? 'Orta Hız / Dikkatli Yükleme' : language === 'DE' ? 'Mittlere Dauer' : 'Moderate Speed'}
                    </span>
                  </div>
                  <span className="text-[8.5px] text-slate-400 font-bold block mt-0.5">
                    {language === 'TR' ? 'Ayak Bileği Bağları, Menisküs, Çapraz Bağ, Omuz' :
                     language === 'DE' ? 'Sprunggelenk, Meniskus, Kreuzband, Schulter' :
                     language === 'ES' ? 'Tobillo, Menisco, Ligamento Cruzado, Hombro' :
                     language === 'FR' ? 'Cheville, Ménisque, Ligaments croisés, Épaule' :
                     language === 'IT' ? 'Caviglia, Menisco, Crociato, Spalla' :
                     language === 'PT' ? 'Tornozelo, Menisco, Ligamento Cruzado, Ombro' :
                     'Ankle Ligaments, Meniscus, Cruciate Ligaments, Shoulder'}
                  </span>
                  <p className="text-[8.5px] text-slate-300 mt-1 leading-relaxed">
                    {language === 'TR' ? 'Dönme, burkulma ve darbeler sonucu eklem kapsülü ve bağ dokusunda esneme veya yırtık meydana gelir. Kan akışı az olduğundan bağ dokusu aşamalı iyileşir.' :
                     language === 'DE' ? 'Entsteht durch Verdrehungen und Stöße. Wegen geringerer Durchblutung heilen Bänder schrittweise.' :
                     language === 'ES' ? 'Consecuencia de torsiones o impactos. Su menor flujo sanguíneo exige una curación gradual.' :
                     language === 'FR' ? 'Provoquée par des torsions ou chocs. La faible vascularisation exige une reprise graduelle.' :
                     language === 'IT' ? 'Dovuto a torsioni o impatti. La minore vascolarizzazione richiede una guarigione progressiva.' :
                     language === 'PT' ? 'Devido a entorses ou pancadas. A menor vascularização exige recuperação progressiva.' :
                     'Twisting, impact sprains, or tears. Slower blood perfusion requires staged reconditioning.'}
                  </p>
                </div>
                <div className="pt-1.5 border-t border-[#261d47] flex items-center justify-between text-[8px] font-black">
                  <span className="text-slate-400">
                    {language === 'TR' ? 'Ortalama Tedavi:' :
                     language === 'DE' ? 'Durchschnittliche Ausfallzeit:' :
                     language === 'ES' ? 'Tratamiento Medio:' :
                     language === 'FR' ? 'Traitement Moyen :' :
                     language === 'IT' ? 'Trattamento Medio:' :
                     language === 'PT' ? 'Tratamento Médio:' :
                     'Average Recovery:'}
                  </span>
                  <span className="text-amber-400 font-extrabold">2 - 5 {language === 'TR' ? 'Hafta' : language === 'DE' ? 'Wochen' : 'Weeks'}</span>
                </div>
              </div>

              {/* Type 3: Kırık & Kemik */}
              <div className="bg-[#17112e] p-2.5 rounded-xl border border-purple-800/40 space-y-1.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-purple-300 flex items-center gap-1">
                      🦴 3. {
                        language === 'TR' ? 'KIRIK & KEMİK ZEDELENMESİ' :
                        language === 'DE' ? 'FRAKTUREN & KNOCHENVERLETZUNGEN' :
                        language === 'ES' ? 'FRACTURAS Y LESIONES ÓSEAS' :
                        language === 'FR' ? 'FRACTURES & LÉSIONS OSSEUSES' :
                        language === 'IT' ? 'FRATTURE E LESIONI OSSEE' :
                        language === 'PT' ? 'FRATURAS E LESÕES ÓSSEAS' :
                        'FRACTURES & BONE INJURIES'
                      }
                    </span>
                    <span className="text-[8px] font-black px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40">
                      {language === 'TR' ? 'Yavaş / Tam Kaynama' : language === 'DE' ? 'Langsame Heilung' : 'Slow / Full Consolidation'}
                    </span>
                  </div>
                  <span className="text-[8.5px] text-slate-400 font-bold block mt-0.5">
                    {language === 'TR' ? 'Metatars Tarak Kemiği, Kaval Stres Kırığı, Kaburga' :
                     language === 'DE' ? 'Mittelfußknochen, Schienbein-Stressfraktur, Rippe' :
                     language === 'ES' ? 'Metatarsiano, Fisura de Tibia, Costilla' :
                     language === 'FR' ? 'Métatarse, Fracture de fatigue tibia, Côte' :
                     language === 'IT' ? 'Metatarso, Frattura da stress tibia, Costola' :
                     language === 'PT' ? 'Metatarso, Fratura de stress tíbia, Costelas' :
                     'Metatarsal, Shin Stress Fracture, Rib'}
                  </span>
                  <p className="text-[8.5px] text-slate-300 mt-1 leading-relaxed">
                    {language === 'TR' ? 'Sert darbeler veya tekrarlayan yoğun stres kırıklarıdır. Kalsifikasyon ve kemik kaynaması tamamlanmadan sahaya çıkılması kalıcı hasar yaratabilir.' :
                     language === 'DE' ? 'Schwere Stöße oder chronische Ermüdungsbrüche. Vollständige Knochenheilung vor Belastung zwingend.' :
                     language === 'ES' ? 'Impactos fuertes o fracturas por sobrecarga. Requiere unión ósea total antes del esfuerzo.' :
                     language === 'FR' ? 'Chocs violents ou fractures de fatigue. La consolidation complète est obligatoire avant reprise.' :
                     language === 'IT' ? 'Duri impatti o fratture da stress. Necessaria calcificazione completa prima dello sforzo.' :
                     language === 'PT' ? 'Impactos violentos ou fraturas de esforço. Requer consolidação total antes do regresso.' :
                     'Severe impact or repetitive stress fractures. Bone consolidation must complete before bearing load.'}
                  </p>
                </div>
                <div className="pt-1.5 border-t border-[#261d47] flex items-center justify-between text-[8px] font-black">
                  <span className="text-slate-400">
                    {language === 'TR' ? 'Ortalama Tedavi:' :
                     language === 'DE' ? 'Durchschnittliche Ausfallzeit:' :
                     language === 'ES' ? 'Tratamiento Medio:' :
                     language === 'FR' ? 'Traitement Moyen :' :
                     language === 'IT' ? 'Trattamento Medio:' :
                     language === 'PT' ? 'Tratamento Médio:' :
                     'Average Recovery:'}
                  </span>
                  <span className="text-purple-400 font-extrabold">4 - 8 {language === 'TR' ? 'Hafta' : language === 'DE' ? 'Wochen' : 'Weeks'}</span>
                </div>
              </div>

            </div>

            {/* Recovery Speed Modifiers / Facility Factors */}
            <div className="bg-[#16112d] p-2.5 rounded-xl border border-[#2e2354] space-y-1.5">
              <span className="text-[9.5px] font-black text-white uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  {language === 'TR' ? 'İyileşme Hızını Etkileyen Faktörler & Çarpanlar' :
                   language === 'DE' ? 'Faktoren für Genesungsgeschwindigkeit & Multiplikatoren' :
                   language === 'ES' ? 'Factores y Multiplicadores de Recuperación' :
                   language === 'FR' ? 'Facteurs & Multiplicateurs de Récupération' :
                   language === 'IT' ? 'Fattori & Moltiplicatori di Guarigione' :
                   language === 'PT' ? 'Fatores e Multiplicadores de Recuperação' :
                   'Recovery Speed Factors & Multipliers'}
                </span>
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                {getRecoveryFactors(injuredPlayers[0] || selectedPlayer).map((f, idx) => (
                  <div key={idx} className="bg-[#100c22] p-2 rounded-lg border border-[#291f4a] space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] font-extrabold text-white flex items-center gap-1">
                        <span>{f.icon}</span>
                        <span className="truncate">{f.title}</span>
                      </span>
                    </div>
                    <span className={`text-[8.5px] font-black block ${f.color}`}>
                      {f.level}
                    </span>
                    <p className="text-[8px] text-slate-400 leading-snug">
                      {f.detail}
                    </p>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Section 3: COMPLETE SQUAD INJURY RISK & STAMINA TABLE */}
          <div className="bg-[#120e24] p-2.5 sm:p-3 rounded-xl border border-[#2b214f] space-y-2">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1.5 border-b border-[#2a204e] pb-1.5">
              <div>
                <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-emerald-400" />
                  <span>
                    {language === 'TR' ? 'Tüm Kadro Sakatlık Riski & Kondisyon Durumu' :
                     language === 'DE' ? 'Kader-Verletzungsrisiko & Ausdauerstatus' :
                     language === 'ES' ? 'Riesgo de Lesión y Condición Física de la Plantilla' :
                     language === 'FR' ? 'Risque de Blessure & Condition Physique de l’Effectif' :
                     language === 'IT' ? 'Rischio Infortuni & Condizione Atletica della Rosa' :
                     language === 'PT' ? 'Risco de Lesão & Condição Física do Plantel' :
                     'Squad Injury Risk & Stamina Status'}
                  </span>
                </h4>
                <p className="text-[9px] text-slate-400">
                  {language === 'TR' ? 'Yaş, antrenman yükü ve kondisyon oranına göre hesaplanan anlık sağlık tablosu.' :
                   language === 'DE' ? 'Berechnet nach Alter, Trainingsbelastung und Ausdauerwert.' :
                   language === 'ES' ? 'Calculado según edad, carga de entrenamiento y nivel de resistencia.' :
                   language === 'FR' ? 'Calculé selon l’âge, la charge d’entraînement et l’endurance.' :
                   language === 'IT' ? 'Calcolato in base a età, carico di lavoro e livello di stamina.' :
                   language === 'PT' ? 'Calculado de acordo com a idade, carga de treino e condição física.' :
                   'Real-time health matrix calculated based on age, training intensity, and stamina.'}
                </p>
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center gap-1 bg-[#1a1433] p-0.5 rounded-lg border border-[#312557] text-[9px] font-extrabold">
                <button
                  onClick={() => setInjuryListFilter('ALL')}
                  className={`px-2 py-0.5 rounded transition-all cursor-pointer ${
                    injuryListFilter === 'ALL' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {language === 'TR' ? `Tüm Kadro (${currentTeam.players.length})` :
                   language === 'DE' ? `Gesamter Kader (${currentTeam.players.length})` :
                   language === 'ES' ? `Toda la Plantilla (${currentTeam.players.length})` :
                   language === 'FR' ? `Tout l'Effectif (${currentTeam.players.length})` :
                   language === 'IT' ? `Tutta la Rosa (${currentTeam.players.length})` :
                   language === 'PT' ? `Todo o Plantel (${currentTeam.players.length})` :
                   `Full Squad (${currentTeam.players.length})`}
                </button>
                <button
                  onClick={() => setInjuryListFilter('INJURED_ONLY')}
                  className={`px-2 py-0.5 rounded transition-all cursor-pointer ${
                    injuryListFilter === 'INJURED_ONLY' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {language === 'TR' ? `Sadece Sakatlar (${injuredPlayers.length})` :
                   language === 'DE' ? `Nur Verletzte (${injuredPlayers.length})` :
                   language === 'ES' ? `Solo Lesionados (${injuredPlayers.length})` :
                   language === 'FR' ? `Blessés Uniquement (${injuredPlayers.length})` :
                   language === 'IT' ? `Solo Infortunati (${injuredPlayers.length})` :
                   language === 'PT' ? `Apenas Lesionados (${injuredPlayers.length})` :
                   `Injured Only (${injuredPlayers.length})`}
                </button>
                <button
                  onClick={() => setInjuryListFilter('HIGH_RISK')}
                  className={`px-2 py-0.5 rounded transition-all cursor-pointer ${
                    injuryListFilter === 'HIGH_RISK' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {language === 'TR' ? `Risk Altındakiler (${highRiskPlayers.length + injuredPlayers.length})` :
                   language === 'DE' ? `Gefährdete (${highRiskPlayers.length + injuredPlayers.length})` :
                   language === 'ES' ? `En Riesgo (${highRiskPlayers.length + injuredPlayers.length})` :
                   language === 'FR' ? `Joueurs à Risque (${highRiskPlayers.length + injuredPlayers.length})` :
                   language === 'IT' ? `A Rischio (${highRiskPlayers.length + injuredPlayers.length})` :
                   language === 'PT' ? `Em Risco (${highRiskPlayers.length + injuredPlayers.length})` :
                   `At Risk (${highRiskPlayers.length + injuredPlayers.length})`}
                </button>
              </div>
            </div>

            {/* Squad Medical Table */}
            <div className="overflow-x-auto custom-scrollbar">
              <table className="w-full text-left text-[10px]">
                <thead>
                  <tr className="border-b border-[#251c47] text-[8.5px] font-black uppercase text-slate-400 tracking-wider">
                    <th className="py-1 px-1.5">{t('PLAYER_LABEL') || 'OYUNCU'}</th>
                    <th className="py-1 px-1.5 text-center">{t('POSITION_LABEL') || 'MEVKİ'}</th>
                    <th className="py-1 px-1.5 text-center">{t('AGE_LABEL') || 'YAŞ'}</th>
                    <th className="py-1 px-1.5 text-center">{t('OVR_LABEL') || 'GEN'}</th>
                    <th className="py-1 px-1.5 text-center">{t('FITNESS_LABEL') || 'KONDİSYON'}</th>
                    <th className="py-1 px-1.5 text-center">
                      {language === 'TR' ? 'ANT. YÜKÜ' :
                       language === 'DE' ? 'TRAIN. INTENSITÄT' :
                       language === 'ES' ? 'INTENSIDAD' :
                       language === 'FR' ? 'INTENSITÉ' :
                       language === 'IT' ? 'INTENSITÀ' :
                       language === 'PT' ? 'INTENSIDADE' :
                       'INTENSITY'}
                    </th>
                    <th className="py-1 px-1.5 text-center">
                      {language === 'TR' ? 'SAKATLIK RİSKİ' :
                       language === 'DE' ? 'RISIKO' :
                       language === 'ES' ? 'RIESGO' :
                       language === 'FR' ? 'RISQUE' :
                       language === 'IT' ? 'RISCHIO' :
                       language === 'PT' ? 'RISCO' :
                       'INJURY RISK'}
                    </th>
                    <th className="py-1 px-1.5 text-right">{t('STATUS') || 'DURUM'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1e173b]">
                  {filteredSquadList.map(p => {
                    const risk = getPlayerRiskAssessment(p);
                    const isInj = p.isInjured || (p.injuryWeeksLeft && p.injuryWeeksLeft > 0);

                    return (
                      <tr 
                        key={p.id}
                        onClick={() => {
                          setSelectedPlayerId(p.id);
                        }}
                        className={`hover:bg-[#1f183d] transition-colors cursor-pointer ${
                          isInj ? 'bg-rose-950/20' : ''
                        }`}
                      >
                        {/* Name */}
                        <td className="py-1.5 px-1.5 font-black text-white">
                          <div className="flex items-center gap-1.5">
                            <span 
                              onClick={(e) => {
                                e.stopPropagation();
                                onOpenPlayerProfile?.(p);
                              }}
                              className="hover:text-amber-300 hover:underline transition-colors"
                              title="Profili Aç"
                            >
                              {p.name}
                            </span>
                            {isInj && <span className="text-[9px]">🚑</span>}
                          </div>
                        </td>

                        {/* Position */}
                        <td className="py-1.5 px-1.5 text-center">
                          <span className="px-1.5 py-0.2 rounded bg-[#231a44] text-purple-300 font-extrabold text-[8.5px]">
                            {p.position}
                          </span>
                        </td>

                        {/* Age */}
                        <td className="py-1.5 px-1.5 text-center font-bold text-slate-300">
                          {p.age}
                        </td>

                        {/* OVR */}
                        <td className="py-1.5 px-1.5 text-center font-black text-amber-300">
                          {p.overall}
                        </td>

                        {/* Stamina */}
                        <td className="py-1.5 px-1.5 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <div className="w-12 h-1.5 bg-[#100c22] rounded-full overflow-hidden border border-[#2d2250] hidden sm:block">
                              <div 
                                style={{ width: `${p.stamina ?? 100}%` }}
                                className={`h-full rounded-full ${
                                  (p.stamina ?? 100) > 80 ? 'bg-emerald-400' : (p.stamina ?? 100) > 60 ? 'bg-amber-400' : 'bg-rose-500'
                                }`}
                              />
                            </div>
                            <span className={`font-black text-[9px] ${
                              (p.stamina ?? 100) > 80 ? 'text-emerald-400' : (p.stamina ?? 100) > 60 ? 'text-amber-400' : 'text-rose-400'
                            }`}>
                              %{p.stamina ?? 100}
                            </span>
                          </div>
                        </td>

                        {/* Training Intensity */}
                        <td className="py-1.5 px-1.5 text-center">
                          <span className={`px-1.5 py-0.2 rounded text-[8.5px] font-black ${
                            p.trainingIntensity === 'Ağır' 
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' 
                              : p.trainingIntensity === 'Hafif' 
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
                              : 'bg-slate-800 text-slate-300'
                          }`}>
                            {p.trainingIntensity === 'Ağır' 
                              ? (language === 'TR' ? 'Ağır' : language === 'DE' ? 'Schwer' : language === 'ES' ? 'Pesado' : language === 'FR' ? 'Lourd' : language === 'IT' ? 'Pesante' : language === 'PT' ? 'Pesado' : 'Heavy')
                              : p.trainingIntensity === 'Hafif'
                              ? (language === 'TR' ? 'Hafif' : language === 'DE' ? 'Leicht' : language === 'ES' ? 'Ligero' : language === 'FR' ? 'Léger' : language === 'IT' ? 'Leggero' : language === 'PT' ? 'Leve' : 'Light')
                              : (language === 'TR' ? 'Normal' : language === 'DE' ? 'Normal' : language === 'ES' ? 'Normal' : language === 'FR' ? 'Normal' : language === 'IT' ? 'Normale' : language === 'PT' ? 'Normal' : 'Normal')}
                          </span>
                        </td>

                        {/* Risk Assessment */}
                        <td className="py-1.5 px-1.5 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[8px] font-black border uppercase inline-flex items-center gap-1 ${risk.badgeColor}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${risk.dotColor}`} />
                            <span>{risk.badge}</span>
                          </span>
                        </td>

                        {/* Status / Note */}
                        <td className="py-1.5 px-1.5 text-right font-extrabold">
                          {isInj ? (
                            <span className="text-rose-400 font-black text-[9px] bg-rose-950/80 px-1.5 py-0.5 rounded border border-rose-600/50">
                              🏥 {p.injuryWeeksLeft || 1} {language === 'TR' ? 'Hf Sakat' : language === 'DE' ? 'Wo. verletzt' : 'Wk Injured'}
                            </span>
                          ) : (
                            <span className="text-emerald-400 font-bold text-[9px]">
                              {language === 'TR' ? '✓ Sahaya Hazır' :
                               language === 'DE' ? '✓ Einsatzbereit' :
                               language === 'ES' ? '✓ Disponible' :
                               language === 'FR' ? '✓ Disponible' :
                               language === 'IT' ? '✓ Pronto' :
                               language === 'PT' ? '✓ Disponível' :
                               '✓ Match Ready'}
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
