import React, { useState } from 'react';
import { Team, Player, Fixture } from '../types';
import { X, Shield, Award, Users, DollarSign, Trophy, Sparkles, Building2, User, History } from 'lucide-react';
import { useTranslation } from '../utils/i18n';
import { ensureTeamHas20Players } from '../utils/squadExpander';
import { getClubLastSeasonRank, getClubHistoricalFinishes } from '../data/historicalStandings';

interface TeamDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  team: Team;
  allTeams?: Team[];
  fixtures?: Fixture[];
  userTeamId?: string;
  onSelectPlayerProfile?: (player: Player, team?: Team) => void;
}

export const TeamDetailModal: React.FC<TeamDetailModalProps> = ({
  isOpen,
  onClose,
  team: rawTeam,
  allTeams = [],
  fixtures = [],
  userTeamId,
  onSelectPlayerProfile
}) => {
  const { t, language } = useTranslation();
  if (!isOpen || !rawTeam) return null;

  const team = ensureTeamHas20Players(rawTeam);
  const isTr = (language || 'TR').toUpperCase() === 'TR';

  const [activeTab, setActiveTab] = useState<'REPORT' | 'SQUAD'>('REPORT');

  const avgOvr = Math.round(
    team.players.reduce((sum, p) => sum + p.overall, 0) / (team.players.length || 1)
  );

  // Recent 5 match results for team
  const playedTeamFixtures = fixtures
    .filter(f => f.played && (f.homeTeamId === team.id || f.awayTeamId === team.id))
    .slice(-5);

  const getLocalizedText = (tr: string, en: string, es: string, fr: string, it: string, de: string, pt: string) => {
    const lang = (language || 'TR').toUpperCase();
    if (lang === 'EN') return en;
    if (lang === 'ES') return es;
    if (lang === 'FR') return fr;
    if (lang === 'IT') return it;
    if (lang === 'DE') return de;
    if (lang === 'PT') return pt;
    return tr;
  };

  return (
    <div className="fixed inset-0 z-[9985] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-[#181528] border-2 border-[#3d2f63] rounded-2xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden my-auto text-slate-100 font-sans">
        
        {/* Header */}
        <div className={`p-4 bg-gradient-to-r ${team.badgeColor || 'from-purple-900 to-indigo-900'} border-b border-[#3d2f63] flex items-center justify-between`}>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-slate-950/70 border border-white/20 flex items-center justify-center font-black text-lg text-white shadow-lg shrink-0">
              {team.shortName || team.name.slice(0, 3).toUpperCase()}
            </div>
            <div>
              <h2 className="font-black text-white text-base sm:text-xl drop-shadow">{team.name}</h2>
              <div className="flex items-center gap-2 text-xs text-slate-200/90 font-semibold mt-0.5">
                <span className="flex items-center gap-1">
                  <Building2 className="w-3 h-3" /> 
                  {team.stadium || team.stadiumName || getLocalizedText('Stadyum', 'Stadium', 'Estadio', 'Stade', 'Stadio', 'Stadion', 'Estádio')}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <User className="w-3 h-3" /> 
                  {getLocalizedText('T.D:', 'Mgr:', 'Entr:', 'Entr:', 'All:', 'Tr:', 'Trein:')} {team.manager || getLocalizedText('Teknik Direktör', 'Manager', 'Entrenador', 'Entraîneur', 'Allenatore', 'Trainer', 'Treinador')}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-950/50 hover:bg-slate-950/80 text-white transition-colors border border-white/20 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="bg-[#120f21] px-4 pt-2 border-b border-[#2d244c] flex items-center gap-2">
          <button
            onClick={() => setActiveTab('REPORT')}
            className={`px-4 py-2 font-black text-xs uppercase tracking-wider rounded-t-xl transition-all border-t border-x cursor-pointer ${
              activeTab === 'REPORT'
                ? 'bg-[#181528] text-amber-300 border-[#3d2f63]'
                : 'bg-transparent text-slate-400 border-transparent hover:text-white'
            }`}
          >
            📊 {t('CLUB_REPORT_FORM') || getLocalizedText('KULÜP RAPORU & FORM', 'CLUB REPORT & FORM', 'INFORME DEL CLUB Y FORMA', 'RAPPORT DU CLUB ET FORME', 'RAPPORTO SQUADRA E FORMA', 'VEREINSBERICHT & FORM', 'RELATÓRIO DO CLUBE E FORMA')}
          </button>
          <button
            onClick={() => setActiveTab('SQUAD')}
            className={`px-4 py-2 font-black text-xs uppercase tracking-wider rounded-t-xl transition-all border-t border-x cursor-pointer ${
              activeTab === 'SQUAD'
                ? 'bg-[#181528] text-amber-300 border-[#3d2f63]'
                : 'bg-transparent text-slate-400 border-transparent hover:text-white'
            }`}
          >
            📋 {getLocalizedText(`KADRO (${team.players.length})`, `SQUAD (${team.players.length})`, `PLANTILLA (${team.players.length})`, `EFFECTIF (${team.players.length})`, `ROSA (${team.players.length})`, `KADER (${team.players.length})`, `PLANTEL (${team.players.length})`)}
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3 custom-scrollbar bg-[#18142a]">
          
          {/* TAB 1: REPORT & FORM */}
          {activeTab === 'REPORT' && (
            <div className="space-y-3">
              
              {/* Stats Overview */}
              <div className="bg-[#120f21] p-3 rounded-xl border border-[#2d244c] space-y-2">
                <span className="text-xs font-black text-amber-300 uppercase tracking-wider block">
                  ⭐ {t('SQUAD_QUALITY_BUDGET') || getLocalizedText('Kadro Kalitesi & Bütçe', 'Squad Quality & Budget', 'Calidad de Plantilla y Presupuesto', 'Qualité de l\'Effectif et Budget', 'Qualità Rosa e Bilancio', 'Kaderqualität & Budget', 'Qualidade do Plantel e Orçamento')}
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <div className="p-2.5 rounded-lg bg-[#19142e] border border-[#312754]">
                    <span className="text-[9.5px] text-slate-400 uppercase font-bold block">{t('AVG_OVR_SHORT') || getLocalizedText('ORT. GEN', 'AVG OVR', 'MED GEN', 'MOY GEN', 'MED GEN', 'DURSCHN. OVR', 'MÉD GEN')}</span>
                    <span className="font-black text-sky-400 text-sm">{avgOvr} OVR</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#19142e] border border-[#312754]">
                    <span className="text-[9.5px] text-slate-400 uppercase font-bold block">{t('SQUAD_COUNT') || getLocalizedText('OYUNCU SAYISI', 'PLAYERS', 'JUGADORES', 'JOUEURS', 'GIOCATORI', 'SPIELER', 'JOGADORES')}</span>
                    <span className="font-black text-white text-sm">{team.players.length}</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#19142e] border border-[#312754]">
                    <span className="text-[9.5px] text-slate-400 uppercase font-bold block">{t('CLUB_BUDGET') || getLocalizedText('BÜTÇE', 'BUDGET', 'PRESUPUESTO', 'BUDGET', 'BILANCIO', 'BUDGET', 'ORÇAMENTO')}</span>
                    <span className="font-black text-amber-300 text-sm">€{(team.budget / 1_000_000).toFixed(1)}M</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#19142e] border border-[#312754]">
                    <span className="text-[9.5px] text-slate-400 uppercase font-bold block">{t('FORMATION_LABEL') || getLocalizedText('DİZİLİŞ', 'FORMATION', 'FORMACIÓN', 'FORMATION', 'FORMAZIONE', 'FORMATION', 'FORMAÇÃO')}</span>
                    <span className="font-black text-purple-300 text-xs">{team.formation || '4-3-3'}</span>
                  </div>
                </div>
              </div>

              {/* Recent 5 Matches Form */}
              <div className="bg-[#120f21] p-3 rounded-xl border border-[#2d244c] space-y-2">
                <span className="text-xs font-black text-sky-400 uppercase tracking-wider block">
                  📈 {getLocalizedText('Son 5 Maçlık Form Durumu', 'Recent 5 Match Form', 'Forma en los Últimos 5 Partidos', 'Forme des 5 Derniers Matchs', 'Forma nelle Ultime 5 Partite', 'Form der Letzten 5 Spiele', 'Forma nos Últimos 5 Jogos')}
                </span>

                {playedTeamFixtures.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">
                    {getLocalizedText('Henüz oynanmış maç verisi bulunmuyor.', 'No played matches recorded yet.', 'Aún no hay partidos jugados registrados.', 'Aucun match joué enregistré pour le moment.', 'Nessuna partita giocata ancora registrata.', 'Noch keine Spieldaten vorhanden.', 'Nenhuma partida disputada registrada ainda.')}
                  </p>
                ) : (
                  <div className="flex items-center gap-2 overflow-x-auto custom-scrollbar pb-1">
                    {playedTeamFixtures.map(f => {
                      const isHome = f.homeTeamId === team.id;
                      const oppId = isHome ? f.awayTeamId : f.homeTeamId;
                      const opp = allTeams.find(t => t.id === oppId);
                      const myScore = isHome ? (f.homeScore || 0) : (f.awayScore || 0);
                      const oppScore = isHome ? (f.awayScore || 0) : (f.homeScore || 0);

                      let badge = isTr ? 'B' : 'D';
                      let badgeBg = 'bg-amber-500/20 text-amber-300 border-amber-500/40';
                      if (myScore > oppScore) {
                        badge = isTr ? 'G' : 'W';
                        badgeBg = 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
                      } else if (myScore < oppScore) {
                        badge = isTr ? 'M' : 'L';
                        badgeBg = 'bg-rose-500/20 text-rose-400 border-rose-500/40';
                      }

                      return (
                        <div key={f.id} className="p-2 rounded-lg bg-[#19142e] border border-[#312754] flex items-center gap-2 shrink-0">
                          <span className={`w-6 h-6 rounded-md font-black text-xs flex items-center justify-center border ${badgeBg}`}>
                            {badge}
                          </span>
                          <div className="text-[10px]">
                            <span className="font-bold text-white block">{opp ? opp.shortName : oppId}</span>
                            <span className="text-slate-400 font-semibold">{myScore} - {oppScore}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Past Season Rank & Historical Finishes */}
              {(() => {
                const lastSeason = getClubLastSeasonRank(team.id || team.name);
                const allFinishes = getClubHistoricalFinishes(team.id || team.name);

                return (
                  <div className="bg-[#120f21] p-3 rounded-xl border border-[#2d244c] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                        <Trophy className="w-3.5 h-3.5 text-amber-400" />
                        {getLocalizedText('Geçen Sezon Lig Sıralaması (2024/25)', 'Last Season League Rank (2024/25)', 'Clasificación de la Temporada Pasada (2024/25)', 'Classement de la Saison Dernière (2024/25)', 'Classifica Scorsa Stagione (2024/25)', 'Vorjahresplatzierung (2024/25)', 'Classificação da Temporada Passada (2024/25)')}
                      </span>
                      {lastSeason && (
                        <span className={`px-2 py-0.5 rounded-lg text-xs font-black border ${
                          lastSeason.rank === 1
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                            : lastSeason.rank <= 4
                            ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                            : 'bg-purple-500/20 text-purple-300 border-purple-500/40'
                        }`}>
                          {lastSeason.rank}. {getLocalizedText('Sıra', 'Place', 'Puesto', 'Place', 'Posto', 'Platz', 'Lugar')} ({lastSeason.points} {getLocalizedText('Puan', 'Pts', 'Pts', 'Pts', 'Punti', 'Pkt', 'Pts')})
                        </span>
                      )}
                    </div>

                    {lastSeason && (
                      <div className="bg-[#19142e] p-2.5 rounded-lg border border-[#312754] flex items-center justify-between text-xs">
                        <div>
                          <span className="text-white font-extrabold text-xs block">
                            {lastSeason.title || `${lastSeason.rank}. Sırada Tamamladı`}
                          </span>
                          <span className="text-[10px] text-slate-400 font-semibold">
                            {lastSeason.status || 'Süper Lig'}
                          </span>
                        </div>
                        <span className="text-amber-400 font-black text-sm">
                          {lastSeason.points} Pts
                        </span>
                      </div>
                    )}

                    {/* Historical Finishes Table */}
                    {allFinishes.length > 0 && (
                      <div className="pt-1">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                          {getLocalizedText('Geçmiş Sezon Dereceleri', 'Historical Season Finishes', 'Resultados Históricos', 'Résultats Historiques', 'Piazzamenti Storici', 'Historische Saisonergebnisse', 'Desempenho Histórico')}
                        </span>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs">
                          {allFinishes.slice(0, 4).map((fin, idx) => (
                            <div key={idx} className="p-2 rounded-lg bg-[#19142e] border border-[#312754] flex flex-col justify-between">
                              <div className="flex items-center justify-between text-[9px] text-slate-400 font-bold">
                                <span>{fin.season}</span>
                                <span className="text-purple-300 font-extrabold">{fin.rank}. {getLocalizedText('Sıra', 'Place', 'Puesto', 'Place', 'Posto', 'Platz', 'Lugar')}</span>
                              </div>
                              <div className="mt-1 flex items-center justify-between">
                                <span className="text-[10px] font-black text-amber-300 truncate mr-1">
                                  {fin.title || fin.status || '-'}
                                </span>
                                <span className="text-[9px] text-slate-300 font-extrabold shrink-0">
                                  {fin.points} P
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}

            </div>
          )}

          {/* TAB 2: FULL SQUAD LIST */}
          {activeTab === 'SQUAD' && (
            <div className="space-y-1.5 max-h-[480px] overflow-y-auto custom-scrollbar pr-1">
              {team.players.map(p => (
                <div
                  key={p.id}
                  onClick={() => {
                    if (onSelectPlayerProfile) {
                      onSelectPlayerProfile(p, team);
                      onClose();
                    }
                  }}
                  className="bg-[#120f21] hover:bg-[#1f1938] p-2.5 rounded-xl border border-[#2d244c] hover:border-purple-500/50 transition-all flex items-center justify-between cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className={`w-7 h-7 rounded-lg font-black text-[10px] flex items-center justify-center border shrink-0 ${
                      p.position === 'GK'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                        : p.position === 'DEF'
                        ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                        : p.position === 'MID'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    }`}>
                      {p.specificRole || p.position}
                    </span>
                    <div className="min-w-0">
                      <span className="font-extrabold text-xs text-white block truncate group-hover:text-amber-300">
                        {p.name}
                      </span>
                      <span className="text-[10px] text-slate-400 block font-semibold">
                        {p.age} {t('YEARS_OLD') || getLocalizedText('Yaş', 'yo', 'años', 'ans', 'anni', 'J.', 'anos')} • {p.nationality || 'Türkiye'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 font-semibold block">{t('MARKET_VALUE') || getLocalizedText('Piyasa Değeri', 'Market Value', 'Valor de Mercado', 'Valeur Marchande', 'Valore di Mercato', 'Marktwert', 'Valor de Mercado')}</span>
                      <span className="text-xs font-black text-amber-300">
                        €{((p.marketValue || 5000000) / 1_000_000).toFixed(1)}M
                      </span>
                    </div>
                    <span className="px-2 py-1 rounded-lg bg-purple-950/80 border border-purple-500/40 text-amber-300 font-black text-xs">
                      {p.overall} OVR
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};

