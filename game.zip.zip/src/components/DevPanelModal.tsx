import React, { useState, useEffect, useMemo } from 'react';
import { 
  Wrench, Upload, Link as LinkIcon, RefreshCw, Check, Image as ImageIcon, 
  Sliders, Eye, Sun, Sparkles, X, CheckCircle2, Move, ZoomIn, Contrast,
  Shield, Search, Trash2, Download, FileUp, Lock, Key, AlertTriangle,
  RotateCcw, Globe
} from 'lucide-react';
import { saveDevConfigToStorage, loadDevConfigFromStorage, getSyncDevConfig } from '../utils/devStorage';
import { 
  getTeamLogoUrl, 
  getCustomTeamLogos, 
  setCustomTeamLogo, 
  removeCustomTeamLogo, 
  resetAllCustomTeamLogos,
  exportCustomTeamLogosJson,
  importCustomTeamLogosJson
} from '../data/teamLogos';
import { getAllGameTeamsForDev, DevTeamInfo } from '../data/allLeaguesTeams';
import { TeamBadge } from './TeamBadge';

export interface DevImageConfig {
  customImageUrl: string;
  scaleVh: number; // e.g. 70 (% height)
  zoomScale: number; // e.g. 100 (% scale transform)
  offsetY: number; // e.g. 0 (px)
  offsetX: number; // e.g. 0 (px)
  opacity: number; // e.g. 100 (%)
  brightness: number; // e.g. 100 (%)
  contrast: number; // e.g. 100 (%)
  glowColor: 'sky' | 'amber' | 'emerald' | 'rose' | 'purple' | 'none';
  stadiumBgUrl: string;
  objectPosition: 'bottom' | 'center';
}

export const DEFAULT_DEV_CONFIG: DevImageConfig = {
  customImageUrl: '/cm27-logo.png',
  scaleVh: 70,
  zoomScale: 100,
  offsetY: 0,
  offsetX: 0,
  opacity: 100,
  brightness: 100,
  contrast: 100,
  glowColor: 'purple',
  stadiumBgUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=1920&auto=format&fit=crop',
  objectPosition: 'center'
};

export const getStoredDevConfig = (): DevImageConfig => {
  return getSyncDevConfig();
};

export const saveStoredDevConfig = (config: DevImageConfig) => {
  saveDevConfigToStorage(config);
};

// Security PIN helpers
const DEFAULT_OWNER_PIN = '1173';

export const getStoredOwnerPin = (): string => {
  try {
    return localStorage.getItem('fm_dev_owner_pin') || DEFAULT_OWNER_PIN;
  } catch {
    return DEFAULT_OWNER_PIN;
  }
};

export const setStoredOwnerPin = (pin: string) => {
  try {
    localStorage.setItem('fm_dev_owner_pin', pin.trim());
  } catch (e) {
    console.error('Failed to save owner PIN', e);
  }
};

export const isDevAuthenticated = (): boolean => {
  try {
    return localStorage.getItem('fm_dev_authenticated') === 'true';
  } catch {
    return false;
  }
};

export const setDevAuthenticated = (auth: boolean) => {
  try {
    if (auth) {
      localStorage.setItem('fm_dev_authenticated', 'true');
    } else {
      localStorage.removeItem('fm_dev_authenticated');
    }
  } catch (e) {
    console.error('Failed to update dev auth', e);
  }
};

export const isDevButtonHidden = (): boolean => {
  try {
    // Default is true (completely stealth for APK/AAB builds and new players)
    const stored = localStorage.getItem('fm_dev_hide_button');
    if (stored === null) return true;
    return stored === 'true';
  } catch {
    return true;
  }
};

export const setDevButtonHidden = (hidden: boolean) => {
  try {
    if (hidden) {
      localStorage.setItem('fm_dev_hide_button', 'true');
    } else {
      localStorage.removeItem('fm_dev_hide_button');
    }
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('fm-dev-visibility-changed'));
    }
  } catch (e) {
    console.error('Failed to update dev button hidden', e);
  }
};

// Canvas compressor for user uploaded images to ensure fast rendering & storage
function compressImageFile(file: File, maxWidth = 800, quality = 0.88): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = (e) => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const mimeType = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
        const compressedDataUrl = canvas.toDataURL(mimeType, quality);
        resolve(compressedDataUrl);
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
}

interface DevPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: DevImageConfig;
  onUpdateConfig: (newConfig: DevImageConfig) => void;
  showToast: (msg: string) => void;
}

export const DevPanelModal: React.FC<DevPanelModalProps> = ({
  isOpen,
  onClose,
  config,
  onUpdateConfig,
  showToast
}) => {
  const [urlInput, setUrlInput] = useState(config.customImageUrl);
  const [stadiumUrlInput, setStadiumUrlInput] = useState(config.stadiumBgUrl);
  const [activeTab, setActiveTab] = useState<'team_logos' | 'source' | 'style' | 'security'>('team_logos');
  const [isUploading, setIsUploading] = useState(false);

  // Team Logos Tab States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLeagueFilter, setSelectedLeagueFilter] = useState('ALL');
  const [editingTeamId, setEditingTeamId] = useState<string | null>(null);
  const [teamUrlInputs, setTeamUrlInputs] = useState<Record<string, string>>({});
  const [teamUploadLoading, setTeamUploadLoading] = useState<string | null>(null);
  const [customLogosRevision, setCustomLogosRevision] = useState(0);
  const [showJsonModal, setShowJsonModal] = useState(false);
  const [jsonInput, setJsonInput] = useState('');

  // Security Tab States
  const [newPinInput, setNewPinInput] = useState('');
  const [hideButtonToggle, setHideButtonToggle] = useState(isDevButtonHidden());

  useEffect(() => {
    if (isOpen) {
      setUrlInput(config.customImageUrl);
      setStadiumUrlInput(config.stadiumBgUrl);
      setHideButtonToggle(isDevButtonHidden());
    }
  }, [isOpen, config]);

  const allTeams = useMemo(() => getAllGameTeamsForDev(), []);
  const customLogos = useMemo(() => getCustomTeamLogos(), [customLogosRevision]);

  const customLogosCount = useMemo(() => {
    return Object.keys(customLogos).length;
  }, [customLogos]);

  const leaguesList = useMemo(() => {
    const set = new Set<string>();
    allTeams.forEach(t => set.add(t.league));
    return Array.from(set);
  }, [allTeams]);

  const filteredTeams = useMemo(() => {
    return allTeams.filter((t) => {
      const matchesSearch = 
        t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (t.shortName && t.shortName.toLowerCase().includes(searchQuery.toLowerCase())) ||
        t.league.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesLeague = selectedLeagueFilter === 'ALL' || t.league === selectedLeagueFilter;
      return matchesSearch && matchesLeague;
    });
  }, [allTeams, searchQuery, selectedLeagueFilter]);

  if (!isOpen) return null;

  const presets = [
    {
      name: 'CM 27 Resmi Logo & Sanat',
      url: '/cm27-logo.png'
    },
    {
      name: 'Yüklenen Özel Görsel (73c9222d)',
      url: '/73c9222d-a64f-4980-9a64-1f6df072fc6b.png'
    },
    {
      name: 'Stadyum Takımı (Fotogerçekçi)',
      url: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=1200&auto=format&fit=crop'
    },
    {
      name: 'Gece Stadyum Işıkları',
      url: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=1200&auto=format&fit=crop'
    }
  ];

  const updateAndSave = async (updatedConfig: DevImageConfig, msg?: string) => {
    onUpdateConfig(updatedConfig);
    await saveDevConfigToStorage(updatedConfig);
    if (msg) showToast(msg);
  };

  const handleApplyUrl = () => {
    if (!urlInput.trim()) return;
    const updated = { ...config, customImageUrl: urlInput.trim() };
    updateAndSave(updated, 'Ana menü görseli başarıyla güncellendi ve kaydedildi!');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const compressedDataUrl = await compressImageFile(file, 1200, 0.90);
      setUrlInput(compressedDataUrl);
      const updated = { ...config, customImageUrl: compressedDataUrl };
      await updateAndSave(updated, 'Resim başarıyla optimize edildi ve kaydedildi!');
    } catch (err) {
      console.error('File load failed', err);
      showToast('Resim yüklenirken hata oluştu');
    } finally {
      setIsUploading(false);
    }
  };

  // Team Logo Handlers
  const handleSaveTeamLogoUrl = (team: DevTeamInfo) => {
    const val = teamUrlInputs[team.id] || '';
    if (!val.trim()) return;
    setCustomTeamLogo(team.id, val.trim());
    setCustomTeamLogo(team.name, val.trim());
    if (team.shortName) setCustomTeamLogo(team.shortName, val.trim());
    setCustomLogosRevision(r => r + 1);
    setEditingTeamId(null);
    showToast(`${team.name} logosu başarıyla güncellendi!`);
  };

  const handleTeamLogoFileUpload = async (team: DevTeamInfo, file: File) => {
    setTeamUploadLoading(team.id);
    try {
      const compressedDataUrl = await compressImageFile(file, 300, 0.90);
      setCustomTeamLogo(team.id, compressedDataUrl);
      setCustomTeamLogo(team.name, compressedDataUrl);
      if (team.shortName) setCustomTeamLogo(team.shortName, compressedDataUrl);
      setCustomLogosRevision(r => r + 1);
      showToast(`${team.name} logosu cihazdan yüklendi ve kaydedildi!`);
    } catch (err) {
      console.error('Logo upload failed', err);
      showToast('Logo yüklenirken hata oluştu');
    } finally {
      setTeamUploadLoading(null);
    }
  };

  const handleResetTeamLogo = (team: DevTeamInfo) => {
    removeCustomTeamLogo(team.id);
    removeCustomTeamLogo(team.name);
    if (team.shortName) removeCustomTeamLogo(team.shortName);
    setCustomLogosRevision(r => r + 1);
    showToast(`${team.name} logosu orijinal varsayılana döndürüldü.`);
  };

  const handleResetAllLogos = () => {
    if (window.confirm('Tüm takımların logolarını orijinal varsayılanlarına sıfırlamak istediğinize emin misiniz?')) {
      resetAllCustomTeamLogos();
      setCustomLogosRevision(r => r + 1);
      showToast('Tüm takımların logoları varsayılana sıfırlandı.');
    }
  };

  const handleExportJson = () => {
    const jsonStr = exportCustomTeamLogosJson();
    navigator.clipboard?.writeText(jsonStr);
    showToast('Özel takım logoları JSON formatında panoya kopyalandı!');
  };

  const handleImportJson = () => {
    if (!jsonInput.trim()) return;
    const ok = importCustomTeamLogosJson(jsonInput.trim());
    if (ok) {
      setCustomLogosRevision(r => r + 1);
      setShowJsonModal(false);
      setJsonInput('');
      showToast('Özel takım logoları başarıyla içe aktarıldı!');
    } else {
      alert('Geçersiz JSON formatı!');
    }
  };

  // Security Handlers
  const handleSavePin = () => {
    if (newPinInput.trim().length < 4) {
      alert('PIN kodu en az 4 karakter olmalıdır.');
      return;
    }
    setStoredOwnerPin(newPinInput.trim());
    setNewPinInput('');
    showToast('Yönetici PIN kodu başarıyla güncellendi!');
  };

  const handleToggleHideButton = (val: boolean) => {
    setHideButtonToggle(val);
    setDevButtonHidden(val);
    showToast(val ? 'Geliştirici butonu ana menüden gizlendi! (Logoya 5 kez tıklayarak açabilirsiniz)' : 'Geliştirici butonu ana menüde görünür yapıldı.');
  };

  const handleLockSession = () => {
    setDevAuthenticated(false);
    onClose();
    showToast('Geliştirici oturumu kilitlendi.');
  };

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn select-none">
      <div className="relative w-full max-w-4xl bg-[#0b071a] border border-purple-500/50 rounded-2xl shadow-[0_0_60px_rgba(168,85,247,0.35)] text-white overflow-hidden flex flex-col max-h-[94vh]">
        
        {/* HEADER BAR */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3 bg-gradient-to-r from-[#200d3d] via-[#140826] to-[#0b071a] border-b border-purple-500/30">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-500/20 border border-purple-400/50 text-purple-300 shadow-[0_0_15px_rgba(168,85,247,0.4)]">
              <Wrench className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black italic tracking-wider uppercase text-white flex items-center gap-2">
                <span>CM 27 YÖNETİCİ & DEV PANELİ</span> 
                <span className="text-[9px] bg-purple-500/30 text-purple-200 px-2 py-0.5 rounded-full border border-purple-400/40 font-mono">
                  GİZLİ YÖNETİCİ MODU
                </span>
              </h2>
              <p className="text-[10px] sm:text-xs text-purple-300/80">
                Tüm takımların logolarını özelleştirin, menü arka planını ve güvenlik ayarlarını yönetin
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-purple-950/80 hover:bg-purple-900 text-purple-300 hover:text-white border border-purple-700/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TABS NAVIGATION */}
        <div className="flex border-b border-purple-900/40 bg-[#070412] px-3 sm:px-6 gap-1 sm:gap-2 pt-2 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('team_logos')}
            className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 text-xs font-black uppercase tracking-wider rounded-t-xl transition-all whitespace-nowrap ${
              activeTab === 'team_logos'
                ? 'bg-[#0b071a] text-purple-300 border-t-2 border-purple-400 border-x border-purple-500/30 shadow-[0_-4px_12px_rgba(168,85,247,0.2)]'
                : 'text-slate-400 hover:text-white hover:bg-purple-950/30'
            }`}
          >
            <Shield className="w-4 h-4 text-purple-400" />
            <span>Takım Logoları ({allTeams.length})</span>
            {customLogosCount > 0 && (
              <span className="bg-purple-600 text-white text-[9px] px-1.5 py-0.2 rounded-full font-mono">
                {customLogosCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('source')}
            className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 text-xs font-black uppercase tracking-wider rounded-t-xl transition-all whitespace-nowrap ${
              activeTab === 'source'
                ? 'bg-[#0b071a] text-purple-300 border-t-2 border-purple-400 border-x border-purple-500/30 shadow-[0_-4px_12px_rgba(168,85,247,0.2)]'
                : 'text-slate-400 hover:text-white hover:bg-purple-950/30'
            }`}
          >
            <ImageIcon className="w-4 h-4 text-sky-400" />
            <span>Ana Menü & CM 27</span>
          </button>

          <button
            onClick={() => setActiveTab('style')}
            className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 text-xs font-black uppercase tracking-wider rounded-t-xl transition-all whitespace-nowrap ${
              activeTab === 'style'
                ? 'bg-[#0b071a] text-purple-300 border-t-2 border-purple-400 border-x border-purple-500/30'
                : 'text-slate-400 hover:text-white hover:bg-purple-950/30'
            }`}
          >
            <Sliders className="w-4 h-4 text-amber-400" />
            <span>Efekt & Konum</span>
          </button>

          <button
            onClick={() => setActiveTab('security')}
            className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 text-xs font-black uppercase tracking-wider rounded-t-xl transition-all whitespace-nowrap ${
              activeTab === 'security'
                ? 'bg-[#0b071a] text-purple-300 border-t-2 border-purple-400 border-x border-purple-500/30'
                : 'text-slate-400 hover:text-white hover:bg-purple-950/30'
            }`}
          >
            <Lock className="w-4 h-4 text-emerald-400" />
            <span>Güvenlik & PIN</span>
          </button>
        </div>

        {/* TAB CONTENTS */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6 space-y-4">
          
          {/* ============================================================ */}
          {/* TAB 1: TAKIM LOGOLARI YÖNETİMİ */}
          {/* ============================================================ */}
          {activeTab === 'team_logos' && (
            <div className="space-y-4">
              
              {/* Top Controls Bar */}
              <div className="bg-[#120926] p-3 sm:p-4 rounded-xl border border-purple-500/30 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 shadow-lg">
                
                {/* Search Bar */}
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-purple-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Takım veya lig adı ile ara (örn: Galatasaray, Real Madrid, Arsenal)..."
                    className="w-full pl-9 pr-8 py-2 bg-[#080410] border border-purple-500/40 rounded-xl text-xs text-white focus:outline-none focus:border-purple-400"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Bulk Actions */}
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={handleExportJson}
                    title="Özel logoları JSON olarak kopyala"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-900/60 hover:bg-purple-800 border border-purple-500/40 text-[11px] font-bold text-purple-200 active:scale-95"
                  >
                    <Download className="w-3.5 h-3.5 text-purple-300" />
                    <span>Dışa Aktar</span>
                  </button>

                  <button
                    onClick={() => setShowJsonModal(true)}
                    title="JSON ile toplu logo yükle"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-900/60 hover:bg-indigo-800 border border-indigo-500/40 text-[11px] font-bold text-indigo-200 active:scale-95"
                  >
                    <FileUp className="w-3.5 h-3.5 text-indigo-300" />
                    <span>İçe Aktar</span>
                  </button>

                  {customLogosCount > 0 && (
                    <button
                      onClick={handleResetAllLogos}
                      title="Tüm özel logoları sıfırla"
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 border border-rose-600/50 text-[11px] font-bold text-rose-300 active:scale-95"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
                      <span>Tümünü Sıfırla</span>
                    </button>
                  )}
                </div>

              </div>

              {/* League Filter Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                <button
                  onClick={() => setSelectedLeagueFilter('ALL')}
                  className={`px-3 py-1 rounded-full text-[11px] font-extrabold uppercase transition-all shrink-0 ${
                    selectedLeagueFilter === 'ALL'
                      ? 'bg-purple-600 text-white shadow-md shadow-purple-950'
                      : 'bg-[#140b2a] text-purple-300/70 hover:text-white border border-purple-900/40'
                  }`}
                >
                  TÜMÜ ({allTeams.length})
                </button>
                {leaguesList.map((lg) => {
                  const count = allTeams.filter(t => t.league === lg).length;
                  return (
                    <button
                      key={lg}
                      onClick={() => setSelectedLeagueFilter(lg)}
                      className={`px-3 py-1 rounded-full text-[11px] font-extrabold uppercase transition-all shrink-0 ${
                        selectedLeagueFilter === lg
                          ? 'bg-purple-600 text-white shadow-md shadow-purple-950'
                          : 'bg-[#140b2a] text-purple-300/70 hover:text-white border border-purple-900/40'
                      }`}
                    >
                      {lg.split('(')[0].trim()} ({count})
                    </button>
                  );
                })}
              </div>

              {/* Teams Grid / List */}
              <div className="space-y-2 max-h-[52vh] overflow-y-auto pr-1">
                {filteredTeams.length === 0 ? (
                  <div className="text-center py-12 text-slate-400 text-xs">
                    Aranan kriterlere uygun takım bulunamadı.
                  </div>
                ) : (
                  filteredTeams.map((team) => {
                    const hasCustomLogo = Boolean(
                      customLogos[team.id.toLowerCase()] || 
                      customLogos[team.name.toLowerCase()]
                    );
                    const isEditing = editingTeamId === team.id;
                    const inputVal = teamUrlInputs[team.id] ?? (getTeamLogoUrl(team.id) || '');

                    return (
                      <div
                        key={team.id}
                        className={`p-2.5 sm:p-3 rounded-xl border transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-3 ${
                          hasCustomLogo
                            ? 'bg-[#150d2e] border-purple-500/60 shadow-[0_0_15px_rgba(168,85,247,0.15)]'
                            : 'bg-[#0e071e] border-purple-950/50 hover:border-purple-800/60'
                        }`}
                      >
                        {/* Team Info & Live Badge */}
                        <div className="flex items-center gap-3 min-w-[200px] shrink-0">
                          <div className="p-1 rounded-xl bg-[#06030c] border border-purple-500/30 flex items-center justify-center shrink-0">
                            <TeamBadge team={team} size="md" />
                          </div>

                          <div className="text-left">
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-xs text-white">{team.name}</span>
                              {hasCustomLogo && (
                                <span className="text-[8px] font-black bg-purple-500 text-white px-1.5 py-0.2 rounded uppercase">
                                  ÖZEL LOGO
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-purple-300/70 font-medium block">
                              {team.league}
                            </span>
                          </div>
                        </div>

                        {/* Action Controls for this team */}
                        <div className="flex items-center gap-2 w-full md:w-auto justify-end flex-wrap">
                          
                          {/* File Upload Trigger */}
                          <label className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-purple-950 hover:bg-purple-900 border border-purple-500/40 text-[10px] font-bold text-purple-200 cursor-pointer active:scale-95 transition-all shadow">
                            <Upload className="w-3.5 h-3.5 text-purple-400" />
                            <span>{teamUploadLoading === team.id ? 'Yükleniyor...' : 'Cihazdan Seç'}</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) handleTeamLogoFileUpload(team, file);
                              }}
                            />
                          </label>

                          {/* URL Input / Edit Toggle */}
                          {!isEditing ? (
                            <button
                              onClick={() => {
                                setEditingTeamId(team.id);
                                setTeamUrlInputs(prev => ({ ...prev, [team.id]: getTeamLogoUrl(team.id) || '' }));
                              }}
                              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#1a0e36] hover:bg-[#25144d] border border-purple-600/40 text-[10px] font-bold text-purple-300 active:scale-95"
                            >
                              <LinkIcon className="w-3.5 h-3.5 text-sky-400" />
                              <span>URL Gir</span>
                            </button>
                          ) : (
                            <div className="flex items-center gap-1 w-full sm:w-auto">
                              <input
                                type="text"
                                value={inputVal}
                                onChange={(e) => setTeamUrlInputs({ ...teamUrlInputs, [team.id]: e.target.value })}
                                placeholder="https://... logo url"
                                className="px-2 py-1 bg-[#06030c] border border-purple-500 rounded text-[10px] text-white w-48 focus:outline-none"
                              />
                              <button
                                onClick={() => handleSaveTeamLogoUrl(team)}
                                className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-black"
                              >
                                Kaydet
                              </button>
                              <button
                                onClick={() => setEditingTeamId(null)}
                                className="px-1.5 py-1 rounded bg-slate-800 text-slate-400 hover:text-white text-[10px]"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </div>
                          )}

                          {/* Reset Button */}
                          {hasCustomLogo && (
                            <button
                              onClick={() => handleResetTeamLogo(team)}
                              title="Varsayılan orijinal logoya dön"
                              className="p-1.5 rounded-lg bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-700/50"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                        </div>

                      </div>
                    );
                  })
                )}
              </div>

            </div>
          )}

          {/* ============================================================ */}
          {/* TAB 2: ANA MENÜ GÖRSELİ & CM 27 */}
          {/* ============================================================ */}
          {activeTab === 'source' && (
            <div className="space-y-4">
              
              {/* Presets Grid */}
              <div>
                <label className="block text-xs font-black text-purple-300 uppercase tracking-wider mb-2">
                  Önceden Tanımlı Resmi Şablonlar
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {presets.map((preset, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setUrlInput(preset.url);
                        const updated = { ...config, customImageUrl: preset.url };
                        updateAndSave(updated, `${preset.name} uygulandı ve kaydedildi!`);
                      }}
                      className={`flex items-center gap-3 p-2.5 rounded-xl border text-left transition-all ${
                        config.customImageUrl === preset.url
                          ? 'bg-purple-950 border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.3)]'
                          : 'bg-[#100724] border-purple-900/40 hover:border-purple-600'
                      }`}
                    >
                      <div className="w-12 h-10 rounded-lg overflow-hidden bg-black shrink-0 border border-purple-500/30">
                        <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="truncate">
                        <span className="text-xs font-extrabold text-white block truncate">{preset.name}</span>
                        <span className="text-[9px] text-purple-300/70 font-mono">Tıklayarak Uygula</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom URL Input */}
              <div className="bg-[#120926] p-4 rounded-xl border border-purple-500/30 space-y-2">
                <label className="block text-xs font-black text-purple-200 uppercase">
                  Özel Görsel URL Linki
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    placeholder="https://images.unsplash.com/... veya /cm27-logo.png"
                    className="flex-1 px-3 py-2 bg-[#080410] border border-purple-500/40 rounded-xl text-xs text-white focus:outline-none focus:border-purple-400"
                  />
                  <button
                    onClick={handleApplyUrl}
                    className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-black text-xs rounded-xl uppercase tracking-wider shadow"
                  >
                    Uygula
                  </button>
                </div>
              </div>

              {/* Upload from Device */}
              <div className="bg-[#120926] p-4 rounded-xl border border-purple-500/30 space-y-2">
                <label className="block text-xs font-black text-purple-200 uppercase">
                  Cihazdan Yeni Resim Yükle
                </label>
                <p className="text-[10px] text-purple-300/70">
                  Kendi teknik direktör veya takım fotoğrafınızı yükleyin (Otomatik optimize edilir ve kaydedilir)
                </p>
                <label className="flex items-center justify-center gap-2 w-full p-4 rounded-xl border-2 border-dashed border-purple-500/40 hover:border-purple-400 bg-purple-950/30 hover:bg-purple-950/50 cursor-pointer transition-all">
                  <Upload className="w-5 h-5 text-purple-400" />
                  <span className="text-xs font-extrabold text-purple-200">
                    {isUploading ? 'Resim İşleniyor...' : 'Fotoğraf veya Logo Dosyası Seç (PNG, JPG, WebP)'}
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileUpload}
                    disabled={isUploading}
                  />
                </label>
              </div>

            </div>
          )}

          {/* ============================================================ */}
          {/* TAB 3: EFEKT & KONUM */}
          {/* ============================================================ */}
          {activeTab === 'style' && (
            <div className="space-y-4">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Zoom Scale */}
                <div className="bg-[#120926] p-3.5 rounded-xl border border-purple-500/30 space-y-2">
                  <div className="flex justify-between text-xs font-bold text-purple-200">
                    <span>Yakınlaştırma (Zoom)</span>
                    <span className="font-mono text-amber-300">%{config.zoomScale}</span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="200"
                    value={config.zoomScale}
                    onChange={(e) => updateAndSave({ ...config, zoomScale: Number(e.target.value) })}
                    className="w-full accent-purple-500"
                  />
                </div>

                {/* Vertical Offset */}
                <div className="bg-[#120926] p-3.5 rounded-xl border border-purple-500/30 space-y-2">
                  <div className="flex justify-between text-xs font-bold text-purple-200">
                    <span>Dikey Konum (Y Offset)</span>
                    <span className="font-mono text-amber-300">{config.offsetY}px</span>
                  </div>
                  <input
                    type="range"
                    min="-200"
                    max="200"
                    value={config.offsetY}
                    onChange={(e) => updateAndSave({ ...config, offsetY: Number(e.target.value) })}
                    className="w-full accent-purple-500"
                  />
                </div>

                {/* Horizontal Offset */}
                <div className="bg-[#120926] p-3.5 rounded-xl border border-purple-500/30 space-y-2">
                  <div className="flex justify-between text-xs font-bold text-purple-200">
                    <span>Yatay Konum (X Offset)</span>
                    <span className="font-mono text-amber-300">{config.offsetX}px</span>
                  </div>
                  <input
                    type="range"
                    min="-300"
                    max="300"
                    value={config.offsetX}
                    onChange={(e) => updateAndSave({ ...config, offsetX: Number(e.target.value) })}
                    className="w-full accent-purple-500"
                  />
                </div>

                {/* Brightness */}
                <div className="bg-[#120926] p-3.5 rounded-xl border border-purple-500/30 space-y-2">
                  <div className="flex justify-between text-xs font-bold text-purple-200">
                    <span>Parlaklık (Brightness)</span>
                    <span className="font-mono text-amber-300">%{config.brightness}</span>
                  </div>
                  <input
                    type="range"
                    min="40"
                    max="180"
                    value={config.brightness}
                    onChange={(e) => updateAndSave({ ...config, brightness: Number(e.target.value) })}
                    className="w-full accent-purple-500"
                  />
                </div>

              </div>

              {/* Glow Color Preset */}
              <div className="bg-[#120926] p-3.5 rounded-xl border border-purple-500/30 space-y-2">
                <label className="block text-xs font-black text-purple-200 uppercase">
                  Stadyum Işık Halesi (Glow)
                </label>
                <div className="flex items-center gap-2 flex-wrap">
                  {(['purple', 'sky', 'amber', 'emerald', 'rose', 'none'] as const).map((color) => (
                    <button
                      key={color}
                      onClick={() => updateAndSave({ ...config, glowColor: color })}
                      className={`px-3 py-1 rounded-lg text-[11px] font-extrabold uppercase transition-all ${
                        config.glowColor === color
                          ? 'bg-purple-600 text-white shadow-lg'
                          : 'bg-[#080410] text-purple-300/70 hover:text-white border border-purple-900/40'
                      }`}
                    >
                      {color === 'purple' ? '💜 Mor (CM 27)' : color}
                    </button>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* ============================================================ */}
          {/* TAB 4: GÜVENLİK & PIN */}
          {/* ============================================================ */}
          {activeTab === 'security' && (
            <div className="space-y-4">
              
              <div className="bg-[#120926] p-4 rounded-xl border border-purple-500/30 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-sm">
                  <Shield className="w-5 h-5" />
                  <span>APK & AAB Tam Güvenlik (Sadece Klavye / Emülatör / PC Erişimi)</span>
                </div>
                <p className="text-xs text-purple-200/80 leading-relaxed">
                  Oyun APK veya AAB olarak paketlendiğinde mobil dokunmatik tüm girişler (logo tıklama, sürüm basılı tutma vb.) tamamen kapatılmıştır. Hiçbir oyuncu panele erişemez.
                </p>
                <div className="space-y-1.5 text-[11px] text-purple-300 bg-purple-950/40 p-3 rounded-xl border border-purple-800/40 font-medium">
                  <div>⌨️ <strong>Tek Giriş Yöntemi (Klavye / PC / Emülatör):</strong> <kbd className="bg-purple-900 px-1.5 py-0.5 rounded border border-purple-600 text-white font-mono font-bold">Ctrl + Shift + D</kbd> veya <kbd className="bg-purple-900 px-1.5 py-0.5 rounded border border-purple-600 text-white font-mono font-bold">Ctrl + Alt + M</kbd> tuşlarına basarak Yönetici PIN Doğrulama kapısını açabilirsiniz.</div>
                  <div>🔒 <strong>Mobil Dokunmatik Erişim:</strong> Kapalı (APK'da dokunarak açılamaz).</div>
                </div>
              </div>

              {/* Hide Button Toggle */}
              <div className="bg-[#120926] p-4 rounded-xl border border-purple-500/30 flex items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-extrabold text-white block">
                    Geliştirici Butonunu Ana Menüde Tamamen Gizle (APK/AAB Varsayılanı: Gizli)
                  </span>
                  <span className="text-[10px] text-purple-300/70 block mt-0.5">
                    Bu seçenek açıkken ana menüde hiçbir buton görünmez. Yukarıdaki gizli kombinasyonlarla PIN girerek açabilirsiniz.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={hideButtonToggle}
                  onChange={(e) => handleToggleHideButton(e.target.checked)}
                  className="w-5 h-5 accent-purple-600 rounded cursor-pointer"
                />
              </div>

              {/* Change Master PIN */}
              <div className="bg-[#120926] p-4 rounded-xl border border-purple-500/30 space-y-2">
                <label className="block text-xs font-black text-purple-200 uppercase">
                  Yönetici PIN Kodunu Değiştir (Varsayılan: 1173)
                </label>
                <div className="flex gap-2">
                  <input
                    type="password"
                    value={newPinInput}
                    onChange={(e) => setNewPinInput(e.target.value)}
                    placeholder="Yeni 4+ haneli PIN girin..."
                    className="flex-1 px-3 py-2 bg-[#080410] border border-purple-500/40 rounded-xl text-xs text-white focus:outline-none focus:border-purple-400"
                  />
                  <button
                    onClick={handleSavePin}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl uppercase tracking-wider shadow"
                  >
                    PIN Kaydet
                  </button>
                </div>
              </div>

              {/* Lock Session */}
              <div className="pt-2 flex justify-end">
                <button
                  onClick={handleLockSession}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-950 hover:bg-rose-900 border border-rose-600/50 text-rose-300 font-black text-xs uppercase tracking-wider shadow active:scale-95"
                >
                  <Lock className="w-4 h-4 text-rose-400" />
                  <span>Geliştirici Oturumunu Kilitle & Çıkış Yap</span>
                </button>
              </div>

            </div>
          )}

        </div>

        {/* FOOTER */}
        <div className="px-5 py-3 bg-[#070412] border-t border-purple-900/40 flex items-center justify-between">
          <span className="text-[10px] text-purple-300/60 font-mono">
            CM 27 • Yetkili Geliştirici Oturumu Aktif
          </span>
          <button
            onClick={onClose}
            className="px-6 py-2 bg-purple-600 hover:bg-purple-500 text-white font-black text-xs rounded-xl uppercase tracking-wider shadow-lg shadow-purple-950 border border-purple-400/40 active:scale-95"
          >
            KAPAT
          </button>
        </div>

      </div>

      {/* JSON Import Modal */}
      {showJsonModal && (
        <div className="fixed inset-0 z-[10010] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="w-full max-w-lg bg-[#0e071e] border border-purple-500/60 rounded-2xl p-5 text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black uppercase text-purple-300 flex items-center gap-2">
                <FileUp className="w-4 h-4" />
                Özel Logoları JSON ile İçe Aktar
              </h3>
              <button onClick={() => setShowJsonModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-300">
              Daha önce dışa aktardığınız logo JSON metnini buraya yapıştırın:
            </p>
            <textarea
              rows={8}
              value={jsonInput}
              onChange={(e) => setJsonInput(e.target.value)}
              placeholder='{ "galatasaray": "https://...", "fenerbahce": "https://..." }'
              className="w-full p-3 bg-[#06030c] border border-purple-500/40 rounded-xl text-xs font-mono text-purple-200 focus:outline-none"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowJsonModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 text-xs rounded-xl font-bold"
              >
                İptal
              </button>
              <button
                onClick={handleImportJson}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs rounded-xl font-black uppercase"
              >
                Logoları Yükle
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
