import React, { useState } from 'react';
import { Team, ManagerProfile } from '../types';
import { useTranslation } from '../utils/i18n';
import { Mic, Camera, Award, Sparkles, CheckCircle2, ChevronRight, MessageSquare, ThumbsUp, ShieldAlert, HeartHandshake, Flame } from 'lucide-react';
import confetti from 'canvas-confetti';

export interface PostMatchPressData {
  isDerby: boolean;
  opponentTeam: Team;
  userScore: number;
  opponentScore: number;
}

interface PressConferenceModalProps {
  isOpen: boolean;
  manager: ManagerProfile;
  team: Team;
  mode?: 'INTRO' | 'POST_MATCH';
  postMatchData?: PostMatchPressData;
  onComplete: (answersSummary: string[]) => void;
}

interface Question {
  id: number;
  reporter: string;
  mediaOutlet: string;
  avatar: string;
  questionText: string;
  options: {
    label: string;
    text: string;
    effect: string;
    effectType: 'morale' | 'confidence' | 'discipline';
  }[];
}

export const PressConferenceModal: React.FC<PressConferenceModalProps> = ({
  isOpen,
  manager,
  team,
  mode = 'INTRO',
  postMatchData,
  onComplete
}) => {
  const { t, language } = useTranslation();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [isFinished, setIsFinished] = useState(false);

  const getLocalizedText = (tr: string, en: string, es: string, fr: string, it: string, de: string, pt: string) => {
    const lang = (language || 'TR').toUpperCase();
    if (lang === 'EN') return en;
    if (lang === 'ES') return es;
    if (lang === 'FR') return fr;
    if (lang === 'IT') return it;
    if (lang === 'DE') return de;
    if (lang === 'PT') return pt;
    return tr;
  };

  if (!isOpen) return null;

  const teamName = team?.name || (language === 'EN' ? 'Team' : 'Takım');
  const managerName = manager?.name || (language === 'EN' ? 'Head Coach' : 'Teknik Direktör');
  const oppName = postMatchData?.opponentTeam?.name || (language === 'EN' ? 'Opponent' : 'Rakip Takım');

  // Generate Questions dynamically based on mode and match result
  let questions: Question[] = [];

  if (mode === 'POST_MATCH' && postMatchData) {
    const { isDerby, userScore, opponentScore } = postMatchData;
    const isWin = userScore > opponentScore;
    const isDraw = userScore === opponentScore;
    const isLoss = userScore < opponentScore;

    if (isDerby) {
      if (isWin) {
        questions = [
          {
            id: 1,
            reporter: getLocalizedText('Kaan Yılmaz', 'Liam Smith', 'Carlos Gómez', 'Julien Moreau', 'Marco Rossi', 'Lukas Weber', 'Tiago Silva'),
            mediaOutlet: getLocalizedText('Derbi TV Canlı', 'Derby TV Live', 'Derbi TV Directo', 'Derby TV Direct', 'Derby TV Diretta', 'Derby TV Live', 'Derby TV Ao Vivo'),
            avatar: '🎙️',
            questionText: getLocalizedText(
              `Sayın ${managerName}, ${oppName} karşısında alınan ${userScore}-${opponentScore} derbi zaferini nasıl değerlendiriyorsunuz?`,
              `Mr. ${managerName}, how do you evaluate the ${userScore}-${opponentScore} derby victory against ${oppName}?`,
              `Sr. ${managerName}, ¿cómo valora la victoria en el derbi ${userScore}-${opponentScore} contra ${oppName}?`,
              `M. ${managerName}, comment analysez-vous la victoire ${userScore}-${opponentScore} dans le derby face à ${oppName} ?`,
              `Mister ${managerName}, come valuta questa vittoria nel derby per ${userScore}-${opponentScore} contro ${oppName}?`,
              `Herr ${managerName}, wie bewerten Sie den ${userScore}-${opponentScore}-Derbysieg gegen ${oppName}?`,
              `Sr. ${managerName}, como você avalia a vitória no clássico por ${userScore}-${opponentScore} contra o ${oppName}?`
            ),
            options: [
              {
                label: 'A',
                text: getLocalizedText(
                  `Bu galibiyet muhteşem ${teamName} taraftarına armağan olsun. Şampiyonluğun en büyük adayıyız!`,
                  `This victory is dedicated to our great ${teamName} fans. We are true title contenders!`,
                  `Esta victoria va para la afición de ${teamName}. ¡Somos serios candidatos al título!`,
                  `Cette victoire est pour les supporters de ${teamName}. Nous jouons le titre !`,
                  `Dedichiamo questa vittoria ai tifosi del ${teamName}. Puntiamo allo scudetto!`,
                  `Dieser Sieg ist für die ${teamName}-Fans. Wir greifen nach dem Titel!`,
                  `Esta vitória é para a torcida do ${teamName}. Somos candidatos ao título!`
                ),
                effect: getLocalizedText('Moral & Özgüven Tavan Yaptı! (+15 Moral)', 'Morale & Confidence Surged! (+15)', '¡Moral y confianza al máximo! (+15)', 'Moral et confiance au sommet ! (+15)', 'Morale e fiducia alle stelle! (+15)', 'Moral & Selbstvertrauen auf Höchststand! (+15)', 'Moral e confiança nas alturas! (+15)'),
                effectType: 'morale'
              },
              {
                label: 'B',
                text: getLocalizedText(
                  'Taktik disiplinimize sadık kaldık. Rehavete kapılmadan bir sonraki maça odaklanacağız.',
                  'We stuck to our tactical discipline. We must stay focused for the next match.',
                  'Mantuvimos la disciplina táctica. Hay que seguir concentrados para el próximo partido.',
                  'Nous sommes restés fidèles à notre discipline tactique. Restons concentrés.',
                  'Siamo rimasti fedeli alla nostra disciplina. Ora concentrati sulla prossima gara.',
                  'Wir blieben taktisch diszipliniert. Voller Fokus auf das nächste Spiel.',
                  'Mantivemos a disciplina tática. Foco total na próxima partida.'
                ),
                effect: getLocalizedText('Takım Disiplini Arttı (+10 Disiplin)', 'Team Discipline Increased (+10)', 'Disciplina del equipo aumentada (+10)', 'Discipline collective accrue (+10)', 'Disciplina di squadra aumentata (+10)', 'Teamdisziplin gestiegen (+10)', 'Disciplina da equipe aumentada (+10)'),
                effectType: 'discipline'
              },
              {
                label: 'C',
                text: getLocalizedText(
                  'Sahada yüreğini koyan tüm futbolcularımı tek tek kutluyorum.',
                  'I congratulate every single player who fought with heart on the pitch today.',
                  'Felicito a cada jugador por su entrega en el campo hoy.',
                  'Je félicite chaque joueur pour son engagement sans faille sur le terrain.',
                  'Faccio i complimenti a tutti i giocatori per il cuore messo in campo.',
                  'Ich gratuliere jedem Spieler, der heute alles auf dem Platz gegeben hat.',
                  'Parabenizo todos os jogadores pela garra e entrega em campo.'
                ),
                effect: getLocalizedText('Takım Kenetlenmesi Güçlendi', 'Team Bonding Strengthened', 'Unión del equipo reforzada', 'Cohésion d\'équipe renforcée', 'Coesione di squadra rafforzata', 'Teamgeist gestärkt', 'União do elenco fortalecida'),
                effectType: 'confidence'
              }
            ]
          }
        ];
      } else if (isLoss) {
        questions = [
          {
            id: 1,
            reporter: getLocalizedText('Emre Demir', 'Oliver Brown', 'Alejandro Ruiz', 'Alexandre Laurent', 'Andrea Moretti', 'Maximilian Schulz', 'Gabriel Costa'),
            mediaOutlet: getLocalizedText('Futbol Haber', 'Football News', 'Diario Deportivo', 'Presse Football', 'Notizie Calcio', 'Fußball Aktuell', 'Notícias Futebol'),
            avatar: '🎥',
            questionText: getLocalizedText(
              `Sayın ${managerName}, derbide ${oppName} karşısında gelen ${userScore}-${opponentScore} mağlubiyeti taraftarı üzdü. Neler söyleyeceksiniz?`,
              `Mr. ${managerName}, the ${userScore}-${opponentScore} derby loss against ${oppName} disappointed fans. What are your thoughts?`,
              `Sr. ${managerName}, la derrota ${userScore}-${opponentScore} ante ${oppName} dolió a los aficionados. ¿Qué tiene que decir?`,
              `M. ${managerName}, la défaite ${userScore}-${opponentScore} contre ${oppName} a déçu les supporters. Votre réaction ?`,
              `Mister ${managerName}, la sconfitta per ${userScore}-${opponentScore} contro il ${oppName} brucia ai tifosi. Cosa dice?`,
              `Herr ${managerName}, die ${userScore}-${opponentScore}-Derbyniederlage gegen ${oppName} schmerzt. Ihr Fazit?`,
              `Sr. ${managerName}, a derrota por ${userScore}-${opponentScore} contra o ${oppName} entristeceu a torcida. O que dizer?`
            ),
            options: [
              {
                label: 'A',
                text: getLocalizedText(
                  'Sorumluluk tamamen bana ait. Hatalarımızdan ders çıkarıp hızla toparlanacağız.',
                  'The responsibility is entirely mine. We will learn from our mistakes and bounce back.',
                  'La responsabilidad es mía. Aprenderemos de los errores y nos recuperaremos.',
                  'J\'assume l\'entière responsabilité. Nous apprendrons de nos erreurs pour rebondir.',
                  'La responsabilità è tutta mia. Impareremo dagli errori e ci rialzeremo subito.',
                  'Die Verantwortung liegt bei mir. Wir werden daraus lernen und zurückschlagen.',
                  'A responsabilidade é toda minha. Vamos corrigir os erros e dar a volta por cima.'
                ),
                effect: getLocalizedText('Yönetim & Taraftar Güveni Arttı', 'Board & Fan Respect Gained', 'Respeto ganado de afición y directiva', 'Respect accru de la direction et des supporters', 'Rispetto conquistato da tifosi e dirigenza', 'Respekt von Vorstand & Fans gewonnen', 'Respeito da diretoria e torcida conquistado'),
                effectType: 'confidence'
              },
              {
                label: 'B',
                text: getLocalizedText(
                  'Hakem kararları ve şanssız anlar oyunun önüne geçti. Hak ettiğimiz skor bu değildi.',
                  'Referee decisions and unlucky moments decided the match. We deserved more.',
                  'Las decisiones arbitrales y la mala suerte nos condicionaron. Merecíamos más.',
                  'L\'arbitrage et le manque de réussite ont pesé. Nous méritions mieux.',
                  'Decisioni arbitrali e sfortuna hanno inciso. Meritavamo un risultato diverso.',
                  'Schiedsrichterentscheidungen und Pech haben den Ausschlag gegeben.',
                  'Decisões da arbitragem e azar influenciaram o resultado. Merecíamos mais.'
                ),
                effect: getLocalizedText('Mücadele Hırsı Arttı', 'Fighting Spirit Boosted', 'Espíritu de lucha impulsado', 'Esprit combatif renforcé', 'Grinta aumentata', 'Kampfgeist gesteigert', 'Espírito de luta ampliado'),
                effectType: 'morale'
              }
            ]
          }
        ];
      } else {
        questions = [
          {
            id: 1,
            reporter: getLocalizedText('Selin Arslan', 'Sarah Jenkins', 'Laura Morales', 'Sophie Dubois', 'Chiara Conti', 'Anna Becker', 'Beatriz Martins'),
            mediaOutlet: getLocalizedText('Spor Radyo', 'Sports Radio Live', 'Radio Deportes', 'Radio Sport', 'Radio Sport Live', 'Sportradio', 'Rádio Esporte'),
            avatar: '🎙️',
            questionText: getLocalizedText(
              `Derbi ${userScore}-${opponentScore} beraberlikle sonuçlandı. İki taraf da 1 puanla yetindi. Sonuçtan memnun musunuz?`,
              `The derby ended in a ${userScore}-${opponentScore} draw. Are you satisfied with the 1 point?`,
              `El derbi terminó en empate ${userScore}-${opponentScore}. ¿Satisfecho con el punto?`,
              `Le derby s'est terminé sur un nul ${userScore}-${opponentScore}. Satisfait de ce point ?`,
              `Il derby è terminato ${userScore}-${opponentScore}. Soddisfatto di questo pareggio?`,
              `Das Derby endete ${userScore}-${opponentScore}. Sind Sie mit dem Punkt zufrieden?`,
              `O clássico terminou em empate por ${userScore}-${opponentScore}. Satisfeito com 1 ponto?`
            ),
            options: [
              {
                label: 'A',
                text: getLocalizedText(
                  'Zorlu bir derbide 1 puan değerli ama biz kazanmak için oynamıştık.',
                  'A point in a tough derby is valuable, but we played to win.',
                  'Un punto en un derbi difícil es valioso, pero jugamos para ganar.',
                  'Un point dans un derby est toujours bon, mais nous voulions gagner.',
                  'Un punto in un derby difficile è prezioso, ma siamo scesi in campo per vincere.',
                  'Ein Punkt im Derby ist wertvoll, aber wir wollten gewinnen.',
                  'Um ponto no clássico é válido, mas jogamos para vencer.'
                ),
                effect: getLocalizedText('Dengeli Moral & Mücadele Gücü', 'Balanced Morale & Work Rate', 'Moral equilibrada y trabajo duro', 'Moral équilibré et combativité', 'Morale equilibrato e dedizione', 'Ausgeglichene Moral & Einsatz', 'Moral equilibrada e garra'),
                effectType: 'morale'
              },
              {
                label: 'B',
                text: getLocalizedText(
                  'Girdiğimiz net fırsatları değerlendirmeliydik. 3 puanı hak eden taraftık.',
                  'We should have converted our clear chances. We deserved the 3 points.',
                  'Debimos aprovechar las ocasiones claras. Merecíamos los 3 puntos.',
                  'Nous aurions dû concrétiser nos occasions nettes. Nous méritions 3 points.',
                  'Dovevamo concretizzare le occasioni nitide. Meritavamo i 3 punti.',
                  'Wir hätten unsere Chancen nutzen müssen. Wir verdienten die 3 Punkte.',
                  'Deveríamos ter aproveitado as chances claras. Merecíamos os 3 pontos.'
                ),
                effect: getLocalizedText('Hırs Seviyesi Yükseldi!', 'Hunger & Determination Boosted!', '¡Determinación y ambición aumentadas!', 'Détermination renforcée !', 'Determinazione aumentata!', 'Ehrgeiz & Siegeswille gestiegen!', 'Determinação e ambição aumentadas!'),
                effectType: 'discipline'
              }
            ]
          }
        ];
      }
    } else {
      // Normal Match Post-Match
      questions = [
        {
          id: 1,
          reporter: getLocalizedText('Murat Kaya', 'James Wilson', 'Mateo Fernández', 'Antoine Bernard', 'Matteo Fontana', 'Florian Meyer', 'Rodrigo Santos'),
          mediaOutlet: getLocalizedText('Futbol Masası', 'Football Central', 'Mesa de Fútbol', 'Le Mag Football', 'Salotto Calcio', 'Fußball Talk', 'Bancada Futebol'),
          avatar: '🎥',
          questionText: getLocalizedText(
            `Sayın ${managerName}, ${oppName} karşılaşması ${userScore}-${opponentScore} sona erdi. Maçın genel değerlendirmesini yapar mısınız?`,
            `Mr. ${managerName}, the match against ${oppName} ended ${userScore}-${opponentScore}. What is your assessment?`,
            `Sr. ${managerName}, el partido contra ${oppName} finalizó ${userScore}-${opponentScore}. ¿Cuál es su balance?`,
            `M. ${managerName}, le match contre ${oppName} s'est soldé par un score de ${userScore}-${opponentScore}. Votre analyse ?`,
            `Mister ${managerName}, la sfida contro ${oppName} è finita ${userScore}-${opponentScore}. Come commenta la gara?`,
            `Herr ${managerName}, das Spiel gegen ${oppName} endete ${userScore}-${opponentScore}. Ihr Resümee?`,
            `Sr. ${managerName}, a partida contra o ${oppName} terminou em ${userScore}-${opponentScore}. Qual é a sua avaliação?`
          ),
          options: [
            {
              label: 'A',
              text: isWin ? getLocalizedText(
                'İyi futbolla hak ettiğimiz 3 puanı aldık. Serimizi sürdürmek istiyoruz.',
                'We got a well-deserved 3 points with solid football. We want to keep this run going.',
                'Conseguimos 3 puntos muy merecidos. Queremos mantener esta racha.',
                'Nous prenons 3 points mérités avec un bon contenu. Continuons ainsi.',
                'Prendiamo 3 punti meritati con una bella prestazione. Vogliamo continuità.',
                'Verdiente 3 Punkte mit gutem Fußball. Diesen Lauf wollen wir fortsetzen.',
                'Conquistamos 3 pontos merecidos com bom futebol. Queremos manter a sequência.'
              ) : getLocalizedText(
                'İstediğimiz oyunu sahaya yansıtamadık. Eksiklerimizi kapatıp daha güçlü döneceğiz.',
                'We could not execute our gameplan. We will address our weaknesses and come back stronger.',
                'No mostramos nuestro juego. Corregiremos errores para volver más fuertes.',
                'Nous n\'avons pas produit notre jeu. Nous allons corriger le tir pour revenir plus forts.',
                'Non abbiamo espresso il nostro gioco. Lavoreremo sodo per ripartire subito.',
                'Wir konnten unseren Plan nicht umsetzen. Wir arbeiten hart und kommen stärker zurück.',
                'Não conseguimos impor nosso jogo. Vamos corrigir os erros e voltar mais fortes.'
              ),
              effect: isWin 
                ? getLocalizedText('Moral & Özgüven Arttı! (+10 Moral)', 'Morale & Confidence Boosted! (+10)', '¡Moral y confianza aumentadas! (+10)', 'Moral et confiance au beau fixe ! (+10)', 'Morale e fiducia aumentati! (+10)', 'Moral & Selbstvertrauen gestärkt! (+10)', 'Moral e confiança aumentadas! (+10)')
                : getLocalizedText('Disiplin & Özeleştiri Artışı (+10 Disiplin)', 'Discipline & Self-Correction (+10)', 'Disciplina y autocrítica reforzadas (+10)', 'Discipline et travail renforcés (+10)', 'Disciplina e spirito critico (+10)', 'Disziplin & Selbstkritik geschärft (+10)', 'Disciplina e autocrítica (+10)'),
              effectType: isWin ? 'morale' : 'discipline'
            },
            {
              label: 'B',
              text: getLocalizedText(
                'Önemli olan takımın sahada sergilediği karakter. Oyuncularımın mücadelesinden memnunum.',
                'What matters most is the character shown on the pitch. I am proud of the team\'s effort.',
                'Lo importante es el carácter mostrado en el campo. Orgulloso del esfuerzo del equipo.',
                'L\'essentiel est le caractère affiché sur le terrain. Fier de l\'engagement des joueurs.',
                'Conta il carattere mostrato sul campo. Sono orgoglioso dell\'impegno dei miei ragazzi.',
                'Wichtig ist der Charakter auf dem Platz. Ich bin stolz auf den Einsatz der Mannschaft.',
                'O mais importante é o caráter demonstrado em campo. Orgulhoso do empenho de todos.'
              ),
              effect: getLocalizedText('Takım Kenetlenmesi Yükseldi!', 'Team Unity Boosted!', '¡Unión de vestuario reforzada!', 'Cohésion d\'équipe renforcée !', 'Spirito di gruppo rafforzato!', 'Zusammenhalt im Team gestärkt!', 'Espírito de equipe fortalecido!'),
              effectType: 'confidence'
            }
          ]
        }
      ];
    }
  } else {
    // INTRO QUESTIONS
    questions = [
      {
        id: 1,
        reporter: getLocalizedText('Ahmet Taner', 'Arthur Davies', 'Javier Navarro', 'Pierre Martin', 'Giuseppe Ferri', 'Thomas Wagner', 'Lucas Fernandes'),
        mediaOutlet: getLocalizedText('Spor TV Canlı', 'Global Sports TV', 'Teledeporte En Vivo', 'Sport TV Direct', 'Sport TV Live', 'Sport TV Live', 'Esporte TV Ao Vivo'),
        avatar: '🎥',
        questionText: getLocalizedText(
          `Sayın ${managerName}, ${teamName} kulübünün yeni teknik direktörü olarak imzanızı attınız. İlk hisleriniz nelerdir?`,
          `Mr. ${managerName}, you have signed as the new manager of ${teamName}. What are your initial thoughts?`,
          `Sr. ${managerName}, ha firmado como nuevo entrenador del ${teamName}. ¿Cuáles son sus primeras sensaciones?`,
          `M. ${managerName}, vous êtes officiellement le nouvel entraîneur de ${teamName}. Vos premières impressions ?`,
          `Mister ${managerName}, ha firmato come nuovo allenatore del ${teamName}. Quali sono le sue prime sensazioni?`,
          `Herr ${managerName}, Sie haben als neuer Trainer von ${teamName} unterschrieben. Was sind Ihre ersten Eindrücke?`,
          `Sr. ${managerName}, você assinou como novo técnico do ${teamName}. Quais são as suas primeiras impressões?`
        ),
        options: [
          {
            label: 'A',
            text: getLocalizedText(
              `Bu büyük kulübe geldiğim için gururluyum. Taraftarlarımıza büyük zaferler yaşatacağız!`,
              `I am proud to be at this great club. We will bring unforgettable victories to our fans!`,
              `Es un orgullo llegar a este gran club. ¡Daremos grandes alegrías a nuestra afición!`,
              `Fier de rejoindre ce grand club. Nous allons offrir de grands trophées aux supporters !`,
              `Orgoglioso di essere in questo grande club. Regaleremo grandi vittorie ai nostri tifosi!`,
              `Ich bin stolz, bei diesem Traditionsverein zu sein. Wir werden große Siege feiern!`,
              `É um orgulho chegar a este grande clube. Daremos muitas alegrias à torcida!`
            ),
            effect: getLocalizedText('Taraftar Coşkusu & Takım Morali Yükseldi! (+15 Moral)', 'Fan Excitement & Morale Soared! (+15 Morale)', '¡Euforia de la afición y moral del equipo! (+15)', 'Ferveur des supporters et moral au sommet ! (+15)', 'Entusiasmo dei tifosi e morale alle stelle! (+15)', 'Fan-Begeisterung & Team-Moral gestiegen! (+15)', 'Empolgação da torcida e moral alta! (+15)'),
            effectType: 'morale'
          },
          {
            label: 'B',
            text: getLocalizedText(
              'Ciddi bir iş disipliniyle buradayım. Lafla değil, sahada oynayacağımız futbolla konuşmayı tercih ederim.',
              'I am here with strict work discipline. I let our football on the pitch do the talking.',
              'Vengo con máxima disciplina de trabajo. Prefiero que hablemos en el terreno de juego.',
              'Je viens avec une rigueur absolue. C\'est le terrain qui parlera pour nous.',
              'Sono qui con grande disciplina. Preferisco parlare con il calcio giocato sul campo.',
              'Ich bin mit hoher Arbeitsdisziplin hier. Wir lassen unsere Leistung auf dem Platz sprechen.',
              'Chego com muita disciplina de trabalho. Prefiro que o futebol em campo fale por nós.'
            ),
            effect: getLocalizedText('Takım Disiplini & Ciddiyet Arttı! (+10 Disiplin)', 'Team Discipline & Seriousness Boosted! (+10 Discipline)', '¡Disciplina y rigor aumentados! (+10)', 'Discipline et rigueur renforcées ! (+10)', 'Disciplina e serietà aumentate! (+10)', 'Disziplin & Fokus geschärft! (+10)', 'Disciplina e foco aumentados! (+10)'),
            effectType: 'discipline'
          },
          {
            label: 'C',
            text: getLocalizedText(
              'Büyük bir sorumluluk. Sabırla çalışıp aşama aşama takımı hedeflediğimiz noktaya taşıyacağız.',
              'It is a major responsibility. With patience and hard work, we will reach our goals step by step.',
              'Es una gran responsabilidad. Con paciencia y trabajo alcanzaremos nuestros objetivos.',
              'C\'est une immense responsabilité. Avec du travail, nous atteindrons nos objectifs étape par étape.',
              'Una grande responsabilità. Con pazienza e lavoro porteremo la squadra dove merita.',
              'Eine große Verantwortung. Mit Geduld und akribischer Arbeit erreichen wir unsere Ziele.',
              'Uma grande responsabilidade. Com paciência e trabalho levaremos o time aos objetivos.'
            ),
            effect: getLocalizedText('Yönetim Güveni & İstikrar Arttı! (+10 Güven)', 'Board Confidence & Stability Boosted! (+10 Confidence)', '¡Confianza de la directiva aumentada! (+10)', 'Confiance de la direction consolidée ! (+10)', 'Fiducia della dirigenza aumentata! (+10)', 'Vorstandsvertrauen & Stabilität gestärkt! (+10)', 'Confiança da diretoria aumentada! (+10)'),
            effectType: 'confidence'
          }
        ]
      },
      {
        id: 2,
        reporter: getLocalizedText('Can Berk', 'Nathan Cooper', 'Marcos Rey', 'Lucas Lambert', 'Stefano Mancini', 'Jonas Fischer', 'Guilherme Ramos'),
        mediaOutlet: getLocalizedText('Futbol Gazetesi', 'Football Daily', 'Mundo Deportivo', 'L\'Équipe Quotidien', 'Corriere Sportivo', 'Sport Kurier', 'Jornal do Futebol'),
        avatar: '📰',
        questionText: getLocalizedText(
          `Takımın transfer stratejisi ve oyun anlayışı konusunda taraftarlara mesajınız nedir?`,
          `What is your message to fans regarding the transfer policy and tactical style of play?`,
          `¿Cuál es su mensaje para la afición respecto a los fichajes y el estilo de juego táctico?`,
          `Quel message adressez-vous aux supporters concernant les transferts et le style de jeu ?`,
          `Qual è il suo messaggio per i tifosi sulla strategia di mercato e la filosofia di gioco?`,
          `Welche Botschaft haben Sie für die Fans bezüglich Transferstrategie und Spielphilosophie?`,
          `Qual é a sua mensagem para a torcida sobre contratações e filosofia de jogo?`
        ),
        options: [
          {
            label: 'A',
            text: getLocalizedText(
              `Dinamik, ofansif ve pres yapan bir futbol oynayacağız. Sahaya her şeyini koyan isimler kadroda yer alacak.`,
              `We will play dynamic, high-pressing attacking football. Only players who give 100% will feature.`,
              `Jugaremos un fútbol dinámico, ofensivo y de presión alta. Solo jugarán quienes den el 100%.`,
              `Nous jouerons un football offensif, intense et avec un pressing haut. 100% d'engagement exigé.`,
              `Giocheremo un calcio dinamico, offensivo e di pressing. In campo solo chi dà il massimo.`,
              `Wir werden dynamischen, offensiven Pressing-Fußball spielen. Voller Einsatz ist Pflicht.`,
              `Jogaremos um futebol dinâmico, ofensivo e com pressão alta. Só jogará quem der 100%.`
            ),
            effect: getLocalizedText('Ofansif Oyun Gücü & Taraftar Sevgisi Arttı', 'Attacking Energy & Fan Love Boosted', 'Fuerza ofensiva y cariño de la afición', 'Élan offensif et soutien populaire accrus', 'Spinta offensiva e affetto dei tifosi', 'Offensivdrang & Fan-Zuspruch gestärkt', 'Força ofensiva e apoio da torcida'),
            effectType: 'morale'
          },
          {
            label: 'B',
            text: getLocalizedText(
              'Önce savunma güvenliğini ve takım dengesini oturtacağız. Disiplin ve taktik sadakat önceliğimizdir.',
              'We will first build defensive solidity and balance. Discipline and tactical loyalty are top priority.',
              'Primero consolidaremos la solidez defensiva y el equilibrio. La disciplina táctica es prioridad.',
              'Nous poserons d\'abord les bases défensives et l\'équilibre. La discipline est la priorité.',
              'Prima di tutto solidità difensiva ed equilibrio. Disciplina e fedeltà tattica al primo posto.',
              'Zuerst schaffen wir defensive Stabilität und Balance. Disziplin hat oberste Priorität.',
              'Primeiro vamos consolidar a solidez defensiva e o equilíbrio. A disciplina tática é prioridade.'
            ),
            effect: getLocalizedText('Takım Savunma Disiplini Güçlendi', 'Defensive Discipline Strengthened', 'Solidez defensiva reforzada', 'Solidité défensive renforcée', 'Solidità difensiva rafforzata', 'Defensive Stabilität gestärkt', 'Solidez defensiva reforçada'),
            effectType: 'discipline'
          }
        ]
      }
    ];
  }

  const currentQ = (questions && questions.length > 0)
    ? (questions[currentQuestionIndex] || questions[0])
    : null;

  const handleSelectOption = (optionIndex: number) => {
    const updated = [...selectedAnswers, optionIndex];
    setSelectedAnswers(updated);

    if (questions && currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setIsFinished(true);
      confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
    }
  };

  const handleFinalSubmit = () => {
    const answersSummary = selectedAnswers.map((optIdx, qIdx) => questions[qIdx]?.options?.[optIdx]?.text || '');
    onComplete(answersSummary);
  };

  const isDerby = postMatchData?.isDerby;
  const teamBadge = team?.badgeColor || 'from-purple-600 to-indigo-600';
  const managerNameStr = managerName;
  const managerInitials = managerNameStr.trim() ? managerNameStr.trim().split(' ').map(n => n[0] || '').join('') : 'TD';

  return (
    <div className="fixed inset-0 z-[9995] bg-[#07050f]/95 backdrop-blur-xl flex items-center justify-center p-2 sm:p-4 overflow-y-auto select-none w-screen h-screen">
      
      {/* Sponsor Wall Background Graphic */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/30 via-[#0a0718] to-[#04030a] pointer-events-none" />

      {/* Main Card */}
      <div className="w-full max-w-2xl max-h-[94vh] bg-[#140f29]/95 border-2 border-[#392e5c] rounded-2xl shadow-2xl overflow-hidden flex flex-col relative z-10">
        
        {/* Header Bar: Press Conference Banner */}
        <div className="bg-gradient-to-r from-[#1b1438] via-[#2d2154] to-[#1b1438] p-2.5 sm:p-3 border-b border-[#3d3163] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center text-white shadow-xl shrink-0 ${
              isDerby
                ? 'bg-gradient-to-tr from-amber-500 via-rose-600 to-red-600 animate-pulse'
                : 'bg-gradient-to-tr from-amber-500 via-purple-600 to-indigo-600'
            }`}>
              {isDerby ? <Flame className="w-4 h-4 text-amber-200" /> : <Mic className="w-4 h-4 text-amber-200" />}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className={`px-1.5 py-0.2 rounded font-black text-[8px] sm:text-[9px] uppercase tracking-wider border ${
                  isDerby
                    ? 'bg-rose-500/20 border-rose-400/40 text-rose-300'
                    : 'bg-purple-500/20 border-purple-400/40 text-purple-300'
                }`}>
                  {isDerby ? `🔥 ${t('LIVE_DERBY')}` : mode === 'POST_MATCH' ? `🎥 ${t('LIVE_MATCH_END')}` : `🎤 ${t('LIVE_SIGNING_CEREMONY')}`}
                </span>
                <span className="text-[9px] text-amber-300 font-bold flex items-center gap-1">
                  <Camera className="w-3 h-3 animate-pulse text-amber-400" /> {t('MEDIA_TITLE')}
                </span>
              </div>
              <h2 className="text-xs sm:text-sm font-black text-white uppercase tracking-wide leading-tight mt-0.5">
                {teamName} &bull; {mode === 'POST_MATCH' ? t('MATCH_END_REVIEWS') : t('HEAD_COACH_PRESENTATION')}
              </h2>
            </div>
          </div>

          <div className="text-right shrink-0">
            <span className="text-[9px] text-slate-400 font-bold block">{t('QUESTION_LABEL')}</span>
            <span className="text-xs font-black text-amber-400">
              {isFinished ? t('QUESTION_FINISHED') : `${currentQuestionIndex + 1} / ${questions.length}`}
            </span>
          </div>
        </div>

        {/* Middle Stage: Manager at Microphones Table & Sponsor Back Wall */}
        <div className="relative bg-[#0d091e] border-b border-[#2d234d] p-2.5 sm:p-3 flex items-center justify-between gap-3 overflow-hidden shrink-0">
          
          {/* Sponsor Backdrop Wall Pattern */}
          <div className="absolute inset-0 bg-[radial-gradient(#ffffff0a_1px,transparent_1px)] [background-size:12px_12px] opacity-30 pointer-events-none" />

          {/* Left: Manager Avatar & Microphones Table */}
          <div className="flex items-center gap-2.5 relative z-10">
            <div className="relative">
              <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br ${teamBadge} p-0.5 shadow-xl flex items-center justify-center border border-white/20`}>
                <div className="w-full h-full bg-[#171230] rounded-lg flex items-center justify-center font-black text-xs sm:text-sm text-white">
                  {managerInitials}
                </div>
              </div>
              <div className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 font-black text-[8px] px-1 py-0.2 rounded-full border border-white uppercase shadow">
                TD
              </div>
            </div>

            <div>
              <h3 className="font-black text-xs sm:text-sm text-white leading-tight">{managerNameStr}</h3>
              <p className="text-[10px] text-amber-300 font-bold leading-none">{teamName} {t('HEAD_COACH_LABEL')}</p>
            </div>
          </div>

          {/* Right: Sponsor Logos Badges */}
          <div className="flex items-center gap-1 relative z-10 opacity-75">
            <span className="px-2 py-0.5 rounded bg-slate-900/80 border border-slate-700/60 text-[9px] font-black text-slate-300">
              LEAGUE TV
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-900/80 border border-slate-700/60 text-[9px] font-black text-amber-400">
              SPORT TV
            </span>
          </div>
        </div>

        {/* Content Area: Questions or Summary */}
        <div className="p-2.5 sm:p-4 bg-[#120d26] flex-1 overflow-y-auto custom-scrollbar min-h-0 flex flex-col">
          {(!isFinished && currentQ) ? (
            <div className="space-y-2.5 sm:space-y-3 animate-fadeIn pb-4">
              
              {/* Reporter Box */}
              <div className="bg-[#1b1438] border border-[#392c5e] p-2.5 sm:p-3 rounded-xl flex items-start gap-2.5 shadow-lg">
                <div className="text-xl p-1.5 rounded-lg bg-[#281d4f] border border-[#483780] shrink-0">
                  {currentQ.avatar}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                    <span className="font-black text-white text-xs sm:text-sm">{currentQ.reporter}</span>
                    <span className="text-[9px] font-bold text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-full">
                      {currentQ.mediaOutlet}
                    </span>
                  </div>
                  <p className="text-xs text-slate-200 font-medium leading-snug italic">
                    "{currentQ.questionText}"
                  </p>
                </div>
              </div>

              {/* Options */}
              <div className="space-y-1.5 sm:space-y-2">
                <span className="text-[10px] font-black uppercase text-amber-300 tracking-wider block">
                  {t('CHOOSE_ANSWER')}
                </span>

                {currentQ.options?.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(idx)}
                    className="w-full text-left p-2.5 sm:p-3 rounded-xl bg-[#1a1433] hover:bg-[#281e4d] border border-[#35285e] hover:border-purple-400 transition-all flex items-start gap-2.5 group active:scale-[0.99] shadow-md cursor-pointer"
                  >
                    <span className="w-6 h-6 rounded-lg bg-purple-600 group-hover:bg-amber-500 group-hover:text-slate-950 font-black text-xs text-white flex items-center justify-center shrink-0 transition-all mt-0.5">
                      {opt.label}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-white group-hover:text-amber-200 leading-snug">
                        {opt.text}
                      </p>
                      <span className="inline-block text-[9px] font-extrabold text-emerald-400 mt-1 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.2 rounded">
                        {t('EFFECT_LABEL')}: {opt.effect}
                      </span>
                    </div>
                  </button>
                ))}
              </div>

            </div>
          ) : (
            <div className="text-center space-y-3 py-4 my-auto animate-fadeIn">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 border-2 border-emerald-400 text-emerald-400 flex items-center justify-center mx-auto shadow-xl">
                <CheckCircle2 className="w-6 h-6" />
              </div>

              <div>
                <h3 className="text-base sm:text-lg font-black text-white">{t('PRESS_CONFERENCE_COMPLETED')}</h3>
                <p className="text-xs text-slate-300 font-medium max-w-md mx-auto mt-0.5">
                  {t('PRESS_CONFERENCE_DESC')}
                </p>
              </div>

              <button
                onClick={handleFinalSubmit}
                className="px-6 py-2.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs sm:text-sm rounded-xl border border-emerald-300 shadow-xl transition-all active:scale-95 inline-flex items-center gap-2"
              >
                <span>{t('RETURN_TO_INTERFACE')}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
