import React, { useState, useEffect } from 'react';
import { Smartphone, RotateCcw, Shield } from 'lucide-react';

export const RotateDeviceOverlay: React.FC = () => {
  const [isPortrait, setIsPortrait] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.innerHeight > window.innerWidth && window.innerWidth < 1024;
    }
    return false;
  });

  useEffect(() => {
    const handleResize = () => {
      setIsPortrait(window.innerHeight > window.innerWidth && window.innerWidth < 1024);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, []);

  if (!isPortrait) return null;

  return (
    <div className="rotate-overlay fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-xl flex flex-col items-center justify-center p-6 text-center text-white space-y-6">
      
      {/* Animated Phone Rotation Icon */}
      <div className="relative">
        <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-emerald-600/30 via-teal-500/20 to-cyan-500/30 border border-emerald-500/40 flex items-center justify-center animate-pulse shadow-2xl shadow-emerald-500/20">
          <Smartphone className="w-12 h-12 text-emerald-400 animate-bounce" />
        </div>
        <div className="absolute -bottom-2 -right-2 p-2 bg-slate-900 border border-emerald-500/50 rounded-full text-emerald-400 shadow-lg">
          <RotateCcw className="w-5 h-5 animate-spin" style={{ animationDuration: '4s' }} />
        </div>
      </div>

      {/* Message */}
      <div className="max-w-xs space-y-2">
        <span className="px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-[10px] font-black uppercase tracking-wider inline-block">
          YATAY EKRAN MODU ZORUNLU
        </span>
        <h3 className="text-lg font-black text-white">
          Cihazınızı Yan Çevirin
        </h3>
        <p className="text-xs text-slate-300 font-medium leading-relaxed">
          🎮 En iyi menajerlik deneyimi için lütfen cihazınızı YATAY çevirin.
        </p>
      </div>

      {/* Visual orientation indicator */}
      <div className="flex items-center gap-3 pt-2 text-[11px] font-bold text-slate-400 bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-800">
        <Shield className="w-4 h-4 text-emerald-400" />
        <span>Taktik Tahtası & Maç Simülasyonu Yatay Uyumlu</span>
      </div>

    </div>
  );
};
