import React, { useState, useEffect } from 'react';
import { CustomPlayerAvatar } from '../types';
import { RotateCw, Sparkles, Shield, User } from 'lucide-react';

interface PlayerAvatarRendererProps {
  avatar?: CustomPlayerAvatar;
  jerseyColor?: string;
  className?: string;
  size?: number;
  show3DControls?: boolean;
  interactiveRotation?: boolean;
}

export const PlayerAvatarRenderer: React.FC<PlayerAvatarRendererProps> = ({
  avatar = {
    skinTone: 'Buğday',
    hairStyle: 'Fade',
    hairColor: 'Siyah',
    eyeColor: 'Kahverengi',
    sleeveLength: 'Uzun Kol',
    bootColor: 'Neon Sarı',
  },
  jerseyColor = '#7b2cbf',
  className = '',
  size = 140,
  show3DControls = true,
  interactiveRotation = true
}) => {
  const [rotationAngle, setRotationAngle] = useState<number>(0);
  const [pulseKey, setPulseKey] = useState<number>(0);

  useEffect(() => {
    setPulseKey((prev) => prev + 1);
  }, [avatar.skinTone, avatar.hairStyle, avatar.hairColor, avatar.eyeColor, avatar.sleeveLength, avatar.bootColor]);

  // Skin Palette with realistic highlights, base, shadow, and blush
  const skinColorMap: Record<CustomPlayerAvatar['skinTone'], { base: string; shadow: string; darkShadow: string; highlight: string; blush: string }> = {
    'Açık': { base: '#fce3db', shadow: '#f3bfae', darkShadow: '#d49885', highlight: '#ffffff', blush: '#f8a896' },
    'Buğday': { base: '#f3c19e', shadow: '#d99c73', darkShadow: '#b2744c', highlight: '#fdf0e6', blush: '#e59675' },
    'Bronz': { base: '#e1ad6d', shadow: '#b98144', darkShadow: '#8e5926', highlight: '#f6dcb8', blush: '#c47d3d' },
    'Esmer': { base: '#b87c47', shadow: '#8d5524', darkShadow: '#613713', highlight: '#dcb189', blush: '#955424' },
    'Koyu': { base: '#70421a', shadow: '#4a290c', darkShadow: '#2f1805', highlight: '#9c6738', blush: '#542d0b' },
  };

  // Hair Palette with realistic 3D specular shine and shadow depth
  const hairColorMap: Record<CustomPlayerAvatar['hairColor'], { base: string; highlight: string; specular: string; shadow: string }> = {
    'Siyah': { base: '#1a1816', highlight: '#3a3530', specular: '#6e675e', shadow: '#0a0908' },
    'Kahverengi': { base: '#4a2c1b', highlight: '#73462d', specular: '#9e6747', shadow: '#2d180c' },
    'Sarı': { base: '#d9a014', highlight: '#facc15', specular: '#fef08a', shadow: '#926505' },
    'Kızıl': { base: '#991b1b', highlight: '#dc2626', specular: '#f87171', shadow: '#581111' },
    'Gümüş': { base: '#8d96a0', highlight: '#cbd5e1', specular: '#f8fafc', shadow: '#475569' },
  };

  const eyeColorMap: Record<CustomPlayerAvatar['eyeColor'], { iris: string; ring: string }> = {
    'Kahverengi': { iris: '#542907', ring: '#271002' },
    'Mavi': { iris: '#0284c7', ring: '#075985' },
    'Yeşil': { iris: '#16a34a', ring: '#14532d' },
    'Ela': { iris: '#ca8a04', ring: '#713f12' },
  };

  const bootColorMap: Record<CustomPlayerAvatar['bootColor'], { primary: string; secondary: string; accent: string }> = {
    'Neon Sarı': { primary: '#facc15', secondary: '#16a34a', accent: '#ffffff' },
    'Kırmızı': { primary: '#ef4444', secondary: '#991b1b', accent: '#ffffff' },
    'Mavi': { primary: '#3b82f6', secondary: '#1d4ed8', accent: '#93c5fd' },
    'Siyah': { primary: '#27272a', secondary: '#52525b', accent: '#e4e4e7' },
    'Beyaz': { primary: '#f8fafc', secondary: '#cbd5e1', accent: '#3b82f6' },
    'Altın': { primary: '#eab308', secondary: '#854d0e', accent: '#ffffff' },
  };

  const skin = skinColorMap[avatar.skinTone] || skinColorMap['Buğday'];
  const hair = hairColorMap[avatar.hairColor] || hairColorMap['Siyah'];
  const eye = eyeColorMap[avatar.eyeColor] || eyeColorMap['Kahverengi'];
  const boot = bootColorMap[avatar.bootColor] || bootColorMap['Neon Sarı'];

  const handleRotate3D = () => {
    setRotationAngle((prev) => (prev === 0 ? 25 : prev === 25 ? -25 : 0));
  };

  return (
    <div className={`relative flex flex-col items-center justify-center ${className}`}>
      
      {/* 3D Studio Display Box */}
      <div
        className="relative flex items-center justify-center p-3 rounded-3xl bg-gradient-to-b from-[#1c1438] via-[#100b26] to-[#070414] border-2 border-purple-500/40 shadow-[0_12px_36px_rgba(123,44,191,0.4)] transition-all duration-500 overflow-hidden group select-none"
        style={{ perspective: '700px' }}
      >
        {/* Ambient Studio Lighting Glow */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_25%,rgba(199,125,255,0.3),transparent_65%)] pointer-events-none" />
        <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* 3D Rotatable Character Container */}
        <div
          className="relative transition-transform duration-500 ease-out flex items-center justify-center"
          style={{
            transform: `rotateY(${rotationAngle}deg) rotateX(3deg)`,
            transformStyle: 'preserve-3d',
          }}
        >
          <svg
            width={size}
            height={size * 1.18}
            viewBox="0 0 130 150"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="filter drop-shadow-[0_14px_22px_rgba(0,0,0,0.7)]"
          >
            <defs>
              {/* Studio Pedestal Glow */}
              <radialGradient id="pedestalGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#c77dff" stopOpacity="0.7" />
                <stop offset="50%" stopColor="#7b2cbf" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0" />
              </radialGradient>

              {/* Realistic 3D Skin Gradient */}
              <linearGradient id="skin3DGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor={skin.highlight} />
                <stop offset="35%" stopColor={skin.base} />
                <stop offset="80%" stopColor={skin.shadow} />
                <stop offset="100%" stopColor={skin.darkShadow} />
              </linearGradient>

              {/* Face Contour Shadow */}
              <linearGradient id="chinShadowGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor={skin.darkShadow} stopOpacity="0.6" />
                <stop offset="100%" stopColor={skin.shadow} stopOpacity="0" />
              </linearGradient>

              {/* 3D Hair Texture Gradient */}
              <linearGradient id="hair3DGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor={hair.specular} />
                <stop offset="30%" stopColor={hair.highlight} />
                <stop offset="70%" stopColor={hair.base} />
                <stop offset="100%" stopColor={hair.shadow} />
              </linearGradient>

              {/* Jersey Fabric Shader */}
              <linearGradient id="jerseyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.35" />
                <stop offset="50%" stopColor={jerseyColor} />
                <stop offset="100%" stopColor="#0a0518" stopOpacity="0.65" />
              </linearGradient>
            </defs>

            {/* Studio Pedestal & Shadow */}
            <ellipse cx="65" cy="142" rx="46" ry="7" fill="url(#pedestalGlow)" />
            <ellipse cx="65" cy="142" rx="34" ry="4" fill="#000000" opacity="0.6" />

            {/* Soccer Boots */}
            <g transform="translate(2, 6)">
              {/* Left Boot */}
              <path d="M 44 126 C 42 126, 36 128, 34 132 C 32 135, 36 137, 46 137 L 50 135 L 50 126 Z" fill={boot.primary} />
              <path d="M 34 132 C 36 134, 42 134, 46 133" stroke={boot.secondary} strokeWidth="1.8" />
              <circle cx="38" cy="135" r="1.2" fill={boot.accent} />
              <circle cx="42" cy="135" r="1.2" fill={boot.accent} />

              {/* Right Boot */}
              <path d="M 86 126 C 88 126, 94 128, 96 132 C 98 135, 94 137, 84 137 L 80 135 L 80 126 Z" fill={boot.primary} />
              <path d="M 96 132 C 94 134, 88 134, 84 133" stroke={boot.secondary} strokeWidth="1.8" />
              <circle cx="92" cy="135" r="1.2" fill={boot.accent} />
              <circle cx="88" cy="135" r="1.2" fill={boot.accent} />
            </g>

            {/* Socks & Legs */}
            <rect x="45" y="112" width="10" height="18" rx="3" fill="#1e1b4b" />
            <rect x="75" y="112" width="10" height="18" rx="3" fill="#1e1b4b" />
            <rect x="45" y="112" width="10" height="4" fill="#ffffff" opacity="0.9" />
            <rect x="75" y="112" width="10" height="4" fill="#ffffff" opacity="0.9" />

            {/* Neck Structure */}
            <rect x="56" y="66" width="18" height="18" rx="4" fill="url(#skin3DGrad)" />
            <path d="M 56 68 Q 65 74 74 68 Z" fill="url(#chinShadowGrad)" />

            {/* Shoulders & Jersey */}
            <path
              d="M 28 114 C 28 84, 42 76, 56 76 L 74 76 C 88 76, 102 84, 102 114 Z"
              fill="url(#jerseyGrad)"
            />
            {/* V-Neck Collar & Trim */}
            <path d="M 56 76 L 65 90 L 74 76 Z" fill="#ffffff" opacity="0.95" />
            <path d="M 60 76 L 65 86 L 70 76 Z" fill={jerseyColor} />

            {/* Metallic Club Crest Badge on Left Chest */}
            <g transform="translate(40, 84)">
              <polygon points="6,0 12,3 12,9 6,13 0,9 0,3" fill="#facc15" stroke="#ffffff" strokeWidth="1" />
              <circle cx="6" cy="6" r="2.5" fill="#7b2cbf" />
            </g>

            {/* Sleeve Customizations */}
            {avatar.sleeveLength === 'Uzun Kol' && (
              <g fill={jerseyColor}>
                <path d="M 28 98 L 20 114 L 32 114 Z" />
                <path d="M 102 98 L 110 114 L 98 114 Z" />
              </g>
            )}

            {avatar.sleeveLength === 'Termal İçlik' && (
              <g fill="#09090b">
                <path d="M 28 94 L 18 114 L 30 114 Z" />
                <path d="M 102 94 L 112 114 L 100 114 Z" />
              </g>
            )}

            {avatar.sleeveLength === 'Kol Bandı' && (
              <g fill="#ffffff">
                <rect x="24" y="98" width="8" height="6" rx="1.5" />
                <rect x="98" y="98" width="8" height="6" rx="1.5" />
              </g>
            )}

            {/* HEAD & FACE STRUCTURE */}
            {/* Ears with Cartilage Shading */}
            <g>
              <ellipse cx="41" cy="48" rx="4.5" ry="6.5" fill={skin.base} />
              <ellipse cx="89" cy="48" rx="4.5" ry="6.5" fill={skin.base} />
              <path d="M 41 44 Q 43 48 41 52" stroke={skin.shadow} strokeWidth="1.2" fill="none" />
              <path d="M 89 44 Q 87 48 89 52" stroke={skin.shadow} strokeWidth="1.2" fill="none" />
            </g>

            {/* Head Contour */}
            <path
              d="M 43 45 C 43 25, 52 20, 65 20 C 78 20, 87 25, 87 45 C 87 60, 78 70, 65 70 C 52 70, 43 60, 43 45 Z"
              fill="url(#skin3DGrad)"
            />

            {/* Cheekbone & Chin Highlight Layers */}
            <ellipse cx="54" cy="54" rx="5" ry="3" fill={skin.blush} opacity="0.3" />
            <ellipse cx="76" cy="54" rx="5" ry="3" fill={skin.blush} opacity="0.3" />
            <ellipse cx="65" cy="65" rx="4" ry="2" fill={skin.highlight} opacity="0.4" />

            {/* REALISTIC EYES */}
            {/* Left Eye */}
            <g>
              <ellipse cx="55" cy="46" rx="4.5" ry="3.2" fill="#ffffff" />
              <ellipse cx="55" cy="46" rx="4.5" ry="3.2" stroke={skin.darkShadow} strokeWidth="0.8" fill="none" />
              <circle cx="55" cy="46" r="2.5" fill={eye.iris} />
              <circle cx="55" cy="46" r="1.2" fill={eye.ring} />
              <circle cx="53.8" cy="44.8" r="0.8" fill="#ffffff" />
            </g>

            {/* Right Eye */}
            <g>
              <ellipse cx="75" cy="46" rx="4.5" ry="3.2" fill="#ffffff" />
              <ellipse cx="75" cy="46" rx="4.5" ry="3.2" stroke={skin.darkShadow} strokeWidth="0.8" fill="none" />
              <circle cx="75" cy="46" r="2.5" fill={eye.iris} />
              <circle cx="75" cy="46" r="1.2" fill={eye.ring} />
              <circle cx="73.8" cy="44.8" r="0.8" fill="#ffffff" />
            </g>

            {/* Eyebrows */}
            <path d="M 48 40 Q 55 37 60 40" stroke={hair.base} strokeWidth="2.4" strokeLinecap="round" fill="none" />
            <path d="M 70 40 Q 75 37 82 40" stroke={hair.base} strokeWidth="2.4" strokeLinecap="round" fill="none" />

            {/* Realistic Nose Bridge & Nostril Shadow */}
            <path d="M 65 42 L 63 53 Q 65 56 67 53 Z" fill={skin.highlight} opacity="0.3" />
            <path d="M 63 53 C 63 56, 67 56, 67 53" stroke={skin.darkShadow} strokeWidth="1.6" strokeLinecap="round" fill="none" />

            {/* Realistic Lips */}
            <path d="M 57 61 Q 65 59 73 61 Q 65 66 57 61 Z" fill={skin.blush} opacity="0.85" />
            <path d="M 57 61 Q 65 63 73 61" stroke={skin.darkShadow} strokeWidth="1.2" strokeLinecap="round" fill="none" />

            {/* HIGH-FIDELITY HAIRSTYLES */}

            {/* 1. Uzun Saç (Flowing Long Hair) */}
            {avatar.hairStyle === 'Uzun' && (
              <g fill="url(#hair3DGrad)">
                <path d="M 41 48 C 41 20, 52 14, 65 14 C 78 14, 89 20, 89 48 C 93 68, 86 88, 81 94 C 77 80, 86 52, 65 34 C 44 52, 53 80, 49 94 C 45 88, 37 68, 41 48 Z" />
                <path d="M 39 48 L 32 82 L 43 72 Z" opacity="0.95" />
                <path d="M 91 48 L 98 82 L 87 72 Z" opacity="0.95" />
                <path d="M 55 18 C 65 18, 75 22, 70 30" stroke={hair.specular} strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.7" />
              </g>
            )}

            {/* 2. Kısa Saç (Classic Short Layered Crop) */}
            {avatar.hairStyle === 'Kısa' && (
              <g fill="url(#hair3DGrad)">
                <path d="M 41 44 C 41 22, 52 16, 65 16 C 78 16, 89 22, 89 44 C 84 35, 75 28, 65 28 C 55 28, 46 35, 41 44 Z" />
                <path d="M 50 26 Q 65 19 80 26 Z" fill={hair.specular} opacity="0.6" />
                {/* Fringe strands */}
                <path d="M 52 30 Q 56 36 60 30" stroke={hair.base} strokeWidth="2" strokeLinecap="round" />
                <path d="M 64 30 Q 68 36 72 30" stroke={hair.base} strokeWidth="2" strokeLinecap="round" />
              </g>
            )}

            {/* 3. Fade / Amerikan (Textured Top & Faded Gradient Sides) */}
            {avatar.hairStyle === 'Fade' && (
              <g>
                <path
                  d="M 42 41 C 43 23, 52 16, 65 16 C 78 16, 87 23, 88 41 C 82 32, 74 25, 65 25 C 56 25, 48 32, 42 41 Z"
                  fill="url(#hair3DGrad)"
                />
                <path d="M 40 46 C 40 38, 43 32, 46 32 L 46 48 Z" fill={hair.base} opacity="0.45" />
                <path d="M 90 46 C 90 38, 87 32, 84 32 L 84 48 Z" fill={hair.base} opacity="0.45" />
                {/* Top Volumetric Spikes */}
                <path d="M 50 22 Q 54 16 58 20" stroke={hair.specular} strokeWidth="2.5" strokeLinecap="round" fill="none" />
                <path d="M 62 20 Q 66 14 70 18" stroke={hair.specular} strokeWidth="2.5" strokeLinecap="round" fill="none" />
              </g>
            )}

            {/* 4. Bukleli / Kıvırcık (3D Textured Ringlets) */}
            {avatar.hairStyle === 'Bukleli' && (
              <g fill="url(#hair3DGrad)">
                <circle cx="65" cy="18" r="10" />
                <circle cx="52" cy="20" r="9" />
                <circle cx="78" cy="20" r="9" />
                <circle cx="43" cy="26" r="8" />
                <circle cx="87" cy="26" r="8" />
                <circle cx="40" cy="36" r="7" />
                <circle cx="90" cy="36" r="7" />
                <circle cx="58" cy="14" r="9" />
                <circle cx="72" cy="14" r="9" />
                {/* Curls Highlight Specular overlay */}
                <circle cx="63" cy="16" r="3" fill={hair.specular} opacity="0.6" />
                <circle cx="50" cy="18" r="3" fill={hair.specular} opacity="0.6" />
                <circle cx="76" cy="18" r="3" fill={hair.specular} opacity="0.6" />
              </g>
            )}

            {/* 5. Buzz Cut / Askeri (Clean Stubble Texture) */}
            {avatar.hairStyle === 'Buzz' && (
              <g>
                <path
                  d="M 41 44 C 41 24, 52 18, 65 18 C 78 18, 89 24, 89 44 C 84 36, 75 30, 65 30 C 55 30, 46 36, 41 44 Z"
                  fill="url(#hair3DGrad)"
                  opacity="0.9"
                />
                <path d="M 48 30 Q 65 24 82 30" stroke={hair.specular} strokeWidth="1.5" strokeDasharray="2 2" opacity="0.5" />
              </g>
            )}

          </svg>
        </div>

        {/* Live 3D Badge */}
        <div className="absolute top-2 left-2 text-[9px] font-black px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-200 border border-purple-500/30 backdrop-blur-sm flex items-center gap-1">
          <Sparkles className="w-2.5 h-2.5 text-amber-300 animate-spin" />
          <span>REALİSTİK 3D AVATAR</span>
        </div>

        {/* 3D Rotate Button */}
        {interactiveRotation && (
          <button
            onClick={handleRotate3D}
            className="absolute bottom-2 right-2 p-1.5 rounded-xl bg-purple-600/80 hover:bg-purple-500 text-white shadow-lg border border-purple-300/40 active:scale-95 transition-all text-[10px] font-bold flex items-center gap-1"
            title="3D Modeli Döndür"
          >
            <RotateCw className="w-3 h-3 text-amber-300" /> 3D Döndür
          </button>
        )}
      </div>

    </div>
  );
};
