import React, { useState } from 'react';
import { Team } from '../types';
import { X, DollarSign, TrendingUp, TrendingDown, Building2, Ticket, Award, CreditCard, ShieldAlert, BarChart3 } from 'lucide-react';
import { useTranslation } from '../utils/i18n';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  Cell
} from 'recharts';

interface FinancesModalProps {
  isOpen: boolean;
  onClose: () => void;
  team: Team;
}

export const FinancesModal: React.FC<FinancesModalProps> = ({
  isOpen,
  onClose,
  team
}) => {
  const { t, language } = useTranslation();
  const isTr = language === 'TR';

  if (!isOpen || !team) return null;

  // Calculate detailed financial breakdown based on Süper Lig real club tiers
  const totalPlayers = team.players.length;
  
  // Weekly total wage bill calculated from real squad members
  const weeklyWageBill = team.players.reduce((sum, p) => sum + (p.wage || 20000), 0);
  const annualWageBill = weeklyWageBill * 52;

  // Determine club financial scale tier
  const isEliteClub = team.budget >= 15_000_000 || ['galatasaray', 'fenerbahce', 'besiktas', 'trabzonspor'].includes(team.id) || ['Galatasaray', 'Fenerbahçe', 'Beşiktaş', 'Trabzonspor'].includes(team.name);
  const isMidTable = !isEliteClub && team.budget >= 5_000_000;

  // Realistic Matchday ticket & stadium revenue (capacity * avg ticket price * 19 home matches)
  const ticketAvgPrice = isEliteClub ? 30 : isMidTable ? 15 : 10; // in Euros
  const matchdayRevenuePerMatch = Math.round((team.stadiumCapacity || 35000) * ticketAvgPrice * 0.75); // 75% avg stadium occupancy
  const annualMatchdayRevenue = matchdayRevenuePerMatch * 19; 
  const weeklyMatchdayAvg = Math.round(annualMatchdayRevenue / 38);

  // TV Broadcasting Rights (TFF pool distribution based on performance & prestige)
  const annualTvRights = isEliteClub ? 7_500_000 : isMidTable ? 4_200_000 : 2_800_000;
  const weeklyTvAvg = Math.round(annualTvRights / 38);

  // Sponsorships & Commercial (Kit supplier, main chest sponsor, stadium naming rights)
  const annualSponsorship = isEliteClub ? 22_000_000 : isMidTable ? 5_500_000 : 2_100_000;
  const weeklySponsorshipAvg = Math.round(annualSponsorship / 52);

  // Official Store & Merchandise Revenue
  const annualMerchandise = isEliteClub ? 11_000_000 : isMidTable ? 2_200_000 : 800_000;
  const weeklyMerchandiseAvg = Math.round(annualMerchandise / 52);

  // Facility, Academy & Travel Expenses
  const annualFacilityCost = isEliteClub ? 5_200_000 : isMidTable ? 2_100_000 : 1_100_000;
  const weeklyFacilityCost = Math.round(annualFacilityCost / 52);

  // Total Annual Revenues & Expenses
  const totalAnnualIncomes = annualMatchdayRevenue + annualTvRights + annualSponsorship + annualMerchandise;
  const totalAnnualExpenses = annualWageBill + annualFacilityCost;
  const netAnnualProfitLoss = totalAnnualIncomes - totalAnnualExpenses;

  // Weekly Incomes and Expenses baseline
  const estimatedWeeklyIncome = weeklyMatchdayAvg + weeklyTvAvg + weeklySponsorshipAvg + weeklyMerchandiseAvg;
  const estimatedWeeklyExpense = weeklyWageBill + weeklyFacilityCost;

  // Last 5 weeks dynamic cash flow chart data
  const currentBudgetM = Number((team.budget / 1_000_000).toFixed(2));
  const weeklyNetM = (estimatedWeeklyIncome - estimatedWeeklyExpense) / 1_000_000;

  const chartData = [
    {
      week: isTr ? '4 Hf Önce' : '4 Wks Ago',
      income: Number(((estimatedWeeklyIncome * 0.95) / 1_000_000).toFixed(2)),
      expense: Number(((estimatedWeeklyExpense * 0.98) / 1_000_000).toFixed(2)),
      treasury: Math.max(0, Number((currentBudgetM - weeklyNetM * 4).toFixed(2))),
    },
    {
      week: isTr ? '3 Hf Önce' : '3 Wks Ago',
      income: Number(((estimatedWeeklyIncome * 1.1) / 1_000_000).toFixed(2)),
      expense: Number(((estimatedWeeklyExpense * 1.0) / 1_000_000).toFixed(2)),
      treasury: Math.max(0, Number((currentBudgetM - weeklyNetM * 3).toFixed(2))),
    },
    {
      week: isTr ? '2 Hf Önce' : '2 Wks Ago',
      income: Number(((estimatedWeeklyIncome * 0.85) / 1_000_000).toFixed(2)),
      expense: Number(((estimatedWeeklyExpense * 1.02) / 1_000_000).toFixed(2)),
      treasury: Math.max(0, Number((currentBudgetM - weeklyNetM * 2).toFixed(2))),
    },
    {
      week: isTr ? 'Geçen Hf' : 'Last Wk',
      income: Number(((estimatedWeeklyIncome * 1.05) / 1_000_000).toFixed(2)),
      expense: Number(((estimatedWeeklyExpense * 1.0) / 1_000_000).toFixed(2)),
      treasury: Math.max(0, Number((currentBudgetM - weeklyNetM).toFixed(2))),
    },
    {
      week: isTr ? 'Bu Hafta' : 'This Wk',
      income: Number((estimatedWeeklyIncome / 1_000_000).toFixed(2)),
      expense: Number((estimatedWeeklyExpense / 1_000_000).toFixed(2)),
      treasury: currentBudgetM,
    },
  ];

  return (
    <div className="fixed inset-0 z-[9980] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-[#181528] border-2 border-[#392e61] rounded-2xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 font-sans">
        
        {/* Header */}
        <div className="p-3.5 bg-[#120f21] border-b border-[#2d254a] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-white text-sm sm:text-base flex items-center gap-2">
                {team.name} - {t('FINANCES_TITLE')}
              </h3>
              <p className="text-[10px] text-slate-400 font-semibold">
                {t('FINANCES_SUBTITLE')}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-[#261e42] hover:bg-[#352a5c] text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-3.5 sm:p-5 overflow-y-auto flex-1 space-y-4 custom-scrollbar">
          
          {/* Top Treasury Summary Card */}
          <div className="bg-gradient-to-r from-[#1c1836] via-[#15112a] to-[#0f0c1f] p-4 rounded-2xl border border-[#3b2e63] shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block">
                {t('TREASURY_TRANSFER_BUDGET')}
              </span>
              <span className={`text-2xl sm:text-3xl font-black ${team.budget >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                €{(team.budget / 1_000_000).toFixed(2)}M
              </span>
              <p className="text-[11px] text-slate-400 font-semibold mt-0.5">
                {team.budget < 2000000 ? (
                  <span className="text-rose-400 font-bold flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5" /> {t('BUDGET_CRITICAL_WARNING')}
                  </span>
                ) : (
                  <span className="text-emerald-400 font-bold">✅ {t('BUDGET_OK_INFO')}</span>
                )}
              </p>
            </div>

            <div className="bg-[#100d1e] p-3 rounded-xl border border-[#2c234a] text-right shrink-0 min-w-[160px]">
              <span className="text-[9px] uppercase font-bold text-slate-400 block">{t('WEEKLY_WAGE_BUDGET')}</span>
              <span className="text-base font-black text-amber-300">€{Math.round(weeklyWageBill / 1000)}B / {t('PER_WEEK')}</span>
              <span className="text-[9px] text-slate-500 font-bold block">{t('ANNUAL_LABEL')}: €{(annualWageBill / 1_000_000).toFixed(1)}M</span>
            </div>
          </div>

          {/* SON 5 HAFTALIK BÜTÇE & GELİR-GİDER ÇUBUK GRAFİĞİ (Recharts Bar Chart) */}
          <div className="bg-[#120e21] border border-[#2d234a] rounded-2xl p-3.5 space-y-2.5 shadow-md">
            <div className="flex items-center justify-between border-b border-[#291f42] pb-2">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-purple-400" />
                <h4 className="font-black text-xs text-white uppercase tracking-wider">
                  {isTr ? 'Son 5 Haftalık Gelir - Gider & Kasa Değişimi' : '5-Week Income - Expense & Budget Evolution'}
                </h4>
              </div>
              <span className="text-[10px] text-purple-300 font-black px-2 py-0.5 rounded-full bg-purple-950/60 border border-purple-500/40">
                {isTr ? 'Birim: Milyon €' : 'Unit: Million €'}
              </span>
            </div>

            {/* Recharts Bar Container */}
            <div className="w-full h-48 sm:h-56 pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartData}
                  margin={{ top: 10, right: 10, left: -15, bottom: 0 }}
                  barGap={4}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#251c3f" vertical={false} />
                  <XAxis
                    dataKey="week"
                    stroke="#94a3b8"
                    tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
                    axisLine={{ stroke: '#2e2350' }}
                    tickLine={false}
                  />
                  <YAxis
                    stroke="#94a3b8"
                    tick={{ fill: '#94a3b8', fontSize: 9, fontWeight: 600 }}
                    axisLine={{ stroke: '#2e2350' }}
                    tickLine={false}
                    tickFormatter={(v) => `€${v}M`}
                  />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        const inc = payload.find(p => p.dataKey === 'income')?.value;
                        const exp = payload.find(p => p.dataKey === 'expense')?.value;
                        const trs = payload.find(p => p.dataKey === 'treasury')?.value;
                        return (
                          <div className="bg-[#17122b] border border-purple-500/60 rounded-xl p-2.5 shadow-2xl text-[11px] space-y-1 z-50">
                            <span className="font-black text-white block border-b border-purple-500/30 pb-1">{label}</span>
                            <div className="flex items-center justify-between gap-4 text-emerald-400 font-bold">
                              <span>{isTr ? 'Haftalık Gelir:' : 'Weekly Income:'}</span>
                              <span className="font-black">€{inc}M</span>
                            </div>
                            <div className="flex items-center justify-between gap-4 text-rose-400 font-bold">
                              <span>{isTr ? 'Haftalık Gider:' : 'Weekly Expense:'}</span>
                              <span className="font-black">€{exp}M</span>
                            </div>
                            <div className="flex items-center justify-between gap-4 text-purple-300 font-bold pt-1 border-t border-[#2d2252]">
                              <span>{isTr ? 'Kasa Bütçesi:' : 'Treasury:'}</span>
                              <span className="font-black">€{trs}M</span>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend
                    verticalAlign="top"
                    height={30}
                    formatter={(value) => {
                      if (value === 'income') return <span className="text-[10.5px] font-bold text-emerald-400">{isTr ? 'Gelir (€M)' : 'Income (€M)'}</span>;
                      if (value === 'expense') return <span className="text-[10.5px] font-bold text-rose-400">{isTr ? 'Gider (€M)' : 'Expense (€M)'}</span>;
                      return <span className="text-[10.5px] font-bold text-purple-300">{isTr ? 'Kasa Bakiyesi (€M)' : 'Treasury (€M)'}</span>;
                    }}
                  />
                  <Bar dataKey="income" name="income" fill="#10b981" radius={[4, 4, 0, 0]} maxBarSize={28} />
                  <Bar dataKey="expense" name="expense" fill="#f43f5e" radius={[4, 4, 0, 0]} maxBarSize={28} />
                  <Bar dataKey="treasury" name="treasury" fill="#a855f7" radius={[4, 4, 0, 0]} maxBarSize={28} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Income vs Expenses Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            {/* GELİRLER (Incomes) */}
            <div className="bg-[#120e21] border border-[#2d234a] rounded-2xl p-3.5 space-y-2.5">
              <div className="flex items-center gap-2 border-b border-[#291f42] pb-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <h4 className="font-black text-xs text-emerald-400 uppercase tracking-wider">
                  {t('SEASONAL_INCOMES')}
                </h4>
              </div>

              <div className="space-y-2 text-xs font-semibold">
                <div className="flex justify-between items-center p-2 rounded-xl bg-[#19142d]">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <Ticket className="w-3.5 h-3.5 text-sky-400" /> {t('MATCHDAY_TICKETS')}
                  </span>
                  <span className="font-extrabold text-white">€{(annualMatchdayRevenue / 1_000_000).toFixed(1)}M</span>
                </div>

                <div className="flex justify-between items-center p-2 rounded-xl bg-[#19142d]">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-amber-400" /> {t('TV_BROADCASTING')}
                  </span>
                  <span className="font-extrabold text-white">€{(annualTvRights / 1_000_000).toFixed(1)}M</span>
                </div>

                <div className="flex justify-between items-center p-2 rounded-xl bg-[#19142d]">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-purple-400" /> {t('SPONSORSHIP_COMMERICAL')}
                  </span>
                  <span className="font-extrabold text-white">€{(annualSponsorship / 1_000_000).toFixed(1)}M</span>
                </div>

                <div className="flex justify-between items-center p-2 rounded-xl bg-[#19142d]">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" /> {t('STORE_MERCHANDISE')}
                  </span>
                  <span className="font-extrabold text-white">€{(annualMerchandise / 1_000_000).toFixed(1)}M</span>
                </div>

                <div className="flex justify-between items-center p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 font-extrabold pt-2">
                  <span>{t('TOTAL_ESTIMATED_INCOME')}</span>
                  <span className="text-sm font-black text-emerald-400">€{(totalAnnualIncomes / 1_000_000).toFixed(1)}M</span>
                </div>
              </div>
            </div>

            {/* GİDERLER (Expenses) */}
            <div className="bg-[#120e21] border border-[#2d234a] rounded-2xl p-3.5 space-y-2.5">
              <div className="flex items-center gap-2 border-b border-[#291f42] pb-2">
                <TrendingDown className="w-4 h-4 text-rose-400" />
                <h4 className="font-black text-xs text-rose-400 uppercase tracking-wider">
                  {t('SEASONAL_EXPENSES')}
                </h4>
              </div>

              <div className="space-y-2 text-xs font-semibold">
                <div className="flex justify-between items-center p-2 rounded-xl bg-[#19142d]">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-rose-400" /> {t('TOTAL_PLAYER_WAGES').replace('{count}', String(totalPlayers))}
                  </span>
                  <span className="font-extrabold text-rose-300">€{(annualWageBill / 1_000_000).toFixed(1)}M</span>
                </div>

                <div className="flex justify-between items-center p-2 rounded-xl bg-[#19142d]">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-amber-400" /> {t('FACILITY_MAINTENANCE')}
                  </span>
                  <span className="font-extrabold text-rose-300">€{(annualFacilityCost / 1_000_000).toFixed(1)}M</span>
                </div>

                <div className="flex justify-between items-center p-2 rounded-xl bg-[#19142d]">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-purple-400" /> {t('TRANSFER_INSTALLMENTS')}
                  </span>
                  <span className="font-extrabold text-slate-300">{t('INCLUDED_ANNUAL_INSTALLMENT')}</span>
                </div>

                <div className="flex justify-between items-center p-2.5 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 font-extrabold pt-2">
                  <span>{t('TOTAL_ESTIMATED_EXPENSE')}</span>
                  <span className="text-sm font-black text-rose-400">€{(totalAnnualExpenses / 1_000_000).toFixed(1)}M</span>
                </div>
              </div>
            </div>

          </div>

          {/* Bilanço & Kurallar Notu */}
          <div className="bg-[#100d1d] p-3 rounded-xl border border-[#2d254a] text-xs text-slate-300 space-y-1">
            <div className="flex justify-between items-center font-bold">
              <span>{t('SEASONAL_NET_BALANCE')}</span>
              <span className={`text-sm font-black ${netAnnualProfitLoss >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {netAnnualProfitLoss >= 0
                  ? `+€${(netAnnualProfitLoss / 1_000_000).toFixed(1)}M ${t('PROFIT_LABEL')}`
                  : `-€${(Math.abs(netAnnualProfitLoss) / 1_000_000).toFixed(1)}M ${t('LOSS_LABEL')}`}
              </span>
            </div>
            <p className="text-[10px] text-slate-400 italic pt-1">
              * {t('FINANCE_RULES_NOTE')}
            </p>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-[#120f21] border-t border-[#2d254a] flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#7b2cbf] hover:bg-[#9d4edd] text-white font-extrabold text-xs rounded-xl uppercase tracking-wider cursor-pointer transition-colors"
          >
            {t('UNDERSTOOD_CLOSE')}
          </button>
        </div>

      </div>
    </div>
  );
};
