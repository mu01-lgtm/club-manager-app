import React from 'react';
import { Sparkles, Trophy, Globe, Shield, Cloud, CheckCircle, X } from 'lucide-react';
import { useTranslation } from '../utils/i18n';

interface ComingSoonModalProps {
  isOpen: boolean;
  onClose: () => void;
  type?: 'ONLINE' | 'TOURNAMENT' | 'CREATE_CLUB' | 'CLOUD_PROFILE' | null;
}

export const ComingSoonModal: React.FC<ComingSoonModalProps> = ({
  isOpen,
  onClose,
  type = 'ONLINE'
}) => {
  const { t } = useTranslation();
  if (!isOpen) return null;

  const getContent = () => {
    switch (type) {
      case 'ONLINE':
        return {
          title: t('ONLINE_CAREER_TITLE'),
          icon: Globe,
          iconBg: 'from-purple-600 to-indigo-600',
          badgeText: `${t('COMING_SOON')} 🚀`,
          badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
          desc: t('ONLINE_CAREER_DESC'),
          subDetails: [
            t('ONLINE_FEATURE_1'),
            t('ONLINE_FEATURE_2'),
            t('ONLINE_FEATURE_3')
          ]
        };
      case 'TOURNAMENT':
        return {
          title: t('TOURNAMENTS_TITLE'),
          icon: Trophy,
          iconBg: 'from-amber-500 to-yellow-600',
          badgeText: `${t('COMING_SOON')} 🏆`,
          badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
          desc: t('TOURNAMENTS_MODAL_DESC'),
          subDetails: [
            t('TOURNAMENT_FEATURE_1'),
            t('TOURNAMENT_FEATURE_2'),
            t('TOURNAMENT_FEATURE_3')
          ]
        };
      case 'CREATE_CLUB':
        return {
          title: t('CREATE_CLUB_TITLE'),
          icon: Shield,
          iconBg: 'from-orange-500 to-rose-600',
          badgeText: `${t('COMING_SOON')} 🛡️`,
          badgeColor: 'bg-orange-500/20 text-orange-300 border-orange-500/40',
          desc: t('CREATE_CLUB_MODAL_DESC'),
          subDetails: [
            t('CREATE_CLUB_FEATURE_1'),
            t('CREATE_CLUB_FEATURE_2'),
            t('CREATE_CLUB_FEATURE_3')
          ]
        };
      case 'CLOUD_PROFILE':
      default:
        return {
          title: t('CLOUD_SYNC_TITLE'),
          icon: Cloud,
          iconBg: 'from-sky-500 to-blue-600',
          badgeText: `${t('COMING_SOON')} ☁️`,
          badgeColor: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
          desc: t('CLOUD_SYNC_DESC'),
          subDetails: [
            t('CLOUD_FEATURE_1'),
            t('CLOUD_FEATURE_2'),
            t('CLOUD_FEATURE_3')
          ]
        };
    }
  };

  const content = getContent();
  const IconComponent = content.icon;

  return (
    <div className="fixed inset-0 z-[9999] bg-black/80 backdrop-blur-md flex items-center justify-center p-2.5 sm:p-4 select-none animate-fadeIn">
      
      {/* Container Card */}
      <div className="w-full max-w-[340px] sm:max-w-sm max-h-[85vh] overflow-y-auto custom-scrollbar bg-[#161228] border-2 border-[#382d5e] rounded-2xl p-3.5 sm:p-5 shadow-2xl relative flex flex-col items-center text-center space-y-2.5 my-auto">
        
        {/* Top Glow Accent */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-500 via-amber-400 to-sky-400" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-2.5 right-2.5 p-1 rounded-full bg-[#241c3e] hover:bg-[#322854] text-slate-400 hover:text-white transition-colors border border-[#382d5e]"
        >
          <X className="w-3.5 h-3.5" />
        </button>

        {/* Icon Circle */}
        <div className={`w-11 h-11 sm:w-13 sm:h-13 rounded-xl bg-gradient-to-tr ${content.iconBg} flex items-center justify-center text-white shadow-lg shadow-purple-900/40 mt-0.5 shrink-0`}>
          <IconComponent className="w-5 h-5 sm:w-6 sm:h-6" />
        </div>

        {/* Header Title & Badge */}
        <div className="space-y-0.5">
          <span className={`inline-block text-[9px] sm:text-[10px] font-black px-2 py-0.5 rounded-full border uppercase tracking-wider ${content.badgeColor}`}>
            {content.badgeText}
          </span>
          <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wide">
            {content.title}
          </h3>
        </div>

        {/* Description */}
        <p className="text-[11px] text-slate-300 font-medium leading-relaxed">
          {content.desc}
        </p>

        {/* Sub Details List */}
        <div className="w-full bg-[#1e1836] border border-[#2e254e] rounded-xl p-2.5 text-left space-y-1.5">
          <span className="text-[9.5px] font-black text-amber-300 uppercase tracking-wider block">
            ⭐ {t('PLANNED_FUTURE_FEATURES')}:
          </span>
          {content.subDetails.map((detail, idx) => (
            <div key={idx} className="flex items-center gap-1.5 text-[10.5px] text-slate-300 font-semibold leading-tight">
              <CheckCircle className="w-3 h-3 text-emerald-400 shrink-0" />
              <span>{detail}</span>
            </div>
          ))}
        </div>

        {/* Action Button */}
        <button
          onClick={onClose}
          className="w-full py-2 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:brightness-110 text-white font-black text-[11px] sm:text-xs uppercase tracking-wider shadow-lg transition-all active:scale-95 mt-0.5"
        >
          {t('UNDERSTOOD_CONTINUE')}
        </button>

      </div>
    </div>
  );
};

