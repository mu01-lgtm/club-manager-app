import React from 'react';

interface SoccerJerseyProps {
  number?: number;
  color?: string;
  secondaryColor?: string;
  isGk?: boolean;
  isEmpty?: boolean;
  className?: string;
}

export const SoccerJersey: React.FC<SoccerJerseyProps> = ({
  number = 10,
  color = '#38bdf8',
  secondaryColor = '#ffffff',
  isGk = false,
  isEmpty = false,
  className = 'w-5 h-5 sm:w-6 sm:h-6'
}) => {
  // If empty slot, render a stylish translucent dashed jersey wireframe
  if (isEmpty) {
    return (
      <div className={`relative flex items-center justify-center select-none opacity-60 hover:opacity-100 transition-opacity ${className}`}>
        <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible">
          <path
            d="M 28 22 L 4 36 C 2 40 4 48 9 52 L 22 45 L 25 32 Z"
            fill="rgba(255,255,255,0.05)"
            stroke="rgba(255,255,255,0.6)"
            strokeWidth="2"
            strokeDasharray="4 3"
          />
          <path
            d="M 72 22 L 96 36 C 98 40 96 48 91 52 L 78 45 L 75 32 Z"
            fill="rgba(255,255,255,0.05)"
            stroke="rgba(255,255,255,0.6)"
            strokeWidth="2"
            strokeDasharray="4 3"
          />
          <path
            d="M 28 22 C 36 28 64 28 72 22 L 77 34 L 73 88 C 73 91 70 93 67 93 L 33 93 C 30 93 27 91 27 88 L 23 34 Z"
            fill="rgba(255,255,255,0.08)"
            stroke="rgba(255,255,255,0.7)"
            strokeWidth="2"
            strokeDasharray="5 3"
          />
          <text
            x="50"
            y="58"
            textAnchor="middle"
            dominantBaseline="central"
            fill="rgba(255,255,255,0.9)"
            fontSize="32"
            fontWeight="bold"
          >
            +
          </text>
        </svg>
      </div>
    );
  }

  // Determine dynamic colors for outfield vs GK
  const mainColor = isGk ? '#10b981' : color;
  const gradId = `kit-grad-${isGk ? 'gk' : color.replace(/[^a-zA-Z0-9]/g, '')}-${number}`;
  const collarCol = isGk ? '#064e3b' : (secondaryColor || '#ffffff');
  const sleeveTrimCol = isGk ? '#34d399' : (secondaryColor || '#ffffff');

  return (
    <div className={`relative flex items-center justify-center select-none ${className}`}>
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full overflow-visible filter drop-shadow-[0_3px_5px_rgba(0,0,0,0.85)]"
      >
        <defs>
          {/* Main 3D Gradient for Jersey Body */}
          <linearGradient id={gradId} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={mainColor} stopOpacity="1" />
            <stop offset="60%" stopColor={mainColor} stopOpacity="0.96" />
            <stop offset="100%" stopColor={mainColor} stopOpacity="0.82" />
          </linearGradient>

          {/* Top highlight gradient */}
          <linearGradient id={`hl-${gradId}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.25" />
            <stop offset="50%" stopColor="#ffffff" stopOpacity="0.0" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0.1" />
          </linearGradient>

          {/* Left sleeve gradient */}
          <linearGradient id={`sl-${gradId}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={mainColor} />
            <stop offset="100%" stopColor={mainColor} stopOpacity="0.85" />
          </linearGradient>

          {/* Right sleeve gradient */}
          <linearGradient id={`sr-${gradId}`} x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={mainColor} />
            <stop offset="100%" stopColor={mainColor} stopOpacity="0.85" />
          </linearGradient>
        </defs>

        {/* Left Sleeve */}
        <path
          d="M 28 22 L 5 36 C 3 40 5 48 10 52 L 23 45 L 25 32 Z"
          fill={mainColor}
          stroke="rgba(0,0,0,0.2)"
          strokeWidth="1.2"
        />
        <path
          d="M 28 22 L 5 36 C 3 40 5 48 10 52 L 23 45 L 25 32 Z"
          fill={`url(#sl-${gradId})`}
        />
        {/* Left Sleeve Cuff Trim */}
        <path
          d="M 5 36 L 10 52"
          stroke={sleeveTrimCol}
          strokeWidth="2.8"
          strokeLinecap="round"
        />

        {/* Right Sleeve */}
        <path
          d="M 72 22 L 95 36 C 97 40 95 48 90 52 L 77 45 L 75 32 Z"
          fill={mainColor}
          stroke="rgba(0,0,0,0.2)"
          strokeWidth="1.2"
        />
        <path
          d="M 72 22 L 95 36 C 97 40 95 48 90 52 L 77 45 L 75 32 Z"
          fill={`url(#sr-${gradId})`}
        />
        {/* Right Sleeve Cuff Trim */}
        <path
          d="M 95 36 L 90 52"
          stroke={sleeveTrimCol}
          strokeWidth="2.8"
          strokeLinecap="round"
        />

        {/* Main Torso Body */}
        <path
          d="M 28 22 
             C 36 27 64 27 72 22 
             L 77 34 
             L 73 88 
             C 73 91 70 93 66 93 
             L 34 93 
             C 30 93 27 91 27 88 
             L 23 34 
             Z"
          fill={`url(#${gradId})`}
          stroke="rgba(0,0,0,0.25)"
          strokeWidth="1.2"
        />

        {/* Highlight Overlay */}
        <path
          d="M 28 22 
             C 36 27 64 27 72 22 
             L 77 34 
             L 73 88 
             C 73 91 70 93 66 93 
             L 34 93 
             C 30 93 27 91 27 88 
             L 23 34 
             Z"
          fill={`url(#hl-${gradId})`}
        />

        {/* Collar Design */}
        <path
          d="M 38 22 C 42 30 58 30 62 22 C 56 26 44 26 38 22 Z"
          fill={collarCol}
          stroke="rgba(0,0,0,0.2)"
          strokeWidth="0.8"
        />

        {/* Bold, Razor Sharp Jersey Number */}
        <text
          x="50"
          y="62"
          textAnchor="middle"
          dominantBaseline="central"
          fill="#ffffff"
          fontSize="33"
          fontWeight="900"
          fontFamily="system-ui, -apple-system, sans-serif"
          letterSpacing="-0.5px"
          stroke="rgba(0,0,0,0.4)"
          strokeWidth="0.8"
        >
          {number}
        </text>
      </svg>
    </div>
  );
};
