import React, { useState, useEffect } from 'react';
import { getTeamLogoUrl } from '../data/teamLogos';

interface TeamBadgeProps {
  team?: {
    id?: string;
    name?: string;
    shortName?: string;
    badgeColor?: string;
    logoUrl?: string;
  } | null;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  showName?: boolean;
}

const SIZE_MAP = {
  xs: { box: 'w-4 h-4 text-[7px]', img: 'w-4 h-4', rounded: 'rounded' },
  sm: { box: 'w-6 h-6 text-[9px]', img: 'w-6 h-6', rounded: 'rounded-md' },
  md: { box: 'w-8 h-8 text-xs', img: 'w-8 h-8', rounded: 'rounded-lg' },
  lg: { box: 'w-10 h-10 text-sm', img: 'w-10 h-10', rounded: 'rounded-xl' },
  xl: { box: 'w-12 h-12 text-base', img: 'w-12 h-12', rounded: 'rounded-2xl' },
  '2xl': { box: 'w-16 h-16 text-lg', img: 'w-16 h-16', rounded: 'rounded-2xl' },
};

const DISTINCT_CLUB_GRADIENTS = [
  'from-red-600 via-red-700 to-amber-600',
  'from-blue-700 via-indigo-800 to-sky-600',
  'from-emerald-600 via-teal-700 to-emerald-900',
  'from-amber-500 via-orange-600 to-red-800',
  'from-purple-700 via-indigo-900 to-violet-800',
  'from-cyan-600 via-blue-700 to-slate-900',
  'from-rose-600 via-pink-700 to-purple-900',
  'from-lime-600 via-emerald-700 to-teal-900',
  'from-indigo-600 via-blue-800 to-slate-950',
  'from-zinc-800 via-slate-900 to-zinc-950',
  'from-sky-500 via-blue-600 to-indigo-900',
  'from-yellow-500 via-amber-600 to-amber-900',
  'from-teal-500 via-emerald-800 to-slate-900',
  'from-fuchsia-600 via-purple-700 to-indigo-950',
  'from-red-800 via-rose-900 to-neutral-900',
  'from-violet-600 via-purple-800 to-stone-900',
  'from-orange-500 via-amber-700 to-yellow-800',
  'from-blue-900 via-indigo-950 to-cyan-900',
  'from-stone-700 via-zinc-800 to-stone-950',
  'from-emerald-700 via-green-900 to-teal-950',
  'from-red-600 via-stone-800 to-black',
  'from-amber-600 via-yellow-700 to-zinc-900',
  'from-blue-600 via-sky-800 to-slate-950',
  'from-violet-700 via-fuchsia-900 to-slate-950'
];

const getUniqueTeamGradient = (nameOrId?: string, explicitColor?: string): string => {
  if (explicitColor && explicitColor.includes('from-') && !explicitColor.includes('from-purple-900 to-indigo-900')) {
    return explicitColor;
  }
  const str = nameOrId || 'team';
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  const index = Math.abs(hash) % DISTINCT_CLUB_GRADIENTS.length;
  return DISTINCT_CLUB_GRADIENTS[index];
};

export const TeamBadge: React.FC<TeamBadgeProps> = ({
  team,
  size = 'md',
  className = '',
  showName = false,
}) => {
  const [failedSrc, setFailedSrc] = useState<string | null>(null);
  const [, setRevision] = useState(0);

  useEffect(() => {
    const handleLogosUpdate = () => {
      setFailedSrc(null);
      setRevision((prev) => prev + 1);
    };

    window.addEventListener('fm-team-logos-updated', handleLogosUpdate);
    return () => window.removeEventListener('fm-team-logos-updated', handleLogosUpdate);
  }, []);

  if (!team) {
    return (
      <div className={`w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-slate-500 font-black text-xs ${className}`}>
        ?
      </div>
    );
  }

  const dimensions = SIZE_MAP[size] || SIZE_MAP.md;
  const badgeGradient = getUniqueTeamGradient(team.id || team.name, team.badgeColor);
  const shortText = (team.shortName || team.name?.slice(0, 3) || 'KUL').toUpperCase();

  const customOrOfficial = (team.id ? getTeamLogoUrl(team.id) : undefined) || 
                           (team.name ? getTeamLogoUrl(team.name) : undefined) || 
                           (team.shortName ? getTeamLogoUrl(team.shortName) : undefined);
  const logoSrc = customOrOfficial || (team.logoUrl ? (getTeamLogoUrl(team.logoUrl) || team.logoUrl) : undefined);

  const hasImgError = Boolean(logoSrc && failedSrc === logoSrc);

  const renderBadgeIcon = () => {
    if (logoSrc && !hasImgError) {
      return (
        <div className={`${dimensions.box} relative flex items-center justify-center shrink-0`}>
          <img
            src={logoSrc}
            alt={team.name || 'Takım Logosu'}
            referrerPolicy="no-referrer"
            onError={() => setFailedSrc(logoSrc)}
            className={`${dimensions.img} object-contain filter drop-shadow-[0_2px_6px_rgba(0,0,0,0.55)] transition-transform duration-200 group-hover:scale-110 shrink-0`}
          />
        </div>
      );
    }

    return (
      <div
        className={`${dimensions.box} ${dimensions.rounded} bg-gradient-to-br ${badgeGradient} flex items-center justify-center font-black text-white shadow-md border border-white/20 shrink-0 select-none tracking-tight`}
      >
        <span className="drop-shadow-sm font-extrabold">{shortText}</span>
      </div>
    );
  };

  if (showName) {
    return (
      <div className={`flex items-center gap-2 group ${className}`}>
        {renderBadgeIcon()}
        <span className="font-extrabold text-white text-xs truncate">{team.name || team.shortName}</span>
      </div>
    );
  }

  return <div className={`inline-flex items-center justify-center shrink-0 ${className}`}>{renderBadgeIcon()}</div>;
};
