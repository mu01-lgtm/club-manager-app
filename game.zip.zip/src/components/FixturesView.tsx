import React, { useState } from 'react';
import { Fixture, Team } from '../types';
import { useTranslation } from '../utils/i18n';
import { DAYS_BY_LANG, MONTHS_BY_LANG } from '../utils/dateHelper';
import { CalendarDays, Bell, BellRing, ChevronLeft, ChevronRight, ListFilter, Calendar } from 'lucide-react';
import { TeamBadge } from './TeamBadge';

interface FixturesViewProps {
  fixtures: Fixture[];
  allTeams: Team[];
  currentWeek: number;
  currentTeamId?: string;
}

export const FixturesView: React.FC<FixturesViewProps> = ({
  fixtures,
  allTeams,
  currentWeek,
  currentTeamId = 'galatasaray'
}) => {
  const { t, language } = useTranslation();
  const [viewFilter, setViewFilter] = useState<'MY_TEAM' | 'ALL_LEAGUE'>('MY_TEAM');
  const [allLeagueMode, setAllLeagueMode] = useState<'WEEKLY' | 'FULL_SEASON'>('WEEKLY');
  const [selectedWeek, setSelectedWeek] = useState<number>(currentWeek);
  const [reminders, setReminders] = useState<Set<string>>(new Set());
  const [notificationToast, setNotificationToast] = useState<string | null>(null);

  const toggleReminder = (fixtureId: string, matchName: string) => {
    setReminders(prev => {
      const next = new Set(prev);
      if (next.has(fixtureId)) {
        next.delete(fixtureId);
        setNotificationToast(`"${matchName}"`);
      } else {
        next.add(fixtureId);
        setNotificationToast(`🔔 "${matchName}"`);
      }
      return next;
    });

    setTimeout(() => {
      setNotificationToast(null);
    }, 3500);
  };

  const getTeam = (id: string) => allTeams.find(t => t.id === id);

  const getTeamName = (id: string) => {
    const tm = getTeam(id);
    return tm ? tm.name : id;
  };

  const getTeamBadge = (id: string) => {
    const tm = getTeam(id);
    return tm ? tm.shortName : id.slice(0, 3).toUpperCase();
  };

  // Helper for realistic match dates and times localized by selected language
  const getMatchDateStr = (week: number, matchIdx: number = 0, f?: Fixture | null) => {
    const monthsList = MONTHS_BY_LANG[language] || MONTHS_BY_LANG.TR;
    const daysList = DAYS_BY_LANG[language] || DAYS_BY_LANG.TR;
    
    if (f && f.matchDate && f.matchTime) {
      // Localize month name in matchDate if present
      let locDate = f.matchDate;
      MONTHS_BY_LANG.TR.forEach((trMonth, mIdx) => {
        if (locDate.includes(trMonth)) {
          locDate = locDate.replace(trMonth, monthsList[mIdx] || trMonth);
        }
      });
      // Localize day name
      let locDay = f.dayName || '';
      DAYS_BY_LANG.TR.forEach((trDay, dIdx) => {
        if (locDay === trDay) {
          locDay = daysList[dIdx] || trDay;
        }
      });
      return `${locDate} ${locDay} - ${f.matchTime}`;
    }

    // Fallback: Start season on 15 Aug 2025 (Friday)
    const d = new Date(2025, 7, 15);
    d.setDate(d.getDate() + (week - 1) * 7 + (matchIdx % 4));

    const jsDay = d.getDay();
    const customDayIdx = jsDay === 0 ? 6 : jsDay - 1;
    const dayName = daysList[customDayIdx];
    const monthName = monthsList[d.getMonth()];
    const dayNum = d.getDate();
    const times = ['19:00', '20:00', '20:30', '21:00', '21:45', '22:00'];
    const timeStr = times[matchIdx % times.length];

    return `${dayNum} ${monthName} ${d.getFullYear()} ${dayName} - ${timeStr}`;
  };

  // Dynamic max week calculation based on generated schedule
  const maxWeek = fixtures.length > 0 ? Math.max(...fixtures.map(f => f.week)) : 38;

  // Build complete schedule for user team including BYE weeks
  const myTeamSchedule = Array.from({ length: maxWeek }, (_, i) => {
    const w = i + 1;
    const fix = fixtures.find(f => f.week === w && (f.homeTeamId === currentTeamId || f.awayTeamId === currentTeamId));
    return { week: w, fixture: fix || null };
  });

  // Week fixtures for ALL_LEAGUE view
  const weekFixtures = fixtures.filter(f => f.week === selectedWeek);

  const myTeam = getTeam(currentTeamId);

  return (
    <div className="bg-[#18142a] border border-[#2d244c] rounded-xl shadow-xl p-2 sm:p-3 space-y-2 relative w-full">
      
      {/* Toast Banner for Notification Alerts */}
      {notificationToast && (
        <div className="bg-[#7b2cbf] text-white px-2.5 py-1.5 rounded-lg text-xs font-bold border border-purple-400/50 shadow-xl flex items-center gap-1.5 animate-bounce">
          <Bell className="w-3.5 h-3.5 text-amber-300 shrink-0" />
          <span>{notificationToast}</span>
        </div>
      )}

      {/* Banner & Filter Bar */}
      <div className="bg-[#130f24] p-2 rounded-xl border border-[#2d244c] flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-purple-500/20 border border-purple-500/30 text-purple-300">
            <CalendarDays className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-extrabold text-white text-xs sm:text-sm">{t('FIXTURES_AND_SCHEDULE')}</h3>
            <p className="text-[10px] text-slate-400 font-semibold">
              {myTeam ? t('TOTAL_WEEKS_FIXTURE', { weeks: maxWeek, team: myTeam.name }) : t('SEASON_MATCHES')}
            </p>
          </div>
        </div>

        {/* Filter Buttons */}
        <div className="flex items-center gap-1 bg-[#1f1938] p-0.5 rounded-lg border border-[#382d5e]">
          <button
            onClick={() => setViewFilter('MY_TEAM')}
            className={`px-3 py-1 rounded-md text-[11px] font-black transition-all ${
              viewFilter === 'MY_TEAM'
                ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/50'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            ⭐ {t('MY_TEAM_FILTER')}
          </button>
          <button
            onClick={() => setViewFilter('ALL_LEAGUE')}
            className={`px-3 py-1 rounded-md text-[11px] font-black transition-all ${
              viewFilter === 'ALL_LEAGUE'
                ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/50'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            🏆 {t('ALL_LEAGUE_FILTER')}
          </button>
        </div>
      </div>

      {/* FILTER 1: MY TEAM ALL FIXTURES (FULL SEASON VERTICAL SCROLL) */}
      {viewFilter === 'MY_TEAM' && (
        <div className="space-y-1.5 max-h-[75vh] sm:max-h-[82vh] overflow-y-auto pr-1 custom-fmm-scrollbar">
          {myTeamSchedule.map(({ week, fixture: f }, idx) => {
            const isCurrentWeekMatch = week === currentWeek;
            const dateStr = getMatchDateStr(week, idx, f);

            if (!f) {
              return (
                <div
                  key={`bye-${week}`}
                  className={`p-1.5 sm:p-2 rounded-xl border flex items-center justify-between gap-1.5 transition-all shadow-sm ${
                    isCurrentWeekMatch
                      ? 'bg-[#241c3e] border-amber-500/60 ring-1 ring-amber-500/30'
                      : 'bg-[#130f24]/60 border-[#282142]'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`text-[11px] font-black ${isCurrentWeekMatch ? 'text-amber-400' : 'text-purple-300'}`}>
                      {t('WEEK_LABEL', { week })}
                    </span>
                    <span className="text-[9px] text-amber-300 font-bold bg-amber-500/10 px-1 py-0.2 rounded border border-amber-500/20">
                      🗓️ {dateStr}
                    </span>
                  </div>
                  <div className="text-center flex-1">
                    <span className="px-2 py-0.5 rounded-lg bg-purple-900/40 border border-purple-500/40 text-purple-200 font-extrabold text-[10px] sm:text-xs">
                      💤 {t('BYE_WEEK')}
                    </span>
                  </div>
                  <span className="text-[9px] text-slate-500 font-bold">---</span>
                </div>
              );
            }

            const isHome = f.homeTeamId === currentTeamId;

            // Result indicator
            let resultTag = null;
            if (f.played && f.homeScore !== undefined && f.awayScore !== undefined) {
              const myScore = isHome ? f.homeScore : f.awayScore;
              const oppScore = isHome ? f.awayScore : f.homeScore;

              if (myScore > oppScore) {
                resultTag = <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 font-black text-[9px]">G</span>;
              } else if (myScore < oppScore) {
                resultTag = <span className="px-1.5 py-0.5 rounded bg-rose-500/20 border border-rose-500/40 text-rose-400 font-black text-[9px]">M</span>;
              } else {
                resultTag = <span className="px-1.5 py-0.5 rounded bg-amber-500/20 border border-amber-500/40 text-amber-400 font-black text-[9px]">B</span>;
              }
            }

            return (
              <div
                key={f.id}
                className={`p-1.5 sm:p-2 rounded-xl border flex flex-col sm:flex-row items-center justify-between gap-1.5 transition-all shadow-sm ${
                  isCurrentWeekMatch
                    ? 'bg-[#241c3e] border-amber-500/60 ring-1 ring-amber-500/30'
                    : f.played
                    ? 'bg-[#130f24]/90 border-[#282142]'
                    : 'bg-[#18142a] border-[#2d244c]'
                }`}
              >
                {/* Week & Date Label */}
                <div className="w-full sm:w-32 shrink-0 flex items-center sm:flex-col justify-between sm:justify-center border-b sm:border-b-0 border-[#282042] pb-0.5 sm:pb-0">
                  <div className="flex items-center gap-1 sm:flex-col sm:gap-0">
                    <span className={`text-[11px] font-black ${isCurrentWeekMatch ? 'text-amber-400' : 'text-purple-300'}`}>
                      {t('WEEK_LABEL', { week: f.week })}
                    </span>
                    <span className="text-[9px] text-amber-300 font-bold flex items-center gap-0.5 bg-amber-500/10 px-1 py-0.2 rounded border border-amber-500/20">
                      🗓️ {dateStr}
                    </span>
                  </div>
                </div>

                {/* Match Box (Home vs Away) */}
                <div className="flex-1 flex items-center justify-center gap-1.5 sm:gap-2 w-full">
                  
                  {/* Home Team */}
                  <div className="flex items-center gap-1.5 justify-end flex-1 text-right min-w-0">
                    <span className={`font-black text-[11px] truncate ${f.homeTeamId === currentTeamId ? 'text-emerald-400' : 'text-white'}`}>
                      {getTeamName(f.homeTeamId)}
                    </span>
                    <TeamBadge team={getTeam(f.homeTeamId)} size="xs" />
                  </div>

                  {/* Score or VS */}
                  <div className="shrink-0 text-center">
                    {f.played ? (
                      <div className="px-2 py-0.5 bg-[#261f42] border border-[#43356e] rounded-md text-white font-black text-[11px] shadow-inner">
                        {f.homeScore} - {f.awayScore}
                      </div>
                    ) : (
                      <div className="px-1.5 py-0.2 bg-[#130f24] border border-[#2d244c] rounded-md text-slate-400 font-bold text-[9px]">
                        VS
                      </div>
                    )}
                  </div>

                  {/* Away Team */}
                  <div className="flex items-center gap-1.5 justify-start flex-1 text-left min-w-0">
                    <TeamBadge team={getTeam(f.awayTeamId)} size="xs" />
                    <span className={`font-black text-[11px] truncate ${f.awayTeamId === currentTeamId ? 'text-emerald-400' : 'text-white'}`}>
                      {getTeamName(f.awayTeamId)}
                    </span>
                  </div>

                </div>

                {/* Status Badge in MY_TEAM view */}
                <div className="shrink-0 flex items-center justify-end">
                  {f.played ? (
                    resultTag
                  ) : (
                    <span className="px-1.5 py-0.5 rounded bg-purple-500/20 border border-purple-500/40 text-purple-300 font-bold text-[9px]">
                      ⭐ {t('MY_MATCH_TAG')}
                    </span>
                  )}
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* FILTER 2: ALL LEAGUE */}
      {viewFilter === 'ALL_LEAGUE' && (
        <div className="space-y-2">
          
          {/* Controls Bar for All League */}
          <div className="flex flex-wrap items-center justify-between bg-[#130f24] p-1.5 sm:p-2 rounded-xl border border-[#2d244c] gap-2">
            
            {/* Display Mode Sub-Tabs */}
            <div className="flex items-center gap-1 bg-[#1f1938] p-0.5 rounded-lg border border-[#382d5e]">
              <button
                onClick={() => setAllLeagueMode('WEEKLY')}
                className={`px-2.5 py-1 rounded-md text-[10px] font-black transition-all flex items-center gap-1 ${
                  allLeagueMode === 'WEEKLY'
                    ? 'bg-[#7b2cbf] text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Calendar className="w-3 h-3" />
                <span>{t('WEEKLY_VIEW')}</span>
              </button>
              <button
                onClick={() => setAllLeagueMode('FULL_SEASON')}
                className={`px-2.5 py-1 rounded-md text-[10px] font-black transition-all flex items-center gap-1 ${
                  allLeagueMode === 'FULL_SEASON'
                    ? 'bg-[#7b2cbf] text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <ListFilter className="w-3 h-3" />
                <span>{t('FULL_SEASON_VIEW')}</span>
              </button>
            </div>

            {/* Week Selector Dropdown & Nav Buttons (in Weekly mode) */}
            {allLeagueMode === 'WEEKLY' && (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setSelectedWeek(prev => Math.max(1, prev - 1))}
                  className="p-1.5 rounded-lg bg-[#221a3b] hover:bg-[#2e234e] text-slate-300 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                >
                  <ChevronLeft className="w-3.5 h-3.5" /> {t('PREVIOUS')}
                </button>

                {/* Week Dropdown */}
                <select
                  value={selectedWeek}
                  onChange={(e) => setSelectedWeek(Number(e.target.value))}
                  className="bg-[#1f1938] border border-[#382d5e] text-amber-300 text-xs font-black rounded-lg px-2 py-1 outline-none cursor-pointer"
                >
                  {Array.from({ length: maxWeek }, (_, i) => i + 1).map(w => (
                    <option key={w} value={w} className="bg-[#18142a] text-white font-bold">
                      {t('WEEK_LABEL', { week: w })} {w === currentWeek ? t('CURRENT_WEEK_TAG') : ''}
                    </option>
                  ))}
                </select>

                <button
                  onClick={() => setSelectedWeek(prev => Math.min(maxWeek, prev + 1))}
                  disabled={selectedWeek >= maxWeek}
                  className="p-1.5 rounded-lg bg-[#221a3b] hover:bg-[#2e234e] disabled:opacity-40 text-slate-300 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                >
                  {t('NEXT')} <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Quick jump to current week in full season mode */}
            {allLeagueMode === 'FULL_SEASON' && (
              <div className="text-[10px] text-amber-300 font-extrabold bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/30">
                {t('ALL_SEASON_MATCHES_RANGE', { maxWeek })}
              </div>
            )}
          </div>

          {/* MODE A: WEEKLY VIEW */}
          {allLeagueMode === 'WEEKLY' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5 max-h-[75vh] sm:max-h-[82vh] overflow-y-auto pr-1 custom-fmm-scrollbar">
              {weekFixtures.map((f, idx) => {
                const hasReminder = reminders.has(f.id);
                const matchName = `${getTeamName(f.homeTeamId)} vs ${getTeamName(f.awayTeamId)}`;
                const matchDateStr = getMatchDateStr(selectedWeek, idx, f);

                return (
                  <div
                    key={f.id}
                    className="bg-[#130f24] border border-[#2d244c] rounded-xl p-1.5 flex flex-col sm:flex-row items-center justify-between gap-1.5 shadow hover:border-purple-500/40 transition-all"
                  >
                    {/* Match Day & Date Tag */}
                    <div className="w-full sm:w-32 text-[9px] font-black text-amber-300 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/30 text-center sm:text-left shrink-0">
                      🗓️ {matchDateStr}
                    </div>

                    {/* Match Teams */}
                    <div className="flex-1 flex items-center justify-center gap-1.5 w-full">
                      {/* Home Team */}
                      <div className="flex items-center gap-1.5 w-5/12 justify-end text-right min-w-0">
                        <span className="font-extrabold text-white text-[11px] truncate">{getTeamName(f.homeTeamId)}</span>
                        <TeamBadge team={getTeam(f.homeTeamId)} size="xs" />
                      </div>

                      {/* Score / VS */}
                      <div className="w-2/12 flex flex-col items-center justify-center shrink-0 px-1">
                        {f.played ? (
                          <div className="px-1.5 py-0.5 bg-emerald-500/20 border border-emerald-500/30 rounded-md text-emerald-300 font-black text-[11px]">
                            {f.homeScore} - {f.awayScore}
                          </div>
                        ) : (
                          <div className="px-1.5 py-0.2 bg-[#18142a] border border-[#2d244c] rounded-md text-slate-500 font-bold text-[9px]">
                            VS
                          </div>
                        )}
                      </div>

                      {/* Away Team */}
                      <div className="flex items-center gap-1.5 w-5/12 justify-start text-left min-w-0">
                        <TeamBadge team={getTeam(f.awayTeamId)} size="xs" />
                        <span className="font-extrabold text-white text-[11px] truncate">{getTeamName(f.awayTeamId)}</span>
                      </div>
                    </div>

                    {/* Reminder Toggle Button */}
                    <div className="shrink-0 flex items-center gap-1.5 w-full sm:w-auto justify-end pt-1 sm:pt-0 border-t sm:border-t-0 border-[#231b3d]">
                      <button
                        onClick={() => toggleReminder(f.id, matchName)}
                        className={`p-1.5 rounded-lg border text-[10px] font-black transition-all flex items-center gap-1 ${
                          hasReminder
                            ? 'bg-amber-500/20 border-amber-500/60 text-amber-300'
                            : 'bg-[#1f1938] border-[#382d5e] text-slate-400 hover:text-white hover:bg-[#2c234f]'
                        }`}
                        title="Bu Maça Hatırlatıcı Kur"
                      >
                        {hasReminder ? (
                          <>
                            <BellRing className="w-3.5 h-3.5 text-amber-300" />
                            <span>{t('REMINDER_ACTIVE')}</span>
                          </>
                        ) : (
                          <>
                            <Bell className="w-3.5 h-3.5" />
                            <span>{t('SET_REMINDER')}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* MODE B: FULL SEASON VIEW (ALL MATCHES SCROLLABLE) */}
          {allLeagueMode === 'FULL_SEASON' && (
            <div className="space-y-4 max-h-[75vh] sm:max-h-[82vh] overflow-y-auto pr-1 custom-fmm-scrollbar">
              {Array.from({ length: maxWeek }, (_, i) => i + 1).map(w => {
                const weekMatches = fixtures.filter(f => f.week === w);
                if (weekMatches.length === 0) return null;

                const isCurrent = w === currentWeek;

                return (
                  <div key={`season-week-${w}`} className="space-y-1.5 bg-[#130f24]/80 p-2 rounded-xl border border-[#2b2247]">
                    <div className="flex items-center justify-between border-b border-[#2d244c] pb-1">
                      <span className={`text-xs font-black uppercase ${isCurrent ? 'text-amber-400' : 'text-purple-300'}`}>
                        🏆 {t('WEEK_LABEL', { week: w }).toUpperCase()} {isCurrent ? t('CURRENT_WEEK_TAG') : ''}
                      </span>
                      <span className="text-[10px] text-slate-400 font-bold">
                        {t('MATCH_COUNT', { count: weekMatches.length })}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5">
                      {weekMatches.map((f, idx) => {
                        const matchDateStr = getMatchDateStr(w, idx, f);
                        const isUserMatch = f.homeTeamId === currentTeamId || f.awayTeamId === currentTeamId;

                        return (
                          <div
                            key={f.id}
                            className={`p-1.5 rounded-xl border flex items-center justify-between gap-1.5 text-xs ${
                              isUserMatch
                                ? 'bg-[#241c3e] border-amber-500/50 ring-1 ring-amber-500/20'
                                : 'bg-[#18142a] border-[#292044]'
                            }`}
                          >
                            <div className="text-[9px] font-black text-amber-300/90 shrink-0 w-20">
                              {matchDateStr.split('-')[0]}
                            </div>

                            <div className="flex-1 flex items-center justify-between gap-1 min-w-0">
                              {/* Home */}
                              <div className="flex items-center gap-1 flex-1 justify-end truncate">
                                <span className={`font-bold text-[10px] truncate ${f.homeTeamId === currentTeamId ? 'text-emerald-400 font-black' : 'text-slate-200'}`}>
                                  {getTeamName(f.homeTeamId)}
                                </span>
                              </div>

                              {/* Score */}
                              <div className="shrink-0 font-black text-[10px] px-1.5 py-0.5 bg-[#110d21] rounded border border-[#312752] text-white">
                                {f.played ? `${f.homeScore} - ${f.awayScore}` : 'VS'}
                              </div>

                              {/* Away */}
                              <div className="flex items-center gap-1 flex-1 justify-start truncate">
                                <span className={`font-bold text-[10px] truncate ${f.awayTeamId === currentTeamId ? 'text-emerald-400 font-black' : 'text-slate-200'}`}>
                                  {getTeamName(f.awayTeamId)}
                                </span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

        </div>
      )}

    </div>
  );
};
