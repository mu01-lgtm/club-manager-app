import React, { useState, useRef, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { ChevronDown, Check } from 'lucide-react';
import { Player } from '../types';

export interface CustomSelectOption {
  value: string;
  label: string;
  player?: Player;
  badge?: string;
  badgeType?: 'GK' | 'DEF' | 'MID' | 'FW' | string;
  subLabel?: string;
  ovr?: number;
}

interface CustomSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: CustomSelectOption[];
  placeholder?: string;
  buttonClassName?: string;
  dropdownClassName?: string;
  dropdownAlign?: 'left' | 'right';
}

export const CustomSelect: React.FC<CustomSelectProps> = ({
  value,
  onChange,
  options,
  placeholder = 'Seçiniz...',
  buttonClassName = '',
  dropdownClassName = '',
  dropdownAlign = 'left'
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [dropdownPosition, setDropdownPosition] = useState<{
    top: number;
    left: number;
    width: number;
    openUpward: boolean;
  }>({
    top: 0,
    left: 0,
    width: 0,
    openUpward: false
  });
  const containerRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const selectedOption = options.find(o => o.value === value);

  // Calculate coordinates and direction whenever dropdown opens or window resizes
  useEffect(() => {
    if (isOpen && containerRef.current) {
      const updatePosition = () => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const spaceBelow = window.innerHeight - rect.bottom;
        const shouldOpenUp = spaceBelow < 260 && rect.top > 260;

        const targetWidth = Math.max(rect.width, 220);
        let leftPos = dropdownAlign === 'right' ? rect.right - targetWidth : rect.left;

        // Prevent leaking past viewport edges
        if (leftPos + targetWidth > window.innerWidth - 12) {
          leftPos = Math.max(12, window.innerWidth - targetWidth - 12);
        }
        if (leftPos < 12) {
          leftPos = 12;
        }

        setDropdownPosition({
          top: shouldOpenUp ? rect.top - 4 : rect.bottom + 4,
          left: leftPos,
          width: targetWidth,
          openUpward: shouldOpenUp
        });
      };

      updatePosition();
      window.addEventListener('resize', updatePosition);
      window.addEventListener('scroll', updatePosition, true);
      return () => {
        window.removeEventListener('resize', updatePosition);
        window.removeEventListener('scroll', updatePosition, true);
      };
    }
  }, [isOpen, dropdownAlign]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Node;
      if (
        containerRef.current &&
        !containerRef.current.contains(target) &&
        dropdownRef.current &&
        !dropdownRef.current.contains(target)
      ) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isOpen]);

  const getPositionBadgeStyle = (posType?: string) => {
    const type = posType?.toUpperCase() || 'MID';
    if (type === 'GK' || type === 'KL') {
      return 'bg-amber-500/25 border-amber-400/60 text-amber-300';
    }
    if (['DEF', 'CB', 'LB', 'RB', 'LWB', 'RWB', 'DF'].includes(type)) {
      return 'bg-sky-500/25 border-sky-400/60 text-sky-300';
    }
    if (['FW', 'ST', 'CF', 'RW', 'LW', 'FV'].includes(type)) {
      return 'bg-rose-500/25 border-rose-400/60 text-rose-300';
    }
    return 'bg-emerald-500/25 border-emerald-400/60 text-emerald-300';
  };

  const dropdownElement = isOpen ? (
    <div
      ref={dropdownRef}
      style={{
        position: 'fixed',
        left: `${dropdownPosition.left}px`,
        top: dropdownPosition.openUpward ? 'auto' : `${dropdownPosition.top}px`,
        bottom: dropdownPosition.openUpward ? `${window.innerHeight - dropdownPosition.top}px` : 'auto',
        width: `${dropdownPosition.width}px`,
        maxWidth: 'min(340px, calc(100vw - 24px))',
        backgroundColor: '#15102a',
        border: '1.5px solid rgba(52, 211, 153, 0.85)',
        boxShadow: '0 16px 45px rgba(0,0,0,0.98), 0 0 20px rgba(52, 211, 153, 0.25)',
        zIndex: 999999
      }}
      className={`rounded-xl max-h-[280px] overflow-y-auto p-1 custom-fmm-scrollbar shadow-2xl animate-in fade-in zoom-in-95 duration-150 ${dropdownClassName}`}
    >
      {options.length === 0 ? (
        <div className="p-2 text-center text-slate-400 text-xs italic">Seçenek bulunamadı.</div>
      ) : (
        options.map((opt) => {
          const isSelected = opt.value === value;
          const player = opt.player;
          const posType = opt.badgeType || player?.position || (opt.badge ? opt.badge : undefined);
          const hasBadge = !!posType && posType !== 'ODAK' && posType !== 'YÜK';
          const badgeStyle = hasBadge ? getPositionBadgeStyle(posType) : '';

          return (
            <div
              key={opt.value}
              onClick={() => {
                onChange(opt.value);
                setIsOpen(false);
              }}
              className={`p-2 mb-1 rounded-lg transition-all cursor-pointer flex items-center justify-between border select-none group gap-2 ${
                isSelected
                  ? 'bg-emerald-950/90 border-emerald-400/90 text-white shadow-sm'
                  : 'bg-[#191333] border-[#2f2552] hover:bg-emerald-950/50 hover:border-emerald-400/50 text-slate-200'
              }`}
            >
              {/* Left & Center Info */}
              <div className="flex items-center gap-2 min-w-0 flex-1">
                {/* Position Badge if present */}
                {hasBadge && (
                  <span className={`w-7 h-5 rounded flex items-center justify-center font-black text-[8.5px] border shrink-0 ${badgeStyle}`}>
                    {opt.badge || player?.position || posType}
                  </span>
                )}

                <div className="min-w-0 flex-1 leading-snug">
                  <div className="flex items-center gap-1">
                    <span className="font-extrabold text-white text-[11.5px] group-hover:text-emerald-300 leading-tight">
                      {opt.label}
                    </span>
                  </div>
                  {opt.subLabel && (
                    <p className="text-[9px] text-slate-300 font-medium mt-0.5 leading-tight">
                      {opt.subLabel}
                    </p>
                  )}
                </div>
              </div>

              {/* Right Side OVR / Rating Badge */}
              <div className="flex items-center gap-1 shrink-0 ml-1">
                {(opt.ovr !== undefined || player?.overall) && (
                  <span className="px-1.5 py-0.5 rounded bg-purple-900/80 border border-purple-500 text-amber-300 font-black text-[8.5px] tracking-wide shadow-sm">
                    {opt.ovr ?? player?.overall} OVR
                  </span>
                )}
                {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
              </div>
            </div>
          );
        })
      )}
    </div>
  ) : null;

  return (
    <div ref={containerRef} className="relative inline-block w-full select-none">
      {/* Selected Value Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(prev => !prev)}
        className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer border whitespace-nowrap overflow-hidden ${
          isOpen
            ? 'bg-[#1e173a] border-emerald-400/90 ring-2 ring-emerald-400/40 text-white'
            : 'bg-[#140f28] border-[#312756] hover:border-emerald-400/60 text-white'
        } ${buttonClassName}`}
      >
        <div className="flex items-center gap-1.5 min-w-0 flex-1 truncate pr-1">
          {selectedOption?.badge && (
            <span className={`px-1.5 py-0.2 rounded text-[8.5px] font-black border shrink-0 ${getPositionBadgeStyle(selectedOption.badgeType || selectedOption.badge)}`}>
              {selectedOption.badge}
            </span>
          )}
          <span className="truncate text-white font-extrabold text-xs tracking-tight">
            {selectedOption ? selectedOption.label : placeholder}
          </span>
          {selectedOption?.ovr !== undefined && (
            <span className="px-1.5 py-0.2 rounded bg-amber-500/20 border border-amber-400/40 text-amber-300 font-black text-[8.5px] shrink-0">
              {selectedOption.ovr} OVR
            </span>
          )}
        </div>
        <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 shrink-0 ml-1 ${isOpen ? 'rotate-180 text-emerald-400' : ''}`} />
      </button>

      {/* Render Dropdown via Portal directly to body */}
      {typeof document !== 'undefined' && dropdownElement && ReactDOM.createPortal(dropdownElement, document.body)}
    </div>
  );
};
