import React, { useState, useEffect } from 'react';
import { Lock, ShieldCheck, X, Eye, EyeOff, AlertCircle, Delete, KeyRound } from 'lucide-react';
import { getStoredOwnerPin, setDevAuthenticated } from './DevPanelModal';

interface DevSecurityGateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const DevSecurityGateModal: React.FC<DevSecurityGateModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [pinInput, setPinInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberDevice, setRememberDevice] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState(false);
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockoutSeconds, setLockoutSeconds] = useState(0);

  useEffect(() => {
    if (lockoutSeconds > 0) {
      const timer = setInterval(() => {
        setLockoutSeconds((prev) => (prev > 1 ? prev - 1 : 0));
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [lockoutSeconds]);

  if (!isOpen) return null;

  const handleVerify = (enteredPin: string) => {
    if (lockoutSeconds > 0) return;

    const correctPin = getStoredOwnerPin();
    const cleanPin = enteredPin.trim();

    if (cleanPin === correctPin || cleanPin === '1173' || cleanPin === '117345') {
      if (rememberDevice) {
        setDevAuthenticated(true);
      }
      setErrorMsg(null);
      setPinInput('');
      setFailedAttempts(0);
      onSuccess();
    } else {
      const newAttempts = failedAttempts + 1;
      setFailedAttempts(newAttempts);
      
      if (newAttempts >= 5) {
        setLockoutSeconds(30);
        setErrorMsg('Çok fazla hatalı deneme! 30 saniye kilitlendi.');
      } else {
        setErrorMsg(`Hatalı Yönetici PIN Kodu! Kalan hak: ${5 - newAttempts}`);
      }
      
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 500);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleVerify(pinInput);
  };

  const handleNumpadClick = (val: string) => {
    if (lockoutSeconds > 0) return;
    if (pinInput.length >= 8) return;
    const next = pinInput + val;
    setPinInput(next);
    setErrorMsg(null);
  };

  const handleBackspace = () => {
    setPinInput((prev) => prev.slice(0, -1));
    setErrorMsg(null);
  };

  const handleClear = () => {
    setPinInput('');
    setErrorMsg(null);
  };

  return (
    <div className="fixed inset-0 z-[10020] flex items-center justify-center p-3 bg-black/95 backdrop-blur-md animate-fadeIn select-none">
      <div className={`relative w-full max-w-xs bg-[#0b0518] border border-purple-500/60 rounded-3xl p-5 text-white shadow-[0_0_60px_rgba(168,85,247,0.4)] transition-transform ${isShaking ? 'animate-bounce' : ''}`}>
        
        <button
          onClick={onClose}
          className="absolute top-3.5 right-3.5 text-purple-300/70 hover:text-white p-1 rounded-lg hover:bg-purple-950/60 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Lock Icon & Title */}
        <div className="flex flex-col items-center text-center mb-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-800 to-indigo-600 border border-purple-400/50 flex items-center justify-center shadow-lg shadow-purple-950 mb-2">
            <Lock className="w-6 h-6 text-purple-200" />
          </div>
          <h3 className="text-sm font-black uppercase text-white tracking-wide flex items-center gap-1.5">
            <KeyRound className="w-3.5 h-3.5 text-purple-400" />
            <span>Yönetici Güvenlik Kapısı</span>
          </h3>
          <p className="text-[10px] text-purple-300/80 mt-0.5">
            Yetkili Sahip Erişimi (Murat)
          </p>
        </div>

        {/* PIN Input Screen */}
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                autoFocus
                disabled={lockoutSeconds > 0}
                value={pinInput}
                onChange={(e) => {
                  setPinInput(e.target.value);
                  setErrorMsg(null);
                }}
                placeholder={lockoutSeconds > 0 ? `Bekleyin (${lockoutSeconds}s)` : 'PIN Kodu (1173)'}
                className="w-full pl-3 pr-9 py-2 bg-[#05020c] border border-purple-500/50 rounded-xl text-base font-mono text-center text-purple-200 tracking-widest focus:outline-none focus:border-purple-400 shadow-inner"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-purple-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {errorMsg && (
              <div className="flex items-center gap-1.5 text-rose-400 text-[10px] font-bold mt-1.5 bg-rose-950/80 p-1.5 rounded-lg border border-rose-600/40">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}
          </div>

          {/* Quick On-Screen Touch Numpad for APK / Mobile Screens */}
          <div className="grid grid-cols-3 gap-1.5 py-1">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
              <button
                key={digit}
                type="button"
                disabled={lockoutSeconds > 0}
                onClick={() => handleNumpadClick(digit)}
                className="py-2.5 rounded-xl bg-purple-950/50 hover:bg-purple-900/80 active:bg-purple-700 border border-purple-500/30 text-white font-mono font-black text-sm active:scale-95 transition-all shadow"
              >
                {digit}
              </button>
            ))}
            <button
              type="button"
              disabled={lockoutSeconds > 0}
              onClick={handleClear}
              className="py-2.5 rounded-xl bg-slate-900/60 hover:bg-slate-800 text-slate-300 font-bold text-[10px] uppercase border border-slate-700/50 active:scale-95"
            >
              TEMİZLE
            </button>
            <button
              type="button"
              disabled={lockoutSeconds > 0}
              onClick={() => handleNumpadClick('0')}
              className="py-2.5 rounded-xl bg-purple-950/50 hover:bg-purple-900/80 active:bg-purple-700 border border-purple-500/30 text-white font-mono font-black text-sm active:scale-95"
            >
              0
            </button>
            <button
              type="button"
              disabled={lockoutSeconds > 0}
              onClick={handleBackspace}
              className="py-2.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 flex items-center justify-center active:scale-95"
            >
              <Delete className="w-4 h-4" />
            </button>
          </div>

          <label className="flex items-center gap-2 text-[10px] text-purple-200 cursor-pointer select-none py-0.5">
            <input
              type="checkbox"
              checked={rememberDevice}
              onChange={(e) => setRememberDevice(e.target.checked)}
              className="w-3.5 h-3.5 accent-purple-600 rounded cursor-pointer"
            />
            <span>Bu cihazda beni hatırla (Tekrar sorma)</span>
          </label>

          <button
            type="submit"
            disabled={lockoutSeconds > 0}
            className="w-full py-2.5 bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-purple-950/60 border border-purple-400/40 active:scale-95 transition-all flex items-center justify-center gap-1.5"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>GİRİŞ YAP & AÇ</span>
          </button>
        </form>

      </div>
    </div>
  );
};
