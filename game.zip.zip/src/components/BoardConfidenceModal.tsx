import React from 'react';
import { X, ShieldCheck, TrendingUp, Award, DollarSign, Users, Target, AlertTriangle, Building2, CheckCircle2, ChevronRight, BarChart2 } from 'lucide-react';
import { Team } from '../types';
import { getTeamTargetGoal } from '../utils/teamGoalsHelper';
import { useTranslation } from '../utils/i18n';

interface BoardConfidenceModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTeam: Team;
  currentRank: number;
  totalTeams: number;
  points: number;
  boardConfidence: number;
  won?: number;
  drawn?: number;
  lost?: number;
  form?: string[];
}

export const BoardConfidenceModal: React.FC<BoardConfidenceModalProps> = ({
  isOpen,
  onClose,
  currentTeam,
  currentRank,
  totalTeams,
  points,
  boardConfidence,
  won = 0,
  drawn = 0,
  lost = 0,
  form = []
}) => {
  const { t, language } = useTranslation();

  if (!isOpen) return null;

  const targetGoal = getTeamTargetGoal(currentTeam);
  const isEliteClub = targetGoal.targetPosition === 1;

  // Compute dynamic sub-scores for the 4 pillars
  const rankRatio = (totalTeams - currentRank + 1) / totalTeams;
  const matchPerfScore = Math.min(99, Math.max(25, Math.round(boardConfidence * 0.95 + (rankRatio * 15))));
  
  const budgetRatio = currentTeam.budget / 25_000_000;
  const financialScore = Math.min(98, Math.max(50, Math.round(75 + Math.min(20, budgetRatio * 5))));
  
  const avgMorale = Math.round(
    currentTeam.players.reduce((acc, p) => acc + (p.morale ?? 85), 0) / (currentTeam.players.length || 1)
  );
  const moraleScore = Math.min(99, Math.max(45, avgMorale));

  const squadAvgOvr = Math.round(
    currentTeam.players.reduce((acc, p) => acc + p.overall, 0) / (currentTeam.players.length || 1)
  );
  const tacticalScore = Math.min(98, Math.max(50, Math.round(squadAvgOvr * 1.1)));

  // Board Status Text & Color
  let confidenceStatus = t('BOARD_STATUS_SAFE');
  let badgeBg = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
  let jobStatusText = t('BOARD_JOB_SECURE');
  let presidentQuote = isEliteClub
    ? (language === 'TR'
      ? `${currentTeam.name} gibi büyük bir camiada tek hedef her maçı kazanıp zirvede olmaktır. Puan kaybına tahammülümüz yok.`
      : `At a great club like ${currentTeam.name}, the only goal is winning every game and staying on top. We cannot tolerate dropped points.`)
    : t('BOARD_QUOTE_STANDARD').replace('{team}', currentTeam.name);

  if (boardConfidence >= 90) {
    confidenceStatus = t('BOARD_STATUS_EXCELLENT');
    badgeBg = 'bg-emerald-500/30 text-emerald-200 border-emerald-400 ring-1 ring-emerald-400/50';
    jobStatusText = t('BOARD_JOB_HISTORIC');
    presidentQuote = isEliteClub
      ? (language === 'TR'
        ? `Tebrikler! Takım şampiyonluk yolunda harika gidiyor, yönetim olarak tam destek arkandayız.`
        : `Congratulations! The team is on a championship course, the board fully stands behind you.`)
      : t('BOARD_QUOTE_HISTORIC');
  } else if (boardConfidence >= 75) {
    confidenceStatus = t('BOARD_STATUS_STABLE');
    badgeBg = 'bg-sky-500/20 text-sky-300 border-sky-500/40';
    jobStatusText = t('BOARD_JOB_SECURE');
    presidentQuote = isEliteClub
      ? (language === 'TR'
        ? `İyi gidiyoruz fakat büyük hedefler için istikrarı korumalı ve puan kayıplarını minimuma indirmeliyiz.`
        : `Good run, but for title ambitions we must maintain consistency and minimize dropped points.`)
      : t('BOARD_QUOTE_STABLE');
  } else if (boardConfidence >= 60) {
    confidenceStatus = t('BOARD_STATUS_NEUTRAL');
    badgeBg = 'bg-amber-500/20 text-amber-300 border-amber-500/40';
    jobStatusText = t('BOARD_JOB_WATCHED');
    presidentQuote = isEliteClub
      ? (language === 'TR'
        ? `Yönetim Kurulu olarak son puan kayıplarından ve sıralamadaki durumdan son derece rahatsızız. Acil galibiyet serisi bekliyoruz!`
        : `The Board is deeply unsettled by recent dropped points. We urgently expect a winning streak!`)
      : t('BOARD_QUOTE_WATCHED');
  } else {
    confidenceStatus = t('BOARD_STATUS_CRITICAL');
    badgeBg = 'bg-rose-500/20 text-rose-300 border-rose-500/40';
    jobStatusText = t('BOARD_JOB_URGENT');
    presidentQuote = isEliteClub
      ? (language === 'TR'
        ? `KRİTİK UYARI: ${currentTeam.name} standartlarının çok altındayız. Yönetim güveni tükenmek üzere, gelecek maçta mutlak galibiyet şart!`
        : `CRITICAL WARNING: We are far below ${currentTeam.name} standards. Board patience has run out, a win in the next match is mandatory!`)
      : t('BOARD_QUOTE_CRITICAL');
  }

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-3 animate-fade-in">
      <div className="bg-gradient-to-b from-[#1a1533] via-[#141029] to-[#0c0a1a] border border-[#3b2b66] rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="p-4 border-b border-[#2d2252] flex items-center justify-between bg-[#1f193f]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/20 border border-amber-400/40 text-amber-300 rounded-xl shadow-inner">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                <span>{t('BOARD_CONFIDENCE_REPORT')}</span>
                <span className="text-[10px] bg-purple-950 text-purple-300 px-2 py-0.5 rounded-full border border-purple-600/50">
                  {currentTeam.name}
                </span>
              </h2>
              <p className="text-[11px] text-slate-300">{t('BOARD_CONFIDENCE_DESC')}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto custom-scrollbar space-y-4">
          
          {/* Main Executive Confidence Gauge Box */}
          <div className="bg-gradient-to-r from-[#1e173e] via-[#2a1d56] to-[#1e173e] border border-[#3d2e6e] rounded-2xl p-4 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
              <ShieldCheck className="w-32 h-32 text-amber-400" />
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 relative z-10">
              {/* Score Metric */}
              <div className="flex items-center gap-4">
                <div className="relative flex items-center justify-center w-20 h-20 rounded-2xl bg-[#120d28] border-2 border-amber-400/60 shadow-lg shrink-0">
                  <div className="text-center">
                    <span className="text-xs text-slate-400 block font-bold">{t('BOARD_INDEX')}</span>
                    <span className="text-2xl font-black text-amber-300">%{boardConfidence}</span>
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <span className={`px-2.5 py-0.5 rounded-md border text-[10px] font-black uppercase ${badgeBg}`}>
                      {confidenceStatus}
                    </span>
                  </div>
                  <h3 className="text-sm font-extrabold text-white mt-1">{t('BOARD_ASSESSMENT')}</h3>
                  <p className="text-xs text-slate-300 flex items-center gap-1.5 mt-0.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{t('STATUS')}: <strong>{jobStatusText}</strong></span>
                  </p>
                </div>
              </div>

              {/* Quick Info Pill */}
              <div className="bg-[#120d28]/90 border border-[#342759] p-3 rounded-xl flex flex-col gap-1 text-right w-full sm:w-auto">
                <span className="text-[10px] text-slate-400 font-extrabold uppercase block">{t('SEASON_GOAL_TITLE')}</span>
                <span className="text-xs font-black text-amber-300">
                  🎯 {getTeamTargetGoal(currentTeam).seasonGoalText}
                </span>
                <span className="text-[10px] text-purple-200/90 font-bold mt-0.5">
                  {t('CURRENT_RANK')}: #{currentRank} / {totalTeams} {t('TEAMS_LABEL')}
                </span>
              </div>
            </div>

            {/* Confidence Progress Bar */}
            <div className="mt-4 pt-3 border-t border-[#372a63]">
              <div className="flex justify-between text-[11px] font-bold mb-1.5">
                <span className="text-slate-300">{t('CONFIDENCE_LEVEL_BAR')}</span>
                <span className="text-amber-300">%{boardConfidence} / %100</span>
              </div>
              <div className="w-full bg-[#120d28] h-3 rounded-full overflow-hidden border border-[#35285e] p-0.5">
                <div
                  className="bg-gradient-to-r from-amber-500 via-emerald-400 to-sky-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, boardConfidence)}%` }}
                />
              </div>
            </div>
          </div>

          {/* 4 Pillars Breakdown Grid */}
          <div>
            <h4 className="text-xs font-black text-purple-300 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
              <BarChart2 className="w-4 h-4 text-amber-400" />
              <span>{t('PILLARS_TITLE')}</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              
              {/* Pillar 1: Saha İçi Performans */}
              <div className="bg-[#16112e] border border-[#2d2252] p-3 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-extrabold text-white">{t('PILLAR_ON_PITCH')}</span>
                  </div>
                  <span className="text-xs font-black text-emerald-400">%{matchPerfScore}</span>
                </div>
                <div className="w-full bg-[#0d0a1c] h-2 rounded-full overflow-hidden border border-[#2b204e]">
                  <div className="bg-emerald-400 h-full rounded-full" style={{ width: `${matchPerfScore}%` }} />
                </div>
                <p className="text-[10px] text-slate-300">
                  {currentRank <= 4
                    ? t('PILLAR_PITCH_TOP').replace('{rank}', String(currentRank))
                    : t('PILLAR_PITCH_MID').replace('{rank}', String(currentRank))}
                </p>
              </div>

              {/* Pillar 2: Bütçe & Finans */}
              <div className="bg-[#16112e] border border-[#2d2252] p-3 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-sky-400" />
                    <span className="text-xs font-extrabold text-white">{t('PILLAR_FINANCE')}</span>
                  </div>
                  <span className="text-xs font-black text-sky-400">%{financialScore}</span>
                </div>
                <div className="w-full bg-[#0d0a1c] h-2 rounded-full overflow-hidden border border-[#2b204e]">
                  <div className="bg-sky-400 h-full rounded-full" style={{ width: `${financialScore}%` }} />
                </div>
                <p className="text-[10px] text-slate-300">
                  {t('PILLAR_FINANCE_DESC').replace('{amount}', (currentTeam.budget / 1_000_000).toFixed(1))}
                </p>
              </div>

              {/* Pillar 3: Soyunma Odası Morali */}
              <div className="bg-[#16112e] border border-[#2d2252] p-3 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-extrabold text-white">{t('PILLAR_MORALE')}</span>
                  </div>
                  <span className="text-xs font-black text-amber-400">%{moraleScore}</span>
                </div>
                <div className="w-full bg-[#0d0a1c] h-2 rounded-full overflow-hidden border border-[#2b204e]">
                  <div className="bg-amber-400 h-full rounded-full" style={{ width: `${moraleScore}%` }} />
                </div>
                <p className="text-[10px] text-slate-300">
                  {t('PILLAR_MORALE_DESC').replace('{score}', String(moraleScore))}
                </p>
              </div>

              {/* Pillar 4: Kadro & Taktiksel Verim */}
              <div className="bg-[#16112e] border border-[#2d2252] p-3 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-purple-400" />
                    <span className="text-xs font-extrabold text-white">{t('PILLAR_TACTICS')}</span>
                  </div>
                  <span className="text-xs font-black text-purple-400">%{tacticalScore}</span>
                </div>
                <div className="w-full bg-[#0d0a1c] h-2 rounded-full overflow-hidden border border-[#2b204e]">
                  <div className="bg-purple-400 h-full rounded-full" style={{ width: `${tacticalScore}%` }} />
                </div>
                <p className="text-[10px] text-slate-300">
                  {t('PILLAR_TACTICS_DESC').replace('{ovr}', String(squadAvgOvr))}
                </p>
              </div>

            </div>
          </div>

          {/* President Statement */}
          <div className="bg-[#120d26] border border-[#2d2150] p-3.5 rounded-xl space-y-2">
            <span className="text-[10px] font-black text-amber-400 uppercase tracking-wider block">
              💬 {t('PRESIDENT_STATEMENT_TITLE')}
            </span>
            <p className="text-xs text-slate-300 italic leading-relaxed">
              "{presidentQuote}"
            </p>
            <span className="text-[10px] text-slate-400 font-bold block text-right">
              — {currentTeam.name} {t('PRESIDENT_TITLE')}
            </span>
          </div>

          {/* Actionable Recommendations */}
          <div className="bg-amber-950/30 border border-amber-500/30 p-3 rounded-xl space-y-1.5 text-xs text-amber-200">
            <div className="flex items-center gap-1.5 font-bold text-amber-300">
              <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
              <span>{t('BOARD_RECOMMENDATIONS_TITLE')}</span>
            </div>
            <ul className="space-y-1 pl-5 list-disc text-[11px] text-amber-100/90 leading-snug">
              <li>{t('REC_WINNING_STREAK')}</li>
              <li>{t('REC_WAGE_BALANCE')}</li>
              <li>{t('REC_PRESS_TONE')}</li>
            </ul>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-3 border-t border-[#2d2252] bg-[#171233] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all active:scale-95 cursor-pointer"
          >
            {t('CONFIRM_AND_CLOSE')}
          </button>
        </div>

      </div>
    </div>
  );
};
