import React, { useState } from 'react';
import { Player, Team } from '../types';
import { X, FileText, CheckCircle2, XCircle, AlertCircle, ArrowUpRight, Shield, Calendar, DollarSign } from 'lucide-react';
import { useTranslation } from '../utils/i18n';

interface ContractModalProps {
  isOpen: boolean;
  onClose: () => void;
  player: Player;
  team: Team;
  userTeamId?: string;
  onUpdatePlayerContract: (playerId: string, updates: Partial<Player>) => void;
  showToast: (type: 'success' | 'error' | 'info', title: string, message: string) => void;
  onOpenOfferModal?: (player: Player, team?: Team, defaultType?: 'BUY' | 'LOAN') => void;
}

export const ContractModal: React.FC<ContractModalProps> = ({
  isOpen,
  onClose,
  player,
  team,
  userTeamId,
  onUpdatePlayerContract,
  showToast,
  onOpenOfferModal
}) => {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<'ACTIONS' | 'EXTENSION'>('ACTIONS');
  const [proposedYears, setProposedYears] = useState<number>(2);
  const [proposedWage, setProposedWage] = useState<number>(
    player.wage || 25000
  );
  const [relegationClause, setRelegationClause] = useState<boolean>(
    player.hasRelegationClause || false
  );
  const [negotiationResult, setNegotiationResult] = useState<{ status: 'IDLE' | 'SUCCESS' | 'REJECTED'; message: string } | null>(null);

  const [isListedForTransfer, setIsListedForTransfer] = useState<boolean>(!!player.isListedForTransfer);
  const [isListedForLoan, setIsListedForLoan] = useState<boolean>(!!player.isListedForLoan);

  React.useEffect(() => {
    setIsListedForTransfer(!!player.isListedForTransfer);
    setIsListedForLoan(!!player.isListedForLoan);
  }, [player.id, player.isListedForTransfer, player.isListedForLoan]);

  if (!isOpen) return null;

  const isUserOwned = !userTeamId || team.id === userTeamId;

  const currentWage = player.wage || 25000;
  const isYoung = player.age < 24;
  const isVeteran = player.age >= 30;

  // Expected wage rule:
  // Relegation clause reduces expected wage by 15%!
  let expectedWage = isYoung
    ? Math.round(currentWage * 1.25)
    : isVeteran
    ? Math.round(currentWage * 0.9)
    : Math.round(currentWage * 1.1);

  if (relegationClause) {
    expectedWage = Math.round(expectedWage * 0.85);
  }

  const handleContractSubmit = () => {
    // Check young player restriction (Max 3 years extension)
    if (isYoung && proposedYears > 3) {
      setNegotiationResult({
        status: 'REJECTED',
        message: t('NEGOTIATION_YOUNG_REJECTED').replace('{name}', player.name).replace('{age}', String(player.age))
      });
      return;
    }

    if (proposedYears > 5) {
      setNegotiationResult({
        status: 'REJECTED',
        message: t('NEGOTIATION_MAX_5_YEARS')
      });
      return;
    }

    // Wage check
    if (proposedWage < expectedWage * 0.9) {
      setNegotiationResult({
        status: 'REJECTED',
        message: t('NEGOTIATION_WAGE_LOW').replace('{name}', player.name).replace('{proposed}', proposedWage.toLocaleString('tr-TR')).replace('{expected}', expectedWage.toLocaleString('tr-TR'))
      });
      return;
    }

    // Accept!
    const currentEnd = player.contractUntil || 2028;
    const newEnd = currentEnd + proposedYears;

    onUpdatePlayerContract(player.id, {
      contractUntil: newEnd,
      wage: proposedWage,
      hasRelegationClause: relegationClause
    });

    setNegotiationResult({
      status: 'SUCCESS',
      message: t('NEGOTIATION_AGREED_SUCCESS').replace('{name}', player.name).replace('{year}', String(newEnd)).replace('{wage}', proposedWage.toLocaleString('tr-TR'))
    });

    showToast('success', t('CONTRACT_RENEWED_TITLE'), t('CONTRACT_RENEWED_MSG').replace('{name}', player.name).replace('{years}', String(proposedYears)));
  };

  const handleToggleTransferList = () => {
    const nextState = !isListedForTransfer;
    setIsListedForTransfer(nextState);
    onUpdatePlayerContract(player.id, { isListedForTransfer: nextState });
    showToast(
      'info',
      nextState ? t('ADDED_TRANSFER_LIST') : t('REMOVED_TRANSFER_LIST'),
      `${player.name} ${nextState ? t('MSG_ADDED_TRANSFER') : t('MSG_REMOVED_TRANSFER')}`
    );
  };

  const handleToggleLoanList = () => {
    const nextState = !isListedForLoan;
    setIsListedForLoan(nextState);
    onUpdatePlayerContract(player.id, { isListedForLoan: nextState });
    showToast(
      'info',
      nextState ? t('ADDED_LOAN_LIST') : t('REMOVED_LOAN_LIST'),
      `${player.name} ${nextState ? t('MSG_ADDED_LOAN') : t('MSG_REMOVED_LOAN')}`
    );
  };

  return (
    <div className="fixed inset-0 z-[10000] bg-black/85 backdrop-blur-md flex items-center justify-center p-3">
      <div className="bg-[#18142b] border border-[#3b2d63] w-full max-w-lg rounded-3xl p-4 sm:p-5 shadow-2xl space-y-4 text-white animate-in zoom-in duration-150 max-h-[90vh] overflow-y-auto custom-scrollbar">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#2b2247] pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#7b2cbf] to-[#3a0ca3] border border-[#9d4edd] flex items-center justify-center font-black text-amber-300">
              {player.overall}
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-1.5">
                {player.name} <span className="text-xs font-normal text-slate-400">({player.age} {t('YEARS_OLD')})</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                {team.name} • {t('CONTRACT_END')}: <strong className="text-purple-300">{player.contractUntil || 2028}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {player.isLoaned ? (
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#20183b] to-[#18122c] border-2 border-amber-500/60 space-y-4 text-center my-1 shadow-xl">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center text-amber-300 text-2xl mx-auto shadow-inner">
              🔄
            </div>
            
            <div>
              <h4 className="font-black text-base text-amber-300 uppercase tracking-wide">
                {t('LOAN_PLAYER_INFO_TITLE')}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed mt-1">
                <strong className="text-white">{player.name}</strong>, {t('LOAN_PLAYER_INFO_DESC')}
              </p>
            </div>

            <div className="bg-[#120e21] p-3 rounded-xl border border-[#2d224e] text-xs space-y-2 text-left">
              <div className="flex justify-between items-center border-b border-[#231b3e] pb-1.5">
                <span className="text-slate-400 font-bold">{t('PARENT_CLUB')}:</span>
                <span className="font-black text-white">{player.parentClubName || 'Bonservisli Kulüp'}</span>
              </div>
              <div className="flex justify-between items-center border-b border-[#231b3e] pb-1.5">
                <span className="text-slate-400 font-bold">{t('LOAN_CONTRACT_END')}:</span>
                <span className="font-black text-amber-300">30 {t('JUNE')} 2026 (1 {t('SEASON')})</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 font-bold">{t('MARKET_VALUE')}:</span>
                <span className="font-black text-emerald-400">€{((player.marketValue || 5000000) / 1_000_000).toFixed(1)}M</span>
              </div>
            </div>

            <p className="text-[11px] text-purple-300 font-bold italic">
              {t('BUY_PERMANENT_QUESTION')}
            </p>

            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <button
                onClick={() => {
                  onClose();
                  if (onOpenOfferModal) {
                    onOpenOfferModal(
                      player,
                      { name: player.parentClubName || 'Bonservisli Kulüp' } as any,
                      'BUY'
                    );
                  }
                }}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
              >
                <span>{t('BUY_TRANSFER_OFFER')}</span>
                <span>↗</span>
              </button>

              <button
                onClick={onClose}
                className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
              >
                {t('CLOSE')}
              </button>
            </div>
          </div>
        ) : !isUserOwned ? (
          <div className="p-4 sm:p-5 rounded-2xl bg-amber-950/40 border border-amber-500/50 space-y-3 text-center my-2">
            <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
            <h4 className="font-extrabold text-sm text-amber-300 uppercase tracking-wide">
              {t('CONTRACT_ACTION_BLOCKED')}
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              <strong className="text-white">{player.name}</strong>, <strong className="text-amber-200">{team.name}</strong> {t('OTHER_TEAM_PLAYER_WARNING')}
            </p>
            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-extrabold text-xs uppercase tracking-wider"
            >
              {t('OK_BTN')}
            </button>
          </div>
        ) : (
          <>
            {/* Tab Navigation */}
            <div className="flex items-center gap-2 bg-[#120f21] p-1 rounded-2xl border border-[#2b2247] text-xs font-bold">
          <button
            onClick={() => { setActiveTab('ACTIONS'); setNegotiationResult(null); }}
            className={`flex-1 py-2 rounded-xl transition-all ${
              activeTab === 'ACTIONS'
                ? 'bg-[#7b2cbf] text-white shadow font-black'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {t('TAB_CONTRACT_ACTIONS')}
          </button>
          <button
            onClick={() => { setActiveTab('EXTENSION'); setNegotiationResult(null); }}
            className={`flex-1 py-2 rounded-xl transition-all ${
              activeTab === 'EXTENSION'
                ? 'bg-[#7b2cbf] text-white shadow font-black'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {t('TAB_EXTEND_CONTRACT')}
          </button>
        </div>

        {/* Content Area */}
        {activeTab === 'ACTIONS' ? (
          <div className="space-y-3 py-1">
            <div className="bg-[#120f21] p-3 rounded-2xl border border-[#2b2247] space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 font-medium">{t('CURRENT_WEEKLY_WAGE')}:</span>
                <span className="font-extrabold text-sky-300">€{currentWage.toLocaleString('tr-TR')} / {t('PER_WEEK')}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 font-medium">{t('MARKET_VALUE')}:</span>
                <span className="font-extrabold text-amber-300">€{((player.marketValue || 5000000) / 1_000_000).toFixed(1)}M</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 font-medium">{t('PLAYER_STATUS')}:</span>
                <span className="font-extrabold text-purple-300">
                  {isYoung ? `🌟 ${t('YOUNG_TALENT')}` : isVeteran ? `🛡️ ${t('VETERAN_PLAYER')}` : `⚡ ${t('KEY_PLAYER')}`}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-2.5">
              <button
                onClick={() => setActiveTab('EXTENSION')}
                className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 text-white font-extrabold text-xs uppercase tracking-wider shadow flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-amber-300" />
                  <span>{t('BTN_CONTRACT_NEGOTIATION')}</span>
                </div>
                <ArrowUpRight className="w-4 h-4" />
              </button>

              <button
                onClick={handleToggleTransferList}
                className={`w-full py-2.5 px-4 rounded-2xl border text-xs font-extrabold flex items-center justify-between transition-all cursor-pointer ${
                  isListedForTransfer
                    ? 'bg-rose-950/40 border-rose-500/60 text-rose-300 hover:bg-rose-900/50'
                    : 'bg-[#120f21] border-[#2b2247] hover:border-slate-500 text-slate-200'
                }`}
              >
                <span>{t('TOGGLE_TRANSFER_LIST')}</span>
                <span className={`px-2 py-0.5 rounded-lg text-[10px] font-black ${
                  isListedForTransfer ? 'bg-rose-500 text-white' : 'bg-slate-800 text-slate-400'
                }`}>
                  {isListedForTransfer ? t('LISTED_TRANSFER') : t('NOT_LISTED')}
                </span>
              </button>

              <button
                onClick={handleToggleLoanList}
                className={`w-full py-2.5 px-4 rounded-2xl border text-xs font-extrabold flex items-center justify-between transition-all cursor-pointer ${
                  isListedForLoan
                    ? 'bg-sky-950/40 border-sky-500/60 text-sky-300 hover:bg-sky-900/50'
                    : 'bg-[#120f21] border-[#2b2247] hover:border-slate-500 text-slate-200'
                }`}
              >
                <span>{t('TOGGLE_LOAN_LIST')}</span>
                <span className={`px-2 py-0.5 rounded-lg text-[10px] font-black ${
                  isListedForLoan ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-400'
                }`}>
                  {isListedForLoan ? t('LISTED_LOAN') : t('NOT_LISTED')}
                </span>
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-3.5 py-1">
            <div className="bg-[#120f21] p-3 rounded-2xl border border-[#2b2247] space-y-1.5 text-xs">
              <div className="flex justify-between items-center text-slate-400">
                <span>{t('CURRENT_WAGE_LABEL')}:</span>
                <strong className="text-white">€{currentWage.toLocaleString('tr-TR')} / {t('PER_WEEK')}</strong>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>{t('EXPECTED_WAGE_LABEL')}:</span>
                <strong className="text-emerald-400">€{expectedWage.toLocaleString('tr-TR')} / {t('PER_WEEK')}</strong>
              </div>
              {isYoung && (
                <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[11px] font-semibold flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{t('YOUNG_PLAYER_CONTRACT_LIMIT').replace('{age}', String(player.age))}</span>
                </div>
              )}
            </div>

            {/* Proposed Years */}
            <div className="space-y-1">
              <label className="text-[11px] font-extrabold text-slate-300 uppercase flex justify-between">
                <span>{t('YEARS_TO_EXTEND')}</span>
                <span className="text-purple-300 font-black">+{proposedYears} {t('YEARS_UNIT')}</span>
              </label>
              <div className="flex gap-1.5">
                {[1, 2, 3, 4, 5].map(yr => {
                  const isDisabled = isYoung && yr > 3;
                  return (
                    <button
                      key={yr}
                      disabled={isDisabled}
                      onClick={() => setProposedYears(yr)}
                      className={`flex-1 py-2 rounded-xl text-xs font-black transition-all ${
                        isDisabled
                          ? 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed opacity-50'
                          : proposedYears === yr
                          ? 'bg-[#7b2cbf] text-white border border-[#9d4edd] shadow'
                          : 'bg-[#120f21] border border-[#2b2247] text-slate-300 hover:text-white'
                      }`}
                    >
                      {yr} {t('YEARS_UNIT')}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Proposed Wage */}
            <div className="space-y-1">
              <label className="text-[11px] font-extrabold text-slate-300 uppercase flex justify-between">
                <span>{t('OFFERED_WAGE_LABEL')}</span>
                <span className="text-sky-300 font-black">€{proposedWage.toLocaleString('tr-TR')} / {t('PER_WEEK')}</span>
              </label>
              <input
                type="number"
                step="1000"
                value={proposedWage}
                onChange={e => setProposedWage(Number(e.target.value))}
                className="w-full bg-[#120f21] border border-[#3b2d63] rounded-xl px-3 py-2 text-sm font-black text-emerald-400 focus:outline-none focus:border-purple-500"
              />
            </div>

            {/* Küme Düşerse Serbest Kalma Maddesi */}
            <div className="bg-[#120f21] p-2.5 rounded-xl border border-[#2b2247] flex items-center justify-between gap-3">
              <div>
                <span className="text-xs font-bold text-slate-200 block flex items-center gap-1.5">
                  <span>📉 {t('RELEGATION_CLAUSE_TITLE')}</span>
                </span>
                <span className="text-[10px] text-slate-400 block leading-tight">
                  {t('RELEGATION_CLAUSE_DESC')}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setRelegationClause(!relegationClause)}
                className={`w-11 h-6 rounded-full transition-colors relative p-1 shrink-0 ${
                  relegationClause ? 'bg-emerald-500' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    relegationClause ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Negotiation Output Result */}
            {negotiationResult && negotiationResult.status !== 'IDLE' && (
              <div className={`p-3 rounded-xl border text-xs font-semibold leading-relaxed flex items-start gap-2 ${
                negotiationResult.status === 'SUCCESS'
                  ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
                  : 'bg-rose-950/40 border-rose-500/50 text-rose-200'
              }`}>
                {negotiationResult.status === 'SUCCESS' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                )}
                <span>{negotiationResult.message}</span>
              </div>
            )}

            {/* Extension Submit Buttons */}
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setActiveTab('ACTIONS')}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold"
              >
                {t('BACK_BTN')}
              </button>
              {negotiationResult?.status !== 'SUCCESS' && (
                <button
                  onClick={handleContractSubmit}
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs uppercase tracking-wider shadow"
                >
                  {t('OFFER_CONTRACT_SUBMIT')}
                </button>
              )}
            </div>
          </div>
        )}
        </>
        )}

      </div>
    </div>
  );
};

