import React, { useState } from 'react';
import { CreatedPlayerProfile, Team, CustomPlayerAvatar } from '../types';
import { PlayerAvatarRenderer } from './PlayerAvatarRenderer';
import {
  UserCheck,
  Trophy,
  Zap,
  Shirt,
  Edit3,
  Check,
  Dumbbell,
  FileText,
  Mail,
  Building2,
  TrendingUp,
  Sparkles,
  ChevronRight,
  ShieldAlert,
  Send,
  Clock,
  Briefcase,
  AlertCircle
} from 'lucide-react';

interface MyPlayerViewProps {
  createdPlayer: CreatedPlayerProfile;
  currentTeam: Team;
  allTeams: Team[];
  onUpdatePlayerProfile: (updated: CreatedPlayerProfile) => void;
  onTransferToTeam: (newTeamId: string) => void;
}

export const MyPlayerView: React.FC<MyPlayerViewProps> = ({
  createdPlayer,
  currentTeam,
  allTeams,
  onUpdatePlayerProfile,
  onTransferToTeam
}) => {
  // Navigation Sub-Tabs inside Player Career
  const [activeSubTab, setActiveSubTab] = useState<'PROFILE' | 'TRAINING' | 'CHAIRMAN'>('PROFILE');

  // Avatar Edit Modal State
  const [isEditingAvatar, setIsEditingAvatar] = useState<boolean>(false);
  const [avatarForm, setAvatarForm] = useState<CustomPlayerAvatar>(createdPlayer.avatar);

  // Player Personal Training State
  const [trainingEnergy, setTrainingEnergy] = useState<number>(3); // 3 drills max per week
  const [isTraining, setIsTraining] = useState<boolean>(false);
  const [activeDrillName, setActiveDrillName] = useState<string>('');
  const [trainingProgress, setTrainingProgress] = useState<number>(0);
  const [trainingSuccessMsg, setTrainingSuccessMsg] = useState<string | null>(null);

  // Chairman & Transfer Request State
  const [transferStatus, setTransferStatus] = useState<'NORMAL' | 'TRANSFER_LISTED' | 'LOAN_LISTED'>('NORMAL');
  const [requestType, setRequestType] = useState<'TRANSFER' | 'LOAN' | 'WAGE'>('TRANSFER');
  const [requestNote, setRequestNote] = useState<string>('');
  const [pendingRequest, setPendingRequest] = useState<string | null>(null);
  const [chairmanDecisionModal, setChairmanDecisionModal] = useState<{
    open: boolean;
    approved: boolean;
    title: string;
    message: string;
  } | null>(null);

  // Incoming Transfer Offers (Generated when listed)
  const potentialOfferTeams = allTeams.filter(t => t.id !== currentTeam.id);
  const [selectedOfferTeamId, setSelectedOfferTeamId] = useState<string>('');

  // Save Avatar Changes
  const handleSaveAvatar = () => {
    onUpdatePlayerProfile({
      ...createdPlayer,
      avatar: avatarForm
    });
    setIsEditingAvatar(false);
  };

  // Run Personal Training Drill
  const handleStartDrill = (attrKey: keyof typeof createdPlayer.attributes, drillLabel: string) => {
    if (trainingEnergy <= 0) return;

    setIsTraining(true);
    setActiveDrillName(drillLabel);
    setTrainingProgress(10);
    setTrainingSuccessMsg(null);

    // Simulate animated training progress
    let interval = setInterval(() => {
      setTrainingProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          
          // Apply attribute increase
          const currentAttrVal = createdPlayer.attributes[attrKey];
          const newAttrVal = Math.min(99, currentAttrVal + 1);
          
          const newAttributes = {
            ...createdPlayer.attributes,
            [attrKey]: newAttrVal
          };

          // Recalculate Overall (OVR)
          const newOverall = Math.round(
            (newAttributes.pace +
              newAttributes.shooting +
              newAttributes.passing +
              newAttributes.defending +
              newAttributes.physical) / 5
          );

          const updatedProfile: CreatedPlayerProfile = {
            ...createdPlayer,
            attributes: newAttributes,
            overall: newOverall
          };

          onUpdatePlayerProfile(updatedProfile);
          setTrainingEnergy((e) => Math.max(0, e - 1));
          setIsTraining(false);
          setTrainingSuccessMsg(`Tebrikler! ${drillLabel} tamamlandı. Özelliğiniz ${currentAttrVal} ➔ ${newAttrVal} seviyesine yükseldi! ⭐`);

          return 100;
        }
        return prev + 25;
      });
    }, 250);
  };

  // Submit Request to Chairman
  const handleSubmitRequestToChairman = () => {
    if (!requestType) return;

    const requestLabels = {
      TRANSFER: 'Transfer Listesine Eklenme Talebi',
      LOAN: 'Kiralık Listesine Eklenme Talebi',
      WAGE: 'Sözleşme Yenileme & Maaş Zammı Talebi'
    };

    setPendingRequest(requestLabels[requestType]);
  };

  // Resolve Chairman Decision (Simulate 2-3 Days Later)
  const handleResolveChairmanDecision = () => {
    if (!pendingRequest) return;

    // Decision Logic based on Manager Trust %
    const trust = createdPlayer.managerTrust;
    const isApproved = trust >= 50 || Math.random() > 0.35;

    if (isApproved) {
      if (requestType === 'TRANSFER') {
        setTransferStatus('TRANSFER_LISTED');
      } else if (requestType === 'LOAN') {
        setTransferStatus('LOAN_LISTED');
      } else if (requestType === 'WAGE') {
        const updatedProfile: CreatedPlayerProfile = {
          ...createdPlayer,
          wage: Math.round(createdPlayer.wage * 1.35)
        };
        onUpdatePlayerProfile(updatedProfile);
      }

      setChairmanDecisionModal({
        open: true,
        approved: true,
        title: 'BŞK. MEHMET BÜYÜKEKŞİ - DILEKÇE ONAY MEKTUBU',
        message: `Sayın ${createdPlayer.name},\n\nYönetim kurulumuz ile gerçekleştirdiğimiz toplantı sonucunda '${pendingRequest}' konulu dilekçeniz değerlendirilmiştir. Kulübümüze kattığınız emekler için teşekkür eder, talebinizi KABUL ETTİĞİMİZİ bildirmek isteriz.\n\nİsminiz resmi transfer pazarında güncelleştirilmiştir.`
      });
    } else {
      setChairmanDecisionModal({
        open: true,
        approved: false,
        title: 'BŞK. MEHMET BÜYÜKEKŞİ - DILEKÇE RED MEKTUBU',
        message: `Sayın ${createdPlayer.name},\n\nSüper Lig şampiyonluk yolundaki kilit oyuncularımızdan biri olmanız nedeniyle dilekçeniz şu an için REDDEDİLMİŞTİR. Takımımızın kadro derinliğini korumak adına sizi satmayı veya kiralamayı düşünmüyoruz.`
      });
    }

    setPendingRequest(null);
  };

  return (
    <div className="w-full max-w-6xl mx-auto space-y-4 sm:space-y-6 pb-16 px-1 sm:px-2 animate-fadeIn">
      
      {/* HEADER CARD - Fully Fluid & Responsive on PC & Mobile */}
      <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden border-2 border-[#382d5e] bg-gradient-to-r from-[#161131] via-[#241a4a] to-[#161131] p-4 sm:p-6 shadow-2xl">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 sm:gap-6 relative z-10">
          
          {/* Left: Player Avatar + Details */}
          <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left w-full md:w-auto">
            <div className="relative shrink-0">
              <PlayerAvatarRenderer
                avatar={createdPlayer.avatar}
                jerseyColor={currentTeam.secondaryColor || '#7b2cbf'}
                size={100}
              />
              <button
                onClick={() => setIsEditingAvatar(true)}
                className="absolute -bottom-1 -right-1 p-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white shadow-xl border border-purple-400/50 text-[11px] font-bold flex items-center gap-1 active:scale-95 transition-all"
                title="Görünümü Düzenle"
              >
                <Edit3 className="w-3 h-3" /> Düzenle
              </button>
            </div>

            <div className="w-full">
              <div className="flex items-center justify-center sm:justify-start gap-2 mb-1 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/30 font-black text-[10px] uppercase tracking-wider">
                  Kariyer Modu ⚽
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 font-black text-[10px]">
                  {createdPlayer.preferredFoot} Ayak
                </span>
                <span className={`px-2.5 py-0.5 rounded-full font-black text-[10px] ${
                  transferStatus === 'TRANSFER_LISTED'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : transferStatus === 'LOAN_LISTED'
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                }`}>
                  {transferStatus === 'TRANSFER_LISTED' ? '🔥 Transfer Listesinde' : transferStatus === 'LOAN_LISTED' ? '🔄 Kiralık Listesinde' : '🛡️ Kulüpte Kalıyor'}
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-wide">
                {createdPlayer.name}
              </h2>

              <p className="text-xs sm:text-sm text-slate-300 font-bold flex items-center justify-center sm:justify-start gap-2 mt-1 flex-wrap">
                <span className={`w-3 h-3 rounded-full bg-gradient-to-br ${currentTeam.badgeColor} inline-block shadow-sm`} />
                {currentTeam.name} • {createdPlayer.position} ({createdPlayer.specificRole}) • {createdPlayer.age} Yaş
              </p>

              {/* Quick Stat Indicators */}
              <div className="grid grid-cols-3 gap-2 mt-3 pt-2 border-t border-[#382d5e]/60 text-center sm:text-left text-xs">
                <div>
                  <span className="text-slate-400 block text-[9px] font-extrabold uppercase">Piyasa Değeri</span>
                  <span className="font-black text-emerald-400 text-xs sm:text-sm">€{(createdPlayer.marketValue / 1_000_000).toFixed(1)}M</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[9px] font-extrabold uppercase">Haftalık Maaş</span>
                  <span className="font-black text-amber-300 text-xs sm:text-sm">€{createdPlayer.wage.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[9px] font-extrabold uppercase">Teknik Güven</span>
                  <span className="font-black text-sky-300 text-xs sm:text-sm">%{createdPlayer.managerTrust}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: OVR Rating Card */}
          <div className="flex flex-row md:flex-col items-center justify-between md:justify-center gap-3 w-full md:w-auto shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-[#382d5e]/60">
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl sm:rounded-3xl bg-gradient-to-tr from-[#7b2cbf] via-[#9d4edd] to-[#c77dff] flex flex-col items-center justify-center text-white shadow-2xl border-2 border-purple-300/40">
              <span className="text-[9px] uppercase font-black tracking-widest text-purple-200">GENEL (OVR)</span>
              <span className="text-2xl sm:text-3xl font-black">{createdPlayer.overall}</span>
              <span className="text-[9px] font-bold text-emerald-300">⭐ A Takım</span>
            </div>

            <button
              onClick={() => setActiveSubTab('CHAIRMAN')}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:brightness-110 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg flex items-center gap-1.5 active:scale-95 transition-all"
            >
              <Building2 className="w-4 h-4" /> Başkan Odası
            </button>
          </div>

        </div>
      </div>

      {/* SUB-NAVIGATION TABS (Mobil & PC Uyumlu Menü) */}
      <div className="flex items-center gap-2 bg-[#140f2a] p-1.5 rounded-2xl border border-[#2b214d] overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveSubTab('PROFILE')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all active:scale-95 ${
            activeSubTab === 'PROFILE'
              ? 'bg-[#7b2cbf] text-white shadow-lg shadow-purple-500/30 border border-purple-400/40'
              : 'text-slate-400 hover:text-white hover:bg-[#1e173e]'
          }`}
        >
          <UserCheck className="w-4 h-4 text-purple-300" />
          <span>Profil & İstatistikler</span>
        </button>

        <button
          onClick={() => setActiveSubTab('TRAINING')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all active:scale-95 ${
            activeSubTab === 'TRAINING'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/30 border border-emerald-400/40'
              : 'text-slate-400 hover:text-white hover:bg-[#1e173e]'
          }`}
        >
          <Dumbbell className="w-4 h-4 text-emerald-300" />
          <span>Kişisel Antrenman</span>
        </button>

        <button
          onClick={() => setActiveSubTab('CHAIRMAN')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all active:scale-95 ${
            activeSubTab === 'CHAIRMAN'
              ? 'bg-amber-600 text-white shadow-lg shadow-amber-500/30 border border-amber-400/40'
              : 'text-slate-400 hover:text-white hover:bg-[#1e173e]'
          }`}
        >
          <Building2 className="w-4 h-4 text-amber-300" />
          <span>Başkan Odası & Transfer</span>
        </button>
      </div>

      {/* SUB-TAB 1: PROFILE & STATISTICS */}
      {activeSubTab === 'PROFILE' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 sm:gap-5 animate-fadeIn">
          
          {/* Season Match Performance Statistics */}
          <div className="md:col-span-6 bg-[#161131] border border-[#2e2352] rounded-3xl p-4 sm:p-5 space-y-4 shadow-xl">
            <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider flex items-center gap-2 border-b border-[#2e2352] pb-3">
              <Trophy className="w-4 h-4 text-amber-400" /> Sezon Performansı & Maç Kayıtları
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-[#1f1842] rounded-2xl border border-[#352968] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase text-slate-400 block">Oynanan Maç</span>
                  <span className="text-xl font-black text-white">{createdPlayer.matchesPlayed}</span>
                </div>
                <div className="w-9 h-9 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-300 text-sm">
                  🏟️
                </div>
              </div>

              <div className="p-3 bg-[#1f1842] rounded-2xl border border-[#352968] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase text-slate-400 block">Atılan Gol</span>
                  <span className="text-xl font-black text-emerald-400">{createdPlayer.goalsScored}</span>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-300 text-sm">
                  ⚽
                </div>
              </div>

              <div className="p-3 bg-[#1f1842] rounded-2xl border border-[#352968] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase text-slate-400 block">Asist Sayısı</span>
                  <span className="text-xl font-black text-sky-400">{createdPlayer.assists}</span>
                </div>
                <div className="w-9 h-9 rounded-xl bg-sky-500/20 flex items-center justify-center text-sky-300 text-sm">
                  🎯
                </div>
              </div>

              <div className="p-3 bg-[#1f1842] rounded-2xl border border-[#352968] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase text-slate-400 block">Maç Puanı Ort.</span>
                  <span className="text-xl font-black text-amber-300">{createdPlayer.averageRating.toFixed(1)}</span>
                </div>
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-300 text-sm">
                  ⭐
                </div>
              </div>
            </div>

            <div className="p-3.5 bg-[#1a1438] rounded-2xl border border-[#32265d] space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-300">Maç Kondisyonu (Stamina)</span>
                <span className="font-black text-emerald-400">%{createdPlayer.stamina}</span>
              </div>
              <div className="w-full h-2.5 bg-[#251c4a] rounded-full overflow-hidden border border-[#3a2c70]">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
                  style={{ width: `${createdPlayer.stamina}%` }}
                />
              </div>
            </div>
          </div>

          {/* Player Skill Attributes Breakdown */}
          <div className="md:col-span-6 bg-[#161131] border border-[#2e2352] rounded-3xl p-4 sm:p-5 space-y-4 shadow-xl">
            <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider flex items-center gap-2 border-b border-[#2e2352] pb-3">
              <Zap className="w-4 h-4 text-sky-400" /> Oyuncu Yetenek Seviyeleri
            </h3>

            <div className="space-y-3">
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-300">Hız & İvmelenme (PAC)</span>
                  <span className="text-purple-300 font-black">{createdPlayer.attributes.pace}</span>
                </div>
                <div className="w-full h-2 bg-[#251c4a] rounded-full overflow-hidden">
                  <div className="h-full bg-purple-500 rounded-full transition-all duration-500" style={{ width: `${createdPlayer.attributes.pace}%` }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-300">Şut & Bitiricilik (SHO)</span>
                  <span className="text-emerald-400 font-black">{createdPlayer.attributes.shooting}</span>
                </div>
                <div className="w-full h-2 bg-[#251c4a] rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full transition-all duration-500" style={{ width: `${createdPlayer.attributes.shooting}%` }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-300">Pas & Vizyon (PAS)</span>
                  <span className="text-sky-400 font-black">{createdPlayer.attributes.passing}</span>
                </div>
                <div className="w-full h-2 bg-[#251c4a] rounded-full overflow-hidden">
                  <div className="h-full bg-sky-500 rounded-full transition-all duration-500" style={{ width: `${createdPlayer.attributes.passing}%` }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-300">Defans & Müdahale (DEF)</span>
                  <span className="text-amber-400 font-black">{createdPlayer.attributes.defending}</span>
                </div>
                <div className="w-full h-2 bg-[#251c4a] rounded-full overflow-hidden">
                  <div className="h-full bg-amber-500 rounded-full transition-all duration-500" style={{ width: `${createdPlayer.attributes.defending}%` }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-300">Fizik & Güç (PHY)</span>
                  <span className="text-rose-400 font-black">{createdPlayer.attributes.physical}</span>
                </div>
                <div className="w-full h-2 bg-[#251c4a] rounded-full overflow-hidden">
                  <div className="h-full bg-rose-500 rounded-full transition-all duration-500" style={{ width: `${createdPlayer.attributes.physical}%` }} />
                </div>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* SUB-TAB 2: GRADUAL ATTRIBUTE TRAINING */}
      {activeSubTab === 'TRAINING' && (
        <div className="space-y-4 sm:space-y-5 animate-fadeIn">
          
          {/* Energy & Status Header */}
          <div className="bg-[#161131] border border-emerald-500/30 rounded-3xl p-4 sm:p-6 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-left">
              <h3 className="text-lg font-black text-white flex items-center justify-center sm:justify-start gap-2">
                <Dumbbell className="w-5 h-5 text-emerald-400" /> Kişisel AntrenmAn & Yetenek Geliştirme
              </h3>
              <p className="text-xs text-slate-300">
                Haftalık antrenman programınızla yeteneklerinizi yavaş yavaş geliştirin. Her antrenman ilgili özelliğinizi +1 arttırır!
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0 bg-[#1f1745] p-3 rounded-2xl border border-[#382b6b]">
              <div>
                <span className="text-[10px] uppercase font-extrabold text-slate-400 block">Haftalık Enerji Hakları</span>
                <span className="text-lg font-black text-emerald-400">{trainingEnergy} / 3 Antrenman</span>
              </div>
              {trainingEnergy === 0 && (
                <button
                  onClick={() => setTrainingEnergy(3)}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black active:scale-95 transition-all shadow"
                >
                  Dinlen & Yenile ⚡
                </button>
              )}
            </div>
          </div>

          {/* Success Banner */}
          {trainingSuccessMsg && (
            <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-500/50 text-emerald-200 font-extrabold text-xs sm:text-sm flex items-center gap-3 shadow-lg animate-fadeIn">
              <Sparkles className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>{trainingSuccessMsg}</span>
            </div>
          )}

          {/* Active Training Progress Modal/Overlay */}
          {isTraining && (
            <div className="p-5 rounded-3xl bg-gradient-to-r from-purple-900/90 to-indigo-900/90 border-2 border-emerald-400/60 space-y-3 shadow-2xl animate-pulse">
              <div className="flex items-center justify-between text-xs font-black text-white">
                <span className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-emerald-400 animate-spin" /> {activeDrillName} Yapılıyor...
                </span>
                <span className="text-emerald-300">%{trainingProgress}</span>
              </div>
              <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden border border-purple-400/40">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-300 rounded-full transition-all duration-300"
                  style={{ width: `${trainingProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Training Drills Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            
            {/* Drill 1: Shooting */}
            <div className="bg-[#181230] border border-[#2e2352] rounded-2xl p-4 space-y-3 hover:border-emerald-500/50 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-300 font-black text-xs">
                    🎯 Bitiricilik & Şut
                  </span>
                  <span className="text-xs font-black text-emerald-400">
                    Mevcut: {createdPlayer.attributes.shooting}
                  </span>
                </div>
                <h4 className="text-sm font-black text-white">Sert Şut ve Karşı Karşıya Vuruş</h4>
                <p className="text-xs text-slate-300 mt-1">
                  Ceza sahası dışından plase ve frikik bitiricilik antrenmanı.
                </p>
              </div>

              <button
                disabled={isTraining || trainingEnergy <= 0}
                onClick={() => handleStartDrill('shooting', 'Şut & Bitiricilik Çalışması')}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow"
              >
                <Dumbbell className="w-4 h-4" /> Antrenmanı Yap (+1 SHO)
              </button>
            </div>

            {/* Drill 2: Pace */}
            <div className="bg-[#181230] border border-[#2e2352] rounded-2xl p-4 space-y-3 hover:border-purple-500/50 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="p-2 rounded-xl bg-purple-500/20 text-purple-300 font-black text-xs">
                    ⚡ Sürat & İvmelenme
                  </span>
                  <span className="text-xs font-black text-purple-300">
                    Mevcut: {createdPlayer.attributes.pace}
                  </span>
                </div>
                <h4 className="text-sm font-black text-white">Çeviklik Merdiveni & Deparlar</h4>
                <p className="text-xs text-slate-300 mt-1">
                  Kısa mesafe patlayıcı hız ve ivmelenme çalışmaları.
                </p>
              </div>

              <button
                disabled={isTraining || trainingEnergy <= 0}
                onClick={() => handleStartDrill('pace', 'Sürat & İvmelenme Deparları')}
                className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow"
              >
                <Dumbbell className="w-4 h-4" /> Antrenmanı Yap (+1 PAC)
              </button>
            </div>

            {/* Drill 3: Passing */}
            <div className="bg-[#181230] border border-[#2e2352] rounded-2xl p-4 space-y-3 hover:border-sky-500/50 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="p-2 rounded-xl bg-sky-500/20 text-sky-300 font-black text-xs">
                    🎯 Pas & Vizyon
                  </span>
                  <span className="text-xs font-black text-sky-400">
                    Mevcut: {createdPlayer.attributes.passing}
                  </span>
                </div>
                <h4 className="text-sm font-black text-white">Ara Pası & Oyun Kurma</h4>
                <p className="text-xs text-slate-300 mt-1">
                  Derinlemesine paslar, duran top organizasyonu ve orta kalitesi.
                </p>
              </div>

              <button
                disabled={isTraining || trainingEnergy <= 0}
                onClick={() => handleStartDrill('passing', 'Pas & Vizyon Çalışması')}
                className="w-full py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow"
              >
                <Dumbbell className="w-4 h-4" /> Antrenmanı Yap (+1 PAS)
              </button>
            </div>

            {/* Drill 4: Defending */}
            <div className="bg-[#181230] border border-[#2e2352] rounded-2xl p-4 space-y-3 hover:border-amber-500/50 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="p-2 rounded-xl bg-amber-500/20 text-amber-300 font-black text-xs">
                    🛡️ Defans & Pres
                  </span>
                  <span className="text-xs font-black text-amber-400">
                    Mevcut: {createdPlayer.attributes.defending}
                  </span>
                </div>
                <h4 className="text-sm font-black text-white">Alan Pozisyonlama & Top Kapma</h4>
                <p className="text-xs text-slate-300 mt-1">
                  İkili mücadeleler, top kapma zamanlaması ve alan savunması.
                </p>
              </div>

              <button
                disabled={isTraining || trainingEnergy <= 0}
                onClick={() => handleStartDrill('defending', 'Defans & Pres Çalışması')}
                className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow"
              >
                <Dumbbell className="w-4 h-4" /> Antrenmanı Yap (+1 DEF)
              </button>
            </div>

            {/* Drill 5: Physical */}
            <div className="bg-[#181230] border border-[#2e2352] rounded-2xl p-4 space-y-3 hover:border-rose-500/50 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="p-2 rounded-xl bg-rose-500/20 text-rose-300 font-black text-xs">
                    🏋️ Fizik & Dayanıklılık
                  </span>
                  <span className="text-xs font-black text-rose-400">
                    Mevcut: {createdPlayer.attributes.physical}
                  </span>
                </div>
                <h4 className="text-sm font-black text-white">Ağırlık & Fitness Salonu</h4>
                <p className="text-xs text-slate-300 mt-1">
                  Kas gücü, vücut vücuda mücadele direnci ve maç kondisyonu.
                </p>
              </div>

              <button
                disabled={isTraining || trainingEnergy <= 0}
                onClick={() => handleStartDrill('physical', 'Fizik & Güç Çalışması')}
                className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow"
              >
                <Dumbbell className="w-4 h-4" /> Antrenmanı Yap (+1 PHY)
              </button>
            </div>

          </div>

        </div>
      )}

      {/* SUB-TAB 3: CHAIRMAN ROOM & TRANSFER REQUESTS */}
      {activeSubTab === 'CHAIRMAN' && (
        <div className="space-y-4 sm:space-y-6 animate-fadeIn">
          
          {/* Chairman Info Card */}
          <div className="bg-[#161131] border-2 border-amber-500/40 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 relative z-10">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300 font-black text-2xl shrink-0">
                  🏛️
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-amber-400 block">
                    Kulüp Yönetimi & Başkan Odası
                  </span>
                  <h3 className="text-lg sm:text-xl font-black text-white">
                    {currentTeam.name} Yönetim Kurulu
                  </h3>
                  <p className="text-xs text-slate-300 font-medium mt-0.5">
                    Kulüp Başkanı ve yönetim kuruluna resmi dilekçe sunabilir, transfer veya kiralık listenizi talep edebilirsiniz.
                  </p>
                </div>
              </div>

              <div className="px-4 py-2.5 rounded-2xl bg-[#1e163d] border border-[#382b6b] text-center shrink-0 w-full sm:w-auto">
                <span className="text-[10px] uppercase font-black text-slate-400 block">Resmi Durumunuz</span>
                <span className={`text-sm font-black ${
                  transferStatus === 'NORMAL' ? 'text-emerald-400' : 'text-amber-300'
                }`}>
                  {transferStatus === 'NORMAL' ? 'Kulüpte Kalıyor (Satılık Değil)' : transferStatus === 'TRANSFER_LISTED' ? 'Transfer Listesinde (Satılık)' : 'Kiralık Listesinde'}
                </span>
              </div>
            </div>
          </div>

          {/* Pending Request Alert Box */}
          {pendingRequest && (
            <div className="p-5 rounded-3xl bg-amber-500/10 border-2 border-amber-500/40 space-y-3 shadow-xl">
              <div className="flex items-center justify-between text-xs font-black text-amber-300">
                <span className="flex items-center gap-2 text-sm">
                  <Clock className="w-5 h-5 text-amber-400 animate-spin" /> Dilekçeniz Başkanın Masasında
                </span>
                <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-200 border border-amber-500/30">
                  İncelemede ⏳
                </span>
              </div>

              <p className="text-xs text-slate-300">
                Resmi talebiniz ({pendingRequest}) kulüp başkanına iletildi. Başkan kurul toplantısı sonrası kararını açıklayacaktır.
              </p>

              <button
                onClick={handleResolveChairmanDecision}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all shadow-lg"
              >
                <Mail className="w-4 h-4" /> Başkanın Kararını Açıkla (2 Gün Sonra)
              </button>
            </div>
          )}

          {/* Transfer Request Form */}
          {!pendingRequest && (
            <div className="bg-[#161131] border border-[#2e2352] rounded-3xl p-5 space-y-4 shadow-xl">
              <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider flex items-center gap-2 border-b border-[#2e2352] pb-3">
                <FileText className="w-4 h-4 text-amber-400" /> Başkana Resmi Dilekçe Gönder
              </h3>

              <div className="space-y-3">
                <label className="text-xs font-bold text-slate-300 block">Talep Türünü Seçin:</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setRequestType('TRANSFER')}
                    className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                      requestType === 'TRANSFER'
                        ? 'bg-amber-500/20 border-amber-400 text-white shadow'
                        : 'bg-[#1e173e] border-[#34285e] text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="font-black text-xs">🔥 Transfer Listesi</span>
                    <span className="text-[10px] text-slate-300 mt-1">Bonservisle başka kulübe satılmak için listeye girmeyi talep et.</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRequestType('LOAN')}
                    className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                      requestType === 'LOAN'
                        ? 'bg-sky-500/20 border-sky-400 text-white shadow'
                        : 'bg-[#1e173e] border-[#34285e] text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="font-black text-xs">🔄 Kiralık Listesi</span>
                    <span className="text-[10px] text-slate-300 mt-1">Düzenli forma giymek için 1 sezonluğuna kiralanmayı talep et.</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRequestType('WAGE')}
                    className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                      requestType === 'WAGE'
                        ? 'bg-emerald-500/20 border-emerald-400 text-white shadow'
                        : 'bg-[#1e173e] border-[#34285e] text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="font-black text-xs">💰 Maaş Zam Talebi</span>
                    <span className="text-[10px] text-slate-300 mt-1">Sezon performansın doğrultusunda maaşında iyileştirme iste.</span>
                  </button>
                </div>

                <div className="space-y-1.5 pt-2">
                  <label className="text-xs font-bold text-slate-300 block">Başkan'a Özel Notunuz (İsteğe Bağlı):</label>
                  <textarea
                    rows={3}
                    value={requestNote}
                    onChange={(e) => setRequestNote(e.target.value)}
                    placeholder="Sayın Başkanım, kariyerimde yeni bir sayfa açmak istiyorum..."
                    className="w-full bg-[#1c153b] border border-[#362a63] rounded-2xl p-3 text-white text-xs font-medium focus:outline-none focus:border-amber-400"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleSubmitRequestToChairman}
                  className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:brightness-110 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all shadow-lg"
                >
                  <Send className="w-4 h-4" /> Dilekçeyi Başkanı Gönder
                </button>
              </div>
            </div>
          )}

          {/* Incoming Transfer & Loan Offers (If Listed) */}
          {(transferStatus === 'TRANSFER_LISTED' || transferStatus === 'LOAN_LISTED') && (
            <div className="bg-[#161131] border border-emerald-500/30 rounded-3xl p-5 space-y-4 shadow-xl">
              <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider flex items-center gap-2 border-b border-[#2e2352] pb-3">
                <Briefcase className="w-4 h-4 text-emerald-400" /> Masadaki Transfer & Sözleşme Teklifleri
              </h3>

              <p className="text-xs text-slate-300">
                Kulübünüz transfer/kiralık talebinizi onayladığı için diğer Süper Lig kulüplerinden resmi sözleşme teklifleri geldi.
              </p>

              <div className="space-y-2.5 max-h-[280px] overflow-y-auto custom-scrollbar pr-1">
                {potentialOfferTeams.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => setSelectedOfferTeamId(t.id)}
                    className={`p-3.5 rounded-2xl border cursor-pointer flex items-center justify-between transition-all ${
                      selectedOfferTeamId === t.id
                        ? 'bg-emerald-500/20 border-emerald-400 text-white shadow'
                        : 'bg-[#1e173e] border-[#32275b] text-slate-300 hover:bg-[#281f4f]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${t.badgeColor} flex items-center justify-center font-black text-xs text-white shadow`}>
                        {t.shortName}
                      </div>
                      <div>
                        <span className="font-black text-sm text-white block">{t.name}</span>
                        <span className="text-[10px] text-emerald-400 font-bold">
                          Teklif: €{((createdPlayer.marketValue * 1.1) / 1_000_000).toFixed(1)}M Bonservis • €{Math.round(createdPlayer.wage * 1.25).toLocaleString()}/Hafta
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onTransferToTeam(t.id);
                      }}
                      className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase shadow flex items-center gap-1 active:scale-95 transition-all"
                    >
                      <Check className="w-3.5 h-3.5" /> İmzala & Transfer Ol
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      )}

      {/* EDIT AVATAR MODAL */}
      {isEditingAvatar && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-lg bg-[#181230] border-2 border-purple-500/40 rounded-3xl p-5 sm:p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#2e2352] pb-3">
              <h3 className="text-sm font-black text-white uppercase flex items-center gap-2">
                <Shirt className="w-5 h-5 text-purple-400" /> Oyuncu Görünümünü Düzenle
              </h3>
              <button onClick={() => setIsEditingAvatar(false)} className="text-slate-400 hover:text-white font-bold text-xs">
                Kapat ✕
              </button>
            </div>

            <div className="flex items-center justify-center py-2">
              <PlayerAvatarRenderer
                avatar={avatarForm}
                jerseyColor={currentTeam.secondaryColor || '#7b2cbf'}
                size={100}
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300 font-bold block">Ten Rengi:</label>
                <select
                  value={avatarForm.skinTone}
                  onChange={(e) => setAvatarForm((a) => ({ ...a, skinTone: e.target.value as any }))}
                  className="w-full bg-[#20183f] border border-[#392e5c] rounded-xl px-2.5 py-1.5 text-white font-bold"
                >
                  <option value="Açık">Açık Ten</option>
                  <option value="Buğday">Buğday Ten</option>
                  <option value="Bronz">Bronz Ten</option>
                  <option value="Esmer">Esmer Ten</option>
                  <option value="Koyu">Koyu Ten</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-bold block">Saç Modeli:</label>
                <select
                  value={avatarForm.hairStyle}
                  onChange={(e) => setAvatarForm((a) => ({ ...a, hairStyle: e.target.value as any }))}
                  className="w-full bg-[#20183f] border border-[#392e5c] rounded-xl px-2.5 py-1.5 text-white font-bold"
                >
                  <option value="Fade">Fade / Amerikan</option>
                  <option value="Kısa">Kısa Saç</option>
                  <option value="Bukleli">Bukleli / Kıvırcık</option>
                  <option value="Uzun">Uzun Saç</option>
                  <option value="Buzz">Askeri / Buzz Cut</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-bold block">Saç Rengi:</label>
                <select
                  value={avatarForm.hairColor}
                  onChange={(e) => setAvatarForm((a) => ({ ...a, hairColor: e.target.value as any }))}
                  className="w-full bg-[#20183f] border border-[#392e5c] rounded-xl px-2.5 py-1.5 text-white font-bold"
                >
                  <option value="Siyah">Siyah</option>
                  <option value="Kahverengi">Kahverengi</option>
                  <option value="Sarı">Sarı / Sarışın</option>
                  <option value="Kızıl">Kızıl</option>
                  <option value="Gümüş">Gümüş / Gri</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-bold block">Göz Rengi:</label>
                <select
                  value={avatarForm.eyeColor}
                  onChange={(e) => setAvatarForm((a) => ({ ...a, eyeColor: e.target.value as any }))}
                  className="w-full bg-[#20183f] border border-[#392e5c] rounded-xl px-2.5 py-1.5 text-white font-bold"
                >
                  <option value="Kahverengi">Kahverengi</option>
                  <option value="Mavi">Mavi</option>
                  <option value="Yeşil">Yeşil</option>
                  <option value="Ela">Ela</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-bold block">Kol Aksesuarı:</label>
                <select
                  value={avatarForm.sleeveLength}
                  onChange={(e) => setAvatarForm((a) => ({ ...a, sleeveLength: e.target.value as any }))}
                  className="w-full bg-[#20183f] border border-[#392e5c] rounded-xl px-2.5 py-1.5 text-white font-bold"
                >
                  <option value="Kısa Kol">Kısa Kol</option>
                  <option value="Uzun Kol">Uzun Kol Forma</option>
                  <option value="Kol Bandı">Kol Bandı & Bileklik</option>
                  <option value="Termal İçlik">Siyah Termal İçlik</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-bold block">Krampon Rengi:</label>
                <select
                  value={avatarForm.bootColor}
                  onChange={(e) => setAvatarForm((a) => ({ ...a, bootColor: e.target.value as any }))}
                  className="w-full bg-[#20183f] border border-[#392e5c] rounded-xl px-2.5 py-1.5 text-white font-bold"
                >
                  <option value="Neon Sarı">Neon Sarı 👟</option>
                  <option value="Kırmızı">Alev Kırmızı 👟</option>
                  <option value="Mavi">Elektrik Mavi 👟</option>
                  <option value="Siyah">Klasik Siyah 👟</option>
                  <option value="Beyaz">Saf Beyaz 👟</option>
                  <option value="Altın">Efsane Altın 👟</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2 border-t border-[#2e2352]">
              <button
                onClick={() => setIsEditingAvatar(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs"
              >
                İptal
              </button>
              <button
                onClick={handleSaveAvatar}
                className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs uppercase shadow flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" /> Değişiklikleri Kaydet
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CHAIRMAN DECISION LETTERHEAD MODAL */}
      {chairmanDecisionModal?.open && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-lg bg-[#1a1336] border-2 border-amber-500/50 rounded-3xl p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-[#312558] pb-3">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-amber-400" />
                <h3 className="text-xs font-black text-amber-300 tracking-wider uppercase">
                  {chairmanDecisionModal.title}
                </h3>
              </div>
              <button
                onClick={() => setChairmanDecisionModal(null)}
                className="text-slate-400 hover:text-white font-bold text-xs"
              >
                Kapat ✕
              </button>
            </div>

            <div className={`p-4 rounded-2xl border text-xs leading-relaxed whitespace-pre-line font-medium ${
              chairmanDecisionModal.approved
                ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-200'
                : 'bg-rose-500/10 border-rose-500/40 text-rose-200'
            }`}>
              {chairmanDecisionModal.message}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setChairmanDecisionModal(null)}
                className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase shadow active:scale-95 transition-all"
              >
                Anlaşıldı
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
