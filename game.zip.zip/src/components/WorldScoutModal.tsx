import React, { useState } from 'react';
import { Team, Player } from '../types';
import { X, Globe, ChevronRight, Shield, Search, ArrowLeft, Star, DollarSign, Award, Users, AlertCircle } from 'lucide-react';
import { TransferOfferModal } from './TransferOfferModal';
import { TeamBadge } from './TeamBadge';
import { SPANISH_TEAMS } from '../data/spanishTeams';
import { ENGLISH_TEAMS } from '../data/englishTeams';
import { BUNDESLIGA_TEAMS } from '../data/bundesligaTeams';
import { SERIE_A_TEAMS } from '../data/serieATeams';
import { LIGUE1_TEAMS } from '../data/ligue1Teams';
import { SUPER_LIG_TEAMS } from '../data/superLigTeams';
import { ADDITIONAL_EUROPEAN_TEAMS } from '../data/europeanTeams';
import { ensureTeamHas20Players } from '../utils/squadExpander';
import { useTranslation } from '../utils/i18n';

interface WorldScoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  allTeams: Team[];
  userTeam: Team;
  onSelectPlayerProfile: (player: Player, team?: Team) => void;
  onTransferPlayer: (player: Player, sellerTeam: Team, buyerTeamId: string, transferFee: number) => void;
  showToast: (type: 'success' | 'error' | 'info', title: string, message: string) => void;
}

export interface ExternalTeamData {
  id: string;
  name: string;
  country: string;
  flag: string;
  stadium: string;
  manager: string;
  overall: number;
  budget: number;
  badgeColor: string;
  logoUrl?: string;
  shortName: string;
  players: Player[];
}


const CONTINENTS = [
  { id: 'EU', name: 'Avrupa', icon: '🌍', desc: 'UEFA Şampiyonlar Ligi ve dünyanın en prestijli kulüpleri' },
  { id: 'SA', name: 'Güney Amerika', icon: '🌎', desc: 'Copa Libertadores, Samba tekniği ve Tango tutkusu' },
  { id: 'NA', name: 'Kuzey Amerika', icon: '🌎', desc: 'MLS yıldızları ve Liga MX tutkulu rekabeti' },
  { id: 'AS', name: 'Asya', icon: '🌏', desc: 'Suudi Pro Ligi dünya yıldızları ve J-League disiplini' },
  { id: 'AF', name: 'Afrika', icon: '🌍', desc: 'CAF Şampiyonlar Ligi, fiziksel güç ve genç yetenekler' },
  { id: 'OC', name: 'Okyanusya', icon: '🌏', desc: 'A-League ve Ada ülkeleri futbol sahnesi' },
  { id: 'AN', name: 'Antarktika', icon: '❄️', desc: 'Buzullar arası dostluk turnuvası ve Penguen Birliği' },
];

export const COUNTRY_TRANSLATIONS: Record<string, Record<string, string>> = {
  'Türkiye': { EN: 'Turkey', FR: 'Turquie', ES: 'Turquía', IT: 'Turchia', PT: 'Turquia', DE: 'Türkei' },
  'İspanya': { EN: 'Spain', FR: 'Espagne', ES: 'España', IT: 'Spagna', PT: 'Espanha', DE: 'Spanien' },
  'İngiltere': { EN: 'England', FR: 'Angleterre', ES: 'Inglaterra', IT: 'Inghilterra', PT: 'Inglaterra', DE: 'England' },
  'İtalya': { EN: 'Italy', FR: 'Italie', ES: 'Italia', IT: 'Italia', PT: 'Itália', DE: 'Italien' },
  'Almanya': { EN: 'Germany', FR: 'Allemagne', ES: 'Alemania', IT: 'Germania', PT: 'Alemanha', DE: 'Deutschland' },
  'Fransa': { EN: 'France', FR: 'France', ES: 'Francia', IT: 'Francia', PT: 'França', DE: 'Frankreich' },
  'Portekiz': { EN: 'Portugal', FR: 'Portugal', ES: 'Portugal', IT: 'Portogallo', PT: 'Portugal', DE: 'Portugal' },
  'Hollanda': { EN: 'Netherlands', FR: 'Pays-Bas', ES: 'Países Bajos', IT: 'Paesi Bassi', PT: 'Holanda', DE: 'Niederlande' },
  'Avusturya': { EN: 'Austria', FR: 'Autriche', ES: 'Austria', IT: 'Austria', PT: 'Áustria', DE: 'Österreich' },
  'Belçika': { EN: 'Belgium', FR: 'Belgique', ES: 'Bélgica', IT: 'Belgio', PT: 'Bélgica', DE: 'Belgien' },
  'İskoçya': { EN: 'Scotland', FR: 'Écosse', ES: 'Escocia', IT: 'Scozia', PT: 'Escócia', DE: 'Schottland' },
  'Yunanistan': { EN: 'Greece', FR: 'Grèce', ES: 'Grecia', IT: 'Grecia', PT: 'Grécia', DE: 'Griechenland' },
  'Danimarka': { EN: 'Denmark', FR: 'Danemark', ES: 'Dinamarca', IT: 'Danimarca', PT: 'Dinamarca', DE: 'Dänemark' },
  'İsveç': { EN: 'Sweden', FR: 'Suède', ES: 'Suecia', IT: 'Svezia', PT: 'Suécia', DE: 'Schweden' },
  'İsviçre': { EN: 'Switzerland', FR: 'Suisse', ES: 'Suiza', IT: 'Svizzera', PT: 'Suíça', DE: 'Schweiz' },
  'Romanya': { EN: 'Romania', FR: 'Roumanie', ES: 'Rumania', IT: 'Romania', PT: 'Romênia', DE: 'Rumänien' },
  'Çekya': { EN: 'Czech Republic', FR: 'Tchéquie', ES: 'Chequia', IT: 'Cechia', PT: 'Chéquia', DE: 'Tschechien' },
  'Polonya': { EN: 'Poland', FR: 'Pologne', ES: 'Polonia', IT: 'Polonia', PT: 'Polônia', DE: 'Polen' },
  'Hırvatistan': { EN: 'Croatia', FR: 'Croatie', ES: 'Croacia', IT: 'Croazia', PT: 'Croácia', DE: 'Kroatien' },
  'Sırbistan': { EN: 'Serbia', FR: 'Serbie', ES: 'Serbia', IT: 'Serbia', PT: 'Sérvia', DE: 'Serbien' },
  'Brezilya': { EN: 'Brazil', FR: 'Brésil', ES: 'Brasil', IT: 'Brasile', PT: 'Brasil', DE: 'Brasilien' },
  'Arjantin': { EN: 'Argentina', FR: 'Argentine', ES: 'Argentina', IT: 'Argentina', PT: 'Argentina', DE: 'Argentinien' },
  'Uruguay': { EN: 'Uruguay', FR: 'Uruguay', ES: 'Uruguay', IT: 'Uruguay', PT: 'Uruguai', DE: 'Uruguay' },
  'Kolombiya': { EN: 'Colombia', FR: 'Colombie', ES: 'Colombia', IT: 'Colombia', PT: 'Colômbia', DE: 'Kolumbien' },
  'Amerika B. D.': { EN: 'USA', FR: 'États-Unis', ES: 'Estados Unidos', IT: 'Stati Uniti', PT: 'Estados Unidos', DE: 'USA' },
  'Meksika': { EN: 'Mexico', FR: 'Mexique', ES: 'México', IT: 'Messico', PT: 'México', DE: 'Mexiko' },
  'Suudi Arabistan': { EN: 'Saudi Arabia', FR: 'Arabie Saoudite', ES: 'Arabia Saudita', IT: 'Arabia Saudita', PT: 'Arábia Saudita', DE: 'Saudi-Arabien' },
  'Japonya': { EN: 'Japan', FR: 'Japon', ES: 'Japón', IT: 'Giappone', PT: 'Japão', DE: 'Japan' },
  'Güney Kore': { EN: 'South Korea', FR: 'Corée du Sud', ES: 'Corea del Sur', IT: 'Corea del Sud', PT: 'Coreia do Sul', DE: 'Südkorea' },
  'Mısır': { EN: 'Egypt', FR: 'Égypte', ES: 'Egipto', IT: 'Egitto', PT: 'Egito', DE: 'Ägypten' },
  'Fas': { EN: 'Morocco', FR: 'Maroc', ES: 'Marruecos', IT: 'Marocco', PT: 'Marrocos', DE: 'Marokko' },
  'Nijerya': { EN: 'Nigeria', FR: 'Nigéria', ES: 'Nigeria', IT: 'Nigeria', PT: 'Nigéria', DE: 'Nigeria' },
  'Avustralya': { EN: 'Australia', FR: 'Australie', ES: 'Australia', IT: 'Australia', PT: 'Austrália', DE: 'Australien' },
  'Yeni Zelanda': { EN: 'New Zealand', FR: 'Nouvelle-Zélande', ES: 'Nueva Zelanda', IT: 'Nuova Zelanda', PT: 'Nova Zelândia', DE: 'Neuseeland' },
  'Antarktika Birliği': { EN: 'Antarctic Union', FR: 'Union Antarctique', ES: 'Unión Antártica', IT: 'Unione Antartica', PT: 'União Antártica', DE: 'Antarktis-Allianz' }
};

export const getLocalizedCountry = (name: string, lang: string): string => {
  if (lang === 'TR' || !lang) return name;
  return COUNTRY_TRANSLATIONS[name]?.[lang] || COUNTRY_TRANSLATIONS[name]?.['EN'] || name;
};

const COUNTRIES_BY_CONTINENT: Record<string, { code: string; name: string; flag: string }[]> = {
  EU: [
    { code: 'TR', name: 'Türkiye', flag: '🇹🇷' },
    { code: 'ES', name: 'İspanya', flag: '🇪🇸' },
    { code: 'EN', name: 'İngiltere', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿' },
    { code: 'IT', name: 'İtalya', flag: '🇮🇹' },
    { code: 'DE', name: 'Almanya', flag: '🇩🇪' },
    { code: 'FR', name: 'Fransa', flag: '🇫🇷' },
    { code: 'PT', name: 'Portekiz', flag: '🇵🇹' },
    { code: 'NL', name: 'Hollanda', flag: '🇳🇱' },
    { code: 'AT', name: 'Avusturya', flag: '🇦🇹' },
    { code: 'BE', name: 'Belçika', flag: '🇧🇪' },
    { code: 'SCO', name: 'İskoçya', flag: '🏴󠁧󠁢󠁳󠁣󠁴󠁿' },
    { code: 'GR', name: 'Yunanistan', flag: '🇬🇷' },
    { code: 'DK', name: 'Danimarka', flag: '🇩🇰' },
    { code: 'SE', name: 'İsveç', flag: '🇸🇪' },
    { code: 'CH', name: 'İsviçre', flag: '🇨🇭' },
    { code: 'RO', name: 'Romanya', flag: '🇷🇴' },
    { code: 'CZ', name: 'Çekya', flag: '🇨🇿' },
    { code: 'PL', name: 'Polonya', flag: '🇵🇱' },
    { code: 'HR', name: 'Hırvatistan', flag: '🇭🇷' },
    { code: 'RS', name: 'Sırbistan', flag: '🇷🇸' },
  ],
  SA: [
    { code: 'BR', name: 'Brezilya', flag: '🇧🇷' },
    { code: 'AR', name: 'Arjantin', flag: '🇦🇷' },
    { code: 'UY', name: 'Uruguay', flag: '🇺🇾' },
    { code: 'CO', name: 'Kolombiya', flag: '🇨🇴' },
  ],
  NA: [
    { code: 'US', name: 'Amerika B. D.', flag: '🇺🇸' },
    { code: 'MX', name: 'Meksika', flag: '🇲🇽' },
  ],
  AS: [
    { code: 'SAU', name: 'Suudi Arabistan', flag: '🇸🇦' },
    { code: 'JP', name: 'Japonya', flag: '🇯🇵' },
    { code: 'KR', name: 'Güney Kore', flag: '🇰🇷' },
  ],
  AF: [
    { code: 'EG', name: 'Mısır', flag: '🇪🇬' },
    { code: 'MA', name: 'Fas', flag: '🇲🇦' },
    { code: 'NG', name: 'Nijerya', flag: '🇳🇬' },
  ],
  OC: [
    { code: 'AU', name: 'Avustralya', flag: '🇦🇺' },
    { code: 'NZ', name: 'Yeni Zelanda', flag: '🇳🇿' },
  ],
  AN: [
    { code: 'AQ', name: 'Antarktika Birliği', flag: '🇦🇶' },
  ]
};

// Raw dataset of International Teams
const RAW_INTERNATIONAL_TEAMS: ExternalTeamData[] = [
  ...SPANISH_TEAMS,
  ...ENGLISH_TEAMS,
  ...BUNDESLIGA_TEAMS,
  ...SERIE_A_TEAMS,
  ...LIGUE1_TEAMS,
  ...ADDITIONAL_EUROPEAN_TEAMS,
  // GÜNEY AMERİKA - ARJANTİN & BREZİLYA & URUGUAY
  {
    id: 'flamengo',
    name: 'CR Flamengo',
    country: 'Brezilya',
    flag: '🇧🇷',
    stadium: 'Maracanã',
    manager: 'Tite',
    overall: 81,
    budget: 40000000,
    badgeColor: 'from-red-700 to-black',
    shortName: 'FLA',
    players: [
      { id: 'fla-1', name: 'Agustín Rossi', age: 28, position: 'GK', specificRole: 'GK', overall: 80, stamina: 88, form: 7.9, marketValue: 7000000, wage: 16667, nationality: 'Arjantin', attributes: { pace: 48, shooting: 15, passing: 70, defending: 81, physical: 78 }, isStarting: true },
      { id: 'fla-2', name: 'Gerson', age: 27, position: 'MID', specificRole: 'CM', overall: 82, stamina: 91, form: 8.2, marketValue: 18000000, wage: 26667, nationality: 'Brezilya', attributes: { pace: 76, shooting: 74, passing: 83, defending: 76, physical: 82 }, isStarting: true },
      { id: 'fla-3', name: 'Pedro Guilherme', age: 27, position: 'FW', specificRole: 'ST', overall: 82, stamina: 89, form: 8.4, marketValue: 22000000, wage: 30000, nationality: 'Brezilya', attributes: { pace: 74, shooting: 84, passing: 70, defending: 38, physical: 85 }, isStarting: true },
      { id: 'fla-4', name: 'Giorgian de Arrascaeta', age: 30, position: 'MID', specificRole: 'CAM', overall: 83, stamina: 87, form: 8.5, marketValue: 15000000, wage: 20000, nationality: 'Uruguay', attributes: { pace: 78, shooting: 80, passing: 86, defending: 48, physical: 72 }, isStarting: true }
    ]
  },
  {
    id: 'palmeiras',
    name: 'SE Palmeiras',
    country: 'Brezilya',
    flag: '🇧🇷',
    stadium: 'Allianz Parque',
    manager: 'Abel Ferreira',
    overall: 81,
    budget: 38000000,
    badgeColor: 'from-emerald-700 to-green-900',
    shortName: 'PAL',
    players: [
      { id: 'pal-1', name: 'Weverton', age: 36, position: 'GK', specificRole: 'GK', overall: 80, stamina: 86, form: 7.9, marketValue: 3000000, wage: 45000, nationality: 'Brezilya', attributes: { pace: 48, shooting: 15, passing: 68, defending: 81, physical: 78 }, isStarting: true },
      { id: 'pal-2', name: 'Raphael Veiga', age: 29, position: 'MID', specificRole: 'CAM', overall: 81, stamina: 90, form: 8.3, marketValue: 16000000, wage: 25000, nationality: 'Brezilya', attributes: { pace: 76, shooting: 82, passing: 83, defending: 55, physical: 74 }, isStarting: true },
      { id: 'pal-3', name: 'Estêvão (Willian)', age: 17, position: 'FW', specificRole: 'RW', overall: 78, stamina: 92, form: 8.6, marketValue: 40000000, wage: 30000, nationality: 'Brezilya', attributes: { pace: 89, shooting: 78, passing: 81, defending: 40, physical: 65 }, isStarting: true }
    ]
  },
  {
    id: 'river-plate',
    name: 'CA River Plate',
    country: 'Arjantin',
    flag: '🇦🇷',
    stadium: 'Mônumental de Núñez',
    manager: 'Marcelo Gallardo',
    overall: 80,
    budget: 30000000,
    badgeColor: 'from-red-600 to-white',
    shortName: 'RIV',
    players: [
      { id: 'riv-1', name: 'Franco Armani', age: 37, position: 'GK', specificRole: 'GK', overall: 79, stamina: 84, form: 7.8, marketValue: 1500000, wage: 40000, nationality: 'Arjantin', attributes: { pace: 45, shooting: 15, passing: 65, defending: 80, physical: 76 }, isStarting: true },
      { id: 'riv-2', name: 'Claudio Echeverri', age: 18, position: 'MID', specificRole: 'CAM', overall: 77, stamina: 90, form: 8.3, marketValue: 20000000, wage: 25000, nationality: 'Arjantin', attributes: { pace: 84, shooting: 75, passing: 80, defending: 42, physical: 62 }, isStarting: true },
      { id: 'riv-3', name: 'Borja', age: 31, position: 'FW', specificRole: 'ST', overall: 79, stamina: 86, form: 8.2, marketValue: 5000000, wage: 16667, nationality: 'Kolombiya', attributes: { pace: 75, shooting: 82, passing: 64, defending: 38, physical: 85 }, isStarting: true }
    ]
  },
  {
    id: 'boca-juniors',
    name: 'CA Boca Juniors',
    country: 'Arjantin',
    flag: '🇦🇷',
    stadium: 'La Bombonera',
    manager: 'Fernando Gago',
    overall: 79,
    budget: 25000000,
    badgeColor: 'from-blue-700 to-yellow-400',
    shortName: 'BOC',
    players: [
      { id: 'bj-1', name: 'Sergio Romero', age: 37, position: 'GK', specificRole: 'GK', overall: 78, stamina: 82, form: 7.7, marketValue: 1000000, wage: 35000, nationality: 'Arjantin', attributes: { pace: 45, shooting: 15, passing: 65, defending: 79, physical: 75 }, isStarting: true },
      { id: 'bj-2', name: 'Edinson Cavani', age: 37, position: 'FW', specificRole: 'ST', overall: 80, stamina: 82, form: 8.1, marketValue: 2000000, wage: 20000, nationality: 'Uruguay', attributes: { pace: 70, shooting: 84, passing: 72, defending: 45, physical: 80 }, isStarting: true },
      { id: 'bj-3', name: 'Kevin Zenón', age: 23, position: 'MID', specificRole: 'LM', overall: 77, stamina: 90, form: 8.0, marketValue: 10000000, wage: 30000, nationality: 'Arjantin', attributes: { pace: 82, shooting: 75, passing: 78, defending: 62, physical: 74 }, isStarting: true }
    ]
  },
  // KUZEY AMERİKA - MLS & LIGA MX
  {
    id: 'inter-miami',
    name: 'Inter Miami CF',
    country: 'Amerika B. D.',
    flag: '🇺🇸',
    stadium: 'Chase Stadium',
    manager: 'Gerardo Martino',
    overall: 81,
    budget: 50000000,
    badgeColor: 'from-pink-500 to-black',
    shortName: 'MIA',
    players: [
      { id: 'mia-1', name: 'Drake Callender', age: 26, position: 'GK', specificRole: 'GK', overall: 76, stamina: 88, form: 7.6, marketValue: 3000000, wage: 25000, nationality: 'ABD', attributes: { pace: 48, shooting: 15, passing: 68, defending: 77, physical: 76 }, isStarting: true },
      { id: 'mia-2', name: 'Jordi Alba', age: 35, position: 'DEF', specificRole: 'LB', overall: 81, stamina: 82, form: 8.1, marketValue: 2500000, wage: 26667, nationality: 'İspanya', attributes: { pace: 80, shooting: 68, passing: 83, defending: 76, physical: 68 }, isStarting: true },
      { id: 'mia-3', name: 'Sergio Busquets', age: 36, position: 'MID', specificRole: 'CDM', overall: 81, stamina: 80, form: 8.2, marketValue: 2500000, wage: 30000, nationality: 'İspanya', attributes: { pace: 50, shooting: 62, passing: 88, defending: 81, physical: 74 }, isStarting: true },
      { id: 'mia-4', name: 'Lionel Messi', age: 37, position: 'FW', specificRole: 'RW', overall: 88, stamina: 80, form: 9.0, marketValue: 30000000, wage: 50000, nationality: 'Arjantin', attributes: { pace: 78, shooting: 90, passing: 93, defending: 32, physical: 64 }, isStarting: true },
      { id: 'mia-5', name: 'Luis Suárez', age: 37, position: 'FW', specificRole: 'ST', overall: 82, stamina: 80, form: 8.4, marketValue: 3000000, wage: 20000, nationality: 'Uruguay', attributes: { pace: 68, shooting: 88, passing: 78, defending: 38, physical: 78 }, isStarting: true }
    ]
  },
  {
    id: 'club-america',
    name: 'Club América',
    country: 'Meksika',
    flag: '🇲🇽',
    stadium: 'Estadio Azteca',
    manager: 'André Jardine',
    overall: 79,
    budget: 30000000,
    badgeColor: 'from-amber-300 to-blue-800',
    shortName: 'AME',
    players: [
      { id: 'ame-1', name: 'Luis Malagón', age: 27, position: 'GK', specificRole: 'GK', overall: 79, stamina: 88, form: 8.0, marketValue: 6000000, wage: 30000, nationality: 'Meksika', attributes: { pace: 48, shooting: 15, passing: 68, defending: 80, physical: 76 }, isStarting: true },
      { id: 'ame-2', name: 'Henry Martín', age: 31, position: 'FW', specificRole: 'ST', overall: 79, stamina: 87, form: 8.2, marketValue: 5000000, wage: 45000, nationality: 'Meksika', attributes: { pace: 76, shooting: 81, passing: 72, defending: 40, physical: 82 }, isStarting: true }
    ]
  },
  // ASYA - SUUDİ ARABİSTAN, JAPONYA, GÜNEY KORE
  {
    id: 'al-hilal',
    name: 'Al-Hilal SFC',
    country: 'Suudi Arabistan',
    flag: '🇸🇦',
    stadium: 'Kingdom Arena',
    manager: 'Jorge Jesus',
    overall: 84,
    budget: 140000000,
    badgeColor: 'from-blue-700 to-sky-500',
    shortName: 'HIL',
    players: [
      { id: 'hil-1', name: 'Yassine Bounou', age: 33, position: 'GK', specificRole: 'GK', overall: 85, stamina: 90, form: 8.3, marketValue: 15000000, wage: 36000, nationality: 'Fas', attributes: { pace: 48, shooting: 15, passing: 75, defending: 86, physical: 80 }, isStarting: true },
      { id: 'hil-2', name: 'Kalidou Koulibaly', age: 33, position: 'DEF', specificRole: 'CB', overall: 83, stamina: 86, form: 8.0, marketValue: 10000000, wage: 35714, nationality: 'Senegal', attributes: { pace: 72, shooting: 40, passing: 68, defending: 84, physical: 87 }, isStarting: true },
      { id: 'hil-3', name: 'Rúben Neves', age: 27, position: 'MID', specificRole: 'CDM', overall: 84, stamina: 91, form: 8.2, marketValue: 32000000, wage: 40000, nationality: 'Portekiz', attributes: { pace: 68, shooting: 80, passing: 88, defending: 79, physical: 80 }, isStarting: true },
      { id: 'hil-4', name: 'Sergej Milinković-Savić', age: 29, position: 'MID', specificRole: 'CM', overall: 85, stamina: 92, form: 8.4, marketValue: 30000000, wage: 42857, nationality: 'Sırbistan', attributes: { pace: 70, shooting: 82, passing: 85, defending: 78, physical: 88 }, isStarting: true },
      { id: 'hil-5', name: 'Aleksandar Mitrović', age: 29, position: 'FW', specificRole: 'ST', overall: 84, stamina: 90, form: 8.6, marketValue: 28000000, wage: 45714, nationality: 'Sırbistan', attributes: { pace: 74, shooting: 86, passing: 68, defending: 38, physical: 90 }, isStarting: true },
      { id: 'hil-6', name: 'Neymar Jr', age: 32, position: 'FW', specificRole: 'LW', overall: 88, stamina: 80, form: 8.5, marketValue: 30000000, wage: 80000, nationality: 'Brezilya', attributes: { pace: 85, shooting: 84, passing: 89, defending: 35, physical: 65 }, isStarting: true }
    ]
  },
  {
    id: 'al-nassr',
    name: 'Al-Nassr FC',
    country: 'Suudi Arabistan',
    flag: '🇸🇦',
    stadium: 'Al-Awwal Park',
    manager: 'Stefano Pioli',
    overall: 83,
    budget: 120000000,
    badgeColor: 'from-yellow-400 to-blue-700',
    shortName: 'NAS',
    players: [
      { id: 'nas-1', name: 'Bento', age: 25, position: 'GK', specificRole: 'GK', overall: 81, stamina: 88, form: 8.0, marketValue: 15000000, wage: 30000, nationality: 'Brezilya', attributes: { pace: 50, shooting: 15, passing: 72, defending: 82, physical: 78 }, isStarting: true },
      { id: 'nas-2', name: 'Aymeric Laporte', age: 30, position: 'DEF', specificRole: 'CB', overall: 83, stamina: 87, form: 8.1, marketValue: 20000000, wage: 35714, nationality: 'İspanya', attributes: { pace: 72, shooting: 45, passing: 78, defending: 84, physical: 82 }, isStarting: true },
      { id: 'nas-3', name: 'Marcelo Brozović', age: 31, position: 'MID', specificRole: 'CDM', overall: 83, stamina: 95, form: 8.3, marketValue: 18000000, wage: 31429, nationality: 'Hırvatistan', attributes: { pace: 74, shooting: 74, passing: 86, defending: 82, physical: 82 }, isStarting: true },
      { id: 'nas-4', name: 'Sadio Mané', age: 32, position: 'FW', specificRole: 'LW', overall: 84, stamina: 88, form: 8.3, marketValue: 20000000, wage: 50000, nationality: 'Senegal', attributes: { pace: 88, shooting: 83, passing: 78, defending: 42, physical: 76 }, isStarting: true },
      { id: 'nas-5', name: 'Cristiano Ronaldo', age: 39, position: 'FW', specificRole: 'ST', overall: 87, stamina: 88, form: 8.9, marketValue: 15000000, wage: 80000, nationality: 'Portekiz', attributes: { pace: 78, shooting: 91, passing: 76, defending: 35, physical: 80 }, isStarting: true },
      { id: 'nas-6', name: 'Otávio', age: 29, position: 'MID', specificRole: 'CAM', overall: 82, stamina: 90, form: 8.1, marketValue: 22000000, wage: 36000, nationality: 'Portekiz', attributes: { pace: 80, shooting: 76, passing: 83, defending: 68, physical: 75 }, isStarting: true }
    ]
  },
  {
    id: 'al-ittihad',
    name: 'Al-Ittihad Club',
    country: 'Suudi Arabistan',
    flag: '🇸🇦',
    stadium: 'King Abdullah Sports City',
    manager: 'Laurent Blanc',
    overall: 83,
    budget: 110000000,
    badgeColor: 'from-amber-400 to-slate-900',
    shortName: 'ITT',
    players: [
      { id: 'itt-1', name: 'Predrag Rajković', age: 28, position: 'GK', specificRole: 'GK', overall: 80, stamina: 88, form: 8.0, marketValue: 10000000, wage: 26667, nationality: 'Sırbistan', attributes: { pace: 48, shooting: 15, passing: 70, defending: 80, physical: 78 }, isStarting: true },
      { id: 'itt-2', name: 'N\'Golo Kanté', age: 33, position: 'MID', specificRole: 'CDM', overall: 84, stamina: 96, form: 8.5, marketValue: 15000000, wage: 42857, nationality: 'Fransa', attributes: { pace: 76, shooting: 66, passing: 78, defending: 86, physical: 84 }, isStarting: true },
      { id: 'itt-3', name: 'Fabinho', age: 30, position: 'MID', specificRole: 'CDM', overall: 82, stamina: 88, form: 8.0, marketValue: 22000000, wage: 28571, nationality: 'Brezilya', attributes: { pace: 65, shooting: 68, passing: 79, defending: 83, physical: 82 }, isStarting: true },
      { id: 'itt-4', name: 'Moussa Diaby', age: 25, position: 'FW', specificRole: 'RW', overall: 82, stamina: 90, form: 8.2, marketValue: 40000000, wage: 31429, nationality: 'Fransa', attributes: { pace: 93, shooting: 78, passing: 75, defending: 38, physical: 68 }, isStarting: true },
      { id: 'itt-5', name: 'Karim Benzema', age: 36, position: 'FW', specificRole: 'ST', overall: 86, stamina: 84, form: 8.6, marketValue: 12000000, wage: 60000, nationality: 'Fransa', attributes: { pace: 74, shooting: 88, passing: 83, defending: 38, physical: 78 }, isStarting: true }
    ]
  },
  {
    id: 'vissel-kobe',
    name: 'Vissel Kobe',
    country: 'Japonya',
    flag: '🇯🇵',
    stadium: 'Noevir Stadium Kobe',
    manager: 'Takayuki Yoshida',
    overall: 76,
    budget: 18000000,
    badgeColor: 'from-red-800 to-black',
    shortName: 'KOB',
    players: [
      { id: 'kob-1', name: 'Yuya Osako', age: 34, position: 'FW', specificRole: 'ST', overall: 76, stamina: 84, form: 8.0, marketValue: 2000000, wage: 30000, nationality: 'Japonya', attributes: { pace: 70, shooting: 78, passing: 72, defending: 38, physical: 76 }, isStarting: true },
      { id: 'kob-2', name: 'Yoshinori Muto', age: 32, position: 'FW', specificRole: 'RW', overall: 75, stamina: 86, form: 7.9, marketValue: 1800000, wage: 25000, nationality: 'Japonya', attributes: { pace: 78, shooting: 74, passing: 70, defending: 42, physical: 74 }, isStarting: true }
    ]
  },
  // AFRİKA - MISIR, FAS, NİJERYA
  {
    id: 'al-ahly',
    name: 'Al Ahly SC',
    country: 'Mısır',
    flag: '🇪🇬',
    stadium: 'Cairo International Stadium',
    manager: 'Marcel Koller',
    overall: 78,
    budget: 20000000,
    badgeColor: 'from-red-600 to-amber-400',
    shortName: 'AHL',
    players: [
      { id: 'ahl-1', name: 'Mohamed El Shenawy', age: 35, position: 'GK', specificRole: 'GK', overall: 78, stamina: 85, form: 8.0, marketValue: 2500000, wage: 25000, nationality: 'Mısır', attributes: { pace: 45, shooting: 15, passing: 65, defending: 79, physical: 78 }, isStarting: true },
      { id: 'ahl-2', name: 'Emam Ashour', age: 26, position: 'MID', specificRole: 'CM', overall: 77, stamina: 90, form: 8.2, marketValue: 4000000, wage: 20000, nationality: 'Mısır', attributes: { pace: 78, shooting: 75, passing: 77, defending: 70, physical: 78 }, isStarting: true },
      { id: 'ahl-3', name: 'Wessam Abou Ali', age: 25, position: 'FW', specificRole: 'ST', overall: 76, stamina: 88, form: 8.1, marketValue: 3500000, wage: 18000, nationality: 'Filistin', attributes: { pace: 80, shooting: 78, passing: 65, defending: 36, physical: 78 }, isStarting: true }
    ]
  },
  {
    id: 'raja-casablanca',
    name: 'Raja CA Casablanca',
    country: 'Fas',
    flag: '🇲🇦',
    stadium: 'Stade Mohammed V',
    manager: 'Rusmir Cviko',
    overall: 76,
    budget: 12000000,
    badgeColor: 'from-emerald-700 to-green-900',
    shortName: 'RAJ',
    players: [
      { id: 'raj-1', name: 'Anas Znouti', age: 35, position: 'GK', specificRole: 'GK', overall: 76, stamina: 84, form: 7.8, marketValue: 1200000, wage: 15000, nationality: 'Fas', attributes: { pace: 45, shooting: 15, passing: 64, defending: 77, physical: 75 }, isStarting: true }
    ]
  },
  // OKYANUSYA - AVUSTRALYA & YENİ ZELANDA
  {
    id: 'sydney-fc',
    name: 'Sydney FC',
    country: 'Avustralya',
    flag: '🇦🇺',
    stadium: 'Allianz Stadium Sydney',
    manager: 'Ufuk Talay',
    overall: 74,
    budget: 10000000,
    badgeColor: 'from-sky-500 to-blue-900',
    shortName: 'SYD',
    players: [
      { id: 'syd-1', name: 'Douglas Costa', age: 33, position: 'FW', specificRole: 'RW', overall: 76, stamina: 80, form: 7.9, marketValue: 1500000, wage: 25000, nationality: 'Brezilya', attributes: { pace: 82, shooting: 75, passing: 78, defending: 35, physical: 65 }, isStarting: true },
      { id: 'syd-2', name: 'Joe Lolley', age: 31, position: 'FW', specificRole: 'LW', overall: 74, stamina: 85, form: 7.8, marketValue: 1000000, wage: 18000, nationality: 'İngiltere', attributes: { pace: 78, shooting: 74, passing: 72, defending: 40, physical: 72 }, isStarting: true }
    ]
  },
  // ANTARKTİKA - PENGUEN BİRLİĞİ
  {
    id: 'antarctica-penguins',
    name: 'Antarktika Penguen FC',
    country: 'Antarktika Birliği',
    flag: '🇦🇶',
    stadium: 'Buzul Arena',
    manager: 'Kutup Ayısı Hans',
    overall: 75,
    budget: 5000000,
    badgeColor: 'from-cyan-400 to-blue-950',
    shortName: 'PNG',
    players: [
      { id: 'png-1', name: 'Frosty Glacier', age: 24, position: 'FW', specificRole: 'ST', overall: 76, stamina: 99, form: 8.5, marketValue: 3000000, wage: 10000, nationality: 'Antarktika', attributes: { pace: 90, shooting: 76, passing: 70, defending: 40, physical: 90 }, isStarting: true },
      { id: 'png-2', name: 'Icy McSlide', age: 22, position: 'MID', specificRole: 'CM', overall: 75, stamina: 98, form: 8.2, marketValue: 2500000, wage: 8000, nationality: 'Antarktika', attributes: { pace: 85, shooting: 70, passing: 80, defending: 75, physical: 85 }, isStarting: true }
    ]
  },

  // EXTRA AMERICAS & ASIA
  {
    id: 'la-galaxy',
    name: 'LA Galaxy',
    country: 'Amerika B. D.',
    flag: '🇺🇸',
    stadium: 'Dignity Health Sports Park',
    manager: 'Greg Vanney',
    overall: 78,
    budget: 30000000,
    badgeColor: 'from-blue-900 to-amber-400',
    shortName: 'LAG',
    players: [
      { id: 'lag-1', name: 'Riqui Puig', age: 25, position: 'MID', specificRole: 'CAM', overall: 80, stamina: 90, form: 8.5, marketValue: 20000000, wage: 25000, nationality: 'İspanya', attributes: { pace: 78, shooting: 75, passing: 85, defending: 50, physical: 65 }, isStarting: true },
      { id: 'lag-2', name: 'Gabriel Pec', age: 23, position: 'FW', specificRole: 'RW', overall: 78, stamina: 88, form: 8.3, marketValue: 15000000, wage: 18000, nationality: 'Brezilya', attributes: { pace: 86, shooting: 76, passing: 75, defending: 38, physical: 70 }, isStarting: true }
    ]
  },
  {
    id: 'tigres-uanl',
    name: 'Tigres UANL',
    country: 'Meksika',
    flag: '🇲🇽',
    stadium: 'Estadio Universitario',
    manager: 'Veljko Paunović',
    overall: 78,
    budget: 25000000,
    badgeColor: 'from-amber-400 to-blue-800',
    shortName: 'TIG',
    players: [
      { id: 'tig-1', name: 'Nahuel Guzmán', age: 38, position: 'GK', specificRole: 'GK', overall: 77, stamina: 82, form: 7.8, marketValue: 1000000, wage: 20000, nationality: 'Arjantin', attributes: { pace: 45, shooting: 15, passing: 68, defending: 78, physical: 76 }, isStarting: true },
      { id: 'tig-2', name: 'André-Pierre Gignac', age: 38, position: 'FW', specificRole: 'ST', overall: 78, stamina: 80, form: 8.1, marketValue: 1500000, wage: 30000, nationality: 'Fransa', attributes: { pace: 68, shooting: 84, passing: 72, defending: 35, physical: 82 }, isStarting: true }
    ]
  },
  {
    id: 'al-ahli-saudi',
    name: 'Al-Ahli SFC',
    country: 'Suudi Arabistan',
    flag: '🇸🇦',
    stadium: 'King Abdullah Sports City',
    manager: 'Matthias Jaissle',
    overall: 83,
    budget: 100000000,
    badgeColor: 'from-emerald-600 to-white',
    shortName: 'AHL',
    players: [
      { id: 'ahs-1', name: 'Édouard Mendy', age: 32, position: 'GK', specificRole: 'GK', overall: 82, stamina: 86, form: 8.1, marketValue: 12000000, wage: 30000, nationality: 'Senegal', attributes: { pace: 50, shooting: 15, passing: 70, defending: 82, physical: 80 }, isStarting: true },
      { id: 'ahs-2', name: 'Riyad Mahrez', age: 33, position: 'FW', specificRole: 'RW', overall: 84, stamina: 85, form: 8.4, marketValue: 18000000, wage: 50000, nationality: 'Cezayir', attributes: { pace: 80, shooting: 82, passing: 86, defending: 38, physical: 65 }, isStarting: true },
      { id: 'ahs-3', name: 'Roberto Firmino', age: 32, position: 'FW', specificRole: 'ST', overall: 81, stamina: 85, form: 8.0, marketValue: 12000000, wage: 35000, nationality: 'Brezilya', attributes: { pace: 74, shooting: 80, passing: 82, defending: 55, physical: 76 }, isStarting: true },
      { id: 'ahs-4', name: 'Franck Kessié', age: 27, position: 'MID', specificRole: 'CM', overall: 82, stamina: 92, form: 8.3, marketValue: 20000000, wage: 32000, nationality: 'Fildişi Sahili', attributes: { pace: 76, shooting: 74, passing: 78, defending: 82, physical: 86 }, isStarting: true },
      { id: 'ahs-5', name: 'Ivan Toney', age: 28, position: 'FW', specificRole: 'ST', overall: 83, stamina: 90, form: 8.5, marketValue: 45000000, wage: 40000, nationality: 'İngiltere', attributes: { pace: 82, shooting: 85, passing: 74, defending: 42, physical: 84 }, isStarting: true }
    ]
  },
  {
    id: 'kawasaki-frontale',
    name: 'Kawasaki Frontale',
    country: 'Japonya',
    flag: '🇯🇵',
    stadium: 'Todoroki Athletics Stadium',
    manager: 'Toru Oniki',
    overall: 75,
    budget: 15000000,
    badgeColor: 'from-sky-500 to-black',
    shortName: 'KAW',
    players: [
      { id: 'kaw-1', name: 'Akihiro Ienaga', age: 38, position: 'FW', specificRole: 'RW', overall: 75, stamina: 82, form: 7.8, marketValue: 1000000, wage: 15000, nationality: 'Japonya', attributes: { pace: 68, shooting: 74, passing: 78, defending: 45, physical: 72 }, isStarting: true }
    ]
  },
  {
    id: 'ulsan-hd',
    name: 'Ulsan HD FC',
    country: 'Güney Kore',
    flag: '🇰🇷',
    stadium: 'Ulsan Munsu Football Stadium',
    manager: 'Kim Pan-gon',
    overall: 75,
    budget: 15000000,
    badgeColor: 'from-blue-700 to-amber-400',
    shortName: 'ULS',
    players: [
      { id: 'uls-1', name: 'Jo Hyeon-woo', age: 32, position: 'GK', specificRole: 'GK', overall: 77, stamina: 86, form: 8.1, marketValue: 1800000, wage: 18000, nationality: 'Güney Kore', attributes: { pace: 50, shooting: 15, passing: 68, defending: 78, physical: 76 }, isStarting: true },
      { id: 'uls-2', name: 'Joo Min-kyu', age: 34, position: 'FW', specificRole: 'ST', overall: 75, stamina: 82, form: 7.9, marketValue: 1200000, wage: 15000, nationality: 'Güney Kore', attributes: { pace: 68, shooting: 76, passing: 68, defending: 35, physical: 80 }, isStarting: true }
    ]
  },
  {
    id: 'zamalek',
    name: 'Zamalek SC',
    country: 'Mısır',
    flag: '🇪🇬',
    stadium: 'Cairo International Stadium',
    manager: 'José Gomes',
    overall: 76,
    budget: 15000000,
    badgeColor: 'from-red-600 to-white',
    shortName: 'ZAM',
    players: [
      { id: 'zam-1', name: 'Ahmed Sayed Zizo', age: 28, position: 'FW', specificRole: 'RW', overall: 78, stamina: 90, form: 8.3, marketValue: 5000000, wage: 25000, nationality: 'Mısır', attributes: { pace: 84, shooting: 78, passing: 80, defending: 48, physical: 74 }, isStarting: true }
    ]
  },
  {
    id: 'wydad-ac',
    name: 'Wydad AC Casablanca',
    country: 'Fas',
    flag: '🇲🇦',
    stadium: 'Stade Mohammed V',
    manager: 'Rulani Mokwena',
    overall: 75,
    budget: 12000000,
    badgeColor: 'from-red-700 to-white',
    shortName: 'WYD',
    players: [
      { id: 'wyd-1', name: 'Youssef Mouti', age: 27, position: 'GK', specificRole: 'GK', overall: 75, stamina: 85, form: 7.8, marketValue: 1200000, wage: 12000, nationality: 'Fas', attributes: { pace: 45, shooting: 15, passing: 62, defending: 76, physical: 75 }, isStarting: true }
    ]
  },
  {
    id: 'enyimba',
    name: 'Enyimba International FC',
    country: 'Nijerya',
    flag: '🇳🇬',
    stadium: 'Enyimba International Stadium',
    manager: 'Yemi Olanrewaju',
    overall: 73,
    budget: 8000000,
    badgeColor: 'from-blue-600 to-white',
    shortName: 'ENY',
    players: [
      { id: 'eny-1', name: 'Chijioke Mbaoma', age: 22, position: 'FW', specificRole: 'ST', overall: 74, stamina: 88, form: 8.0, marketValue: 1500000, wage: 8000, nationality: 'Nijerya', attributes: { pace: 82, shooting: 74, passing: 62, defending: 35, physical: 80 }, isStarting: true }
    ]
  },
  {
    id: 'melbourne-city',
    name: 'Melbourne City FC',
    country: 'Avustralya',
    flag: '🇦🇺',
    stadium: 'AAMI Park',
    manager: 'Aurelio Vidmar',
    overall: 74,
    budget: 10000000,
    badgeColor: 'from-sky-400 to-white',
    shortName: 'MCY',
    players: [
      { id: 'mcy-1', name: 'Jamie Maclaren', age: 31, position: 'FW', specificRole: 'ST', overall: 75, stamina: 85, form: 7.9, marketValue: 1500000, wage: 18000, nationality: 'Avustralya', attributes: { pace: 76, shooting: 78, passing: 68, defending: 35, physical: 74 }, isStarting: true }
    ]
  },
  {
    id: 'auckland-city',
    name: 'Auckland City FC',
    country: 'Yeni Zelanda',
    flag: '🇳🇿',
    stadium: 'Kiwitea Street',
    manager: 'Albert Riera',
    overall: 72,
    budget: 5000000,
    badgeColor: 'from-blue-700 to-yellow-400',
    shortName: 'ACK',
    players: [
      { id: 'ack-1', name: 'Ryan De Vries', age: 32, position: 'FW', specificRole: 'ST', overall: 73, stamina: 82, form: 7.7, marketValue: 800000, wage: 6000, nationality: 'Yeni Zelanda', attributes: { pace: 72, shooting: 73, passing: 65, defending: 35, physical: 72 }, isStarting: true }
    ]
  }
];

// Deduplicate teams by ID and ensure every team has AT LEAST 20 players
const teamMap = new Map<string, ExternalTeamData>();
RAW_INTERNATIONAL_TEAMS.forEach(team => {
  if (!teamMap.has(team.id)) {
    teamMap.set(team.id, ensureTeamHas20Players(team));
  }
});

export const INTERNATIONAL_TEAMS: ExternalTeamData[] = Array.from(teamMap.values());

const GENERIC_EUROPEAN_CLUBS: Record<string, string[]> = {
  'Avusturya': ['SK Rapid Wien', 'FK Austria Wien', 'FC Red Bull Salzburg', 'SK Sturm Graz', 'LASK Linz', 'Wolfsberger AC', 'TSV Hartberg', 'Austria Klagenfurt', 'SCR Altach', 'WSG Tirol', 'Grazer AK', 'FC Blau-Weiß Linz', 'SV Ried', 'Admira Wacker', 'First Vienna FC'],
  'Belçika': ['Club Brugge KV', 'RSC Anderlecht', 'KAA Gent', 'KRC Genk', 'Royal Antwerp FC', 'Standard Liège', 'Royale Union SG', 'Cercle Brugge KSV', 'KV Mechelen', 'KVC Westerlo', 'OH Leuven', 'STVV', 'Sporting Charleroi', 'KV Kortrijk', 'KAS Eupen'],
  'İskoçya': ['Celtic FC', 'Rangers FC', 'Aberdeen FC', 'Heart of Midlothian FC', 'Hibernian FC', 'Dundee United FC', 'Motherwell FC', 'Kilmarnock FC', 'St Mirren FC', 'St Johnstone FC', 'Dundee FC', 'Ross County FC', 'Livingston FC', 'Ayr United FC', 'Partick Thistle FC'],
  'Yunanistan': ['Olympiacos FC', 'Panathinaikos FC', 'AEK Athens FC', 'PAOK FC', 'Aris Thessaloniki FC', 'Atromitos FC', 'OFI Crete FC', 'Asteras Tripolis FC', 'Panetolikos FC', 'PAS Giannina FC', 'Volos NPS', 'Lamia FC', 'Panserraikos FC', 'Kifisia FC', 'Iraklis FC'],
  'Danimarka': ['FC Copenhagen', 'Brøndby IF', 'FC Midtjylland', 'FC Nordsjælland', 'Aarhus GF', 'Aalborg BK', 'Odense BK', 'Silkeborg IF', 'Randers FC', 'Viborg FF', 'Lyngby BK', 'Vejle BK', 'Sønderjyske', 'AC Horsens', 'Hvidovre IF'],
  'İsveç': ['Malmö FF', 'AIK Fotboll', 'Djurgårdens IF', 'Hammarby IF', 'IFK Göteborg', 'BK Häcken', 'IF Elfsborg', 'IFK Norrköping', 'Kalmar FF', 'IK Sirius', 'Mjällby AIF', 'Halmstads BK', 'Västerås SK', 'BP Brommapojkarna', 'Örebro SK'],
  'İsviçre': ['BSC Young Boys', 'FC Basel 1893', 'FC Zürich', 'Servette FC', 'FC Lugano', 'FC St. Gallen', 'FC Luzern', 'FC Sion', 'Grasshopper Club Zürich', 'FC Winterthur', 'Yverdon Sport FC', 'FC Lausanne-Sport', 'FC Thun', 'FC Vaduz', 'Neuchâtel Xamax'],
  'Romanya': ['FCSB', 'CFR 1907 Cluj', 'CS Universitatea Craiova', 'FC Rapid 1923', 'Farul Constanța', 'FC Dinamo 1948', 'Sepsi OSK Sfântu Gheorghe', 'UTA Arad', 'FC Hermannstadt', 'FC Petrolul Ploiești', 'SC Oțelul Galați', 'AS FC Universitatea Cluj', 'FC Botoșani', 'CSM Politehnica Iași', 'FC Voluntari'],
  'Çekya': ['AC Sparta Praha', 'SK Slavia Praha', 'FC Viktoria Plzeň', 'FC Baník Ostrava', '1. FC Slovácko', 'Bohemians 1905', 'FC Slovan Liberec', 'FK Mladá Boleslav', 'FK Jablonec', 'FC Hradec Králové', 'SK Sigma Olomouc', 'FK Teplice', 'FC Zlín', 'FK Pardubice', 'MFK Karviná']
};

export const WorldScoutModal: React.FC<WorldScoutModalProps> = ({
  isOpen,
  onClose,
  allTeams,
  userTeam,
  onSelectPlayerProfile,
  onTransferPlayer,
  showToast,
}) => {
  const { t, language } = useTranslation();
  const [selectedContinent, setSelectedContinent] = useState<string | null>(null);
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [selectedTeam, setSelectedTeam] = useState<{ id: string; name: string; isLocal: boolean; teamData?: Team | ExternalTeamData } | null>(null);

  // Transfer Negotiation State
  const [negotiatingPlayer, setNegotiatingPlayer] = useState<{ player: Player; sellerTeam: Team | ExternalTeamData } | null>(null);
  const [offerFee, setOfferFee] = useState<number>(0);
  const [negotiationResult, setNegotiationResult] = useState<{ status: 'IDLE' | 'SUCCESS' | 'REJECTED'; message: string } | null>(null);

  if (!isOpen) return null;

  // Resolve team object when a team is selected
  const currentInspectTeam = selectedTeam
    ? selectedTeam.teamData
      ? ensureTeamHas20Players(selectedTeam.teamData)
      : selectedTeam.isLocal
        ? ensureTeamHas20Players(allTeams.find(t => t.id === selectedTeam.id) || allTeams[0])
        : INTERNATIONAL_TEAMS.find(t => t.id === selectedTeam.id) || null
    : null;

  const handleOpenTransfer = (player: Player, sellerTeam: Team | ExternalTeamData) => {
    setNegotiatingPlayer({ player, sellerTeam });
    setOfferFee(Math.round((player.marketValue || 5000000) * 1.1));
    setNegotiationResult({ status: 'IDLE', message: '' });
  };

  const handleSendOffer = () => {
    if (!negotiatingPlayer) return;
    const { player, sellerTeam } = negotiatingPlayer;

    if (sellerTeam.id === userTeam.id) {
      setNegotiationResult({
        status: 'REJECTED',
        message: 'Bu oyuncu zaten sizin kulübünüzde!'
      });
      return;
    }

    if (offerFee > userTeam.budget) {
      setNegotiationResult({
        status: 'REJECTED',
        message: `Yetersiz Bütçe! Mevcut bütçeniz: €${(userTeam.budget / 1_000_000).toFixed(1)}M, Teklifiniz: €${(offerFee / 1_000_000).toFixed(1)}M`
      });
      return;
    }

    const marketVal = player.marketValue || 5000000;
    let minAcceptable = marketVal * 1.1;

    if (player.overall >= 85) minAcceptable = marketVal * 1.3;
    else if (player.age < 23 && player.overall >= 78) minAcceptable = marketVal * 1.35;

    if (offerFee >= minAcceptable) {
      setNegotiationResult({
        status: 'SUCCESS',
        message: `Tebrikler! ${sellerTeam.name} yönetimi €${(offerFee / 1_000_000).toFixed(1)}M bonservis teklifini kabul etti!`
      });
      onTransferPlayer(player, sellerTeam as Team, userTeam.id, offerFee);
      showToast('success', 'Transfer Tamamlandı!', `${player.name} €${(offerFee / 1_000_000).toFixed(1)}M bedelle ${userTeam.name} kadrosuna katıldı.`);
    } else {
      setNegotiationResult({
        status: 'REJECTED',
        message: `${sellerTeam.name} yöneticisi: "${player.name} satılık değil veya teklifiniz yetersiz! En az €${(minAcceptable / 1_000_000).toFixed(1)}M bekliyoruz."`
      });
    }
  };

  // Helper to list teams in a country (Guarantees at least 15 teams and 20 players per team)
  const getTeamsInCountry = (countryName: string) => {
    const isTurkey = countryName.toLowerCase() === 'türkiye' || countryName.toLowerCase() === 'turkey';
    if (isTurkey) {
      const sourceTeams = (allTeams && allTeams.length > 0 && allTeams.some(t => t.id === 'galatasaray' || t.id === 'fenerbahce' || t.id === 'besiktas'))
        ? allTeams
        : SUPER_LIG_TEAMS;

      return sourceTeams.map(t => {
        const expanded = ensureTeamHas20Players(t);
        return {
          id: expanded.id,
          name: expanded.name,
          country: 'Türkiye',
          flag: '🇹🇷',
          stadium: expanded.stadium || 'Stadyum',
          manager: expanded.managerName || 'Teknik Direktör',
          overall: expanded.overall,
          budget: expanded.budget,
          badgeColor: expanded.badgeColor || 'from-purple-600 to-indigo-700',
          logoUrl: expanded.logoUrl,
          shortName: expanded.shortName,
          players: expanded.players,
          isLocal: true,
        };
      });
    }

    const existingTeams = INTERNATIONAL_TEAMS.filter(t => t.country.toLowerCase() === countryName.toLowerCase());
    const mappedTeams = existingTeams.map(t => ({
      ...ensureTeamHas20Players(t),
      isLocal: false
    }));

    if (mappedTeams.length >= 15) {
      return mappedTeams;
    }

    // Generate extra teams to reach at least 15 teams
    const needed = 15 - mappedTeams.length;
    const teamNamesPool = GENERIC_EUROPEAN_CLUBS[countryName] || [
      `${countryName} FC`, `${countryName} United`, `${countryName} City`, `${countryName} Athletic`,
      `${countryName} Real`, `${countryName} Sporting`, `${countryName} Dynamo`, `${countryName} Lokomotiv`,
      `${countryName} CSKA`, `${countryName} Rovers`, `${countryName} Wanderers`, `${countryName} Academica`,
      `${countryName} Olympic`, `${countryName} Alliance`, `${countryName} Red Star`
    ];

    const generatedTeams = [...mappedTeams];
    const flagEmoji = CONTINENTS.flatMap(c => COUNTRIES_BY_CONTINENT[c.id] || []).find(cnt => cnt.name.toLowerCase() === countryName.toLowerCase())?.flag || '🇪🇺';

    for (let i = 0; i < needed; i++) {
      const genericName = teamNamesPool[i % teamNamesPool.length];
      // Skip if name already exists in generatedTeams
      if (generatedTeams.some(gt => gt.name.toLowerCase() === genericName.toLowerCase())) {
        continue;
      }

      const teamId = `gen-${countryName.toLowerCase().replace(/\s+/g, '-')}-${i + 1}`;
      const baseTeam: ExternalTeamData = {
        id: teamId,
        name: genericName,
        country: countryName,
        flag: flagEmoji,
        stadium: `${genericName} Stadyumu`,
        manager: `Teknik Direktör ${i + 1}`,
        overall: Math.floor(Math.random() * 10) + 72,
        budget: Math.floor(Math.random() * 20000000) + 10000000,
        badgeColor: 'from-blue-600 to-indigo-800',
        shortName: genericName.substring(0, 3).toUpperCase(),
        players: []
      };

      const fullTeam = ensureTeamHas20Players(baseTeam);
      generatedTeams.push({
        ...fullTeam,
        isLocal: false
      });
    }

    return generatedTeams;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4">
      <div className="bg-[#120f21] border border-[#302652] w-full max-w-5xl h-[94vh] sm:h-[90vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden text-white animate-in fade-in zoom-in duration-200">
        
        {/* Header Bar */}
        <div className="bg-gradient-to-r from-[#1b1535] via-[#2a1e50] to-[#1b1535] p-3 sm:p-4 border-b border-[#302652] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#7b2cbf] to-[#3a0ca3] border border-[#9d4edd] flex items-center justify-center text-xl shadow-lg shrink-0">
              <Globe className="w-5 h-5 text-sky-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm sm:text-base font-black tracking-wide text-white uppercase">
                  {t('WORLD_SCOUT_TITLE') || 'Dünya Futbol Haritası & Gözlem Ağı'}
                </h3>
              </div>
              
              {/* Breadcrumb Navigation */}
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-bold mt-0.5">
                <button
                  onClick={() => { setSelectedContinent(null); setSelectedCountry(null); setSelectedTeam(null); }}
                  className="hover:text-amber-300 transition-colors"
                >
                  {t('CONTINENTS_7')}
                </button>
                {selectedContinent && (
                  <>
                    <ChevronRight className="w-3 h-3 text-slate-500" />
                    <button
                      onClick={() => { setSelectedCountry(null); setSelectedTeam(null); }}
                      className="hover:text-amber-300 transition-colors"
                    >
                      {t(`CONTINENT_${selectedContinent}`)}
                    </button>
                  </>
                )}
                {selectedCountry && (
                  <>
                    <ChevronRight className="w-3 h-3 text-slate-500" />
                    <button
                      onClick={() => setSelectedTeam(null)}
                      className="hover:text-amber-300 transition-colors"
                    >
                      {getLocalizedCountry(selectedCountry, language)}
                    </button>
                  </>
                )}
                {selectedTeam && (
                  <>
                    <ChevronRight className="w-3 h-3 text-slate-500" />
                    <span className="text-purple-300 font-black">{selectedTeam.name}</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {(selectedContinent || selectedCountry || selectedTeam) && (
              <button
                onClick={() => {
                  if (selectedTeam) setSelectedTeam(null);
                  else if (selectedCountry) setSelectedCountry(null);
                  else if (selectedContinent) setSelectedContinent(null);
                }}
                className="px-3 py-1.5 rounded-xl bg-[#20193d] hover:bg-[#2c2252] border border-[#3b2d6b] text-xs font-bold text-slate-300 flex items-center gap-1 transition-all"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> {t('BACK_BTN')}
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-3 sm:p-5 bg-[#120f21]">
          
          {/* VIEW 1: SELECT CONTINENT (7 KITA) */}
          {!selectedContinent && (
            <div className="space-y-4">
              <div className="bg-[#18142b] border border-[#2b2247] p-3.5 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-sm text-white">{t('SELECT_CONTINENT_TITLE')}</h4>
                  <p className="text-xs text-slate-400">{t('SELECT_CONTINENT_DESC')}</p>
                </div>
                <span className="px-2.5 py-1 rounded-xl bg-purple-600/20 border border-purple-500/40 text-purple-300 font-black text-xs">
                  {t('7_CONTINENTS_ACTIVE')}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {CONTINENTS.map(cont => (
                  <div
                    key={cont.id}
                    onClick={() => setSelectedContinent(cont.id)}
                    className="bg-[#18142b] border border-[#2b2247] hover:border-[#7b2cbf] rounded-2xl p-4 cursor-pointer transition-all group hover:scale-[1.01] shadow-lg flex flex-col justify-between"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-3xl p-2 rounded-2xl bg-[#120f21] border border-[#2b2247] shadow">
                        {cont.icon}
                      </span>
                      <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-purple-400 group-hover:translate-x-1 transition-all" />
                    </div>

                    <div>
                      <h5 className="font-extrabold text-base text-white group-hover:text-purple-300 transition-colors">
                        {t(`CONTINENT_${cont.id}`)}
                      </h5>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {t(`CONTINENT_${cont.id}_DESC`)}
                      </p>
                    </div>

                    <div className="mt-4 pt-2 border-t border-[#2b2247] flex items-center justify-between text-[11px] text-slate-400 font-bold">
                      <span>{(COUNTRIES_BY_CONTINENT[cont.id] || []).length} {t('COUNTRIES_AVAILABLE')}</span>
                      <span className="text-purple-400 group-hover:underline">{t('INSPECT_BTN')} &rarr;</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* VIEW 2: SELECT COUNTRY IN CONTINENT */}
          {selectedContinent && !selectedCountry && (
            <div className="space-y-4">
              <div className="bg-[#18142b] border border-[#2b2247] p-3.5 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-sm text-white flex items-center gap-2">
                    <span>{CONTINENTS.find(c => c.id === selectedContinent)?.icon}</span>
                    <span>{t(`CONTINENT_${selectedContinent}`)} {language === 'TR' ? 'Ülkeleri' : (language === 'ES' ? 'Países' : (language === 'FR' ? 'Pays' : (language === 'IT' ? 'Paesi' : (language === 'PT' ? 'Países' : 'Countries'))))}</span>
                  </h4>
                  <p className="text-xs text-slate-400">{t('SELECT_COUNTRY_DESC') || 'Görüntülemek istediğiniz ülkeyi seçerek takımlarına erişin'}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                {(COUNTRIES_BY_CONTINENT[selectedContinent] || []).map(country => (
                  <div
                    key={country.code}
                    onClick={() => setSelectedCountry(country.name)}
                    className="bg-[#18142b] border border-[#2b2247] hover:border-[#7b2cbf] rounded-2xl p-4 cursor-pointer transition-all group flex items-center justify-between shadow"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{country.flag}</span>
                      <div>
                        <h5 className="font-extrabold text-sm text-white group-hover:text-purple-300 transition-colors">
                          {getLocalizedCountry(country.name, language)}
                        </h5>
                        <span className="text-[10px] font-bold text-slate-400 block">
                          {t('VIEW_CLUBS') || 'Kulüpleri Listele'} &rarr;
                        </span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-purple-400" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* VIEW 3: SELECT TEAM IN COUNTRY */}
          {selectedContinent && selectedCountry && !selectedTeam && (
            <div className="space-y-4">
              <div className="bg-[#18142b] border border-[#2b2247] p-3.5 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-sm text-white uppercase flex items-center gap-2">
                    <span>{getLocalizedCountry(selectedCountry, language)} {language === 'TR' ? 'KULÜPLERİ' : (language === 'ES' ? 'CLUBES' : (language === 'FR' ? 'CLUBS' : (language === 'IT' ? 'CLUB' : (language === 'PT' ? 'CLUBES' : 'CLUBS'))))}</span>
                  </h4>
                  <p className="text-xs text-slate-400">{t('SELECT_CLUB_DESC') || 'Takımın bilgilerini ve kadro ekranını incelemek için bir kulüp seçin'}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {getTeamsInCountry(selectedCountry).map(tItem => (
                  <div
                    key={tItem.id}
                    onClick={() => setSelectedTeam({ id: tItem.id, name: tItem.name, isLocal: tItem.isLocal, teamData: tItem })}
                    className="bg-[#18142b] border border-[#2b2247] hover:border-[#7b2cbf] rounded-2xl p-3.5 cursor-pointer transition-all group shadow flex flex-col justify-between"
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <TeamBadge team={tItem} size="lg" className="shrink-0 shadow" />
                      <div className="min-w-0 flex-1">
                        <h5 className="font-extrabold text-sm text-white group-hover:text-purple-300 transition-colors truncate">
                          {tItem.name}
                        </h5>
                        <p className="text-[11px] text-slate-400 truncate">
                          🏟️ {tItem.stadium}
                        </p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-[#2b2247] flex items-center justify-between text-[11px] font-semibold text-slate-300">
                      <span className="bg-[#120f21] px-2 py-0.5 rounded border border-[#2b2247] text-amber-300 font-extrabold">
                        {tItem.overall} OVR
                      </span>
                      <span className="text-purple-400 group-hover:underline font-extrabold">
                        {t('ROSTER_SCREEN_BTN') || 'Kadro Ekranı'} &rarr;
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* VIEW 4: TEAM DETAILED PROFILE & FM-STYLE ROSTER SCREEN */}
          {selectedTeam && currentInspectTeam && (
            <div className="space-y-4">
              
              {/* Team Banner */}
              <div className="bg-gradient-to-r from-[#1f163b] via-[#2d1c59] to-[#1f163b] border border-[#3b2d66] rounded-2xl p-4 shadow-xl flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <TeamBadge team={currentInspectTeam} size="xl" className="border-2 border-amber-400/60 shadow-lg shrink-0" />
                  <div>
                    <h4 className="font-black text-lg text-white flex items-center gap-2">
                      <span>{currentInspectTeam.name}</span>
                      <span className="text-xs font-normal text-slate-300">({currentInspectTeam.country})</span>
                    </h4>
                    <p className="text-xs text-slate-300 mt-0.5">
                      🏟️ {t('STADIUM_LABEL') || 'Stadyum'}: <strong>{currentInspectTeam.stadium || 'Stadyum'}</strong> • 👔 {t('MANAGER_LABEL') || 'Menajer'}: <strong>{(currentInspectTeam as any).managerName || (currentInspectTeam as any).manager || 'Teknik Direktör'}</strong>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-xs">
                  <div className="bg-[#120f21] p-2 rounded-xl border border-[#302652] text-center">
                    <span className="text-[10px] text-slate-400 block font-bold">{t('TEAM_POWER_LABEL') || 'TAKIM GÜCÜ'}</span>
                    <strong className="text-amber-300 font-black text-sm">{currentInspectTeam.overall || 85} OVR</strong>
                  </div>
                  <div className="bg-[#120f21] p-2 rounded-xl border border-[#302652] text-center">
                    <span className="text-[10px] text-slate-400 block font-bold">{t('BUDGET_TITLE') || 'BÜTÇE'}</span>
                    <strong className="text-emerald-400 font-black text-sm">€{(currentInspectTeam.budget / 1_000_000).toFixed(1)}M</strong>
                  </div>
                  <div className="bg-[#120f21] p-2 rounded-xl border border-[#302652] text-center">
                    <span className="text-[10px] text-slate-400 block font-bold">{t('SQUAD_COUNT_LABEL') || 'KADRO'}</span>
                    <strong className="text-purple-300 font-black text-sm">{currentInspectTeam.players.length} {t('PLAYERS_COUNT_UNIT') || 'Oyuncu'}</strong>
                  </div>
                </div>
              </div>

              {/* FOOTBALL MANAGER STYLE SQUAD SCREEN (LINE-BY-LINE TABLE) */}
              <div className="bg-[#18142b] border border-[#2b2247] rounded-2xl p-3 shadow-xl space-y-2">
                
                <div className="flex items-center justify-between pb-2 border-b border-[#2b2247]">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-purple-400" />
                    <h5 className="font-extrabold text-sm text-white uppercase tracking-wider">
                      {currentInspectTeam.name} - {t('SQUAD_ROSTER_TITLE') || 'OYUNCU KADROSU (FM LAYOUT)'}
                    </h5>
                  </div>
                  <span className="text-[11px] text-slate-400 font-medium">
                    {t('CLICK_PLAYER_TO_PROFILE_HINT') || 'İsme tıklayarak oyuncu profilini görüntüleyebilirsiniz'}
                  </span>
                </div>

                {/* Vertical Line-by-Line Table Header */}
                <div className="overflow-x-auto custom-scrollbar">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-[#2b2247] text-[10px] font-black uppercase text-slate-400 bg-[#120f21]">
                        <th className="py-2 px-2.5">{t('ROLE_LABEL') || 'SEÇ / ROL'}</th>
                        <th className="py-2 px-2.5">{t('PLAYER_NAME_HEADER') || 'OYUNCU ADI'}</th>
                        <th className="py-2 px-2.5">{t('AGE_LABEL') || 'YAŞ'}</th>
                        <th className="py-2 px-2.5">{t('NATIONALITY_LABEL') || 'UYRUK'}</th>
                        <th className="py-2 px-2.5 text-center">{t('FORM_BADGE') || 'FORM'}</th>
                        <th className="py-2 px-2.5">{t('MARKET_VALUE_HEADER') || 'PİYASA DEĞERİ'}</th>
                        <th className="py-2 px-2.5">{t('WAGE_BADGE') || 'MAAŞ'}</th>
                        <th className="py-2 px-2.5 text-right">{t('ACTION_HEADER') || 'İŞLEM'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#231b3e]">
                      {currentInspectTeam.players.map((p, idx) => {
                        const formVal = (p.form || 7.5).toFixed(2);
                        const isStarter = p.isStarting ?? idx < 11;
                        const roleBadge = isStarter ? (p.specificRole || p.position) : `S${idx - 10}`;
                        const isUserTeam = currentInspectTeam.id === userTeam.id;

                        return (
                          <tr
                            key={p.id}
                            className="hover:bg-[#20193b] transition-colors cursor-pointer group"
                            onClick={() => onSelectPlayerProfile(p, currentInspectTeam as unknown as Team)}
                          >
                            {/* Role / Selection Badge */}
                            <td className="py-2 px-2.5">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase shadow-sm ${
                                isStarter ? 'bg-[#5b21b6] text-white border border-[#7c3aed]' : 'bg-slate-800 text-slate-400 border border-slate-700'
                              }`}>
                                {roleBadge}
                              </span>
                            </td>

                            {/* Player Name */}
                            <td className="py-2 px-2.5">
                              <span className="font-extrabold text-white group-hover:text-purple-300 transition-colors">
                                {p.name}
                              </span>
                            </td>

                            {/* Age */}
                            <td className="py-2 px-2.5 text-slate-300 font-medium">
                              {p.age}
                            </td>

                            {/* Nationality */}
                            <td className="py-2 px-2.5 text-slate-300 font-medium">
                              {p.nationality || 'Türkiye'}
                            </td>

                            {/* Form Pill (FM Rating Pill) */}
                            <td className="py-2 px-2.5 text-center">
                              <span className={`px-2 py-0.5 rounded-full font-black text-[11px] shadow-sm ${
                                p.form >= 8.0 ? 'bg-emerald-600 text-white' : p.form >= 7.3 ? 'bg-amber-600 text-white' : 'bg-slate-700 text-slate-300'
                              }`}>
                                {formVal}
                              </span>
                            </td>

                            {/* Value */}
                            <td className="py-2 px-2.5 font-extrabold text-amber-300">
                              €{((p.marketValue || 5000000) / 1_000_000).toFixed(1)}M
                            </td>

                            {/* Wage */}
                            <td className="py-2 px-2.5 font-bold text-sky-300">
                              €{((p.wage || 25000) / 1000).toFixed(0)}k/hf
                            </td>

                            {/* Action Button */}
                            <td className="py-2 px-2.5 text-right" onClick={(e) => e.stopPropagation()}>
                              {isUserTeam ? (
                                <span className="text-[10px] text-emerald-400 font-extrabold">{t('IN_YOUR_CLUB') || 'Kulübünüzde'}</span>
                              ) : (
                                <button
                                  onClick={() => handleOpenTransfer(p, currentInspectTeam)}
                                  className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-[10px] uppercase tracking-wider shadow"
                                >
                                  {t('MAKE_OFFER_BTN') || 'Teklif Et'}
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Transfer & Loan Negotiation Offer Modal */}
      {negotiatingPlayer && (
        <TransferOfferModal
          isOpen={!!negotiatingPlayer}
          onClose={() => setNegotiatingPlayer(null)}
          player={negotiatingPlayer.player}
          sellerTeam={negotiatingPlayer.sellerTeam as unknown as Team}
          userTeam={userTeam}
          onTransferSuccess={(pl, dealType, fee, updatedProps) => {
            const finalPlayer = updatedProps ? { ...pl, ...updatedProps } : pl;
            onTransferPlayer(finalPlayer, negotiatingPlayer.sellerTeam as unknown as Team, userTeam.id, fee);
          }}
          showToast={showToast}
        />
      )}

    </div>
  );
};
