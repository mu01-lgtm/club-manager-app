import React, { useState, useEffect } from 'react';
import { Team, ManagerProfile, LeagueRow, Fixture, GameMode, CreatedPlayerProfile, CustomPlayerAvatar, Position } from '../types';
import { Trophy, Play, Upload, User, Shield, CheckCircle2, Trash2, Sparkles, RefreshCw, Dices, UserCheck, Shirt, Search, Globe, ChevronDown, ChevronUp, Save, Clock, HardDrive } from 'lucide-react';
import { PlayerAvatarRenderer } from './PlayerAvatarRenderer';
import { TeamBadge } from './TeamBadge';
import { SUPER_LIG_TEAMS } from '../data/superLigTeams';
import { ENGLISH_TEAMS } from '../data/englishTeams';
import { SPANISH_TEAMS } from '../data/spanishTeams';
import { BUNDESLIGA_TEAMS } from '../data/bundesligaTeams';
import { SERIE_A_TEAMS } from '../data/serieATeams';
import { LIGUE1_TEAMS } from '../data/ligue1Teams';
import { ADDITIONAL_EUROPEAN_TEAMS } from '../data/europeanTeams';
import { INTERNATIONAL_TEAMS, ExternalTeamData } from './WorldScoutModal';
import { ensureTeamHas20Players } from '../utils/squadExpander';
import { getTeamTargetGoal } from '../utils/teamGoalsHelper';
import { getAllCareers, deleteCareer, deleteCareerSlot, CareerSave, SaveSlotData } from '../utils/saveSystem';
import { getTeamLogoUrl } from '../data/teamLogos';

import { useTranslation } from '../utils/i18n';

export interface SavedGameState {
  id: string;
  saveName: string;
  saveDate: string;
  managerName: string;
  teamId: string;
  teamName?: string;
  currentWeek: number;
  currentSeason: number;
  allTeams: Team[];
  standings: LeagueRow[];
  fixtures: Fixture[];
  gameMode?: GameMode;
  createdPlayer?: CreatedPlayerProfile;
}

interface CareerStartModalProps {
  isOpen: boolean;
  initialMode?: 'MENU' | 'NEW_CAREER' | 'LOAD_CAREER';
  allTeams: Team[];
  onStartNewGame: (
    managerOrPlayerName: string,
    teamId: string,
    gameMode?: GameMode,
    createdPlayer?: CreatedPlayerProfile,
    customTeamsList?: Team[],
    customSaveName?: string
  ) => void;
  onLoadSavedGame: (savedState: any) => void;
  onClose?: () => void;
}

// Convert ExternalTeamData to Team format
const convertExternalTeam = (ext: ExternalTeamData): Team => {
  return ensureTeamHas20Players({
    id: ext.id,
    name: ext.name,
    badgeColor: ext.badgeColor,
    badgeTextColor: 'text-white',
    shortName: ext.shortName,
    stadiumName: ext.stadium,
    logoUrl: ext.logoUrl || getTeamLogoUrl(ext.id) || getTeamLogoUrl(ext.name) || getTeamLogoUrl(ext.shortName),
    country: ext.country,
    manager: ext.manager,
    players: ext.players,
    budget: ext.budget,
    overall: ext.overall,
    formation: '4-3-3',
    tactic: 'ATTACKING'
  }) as Team;
};

export const CareerStartModal: React.FC<CareerStartModalProps> = ({
  isOpen,
  initialMode,
  allTeams,
  onStartNewGame,
  onLoadSavedGame,
  onClose
}) => {
  const { t } = useTranslation();
  const [viewMode, setViewMode] = useState<'MENU' | 'NEW_CAREER' | 'LOAD_CAREER'>(initialMode || 'MENU');
  
  // Game Mode Selection
  const [gameMode, setGameMode] = useState<GameMode>('MANAGER');

  // Manager career setup form
  const [managerName, setManagerName] = useState<string>('Ali Yılmaz');
  const [selectedTeamId, setSelectedTeamId] = useState<string>('galatasaray');
  const [selectedLeague, setSelectedLeague] = useState<string>('SUPER_LIG');
  const [teamSearchQuery, setTeamSearchQuery] = useState<string>('');
  const [customSaveName, setCustomSaveName] = useState<string>('');

  // Player career customization setup form
  const [playerName, setPlayerName] = useState<string>('Sertan Yıldız');
  const [playerAge, setPlayerAge] = useState<number>(19);
  const [playerPosition, setPlayerPosition] = useState<Position>('FW');
  const [playerRole, setPlayerRole] = useState<string>('ST');
  const [playerFoot, setPlayerFoot] = useState<'Sağ' | 'Sol'>('Sağ');

  const [avatar, setAvatar] = useState<CustomPlayerAvatar>({
    skinTone: 'Buğday',
    hairStyle: 'Fade',
    hairColor: 'Siyah',
    eyeColor: 'Kahverengi',
    sleeveLength: 'Kısa Kol',
    bootColor: 'Neon Sarı',
  });

  // Boot / Action Loading animation state
  const [isBooting, setIsBooting] = useState<boolean>(true);
  const [bootProgress, setBootProgress] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingText, setLoadingText] = useState<string>('Veritabanı Oluşturuluyor...');
  const [loadingProgress, setLoadingProgress] = useState<number>(0);

  // Careers and expanded accordion state
  const [allCareersList, setAllCareersList] = useState<CareerSave[]>([]);
  const [expandedCareerId, setExpandedCareerId] = useState<string | null>(null);

  // Initial boot splash simulation & initial mode sync
  useEffect(() => {
    if (isOpen) {
      if (initialMode) {
        setViewMode(initialMode);
      } else {
        setViewMode('MENU');
      }
      setIsBooting(true);
      setBootProgress(15);
      
      const bootTimer1 = setTimeout(() => setBootProgress(45), 200);
      const bootTimer2 = setTimeout(() => setBootProgress(85), 450);
      const bootTimer3 = setTimeout(() => {
        setBootProgress(100);
        setTimeout(() => setIsBooting(false), 150);
      }, 700);

      return () => {
        clearTimeout(bootTimer1);
        clearTimeout(bootTimer2);
        clearTimeout(bootTimer3);
      };
    }
  }, [isOpen, initialMode]);

  // Load saved careers using saveSystem
  useEffect(() => {
    if (isOpen || viewMode === 'LOAD_CAREER') {
      const careers = getAllCareers();
      setAllCareersList(careers);
      if (careers.length > 0 && !expandedCareerId) {
        setExpandedCareerId(careers[0].id);
      }
    }
  }, [viewMode, isOpen]);

  // Global League & Team Datasets
  const ALL_GLOBAL_TEAMS = React.useMemo(() => {
    const list: Team[] = [];

    // 1. Super Lig Teams
    SUPER_LIG_TEAMS.forEach(t => list.push(ensureTeamHas20Players(t) as Team));

    // 2. English Teams
    ENGLISH_TEAMS.forEach(t => {
      if (!list.some(e => e.id === t.id)) list.push(convertExternalTeam(t));
    });

    // 3. Spanish Teams
    SPANISH_TEAMS.forEach(t => {
      if (!list.some(e => e.id === t.id)) list.push(convertExternalTeam(t));
    });

    // 4. European & International Teams from WorldScoutModal
    INTERNATIONAL_TEAMS.forEach(t => {
      if (!list.some(e => e.id === t.id)) {
        list.push(convertExternalTeam(t));
      }
    });

    return list;
  }, []);

  const LEAGUES = [
    { id: 'SUPER_LIG', name: 'Süper Lig', flag: '🇹🇷', country: 'Türkiye' },
    { id: 'PREMIER_LEAGUE', name: 'Premier League', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', country: 'İngiltere' },
    { id: 'LA_LIGA', name: 'La Liga', flag: '🇪🇸', country: 'İspanya' },
    { id: 'BUNDESLIGA', name: 'Bundesliga', flag: '🇩🇪', country: 'Almanya' },
    { id: 'SERIE_A', name: 'Serie A', flag: '🇮🇹', country: 'İtalya' },
    { id: 'LIGUE_1', name: 'Ligue 1', flag: '🇫🇷', country: 'Fransa' },
    { id: 'OTHER_WORLD', name: 'Dünya Kulüpleri', flag: '🌍', country: 'Dünya' },
    { id: 'ALL', name: 'Tüm Kulüpler', flag: '🌐', country: 'Tüm Ligler' },
  ];

  const filteredTeams = React.useMemo(() => {
    let pool: Team[] = [];

    if (selectedLeague === 'SUPER_LIG') {
      pool = SUPER_LIG_TEAMS.map(t => ensureTeamHas20Players(t) as Team);
    } else if (selectedLeague === 'PREMIER_LEAGUE') {
      pool = ENGLISH_TEAMS.map(convertExternalTeam);
    } else if (selectedLeague === 'LA_LIGA') {
      pool = SPANISH_TEAMS.map(convertExternalTeam);
    } else if (selectedLeague === 'BUNDESLIGA') {
      pool = BUNDESLIGA_TEAMS.map(convertExternalTeam);
    } else if (selectedLeague === 'SERIE_A') {
      pool = SERIE_A_TEAMS.map(convertExternalTeam);
    } else if (selectedLeague === 'LIGUE_1') {
      pool = LIGUE1_TEAMS.map(convertExternalTeam);
    } else if (selectedLeague === 'OTHER_WORLD') {
      pool = INTERNATIONAL_TEAMS.filter(t => !['Türkiye', 'İngiltere', 'İspanya', 'Almanya', 'İtalya', 'Fransa'].includes(t.country)).map(convertExternalTeam);
    } else {
      pool = ALL_GLOBAL_TEAMS;
    }

    if (teamSearchQuery.trim()) {
      const q = teamSearchQuery.toLowerCase().trim();
      return ALL_GLOBAL_TEAMS.filter(t => t.name.toLowerCase().includes(q) || t.shortName.toLowerCase().includes(q));
    }

    return pool.length > 0 ? pool : ALL_GLOBAL_TEAMS;
  }, [selectedLeague, teamSearchQuery, ALL_GLOBAL_TEAMS]);

  if (!isOpen) return null;

  const handleRandomTeam = () => {
    if (!filteredTeams || filteredTeams.length === 0) return;
    const randomIndex = Math.floor(Math.random() * filteredTeams.length);
    setSelectedTeamId(filteredTeams[randomIndex].id);
  };

  const handleStartNewSubmit = () => {
    const finalName = gameMode === 'MANAGER' ? managerName.trim() : playerName.trim();
    if (!finalName) return;

    setIsLoading(true);
    setLoadingProgress(10);
    setLoadingText(
      gameMode === 'MANAGER'
        ? t('LOADING_PREP_SQUAD')
        : t('LOADING_LICENSING_PLAYER')
    );

    setTimeout(() => {
      setLoadingProgress(45);
      setLoadingText(t('LOADING_FIXTURES_REFEREES'));
    }, 600);

    setTimeout(() => {
      setLoadingProgress(80);
      setLoadingText(
        gameMode === 'MANAGER'
          ? t('LOADING_SIGNING_MANAGER')
          : t('LOADING_SIGNING_PLAYER')
      );
    }, 1200);

    setTimeout(() => {
      setLoadingProgress(100);
      setTimeout(() => {
        setIsLoading(false);

        let createdPlayerProfile: CreatedPlayerProfile | undefined = undefined;
        if (gameMode === 'PLAYER_CAREER') {
          createdPlayerProfile = {
            id: `usr-player-${Date.now()}`,
            name: finalName,
            age: playerAge,
            position: playerPosition,
            specificRole: playerRole,
            preferredFoot: playerFoot,
            nationality: 'Türkiye',
            avatar: avatar,
            overall: 74,
            marketValue: 4500000,
            wage: 25000,
            attributes: {
              pace: playerPosition === 'FW' ? 84 : 76,
              shooting: playerPosition === 'FW' ? 80 : 68,
              passing: playerPosition === 'MID' ? 82 : 72,
              defending: playerPosition === 'DEF' ? 81 : 45,
              physical: 76,
            },
            currentTeamId: selectedTeamId,
            matchesPlayed: 0,
            goalsScored: 0,
            assists: 0,
            averageRating: 7.2,
            managerTrust: 85,
            stamina: 100,
            form: 8.0,
          };
        }

        // Determine active league pool based on selected team
        let activeLeagueTeams: Team[] = [];
        if (ENGLISH_TEAMS.some(t => t.id === selectedTeamId)) {
          activeLeagueTeams = ENGLISH_TEAMS.map(convertExternalTeam);
        } else if (SPANISH_TEAMS.some(t => t.id === selectedTeamId)) {
          activeLeagueTeams = SPANISH_TEAMS.map(convertExternalTeam);
        } else if (BUNDESLIGA_TEAMS.some(t => t.id === selectedTeamId)) {
          activeLeagueTeams = BUNDESLIGA_TEAMS.map(convertExternalTeam);
        } else if (SERIE_A_TEAMS.some(t => t.id === selectedTeamId)) {
          activeLeagueTeams = SERIE_A_TEAMS.map(convertExternalTeam);
        } else if (LIGUE1_TEAMS.some(t => t.id === selectedTeamId)) {
          activeLeagueTeams = LIGUE1_TEAMS.map(convertExternalTeam);
        } else if (SUPER_LIG_TEAMS.some(t => t.id === selectedTeamId)) {
          activeLeagueTeams = SUPER_LIG_TEAMS.map(t => ensureTeamHas20Players(t) as Team);
        } else {
          const foundExt = INTERNATIONAL_TEAMS.find(t => t.id === selectedTeamId);
          if (foundExt) {
            const sameCountry = INTERNATIONAL_TEAMS.filter(t => t.country === foundExt.country);
            if (sameCountry.length >= 6) {
              activeLeagueTeams = sameCountry.map(convertExternalTeam);
            } else {
              activeLeagueTeams = [convertExternalTeam(foundExt), ...SUPER_LIG_TEAMS.filter(t => t.id !== selectedTeamId).map(t => ensureTeamHas20Players(t) as Team)];
            }
          } else {
            activeLeagueTeams = SUPER_LIG_TEAMS.map(t => ensureTeamHas20Players(t) as Team);
          }
        }

        const selTeam = ALL_GLOBAL_TEAMS.find(t => t.id === selectedTeamId) || activeLeagueTeams[0];
        const finalSaveName = customSaveName.trim() || `${selTeam?.name || 'Takım'} Kariyeri`;

        onStartNewGame(finalName, selectedTeamId, gameMode, createdPlayerProfile, activeLeagueTeams, finalSaveName);
      }, 400);
    }, 1800);
  };

  const handleLoadSlot = (slotData: SaveSlotData, saveName: string, careerId?: string) => {
    setIsLoading(true);
    setLoadingProgress(20);
    setLoadingText('Kayıtlı Kariyer Dosyası Yükleniyor...');

    setTimeout(() => {
      setLoadingProgress(70);
      setLoadingText('Takım İstatistikleri ve Fikstür Yükleniyor...');
    }, 700);

    setTimeout(() => {
      setLoadingProgress(100);
      setTimeout(() => {
        setIsLoading(false);
        const legacyFormat = {
          id: careerId || `career_${Date.now()}`,
          saveName: saveName,
          saveDate: slotData.saveDate,
          managerName: slotData.managerName,
          teamId: slotData.teamId,
          currentWeek: slotData.currentWeek,
          currentSeason: slotData.currentSeason,
          currentDayIndex: slotData.currentDayIndex || 0,
          allTeams: slotData.allTeams,
          standings: slotData.standings,
          fixtures: slotData.fixtures,
          scouts: slotData.scouts,
          scoutReports: slotData.scoutReports,
          inboxMessages: slotData.inboxMessages,
          pendingBuyOffers: slotData.pendingBuyOffers,
          pendingTransferArrivals: slotData.pendingTransferArrivals,
          gameMode: slotData.gameMode,
          createdPlayer: slotData.createdPlayer
        };
        onLoadSavedGame(legacyFormat);
      }, 400);
    }, 1300);
  };

  const handleDeleteEntireCareer = (careerId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = deleteCareer(careerId);
    setAllCareersList(updated);
  };

  const handleDeleteSlotItem = (careerId: string, slotType: 'NORMAL' | 'AUTO', e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = deleteCareerSlot(careerId, slotType);
    setAllCareersList(updated);
  };

  const selectedTeam = allTeams.find(t => t.id === selectedTeamId) || allTeams[0];

  return (
    <div className="fixed inset-0 z-50 bg-[#070510]/95 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-hidden select-none animate-fadeIn">
      
      {/* Background Atmosphere */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/40 via-[#0a0718] to-[#04030a] pointer-events-none" />

      <div className="w-full max-w-4xl max-h-[95vh] sm:max-h-[90vh] bg-[#151126]/95 border-2 border-[#3d2f66] rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col my-auto relative z-10 backdrop-blur-xl">
        
        {/* Header Branding (Fixed Pinned Top) */}
        <div className="bg-gradient-to-r from-[#1d1636] via-[#2d2252] to-[#1d1636] p-3 sm:p-4 border-b border-[#392e5c] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl bg-gradient-to-tr from-[#7b2cbf] to-[#c77dff] flex items-center justify-center text-white shadow-lg font-black text-base sm:text-lg shrink-0">
              FM
            </div>
            <div>
              <h2 className="text-sm sm:text-lg font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                Football Manager Mobile <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">2026</span>
              </h2>
              <p className="text-[11px] sm:text-xs text-slate-400 font-medium">{t('FOOTBALL_CAREER_SIMULATION')}</p>
            </div>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white font-bold text-xs sm:text-sm px-2.5 py-1 rounded-xl bg-[#241b42] border border-[#392e5c] shrink-0"
            >
              {t('CLOSE')}
            </button>
          )}
        </div>

        {/* Scrollable Main Modal Body */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-3.5 sm:p-6">

        {/* BOOT / INITIAL GAME LOADING SCREEN */}
        {isBooting ? (
          <div className="py-8 sm:py-14 flex flex-col items-center justify-center text-center space-y-5">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-[#7b2cbf] via-[#9d4edd] to-[#c77dff] flex items-center justify-center text-white font-black text-2xl sm:text-3xl shadow-2xl animate-pulse">
              FM
            </div>

            <div className="space-y-1">
              <h3 className="text-base sm:text-lg font-black text-white uppercase tracking-widest">Football Manager Mobile 2026</h3>
              <p className="text-xs text-purple-300 font-bold">{t('BOOT_LOADING_DB')}</p>
            </div>

            {/* Progress Bar */}
            <div className="w-full max-w-md h-3 bg-[#1e1738] rounded-full overflow-hidden border border-[#3c2f68] p-0.5">
              <div
                className="h-full bg-gradient-to-r from-purple-600 via-pink-500 to-emerald-400 transition-all duration-200 rounded-full"
                style={{ width: `${bootProgress}%` }}
              />
            </div>
            <span className="text-xs font-black text-slate-400">%{bootProgress}</span>
          </div>
        ) : isLoading ? (
          /* ACTION LOADING OVERLAY */
          <div className="py-8 sm:py-12 flex flex-col items-center justify-center text-center space-y-5">
            <div className="relative">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full border-4 border-purple-500/20 border-t-purple-500 animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center text-purple-300 font-black text-xs">
                {loadingProgress}%
              </div>
            </div>

            <div className="space-y-1 max-w-md">
              <h3 className="text-sm sm:text-base font-black text-white">{loadingText}</h3>
              <p className="text-xs text-slate-400 font-medium">{t('LOADING_PLEASE_WAIT_WORLD')}</p>
            </div>

            {/* Progress Bar */}
            <div className="w-full max-w-sm h-2.5 bg-[#221a3e] rounded-full overflow-hidden border border-[#382d5e]">
              <div
                className="h-full bg-gradient-to-r from-purple-600 to-emerald-400 transition-all duration-300 rounded-full"
                style={{ width: `${loadingProgress}%` }}
              />
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            
            {/* VIEW 1: MAIN START MENU WITH FOOTBALL WALLPAPER */}
            {viewMode === 'MENU' && (
              <div className="space-y-4 text-center relative">
                
                {/* Football Pitch Graphic Banner */}
                <div className="relative rounded-2xl overflow-hidden border border-[#392e5c] bg-gradient-to-br from-[#122e1e] via-[#16122c] to-[#251b47] p-4 sm:p-7 flex flex-col items-center justify-center text-center shadow-inner">
                  <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px] opacity-10 pointer-events-none" />
                  
                  <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-tr from-purple-600 to-emerald-400 flex items-center justify-center text-white shadow-xl font-black text-xl sm:text-2xl mb-2">
                    ⚽
                  </div>
                  <h3 className="text-lg sm:text-2xl font-black text-white uppercase tracking-wider">
                    {t('SUPER_LIG_CAREER_TITLE')}
                  </h3>
                  <p className="text-xs sm:text-sm text-purple-200/80 font-medium max-w-md mt-1">
                    {t('SUPER_LIG_CAREER_SUBTITLE')}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <button
                    onClick={() => {
                      setGameMode('MANAGER');
                      setViewMode('NEW_CAREER');
                    }}
                    className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#7b2cbf] to-[#5a189a] hover:brightness-110 text-white flex flex-col items-center justify-center gap-1.5 border border-purple-400/30 shadow-2xl transition-all active:scale-95 group"
                  >
                    <div className="p-2.5 rounded-xl bg-white/10 group-hover:scale-110 transition-transform">
                      <Play className="w-6 h-6 sm:w-8 sm:h-8 text-white fill-current" />
                    </div>
                    <span className="font-black text-sm sm:text-base uppercase tracking-wider">{t('MANAGER_CAREER_TITLE')}</span>
                    <span className="text-[10px] sm:text-[11px] text-purple-200 opacity-80">{t('MANAGER_CAREER_DESC')}</span>
                  </button>

                  <button
                    onClick={() => {
                      setGameMode('PLAYER_CAREER');
                      setViewMode('NEW_CAREER');
                    }}
                    className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#0284c7] to-[#0369a1] hover:brightness-110 text-white flex flex-col items-center justify-center gap-1.5 border border-sky-400/30 shadow-2xl transition-all active:scale-95 group"
                  >
                    <div className="p-2.5 rounded-xl bg-white/10 group-hover:scale-110 transition-transform">
                      <UserCheck className="w-6 h-6 sm:w-8 sm:h-8 text-sky-200" />
                    </div>
                    <span className="font-black text-sm sm:text-base uppercase tracking-wider">{t('PLAYER_CAREER_TITLE')}</span>
                    <span className="text-[10px] sm:text-[11px] text-sky-100 opacity-90">{t('PLAYER_CAREER_DESC')}</span>
                  </button>
                </div>

                <button
                  onClick={() => setViewMode('LOAD_CAREER')}
                  className="w-full py-2.5 sm:py-3 rounded-xl bg-[#1e1838] hover:bg-[#28204a] text-white font-black text-xs uppercase tracking-wider border border-[#392e5c] shadow transition-all flex items-center justify-center gap-2"
                >
                  <Upload className="w-4 h-4 text-purple-400" /> {t('LOAD_SAVED_GAME')}
                </button>
              </div>
            )}

            {/* VIEW 2: NEW CAREER SETUP */}
            {viewMode === 'NEW_CAREER' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-[#2d244c] pb-2.5">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setGameMode('MANAGER')}
                      className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition-all ${
                        gameMode === 'MANAGER'
                          ? 'bg-purple-600 text-white shadow'
                          : 'bg-[#1a1433] text-slate-400 hover:text-white'
                      }`}
                    >
                      {t('HEAD_COACH_TAB')}
                    </button>
                    <button
                      onClick={() => setGameMode('PLAYER_CAREER')}
                      className={`px-3 py-1.5 rounded-xl font-extrabold text-xs transition-all ${
                        gameMode === 'PLAYER_CAREER'
                          ? 'bg-sky-600 text-white shadow'
                          : 'bg-[#1a1433] text-slate-400 hover:text-white'
                      }`}
                    >
                      {t('PLAYER_CAREER_TAB')}
                    </button>
                  </div>

                  <button
                    onClick={() => setViewMode('MENU')}
                    className="text-xs text-slate-400 hover:text-white font-bold"
                  >
                    {t('MAIN_MENU_BACK')}
                  </button>
                </div>

                {/* MANAGER CAREER MODE FORM */}
                {gameMode === 'MANAGER' ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-xs font-black uppercase text-purple-300 block tracking-wider">
                          {t('MANAGER_NAME_SURNAME')}
                        </label>
                        <input
                          type="text"
                          value={managerName}
                          onChange={(e) => setManagerName(e.target.value)}
                          placeholder="Ali Yılmaz"
                          className="w-full bg-[#1c1633] border-2 border-[#392e5c] focus:border-purple-500 rounded-xl px-3 py-2 text-sm font-extrabold text-white focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-black uppercase text-purple-300 block tracking-wider flex items-center gap-1">
                          <Save className="w-3.5 h-3.5 text-emerald-400" /> {t('CAREER_FILE_NAME_OPTIONAL')}
                        </label>
                        <input
                          type="text"
                          value={customSaveName}
                          onChange={(e) => setCustomSaveName(e.target.value)}
                          placeholder={t('CAREER_NAME_PLACEHOLDER')}
                          className="w-full bg-[#1c1633] border-2 border-[#392e5c] focus:border-purple-500 rounded-xl px-3 py-2 text-sm font-extrabold text-white focus:outline-none placeholder-slate-500"
                        />
                      </div>
                    </div>
                  </div>
                ) : (
                  /* PLAYER CAREER CREATION & CUSTOMIZATION FORM */
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-4 bg-[#110d21] p-3.5 rounded-2xl border border-[#2d244c]">
                    
                    {/* Left Side: Avatar Live Renderer */}
                    <div className="md:col-span-4 flex flex-col items-center justify-center p-3 bg-[#181230] rounded-xl border border-[#2f254e] space-y-2">
                      <PlayerAvatarRenderer
                        avatar={avatar}
                        jerseyColor={selectedTeam?.secondaryColor || '#7b2cbf'}
                        size={110}
                      />
                      <div className="text-center">
                        <span className="font-black text-white text-sm block">{playerName || t('STAR_PLAYER')}</span>
                        <span className="text-[11px] text-purple-300 font-bold block">
                          {playerAge} {t('AGE')} • {playerPosition} ({playerRole})
                        </span>
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-extrabold px-2 py-0.5 rounded-full mt-1 inline-block border border-emerald-500/30">
                          {t('RATING')}: 74 OVR ⭐
                        </span>
                      </div>
                    </div>

                    {/* Right Side: Player Details & Customization Options */}
                    <div className="md:col-span-8 space-y-3 max-h-[300px] overflow-y-auto custom-scrollbar pr-1">
                      
                      {/* Name, Save File & Age */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <div className="space-y-1">
                          <label className="text-[10px] font-black uppercase text-sky-300 block">{t('PLAYER_NAME_LABEL')}</label>
                          <input
                            type="text"
                            value={playerName}
                            onChange={(e) => setPlayerName(e.target.value)}
                            className="w-full bg-[#1c1633] border border-[#392e5c] focus:border-sky-500 rounded-lg px-2.5 py-1.5 text-xs font-bold text-white"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-black uppercase text-emerald-400 block">{t('SAVE_FILE_NAME_LABEL')}</label>
                          <input
                            type="text"
                            value={customSaveName}
                            onChange={(e) => setCustomSaveName(e.target.value)}
                            placeholder={t('SAVE_FILE_PLACEHOLDER')}
                            className="w-full bg-[#1c1633] border border-[#392e5c] focus:border-emerald-500 rounded-lg px-2.5 py-1.5 text-xs font-bold text-white placeholder-slate-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-black uppercase text-sky-300 block">{t('AGE_LABEL')}</label>
                          <select
                            value={playerAge}
                            onChange={(e) => setPlayerAge(Number(e.target.value))}
                            className="w-full bg-[#1c1633] border border-[#392e5c] focus:border-sky-500 rounded-lg px-2 py-1.5 text-xs font-bold text-white"
                          >
                            {[17, 18, 19, 20, 21, 22, 23, 24, 25].map(a => (
                              <option key={a} value={a}>{a} {t('AGE')}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {/* Position & Role */}
                      <div className="grid grid-cols-3 gap-2">
                        <div className="space-y-1">
                          <label className="text-[10px] font-black uppercase text-sky-300 block">{t('POSITION')}:</label>
                          <select
                            value={playerPosition}
                            onChange={(e) => {
                              const pos = e.target.value as Position;
                              setPlayerPosition(pos);
                              if (pos === 'FW') setPlayerRole('ST');
                              else if (pos === 'MID') setPlayerRole('CAM');
                              else if (pos === 'DEF') setPlayerRole('CB');
                              else setPlayerRole('GK');
                            }}
                            className="w-full bg-[#1c1633] border border-[#392e5c] focus:border-sky-500 rounded-lg px-2 py-1.5 text-xs font-bold text-white"
                          >
                            <option value="FW">{t('FORWARD')} (FW)</option>
                            <option value="MID">{t('MIDFIELDER')} (MID)</option>
                            <option value="DEF">{t('DEFENDER')} (DEF)</option>
                            <option value="GK">{t('GOALKEEPER')} (GK)</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-black uppercase text-sky-300 block">{t('ROLE')}:</label>
                          <select
                            value={playerRole}
                            onChange={(e) => setPlayerRole(e.target.value)}
                            className="w-full bg-[#1c1633] border border-[#392e5c] focus:border-sky-500 rounded-lg px-2 py-1.5 text-xs font-bold text-white"
                          >
                            {playerPosition === 'FW' && (
                              <>
                                <option value="ST">ST</option>
                                <option value="LW">LW</option>
                                <option value="RW">RW</option>
                              </>
                            )}
                            {playerPosition === 'MID' && (
                              <>
                                <option value="CAM">CAM</option>
                                <option value="CM">CM</option>
                                <option value="CDM">CDM</option>
                              </>
                            )}
                            {playerPosition === 'DEF' && (
                              <>
                                <option value="CB">CB</option>
                                <option value="LB">LB</option>
                                <option value="RB">RB</option>
                              </>
                            )}
                            {playerPosition === 'GK' && (
                              <option value="GK">GK</option>
                            )}
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-black uppercase text-sky-300 block">{t('PREFERRED_FOOT')}</label>
                          <select
                            value={playerFoot}
                            onChange={(e) => setPlayerFoot(e.target.value as 'Sağ' | 'Sol')}
                            className="w-full bg-[#1c1633] border border-[#392e5c] focus:border-sky-500 rounded-lg px-2 py-1.5 text-xs font-bold text-white"
                          >
                            <option value="Sağ">{t('RIGHT_FOOT')}</option>
                            <option value="Sol">{t('LEFT_FOOT')}</option>
                          </select>
                        </div>
                      </div>

                      {/* Customization Sliders / Toggles */}
                      <div className="pt-1 border-t border-[#292045]">
                        <span className="text-[10px] font-black uppercase text-purple-300 block mb-1.5">
                          {t('CUSTOMIZE_AVATAR_HEADER')}
                        </span>
                        
                        <div className="grid grid-cols-2 gap-2 text-[11px]">
                          {/* Skin Tone */}
                          <div className="space-y-1">
                            <label className="text-slate-400 font-bold block">{t('SKIN_TONE')}</label>
                            <select
                              value={avatar.skinTone}
                              onChange={(e) => setAvatar(a => ({ ...a, skinTone: e.target.value as any }))}
                              className="w-full bg-[#1c1633] border border-[#392e5c] rounded-lg px-2 py-1 text-white font-bold"
                            >
                              <option value="Açık">Açık</option>
                              <option value="Buğday">Buğday</option>
                              <option value="Bronz">Bronz</option>
                              <option value="Esmer">Esmer</option>
                              <option value="Koyu">Koyu</option>
                            </select>
                          </div>

                          {/* Hair Style */}
                          <div className="space-y-1">
                            <label className="text-slate-400 font-bold block">{t('HAIR_STYLE')}</label>
                            <select
                              value={avatar.hairStyle}
                              onChange={(e) => setAvatar(a => ({ ...a, hairStyle: e.target.value as any }))}
                              className="w-full bg-[#1c1633] border border-[#392e5c] rounded-lg px-2 py-1 text-white font-bold"
                            >
                              <option value="Fade">Fade</option>
                              <option value="Kısa">Kısa</option>
                              <option value="Bukleli">Bukleli</option>
                              <option value="Uzun">Uzun</option>
                              <option value="Buzz">Buzz</option>
                            </select>
                          </div>

                          {/* Hair Color */}
                          <div className="space-y-1">
                            <label className="text-slate-400 font-bold block">{t('HAIR_COLOR')}</label>
                            <select
                              value={avatar.hairColor}
                              onChange={(e) => setAvatar(a => ({ ...a, hairColor: e.target.value as any }))}
                              className="w-full bg-[#1c1633] border border-[#392e5c] rounded-lg px-2 py-1 text-white font-bold"
                            >
                              <option value="Siyah">Siyah</option>
                              <option value="Kahverengi">Kahverengi</option>
                              <option value="Sarı">Sarı</option>
                              <option value="Kızıl">Kızıl</option>
                              <option value="Gümüş">Gümüş</option>
                            </select>
                          </div>

                          {/* Eye Color */}
                          <div className="space-y-1">
                            <label className="text-slate-400 font-bold block">{t('EYE_COLOR')}</label>
                            <select
                              value={avatar.eyeColor}
                              onChange={(e) => setAvatar(a => ({ ...a, eyeColor: e.target.value as any }))}
                              className="w-full bg-[#1c1633] border border-[#392e5c] rounded-lg px-2 py-1 text-white font-bold"
                            >
                              <option value="Kahverengi">Kahverengi</option>
                              <option value="Mavi">Mavi</option>
                              <option value="Yeşil">Yeşil</option>
                              <option value="Ela">Ela</option>
                            </select>
                          </div>

                          {/* Sleeve / Accessories */}
                          <div className="space-y-1">
                            <label className="text-slate-400 font-bold block">{t('KIT_ACCESSORY')}</label>
                            <select
                              value={avatar.sleeveLength}
                              onChange={(e) => setAvatar(a => ({ ...a, sleeveLength: e.target.value as any }))}
                              className="w-full bg-[#1c1633] border border-[#392e5c] rounded-lg px-2 py-1 text-white font-bold"
                            >
                              <option value="Kısa Kol">Kısa Kol</option>
                              <option value="Uzun Kol">Uzun Kol Forma</option>
                              <option value="Kol Bandı">Kol Bandı & Bileklik</option>
                              <option value="Termal İçlik">Siyah Termal İçlik</option>
                            </select>
                          </div>

                          {/* Boot Color */}
                          <div className="space-y-1">
                            <label className="text-slate-400 font-bold block">{t('BOOT_COLOR')}</label>
                            <select
                              value={avatar.bootColor}
                              onChange={(e) => setAvatar(a => ({ ...a, bootColor: e.target.value as any }))}
                              className="w-full bg-[#1c1633] border border-[#392e5c] rounded-lg px-2 py-1 text-white font-bold"
                            >
                              <option value="Neon Sarı">Neon Sarı 👟</option>
                              <option value="Kırmızı">Alev Kırmızı 👟</option>
                              <option value="Mavi">Elektrik Mavi 👟</option>
                              <option value="Siyah">Klasik Siyah 👟</option>
                              <option value="Beyaz">Saf Beyaz 👟</option>
                              <option value="Altın">Efsane Altın 👟</option>
                            </select>
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>
                )}

                {/* League Tabs, Search & Team Selector Grid */}
                <div className="space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="text-xs font-black uppercase text-purple-300 block tracking-wider flex items-center gap-1.5">
                      <Globe className="w-4 h-4 text-sky-400" />
                      {gameMode === 'MANAGER' ? t('SELECT_TEAM_TO_MANAGE') : t('SELECT_TEAM_TO_JOIN')}
                    </label>

                    {/* RANDOM TEAM SELECTION BUTTON */}
                    <button
                      type="button"
                      onClick={handleRandomTeam}
                      className="px-3 py-1 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:brightness-110 text-slate-950 font-black text-[11px] flex items-center gap-1.5 shadow active:scale-95 transition-all"
                    >
                      <Dices className="w-3.5 h-3.5" /> {t('RANDOM_TEAM_SELECT')} 🎲
                    </button>
                  </div>

                  {/* League Selector Tabs */}
                  <div className="flex items-center gap-1 overflow-x-auto custom-scrollbar pb-1.5 scrollbar-thin">
                    {LEAGUES.map((lg) => {
                      const isActive = selectedLeague === lg.id && !teamSearchQuery;
                      return (
                        <button
                          key={lg.id}
                          type="button"
                          onClick={() => {
                            setSelectedLeague(lg.id);
                            setTeamSearchQuery('');
                          }}
                          className={`px-2.5 py-1 rounded-xl text-[11px] font-black whitespace-nowrap transition-all flex items-center gap-1 border shrink-0 ${
                            isActive
                              ? 'bg-purple-600 border-purple-400 text-white shadow-md shadow-purple-600/30'
                              : 'bg-[#18132e] border-[#2e244d] text-slate-400 hover:text-white hover:bg-[#231b40]'
                          }`}
                        >
                          <span>{lg.flag}</span>
                          <span>{lg.name}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Instant Team Search Input */}
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      placeholder={t('SEARCH_CLUB_PLACEHOLDER')}
                      value={teamSearchQuery}
                      onChange={(e) => setTeamSearchQuery(e.target.value)}
                      className="w-full bg-[#140f29] border border-[#2e234e] focus:border-purple-500 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 font-semibold focus:outline-none"
                    />
                  </div>

                  {/* Team Cards Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-[220px] overflow-y-auto custom-scrollbar p-1">
                    {filteredTeams.map((teamItem) => {
                      const isSelected = teamItem.id === selectedTeamId;
                      const goal = getTeamTargetGoal(teamItem);
                      return (
                        <div
                          key={teamItem.id}
                          onClick={() => setSelectedTeamId(teamItem.id)}
                          className={`p-2.5 rounded-xl border cursor-pointer transition-all flex flex-col justify-between gap-1.5 ${
                            isSelected
                              ? 'bg-purple-600/30 border-purple-400 ring-2 ring-purple-500/50 text-white shadow-lg'
                              : 'bg-[#18132e] border-[#2e244d] text-slate-300 hover:bg-[#231b40]'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <TeamBadge team={teamItem} size="sm" />
                            <div className="min-w-0 flex-1">
                              <span className="block font-black text-xs truncate text-white">{teamItem.name}</span>
                              <span className="block text-[10px] text-emerald-400 font-bold">€{(teamItem.budget / 1_000_000).toFixed(0)}M Bütçe</span>
                            </div>
                            {isSelected && <CheckCircle2 className="w-4 h-4 text-purple-300 shrink-0" />}
                          </div>

                          <div className="pt-1 border-t border-[#2e244d] flex items-center gap-1 text-[10px] font-black text-amber-300">
                            <span className="text-slate-400 font-extrabold shrink-0">🎯 {t('TARGET')}:</span>
                            <span className="truncate">{goal.seasonGoalText}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Selected Team Card Preview & Submit */}
                {(() => {
                  const selectedTeam = ALL_GLOBAL_TEAMS.find(t => t.id === selectedTeamId) || filteredTeams[0];
                  if (!selectedTeam) return null;
                  const goal = getTeamTargetGoal(selectedTeam);

                  return (
                    <div className="p-3 bg-[#130f24] rounded-xl border border-[#2d244c] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-3">
                        <TeamBadge team={selectedTeam} size="md" />
                        <div className="min-w-0">
                          <span className="font-extrabold text-white text-sm block truncate">{selectedTeam.name}</span>
                          <span className="text-[11px] text-slate-400 font-semibold block truncate">
                            {gameMode === 'MANAGER' ? `${t('STADIUM')}: ${selectedTeam.stadiumName || 'Kulüp Stadyumu'}` : t('JOINING_TEAM')} • {t('BUDGET')}: €{(selectedTeam.budget / 1_000_000).toFixed(0)}M
                          </span>
                          <span className="text-[11px] font-black text-amber-300 block truncate mt-0.5">
                            🎯 {t('BOARD_SEASON_GOAL')}: {goal.seasonGoalText}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={handleStartNewSubmit}
                        className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all shrink-0"
                      >
                        <Play className="w-4 h-4 fill-current shrink-0" /> {gameMode === 'MANAGER' ? t('START_CAREER') : t('START_CAREER_SIGN_CONTRACT')}
                      </button>
                    </div>
                  );
                })()}
              </div>
            )}

            {/* VIEW 3: LOAD SAVED CAREER */}
            {viewMode === 'LOAD_CAREER' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-[#2d244c] pb-3">
                  <h3 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
                    <Upload className="w-5 h-5 text-purple-400" /> {t('SAVED_CAREERS_COUNT').replace('{count}', String(allCareersList.length))}
                  </h3>
                  <button
                    onClick={() => setViewMode('MENU')}
                    className="text-xs text-slate-400 hover:text-white font-bold"
                  >
                    {t('RETURN_TO_MAIN_MENU')}
                  </button>
                </div>

                {allCareersList.length === 0 ? (
                  <div className="p-8 text-center bg-[#18132e] rounded-2xl border border-[#2e244d] space-y-3">
                    <p className="text-xs text-slate-400 font-semibold">{t('NO_SAVED_CAREER_FILES')}</p>
                    <button
                      onClick={() => setViewMode('NEW_CAREER')}
                      className="px-4 py-2 rounded-xl bg-purple-600 text-white font-bold text-xs uppercase"
                    >
                      {t('START_NEW_CAREER_BTN')}
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-[360px] overflow-y-auto custom-scrollbar pr-1">
                    {allCareersList.map((career) => {
                      const team = ALL_GLOBAL_TEAMS.find(t => t.id === career.teamId) || allTeams.find(t => t.id === career.teamId) || allTeams[0];
                      const isExpanded = expandedCareerId === career.id;

                      return (
                        <div
                          key={career.id}
                          className="bg-[#18132e] border border-[#2e244d] hover:border-purple-500/50 rounded-2xl overflow-hidden shadow-lg transition-all"
                        >
                          {/* Parent Career Bar (Clicking expands sub-slots) */}
                          <div
                            onClick={() => setExpandedCareerId(isExpanded ? null : career.id)}
                            className="p-3.5 flex items-center justify-between cursor-pointer bg-gradient-to-r from-[#18132e] via-[#211b3e] to-[#18132e] hover:brightness-110 transition-all select-none"
                          >
                            <div className="flex items-center gap-3">
                              <TeamBadge team={team} size="md" />
                              <div>
                                <div className="flex items-center gap-2">
                                  <h4 className="font-extrabold text-white text-sm">
                                    {career.saveName}
                                  </h4>
                                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-950 border border-purple-500/30 text-purple-300 font-bold">
                                    {career.gameMode === 'PLAYER_CAREER' ? t('PLAYER_CAREER_TAB') : t('HEAD_COACH_TAB')}
                                  </span>
                                </div>
                                <p className="text-[11px] text-slate-400 font-medium">
                                  Menajer: <span className="text-white font-bold">{career.managerName}</span> • Takım: <span className="text-purple-300 font-bold">{team?.name || t('DEFAULT_TEAM')}</span>
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                onClick={(e) => handleDeleteEntireCareer(career.id, e)}
                                className="p-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition-all"
                                title={t('DELETE_CAREER_TITLE')}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                              <div className="p-1.5 rounded-xl bg-[#282042] text-slate-300">
                                {isExpanded ? <ChevronUp className="w-4 h-4 text-purple-300" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                              </div>
                            </div>
                          </div>

                          {/* Accordion Content: Sub-slots (Normal Save vs Auto Save) */}
                          {isExpanded && (
                            <div className="p-3 bg-[#120e24] border-t border-[#2a2047] space-y-2 animate-fadeIn">
                              <span className="text-[10px] font-black uppercase text-purple-300 block tracking-wider px-1">
                                📂 {t('SAVE_FILE_OPTIONS')}
                              </span>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                {/* NORMAL / MANUEL KAYIT */}
                                <div className={`p-3 rounded-xl border flex flex-col justify-between gap-2 ${
                                  career.normalSave
                                    ? 'bg-[#1b1535] border-purple-500/40 hover:border-purple-400'
                                    : 'bg-[#15102a]/50 border-[#282042] opacity-50'
                                }`}>
                                  <div className="flex items-center gap-2">
                                    <div className="p-1.5 rounded-lg bg-purple-600/20 border border-purple-500/40 text-purple-300">
                                      <HardDrive className="w-4 h-4" />
                                    </div>
                                    <div>
                                      <span className="font-extrabold text-xs text-white block">{t('MANUAL_SAVE')}</span>
                                      {career.normalSave ? (
                                        <span className="text-[10px] text-purple-300 font-bold block">
                                          {career.normalSave.gameDateStr || t('SEASON_WEEK_FORMAT').replace('{season}', String(career.normalSave.currentSeason)).replace('{week}', String(career.normalSave.currentWeek))}
                                        </span>
                                      ) : (
                                        <span className="text-[10px] text-slate-500 font-medium block">{t('NO_SAVE_FOUND')}</span>
                                      )}
                                    </div>
                                  </div>

                                  {career.normalSave && (
                                    <>
                                      <div className="text-[10px] text-slate-400 flex items-center gap-1 font-semibold">
                                        <Clock className="w-3 h-3 text-slate-500" /> {career.normalSave.saveDate}
                                      </div>

                                      <div className="flex items-center justify-between pt-1 border-t border-[#2d234a]">
                                        <button
                                          onClick={() => handleLoadSlot(career.normalSave!, career.saveName, career.id)}
                                          className="px-3 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase shadow transition-all flex items-center gap-1"
                                        >
                                          <Play className="w-3 h-3 fill-current" /> {t('LOAD')}
                                        </button>
                                        <button
                                          onClick={(e) => handleDeleteSlotItem(career.id, 'NORMAL', e)}
                                          className="p-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20"
                                          title={t('DELETE_MANUAL_SAVE_TITLE')}
                                        >
                                          <Trash2 className="w-3 h-3" />
                                        </button>
                                      </div>
                                    </>
                                  )}
                                </div>

                                {/* OTOMATİK KAYIT */}
                                <div className={`p-3 rounded-xl border flex flex-col justify-between gap-2 ${
                                  career.autoSave
                                    ? 'bg-[#1b1535] border-amber-500/40 hover:border-amber-400'
                                    : 'bg-[#15102a]/50 border-[#282042] opacity-50'
                                }`}>
                                  <div className="flex items-center gap-2">
                                    <div className="p-1.5 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-300">
                                      <Clock className="w-4 h-4" />
                                    </div>
                                    <div>
                                      <span className="font-extrabold text-xs text-white block">{t('AUTO_SAVE')}</span>
                                      {career.autoSave ? (
                                        <span className="text-[10px] text-amber-300 font-bold block">
                                          {career.autoSave.gameDateStr || t('SEASON_WEEK_FORMAT').replace('{season}', String(career.autoSave.currentSeason)).replace('{week}', String(career.autoSave.currentWeek))}
                                        </span>
                                      ) : (
                                        <span className="text-[10px] text-slate-500 font-medium block">{t('NO_SAVE_FOUND')}</span>
                                      )}
                                    </div>
                                  </div>

                                  {career.autoSave && (
                                    <>
                                      <div className="text-[10px] text-slate-400 flex items-center gap-1 font-semibold">
                                        <Clock className="w-3 h-3 text-slate-500" /> {career.autoSave.saveDate}
                                      </div>

                                      <div className="flex items-center justify-between pt-1 border-t border-[#2d234a]">
                                        <button
                                          onClick={() => handleLoadSlot(career.autoSave!, career.saveName, career.id)}
                                          className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase shadow transition-all flex items-center gap-1"
                                        >
                                          <Play className="w-3 h-3 fill-current" /> {t('LOAD')}
                                        </button>
                                        <button
                                          onClick={(e) => handleDeleteSlotItem(career.id, 'AUTO', e)}
                                          className="p-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20"
                                          title={t('DELETE_AUTO_SAVE_TITLE')}
                                        >
                                          <Trash2 className="w-3 h-3" />
                                        </button>
                                      </div>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

          </div>
        )}

        </div>
      </div>
    </div>
  );
};
