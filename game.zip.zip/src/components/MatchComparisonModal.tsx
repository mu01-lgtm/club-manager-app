import React from 'react';
import { Team, Fixture, Player } from '../types';
import { X, Shield, Swords, Award, TrendingUp, Zap, Target, ArrowRight, Activity, Users, Lightbulb } from 'lucide-react';
import { useTranslation } from '../utils/i18n';

interface MatchComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
  homeTeam: Team;
  awayTeam: Team;
  userTeam: Team;
  currentWeek: number;
  fixture?: Fixture;
  onGoToTactics: () => void;
  onStartPreMatch: () => void;
}

export const MatchComparisonModal: React.FC<MatchComparisonModalProps> = ({
  isOpen,
  onClose,
  homeTeam,
  awayTeam,
  userTeam,
  currentWeek,
  fixture,
  onGoToTactics,
  onStartPreMatch
}) => {
  const { t } = useTranslation();

  if (!isOpen) return null;

  const isUserHome = homeTeam.id === userTeam.id;
  const opponentTeam = isUserHome ? awayTeam : homeTeam;

  // Calculate team strengths
  const calcAvg = (team: Team, attr?: 'shooting' | 'defending' | 'passing') => {
    if (!team.players || team.players.length === 0) return 75;
    const starters = team.players.filter(p => p.isStarting);
    const pool = starters.length > 0 ? starters : team.players.slice(0, 11);
    
    if (!attr) {
      return Math.round(pool.reduce((sum, p) => sum + p.overall, 0) / pool.length);
    }
    return Math.round(pool.reduce((sum, p) => sum + p.attributes[attr], 0) / pool.length);
  };

  const homeOvr = calcAvg(homeTeam);
  const awayOvr = calcAvg(awayTeam);

  const homeAtt = calcAvg(homeTeam, 'shooting');
  const awayAtt = calcAvg(awayTeam, 'shooting');

  const homeDef = calcAvg(homeTeam, 'defending');
  const awayDef = calcAvg(awayTeam, 'defending');

  const homeMid = calcAvg(homeTeam, 'passing');
  const awayMid = calcAvg(awayTeam, 'passing');

  const homeValue = homeTeam.players.reduce((sum, p) => sum + p.marketValue, 0);
  const awayValue = awayTeam.players.reduce((sum, p) => sum + p.marketValue, 0);

  // Win Probabilities
  const totalPower = homeOvr + awayOvr;
  const homeWinPct = Math.min(75, Math.max(20, Math.round((homeOvr / totalPower) * 100) + (isUserHome ? 5 : -5)));
  const awayWinPct = Math.min(75, Math.max(20, Math.round((awayOvr / totalPower) * 100) + (isUserHome ? -5 : 5)));
  const drawPct = Math.max(10, 100 - homeWinPct - awayWinPct);

  // Top Danger Players (Prioritize FW and MID, exclude GK and DEF)
  const getTopPlayer = (team: Team) => {
    const dangerousPool = team.players.filter(p => p.position === 'FW' || p.position === 'MID');
    if (dangerousPool.length === 0) {
      return [...team.players].sort((a, b) => b.overall - a.overall)[0];
    }
    return [...dangerousPool].sort((a, b) => {
      const scoreA = a.overall + (a.position === 'FW' ? 3 : 0);
      const scoreB = b.overall + (b.position === 'FW' ? 3 : 0);
      return scoreB - scoreA;
    })[0];
  };

  const opponentStar = getTopPlayer(opponentTeam);

  // Dynamic Match-Specific Tactical Advice Generator
  const getTacticalAdvice = () => {
    const oppForm = (opponentTeam.formation || '4-3-3').trim();
    const isOpponentOffensive = (opponentTeam.tactic || 'ATTACKING') === 'ATTACKING' || (opponentTeam.tactic || 'POSSESSION') === 'POSSESSION' || (isUserHome ? awayAtt > homeDef : homeAtt > awayDef);
    const isOpponentStronger = (isUserHome ? awayOvr > homeOvr + 2 : homeOvr > awayOvr + 2);
    const starPos = opponentStar?.position || 'FW';

    let adviceText = '';
    let recTactic = '';

    const targetStr = starPos === 'FW' ? t('TARGET_BEHIND_CB') : t('TARGET_MIDFIELD_SPACES');

    if (oppForm === '4-3-3' || oppForm === '4-2-3-1') {
      if (isOpponentOffensive) {
        recTactic = t('TACTIC_REC_COUNTER');
        adviceText = t('TACTIC_ADVICE_COUNTER', { team: opponentTeam.name, form: oppForm, target: targetStr });
      } else {
        recTactic = t('TACTIC_REC_HIGH_PRESS');
        adviceText = t('TACTIC_ADVICE_HIGH_PRESS', { team: opponentTeam.name, form: oppForm });
      }
    } else if (oppForm === '3-5-2' || oppForm === '5-3-2' || oppForm === '5-4-1') {
      recTactic = t('TACTIC_REC_WING_CROSS');
      adviceText = t('TACTIC_ADVICE_WING_CROSS', { team: opponentTeam.name, form: oppForm });
    } else if (oppForm === '4-4-2' || oppForm === '4-1-2-1-2') {
      recTactic = t('TACTIC_REC_MIDFIELD_CROWD');
      adviceText = t('TACTIC_ADVICE_MIDFIELD_CROWD', { team: opponentTeam.name, form: oppForm });
    } else if (oppForm === '3-4-3') {
      recTactic = t('TACTIC_REC_WING_COUNTER');
      adviceText = t('TACTIC_ADVICE_WING_COUNTER', { team: opponentTeam.name, form: oppForm });
    } else {
      if (isOpponentStronger) {
        recTactic = t('TACTIC_REC_DISCIPLINED_DEFENSE');
        adviceText = t('TACTIC_ADVICE_DISCIPLINED_DEFENSE', { team: opponentTeam.name, form: oppForm });
      } else {
        recTactic = t('TACTIC_REC_EARLY_GOAL');
        adviceText = t('TACTIC_ADVICE_EARLY_GOAL', { team: opponentTeam.name, form: oppForm });
      }
    }

    if (isUserHome) {
      adviceText += ` ${t('TACTIC_ADVICE_HOME_EXTRA')}`;
    } else {
      adviceText += ` ${t('TACTIC_ADVICE_AWAY_EXTRA')}`;
    }

    return { adviceText, recTactic };
  };

  const { adviceText, recTactic } = getTacticalAdvice();

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-slide-in">
      <div className="bg-[#18142a] border-2 border-[#3d2f63] rounded-3xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] text-slate-100">
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-[#140f26] via-[#1f173b] to-[#140f26] px-5 py-3.5 border-b border-[#312554] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-600/30 border border-purple-500/50 flex items-center justify-center text-purple-300">
              <Swords className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                {t('MATCH_COMPARISON_HEADER', { week: currentWeek })}
              </h2>
              <p className="text-[10px] text-slate-400 font-semibold">
                {t('MATCH_COMPARISON_TITLE', { home: homeTeam.name, away: awayTeam.name })}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-[#281f47] hover:bg-[#392e63] text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 custom-scrollbar">
          
          {/* 1. Team vs Team Display Card */}
          <div className="bg-[#120e21] border border-[#2b2149] rounded-2xl p-4 flex flex-col items-center justify-between gap-4 shadow-xl relative overflow-hidden">
            
            <div className="flex items-center justify-between w-full gap-2">
              {/* Home Team */}
              <div className="flex flex-col items-center text-center flex-1 space-y-1">
                <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr ${homeTeam.badgeColor} flex items-center justify-center text-white font-black text-xl shadow-lg border-2 border-white/20`}>
                  {homeTeam.shortName}
                </div>
                <h3 className="font-black text-sm sm:text-base text-white">{homeTeam.name}</h3>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  {isUserHome ? t('YOUR_CLUB_HOME') : t('HOME_TEAM_LABEL')}
                </span>
                <span className="text-[11px] font-bold text-emerald-400">{homeOvr} {t('OVERALL_POWER')}</span>
              </div>

              {/* Middle VS Badge */}
              <div className="flex flex-col items-center justify-center px-2 shrink-0">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center font-black text-white text-xs shadow-lg animate-pulse">
                  VS
                </div>
                <span className="text-[10px] font-bold text-slate-400 mt-1">{currentWeek}. Hafta</span>
              </div>

              {/* Away Team */}
              <div className="flex flex-col items-center text-center flex-1 space-y-1">
                <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr ${awayTeam.badgeColor} flex items-center justify-center text-white font-black text-xl shadow-lg border-2 border-white/20`}>
                  {awayTeam.shortName}
                </div>
                <h3 className="font-black text-sm sm:text-base text-white">{awayTeam.name}</h3>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {!isUserHome ? t('YOUR_CLUB_AWAY') : t('AWAY_TEAM_LABEL')}
                </span>
                <span className="text-[11px] font-bold text-emerald-400">{awayOvr} {t('OVERALL_POWER')}</span>
              </div>
            </div>

            {/* Head-to-Head Win Percentage Gauge Bar */}
            <div className="w-full space-y-1.5 pt-2 border-t border-[#231b3d]">
              <div className="flex items-center justify-between text-[11px] font-extrabold">
                <span className="text-emerald-400">{t('TEAM_WINS_PCT', { team: homeTeam.shortName, pct: homeWinPct })}</span>
                <span className="text-slate-400">{t('DRAW_PCT', { pct: drawPct })}</span>
                <span className="text-sky-400">{t('TEAM_WINS_PCT', { team: awayTeam.shortName, pct: awayWinPct })}</span>
              </div>
              
              <div className="w-full h-3 rounded-full bg-slate-900 flex overflow-hidden border border-[#332659]">
                <div style={{ width: `${homeWinPct}%` }} className="bg-emerald-500 transition-all duration-500" title={`${homeTeam.name} %${homeWinPct}`} />
                <div style={{ width: `${drawPct}%` }} className="bg-amber-500 transition-all duration-500" title={`Beraberlik %${drawPct}`} />
                <div style={{ width: `${awayWinPct}%` }} className="bg-sky-500 transition-all duration-500" title={`${awayTeam.name} %${awayWinPct}`} />
              </div>
            </div>

          </div>

          {/* 2. Side-by-Side Analytical Comparison Ratings */}
          <div className="bg-[#120e21] border border-[#2b2149] rounded-2xl p-4 space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-purple-400" />
              {t('SQUAD_POWER_COMPARISON')}
            </h4>

            <div className="space-y-2.5 text-xs font-bold">
              
              {/* Attack Comparison */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-emerald-300 font-black">{homeAtt}</span>
                  <span className="text-slate-400 uppercase tracking-wider">{t('ATTACK_LINE')}</span>
                  <span className="text-sky-300 font-black">{awayAtt}</span>
                </div>
                <div className="flex h-2 rounded-full bg-slate-900 overflow-hidden border border-slate-800">
                  <div style={{ width: `${(homeAtt / (homeAtt + awayAtt)) * 100}%` }} className="bg-emerald-500" />
                  <div style={{ width: `${(awayAtt / (homeAtt + awayAtt)) * 100}%` }} className="bg-sky-500" />
                </div>
              </div>

              {/* Midfield Comparison */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-emerald-300 font-black">{homeMid}</span>
                  <span className="text-slate-400 uppercase tracking-wider">{t('MIDFIELD_CONTROL')}</span>
                  <span className="text-sky-300 font-black">{awayMid}</span>
                </div>
                <div className="flex h-2 rounded-full bg-slate-900 overflow-hidden border border-slate-800">
                  <div style={{ width: `${(homeMid / (homeMid + awayMid)) * 100}%` }} className="bg-emerald-500" />
                  <div style={{ width: `${(awayMid / (homeMid + awayMid)) * 100}%` }} className="bg-sky-500" />
                </div>
              </div>

              {/* Defense Comparison */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-emerald-300 font-black">{homeDef}</span>
                  <span className="text-slate-400 uppercase tracking-wider">{t('DEFENSIVE_STRENGTH')}</span>
                  <span className="text-sky-300 font-black">{awayDef}</span>
                </div>
                <div className="flex h-2 rounded-full bg-slate-900 overflow-hidden border border-slate-800">
                  <div style={{ width: `${(homeDef / (homeDef + awayDef)) * 100}%` }} className="bg-emerald-500" />
                  <div style={{ width: `${(awayDef / (homeDef + awayDef)) * 100}%` }} className="bg-sky-500" />
                </div>
              </div>

              {/* Squad Value Comparison */}
              <div className="flex justify-between items-center pt-2 border-t border-[#231b3d] text-xs">
                <span className="text-amber-300 font-extrabold">€{(homeValue / 1_000_000).toFixed(1)}M</span>
                <span className="text-slate-400 font-bold text-[11px]">{t('TOTAL_SQUAD_VALUE')}</span>
                <span className="text-amber-300 font-extrabold">€{(awayValue / 1_000_000).toFixed(1)}M</span>
              </div>

            </div>
          </div>

          {/* 3. 💡 Tactical Recommendations & Scout Insights Box */}
          <div className="bg-gradient-to-r from-[#1d1538] to-[#261a4c] border border-[#3e2f69] rounded-2xl p-4 space-y-3 shadow-lg">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center font-black">
                <Lightbulb className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-black text-white uppercase tracking-wider">
                  {t('RECOMMENDED_MATCH_TACTIC')}
                </h4>
                <p className="text-[10px] text-amber-300 font-bold">{recTactic}</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 font-medium leading-relaxed bg-[#120e21]/70 p-3 rounded-xl border border-[#2d2350]">
              {adviceText}
            </p>

            {opponentStar && (
              <div className="p-2.5 bg-[#120e21] rounded-xl border border-rose-500/30 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-rose-400 text-base">⚠️</span>
                  <div>
                    <span className="text-slate-300 font-bold block text-[11px]">{t('DANGEROUS_OPPONENT_PLAYER')}</span>
                    <span className="text-white font-black">{opponentStar.name} ({opponentStar.position} - {opponentStar.overall} OVR)</span>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 font-extrabold text-[10px]">
                  {t('KEY_MARKING_REQUIRED')}
                </span>
              </div>
            )}
          </div>

        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 bg-[#120e21] border-t border-[#2b2149] flex items-center justify-center shrink-0">
          <button
            onClick={() => {
              onClose();
              onGoToTactics();
            }}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95"
          >
            📋 {t('GO_TO_TACTICS_SCREEN')}
          </button>
        </div>

      </div>
    </div>
  );
};
