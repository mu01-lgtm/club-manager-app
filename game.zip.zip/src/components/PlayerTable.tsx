import React, { useState } from 'react';
import { Player } from '../types';
import { Shirt, ChevronDown, Check, HeartPulse, Activity } from 'lucide-react';
import { useTranslation } from '../utils/i18n';
import { getKnownPlayerName } from '../utils/playerNameUtils';

interface PlayerTableProps {
  players: Player[];
  selectedPlayer: Player | null;
  onSelectPlayer: (player: Player | null) => void;
  onSwapPlayers: (p1: Player, p2: Player) => void;
  onOpenPlayerProfile?: (player: Player) => void;
}

type SortFilterType = 'ROLE' | 'RATING' | 'AGE' | 'STAMINA' | 'VALUE' | 'STATS';

export const PlayerTable: React.FC<PlayerTableProps> = ({
  players,
  selectedPlayer,
  onSelectPlayer,
  onSwapPlayers,
  onOpenPlayerProfile
}) => {
  const { t } = useTranslation();
  const [sortFilter, setSortFilter] = useState<SortFilterType>('ROLE');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // Map players to FMM Position Tag Abbreviations
  const getFmmPosCode = (p: Player, indexInStarter: number, isStarter: boolean) => {
    if (!isStarter) {
      return `${indexInStarter + 1}`; // 1, 2, 3... for subs
    }
    if (p.position === 'GK') return 'KL';
    const role = p.specificRole || p.position;
    if (role === 'RB') return 'BSğ';
    if (role === 'LB') return 'BSl';
    if (role === 'CB') return 'BO';
    if (role === 'CDM' || role === 'CM') return 'OSO';
    if (role === 'CAM') return 'OOS';
    if (role === 'RW' || role === 'RM') return 'OOSSğ';
    if (role === 'LW' || role === 'LM') return 'OOSSl';
    if (role === 'ST' || role === 'CF') return 'PS';
    return 'OSO';
  };

  // Get FMM Role badge code
  const getFmmRoleCode = (p: Player) => {
    if (p.position === 'GK') return 'K';
    const role = p.specificRole || p.position;
    if (role === 'LB' || role === 'RB' || role === 'LWB' || role === 'RWB') return 'SİB';
    if (role === 'CB') return 'SS';
    if (role === 'CDM' || role === 'CM') return 'MO';
    if (role === 'CAM') return 'OOS';
    if (role === 'RW' || role === 'LW' || role === 'LM' || role === 'RM') return 'KF';
    if (role === 'ST' || role === 'CF') return 'PS';
    return 'MO';
  };

  // Get displayed value in right column badge based on selected filter
  const getRightBadgeValue = (p: Player) => {
    switch (sortFilter) {
      case 'RATING':
        return `${(p.lastRating || 6.8).toFixed(1)}`;
      case 'AGE':
        return `${p.age} Yş`;
      case 'STAMINA':
        return `%${p.stamina}`;
      case 'VALUE':
        return `€${((p.marketValue || 5000000) / 1_000_000).toFixed(0)}M`;
      case 'STATS':
        return `👕${p.appearances || 0} ⚽${p.goalsScored || 0} 🅰️${p.assists || 0} 🟨${p.yellowCards || 0} 🟥${p.redCards || 0}`;
      case 'ROLE':
      default:
        return getFmmRoleCode(p);
    }
  };

  // Format name to single known pitch name (no ellipsis or commas)
  const formatFmmName = (fullName: string) => {
    return getKnownPlayerName(fullName);
  };

  // Get position role detail string
  const getFmmPositionRoleText = (p: Player) => {
    if (p.position === 'GK') return 'KL';
    const role = p.specificRole || p.position;
    if (role === 'RB') return 'D/OS Sağ';
    if (role === 'LB') return 'D/KB Sol';
    if (role === 'CB') return 'D M';
    if (role === 'CDM' || role === 'CM') return 'DOS/OS M';
    if (role === 'CAM') return 'OOS M';
    if (role === 'RW' || role === 'RM') return 'OOS SağM';
    if (role === 'LW' || role === 'LM') return 'OOS SolM';
    if (role === 'ST' || role === 'CF') return 'SNT';
    return 'OS M';
  };

  // Sort players within groups or dynamically
  const sortList = (list: Player[]) => {
    if (sortFilter === 'ROLE') return list;
    const sorted = [...list];
    sorted.sort((a, b) => {
      if (sortFilter === 'RATING') return (b.lastRating || 6.5) - (a.lastRating || 6.5);
      if (sortFilter === 'AGE') return b.age - a.age;
      if (sortFilter === 'STAMINA') return b.stamina - a.stamina;
      if (sortFilter === 'VALUE') return (b.marketValue || 0) - (a.marketValue || 0);
      if (sortFilter === 'STATS') return ((b.goalsScored || 0) + (b.assists || 0)) - ((a.goalsScored || 0) + (a.assists || 0));
      return 0;
    });
    return sorted;
  };

  // Group Players
  const starters = sortList(players.filter(p => p.isStarting));
  const bench = sortList(players.filter(p => !p.isStarting && (p.subOrder ?? 99) <= 7));
  const reserves = sortList(players.filter(p => !p.isStarting && (p.subOrder ?? 99) > 7));

  const filterOptions: { id: SortFilterType; label: string }[] = [
    { id: 'ROLE', label: t('FILTER_CURRENT_ROLE') },
    { id: 'RATING', label: t('FILTER_LAST_RATING') },
    { id: 'AGE', label: t('FILTER_AGE') },
    { id: 'STAMINA', label: t('FILTER_STAMINA_MORALE') },
    { id: 'VALUE', label: t('FILTER_VALUE_WAGE') },
    { id: 'STATS', label: '📊 Gol, Asist ve Kartlar' }
  ];

  const currentFilterLabel = filterOptions.find(f => f.id === sortFilter)?.label || t('FILTER_CURRENT_ROLE');

  const renderPlayerRow = (player: Player, idx: number, isStarter: boolean) => {
    const isSelected = selectedPlayer?.id === player.id;
    const posCode = getFmmPosCode(player, idx, isStarter);
    const badgeVal = getRightBadgeValue(player);
    const formattedName = formatFmmName(player.name);
    const roleDetailText = getFmmPositionRoleText(player);
    const injuryWeeksLeft = player.injuryWeeksLeft ?? player.injuryWeeks ?? 2;
    const injuryTotalWeeks = Math.max(injuryWeeksLeft + 1, 4);
    const recoveryProgressPct = Math.min(100, Math.max(15, Math.round(((injuryTotalWeeks - injuryWeeksLeft) / injuryTotalWeeks) * 100)));
    const injuryTypeStr = player.injuryType || t('INJURY_TYPE_MUSCLE');

    return (
      <div
        key={player.id}
        onClick={() => {
          if (selectedPlayer) {
            if (selectedPlayer.id === player.id) {
              onSelectPlayer(null);
            } else {
              onSwapPlayers(selectedPlayer, player);
            }
          } else {
            onSelectPlayer(player);
          }
        }}
        style={{ padding: '4px 6px', marginBottom: '2px' }}
        className={`rounded-lg transition-all cursor-pointer flex flex-col gap-1 border select-none ${
          isSelected
            ? 'bg-amber-500/20 border-amber-400 ring-2 ring-amber-400/40'
            : player.isInjured
            ? 'bg-rose-950/40 border-rose-800/80'
            : 'bg-[#18142a] border-[#292244] hover:bg-[#231b3b]'
        }`}
      >
        <div className="flex items-center justify-between">
          {/* Left Side: Position Badge + Green Circle + Name & Role */}
          <div className="flex items-center gap-1.5 min-w-0 flex-1">
            {/* Position Badge */}
            <div className="w-7 h-5 rounded bg-[#5b21b6] border border-[#7c3aed] flex items-center justify-center font-black text-[9px] text-white shrink-0 shadow-sm">
              {posCode}
            </div>

            {/* Green Condition Indicator Circle */}
            <div className={`w-2.5 h-2.5 rounded-full border border-[#10b981] flex items-center justify-center shrink-0 ${
              player.stamina > 70 ? 'bg-[#10b981]' : 'bg-transparent'
            }`} />

            {/* Player Name and Subtext Role */}
            <div className="min-w-0 flex-1 leading-none">
              <div className="flex items-center gap-1 flex-wrap">
                <span
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onOpenPlayerProfile) {
                      onOpenPlayerProfile(player);
                    }
                  }}
                  title={t('CLICK_PLAYER_PROFILE')}
                  className={`font-extrabold text-[11px] truncate cursor-pointer hover:underline transition-colors ${
                    player.isLoaned
                      ? 'text-amber-400 hover:text-amber-300 font-black'
                      : 'text-white hover:text-purple-300'
                  }`}
                >
                  {formattedName}
                </span>

                {player.isInjured && (
                  <span className="px-1.5 py-0.2 rounded bg-rose-500/30 text-rose-300 text-[8px] font-black shrink-0 flex items-center gap-0.5 border border-rose-500/40">
                    <HeartPulse className="w-2.5 h-2.5 text-rose-400 animate-pulse" />
                    <span>{t('INJURED_LABEL').replace('{weeks}', String(injuryWeeksLeft))}</span>
                  </span>
                )}

                {player.isSuspended && (
                  <span className="px-1.5 py-0.2 rounded bg-red-600/30 text-red-300 text-[8px] font-black shrink-0 flex items-center gap-0.5 border border-red-500/40" title={player.suspensionReason || 'Cezalı'}>
                    <span>🟥</span>
                    <span>Cezalı ({player.suspensionMatchesLeft || 1} maç)</span>
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1.5 text-[8.5px] mt-0.5 font-semibold flex-wrap">
                <span className="text-slate-400">{roleDetailText}</span>
                <span className="text-slate-600">•</span>
                <span className="text-purple-300 font-extrabold" title="Maç">👕 {player.appearances || 0} Maç</span>
                <span className="text-emerald-400 font-extrabold" title="Gol">⚽ {player.goalsScored || 0}</span>
                <span className="text-sky-400 font-extrabold" title="Asist">🅰️ {player.assists || 0}</span>
                <span className="text-amber-400 font-extrabold" title="Sarı Kart">🟨 {player.yellowCards || 0}</span>
                <span className="text-rose-400 font-extrabold" title="Kırmızı Kart">🟥 {player.redCards || 0}</span>
              </div>
            </div>
          </div>

          {/* Right Side: Dynamic Filter Value Badge */}
          <div className="shrink-0 ml-1">
            <div className="px-1.5 py-0.5 rounded bg-[#6d28d9] border border-[#8b5cf6] text-white font-black text-[9px] tracking-wide shadow-sm min-w-[32px] text-center">
              {badgeVal}
            </div>
          </div>
        </div>

        {/* Visual Recovery Progress Bar & Injury Type Icon (if injured) */}
        {player.isInjured && (
          <div className="bg-[#120a14] p-1 rounded-md border border-rose-900/50 flex flex-col gap-1 text-[8.5px] text-rose-300 mt-0.5">
            <div className="flex items-center justify-between gap-1">
              <span className="flex items-center gap-1 font-bold truncate">
                <Activity className="w-3 h-3 text-rose-400 shrink-0" />
                <span className="truncate">{injuryTypeStr}</span>
              </span>
              <span className="font-black text-emerald-400 shrink-0">
                %{recoveryProgressPct} {t('RECOVERED_PROGRESS').replace('{weeks}', String(injuryWeeksLeft))}
              </span>
            </div>
            {/* Progress Bar Track */}
            <div className="w-full bg-rose-950 rounded-full h-1.5 overflow-hidden border border-rose-800/40">
              <div
                className="bg-gradient-to-r from-amber-500 to-emerald-400 h-full rounded-full transition-all duration-500 shadow"
                style={{ width: `${recoveryProgressPct}%` }}
              />
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="bg-[#18142a] border border-[#2d244c] rounded-2xl p-2 sm:p-2.5 shadow-2xl flex flex-col h-full min-h-0 overflow-hidden relative">
      
      {/* Header Bar with 'Kadro' and Clickable 'Şu Anki Rol' Dropdown Menu */}
      <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-[#2d244c] shrink-0 relative z-20" style={{ padding: '4px' }}>
        <div className="flex items-center gap-1.5">
          <Shirt className="w-3.5 h-3.5 text-emerald-400" />
          <h3 className="font-black text-white text-[0.85rem] tracking-wide">{t('SQUAD_TITLE')}</h3>
        </div>

        {/* Dropdown Toggle Button */}
        <div className="relative">
          <button
            onClick={() => setIsDropdownOpen(prev => !prev)}
            className="px-2 py-1 rounded-lg bg-[#5b21b6] hover:bg-[#6d28d9] text-white font-black text-[10px] border border-[#7c3aed] flex items-center gap-1 transition-all cursor-pointer shadow active:scale-95"
          >
            <span>{currentFilterLabel}</span>
            <ChevronDown className={`w-3 h-3 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
          </button>

          {/* Dropdown Menu Popup */}
          {isDropdownOpen && (
            <div className="absolute right-0 top-full mt-1 w-48 bg-[#1f1938] border border-[#3f3068] rounded-xl shadow-2xl z-50 p-1 space-y-0.5 animate-fadeIn">
              {filterOptions.map(opt => {
                const isSelected = sortFilter === opt.id;
                return (
                  <button
                    key={opt.id}
                    onClick={() => {
                      setSortFilter(opt.id);
                      setIsDropdownOpen(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-[10px] font-extrabold flex items-center justify-between transition-colors ${
                      isSelected
                        ? 'bg-purple-600 text-white'
                        : 'text-slate-300 hover:bg-[#2c224e] hover:text-white'
                    }`}
                  >
                    <span>{opt.label}</span>
                    {isSelected && <Check className="w-3 h-3 text-amber-300" />}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Vertical Scrollable Compact FMM Squad List */}
      <div className="flex-1 min-h-0 overflow-y-auto pr-0.5 space-y-2 custom-scrollbar">
        
        {/* Starters Section */}
        <div className="space-y-0.5">
          <div className="text-[9px] font-black text-emerald-400 uppercase tracking-wider px-1">
            {t('STARTING_ELEVEN')} ({starters.length})
          </div>
          <div>
            {starters.map((p, idx) => renderPlayerRow(p, idx, true))}
            {Array.from({ length: Math.max(0, 11 - starters.length) }).map((_, emptyIdx) => {
              const slotIndex = starters.length + emptyIdx;
              return (
                <div
                  key={`table-empty-${slotIndex}`}
                  onClick={() => {
                    if (selectedPlayer) {
                      const tempDummy: Player = {
                        id: `dummy-${slotIndex}`,
                        name: t('EMPTY_SLOT_TITLE').replace('{num}', String(slotIndex + 1)),
                        age: 20,
                        position: 'MID',
                        specificRole: 'OS',
                        overall: 50,
                        stamina: 100,
                        form: 5,
                        marketValue: 0,
                        attributes: { pace: 50, shooting: 50, passing: 50, defending: 50, physical: 50 },
                        isStarting: false
                      };
                      onSwapPlayers(selectedPlayer, tempDummy);
                    }
                  }}
                  className="p-2 mb-0.5 rounded-lg border-2 border-dashed border-emerald-500/40 bg-emerald-950/20 text-emerald-300 flex items-center justify-between text-[10px] font-extrabold cursor-pointer hover:bg-emerald-950/40 transition-all select-none"
                >
                  <span className="flex items-center gap-1.5">
                    <span className="w-5 h-4 rounded bg-emerald-900/60 border border-emerald-500/50 flex items-center justify-center font-black text-[9px] text-emerald-300">
                      +
                    </span>
                    <span>{t('EMPTY_SLOT_TITLE').replace('{num}', String(slotIndex + 1))}</span>
                  </span>
                  <span className="text-[9px] text-emerald-400/90 font-bold">
                    {selectedPlayer ? t('PLACE_SELECTED_PLAYER') : t('CLICK_TO_SELECT_PLAYER')}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bench Section */}
        <div className="space-y-0.5 pt-1">
          <div className="text-[9px] font-black text-amber-300 uppercase tracking-wider px-1">
            {t('BENCH_SUBSTITUTES')} ({bench.length})
          </div>
          <div>
            {bench.map((p, idx) => renderPlayerRow(p, idx, false))}
          </div>
        </div>

        {/* Reserves Section */}
        {reserves.length > 0 && (
          <div className="space-y-0.5 pt-1">
            <div className="text-[9px] font-black text-slate-400 uppercase tracking-wider px-1">
              {t('RESERVES_UNASSIGNED')} ({reserves.length})
            </div>
            <div>
              {reserves.map((p, idx) => renderPlayerRow(p, idx + bench.length, false))}
            </div>
          </div>
        )}

      </div>

    </div>
  );
};


