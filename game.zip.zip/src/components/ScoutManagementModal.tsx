import React from 'react';
import { Scout } from '../types';
import { X, Search, UserCheck, Shield, AlertCircle, DollarSign, Award, Clock, UserPlus } from 'lucide-react';

interface ScoutManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  scouts: Scout[];
  candidateScouts: Scout[];
  userBudget: number;
  onHireScout: (scout: Scout) => void;
  onFireScout: (scoutId: string) => void;
}

export const ScoutManagementModal: React.FC<ScoutManagementModalProps> = ({
  isOpen,
  onClose,
  scouts,
  candidateScouts,
  userBudget,
  onHireScout,
  onFireScout
}) => {
  if (!isOpen) return null;

  const maxScoutLimit = 5;
  const hiredCount = scouts.length;
  const availableScoutsCount = scouts.filter(s => !s.assignedPlayerId).length;
  const busyScoutsCount = scouts.filter(s => s.assignedPlayerId).length;

  return (
    <div className="fixed inset-0 z-[10000] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-[#18132d] border-2 border-[#3d2f6b] rounded-3xl w-full max-w-2xl text-white shadow-2xl animate-slide-in my-auto max-h-[92vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-[#1f183d] via-[#2d2354] to-[#1a1333] border-b border-[#3b2d66] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 text-white shadow-lg border border-amber-400/50">
              <Search className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black text-base sm:text-xl uppercase tracking-tight text-white flex items-center gap-2">
                GÖZLEM & SCOUT EKİBİ
              </h3>
              <p className="text-[11px] sm:text-xs text-amber-300 font-semibold">
                Oyuncu Potansiyel Raporları ve Scout İşe Alım Merkezi
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-[#2b214c] hover:bg-rose-600 text-slate-300 hover:text-white font-black text-sm flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status Counter Bar */}
        <div className="grid grid-cols-3 bg-[#120e24] p-3 border-b border-[#2d2250] text-center text-xs font-bold shrink-0 gap-2">
          <div className="p-2 rounded-xl bg-[#1d1738] border border-[#34295d]">
            <span className="text-[10px] text-slate-400 block uppercase">Mevcut Gözlemciler</span>
            <span className="text-sm font-black text-amber-300">{hiredCount} / {maxScoutLimit}</span>
          </div>
          <div className="p-2 rounded-xl bg-[#1d1738] border border-[#34295d]">
            <span className="text-[10px] text-slate-400 block uppercase">Boştaki Gözlemci</span>
            <span className="text-sm font-black text-emerald-400">{availableScoutsCount}</span>
          </div>
          <div className="p-2 rounded-xl bg-[#1d1738] border border-[#34295d]">
            <span className="text-[10px] text-slate-400 block uppercase">Gözlemdeki Oyuncu</span>
            <span className="text-sm font-black text-sky-400">{busyScoutsCount}</span>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 overflow-y-auto custom-scrollbar space-y-5 flex-1">
          
          {/* SECTION 1: HIRED SCOUTS */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-extrabold uppercase text-amber-400 tracking-wider flex items-center gap-1.5">
                <UserCheck className="w-4 h-4" /> KADRODAKİ GÖZLEMCİLER ({hiredCount}/{maxScoutLimit})
              </h4>
              <span className="text-[10px] text-slate-400">Her gözlemci aynı anda 1 oyuncuyu izleyebilir</span>
            </div>

            {scouts.length === 0 ? (
              <div className="p-4 rounded-2xl bg-[#120e24] border border-dashed border-[#2d2250] text-center text-xs text-slate-400">
                Kulübünüzde hiç gözlemci yok! Aşağıdaki listeden gözlemci işe alabilirsiniz.
              </div>
            ) : (
              <div className="space-y-2">
                {scouts.map(scout => (
                  <div
                    key={scout.id}
                    className="p-3 rounded-2xl bg-[#151029] border border-[#2e2350] hover:border-amber-500/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 transition-all"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-black text-sm text-white">{scout.name}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-[#251b47] text-slate-300 font-bold">
                          {scout.nationality}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-slate-300 font-semibold">
                        <span>⭐ Yetenek: <strong className="text-amber-300">{scout.judgmentRating}/20</strong></span>
                        <span>•</span>
                        <span>Maaş: <strong className="text-sky-300">€{(scout.weeklyWage).toLocaleString()}/hafta</strong></span>
                      </div>
                      
                      {/* Status indicator */}
                      <div className="text-[11px] pt-0.5">
                        {scout.assignedPlayerId ? (
                          <span className="inline-flex items-center gap-1 text-sky-400 font-bold bg-sky-950/50 px-2 py-0.5 rounded-lg border border-sky-800/60">
                            <Clock className="w-3 h-3" /> Gözlemde: {scout.assignedPlayerName || 'Oyuncu'} ({scout.assignedDaysLeft} gün kaldı)
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-emerald-400 font-bold bg-emerald-950/50 px-2 py-0.5 rounded-lg border border-emerald-800/60">
                            🟢 Boşta - Göreve Hazır
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => onFireScout(scout.id)}
                      className="px-3 py-1.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/80 text-rose-300 border border-rose-800/50 text-xs font-bold transition-colors shrink-0"
                    >
                      Sözleşmeyi Feshet
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* SECTION 2: CANDIDATE SCOUTS FOR HIRE */}
          <div className="space-y-2.5 pt-2 border-t border-[#2d2250]">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-extrabold uppercase text-emerald-400 tracking-wider flex items-center gap-1.5">
                <UserPlus className="w-4 h-4" /> BOŞTAKİ GÖZLEMCİ ADAYLARI (İŞE ALIM)
              </h4>
              <span className="text-[10px] text-slate-400">Maksimum Sınır: 5 Gözlemci</span>
            </div>

            <div className="space-y-2">
              {candidateScouts.map(candidate => {
                const isLimitReached = hiredCount >= maxScoutLimit;
                return (
                  <div
                    key={candidate.id}
                    className="p-3 rounded-2xl bg-[#120e24] border border-[#2b204c] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-200">{candidate.name}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-[#21183f] text-slate-400 font-semibold">
                          {candidate.nationality}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-slate-400 font-semibold">
                        <span>Gözlem Kalitesi: <strong className="text-amber-300">{candidate.judgmentRating}/20</strong></span>
                        <span>•</span>
                        <span>Haftalık Maaş: <strong className="text-emerald-400">€{(candidate.weeklyWage).toLocaleString()}</strong></span>
                      </div>
                    </div>

                    <button
                      disabled={isLimitReached}
                      onClick={() => onHireScout(candidate)}
                      className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow ${
                        isLimitReached
                          ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                          : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white border border-emerald-400/50'
                      }`}
                    >
                      {isLimitReached ? 'Sınır Dolu (Maks 5)' : `İşe Al (€${(candidate.weeklyWage).toLocaleString()}/hf)`}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-3 bg-[#120e24] border-t border-[#2d2250] flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-2xl bg-[#7b2cbf] hover:bg-[#8d35d8] text-white font-extrabold text-xs uppercase tracking-wider shadow"
          >
            Tamam
          </button>
        </div>

      </div>
    </div>
  );
};
