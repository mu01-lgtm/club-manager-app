import React from 'react';
import { Globe, Check, X, Sparkles } from 'lucide-react';
import { useTranslation, SUPPORTED_LANGUAGES, LanguageCode } from '../utils/i18n';

interface LanguageModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LanguageModal: React.FC<LanguageModalProps> = ({ isOpen, onClose }) => {
  const { language, setLanguage, t } = useTranslation();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] bg-black/80 backdrop-blur-md flex items-center justify-center p-2.5 sm:p-4 select-none animate-fadeIn">
      
      {/* Modern Tactical Glassmorphic Card Container */}
      <div className="w-full max-w-[340px] sm:max-w-sm bg-[#161228]/95 border-2 border-[#3d3163] hover:border-purple-500/60 rounded-2xl p-3.5 sm:p-4 shadow-[0_0_40px_rgba(123,44,191,0.35)] relative overflow-hidden space-y-3 my-auto max-h-[85vh] flex flex-col">
        
        {/* Top Glowing Gradient Accent */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-500 via-sky-400 via-amber-400 to-indigo-500" />

        {/* Header & Close Button */}
        <div className="flex items-center justify-between border-b border-[#2e2450] pb-2.5 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-purple-900/40 shrink-0">
              <Globe className="w-4 h-4 text-sky-300" />
            </div>
            <div>
              <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider flex items-center gap-1">
                {t('SELECT_LANGUAGE')}
              </h3>
              <p className="text-[9px] text-purple-300 font-bold uppercase tracking-widest">
                {t('SELECT_GAME_LANGUAGE')}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-full bg-[#241c3e] hover:bg-[#322854] text-slate-400 hover:text-white transition-all active:scale-95 border border-[#372b5c]"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Language Options Grid */}
        <div className="space-y-1.5 max-h-[220px] sm:max-h-[280px] overflow-y-auto custom-scrollbar pr-1 flex-1">
          {SUPPORTED_LANGUAGES.map((langOption) => {
            const isActive = language === langOption.code;

            return (
              <button
                key={langOption.code}
                onClick={() => {
                  setLanguage(langOption.code);
                  setTimeout(onClose, 200);
                }}
                className={`w-full p-2.5 rounded-xl border transition-all flex items-center justify-between group active:scale-[0.98] ${
                  isActive
                    ? 'bg-gradient-to-r from-[#2a1c4e] via-[#21163e] to-[#1a1233] border-purple-400 shadow-md shadow-purple-900/40'
                    : 'bg-[#1b1532] hover:bg-[#251d45] border-[#2f2552] hover:border-purple-500/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-xl sm:text-2xl shrink-0 filter drop-shadow">
                    {langOption.flag}
                  </span>
                  <div className="text-left">
                    <span className={`block font-black text-xs ${isActive ? 'text-white' : 'text-slate-200 group-hover:text-white'}`}>
                      {langOption.nativeName}
                    </span>
                    <span className="text-[9px] font-bold text-slate-400 group-hover:text-purple-300 block">
                      {langOption.name} ({langOption.code})
                    </span>
                  </div>
                </div>

                {isActive ? (
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-400/60 text-emerald-300 text-[10px] font-black">
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{t('ACTIVE')}</span>
                  </div>
                ) : null}
              </button>
            );
          })}
        </div>

        {/* Bottom Helper Info */}
        <div className="p-2 rounded-xl bg-[#120e24] border border-[#271d47] text-center shrink-0">
          <p className="text-[9.5px] text-slate-400 font-semibold flex items-center justify-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400 shrink-0" />
            <span>{t('LANGUAGE_APPLIED_INSTANTLY')}</span>
          </p>
        </div>

      </div>
    </div>
  );
};
