import React from 'react';
import { Users, Trophy, ShoppingCart, Dumbbell, CalendarDays, Home, Newspaper, UserCheck } from 'lucide-react';
import { GameMode } from '../types';
import { useTranslation } from '../utils/i18n';

export type TabType = 'HOME' | 'NEWS' | 'MY_PLAYER' | 'TACTICS' | 'TRANSFERS' | 'STANDINGS' | 'TRAINING' | 'FIXTURES';

interface NavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  unplayedMatchesCount?: number;
  gameMode?: GameMode;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onTabChange,
  gameMode = 'MANAGER'
}) => {
  const { t } = useTranslation();

  const tabs = gameMode === 'PLAYER_CAREER' ? [
    {
      id: 'HOME' as TabType,
      label: t('HOME'),
      icon: Home,
    },
    {
      id: 'MY_PLAYER' as TabType,
      label: t('MY_PLAYER'),
      icon: UserCheck,
      badge: 'YILDIZ'
    },
    {
      id: 'NEWS' as TabType,
      label: t('NEWS'),
      icon: Newspaper,
    },
    {
      id: 'STANDINGS' as TabType,
      label: t('STANDINGS'),
      icon: Trophy
    },
    {
      id: 'FIXTURES' as TabType,
      label: t('FIXTURES'),
      icon: CalendarDays
    }
  ] : [
    {
      id: 'HOME' as TabType,
      label: t('HOME'),
      icon: Home,
    },
    {
      id: 'NEWS' as TabType,
      label: t('NEWS'),
      icon: Newspaper,
      badge: 'YENİ'
    },
    {
      id: 'TACTICS' as TabType,
      label: t('TACTICS'),
      icon: Users,
      badge: '11+5'
    },
    {
      id: 'TRANSFERS' as TabType,
      label: t('TRANSFERS'),
      icon: ShoppingCart
    },
    {
      id: 'STANDINGS' as TabType,
      label: t('STANDINGS'),
      icon: Trophy
    },
    {
      id: 'TRAINING' as TabType,
      label: t('TRAINING'),
      icon: Dumbbell
    },
    {
      id: 'FIXTURES' as TabType,
      label: t('FIXTURES'),
      icon: CalendarDays
    }
  ];

  const mobileBottomTabs = gameMode === 'PLAYER_CAREER' ? [
    { id: 'HOME' as TabType, label: t('HOME'), icon: Home },
    { id: 'MY_PLAYER' as TabType, label: t('MY_PLAYER'), icon: UserCheck },
    { id: 'NEWS' as TabType, label: t('NEWS'), icon: Newspaper },
    { id: 'STANDINGS' as TabType, label: t('STANDINGS'), icon: Trophy },
    { id: 'FIXTURES' as TabType, label: t('FIXTURES'), icon: CalendarDays },
  ] : [
    { id: 'HOME' as TabType, label: t('HOME'), icon: Home },
    { id: 'NEWS' as TabType, label: t('NEWS'), icon: Newspaper },
    { id: 'TACTICS' as TabType, label: t('TACTICS'), icon: Users },
    { id: 'TRANSFERS' as TabType, label: t('TRANSFERS'), icon: ShoppingCart },
    { id: 'STANDINGS' as TabType, label: t('STANDINGS'), icon: Trophy },
  ];

  return (
    <>
      {/* Mobile Fixed Bottom Navigation Bar (Bottom Tab Bar) - Player Career Only */}
      {gameMode === 'PLAYER_CAREER' && (
        <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 border-t border-slate-800/90 backdrop-blur-lg px-2 py-1 shadow-2xl">
          <div className="grid grid-cols-5 gap-1 items-center max-w-md mx-auto">
            {mobileBottomTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;

              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl transition-all touch-manipulation min-h-[48px] ${
                    isActive
                      ? 'text-emerald-400 bg-emerald-500/15 font-black scale-105'
                      : 'text-slate-400 hover:text-slate-200 font-semibold'
                  }`}
                >
                  <Icon className={`w-5 h-5 mb-0.5 ${isActive ? 'text-emerald-400 drop-shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'text-slate-400'}`} />
                  <span className="text-[10px] tracking-tight truncate w-full text-center">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </>
  );
};
