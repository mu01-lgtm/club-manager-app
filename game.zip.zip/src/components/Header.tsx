import React, { useState } from 'react';
import { Team, ManagerProfile } from '../types';
import { DollarSign, Calendar, User, Play, ChevronRight, Save, FolderOpen, Globe, Clock } from 'lucide-react';
import { getSimulatedRealDate } from '../utils/dateHelper';
import { useTranslation } from '../utils/i18n';
import { LanguageModal } from './LanguageModal';
import { TeamBadge } from './TeamBadge';

interface HeaderProps {
  currentTeam: Team;
  opponentTeam?: Team;
  manager: ManagerProfile;
  currentWeek: number;
  currentSeason: number;
  currentDayIndex?: number;
  currentDayName?: string;
  isMatchDay?: boolean;
  isAdvancingDay?: boolean;
  allTeams: Team[];
  onSelectTeam: (teamId: string) => void;
  onAdvanceDay: () => void;
  onOpenPreMatch: () => void;
  onSaveGame: () => void;
  onOpenCareerMenu: () => void;
  onOpenWorldScout?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTeam,
  opponentTeam,
  manager,
  currentWeek,
  currentSeason,
  currentDayIndex = 0,
  currentDayName = 'Pazartesi',
  isMatchDay = false,
  isAdvancingDay = false,
  allTeams,
  onSelectTeam,
  onAdvanceDay,
  onOpenPreMatch,
  onSaveGame,
  onOpenCareerMenu,
  onOpenWorldScout
}) => {
  const { t, language } = useTranslation();
  const [showLangModal, setShowLangModal] = useState<boolean>(false);
  const realSimDate = getSimulatedRealDate(currentSeason, currentWeek, currentDayIndex, language);
  const simulatedDateStr = realSimDate.dateStr;

  return (
    <header className="bg-[#151224] border-b border-[#282142] text-white sticky top-0 z-20 shadow-xl w-full shrink-0">
      <div className="px-2 sm:px-4 py-1.5 flex flex-nowrap items-center justify-between gap-1 sm:gap-2.5 w-full">
        
        {/* Left Section: Locked Team Badge & Manager Name */}
        <div className="flex items-center gap-1 sm:gap-2 flex-nowrap min-w-0 shrink">
          
          {/* Active Team Badge (Locked to User's Career Team) */}
          <div className="flex items-center gap-1.5 bg-[#1f1938] border border-[#342b5c] px-2 py-1 rounded-xl shadow shrink min-w-0">
            <TeamBadge team={currentTeam} size="xs" className="shrink-0" />
            <span className="font-extrabold text-[10px] sm:text-[11px] text-white truncate max-w-[80px] xs:max-w-[110px] sm:max-w-[140px] md:max-w-[180px] lg:max-w-[220px]" title={currentTeam?.name}>
              {currentTeam?.name || 'Takım'}
            </span>
          </div>

          {/* Manager Badge (Hidden on small screens to prioritize match day button) */}
          <div className="hidden md:flex bg-[#1f1938] border border-[#342b5c] px-2.5 py-1 rounded-xl items-center gap-1.5 text-[11px] shrink-0">
            <User className="w-3.5 h-3.5 text-purple-400 shrink-0" />
            <span className="font-black text-slate-200 truncate max-w-[110px] lg:max-w-none">
              {manager?.name || 'Teknik Direktör'}
            </span>
          </div>

          {/* Career Menu / Load Button */}
          <button
            onClick={onOpenCareerMenu}
            title="Kariyer Menüsü / Yeni Oyun / Kayıt Yükle"
            className="p-1 sm:p-1.5 rounded-xl bg-[#1f1938] hover:bg-[#2c244b] text-slate-300 hover:text-white border border-[#342b5c] transition-all active:scale-95 shrink-0 flex items-center gap-1 text-[10px] sm:text-[11px] font-bold"
          >
            <FolderOpen className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="hidden xl:inline text-[10px]">{t('CAREER_MENU')}</span>
          </button>

          {/* Save Game Button (Kariyeri Kaydet - Icon only) */}
          <button
            onClick={onSaveGame}
            className="p-1 sm:p-1.5 rounded-xl bg-[#1a2e26] hover:bg-[#233e33] border border-emerald-500/40 text-emerald-400 hover:text-emerald-300 font-extrabold shadow transition-all active:scale-95 shrink-0 flex items-center justify-center"
            title={t('SAVE_GAME')}
          >
            <Save className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
          </button>

          {/* Language Button (Modern Tactical Dropdown Trigger) */}
          <button
            onClick={() => setShowLangModal(true)}
            className="p-1 sm:p-1.5 px-2 rounded-xl bg-[#1f1938] hover:bg-[#2d2350] border border-[#382c63] text-purple-300 hover:text-white font-extrabold text-[10px] sm:text-[11px] shadow transition-all active:scale-95 shrink-0 flex items-center gap-1"
            title="Oyun Dilini Değiştir"
          >
            <Globe className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            <span>{language}</span>
          </button>

        </div>

        {/* Right Section: World Explorer Button, Compact Date Display & İLERLE / MAÇ GÜNÜ Button */}
        <div className="flex items-center gap-1 sm:gap-2 flex-nowrap shrink-0 ml-auto">
          
          {/* Globe Button (Dünya Haritası ve Kıta Kaşifi) */}
          <button
            onClick={onOpenWorldScout}
            className="p-1 sm:p-1.5 rounded-xl bg-[#1f1938] hover:bg-[#2d2350] border border-[#382c63] text-sky-300 hover:text-sky-200 shadow transition-all active:scale-95 shrink-0 flex items-center justify-center gap-1 group"
            title={`${t('WORLD_SCOUT_TITLE')}: ${t('WORLD_SCOUT_DESC')}`}
          >
            <Globe className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-sky-400 group-hover:rotate-12 transition-transform" />
            <span className="hidden md:inline text-[10px] font-black text-sky-300">{t('WORLD')}</span>
          </button>

          {/* Compact Simulated Game Date Display & Transfer Deadline Badge */}
          <div className="flex items-center gap-1.5 shrink-0">
            {realSimDate.transferWindowDeadlineDays !== undefined && (
              <div className="hidden lg:flex items-center gap-1 bg-amber-500/20 border border-amber-500/40 px-2 py-0.5 rounded-xl text-[10px] font-black text-amber-300 animate-pulse">
                <Clock className="w-3 h-3 text-amber-400 shrink-0" />
                <span>{t('TRANSFER_DEADLINE_TEXT')} {realSimDate.transferWindowDeadlineDays === 0 ? t('LAST_24_HOURS') : t('DAYS_LEFT').replace('{count}', String(realSimDate.transferWindowDeadlineDays))}</span>
              </div>
            )}

            <div className="flex items-center gap-1 bg-[#1f1938] border border-[#342b5c] px-1.5 sm:px-2 py-1 rounded-xl text-[9px] sm:text-[11px] shrink-0">
              <Calendar className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-sky-400 shrink-0" />
              <span className="font-black text-sky-300 whitespace-nowrap text-[9px] sm:text-[11px]">{simulatedDateStr}</span>
              <span className="text-amber-400 font-extrabold text-[9px] hidden xs:inline">({realSimDate.dayName})</span>
            </div>
          </div>

          {/* Dynamic "İLERLE" or "MAÇ GÜNÜ" Button */}
          {isMatchDay ? (
            <button
              onClick={onOpenPreMatch}
              className="px-2.5 sm:px-4 py-1 sm:py-1.5 rounded-xl bg-gradient-to-r from-purple-700 via-purple-600 to-indigo-600 hover:brightness-110 active:scale-95 transition-all text-white font-black text-[10px] sm:text-xs uppercase tracking-wider flex items-center gap-1 sm:gap-1.5 shadow-lg shadow-purple-600/30 border border-purple-400/40 touch-manipulation shrink-0 animate-pulse"
              title="Maç Günü Kadro ve Ön İzleme Ekranı"
            >
              <Play className="w-3 h-3 sm:w-3.5 sm:h-3.5 fill-current shrink-0 text-amber-200" />
              <span>{t('MATCH_DAY')}</span>
              <ChevronRight className="w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0" />
            </button>
          ) : (
            <button
              onClick={onAdvanceDay}
              disabled={isAdvancingDay}
              className={`px-2.5 sm:px-4 py-1 sm:py-1.5 rounded-xl bg-gradient-to-r from-[#7b2cbf] via-[#9d4edd] to-[#c77dff] hover:brightness-110 active:scale-95 transition-all text-white font-black text-[10px] sm:text-xs uppercase tracking-wider flex items-center gap-1 sm:gap-1.5 shadow-md shadow-purple-600/30 touch-manipulation shrink-0 group ${
                isAdvancingDay ? 'opacity-50 cursor-not-allowed animate-pulse' : ''
              }`}
              title="Bir Sonraki Güne İlerle"
            >
              <Play className="w-3 h-3 sm:w-3.5 sm:h-3.5 fill-current shrink-0 group-hover:translate-x-0.5 transition-transform" />
              <span>{isAdvancingDay ? t('ADVANCING') : t('ADVANCE')}</span>
              <ChevronRight className="w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0 group-hover:translate-x-0.5 transition-transform" />
            </button>
          )}

        </div>

      </div>

      {/* Language Selection Modal */}
      <LanguageModal isOpen={showLangModal} onClose={() => setShowLangModal(false)} />
    </header>
  );
};


