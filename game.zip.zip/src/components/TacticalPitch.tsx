import React from 'react';
import { Team, Player, FormationType, TacticType } from '../types';
import { Sparkles, Check, Edit2, Shield, Zap, Target, Sliders, Heart, Filter, HelpCircle, Settings, Play, ChevronRight, Activity, Eye, Maximize2, ZoomIn, ZoomOut, X, AlertTriangle, Users } from 'lucide-react';
import { CustomSelect, CustomSelectOption } from './CustomSelect';
import { PlayerTable } from './PlayerTable';
import { TeamBadge } from './TeamBadge';
import { useTranslation } from '../utils/i18n';
import { calculatePlayerEffectiveOverall } from '../utils/matchEngine';
import { FORMATION_COORDINATES } from '../data/initialData';
import { getKnownPlayerName } from '../utils/playerNameUtils';

interface TacticalPitchProps {
  team: Team;
  selectedPlayer: Player | null;
  onSelectPlayer: (player: Player | null) => void;
  onSwapPlayers: (p1: Player, p2: Player) => void;
  onChangeFormation: (formation: FormationType) => void;
  onChangeTactic: (tactic: TacticType) => void;
  onUpdateTacticalDetails?: (details: Team['tacticalDetails']) => void;
  activeSubMenu?: string;
  isRecommendedPreviewActive?: boolean;
  onGoToRecommendedLineup?: () => void;
  onSaveRecommendedLineup?: () => void;
  onCancelRecommendedLineup?: () => void;
  onOpenPlayerProfile?: (player: Player) => void;
  hideTeamBalance?: boolean;
  hidePlayerDetailBox?: boolean;
  isInMatchTactics?: boolean;
}

export const TacticalPitch: React.FC<TacticalPitchProps> = ({
  team,
  selectedPlayer: propSelectedPlayer,
  onSelectPlayer,
  onSwapPlayers,
  onChangeFormation,
  onChangeTactic,
  onUpdateTacticalDetails,
  activeSubMenu: externalSubMenu,
  isRecommendedPreviewActive,
  onGoToRecommendedLineup,
  onSaveRecommendedLineup,
  onCancelRecommendedLineup,
  onOpenPlayerProfile,
  hideTeamBalance,
  hidePlayerDetailBox,
  isInMatchTactics
}) => {
  const { t, language } = useTranslation();

  // 11 Fixed Slot lineup derivation for exact pitch positions
  const starterSlots: (Player | null)[] = React.useMemo(() => {
    const slots: (Player | null)[] = new Array(11).fill(null);
    const assigned = new Set<string>();

    // 1. Explicit starterIndex (0..10)
    team.players.forEach(p => {
      if (p.isStarting && p.starterIndex !== undefined && p.starterIndex >= 0 && p.starterIndex < 11) {
        if (!slots[p.starterIndex]) {
          slots[p.starterIndex] = p;
          assigned.add(p.id);
        }
      }
    });

    // 2. Any other isStarting players without starterIndex or if slots are missing
    team.players.forEach(p => {
      if (p.isStarting && !assigned.has(p.id)) {
        const nextEmpty = slots.findIndex(s => s === null);
        if (nextEmpty !== -1) {
          slots[nextEmpty] = p;
          assigned.add(p.id);
        }
      }
    });

    return slots;
  }, [team.players]);

  const starters = React.useMemo(() => {
    return starterSlots.filter((p): p is Player => p !== null);
  }, [starterSlots]);

  const nonStarters = React.useMemo(() => {
    const starterIdSet = new Set(starterSlots.filter((p): p is Player => p !== null).map(p => p.id));
    return team.players.filter(p => !starterIdSet.has(p.id));
  }, [team.players, starterSlots]);

  const benchPlayers = nonStarters.slice(0, 7);
  const reservePlayers = isInMatchTactics ? [] : nonStarters.slice(7);
  const reserves = nonStarters;

  // Active selected player (Null when deselected so no automatic GK selection occurs)
  const activeSelectedPlayer = propSelectedPlayer || null;

  // Role Selection Modal State
  const [roleSelectingPlayer, setRoleSelectingPlayer] = React.useState<Player | null>(null);
  const [selectedEmptySlotIdx, setSelectedEmptySlotIdx] = React.useState<number | null>(null);
  const longPressTimerRef = React.useRef<NodeJS.Timeout | null>(null);
  const isLongPressTriggeredRef = React.useRef(false);
  const lastTapRef = React.useRef<{ id: string; time: number } | null>(null);

  const handlePlayerInteraction = (player: Player, actionType: 'select' | 'swap_or_select') => {
    const now = Date.now();
    if (lastTapRef.current && lastTapRef.current.id === player.id && now - lastTapRef.current.time < 400) {
      lastTapRef.current = null;
      onOpenPlayerProfile?.(player);
      return;
    }
    lastTapRef.current = { id: player.id, time: now };

    if (selectedEmptySlotIdx !== null) {
      onSwapPlayers(player, { id: `empty-slot-${selectedEmptySlotIdx}`, name: 'Boş Slot', isStarting: false } as Player);
      setSelectedEmptySlotIdx(null);
      onSelectPlayer(null);
      return;
    }

    if (actionType === 'swap_or_select') {
      if (propSelectedPlayer) {
        if (propSelectedPlayer.id === player.id) {
          // Clicking same player deselects / cancels selection
          onSelectPlayer(null);
        } else {
          onSwapPlayers(propSelectedPlayer, player);
          onSelectPlayer(null);
        }
      } else {
        onSelectPlayer(player);
      }
    } else {
      if (propSelectedPlayer?.id === player.id) {
        // Clicking same player in squad table deselects / cancels selection
        onSelectPlayer(null);
      } else {
        onSelectPlayer(player);
      }
    }
  };

  const handlePitchPlayerPointerDown = (player: Player) => {
    isLongPressTriggeredRef.current = false;
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);
    longPressTimerRef.current = setTimeout(() => {
      isLongPressTriggeredRef.current = true;
      setRoleSelectingPlayer(player);
    }, 400);
  };

  const handlePitchPlayerPointerUp = (player: Player) => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    if (!isLongPressTriggeredRef.current) {
      handlePlayerInteraction(player, 'swap_or_select');
    }
  };

  const handlePitchPlayerPointerLeave = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const [internalSubMenu, setInternalSubMenu] = React.useState(externalSubMenu || 'Diziliş');

  React.useEffect(() => {
    if (externalSubMenu) {
      setInternalSubMenu(externalSubMenu);
    }
  }, [externalSubMenu]);

  const activeSubMenu = internalSubMenu;

  const [viewMode, setViewMode] = React.useState<'pitch' | 'table'>('pitch');
  const [pitchCamera, setPitchCamera] = React.useState<'overhead' | 'perspective' | 'standard'>('standard');
  const [benchTab, setBenchTab] = React.useState<'Yedekler' | 'Rezervler'>('Yedekler');
  const [squadViewTab, setSquadViewTab] = React.useState<'STARTERS' | 'BENCH' | 'RESERVES'>('STARTERS');
  const [specialistModalType, setSpecialistModalType] = React.useState<'captain' | 'penalty' | 'freekick' | 'corner' | null>(null);
  const [benchSwapModalPlayer, setBenchSwapModalPlayer] = React.useState<Player | null>(null);
  const [reservePickerModalForBench, setReservePickerModalForBench] = React.useState<Player | null>(null);
  const [benchPickerModalForReserve, setBenchPickerModalForReserve] = React.useState<Player | null>(null);
  const [swapSearchQuery, setSwapSearchQuery] = React.useState('');
  const [swapPositionFilter, setSwapPositionFilter] = React.useState<'ALL' | 'GK' | 'DEF' | 'MID' | 'FW'>('ALL');
  
  // Starting 11 Table Starters
  const displayedStarters = starters;

  // Interactive Tactical Settings State
  const [playStyle, setPlayStyle] = React.useState({
    passing: team.tacticalDetails?.passing || 'Kısa Pas',
    tempo: team.tacticalDetails?.tempo || 'Hızlı',
    width: team.tacticalDetails?.width || 'Dengeli',
    counter: team.tacticalDetails?.counter || 'Açık',
    pressZone: team.tacticalDetails?.pressZone || 'Yüksek'
  });

  const [defenseStyle, setDefenseStyle] = React.useState({
    line: team.tacticalDetails?.line || 'Normal',
    tackling: team.tacticalDetails?.tackling || 'Normal',
    offsideTrap: team.tacticalDetails?.offsideTrap || 'Kapalı'
  });

  const [attackStyle, setAttackStyle] = React.useState({
    focus: team.tacticalDetails?.focus || 'Topa Sahip Olma',
    shooting: team.tacticalDetails?.shooting || 'Uzaktan Şut'
  });

  // Detailed Team Instructions State
  const [instructions, setInstructions] = React.useState({
    playOutOfDefense: team.tacticalDetails?.playOutOfDefense ?? true,
    workBallIntoBox: team.tacticalDetails?.workBallIntoBox ?? true,
    shootOnSight: team.tacticalDetails?.shootOnSight ?? false,
    overlapWings: team.tacticalDetails?.overlapWings ?? true,
    earlyCrosses: team.tacticalDetails?.earlyCrosses ?? false,
    aggressiveTackling: team.tacticalDetails?.tackling === 'Sert (Agresif)',
    useOffsideTrap: team.tacticalDetails?.offsideTrap === 'Açık',
    tightMarking: true,
    pressGoalkeeper: true,
    counterAttack: team.tacticalDetails?.counter === 'Açık',
    gegenpress: true,
    slowTempo: false
  });

  // Specialist Roles State - Decoupled from starters to allow any player from the whole squad
  const [specialistRoles, setSpecialistRoles] = React.useState({
    captainId: team.tacticalDetails?.captainId || team.players.find(p => p.isStarting)?.id || team.players[0]?.id || '',
    penaltyTakerId: team.tacticalDetails?.penaltyTakerId || team.players.find(p => p.position === 'FW')?.id || team.players[0]?.id || '',
    freekickTakerId: team.tacticalDetails?.freekickTakerId || team.players.find(p => (p.attributes?.shooting || 0) > 80)?.id || team.players[0]?.id || '',
    cornerTakerId: team.tacticalDetails?.cornerTakerId || team.players.find(p => p.position === 'MID')?.id || team.players[0]?.id || ''
  });

  // Individual Player Roles State
  const [playerRoles, setPlayerRoles] = React.useState<Record<string, string>>(() => {
    return team.tacticalDetails?.playerRoles || {};
  });

  // Dynamic Team Balance calculation reacting to active starters and tactical styles:
  // When pitch is empty (0 players), balance is 0. As players are added, balance scales with their OVR and team fullness.
  const teamBalance = React.useMemo(() => {
    const activeStarters = starters.slice(0, 11);
    if (activeStarters.length === 0) {
      return { offensive: 0, possession: 0, defensive: 0, physical: 0 };
    }

    let totalAttOvr = 0, countAtt = 0;
    let totalMidOvr = 0, countMid = 0;
    let totalDefOvr = 0, countDef = 0;
    let totalPhyOvr = 0;

    activeStarters.forEach((p, idx) => {
      const eff = calculatePlayerEffectiveOverall(p, idx, team.formation);
      const effOvr = eff.effectiveOverall;
      const att = p.attributes || {
        pace: effOvr,
        shooting: effOvr,
        passing: effOvr,
        defending: effOvr,
        physical: effOvr
      };

      totalPhyOvr += (att.physical * 0.6 + att.pace * 0.4);

      if (p.position === 'FW') {
        totalAttOvr += (att.shooting * 0.5 + att.pace * 0.3 + effOvr * 0.2);
        countAtt += 1;
      } else if (p.position === 'MID') {
        totalMidOvr += (att.passing * 0.4 + (att.pace * 0.3 + att.shooting * 0.3) * 0.3 + effOvr * 0.3);
        totalAttOvr += (att.shooting * 0.3 + effOvr * 0.2);
        totalDefOvr += (att.defending * 0.3 + effOvr * 0.2);
        countMid += 1;
        countAtt += 0.5;
        countDef += 0.5;
      } else if (p.position === 'DEF' || p.position === 'GK') {
        totalDefOvr += (att.defending * 0.6 + effOvr * 0.4);
        countDef += 1;
      }
    });

    const fullnessRatio = activeStarters.length / 11;
    const baseOff = countAtt > 0 ? (totalAttOvr / countAtt) : (totalMidOvr > 0 ? totalMidOvr / countMid : 50);
    const basePos = countMid > 0 ? (totalMidOvr / countMid) : 50;
    const baseDef = countDef > 0 ? (totalDefOvr / countDef) : 50;
    const basePhy = totalPhyOvr / activeStarters.length;

    let off = Math.round(baseOff * fullnessRatio);
    let pos = Math.round(basePos * fullnessRatio);
    let def = Math.round(baseDef * fullnessRatio);
    let phy = Math.round(basePhy * fullnessRatio);

    // Apply tactical bonuses if at least half the squad is on the pitch
    if (activeStarters.length >= 6) {
      if (attackStyle.focus.includes('Hücum') || attackStyle.focus.includes('Attack')) { off += 8; def -= 4; }
      else if (attackStyle.focus.includes('Çok Riskli') || attackStyle.focus.includes('All Out')) { off += 12; def -= 10; }
      else if (attackStyle.focus.includes('Savunma') || attackStyle.focus.includes('Defens')) { off -= 10; def += 12; }

      if (playStyle.passing.includes('Kısa') || playStyle.passing.includes('Short')) { pos += 8; }
      else if (playStyle.passing.includes('Direkt') || playStyle.passing.includes('Direct')) { off += 5; pos -= 4; }
      else if (playStyle.passing.includes('Uzun') || playStyle.passing.includes('Long')) { off += 4; pos -= 8; phy += 6; }

      if (playStyle.tempo.includes('Hızlı') || playStyle.tempo.includes('Fast')) { off += 5; phy += 4; }
      else if (playStyle.tempo.includes('Yavaş') || playStyle.tempo.includes('Slow')) { pos += 6; off -= 3; }

      if (defenseStyle.line.includes('Yüksek') || defenseStyle.line.includes('High')) { off += 4; def -= 4; }
      else if (defenseStyle.line.includes('Derin') || defenseStyle.line.includes('Deep')) { def += 10; off -= 6; }

      if (playStyle.pressZone.includes('Tam Saha') || playStyle.pressZone.includes('Full Pitch')) { def += 8; phy += 8; }
      else if (playStyle.pressZone.includes('Yüksek') || playStyle.pressZone.includes('High')) { def += 5; phy += 5; }

      if (defenseStyle.tackling.includes('Sert') || defenseStyle.tackling.includes('Hard')) { def += 4; phy += 6; }
    }

    return {
      offensive: Math.max(0, Math.min(99, off)),
      possession: Math.max(0, Math.min(99, pos)),
      defensive: Math.max(0, Math.min(99, def)),
      physical: Math.max(0, Math.min(99, phy))
    };
  }, [starters, team.formation, attackStyle.focus, playStyle.passing, playStyle.tempo, playStyle.width, playStyle.pressZone, defenseStyle.line, defenseStyle.tackling, instructions.counterAttack, instructions.shootOnSight]);

  const syncAllTacticsToParent = (
    newPlay = playStyle,
    newDef = defenseStyle,
    newAtt = attackStyle,
    newInst = instructions,
    newRoles = specialistRoles,
    newDuties = playerRoles
  ) => {
    if (onUpdateTacticalDetails) {
      onUpdateTacticalDetails({
        passing: newPlay.passing,
        tempo: newPlay.tempo,
        width: newPlay.width,
        counter: newInst.counterAttack ? 'Açık' : 'Kapalı',
        pressZone: newPlay.pressZone,
        line: newDef.line,
        tackling: newInst.aggressiveTackling ? 'Sert (Agresif)' : newDef.tackling,
        offsideTrap: newInst.useOffsideTrap ? 'Açık' : 'Kapalı',
        focus: newAtt.focus,
        shooting: newInst.shootOnSight ? 'Uzaktan Şut' : 'Ceza Sahasına Pas',
        playOutOfDefense: newInst.playOutOfDefense,
        workBallIntoBox: newInst.workBallIntoBox,
        overlapWings: newInst.overlapWings,
        earlyCrosses: newInst.earlyCrosses,
        captainId: newRoles.captainId,
        penaltyTakerId: newRoles.penaltyTakerId,
        freekickTakerId: newRoles.freekickTakerId,
        cornerTakerId: newRoles.cornerTakerId,
        playerRoles: newDuties
      });
    }
  };

  const formationsList: FormationType[] = ['4-2-3-1', '4-3-3', '4-4-2', '3-5-2', '5-3-2'];
  const tacticsList: { id: TacticType; labelKey: string; fallback: string }[] = [
    { id: 'ATTACKING', labelKey: 'TACTIC_OPT_ATTACKING', fallback: 'Hücum' },
    { id: 'BALANCED', labelKey: 'TACTIC_OPT_BALANCED', fallback: 'Dengeli' },
    { id: 'DEFENSIVE', labelKey: 'TACTIC_OPT_DEFENSIVE', fallback: 'Savunma' },
    { id: 'ALL_OUT_ATTACK', labelKey: 'TACTIC_OPT_ALL_OUT_ATTACK', fallback: 'Çok Riskli Hücum' }
  ];

  const playStylesList: { id: string; labelKey: string; fallback: string; aliases: string[] }[] = [
    { id: 'Topa Sahip Olma', labelKey: 'PLAYSTYLE_POSSESSION', fallback: 'Topa Sahip Olma', aliases: ['Topa Sahip Olma', 'Possession', 'Ballbesitz', 'Posesión', 'Possesso Palla', 'Posse de Bola'] },
    { id: 'Gegenpress', labelKey: 'PLAYSTYLE_GEGENPRESS', fallback: 'Gegenpress', aliases: ['Gegenpress', 'Gegenpressing'] },
    { id: 'Tiki-Taka', labelKey: 'PLAYSTYLE_TIKI_TAKA', fallback: 'Tiki-Taka', aliases: ['Tiki-Taka', 'Tiki Taka'] },
    { id: 'Kontra Atak', labelKey: 'PLAYSTYLE_COUNTER', fallback: 'Kontra Atak', aliases: ['Kontra Atak', 'Counter Attack', 'Konterfußball', 'Contraataque', 'Contre-attaque', 'Contropiede', 'Contra-ataque'] },
    { id: 'Otobüsü Çek', labelKey: 'PLAYSTYLE_PARK_BUS', fallback: 'Otobüsü Çek', aliases: ['Otobüsü Çek', 'Park the Bus', 'Beton anrühren', 'Aparcar el Autobús', 'Bétonner', 'Autobus davanti alla porta', 'Estacionar o Ônibus'] }
  ];

  const currentPlayStyleId = React.useMemo(() => {
    const found = playStylesList.find(ps => ps.id === attackStyle.focus || ps.aliases.includes(attackStyle.focus));
    return found ? found.id : playStylesList[0].id;
  }, [attackStyle.focus]);

  const formationSelectOptions: CustomSelectOption[] = formationsList.map(f => ({
    value: f,
    label: f
  }));

  const tacticSelectOptions: CustomSelectOption[] = tacticsList.map(tc => ({
    value: tc.id,
    label: t(tc.labelKey) || tc.fallback
  }));

  const playStyleSelectOptions: CustomSelectOption[] = playStylesList.map(ps => ({
    value: ps.id,
    label: t(ps.labelKey) || ps.fallback
  }));

  // Shirt number assignment mapping based on Image 1 / 2 exact data
  const getShirtNumber = (player: Player, index: number): number => {
    if (player.number) return player.number;
    const nameLower = player.name.toLowerCase();
    // Arsenal
    if (nameLower.includes('saka')) return 7;
    if (nameLower.includes('martinelli')) return 11;
    if (nameLower.includes('rice')) return 41;
    if (nameLower.includes('merino')) return 23;
    if (nameLower.includes('ødegaard') || nameLower.includes('odegaard')) return 8;
    if (nameLower.includes('gabriel') && (nameLower.includes('magalh') || nameLower.includes('magalhaes'))) return 6;
    if (nameLower.includes('white')) return 4;
    if (nameLower.includes('saliba')) return 2;
    if (nameLower.includes('timber')) return 12;
    if (nameLower.includes('raya')) return 22;
    if (nameLower.includes('havertz')) return 29;
    if (nameLower.includes('calafiori')) return 33;
    if (nameLower.includes('trossard')) return 19;
    if (nameLower.includes('jesus')) return 9;
    if (nameLower.includes('partey')) return 5;
    if (nameLower.includes('jorginho')) return 20;
    if (nameLower.includes('sterling')) return 30;
    // Real Madrid
    if (nameLower.includes('courtois')) return 1;
    if (nameLower.includes('alexander-arnold') || nameLower.includes('arnold')) return 66;
    if (nameLower.includes('rüdiger') || nameLower.includes('rudiger')) return 22;
    if (nameLower.includes('huijsen')) return 4;
    if (nameLower.includes('lucas') || nameLower.includes('vázquez') || nameLower.includes('vazquez')) return 17;
    if (nameLower.includes('valverde')) return 8;
    if (nameLower.includes('arda') || nameLower.includes('güler') || nameLower.includes('guler')) return 15;
    if (nameLower.includes('bellingham')) return 5;
    if (nameLower.includes('brahim') || nameLower.includes('diaz') || nameLower.includes('díaz')) return 21;
    if (nameLower.includes('vinícius') || nameLower.includes('vinicius')) return 7;
    if (nameLower.includes('mbappé') || nameLower.includes('mbappe')) return 9;
    if (nameLower.includes('lunin')) return 13;
    if (nameLower.includes('militão') || nameLower.includes('militao')) return 3;
    if (nameLower.includes('asencio')) return 35;
    if (nameLower.includes('mendy')) return 23;
    if (nameLower.includes('camavinga')) return 6;
    if (nameLower.includes('tchouaméni') || nameLower.includes('tchouameni')) return 14;
    if (nameLower.includes('rodrygo')) return 11;
    if (nameLower.includes('endrick')) return 16;
    // Galatasaray & others
    if (nameLower.includes('osimhen')) return 9;
    if (nameLower.includes('sara')) return 7;
    if (nameLower.includes('sané') || nameLower.includes('sane')) return 10;
    if (nameLower.includes('yılmaz') || nameLower.includes('yilmaz')) return 21;
    if (nameLower.includes('torreira')) return 34;
    if (nameLower.includes('gündoğan') || nameLower.includes('gundogan')) return 20;
    if (nameLower.includes('singo')) return 19;
    if (nameLower.includes('sánchez') || nameLower.includes('sanchez')) return 6;
    if (nameLower.includes('bardakcı') || nameLower.includes('bardakci')) return 42;
    if (nameLower.includes('elmalı') || nameLower.includes('elmali')) return 53;
    if (nameLower.includes('çakır') || nameLower.includes('cakir')) return 1;
    if (nameLower.includes('muslera')) return 23;
    if (nameLower.includes('angeliño') || nameLower.includes('angelino')) return 3;
    if (nameLower.includes('nelsson')) return 25;
    if (nameLower.includes('kerem')) return 8;
    if (nameLower.includes('zaha')) return 11;
    if (nameLower.includes('icardi')) return 14;
    if (nameLower.includes('bay')) return 18;
    return index + 1;
  };

  // Detailed Role Model for Player Role Selection Popup
  interface DetailedRole {
    code: string;
    name: string;
    duty: 'Hücum' | 'Destek' | 'Savunma';
    dutyLabel: string;
    description: string;
    keyAttributes: string[];
    stars: number;
  }

  const calculateRoleStars = (roleCode: string, player: Player): number => {
    const att = player.attributes || { pace: 70, shooting: 70, passing: 70, defending: 70, physical: 70 };
    const overall = player.overall || 70;
    const role = (player.specificRole || player.position || '').toUpperCase();
    const foot = (player.preferredFoot || '').toUpperCase();

    let score = overall;

    if (player.position === 'GK') {
      if (roleCode === 'LKL') {
        score = att.passing * 0.45 + att.pace * 0.2 + overall * 0.35;
      } else {
        score = att.defending * 0.4 + att.physical * 0.25 + overall * 0.35;
      }
    } else if (player.position === 'DEF') {
      const isCB = role.includes('CB') || role === 'DEF';
      const isFullback = role.includes('LB') || role.includes('RB') || role.includes('LWB') || role.includes('RWB');
      if (roleCode === 'PS') {
        score = (att.passing * 0.5 + att.defending * 0.35 + overall * 0.15) + (isCB ? 5 : -8);
      } else if (roleCode === 'ÇS') {
        score = (att.defending * 0.5 + att.physical * 0.4 + overall * 0.1) + (isCB ? 6 : -14);
      } else if (roleCode === 'HB') {
        score = (att.pace * 0.5 + att.passing * 0.3 + att.physical * 0.2) + (isFullback ? 8 : -16);
      } else if (roleCode === 'İKB') {
        const isInvertedFoot = (role.includes('LB') && (foot.includes('SAĞ') || foot.includes('RIGHT'))) ||
                               (role.includes('RB') && (foot.includes('SOL') || foot.includes('LEFT')));
        score = (att.passing * 0.45 + att.pace * 0.3 + overall * 0.25) + (isFullback ? 6 : -14) + (isInvertedFoot ? 6 : 0);
      }
    } else if (player.position === 'MID') {
      const isCM = role.includes('CM') || role.includes('CDM');
      const isAttMid = role.includes('CAM') || role.includes('RW') || role.includes('LW') || role.includes('AM');
      const isDM = role.includes('CDM') || role.includes('CB') || role.includes('CM');
      const isWinger = role.includes('W') || role.includes('M') || role.includes('LM') || role.includes('RM');

      if (roleCode === 'B2B') {
        score = (att.physical * 0.4 + att.passing * 0.3 + att.pace * 0.3) + (isCM ? 5 : -4);
      } else if (roleCode === 'OOK') {
        score = (att.passing * 0.55 + att.shooting * 0.3 + overall * 0.15) + (isAttMid ? 7 : -10);
      } else if (roleCode === 'DOS') {
        score = (att.defending * 0.55 + att.physical * 0.35 + overall * 0.1) + (isDM ? 7 : -12);
      } else if (roleCode === 'DOK') {
        score = (att.passing * 0.6 + att.defending * 0.25 + overall * 0.15) + (isCM ? 6 : -6);
      } else if (roleCode === 'KF') {
        score = (att.pace * 0.55 + att.shooting * 0.35 + overall * 0.1) + (isWinger ? 7 : -12);
      }
    } else if (player.position === 'FW') {
      const isST = role.includes('ST') || role.includes('CF');
      const isWinger = role.includes('W') || role.includes('LM') || role.includes('RM');
      if (roleCode === 'FG') {
        score = (att.shooting * 0.6 + att.pace * 0.3 + overall * 0.1) + (isST ? 6 : -6);
      } else if (roleCode === 'KF') {
        score = (att.shooting * 0.4 + att.physical * 0.3 + att.passing * 0.3) + (isST ? 4 : -8);
      } else if (roleCode === 'HS') {
        score = (att.physical * 0.65 + att.shooting * 0.25 + overall * 0.1) + (isST ? 7 : -12);
      } else if (roleCode === 'TAK') {
        const isInvertedFoot = (role.includes('LW') && (foot.includes('SAĞ') || foot.includes('RIGHT'))) ||
                               (role.includes('RW') && (foot.includes('SOL') || foot.includes('LEFT')));
        score = (att.pace * 0.5 + att.shooting * 0.4 + overall * 0.1) + (isWinger ? 6 : -8) + (isInvertedFoot ? 6 : -2);
      }
    }

    if (score >= 83) return 5;
    if (score >= 75) return 4;
    if (score >= 66) return 3;
    if (score >= 56) return 2;
    return 1;
  };

  const getDetailedRolesForPlayer = (player: Player, langRaw: string): DetailedRole[] => {
    const lang = (langRaw || 'TR').toUpperCase();
    const isTr = lang === 'TR';
    const isDe = lang === 'DE';
    const isEs = lang === 'ES';
    const isFr = lang === 'FR';
    const isIt = lang === 'IT';
    const isPt = lang === 'PT';

    const getDutyLabel = (duty: 'Hücum' | 'Destek' | 'Savunma') => {
      if (isTr) return duty;
      if (duty === 'Hücum') {
        if (isDe) return 'Angriff';
        if (isEs) return 'Ataque';
        if (isFr) return 'Attaque';
        if (isIt) return 'Attacco';
        if (isPt) return 'Ataque';
        return 'Attack';
      }
      if (duty === 'Destek') {
        if (isDe) return 'Unterstützung';
        if (isEs) return 'Apoyo';
        if (isFr) return 'Soutien';
        if (isIt) return 'Supporto';
        if (isPt) return 'Apoio';
        return 'Support';
      }
      if (isDe) return 'Verteidigen';
      if (isEs) return 'Defensa';
      if (isFr) return 'Défense';
      if (isIt) return 'Difesa';
      if (isPt) return 'Defesa';
      return 'Defend';
    };

    if (player.position === 'GK') {
      return [
        {
          code: 'LKL',
          name: isTr ? 'Libero Kaleci' : isDe ? 'Mitspielender Torwart' : isEs ? 'Portero Cierre' : isFr ? 'Gardien Libéro' : isIt ? 'Portiere Libero' : isPt ? 'Guarda-Redes Líbero' : 'Sweeper Keeper',
          duty: 'Destek',
          dutyLabel: getDutyLabel('Destek'),
          description: isTr ? 'Defans arkasına atılan topları süpürür ve oyunu geriden pasla kurar.' :
                       isEs ? 'Sale de su área para cortar balones en profundidad e inicia jugadas desde atrás.' :
                       isFr ? 'Couvre le dos de sa défense et participe activement à la relance au pied.' :
                       isIt ? 'Spazza i palloni dietro la linea difensiva e imposta la manovra dal basso.' :
                       isPt ? 'Limpa as bolas nas costas da defesa e inicia a construção com passes curtos.' :
                       isDe ? 'Läuft gegnerische Steilpässe ab und leitet Angriffe mit präzisen Pässen ein.' :
                       'Sweeps behind defensive line and initiates attacks with accurate distribution.',
          keyAttributes: isTr ? ['Pas', 'Refleks', 'Hız'] :
                         isEs ? ['Pase', 'Reflejos', 'Ritmo'] :
                         isFr ? ['Passes', 'Réflexes', 'Vitesse'] :
                         isIt ? ['Passaggi', 'Riflessi', 'Velocità'] :
                         isPt ? ['Passe', 'Reflexos', 'Velocidade'] :
                         isDe ? ['Passspiel', 'Reflexe', 'Tempo'] :
                         ['Passing', 'Reflexes', 'Pace'],
          stars: calculateRoleStars('LKL', player)
        },
        {
          code: 'KL',
          name: isTr ? 'Geleneksel Kaleci' : isDe ? 'Klassischer Torwart' : isEs ? 'Portero Clásico' : isFr ? 'Gardien Classique' : isIt ? 'Portiere Tradizionale' : isPt ? 'Guarda-Redes Tradicional' : 'Traditional Goalkeeper',
          duty: 'Savunma',
          dutyLabel: getDutyLabel('Savunma'),
          description: isTr ? 'Çizgide kalır, ceza sahası hakimiyetine ve temel kurtarışlara odaklanır.' :
                       isEs ? 'Se mantiene en la línea de gol, domina el área y realiza paradas clave.' :
                       isFr ? 'Reste sur sa ligne de but, domine sa surface et sécurise les arrêts.' :
                       isIt ? 'Resta sulla linea di porta, domina l’area e si concentra sulle parate.' :
                       isPt ? 'Fica na linha de golo, domina a grande área e foca-se nas defesas.' :
                       isDe ? 'Bleibt auf der Torlinie, beherrscht den Strafraum und verhindert Tore.' :
                       'Stays close to goal line, commands penalty area and prevents goals.',
          keyAttributes: isTr ? ['Refleks', 'Pozisyon', 'Fizik'] :
                         isEs ? ['Reflejos', 'Posicionamiento', 'Físico'] :
                         isFr ? ['Réflexes', 'Placement', 'Physique'] :
                         isIt ? ['Riflessi', 'Posizione', 'Fisico'] :
                         isPt ? ['Reflexos', 'Posicionamento', 'Físico'] :
                         isDe ? ['Reflexe', 'Stellungsspiel', 'Physis'] :
                         ['Reflexes', 'Positioning', 'Physical'],
          stars: calculateRoleStars('KL', player)
        }
      ];
    }

    if (player.position === 'DEF') {
      return [
        {
          code: 'PS',
          name: isTr ? 'Pasör Stoper' : isDe ? 'Aufbauspieler' : isEs ? 'Defensa con Toque' : isFr ? 'Défenseur Relanceur' : isIt ? 'Difensore Impostatore' : isPt ? 'Defesa com Passe' : 'Ball Playing Defender',
          duty: 'Savunma',
          dutyLabel: getDutyLabel('Savunma'),
          description: isTr ? 'Savunmadan oyun kurar, uzun ve isabetli paslarla hücumu başlatır.' :
                       isEs ? 'Inicia las jugadas desde atrás con pases precisos y visión de juego.' :
                       isFr ? 'Relance proprement depuis la défense avec des passes courtes et longues précises.' :
                       isIt ? 'Costruisce il gioco dalla retroguardia con lanci e passaggi filtranti precisi.' :
                       isPt ? 'Inicia a construção ofensiva a partir da defesa com passes longos e precisos.' :
                       isDe ? 'Baut das Spiel aus der Abwehr mit präzisen Pässen und Übersicht auf.' :
                       'Initiates attacks from the back with pinpoint short and long passes.',
          keyAttributes: isTr ? ['Pas', 'Savunma', 'Fizik'] :
                         isEs ? ['Pase', 'Defensa', 'Físico'] :
                         isFr ? ['Passes', 'Défense', 'Physique'] :
                         isIt ? ['Passaggi', 'Difesa', 'Fisico'] :
                         isPt ? ['Passe', 'Defesa', 'Físico'] :
                         isDe ? ['Passspiel', 'Defensive', 'Physis'] :
                         ['Passing', 'Defending', 'Physical'],
          stars: calculateRoleStars('PS', player)
        },
        {
          code: 'ÇS',
          name: isTr ? 'Çakılı Stoper' : isDe ? 'Kompromissloser IV' : isEs ? 'Defensa Central Puro' : isFr ? 'Défenseur Central Strict' : isIt ? 'Difensore Puro' : isPt ? 'Defesa Central Puro' : 'No-Nonsense Centre-Back',
          duty: 'Savunma',
          dutyLabel: getDutyLabel('Savunma'),
          description: isTr ? 'Tehlikeyi doğrudan uzaklaştırır, hava toplarında ve ikili mücadelelerde risksiz oynar.' :
                       isEs ? 'Despeja el peligro directamente y gana duelos físicos sin arriesgar.' :
                       isFr ? 'Écarte le danger directement sans prendre de risques dans les duels.' :
                       isIt ? 'Spazza via il pericolo e domina nei contrasti aerei senza correre rischi.' :
                       isPt ? 'Afasta o perigo diretamente e domina nos duelos físicos sem arriscar.' :
                       isDe ? 'Beseitigt Gefahren kompromisslos und meidet riskante Spielzüge.' :
                       'Eliminates danger directly and dominates physical aerial battles without taking risks.',
          keyAttributes: isTr ? ['Savunma', 'Fizik', 'Mücadele'] :
                         isEs ? ['Defensa', 'Físico', 'Fuerza'] :
                         isFr ? ['Défense', 'Physique', 'Puissance'] :
                         isIt ? ['Difesa', 'Fisico', 'Contrasti'] :
                         isPt ? ['Defesa', 'Físico', 'Força'] :
                         isDe ? ['Defensive', 'Physis', 'Zweikampf'] :
                         ['Defending', 'Physical', 'Strength'],
          stars: calculateRoleStars('ÇS', player)
        },
        {
          code: 'HB',
          name: isTr ? 'Hücumcu Bek' : isDe ? 'Flügelverteidiger' : isEs ? 'Carrilero Ofensivo' : isFr ? 'Latéral Offensif' : isIt ? 'Terzino Fluidificante' : isPt ? 'Ala Ofensivo' : 'Wing-Back',
          duty: 'Hücum',
          dutyLabel: getDutyLabel('Hücum'),
          description: isTr ? 'Kanat çizgisini boydan boya kullanır, forvet hattına bindirmeler ve ortalar yapar.' :
                       isEs ? 'Recorre toda la banda proporcionando amplitud, desbordes y centros de calidad.' :
                       isFr ? 'Arpente tout son couloir pour apporter le surnombre et adresser des centres.' :
                       isIt ? 'Spinge continuamente sulla fascia offrendo sovrapposizioni e cross pericolosi.' :
                       isPt ? 'Corre todo o corredor lateral oferecendo cruzamentos e apoio ofensivo constante.' :
                       isDe ? 'Bearbeitet die gesamte Außenbahn mit schnellen Vorstößen und Flanken.' :
                       'Surges up and down the flank providing width, attacking overlaps and quality crosses.',
          keyAttributes: isTr ? ['Hız', 'Pas', 'Dayanıklılık'] :
                         isEs ? ['Ritmo', 'Pase', 'Resistencia'] :
                         isFr ? ['Vitesse', 'Passes', 'Endurance'] :
                         isIt ? ['Velocità', 'Passaggi', 'Resistenza'] :
                         isPt ? ['Velocidade', 'Passe', 'Resistência'] :
                         isDe ? ['Tempo', 'Passspiel', 'Ausdauer'] :
                         ['Pace', 'Passing', 'Stamina'],
          stars: calculateRoleStars('HB', player)
        },
        {
          code: 'İKB',
          name: isTr ? 'İçe Kat Eden Bek' : isDe ? 'Invertierter Außenverteidiger' : isEs ? 'Lateral Invertido' : isFr ? 'Latéral Inversé' : isIt ? 'Terzino Invertito' : isPt ? 'Lateral Invertido' : 'Inverted Wing-Back',
          duty: 'Destek',
          dutyLabel: getDutyLabel('Destek'),
          description: isTr ? 'Hücumda orta sahaya kayarak merkezde ekstra pas opsiyonu oluşturur.' :
                       isEs ? 'Se interioriza hacia el mediocampo para generar superioridad numérica con balón.' :
                       isFr ? 'Repique dans l’axe pour créer une supériorité numérique au milieu de terrain.' :
                       isIt ? 'Accentra la propria posizione in fase di possesso per creare superiorità in mediana.' :
                       isPt ? 'Entra pelo meio-campo para criar superioridade numérica na posse de bola.' :
                       isDe ? 'Zieht bei Ballbesitz ins Mittelfeldzentrum, um Passüberzahl zu schaffen.' :
                       'Drifts inwards into central midfield to create numerical superiorities in possession.',
          keyAttributes: isTr ? ['Pas', 'Savunma', 'Hız'] :
                         isEs ? ['Pase', 'Defensa', 'Ritmo'] :
                         isFr ? ['Passes', 'Défense', 'Vitesse'] :
                         isIt ? ['Passaggi', 'Difesa', 'Velocità'] :
                         isPt ? ['Passe', 'Defesa', 'Velocidade'] :
                         isDe ? ['Passspiel', 'Defensive', 'Tempo'] :
                         ['Passing', 'Defending', 'Pace'],
          stars: calculateRoleStars('İKB', player)
        }
      ];
    }

    if (player.position === 'MID') {
      return [
        {
          code: 'B2B',
          name: isTr ? 'İki Yönlü (Box-to-Box)' : isDe ? 'Box-to-Box Mittelfeld' : isEs ? 'Todocampista (B2B)' : isFr ? 'Milieu Box-to-Box' : isIt ? 'Centrocampista Box-to-Box' : isPt ? 'Médio Box-to-Box' : 'Box-to-Box Midfielder',
          duty: 'Destek',
          dutyLabel: getDutyLabel('Destek'),
          description: isTr ? 'İki ceza sahası arasında dinamik koşular yapar; hem savunmada hem hücumda etkilidir.' :
                       isEs ? 'Cubre incansablemente ambas áreas; aporta tanto en defensa como en ataque.' :
                       isFr ? 'Multiplie les courses entre les deux surfaces; précieux en attaque comme en défense.' :
                       isIt ? 'Corre instancabilmente tra le due aree di rigore; fondamentale in entrambe le fasi.' :
                       isPt ? 'Percorre todo o campo entre as duas áreas, apoiando a defesa e o ataque.' :
                       isDe ? 'Pendelt dynamisch zwischen beiden Strafräumen und verbindet Defensive und Offensive.' :
                       'Tirelessly covers ground between both boxes; contributes to attack and defense.',
          keyAttributes: isTr ? ['Fizik', 'Pas', 'Savunma'] :
                         isEs ? ['Físico', 'Pase', 'Defensa'] :
                         isFr ? ['Physique', 'Passes', 'Défense'] :
                         isIt ? ['Fisico', 'Passaggi', 'Difesa'] :
                         isPt ? ['Físico', 'Passe', 'Defesa'] :
                         isDe ? ['Physis', 'Passspiel', 'Defensive'] :
                         ['Physical', 'Passing', 'Defending'],
          stars: calculateRoleStars('B2B', player)
        },
        {
          code: 'OOK',
          name: isTr ? 'Ofansif Oyun Kurucu' : isDe ? 'Offensiver Spielmacher' : isEs ? 'Organizador Avanzado' : isFr ? 'Meneur de Jeu Avancé' : isIt ? 'Regista Avanzato' : isPt ? 'Médio Ofensivo Criativo' : 'Advanced Playmaker',
          duty: 'Hücum',
          dutyLabel: getDutyLabel('Hücum'),
          description: isTr ? 'Hücum hattında kilit paslar atar, savunma kilidini açar ve pozisyon yaratır.' :
                       isEs ? 'Opera entre líneas para romper bloques defensivos con pases filtrados.' :
                       isFr ? 'Évolue entre les lignes adverses et distribue des caviars aux attaquants.' :
                       isIt ? 'Gioca tra le linee avversarie per creare occasioni da gol con passaggi decisivi.' :
                       isPt ? 'Joga entre as linhas adversárias para desbloquear defesas com passes de rutura.' :
                       isDe ? 'Agiert in den Zwischenräumen und öffnet Abwehrreihen mit tödlichen Pässen.' :
                       'Operates between lines to unlock defensive blocks with incisive through balls.',
          keyAttributes: isTr ? ['Pas', 'Şut', 'Hız'] :
                         isEs ? ['Pase', 'Disparo', 'Ritmo'] :
                         isFr ? ['Passes', 'Tir', 'Vitesse'] :
                         isIt ? ['Passaggi', 'Tiro', 'Velocità'] :
                         isPt ? ['Passe', 'Remate', 'Velocidade'] :
                         isDe ? ['Passspiel', 'Schuss', 'Tempo'] :
                         ['Passing', 'Shooting', 'Pace'],
          stars: calculateRoleStars('OOK', player)
        },
        {
          code: 'DOS',
          name: isTr ? 'Savaşçı DOS' : isDe ? 'Balleroberer' : isEs ? 'Pivote Recuperador' : isFr ? 'Milieu Récupérateur' : isIt ? 'Incontrista' : isPt ? 'Médio Recuperador' : 'Ball Winning Midfielder',
          duty: 'Savunma',
          dutyLabel: getDutyLabel('Savunma'),
          description: isTr ? 'Agresif presle rakip atakları keser, top kapar ve savunmanın önünü süpürür.' :
                       isEs ? 'Presiona agresivamente, corta contragolpes y protege a la defensa.' :
                       isFr ? 'Presse agressivement, intercepte les contres et protège l’axe central.' :
                       isIt ? 'Pressa aggressivamente, recupera palloni e fa da schermo davanti alla difesa.' :
                       isPt ? 'Pressiona intensamente, recupera a posse e protege a linha defensiva.' :
                       isDe ? 'Stört gegnerische Angriffe aggressiv und erobert zweite Bälle im Zentrum.' :
                       'Presses aggressively, intercepts counterattacks and protects the back four.',
          keyAttributes: isTr ? ['Savunma', 'Fizik', 'Hız'] :
                         isEs ? ['Defensa', 'Físico', 'Ritmo'] :
                         isFr ? ['Défense', 'Physique', 'Vitesse'] :
                         isIt ? ['Difesa', 'Fisico', 'Velocità'] :
                         isPt ? ['Defesa', 'Físico', 'Velocidade'] :
                         isDe ? ['Defensive', 'Physis', 'Tempo'] :
                         ['Defending', 'Physical', 'Pace'],
          stars: calculateRoleStars('DOS', player)
        },
        {
          code: 'DOK',
          name: isTr ? 'Derin Oyun Kurucu' : isDe ? 'Tiefer Spielmacher' : isEs ? 'Organizador en Corto' : isFr ? 'Meneur en Retrait' : isIt ? 'Regista Basso' : isPt ? 'Médio Construtor Recuado' : 'Deep-Lying Playmaker',
          duty: 'Destek',
          dutyLabel: getDutyLabel('Destek'),
          description: isTr ? 'Savunma önünden oyunu yönetir, sahanın her yerine isabetli paslar dağıtır.' :
                       isEs ? 'Dicta el ritmo del partido desde posiciones retrasadas con pases milimétricos.' :
                       isFr ? 'Dicte le tempo du jeu depuis sa moitié de terrain avec une précision chirurgicale.' :
                       isIt ? 'Detta i ritmi della squadra davanti alla difesa con lanci e aperture precise.' :
                       isPt ? 'Dita os ritmos da partida a partir de posições recuadas com passes cirúrgicos.' :
                       isDe ? 'Bestimmt das Spieltempo aus der Tiefe mit fehlerfreier Ballverteilung.' :
                       'Dictates the game tempo from deep positions with flawless distribution.',
          keyAttributes: isTr ? ['Pas', 'Savunma', 'Vizyon'] :
                         isEs ? ['Pase', 'Defensa', 'Visión'] :
                         isFr ? ['Passes', 'Défense', 'Vision'] :
                         isIt ? ['Passaggi', 'Difesa', 'Visione'] :
                         isPt ? ['Passe', 'Defesa', 'Visão'] :
                         isDe ? ['Passspiel', 'Defensive', 'Übersicht'] :
                         ['Passing', 'Defending', 'Vision'],
          stars: calculateRoleStars('DOK', player)
        },
        {
          code: 'KF',
          name: isTr ? 'Kanat Forvet' : isDe ? 'Flügelstürmer' : isEs ? 'Extremo Invertido' : isFr ? 'Ailier Inversé' : isIt ? 'Ala Invertita' : isPt ? 'Extremo Invertido' : 'Inverted Winger',
          duty: 'Hücum',
          dutyLabel: getDutyLabel('Hücum'),
          description: isTr ? 'Hızlı driplinglerle ceza sahasına girer veya sıfıra inip şut/orta dener.' :
                       isEs ? 'Desborda en velocidad hacia el área para disparar o asistir a los delanteros.' :
                       isFr ? 'Perce en vitesse vers l’intérieur pour frapper ou combiner avec l’attaque.' :
                       isIt ? 'Punta l’area palla al piede con dribbling rapidi per calciare o crossare.' :
                       isPt ? 'Entra em drible rápido para dentro da área para rematar ou assistir.' :
                       isDe ? 'Dribbelt mit hohem Tempo in den Sechzehner zum Abschluss oder Querpass.' :
                       'Cuts inside at pace towards goal to shoot or link up with strikers.',
          keyAttributes: isTr ? ['Hız', 'Şut', 'Pas'] :
                         isEs ? ['Ritmo', 'Disparo', 'Pase'] :
                         isFr ? ['Vitesse', 'Tir', 'Passes'] :
                         isIt ? ['Velocità', 'Tiro', 'Passaggi'] :
                         isPt ? ['Velocidade', 'Remate', 'Passe'] :
                         isDe ? ['Tempo', 'Schuss', 'Passspiel'] :
                         ['Pace', 'Shooting', 'Passing'],
          stars: calculateRoleStars('KF', player)
        }
      ];
    }

    // FW
    return [
      {
        code: 'FG',
        name: isTr ? 'Fırsatçı Golcü' : isDe ? 'Knipser / Torjäger' : isEs ? 'Ariete Cazagoles' : isFr ? 'Renard des Surfaces' : isIt ? 'Uomo d’Area' : isPt ? 'Ponta de Lança' : 'Poacher / Advanced Forward',
        duty: 'Hücum',
        dutyLabel: getDutyLabel('Hücum'),
        description: isTr ? 'Ofsayt çizgisinde hareketlenir, ceza sahası içindeki tüm pozisyonları gole çevirir.' :
                     isEs ? 'Juega al límite del fuera de juego y define con frialdad dentro del área.' :
                     isFr ? 'Rôde à la limite du hors-jeu et convertit les moindres occasions dans la surface.' :
                     isIt ? 'Gioca sul filo del fuorigioco e finalizza ogni pallone in area di rigore.' :
                     isPt ? 'Movimenta-se no limite do fora de jogo e converte oportunidades na área.' :
                     isDe ? 'Lauert auf der Abseitslinie und schließt eiskalt im gegnerischen Strafraum ab.' :
                     'Stalks the offside line and converts opportunities inside the box with clinical finishing.',
        keyAttributes: isTr ? ['Şut', 'Hız', 'Bitiricilik'] :
                       isEs ? ['Disparo', 'Ritmo', 'Definición'] :
                       isFr ? ['Tir', 'Vitesse', 'Finition'] :
                       isIt ? ['Tiro', 'Velocità', 'Finalizzazione'] :
                       isPt ? ['Remate', 'Velocidade', 'Finalização'] :
                       isDe ? ['Schuss', 'Tempo', 'Abschluss'] :
                       ['Shooting', 'Pace', 'Finishing'],
        stars: calculateRoleStars('FG', player)
      },
      {
        code: 'KF',
        name: isTr ? 'Komple Forvet' : isDe ? 'Kompletter Stürmer' : isEs ? 'Delantero Completo' : isFr ? 'Attaquant Complet' : isIt ? 'Attaccante Completo' : isPt ? 'Avançado Completo' : 'Complete Forward',
        duty: 'Hücum',
        dutyLabel: getDutyLabel('Hücum'),
        description: isTr ? 'Hem sırtı dönük top saklar, hem uzaktan şut atar, hem de takım arkadaşlarına servis yapar.' :
                     isEs ? 'Aguanta el balón de espaldas, remata de media distancia y asiste a sus compañeros.' :
                     isFr ? 'Conserve le ballon dos au but, frappe de loin et fait briller ses coéquipiers.' :
                     isIt ? 'Protegge palla spalle alla porta, calcia dalla distanza e crea gioco per i compagni.' :
                     isPt ? 'Segura a bola de costas, remata de longe e serve os companheiros de equipa.' :
                     isDe ? 'Hält Bälle mit dem Rücken zum Tor fest, schießt aus der Distanz und legt auf.' :
                     'All-round attacking threat who holds up play, scores from range, and assists teammates.',
        keyAttributes: isTr ? ['Şut', 'Fizik', 'Pas'] :
                       isEs ? ['Disparo', 'Físico', 'Pase'] :
                       isFr ? ['Tir', 'Physique', 'Passes'] :
                       isIt ? ['Tiro', 'Fisico', 'Passaggi'] :
                       isPt ? ['Remate', 'Físico', 'Passe'] :
                       isDe ? ['Schuss', 'Physis', 'Passspiel'] :
                       ['Shooting', 'Physical', 'Passing'],
        stars: calculateRoleStars('KF', player)
      },
      {
        code: 'HS',
        name: isTr ? 'Hedef Santrafor' : isDe ? 'Zielspieler' : isEs ? 'Hombre Objetivo' : isFr ? 'Pivot Offensif' : isIt ? 'Centravanti Boa' : isPt ? 'Homem Alvo' : 'Target Forward',
        duty: 'Destek',
        dutyLabel: getDutyLabel('Destek'),
        description: isTr ? 'Yüksek fiziksel gücü ve hava hakimiyetiyle uzun topları indirir, kanatları oyuna sokar.' :
                     isEs ? 'Domina los duelos aéreos y descarga balones para la llegada de centrocampistas.' :
                     isFr ? 'Domine le jeu aérien et sert de point d’appui pour l’arrivée des ailiers.' :
                     isIt ? 'Domina i duelli aerei e fa da sponda per gli inserimenti di ali e centrocampisti.' :
                     isPt ? 'Domina os duelos aéreos e segura as bolas longas para a subida da equipa.' :
                     isDe ? 'Dominiert Luftzweikämpfe und legt lange Bälle für nachrückende Mitspieler ab.' :
                     'Dominates aerial duels, brings midfielders and wingers into attack with hold-up play.',
        keyAttributes: isTr ? ['Fizik', 'Şut', 'Güç'] :
                       isEs ? ['Físico', 'Disparo', 'Fuerza'] :
                       isFr ? ['Physique', 'Tir', 'Puissance'] :
                       isIt ? ['Fisico', 'Tiro', 'Forza'] :
                       isPt ? ['Físico', 'Remate', 'Força'] :
                       isDe ? ['Physis', 'Schuss', 'Kopfball'] :
                       ['Physical', 'Shooting', 'Aerial'],
        stars: calculateRoleStars('HS', player)
      },
      {
        code: 'TAK',
        name: isTr ? 'Ters Ayaklı Kanat' : isDe ? 'Invertierter Flügelstürmer' : isEs ? 'Delantero Interior' : isFr ? 'Attaquant Intérieur' : isIt ? 'Attaccante Esterno' : isPt ? 'Avançado Interior' : 'Inside Forward',
        duty: 'Hücum',
        dutyLabel: getDutyLabel('Hücum'),
        description: isTr ? 'Kanattan içeri kat edip güçlü ayağıyla şut çeker veya forvetin arkasına sarkar.' :
                     isEs ? 'Se interna desde la banda para disparar con su pierna hábil o atacar el espacio.' :
                     isFr ? 'Repique depuis l’aile pour frapper avec son bon pied ou plonger dans le dos de la défense.' :
                     isIt ? 'Taglia verso il centro per calciare con il piede preferito o inserirsi alle spalle dei difensori.' :
                     isPt ? 'Flete da ala para o meio para rematar com o pé dominante ou atacar a profundidade.' :
                     isDe ? 'Zieht vom Flügel nach innen, um mit dem starken Fuß abzuschließen.' :
                     'Drives inside from wide areas to shoot on stronger foot or exploit central gaps.',
        keyAttributes: isTr ? ['Hız', 'Şut', 'Pas'] :
                       isEs ? ['Ritmo', 'Disparo', 'Pase'] :
                       isFr ? ['Vitesse', 'Tir', 'Passes'] :
                       isIt ? ['Velocità', 'Tiro', 'Passaggi'] :
                       isPt ? ['Velocidade', 'Remate', 'Passe'] :
                       isDe ? ['Tempo', 'Schuss', 'Passspiel'] :
                       ['Pace', 'Shooting', 'Passing'],
        stars: calculateRoleStars('TAK', player)
      }
    ];
  };

  // Slot-based FMM Position Code matching tactical spot on pitch: KL, SLB, SS, SĞB, DOS, MO, OOS, SLK, SĞK, SF
  const getFmmPosCode = (p: Player | null, index: number, formation: FormationType = team.formation): string => {
    if (index === 0 || p?.position === 'GK') return 'KL';
    const slot = FORMATION_COORDINATES[formation]?.[index];
    const role = slot ? slot.role : (p?.specificRole || p?.position || 'CM');
    if (role === 'GK') return 'KL';
    if (role === 'CB') return 'SS';
    if (role === 'LB' || role === 'LWB') return 'SLB';
    if (role === 'RB' || role === 'RWB') return 'SĞB';
    if (role === 'CDM') return 'DOS';
    if (role === 'CM') return 'MO';
    if (role === 'CAM') return 'OOS';
    if (role === 'LW' || role === 'LM') return 'SLK';
    if (role === 'RW' || role === 'RM') return 'SĞK';
    if (role === 'ST' || role === 'CF') return 'SF';
    if (role === 'DEF') return 'SS';
    if (role === 'MID') return 'DOS';
    if (role === 'FW') return 'SF';
    return 'DOS';
  };

  // Role + Duty code matching slot: e.g. "SF - H", "SLK - H", "SĞK - H", "OOS - H", "MO - D", "DOS - D", "SLB - D", "SS - D", "SĞB - D", "KL - D"
  const getRoleDutyCode = (p: Player | null, index: number, formation: FormationType = team.formation): string => {
    const code = getFmmPosCode(p, index, formation);
    const duty = (code === 'SF' || code === 'OOS' || code === 'SLK' || code === 'SĞK') ? 'H' : 'D';
    return `${code} - ${duty}`;
  };

  // Known Single Name formatting matching Image 1
  const getLastName = (fullName: string): string => {
    return getKnownPlayerName(fullName);
  };

  // Formation coordinates mapping for 1st Image visual pitch (% top, % left) with generous spacing
  const getPlayerPositionOnPitch = (index: number, formation: FormationType) => {
    if (index === 0) return { top: '88%', left: '50%' }; // GK

    switch (formation) {
      case '4-2-3-1':
        if (index === 1) return { top: '72%', left: '13%' }; // SLB
        if (index === 2) return { top: '74%', left: '36%' }; // SS1
        if (index === 3) return { top: '74%', left: '64%' }; // SS2
        if (index === 4) return { top: '72%', left: '87%' }; // SĞB

        if (index === 5) return { top: '55%', left: '33%' }; // DOS1
        if (index === 6) return { top: '55%', left: '67%' }; // DOS2

        if (index === 7) return { top: '36%', left: '15%' }; // SLK / LM
        if (index === 8) return { top: '36%', left: '50%' }; // OOS / CAM
        if (index === 9) return { top: '36%', left: '85%' }; // SĞK / RM

        if (index === 10) return { top: '16%', left: '50%' }; // SF / ST
        break;

      case '4-3-3':
        if (index === 1) return { top: '72%', left: '13%' };
        if (index === 2) return { top: '74%', left: '36%' };
        if (index === 3) return { top: '74%', left: '64%' };
        if (index === 4) return { top: '72%', left: '87%' };

        if (index === 5) return { top: '54%', left: '26%' };
        if (index === 6) return { top: '58%', left: '50%' };
        if (index === 7) return { top: '54%', left: '74%' };

        if (index === 8) return { top: '27%', left: '17%' };
        if (index === 9) return { top: '16%', left: '50%' };
        if (index === 10) return { top: '27%', left: '83%' };
        break;

      case '4-4-2':
        if (index === 1) return { top: '72%', left: '13%' };
        if (index === 2) return { top: '74%', left: '36%' };
        if (index === 3) return { top: '74%', left: '64%' };
        if (index === 4) return { top: '72%', left: '87%' };

        if (index === 5) return { top: '50%', left: '14%' };
        if (index === 6) return { top: '52%', left: '37%' };
        if (index === 7) return { top: '52%', left: '63%' };
        if (index === 8) return { top: '50%', left: '86%' };

        if (index === 9) return { top: '17%', left: '34%' };
        if (index === 10) return { top: '17%', left: '66%' };
        break;

      case '3-5-2':
        if (index === 1) return { top: '73%', left: '24%' };
        if (index === 2) return { top: '75%', left: '50%' };
        if (index === 3) return { top: '73%', left: '76%' };

        if (index === 4) return { top: '50%', left: '12%' };
        if (index === 5) return { top: '56%', left: '33%' };
        if (index === 6) return { top: '37%', left: '50%' }; // CAM
        if (index === 7) return { top: '56%', left: '67%' };
        if (index === 8) return { top: '50%', left: '88%' };

        if (index === 9) return { top: '17%', left: '34%' };
        if (index === 10) return { top: '17%', left: '66%' };
        break;

      case '5-3-2':
        if (index === 1) return { top: '70%', left: '12%' };
        if (index === 2) return { top: '74%', left: '31%' };
        if (index === 3) return { top: '76%', left: '50%' };
        if (index === 4) return { top: '74%', left: '69%' };
        if (index === 5) return { top: '70%', left: '88%' };

        if (index === 6) return { top: '52%', left: '28%' };
        if (index === 7) return { top: '56%', left: '50%' };
        if (index === 8) return { top: '52%', left: '72%' };

        if (index === 9) return { top: '17%', left: '34%' };
        if (index === 10) return { top: '17%', left: '66%' };
        break;

      case '4-1-4-1':
        if (index === 1) return { top: '72%', left: '13%' };
        if (index === 2) return { top: '74%', left: '36%' };
        if (index === 3) return { top: '74%', left: '64%' };
        if (index === 4) return { top: '72%', left: '87%' };

        if (index === 5) return { top: '58%', left: '50%' };

        if (index === 6) return { top: '38%', left: '15%' };
        if (index === 7) return { top: '40%', left: '37%' };
        if (index === 8) return { top: '40%', left: '63%' };
        if (index === 9) return { top: '38%', left: '85%' };

        if (index === 10) return { top: '16%', left: '50%' };
        break;

      case '3-4-3':
        if (index === 1) return { top: '74%', left: '24%' };
        if (index === 2) return { top: '76%', left: '50%' };
        if (index === 3) return { top: '74%', left: '76%' };

        if (index === 4) return { top: '52%', left: '14%' };
        if (index === 5) return { top: '54%', left: '37%' };
        if (index === 6) return { top: '54%', left: '63%' };
        if (index === 7) return { top: '52%', left: '86%' };

        if (index === 8) return { top: '27%', left: '17%' };
        if (index === 9) return { top: '16%', left: '50%' };
        if (index === 10) return { top: '27%', left: '83%' };
        break;
    }

    const row = Math.floor(index / 4);
    const col = index % 4;
    return { top: `${24 + row * 18}%`, left: `${20 + col * 20}%` };
  };

  const getSubMenuKey = (menuName: string) => {
    switch (menuName) {
      case 'Diziliş': return t('TAB_FORMATION');
      case 'Oyun Şekli': return t('TAB_PLAYSTYLE');
      case 'Savunma': return t('TAB_DEFENSE');
      case 'Hücum': return t('TAB_ATTACK');
      case 'Duran Toplar': return t('TAB_SETPIECES');
      case 'Kaptan': return t('TAB_CAPTAIN');
      default: return menuName;
    }
  };

  return (
    <div className="flex flex-col h-full w-full min-h-0 bg-[#0c0a18] text-slate-100 selection:bg-[#7b2cbf] selection:text-white p-1 sm:p-1.5 font-sans gap-1 sm:gap-1.5 rounded-xl border border-[#231b42] shadow-2xl overflow-hidden">

      {/* TOP SUB-TAB NAV BAR MATCHING IMAGE 1 */}
      <div className="bg-[#151128] border border-[#2d234f] rounded-lg px-2 py-1 flex items-center justify-between shrink-0 shadow-lg gap-1 min-w-0">
        {/* Left Sub-Menu Buttons & Inline Recommended Preview Box */}
        <div className="flex items-center gap-1 min-w-0 flex-1">
          <div className="flex items-center gap-1 shrink-0">
            {[
              { key: 'Diziliş', label: t('TAB_FORMATION') || 'Diziliş' },
              { key: 'Taktik', label: t('TAB_TACTICS') || 'Taktik' },
              { key: 'Talimatlar', label: t('TAB_INSTRUCTIONS') || 'Talimatlar' },
              { key: 'Roller', label: t('TAB_ROLES') || 'Roller' }
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setInternalSubMenu(tab.key)}
                className={`px-2 sm:px-2.5 py-0.5 rounded-md text-[10.5px] sm:text-xs font-black transition-all whitespace-nowrap cursor-pointer ${
                  activeSubMenu === tab.key
                    ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/50'
                    : 'text-slate-400 hover:text-white hover:bg-[#231b40]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Inline Compact Recommended Lineup Preview Box */}
          {isRecommendedPreviewActive && (
            <div className="flex items-center gap-1.5 bg-gradient-to-r from-[#2c194d] via-[#3a1d63] to-[#251545] border border-amber-400 px-2.5 py-1 rounded-lg shadow-lg shrink-0 ml-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse shrink-0" />
              <span className="text-[10px] sm:text-xs font-black text-amber-300 whitespace-nowrap pr-0.5">
                {t('RECOMMENDED_XI') || 'Önerilen 11'}
              </span>
              <button
                type="button"
                onClick={onSaveRecommendedLineup}
                className="px-2.5 py-1 rounded-md bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-[9.5px] sm:text-[10.5px] uppercase shadow-md flex items-center gap-1 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                title="Önerilen 11 kadrosunu kaydet"
              >
                <Check className="w-3 h-3 text-slate-950 stroke-[3]" />
                <span>{t('SAVE') || 'Kaydet'}</span>
              </button>
              <button
                type="button"
                onClick={onCancelRecommendedLineup}
                className="px-2.5 py-1 rounded-md bg-rose-950/80 hover:bg-rose-900 border border-rose-500/50 text-rose-200 font-black text-[9.5px] sm:text-[10.5px] uppercase active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                title="Eski kadroya geri dön"
              >
                {t('CANCEL') || 'İptal'}
              </button>
            </div>
          )}
        </div>

        {/* Right Pitch View Mode Icons */}
        <div className="flex items-center gap-0.5 shrink-0 bg-[#1e173b] p-0.5 rounded-md border border-[#372b61]">
          <button
            onClick={() => setViewMode('pitch')}
            className={`p-1 rounded cursor-pointer transition-all ${
              viewMode === 'pitch' ? 'bg-[#7b2cbf] text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
            title="Saha Görünümü"
          >
            <Sliders className="w-3 h-3" />
          </button>
          <button
            onClick={() => setViewMode('table')}
            className={`p-1 rounded cursor-pointer transition-all ${
              viewMode === 'table' ? 'bg-[#7b2cbf] text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
            title="Kadro Listesi Tablosu"
          >
            <Filter className="w-3 h-3" />
          </button>
          <button
            onClick={() => setInternalSubMenu('Taktik')}
            className={`p-1 rounded cursor-pointer transition-all ${
              activeSubMenu === 'Taktik' ? 'bg-[#7b2cbf] text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
            title="Taktik Grafiği"
          >
            <Activity className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* MAIN 4-PANEL LAYOUT OR TABLE VIEW OR TACTICAL SUB-MENUS */}
      {viewMode === 'table' ? (
        <div className="flex-1 min-h-0 overflow-hidden">
          <PlayerTable
            players={team.players}
            selectedPlayer={activeSelectedPlayer}
            onSelectPlayer={onSelectPlayer}
            onSwapPlayers={onSwapPlayers}
            onOpenPlayerProfile={onOpenPlayerProfile}
          />
        </div>
      ) : activeSubMenu === 'Taktik' ? (
        /* TAKTİK DASHBOARD */
        <div className="flex-1 min-h-0 bg-[#130f24]/95 border border-[#2d244c] rounded-2xl p-3 overflow-y-auto custom-scrollbar flex flex-col gap-3 shadow-2xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* Panel 1: Hücum & Pas */}
            <div className="bg-[#18132e] border border-[#2d234f] p-3 rounded-xl space-y-2.5">
              <h4 className="font-black text-xs text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                <Target className="w-4 h-4 text-purple-400" />
                <span>Hücum & Pas Felsefesi</span>
              </h4>

              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-1">Taktik Anlayış</label>
                <div className="grid grid-cols-2 gap-1">
                  {['Hücum', 'Dengeli', 'Savunma', 'Çok Riskli'].map(style => (
                    <button
                      key={style}
                      onClick={() => {
                        const newAtt = { ...attackStyle, focus: style };
                        setAttackStyle(newAtt);
                        syncAllTacticsToParent(playStyle, defenseStyle, newAtt);
                      }}
                      className={`py-1 px-2 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                        attackStyle.focus.includes(style)
                          ? 'bg-purple-600 border-purple-400 text-white shadow'
                          : 'bg-[#120f21] border-[#291f47] text-slate-400 hover:text-white'
                      }`}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-1">Pas Yapısı</label>
                <div className="grid grid-cols-2 gap-1">
                  {['Kısa Pas', 'Karma Pas', 'Direkt Pas', 'Uzun Top'].map(pass => (
                    <button
                      key={pass}
                      onClick={() => {
                        const newPlay = { ...playStyle, passing: pass };
                        setPlayStyle(newPlay);
                        syncAllTacticsToParent(newPlay);
                      }}
                      className={`py-1 px-2 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                        playStyle.passing === pass
                          ? 'bg-purple-600 border-purple-400 text-white shadow'
                          : 'bg-[#120f21] border-[#291f47] text-slate-400 hover:text-white'
                      }`}
                    >
                      {pass}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-1">Oyun Temposu</label>
                <div className="grid grid-cols-3 gap-1">
                  {['Çok Hızlı', 'Hızlı', 'Yavaş'].map(tmp => (
                    <button
                      key={tmp}
                      onClick={() => {
                        const newPlay = { ...playStyle, tempo: tmp };
                        setPlayStyle(newPlay);
                        syncAllTacticsToParent(newPlay);
                      }}
                      className={`py-1 px-1.5 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer text-center ${
                        playStyle.tempo === tmp
                          ? 'bg-purple-600 border-purple-400 text-white shadow'
                          : 'bg-[#120f21] border-[#291f47] text-slate-400 hover:text-white'
                      }`}
                    >
                      {tmp}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-1">Hücum Genişliği</label>
                <div className="grid grid-cols-3 gap-1">
                  {['Geniş', 'Dengeli', 'Dar'].map(w => (
                    <button
                      key={w}
                      onClick={() => {
                        const newPlay = { ...playStyle, width: w };
                        setPlayStyle(newPlay);
                        syncAllTacticsToParent(newPlay);
                      }}
                      className={`py-1 px-1.5 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer text-center ${
                        playStyle.width === w
                          ? 'bg-purple-600 border-purple-400 text-white shadow'
                          : 'bg-[#120f21] border-[#291f47] text-slate-400 hover:text-white'
                      }`}
                    >
                      {w}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Panel 2: Savunma & Pres */}
            <div className="bg-[#18132e] border border-[#2d234f] p-3 rounded-xl space-y-2.5">
              <h4 className="font-black text-xs text-sky-300 uppercase tracking-wider flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-sky-400" />
                <span>Savunma & Pres Çizgisi</span>
              </h4>

              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-1">Savunma Çizgisi</label>
                <div className="grid grid-cols-3 gap-1">
                  {['Yüksek', 'Normal', 'Derin Blok'].map(l => (
                    <button
                      key={l}
                      onClick={() => {
                        const newDef = { ...defenseStyle, line: l };
                        setDefenseStyle(newDef);
                        syncAllTacticsToParent(playStyle, newDef);
                      }}
                      className={`py-1 px-1.5 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer text-center ${
                        defenseStyle.line === l
                          ? 'bg-sky-600 border-sky-400 text-white shadow'
                          : 'bg-[#120f21] border-[#291f47] text-slate-400 hover:text-white'
                      }`}
                    >
                      {l}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-1">Pres Bölgesi</label>
                <div className="grid grid-cols-3 gap-1">
                  {['Tam Saha', 'Yüksek', 'Orta Saha'].map(pz => (
                    <button
                      key={pz}
                      onClick={() => {
                        const newPlay = { ...playStyle, pressZone: pz };
                        setPlayStyle(newPlay);
                        syncAllTacticsToParent(newPlay);
                      }}
                      className={`py-1 px-1.5 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer text-center ${
                        playStyle.pressZone === pz
                          ? 'bg-sky-600 border-sky-400 text-white shadow'
                          : 'bg-[#120f21] border-[#291f47] text-slate-400 hover:text-white'
                      }`}
                    >
                      {pz}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-1">Müdahale Sertliği</label>
                <div className="grid grid-cols-2 gap-1">
                  {['Normal', 'Sert (Agresif)'].map(tck => (
                    <button
                      key={tck}
                      onClick={() => {
                        const newDef = { ...defenseStyle, tackling: tck };
                        setDefenseStyle(newDef);
                        syncAllTacticsToParent(playStyle, newDef);
                      }}
                      className={`py-1 px-2 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                        defenseStyle.tackling === tck
                          ? 'bg-sky-600 border-sky-400 text-white shadow'
                          : 'bg-[#120f21] border-[#291f47] text-slate-400 hover:text-white'
                      }`}
                    >
                      {tck}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-1">Ofsayt Taktiği</label>
                <div className="grid grid-cols-2 gap-1">
                  {['Açık', 'Kapalı'].map(ofs => (
                    <button
                      key={ofs}
                      onClick={() => {
                        const newDef = { ...defenseStyle, offsideTrap: ofs };
                        setDefenseStyle(newDef);
                        syncAllTacticsToParent(playStyle, newDef);
                      }}
                      className={`py-1 px-2 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                        defenseStyle.offsideTrap === ofs
                          ? 'bg-sky-600 border-sky-400 text-white shadow'
                          : 'bg-[#120f21] border-[#291f47] text-slate-400 hover:text-white'
                      }`}
                    >
                      {ofs}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Panel 3: Simülasyon Etki Analizi */}
            <div className="bg-[#18132e] border border-[#2d234f] p-3 rounded-xl space-y-2.5 flex flex-col justify-between">
              <div>
                <h4 className="font-black text-xs text-amber-300 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span>{t('LIVE_SIM_BALANCE') || 'Canlı Simülasyon Dengesi'}</span>
                </h4>

                <div className="space-y-2 text-xs">
                  <div>
                    <div className="flex justify-between text-[11px] font-bold text-slate-300 mb-0.5">
                      <span>{t('OFFENSIVE_POWER') || 'Ofansif Güç'}</span>
                      <span className="text-emerald-400 font-extrabold">%{teamBalance.offensive}</span>
                    </div>
                    <div className="w-full bg-[#120e26] rounded-full h-2 overflow-hidden border border-[#2d244c]">
                      <div className="bg-emerald-400 h-full rounded-full transition-all duration-500" style={{ width: `${teamBalance.offensive}%` }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] font-bold text-slate-300 mb-0.5">
                      <span>{t('POSSESSION_BALANCE') || 'Topa Sahip Olma'}</span>
                      <span className="text-sky-400 font-extrabold">%{teamBalance.possession}</span>
                    </div>
                    <div className="w-full bg-[#120e26] rounded-full h-2 overflow-hidden border border-[#2d244c]">
                      <div className="bg-sky-400 h-full rounded-full transition-all duration-500" style={{ width: `${teamBalance.possession}%` }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] font-bold text-slate-300 mb-0.5">
                      <span>{t('DEFENSIVE_RESISTANCE') || 'Defansif Direnç'}</span>
                      <span className="text-purple-300 font-extrabold">%{teamBalance.defensive}</span>
                    </div>
                    <div className="w-full bg-[#120e26] rounded-full h-2 overflow-hidden border border-[#2d244c]">
                      <div className="bg-purple-500 h-full rounded-full transition-all duration-500" style={{ width: `${teamBalance.defensive}%` }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] font-bold text-slate-300 mb-0.5">
                      <span>{t('PHYSICAL_PRESS_POWER') || 'Fiziksel / Pres Baskısı'}</span>
                      <span className="text-amber-400 font-extrabold">%{teamBalance.physical}</span>
                    </div>
                    <div className="w-full bg-[#120e26] rounded-full h-2 overflow-hidden border border-[#2d244c]">
                      <div className="bg-amber-400 h-full rounded-full transition-all duration-500" style={{ width: `${teamBalance.physical}%` }} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-[#120f21] border border-amber-500/40 p-2.5 rounded-xl text-[10px] space-y-1 text-amber-300/90 font-bold">
                <div className="text-amber-300 font-black flex items-center gap-1">
                  <span>⚡ {t('TACTICAL_IMPACT_SUMMARY') || 'Taktik Etki Özeti'}:</span>
                </div>
                <p>• {playStyle.passing}: İsabetli pas oranını arttırır.</p>
                <p>• {playStyle.tempo} Tempo: Ceza sahası içi şut şansını %+15 yükseltir.</p>
                <p>• {defenseStyle.line} Çizgi: Rakip kontraları kesmede etkilidir.</p>
              </div>
            </div>
          </div>
        </div>
      ) : activeSubMenu === 'Talimatlar' ? (
        /* TALİMATLAR DASHBOARD */
        <div className="flex-1 min-h-0 bg-[#130f24]/95 border border-[#2d244c] rounded-2xl p-3 overflow-y-auto custom-scrollbar flex flex-col gap-3 shadow-2xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* 1. Topa Sahip Olurken */}
            <div className="bg-[#18132e] border border-[#2d234f] p-3 rounded-xl space-y-2">
              <h4 className="font-black text-xs text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <span>⚽ {t('IN_POSSESSION_TITLE') || 'Topa Sahip Olurken'}</span>
              </h4>

              {[
                { key: 'playOutOfDefense', title: t('INST_PLAY_OUT_DEFENSE') || 'Defanstan Pasla Çık', desc: t('INST_PLAY_OUT_DEFENSE_DESC') || 'Stoperler geriden ayağa kısa pasla oyun kurar.' },
                { key: 'workBallIntoBox', title: t('INST_WORK_BALL_BOX') || 'Ceza Sahasına Pasla Gir', desc: t('INST_WORK_BALL_BOX_DESC') || 'Rastgele şut yerine olgunlaşmış pas organizasyonu.' },
                { key: 'shootOnSight', title: t('INST_SHOOT_ON_SIGHT') || 'Gördüğün Yerden Şut Vur', desc: t('INST_SHOOT_ON_SIGHT_DESC') || 'Müsait her pozisyonda uzaktan sert füzeler.' },
                { key: 'overlapWings', title: t('INST_OVERLAP_WINGS') || 'Kanatlardan Bindirme Yap', desc: t('INST_OVERLAP_WINGS_DESC') || 'Bekler hücuma aktif katılır ve sıfıra iner.' },
                { key: 'earlyCrosses', title: t('INST_EARLY_CROSSES') || 'Erken Orta Yap', desc: t('INST_EARLY_CROSSES_DESC') || 'Forvet ceza sahasına girmeden kavisli ortalar.' }
              ].map(item => {
                const val = (instructions as any)[item.key];
                return (
                  <div
                    key={item.key}
                    onClick={() => {
                      const updated = { ...instructions, [item.key]: !val };
                      setInstructions(updated);
                      syncAllTacticsToParent(playStyle, defenseStyle, attackStyle, updated);
                    }}
                    className={`p-2 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                      val
                        ? 'bg-emerald-950/40 border-emerald-500/60 text-white shadow'
                        : 'bg-[#120f21] border-[#271f45] text-slate-400 hover:border-purple-500/50'
                    }`}
                  >
                    <div>
                      <span className="font-extrabold text-xs block text-white">{item.title}</span>
                      <span className="text-[9.5px] text-slate-400 font-semibold">{item.desc}</span>
                    </div>
                    <div className={`w-8 h-4 rounded-full p-0.5 transition-all shrink-0 ${val ? 'bg-emerald-500' : 'bg-slate-700'}`}>
                      <div className={`w-3 h-3 rounded-full bg-white transition-all ${val ? 'translate-x-4' : 'translate-x-0'}`} />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* 2. Top Rakipteyken */}
            <div className="bg-[#18132e] border border-[#2d234f] p-3 rounded-xl space-y-2">
              <h4 className="font-black text-xs text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
                <span>🛡️ {t('OUT_OF_POSSESSION_TITLE') || 'Top Rakipteyken'}</span>
              </h4>

              {[
                { key: 'aggressiveTackling', title: t('INST_AGGRESSIVE_TACKLING') || 'Agresif & Sert Müdahale', desc: t('INST_AGGRESSIVE_TACKLING_DESC') || 'Müdahaleler sertleşir, kart riski artar.' },
                { key: 'useOffsideTrap', title: t('INST_OFFSIDE_TRAP') || 'Ofsayt Taktiği Uygula', desc: t('INST_OFFSIDE_TRAP_DESC') || 'Defans hattı senkronize öne çıkar.' },
                { key: 'tightMarking', title: t('INST_TIGHT_MARKING') || 'Sıkı Adam Adama Markaj', desc: t('INST_TIGHT_MARKING_DESC') || 'Rakip kilit oyunculara yakın baskı.' },
                { key: 'pressGoalkeeper', title: t('INST_PRESS_GK') || 'Kaleciye Pres Yap', desc: t('INST_PRESS_GK_DESC') || 'Forvetler rakip stoper ve kaleciye basar.' }
              ].map(item => {
                const val = (instructions as any)[item.key];
                return (
                  <div
                    key={item.key}
                    onClick={() => {
                      const updated = { ...instructions, [item.key]: !val };
                      setInstructions(updated);
                      syncAllTacticsToParent(playStyle, defenseStyle, attackStyle, updated);
                    }}
                    className={`p-2 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                      val
                        ? 'bg-rose-950/40 border-rose-500/60 text-white shadow'
                        : 'bg-[#120f21] border-[#271f45] text-slate-400 hover:border-purple-500/50'
                    }`}
                  >
                    <div>
                      <span className="font-extrabold text-xs block text-white">{item.title}</span>
                      <span className="text-[9.5px] text-slate-400 font-semibold">{item.desc}</span>
                    </div>
                    <div className={`w-8 h-4 rounded-full p-0.5 transition-all shrink-0 ${val ? 'bg-rose-500' : 'bg-slate-700'}`}>
                      <div className={`w-3 h-3 rounded-full bg-white transition-all ${val ? 'translate-x-4' : 'translate-x-0'}`} />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* 3. Geçiş Oyununda */}
            <div className="bg-[#18132e] border border-[#2d234f] p-3 rounded-xl space-y-2">
              <h4 className="font-black text-xs text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                <span>⚡ {t('IN_TRANSITION_TITLE') || 'Geçiş Oyununda'}</span>
              </h4>

              {[
                { key: 'counterAttack', title: t('INST_COUNTER_ATTACK') || 'Topu Kazanınca Kontraya Çık', desc: t('INST_COUNTER_ATTACK_DESC') || 'Kazanılan topla dikine jet hızında hücum.' },
                { key: 'gegenpress', title: t('INST_GEGENPRESS') || 'Şok Press (Gegenpress)', desc: t('INST_GEGENPRESS_DESC') || 'Top kaybında ilk 5 saniye tüm takımla baskı.' },
                { key: 'slowTempo', title: t('INST_SLOW_TEMPO') || 'Tempoyu Düşür / Oyunu Soğut', desc: t('INST_SLOW_TEMPO_DESC') || 'Skoru korumak için kısa yan paslar.' }
              ].map(item => {
                const val = (instructions as any)[item.key];
                return (
                  <div
                    key={item.key}
                    onClick={() => {
                      const updated = { ...instructions, [item.key]: !val };
                      setInstructions(updated);
                      syncAllTacticsToParent(playStyle, defenseStyle, attackStyle, updated);
                    }}
                    className={`p-2 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                      val
                        ? 'bg-amber-950/40 border-amber-500/60 text-white shadow'
                        : 'bg-[#120f21] border-[#271f45] text-slate-400 hover:border-purple-500/50'
                    }`}
                  >
                    <div>
                      <span className="font-extrabold text-xs block text-white">{item.title}</span>
                      <span className="text-[9.5px] text-slate-400 font-semibold">{item.desc}</span>
                    </div>
                    <div className={`w-8 h-4 rounded-full p-0.5 transition-all shrink-0 ${val ? 'bg-amber-500' : 'bg-slate-700'}`}>
                      <div className={`w-3 h-3 rounded-full bg-white transition-all ${val ? 'translate-x-4' : 'translate-x-0'}`} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : activeSubMenu === 'Roller' ? (
        /* ROLLER DASHBOARD */
        <div className="flex-1 min-h-0 bg-[#130f24]/95 border border-[#2d244c] rounded-2xl p-3 overflow-y-auto custom-scrollbar flex flex-col gap-3 shadow-2xl">
          {/* Special Set-Piece Takers Selection Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
            {/* 1. Takım Kaptanı */}
            {(() => {
              const cap = team.players.find(p => p.id === specialistRoles.captainId) || starters[0] || team.players[0];
              const capStarterIdx = starters.findIndex(s => s.id === cap?.id);
              return (
                <div
                  onClick={() => {
                    if (!isInMatchTactics) setSpecialistModalType('captain');
                  }}
                  className={`bg-[#18132e] border border-[#2d234f] p-2.5 rounded-xl space-y-1.5 transition-all shadow ${
                    isInMatchTactics ? 'opacity-70 cursor-not-allowed' : 'hover:border-amber-400 cursor-pointer hover:bg-[#20183e]'
                  }`}
                  title={isInMatchTactics ? (t('LOCKED_IN_MATCH') || 'Maç oynanırken değiştirilemez') : (t('TEAM_CAPTAIN') || 'Kaptan')}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-amber-300 uppercase tracking-wider block">👑 {t('TEAM_CAPTAIN') || 'Takım Kaptanı'}</span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${
                      isInMatchTactics ? 'text-slate-400 bg-slate-800/60 border-slate-600/40' : 'text-amber-400/80 bg-[#281d45] border-amber-500/30'
                    }`}>
                      {isInMatchTactics ? (t('LOCKED_IN_MATCH') || 'Kilitli 🔒') : (t('CHANGE_DROPDOWN') || 'Değiştir ▾')}
                    </span>
                  </div>
                  {cap ? (
                    <div className="flex items-center gap-2 bg-[#120f21] border border-[#2e2354] p-1.5 rounded-lg">
                      <div className="w-5 h-5 rounded bg-amber-500/20 border border-amber-400/40 text-amber-300 text-[9px] font-black flex items-center justify-center shrink-0">
                        {capStarterIdx !== -1 ? capStarterIdx + 1 : 'K'}
                      </div>
                      <div className="min-w-0 flex-1">
                        <span className="font-extrabold text-xs text-white block truncate">{cap.name}</span>
                        <span className="text-[9px] text-slate-400 font-bold">{cap.position} • OVR: {cap.overall} {cap.isStarting ? `• ${language === 'TR' ? 'İlk 11' : 'XI'}` : `• ${language === 'TR' ? 'Kadro' : 'Squad'}`}</span>
                      </div>
                    </div>
                  ) : (
                    <span className="text-xs text-slate-400 italic">{t('NO_CAPTAIN_SELECTED') || 'Kaptan seçilmedi'}</span>
                  )}
                </div>
              );
            })()}

            {/* 2. Penaltı Kullanıcısı */}
            {(() => {
              const pen = team.players.find(p => p.id === specialistRoles.penaltyTakerId) || team.players.find(p => p.position === 'FW') || starters[0] || team.players[0];
              const penStarterIdx = starters.findIndex(s => s.id === pen?.id);
              return (
                <div
                  onClick={() => {
                    if (!isInMatchTactics) setSpecialistModalType('penalty');
                  }}
                  className={`bg-[#18132e] border border-[#2d234f] p-2.5 rounded-xl space-y-1.5 transition-all shadow ${
                    isInMatchTactics ? 'opacity-70 cursor-not-allowed' : 'hover:border-emerald-400 cursor-pointer hover:bg-[#20183e]'
                  }`}
                  title={isInMatchTactics ? (t('LOCKED_IN_MATCH') || 'Maç oynanırken değiştirilemez') : (t('PENALTY_TAKER') || 'Penaltıcı')}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-emerald-400 uppercase tracking-wider block">⚽ {t('PENALTY_TAKER') || 'Penaltı Kullanıcısı'}</span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${
                      isInMatchTactics ? 'text-slate-400 bg-slate-800/60 border-slate-600/40' : 'text-emerald-400/80 bg-[#281d45] border-emerald-500/30'
                    }`}>
                      {isInMatchTactics ? (t('LOCKED_IN_MATCH') || 'Kilitli 🔒') : (t('CHANGE_DROPDOWN') || 'Değiştir ▾')}
                    </span>
                  </div>
                  {pen ? (
                    <div className="flex items-center gap-2 bg-[#120f21] border border-[#2e2354] p-1.5 rounded-lg">
                      <div className="w-5 h-5 rounded bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[9px] font-black flex items-center justify-center shrink-0">
                        {penStarterIdx !== -1 ? penStarterIdx + 1 : 'P'}
                      </div>
                      <div className="min-w-0 flex-1">
                        <span className="font-extrabold text-xs text-white block truncate">{pen.name}</span>
                        <span className="text-[9px] text-emerald-400 font-bold">{t('SHOOTING_SHORT') || 'Şut'}: {pen.attributes?.shooting || pen.overall} • {pen.position}</span>
                      </div>
                    </div>
                  ) : (
                    <span className="text-xs text-slate-400 italic">{t('NO_PENALTY_SELECTED') || 'Penaltıcı seçilmedi'}</span>
                  )}
                </div>
              );
            })()}

            {/* 3. Serbest Vuruşçu */}
            {(() => {
              const fk = team.players.find(p => p.id === specialistRoles.freekickTakerId) || team.players.find(p => (p.attributes?.shooting || 0) > 80) || starters[0] || team.players[0];
              const fkStarterIdx = starters.findIndex(s => s.id === fk?.id);
              return (
                <div
                  onClick={() => {
                    if (!isInMatchTactics) setSpecialistModalType('freekick');
                  }}
                  className={`bg-[#18132e] border border-[#2d234f] p-2.5 rounded-xl space-y-1.5 transition-all shadow ${
                    isInMatchTactics ? 'opacity-70 cursor-not-allowed' : 'hover:border-sky-400 cursor-pointer hover:bg-[#20183e]'
                  }`}
                  title={isInMatchTactics ? (t('LOCKED_IN_MATCH') || 'Maç oynanırken değiştirilemez') : (t('FREEKICK_TAKER') || 'Frikikçi')}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-sky-400 uppercase tracking-wider block">🎯 {t('FREEKICK_TAKER') || 'Serbest Vuruşçu'}</span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${
                      isInMatchTactics ? 'text-slate-400 bg-slate-800/60 border-slate-600/40' : 'text-sky-400/80 bg-[#281d45] border-sky-500/30'
                    }`}>
                      {isInMatchTactics ? (t('LOCKED_IN_MATCH') || 'Kilitli 🔒') : (t('CHANGE_DROPDOWN') || 'Değiştir ▾')}
                    </span>
                  </div>
                  {fk ? (
                    <div className="flex items-center gap-2 bg-[#120f21] border border-[#2e2354] p-1.5 rounded-lg">
                      <div className="w-5 h-5 rounded bg-sky-500/20 border border-sky-400/40 text-sky-300 text-[9px] font-black flex items-center justify-center shrink-0">
                        {fkStarterIdx !== -1 ? fkStarterIdx + 1 : 'F'}
                      </div>
                      <div className="min-w-0 flex-1">
                        <span className="font-extrabold text-xs text-white block truncate">{fk.name}</span>
                        <span className="text-[9px] text-sky-300 font-bold">{t('PASSING_SHORT') || 'Pas'}/{t('SHOOTING_SHORT') || 'Şut'}: {Math.max(fk.attributes?.shooting || 0, fk.attributes?.passing || 0)}</span>
                      </div>
                    </div>
                  ) : (
                    <span className="text-xs text-slate-400 italic">{t('NO_FREEKICK_SELECTED') || 'Frikikçi seçilmedi'}</span>
                  )}
                </div>
              );
            })()}

            {/* 4. Korner Kullanıcısı */}
            {(() => {
              const crn = team.players.find(p => p.id === specialistRoles.cornerTakerId) || team.players.find(p => p.position === 'MID') || starters[0] || team.players[0];
              const crnStarterIdx = starters.findIndex(s => s.id === crn?.id);
              return (
                <div
                  onClick={() => {
                    if (!isInMatchTactics) setSpecialistModalType('corner');
                  }}
                  className={`bg-[#18132e] border border-[#2d234f] p-2.5 rounded-xl space-y-1.5 transition-all shadow ${
                    isInMatchTactics ? 'opacity-70 cursor-not-allowed' : 'hover:border-purple-400 cursor-pointer hover:bg-[#20183e]'
                  }`}
                  title={isInMatchTactics ? (t('LOCKED_IN_MATCH') || 'Maç oynanırken değiştirilemez') : (t('CORNER_TAKER') || 'Kornerci')}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-purple-300 uppercase tracking-wider block">🚩 {t('CORNER_TAKER') || 'Korner Kullanıcısı'}</span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${
                      isInMatchTactics ? 'text-slate-400 bg-slate-800/60 border-slate-600/40' : 'text-purple-300/80 bg-[#281d45] border-purple-500/30'
                    }`}>
                      {isInMatchTactics ? (t('LOCKED_IN_MATCH') || 'Kilitli 🔒') : (t('CHANGE_DROPDOWN') || 'Değiştir ▾')}
                    </span>
                  </div>
                  {crn ? (
                    <div className="flex items-center gap-2 bg-[#120f21] border border-[#2e2354] p-1.5 rounded-lg">
                      <div className="w-5 h-5 rounded bg-purple-500/20 border border-purple-400/40 text-purple-300 text-[9px] font-black flex items-center justify-center shrink-0">
                        {crnStarterIdx !== -1 ? crnStarterIdx + 1 : 'C'}
                      </div>
                      <div className="min-w-0 flex-1">
                        <span className="font-extrabold text-xs text-white block truncate">{crn.name}</span>
                        <span className="text-[9px] text-purple-300 font-bold">{t('PASSING_SHORT') || 'Pas'}: {crn.attributes?.passing || crn.overall} • {crn.position}</span>
                      </div>
                    </div>
                  ) : (
                    <span className="text-xs text-slate-400 italic">{t('NO_CORNER_SELECTED') || 'Kornerci seçilmedi'}</span>
                  )}
                </div>
              );
            })()}
          </div>

          {/* Individual Starters Role Assignor Grid */}
          <div className="space-y-1.5 mt-2">
            <div className="flex items-center justify-between">
              <h4 className="font-black text-xs text-slate-300 uppercase tracking-wider">Sahadaki İlk 11 Bireysel Rol Görevleri</h4>
              <span className="text-[10px] text-purple-300 font-bold">Role tıklayarak detaylı seçim yapın</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {starters.map((player, idx) => {
                const currentDuty = playerRoles[player.id] || (
                  player.position === 'GK' ? 'Libero Kaleci' :
                  player.position === 'DEF' ? 'Pasör Stoper' :
                  player.position === 'MID' ? 'İki Yönlü (Box-to-Box)' : 'Fırsatçı Golcü'
                );

                return (
                  <div
                    key={player.id}
                    onClick={() => setRoleSelectingPlayer(player)}
                    className="bg-[#18132e] border border-[#2d234f] hover:border-purple-400/70 p-2.5 rounded-xl flex items-center justify-between gap-2 cursor-pointer transition-all hover:bg-[#20183e] group shadow"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="w-5 h-5 rounded-md bg-purple-600/30 border border-purple-500/40 text-purple-300 text-[10px] font-black flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <span className="font-extrabold text-xs text-white truncate">{player.name}</span>
                        <span className="px-1.5 py-0.2 text-[9px] font-black bg-emerald-950 border border-emerald-500/40 text-emerald-300 rounded shrink-0">
                          {player.overall}
                        </span>
                      </div>
                      <span className="text-[9.5px] text-slate-400 font-bold block mt-0.5">{player.position}</span>
                    </div>

                    <div className="flex items-center gap-1.5 bg-[#251a44] group-hover:bg-purple-900/60 border border-purple-500/40 px-2 py-1 rounded-lg transition-all shrink-0">
                      <span className="text-[10px] text-purple-200 font-extrabold">{currentDuty}</span>
                      <Settings className="w-3 h-3 text-purple-300" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 min-h-0 grid grid-cols-12 gap-1.5 sm:gap-2">

          {/* 1. LEFT PANEL: TACTICAL CONTROLS (2 Cols) */}
          <div className="col-span-2 h-full min-h-0 bg-[#130f24]/95 backdrop-blur border border-[#2d244c] rounded-xl p-1.5 flex flex-col justify-start overflow-visible relative z-30 shadow-2xl space-y-1.5 text-xs">
            
            {/* Section: DİZİLİŞ */}
            <div className="space-y-0.5 relative z-30 shrink-0">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block">{t('FORMATION_LABEL') || 'DİZİLİŞ'}</span>
              <CustomSelect
                value={team.formation}
                onChange={(val) => onChangeFormation(val as FormationType)}
                options={formationSelectOptions}
              />
            </div>

            {/* Section: TAKTİK */}
            <div className="space-y-0.5 relative z-20 shrink-0">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block">{t('TACTIC_LABEL') || 'TAKTİK'}</span>
              <CustomSelect
                value={team.tactic}
                onChange={(val) => onChangeTactic(val as TacticType)}
                options={tacticSelectOptions}
              />
            </div>

            {/* Section: OYUN ANLAYIŞI */}
            <div className="space-y-0.5 relative z-10 shrink-0">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block">
                {t('TACTIC_PLAYSTYLE') || (language === 'TR' ? 'OYUN ANLAYIŞI' : 'PLAY STYLE')}
              </span>
              <CustomSelect
                value={currentPlayStyleId}
                onChange={(val) => setAttackStyle(p => ({ ...p, focus: val }))}
                options={playStyleSelectOptions}
              />
            </div>

            {/* Section: TAKIM DENGESİ */}
            {!hideTeamBalance && (
              <div className="space-y-1 pt-1.5 border-t border-[#251d3f] shrink-0 mt-auto">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-black text-purple-300 uppercase tracking-wider block">
                    {t('TEAM_BALANCE') || (language === 'TR' ? 'TAKIM DENGESİ' : 'TEAM BALANCE')}
                  </span>
                </div>
                
                <div className="space-y-1 text-xs">
                  <div>
                    <div className="flex justify-between text-[8.5px] font-bold text-slate-300 mb-0.5 leading-none">
                      <span>{t('TACTIC_OFFENSIVE') || (language === 'TR' ? 'Ofansif' : 'Attacking')}</span>
                      <span className="text-purple-300 font-extrabold">{teamBalance.offensive}</span>
                    </div>
                    <div className="w-full bg-[#1e1738] rounded-full h-1 overflow-hidden border border-[#34275d]">
                      <div className="bg-gradient-to-r from-purple-600 to-indigo-400 h-full rounded-full" style={{ width: `${teamBalance.offensive}%` }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[8.5px] font-bold text-slate-300 mb-0.5 leading-none">
                      <span>{t('TACTIC_DEFENSIVE') || (language === 'TR' ? 'Defansif' : 'Defending')}</span>
                      <span className="text-purple-300 font-extrabold">{teamBalance.defensive}</span>
                    </div>
                    <div className="w-full bg-[#1e1738] rounded-full h-1 overflow-hidden border border-[#34275d]">
                      <div className="bg-gradient-to-r from-purple-600 to-indigo-400 h-full rounded-full" style={{ width: `${teamBalance.defensive}%` }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[8.5px] font-bold text-slate-300 mb-0.5 leading-none">
                      <span>{t('TACTIC_PHYSICAL') || (language === 'TR' ? 'Fiziksel' : 'Physical')}</span>
                      <span className="text-purple-300 font-extrabold">{teamBalance.physical}</span>
                    </div>
                    <div className="w-full bg-[#1e1738] rounded-full h-1 overflow-hidden border border-[#34275d]">
                      <div className="bg-gradient-to-r from-purple-600 to-indigo-400 h-full rounded-full" style={{ width: `${teamBalance.physical}%` }} />
                    </div>
                  </div>
                </div>
              </div>
            )}

          </div>

          {/* 2. CENTER PANEL: EXPANDED REALISTIC FOOTBALL PITCH (7 Cols) */}
          <div 
            onClick={() => {
              onSelectPlayer(null);
              setSelectedEmptySlotIdx(null);
            }}
            className="col-span-7 h-full min-h-0 flex flex-col relative rounded-2xl overflow-hidden border-2 border-emerald-900/90 shadow-2xl bg-[#061d11] select-none p-1 sm:p-2 items-center justify-center cursor-default"
          >
            
            {/* Pitch Surface Wrapper */}
            <div 
              onClick={(e) => {
                if (e.target === e.currentTarget || (e.target as HTMLElement).classList.contains('pitch-bg-surface')) {
                  onSelectPlayer(null);
                  setSelectedEmptySlotIdx(null);
                }
              }}
              className="w-full h-full relative rounded-xl overflow-hidden flex flex-col scale-100 pitch-bg-surface cursor-default bg-gradient-to-b from-[#0a351b] via-[#0d4223] to-[#0a351b]"
            >

              {/* Realistic Alternating Lawn Cut Stripes */}
              <div className="absolute inset-0 flex flex-col pointer-events-none opacity-45 pitch-bg-surface">
                {[...Array(10)].map((_, i) => (
                  <div
                    key={i}
                    className={`flex-1 w-full ${i % 2 === 0 ? 'bg-[#0f4423]' : 'bg-[#0b351b]'}`}
                  />
                ))}
              </div>

              {/* Realistic Football Pitch Markings (Authentic Lines & Arcs) */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 100">
                {/* Outer Touchlines & Goal Lines */}
                <rect x="2.5" y="2.5" width="95" height="95" rx="1.5" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />

                {/* Halfway Line */}
                <line x1="2.5" y1="50" x2="97.5" y2="50" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />

                {/* Center Circle & Center Dot */}
                <circle cx="50" cy="50" r="11.5" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />
                <circle cx="50" cy="50" r="0.9" fill="rgba(255,255,255,0.6)" />

                {/* Top Penalty Box (Ceza Sahası) */}
                <rect x="22" y="2.5" width="56" height="17" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />

                {/* Top Goal Area (Altıpas) */}
                <rect x="36" y="2.5" width="28" height="6.5" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />

                {/* Top Penalty Spot */}
                <circle cx="50" cy="11.5" r="0.8" fill="rgba(255,255,255,0.6)" />

                {/* Top Penalty Arc (Ceza Sahası Yayı) */}
                <path d="M 40 19.5 A 10 10 0 0 0 60 19.5" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />

                {/* Top Goal Frame */}
                <rect x="42" y="0.8" width="16" height="1.7" fill="rgba(255,255,255,0.15)" stroke="rgba(255,255,255,0.5)" strokeWidth="0.6" />

                {/* Bottom Penalty Box (Ceza Sahası) */}
                <rect x="22" y="80.5" width="56" height="17" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />

                {/* Bottom Goal Area (Altıpas) */}
                <rect x="36" y="91" width="28" height="6.5" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />

                {/* Bottom Penalty Spot */}
                <circle cx="50" cy="88.5" r="0.8" fill="rgba(255,255,255,0.6)" />

                {/* Bottom Penalty Arc (Ceza Sahası Yayı) */}
                <path d="M 40 80.5 A 10 10 0 0 1 60 80.5" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />

                {/* Bottom Goal Frame */}
                <rect x="42" y="97.5" width="16" height="1.7" fill="rgba(255,255,255,0.15)" stroke="rgba(255,255,255,0.5)" strokeWidth="0.6" />

                {/* 4 Corner Arcs */}
                <path d="M 2.5 6 A 3.5 3.5 0 0 0 6 2.5" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />
                <path d="M 94 2.5 A 3.5 3.5 0 0 0 97.5 6" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />
                <path d="M 2.5 94 A 3.5 3.5 0 0 1 6 97.5" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />
                <path d="M 94 97.5 A 3.5 3.5 0 0 1 97.5 94" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8" />
              </svg>

            {/* 11 Starter Players on Pitch */}
            {starterSlots.map((player, idx) => {
              const pos = getPlayerPositionOnPitch(idx, team.formation);
              const isSelected = player ? activeSelectedPlayer?.id === player.id : false;
              const isEmptySlotSelected = !player && selectedEmptySlotIdx === idx;
              const shirtNum = player ? getShirtNumber(player, idx) : '+';
              const lastName = player ? getLastName(player.name) : (language === 'TR' ? 'BOŞ' : 'EMPTY');
              const roleDuty = player ? getRoleDutyCode(player, idx, team.formation) : '-';
              const eff = player ? calculatePlayerEffectiveOverall(player, idx, team.formation) : null;

              return (
                <div
                  key={player ? player.id : `empty-${idx}`}
                  role="button"
                  tabIndex={0}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (player) {
                      if (!isLongPressTriggeredRef.current) {
                        handlePlayerInteraction(player, 'swap_or_select');
                      }
                    } else {
                      // Clicked empty slot: place selected player or toggle empty slot selection
                      if (propSelectedPlayer) {
                        onSwapPlayers(propSelectedPlayer, { id: `empty-slot-${idx}`, name: 'Boş Slot', isStarting: false } as Player);
                        onSelectPlayer(null);
                        setSelectedEmptySlotIdx(null);
                      } else {
                        setSelectedEmptySlotIdx(prev => prev === idx ? null : idx);
                      }
                    }
                  }}
                  onPointerDown={() => {
                    if (player) handlePitchPlayerPointerDown(player);
                  }}
                  onPointerUp={() => {
                    if (longPressTimerRef.current) {
                      clearTimeout(longPressTimerRef.current);
                      longPressTimerRef.current = null;
                    }
                  }}
                  onPointerLeave={handlePitchPlayerPointerLeave}
                  onContextMenu={(e) => {
                    if (player) {
                      e.preventDefault();
                      setRoleSelectingPlayer(player);
                    }
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      if (player) {
                        if (propSelectedPlayer) {
                          if (propSelectedPlayer.id === player.id) {
                            onSelectPlayer(null);
                          } else {
                            onSwapPlayers(propSelectedPlayer, player);
                          }
                        } else {
                          onSelectPlayer(player);
                        }
                      } else {
                        if (propSelectedPlayer) {
                          onSwapPlayers(propSelectedPlayer, { id: `empty-slot-${idx}`, name: 'Boş Slot', isStarting: false } as Player);
                          onSelectPlayer(null);
                          setSelectedEmptySlotIdx(null);
                        } else {
                          setSelectedEmptySlotIdx(prev => prev === idx ? null : idx);
                        }
                      }
                    }
                  }}
                  style={{
                    top: pos.top,
                    left: pos.left,
                    transform: 'translate(-50%, -50%)'
                  }}
                  className="absolute flex flex-col items-center group transition-all duration-300 touch-manipulation z-10 active:scale-95 cursor-pointer outline-none select-none"
                >
                  <div className={`relative w-[44px] sm:w-[50px] h-[34px] sm:h-[38px] flex flex-col items-center justify-between p-0.5 rounded-lg transition-all shadow-md ${
                    !player
                      ? isEmptySlotSelected
                        ? 'bg-[#291e4a]/95 border border-dashed border-amber-400 ring-2 ring-amber-400/60 shadow-xl scale-105 animate-pulse'
                        : 'bg-[#100c1e]/80 backdrop-blur border border-dashed border-slate-500/60 hover:border-amber-400 hover:bg-[#1a1433]/90'
                      : isSelected
                        ? 'ring-2 ring-amber-400 bg-[#191133]/95 border border-amber-300/80 shadow-2xl scale-105'
                        : eff?.isOutOfPosition
                          ? 'bg-[#260810]/95 backdrop-blur border border-red-500/80 hover:border-red-400'
                          : 'bg-[#0d0a1b]/95 backdrop-blur border border-[#372b5c] hover:border-purple-400 hover:bg-[#16102e]'
                  }`}>
                    
                    {/* Top Jersey Number / Position Badge */}
                    <div className="relative flex items-center justify-center -mt-0.5">
                      <div className={`font-black text-[7px] sm:text-[7.5px] px-1 py-0.1 rounded shadow-sm leading-tight ${
                        !player
                          ? isEmptySlotSelected
                            ? 'bg-amber-500 text-slate-950 font-black'
                            : 'bg-slate-800 text-slate-300'
                          : eff?.isOutOfPosition
                            ? 'bg-gradient-to-r from-red-700 to-rose-600 text-white'
                            : 'bg-gradient-to-r from-purple-700 via-indigo-600 to-purple-600 text-white'
                      }`}>
                        {shirtNum}
                      </div>

                      {/* Status / Checkmark / Warning Indicator */}
                      {player && (
                        player.isInjured ? (
                          <div 
                            title={`Sakat! (${player.injuryWeeksLeft || 1} hafta)`}
                            className="absolute -top-1 -left-2 w-3 h-3 rounded-full bg-rose-600 text-white flex items-center justify-center font-bold text-[6px] border border-rose-300 shadow animate-pulse"
                          >
                            🚑
                          </div>
                        ) : player.isSuspended ? (
                          <div 
                            title={`Cezalı! (${player.suspensionReason || `${player.suspensionMatchesLeft || 1} maç`})`}
                            className="absolute -top-1 -left-2 w-3 h-3 rounded-full bg-red-600 text-white flex items-center justify-center font-bold text-[6px] border border-red-300 shadow"
                          >
                            🟥
                          </div>
                        ) : eff?.isOutOfPosition ? (
                          <div 
                            title={`Mevki Dışı! Doğal: ${player.position} -> Efektif GEN: ${eff.effectiveOverall}`}
                            className="absolute -top-1 -left-1.5 w-2.5 h-2.5 rounded-full bg-red-600 text-white flex items-center justify-center font-bold text-[6px] border border-red-300 shadow animate-pulse"
                          >
                            !
                          </div>
                        ) : (
                          <div className="absolute -top-1 -left-1.5 w-2 h-2 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center font-bold text-[5.5px] shadow-sm">
                            ✓
                          </div>
                        )
                      )}

                      {/* Small 'X' button in top-right corner to clear player to empty slot - ONLY shows when player card is clicked/selected */}
                      {player && isSelected && (
                        <button
                          type="button"
                          id={`pitch-slot-remove-${player.id}`}
                          title={language === 'TR' ? "Kadro'dan Çıkar (Yedeklere Al & Boş Slot Yap)" : "Remove from Starting XI"}
                          onClick={(e) => {
                            e.stopPropagation();
                            onSwapPlayers(player, { id: `empty-slot-remove-${player.id}`, name: 'Boş Slot', isStarting: false } as Player);
                            if (propSelectedPlayer?.id === player.id || activeSelectedPlayer?.id === player.id) {
                              onSelectPlayer(null);
                            }
                            setSelectedEmptySlotIdx(null);
                          }}
                          className="absolute -top-2 -right-2.5 z-40 w-4.5 h-4.5 sm:w-5 sm:h-5 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center font-black text-[9px] sm:text-[10px] border-2 border-white shadow-xl cursor-pointer transition-all hover:scale-125 active:scale-95 ring-2 ring-rose-400 animate-fadeIn"
                        >
                          ✕
                        </button>
                      )}
                    </div>

                    {/* Player Surname or Empty label */}
                    <span className={`font-black text-[7px] sm:text-[7.5px] tracking-tight truncate max-w-[40px] sm:max-w-[46px] px-0.5 leading-none whitespace-nowrap text-center ${
                      !player ? (isEmptySlotSelected ? 'text-amber-300 font-black' : 'text-slate-300') : 'text-white'
                    }`} title={player?.name || lastName}>
                      {lastName}
                    </span>

                    {/* Position Role & Rating Text */}
                    <div className="text-[6px] sm:text-[6.5px] font-extrabold flex items-center justify-center gap-0.5 px-0.5 leading-none whitespace-nowrap flex-nowrap shrink-0 pb-0.2">
                      {player ? (
                        <>
                          <span className={`whitespace-nowrap ${eff?.isOutOfPosition ? 'text-red-300' : 'text-emerald-400 font-bold'}`}>{roleDuty}</span>
                          <span className={`font-black whitespace-nowrap ${eff?.isOutOfPosition ? 'text-red-400' : 'text-white'}`}>
                            {eff ? eff.effectiveOverall : player.overall}
                          </span>
                        </>
                      ) : (
                        <span className={`font-black text-[6px] ${isEmptySlotSelected ? 'text-amber-400' : 'text-slate-400'}`}>
                          {isEmptySlotSelected ? (language === 'TR' ? 'SEÇİLİ' : 'SELECTED') : (language === 'TR' ? '+ EKLE' : '+ ADD')}
                        </span>
                      )}
                    </div>

                  </div>
                </div>
              );
            })}

            {/* DETAILED ROLE SELECTION MODAL OVERLAY (INSIDE PITCH VIEW) */}
            {roleSelectingPlayer && (
              <div
                onClick={() => setRoleSelectingPlayer(null)}
                className="absolute inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-3 animate-fadeIn"
              >
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="bg-[#140e2b] border-2 border-purple-500/90 rounded-2xl p-3 sm:p-4 shadow-2xl w-full max-w-md max-h-[94%] flex flex-col gap-2 overflow-hidden text-slate-100 ring-1 ring-purple-400/40"
                >
                  {/* Modal Header */}
                  <div className="flex items-center justify-between border-b border-[#2d2150] pb-2 shrink-0">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-purple-700 to-indigo-500 text-white font-black text-xs flex items-center justify-center border border-purple-400/50 shadow">
                        {roleSelectingPlayer.position}
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-black text-xs sm:text-sm text-white flex items-center gap-1.5 truncate">
                          <span>{roleSelectingPlayer.name}</span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-950 text-purple-300 border border-purple-500/40">
                            GEN: {roleSelectingPlayer.overall}
                          </span>
                        </h3>
                        <p className="text-[9.5px] text-purple-300 font-bold">
                          {(() => {
                            const l = (language || 'TR').toUpperCase();
                            if (l === 'ES') return 'Selección de Rol y Tarea Táctica';
                            if (l === 'FR') return 'Sélection du Rôle et Devoir Tactique';
                            if (l === 'IT') return 'Selezione Ruolo e Compito Tattico';
                            if (l === 'PT') return 'Seleção de Função e Tarefa Tática';
                            if (l === 'DE') return 'Taktische Rollen- und Aufgabenauswahl';
                            if (l === 'EN') return 'Tactical Role & Duty Selection';
                            return 'Taktiksel Rol & Görev Seçimi';
                          })()}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setRoleSelectingPlayer(null)}
                      className="w-7 h-7 rounded-lg bg-[#20183e] hover:bg-[#2e2358] border border-[#3b2d6a] text-slate-300 hover:text-white flex items-center justify-center transition-all cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Roles List */}
                  <div className="flex-1 overflow-y-auto custom-scrollbar space-y-1.5 pr-0.5 min-h-0">
                    {getDetailedRolesForPlayer(roleSelectingPlayer, language).map((roleItem) => {
                      const currentRoleName = playerRoles[roleSelectingPlayer.id] || '';
                      const isSelectedRole = currentRoleName.includes(roleItem.name) || currentRoleName.includes(roleItem.code);

                      const dutyColor =
                        roleItem.duty === 'Hücum'
                          ? 'bg-rose-950/80 border-rose-500/60 text-rose-300'
                          : roleItem.duty === 'Destek'
                          ? 'bg-sky-950/80 border-sky-500/60 text-sky-300'
                          : 'bg-emerald-950/80 border-emerald-500/60 text-emerald-300';

                      const keyAttrsText = (() => {
                        const l = (language || 'TR').toUpperCase();
                        if (l === 'ES') return 'Atributos Clave';
                        if (l === 'FR') return 'Attributs Clés';
                        if (l === 'IT') return 'Attributi Chiave';
                        if (l === 'PT') return 'Atributos Chave';
                        if (l === 'DE') return 'Schlüsselattribute';
                        if (l === 'EN') return 'Key Attributes';
                        return 'Kilit Yetenekler';
                      })();

                      const selectedText = (() => {
                        const l = (language || 'TR').toUpperCase();
                        if (l === 'ES') return 'Seleccionado';
                        if (l === 'FR') return 'Sélectionné';
                        if (l === 'IT') return 'Selezionato';
                        if (l === 'PT') return 'Selecionado';
                        if (l === 'DE') return 'Ausgewählt';
                        if (l === 'EN') return 'Selected';
                        return 'Seçildi';
                      })();

                      return (
                        <div
                          key={roleItem.code}
                          onClick={() => {
                            const updatedRoles = { ...playerRoles, [roleSelectingPlayer.id]: roleItem.name };
                            setPlayerRoles(updatedRoles);
                            syncAllTacticsToParent(playStyle, defenseStyle, attackStyle, instructions, specialistRoles, updatedRoles);
                          }}
                          className={`p-2 rounded-xl border transition-all cursor-pointer flex flex-col gap-1 ${
                            isSelectedRole
                              ? 'bg-[#291b52] border-purple-400 ring-2 ring-purple-400/40 shadow-lg'
                              : 'bg-[#181233] border-[#2c204d] hover:border-purple-500/50 hover:bg-[#201844]'
                          }`}
                        >
                          {/* Role Title Bar */}
                          <div className="flex items-center justify-between gap-1.5">
                            <div className="flex items-center gap-1.5 min-w-0">
                              <span className="px-1.5 py-0.5 rounded-md bg-[#2d1c5a] border border-purple-400/40 text-purple-200 font-black text-[10px]">
                                {roleItem.code}
                              </span>
                              <span className="font-extrabold text-xs text-white truncate">
                                {roleItem.name}
                              </span>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <span className={`px-2 py-0.5 rounded-full text-[8.5px] font-black border uppercase ${dutyColor}`}>
                                {roleItem.dutyLabel}
                              </span>
                              <div className="text-amber-400 text-[10px] tracking-tight">
                                {'★'.repeat(roleItem.stars)}{'☆'.repeat(5 - roleItem.stars)}
                              </div>
                            </div>
                          </div>

                          {/* Description */}
                          <p className="text-[9.5px] text-slate-300 font-medium leading-relaxed">
                            {roleItem.description}
                          </p>

                          {/* Key Attributes & Active State */}
                          <div className="flex items-center justify-between pt-1 border-t border-[#251b47] text-[8.5px]">
                            <div className="flex items-center gap-1 text-slate-400">
                              <span className="font-bold text-slate-400">{keyAttrsText}:</span>
                              <span className="text-purple-300 font-extrabold">{roleItem.keyAttributes.join(', ')}</span>
                            </div>

                            {isSelectedRole && (
                              <span className="flex items-center gap-1 text-emerald-400 font-black">
                                <Check className="w-3 h-3 text-emerald-400" />
                                <span>{selectedText}</span>
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Modal Footer */}
                  <div className="pt-1.5 border-t border-[#2d2150] flex items-center justify-end gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => setRoleSelectingPlayer(null)}
                      className="px-4 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs uppercase shadow-md active:scale-95 transition-all cursor-pointer"
                    >
                      {(() => {
                        const l = (language || 'TR').toUpperCase();
                        if (l === 'ES') return 'Confirmar';
                        if (l === 'FR') return 'Confirmer';
                        if (l === 'IT') return 'Conferma';
                        if (l === 'PT') return 'Confirmar';
                        if (l === 'DE') return 'Bestätigen';
                        if (l === 'EN') return 'Confirm';
                        return 'Tamam';
                      })()}
                    </button>
                  </div>
                </div>
              </div>
            )}

            </div>
          </div>

          {/* 3. RIGHT PANEL: İLK 11 TABLE (3 Cols) */}
          <div className="col-span-3 h-full min-h-0 bg-[#130f24]/95 backdrop-blur border border-[#2d244c] rounded-xl p-1.5 sm:p-2 flex flex-col justify-start shadow-2xl gap-1 overflow-hidden min-w-0 relative">
            
            {/* Upper Section: İLK 11 TABLE */}
            <div className="flex-1 min-h-0 flex flex-col overflow-hidden">
              {/* Header: Localized Starting 11 */}
              <div className="flex items-center justify-between border-b border-[#2d244c] pb-1 mb-1 shrink-0">
                <span className="font-black text-[11px] text-white uppercase tracking-wider">
                  {(() => {
                    const l = (language || 'TR').toUpperCase();
                    switch (l) {
                      case 'TR': return 'İLK 11';
                      case 'ES': return 'ONCE INICIAL';
                      case 'PT': return 'ONZE INICIAL';
                      case 'IT': return 'FORMAZIONE TITOLARE';
                      case 'FR': return 'ONZE DE DÉPART';
                      case 'DE': return 'STARTELF';
                      case 'EN':
                      default:
                        return 'STARTING 11';
                    }
                  })()}
                </span>
                
                <span className="px-1.5 py-0.2 rounded bg-purple-950/80 border border-purple-500/40 text-purple-300 font-extrabold text-[8.5px]">
                  {displayedStarters.length}/11
                </span>
              </div>

              {/* Table Header */}
              <div className="flex items-center text-[8px] sm:text-[8.5px] font-extrabold text-slate-400 uppercase tracking-wider pb-1 px-1 shrink-0 border-b border-[#231a3d] gap-1">
                <span className="w-5.5 shrink-0 text-left pl-0.5">{t('POSITION_HEADER') || 'POZ'}</span>
                <span className="flex-1 min-w-0 px-0.5">{t('PLAYER_HEADER') || 'OYUNCU'}</span>
                <span className="w-6 shrink-0 text-center">{t('STATUS_HEADER') || 'DURUM'}</span>
              </div>

              {/* Table Rows: 11 Starters (or empty slots) */}
              <div className="flex-1 overflow-y-auto custom-scrollbar space-y-1 pr-0.5 pt-1">
                {starterSlots.map((p, slotIdx) => {
                  if (!p) {
                    const isSlotSelected = selectedEmptySlotIdx === slotIdx;
                    const defaultPosCode = FORMATION_COORDINATES[team.formation]?.[slotIdx]?.role || 'POS';
                    return (
                      <div
                        key={`empty-starter-row-${slotIdx}`}
                        onClick={() => {
                          if (propSelectedPlayer) {
                            onSwapPlayers(propSelectedPlayer, { id: `empty-slot-${slotIdx}`, name: 'Boş Slot', isStarting: false } as Player);
                            onSelectPlayer(null);
                            setSelectedEmptySlotIdx(null);
                          } else {
                            setSelectedEmptySlotIdx((prev) => (prev === slotIdx ? null : slotIdx));
                          }
                        }}
                        className={`flex items-center gap-1 py-1 px-1.5 rounded-lg border border-dashed transition-all cursor-pointer select-none ${
                          isSlotSelected
                            ? 'bg-[#291c4d] border-amber-400 text-amber-300 shadow ring-1 ring-amber-400/50 animate-pulse'
                            : 'bg-[#120d24]/60 border-slate-700/60 hover:border-amber-400 text-slate-400 hover:bg-[#1a1336]'
                        }`}
                      >
                        <span className="w-5.5 h-4.5 shrink-0 flex items-center justify-center rounded font-black text-[7.5px] bg-[#1d1636] text-slate-400 border border-slate-700">
                          {defaultPosCode}
                        </span>
                        <div className="flex-1 min-w-0 flex items-center justify-between gap-1">
                          <span className="font-extrabold text-amber-400/90 text-[9.5px] tracking-tight whitespace-nowrap">
                            {isSlotSelected ? (language === 'TR' ? 'SEÇİLİ (OYUNCU SEÇİN)' : 'SELECTED') : (language === 'TR' ? '+ BOŞ SLOT (EKLE)' : '+ EMPTY SLOT')}
                          </span>
                          <span className="text-[8px] font-bold text-slate-500">-</span>
                        </div>
                        <div className="w-6 shrink-0 flex items-center justify-center text-slate-500 text-[10px]">
                          +
                        </div>
                      </div>
                    );
                  }

                  const isSelected = activeSelectedPlayer?.id === p.id;
                  const posCode = getFmmPosCode(p, slotIdx);
                  const eff = calculatePlayerEffectiveOverall(p, slotIdx, team.formation);
                  const knownName = getLastName(p.name);

                  return (
                    <div
                      key={p.id}
                      onClick={() => handlePlayerInteraction(p, 'swap_or_select')}
                      onDoubleClick={(e) => {
                        e.stopPropagation();
                        onOpenPlayerProfile?.(p);
                      }}
                      title={`${p.name} (Doğal Mevki: ${p.position} • Çift tıklayarak profili açın)`}
                      className={`flex items-center gap-1 py-1 px-1.5 rounded-lg border transition-all cursor-pointer select-none ${
                        isSelected
                          ? 'bg-[#291c4d] border-purple-500 text-white font-extrabold shadow ring-1 ring-purple-400/40'
                          : 'bg-[#18132e] border-[#292047] hover:border-purple-400 text-slate-200 hover:bg-[#20183e]'
                      }`}
                    >
                      {/* Position Badge */}
                      <span className={`w-5.5 h-4.5 shrink-0 flex items-center justify-center rounded font-black text-[7.5px] tracking-tight border ${
                        eff.isRedAlert
                          ? 'bg-red-950/90 text-red-300 border-red-500/60'
                          : 'bg-[#231b42] text-purple-300 border-purple-500/30'
                      }`}>
                        {posCode}
                      </span>

                      {/* Player Name & OVR */}
                      <div className="flex-1 min-w-0 flex items-center justify-between gap-1">
                        <span className="font-extrabold text-white tracking-tight text-[10px] sm:text-[10.5px] whitespace-nowrap overflow-hidden text-clip flex-1 min-w-0">
                          {knownName}
                        </span>
                        <span className="text-[8.5px] font-black text-purple-300 shrink-0 ml-0.5">
                          {eff ? eff.effectiveOverall : p.overall}
                        </span>
                      </div>

                      {/* Right Status / Indicator */}
                      <div className="w-6 shrink-0 flex items-center justify-center">
                        {p.isInjured ? (
                          <span className="text-[9px]" title={`Sakat (${p.injuryWeeksLeft || 1} hafta)`}>🚑</span>
                        ) : p.isSuspended ? (
                          <span className="text-[9px]" title={`Cezalı (${p.suspensionReason || `${p.suspensionMatchesLeft || 1} maç`})`}>🟥</span>
                        ) : eff.isRedAlert ? (
                          <div className="w-3.5 h-3.5 rounded-full bg-red-600 text-white font-black text-[7.5px] flex items-center justify-center shadow-sm" title="Mevki Dışı">
                            !
                          </div>
                        ) : (
                          <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 text-slate-950 font-black text-[7.5px] flex items-center justify-center shadow-sm shadow-emerald-500/50" title="Uygun Mevki">
                            ✓
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* PLAYER INFO PANEL (OYUNCU BİLGİ PANELİ) - Compact, reduced GEN & Kondisyon, stats shifted up */}
            {!hidePlayerDetailBox && (
              propSelectedPlayer ? (
                <div className="bg-[#181233] border border-purple-500/70 rounded-xl p-1.5 shrink-0 flex flex-col justify-between shadow-2xl animate-fadeIn h-auto min-h-[64px] max-h-[82px] overflow-hidden gap-1">
                  {/* Header: Position Badge, Clickable Single Name, Age, OVR & Close */}
                  <div className="flex items-center justify-between border-b border-[#2a1e4c] pb-0.5 leading-none">
                    <div className="flex items-center gap-1.5 min-w-0 flex-1">
                      <span className="w-4 h-4 rounded bg-gradient-to-tr from-purple-800 to-indigo-600 text-amber-300 font-black text-[8px] flex items-center justify-center border border-purple-400/50 shadow shrink-0">
                        {propSelectedPlayer.position}
                      </span>
                      <div className="min-w-0 flex-1">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenPlayerProfile?.(propSelectedPlayer);
                          }}
                          className="font-black text-[11px] text-white hover:text-amber-300 transition-colors block truncate leading-none text-left cursor-pointer hover:underline underline-offset-2"
                          title={language === 'TR' ? `${propSelectedPlayer.name} Profilini Aç` : `Open ${propSelectedPlayer.name} Profile`}
                        >
                          {getLastName(propSelectedPlayer.name)}
                        </button>
                        <span className="text-[7px] text-slate-400 font-bold block leading-none mt-0.5 truncate" title={propSelectedPlayer.name}>
                          {propSelectedPlayer.age || 24} {t('AGE_LABEL') || 'Yaş'} • {propSelectedPlayer.nationality || 'TR'}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0 ml-1">
                      <div className="text-right flex flex-col items-end">
                        <span className="text-[9px] font-black text-amber-300 block leading-none whitespace-nowrap">
                          {propSelectedPlayer.overall} <span className="text-[7px] text-amber-400/80 font-bold">{t('OVR_RATING_LABEL') || 'GEN'}</span>
                        </span>
                        <span className="text-[7px] text-emerald-400 font-bold leading-none mt-0.5 whitespace-nowrap">
                          %{propSelectedPlayer.stamina ?? 100} <span className="text-[6.5px] opacity-80">{t('STAMINA_SHORT') || 'Kond.'}</span>
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectPlayer(null);
                        }}
                        className="w-4 h-4 rounded bg-[#251b47] hover:bg-rose-600 hover:text-white text-slate-400 flex items-center justify-center transition-colors cursor-pointer text-[8.5px] ml-0.5 shrink-0"
                        title="Kapat"
                      >
                        ✕
                      </button>
                    </div>
                  </div>

                  {/* Key Attributes Mini Grid - Shifted Up with tight padding */}
                  <div className="grid grid-cols-5 gap-0.5 text-center bg-[#110c22] p-0.5 sm:p-1 rounded-md border border-[#2b1f4c] text-[7px] sm:text-[7.5px] font-black leading-none mt-0.5">
                    <div>
                      <span className="text-slate-400 block text-[6px] mb-0.5">{t('PACE_SHORT') || 'HIZ'}</span>
                      <span className="text-purple-300 font-extrabold">{propSelectedPlayer.attributes?.pace || propSelectedPlayer.overall}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[6px] mb-0.5">{t('SHOOTING_SHORT') || 'ŞUT'}</span>
                      <span className="text-amber-300 font-extrabold">{propSelectedPlayer.attributes?.shooting || propSelectedPlayer.overall}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[6px] mb-0.5">{t('PASSING_SHORT') || 'PAS'}</span>
                      <span className="text-sky-300 font-extrabold">{propSelectedPlayer.attributes?.passing || propSelectedPlayer.overall}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[6px] mb-0.5">{t('DEFENDING_SHORT') || 'SAV'}</span>
                      <span className="text-emerald-300 font-extrabold">{propSelectedPlayer.attributes?.defending || propSelectedPlayer.overall}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[6px] mb-0.5">{t('PHYSICAL_SHORT') || 'FİZ'}</span>
                      <span className="text-rose-300 font-extrabold">{propSelectedPlayer.attributes?.physical || propSelectedPlayer.overall}</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-[#181233]/70 border border-[#2d244c] border-dashed rounded-xl p-1.5 shrink-0 flex flex-col items-center justify-center text-center gap-0.5 h-auto min-h-[64px] max-h-[82px] overflow-hidden">
                  <span className="text-slate-300 font-extrabold text-[8px]">
                    👤 {t('CLICK_PLAYER_TO_INSPECT') || 'Oyuncu Detay Kutusu'}
                  </span>
                  <span className="text-slate-400 text-[6.5px] leading-tight line-clamp-2 px-1">
                    {t('SELECT_FROM_PITCH_OR_BENCH') || 'Sahadan veya listeden oyuncuya basınca özellikleri burada açılır'}
                  </span>
                </div>
              )
            )}
          </div>

        </div>
      )}

      {/* 4. BOTTOM BENCH PANEL: YEDEKLER / REZERVLER ROW (ONLY IN DİZİLİŞ TAB) */}
      {activeSubMenu === 'Diziliş' && (
        <div className="bg-[#130f24]/90 backdrop-blur border border-[#2d244c] rounded-xl p-1 shrink-0 flex items-center gap-2 overflow-hidden shadow-xl">
          
          {/* Bench Tabs & Add Player Button */}
          <div className="flex items-center gap-1 shrink-0">
            <div className="flex items-center gap-0.5 bg-[#1c1638] p-0.5 rounded-lg border border-[#34275e] text-[10px] font-bold">
              <button
                type="button"
                onClick={() => setBenchTab('Yedekler')}
                className={`px-2.5 py-0.5 rounded-md transition-all cursor-pointer ${
                  benchTab === 'Yedekler'
                    ? 'bg-[#7b2cbf] text-white font-black shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {t('BENCH_TAB_SUBSTITUTES') || 'Yedekler'} ({benchPlayers.length})
              </button>

              {!isInMatchTactics && (
                <button
                  type="button"
                  onClick={() => setBenchTab('Rezervler')}
                  className={`px-2.5 py-0.5 rounded-md transition-all cursor-pointer ${
                    benchTab === 'Rezervler'
                      ? 'bg-[#7b2cbf] text-white font-black shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {t('BENCH_TAB_RESERVES') || 'Rezervler'} ({reservePlayers.length})
                </button>
              )}
            </div>
          </div>

          {/* Horizontal Scrollable Bench/Reserves Players List */}
          <div className="flex-1 flex items-center gap-1.5 overflow-x-auto custom-scrollbar py-0.5">
            {(benchTab === 'Yedekler' ? benchPlayers : reservePlayers).length === 0 ? (
              <span className="text-[10px] text-slate-400 italic px-2 py-0.5 font-medium">
                {benchTab === 'Rezervler' ? (t('NO_RESERVE_PLAYERS') || 'Kadro dışı rezerv oyuncu bulunmuyor.') : (t('NO_BENCH_PLAYERS') || 'Yedek kulübesinde oyuncu bulunmuyor.')}
              </span>
            ) : (
              (benchTab === 'Yedekler' ? benchPlayers : reservePlayers).map((p, idx) => {
                const isSelected = activeSelectedPlayer?.id === p.id;
                const shirtNum = getShirtNumber(p, idx + (benchTab === 'Yedekler' ? 11 : 18));
                const posCode = p.position || 'CM';

                return (
                  <div
                    key={p.id}
                    onClick={() => handlePlayerInteraction(p, 'swap_or_select')}
                    onDoubleClick={(e) => {
                      e.stopPropagation();
                      onOpenPlayerProfile?.(p);
                    }}
                    title={`${p.name} (Double click to inspect)`}
                    className={`bg-[#18132e] border p-1 px-2 rounded-lg flex items-center gap-1.5 cursor-pointer transition-all shrink-0 hover:scale-102 select-none ${
                      isSelected
                        ? 'border-amber-400 bg-[#291e4d] shadow ring-1 ring-amber-400/50'
                        : 'border-[#2d244c] hover:border-purple-400'
                    }`}
                  >
                    {/* Number Badge */}
                    <div className="w-4 h-4 rounded bg-gradient-to-r from-red-600 to-amber-500 text-white font-black text-[9px] flex items-center justify-center shrink-0">
                      {shirtNum}
                    </div>

                    {/* Name & Details */}
                    <div className="flex items-center gap-1 text-[10.5px]">
                      <span className="font-extrabold text-white truncate max-w-[75px]">
                        {getLastName(p.name)}
                      </span>
                      <span className="px-1 py-0.2 rounded bg-[#251b47] text-purple-300 font-black text-[8.5px]">
                        {posCode}
                      </span>
                      <span className="font-black text-amber-300 text-[10px]">
                        {p.overall}
                      </span>
                      {p.isInjured && (
                        <span 
                          title={`Sakat (${p.injuryWeeksLeft || 1} hafta)`}
                          className="px-1 py-0.2 rounded bg-rose-900/90 text-rose-300 border border-rose-500 font-black text-[7.5px] flex items-center gap-0.5 animate-pulse"
                        >
                          🚑 {p.injuryWeeksLeft || 1}H
                        </span>
                      )}
                      {p.isSuspended && (
                        <span 
                          title={`Cezalı (${p.suspensionReason || 'Kırmızı Kart'})`}
                          className="px-1 py-0.2 rounded bg-red-950 text-red-300 border border-red-500 font-black text-[7.5px] flex items-center gap-0.5"
                        >
                          🟥 CEZALI
                        </span>
                      )}
                    </div>

                    {/* Change / Select Button */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setBenchSwapModalPlayer(p);
                      }}
                      title="Swap player"
                      className="ml-1 text-[7.5px] font-black bg-purple-900/60 text-purple-200 hover:bg-purple-700 border border-purple-500/50 px-1 py-0.2 rounded cursor-pointer"
                    >
                      {t('CHANGE_BUTTON') || 'Değiştir'}
                    </button>

                    {/* Quick Move Action */}
                    {benchTab === 'Rezervler' ? (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setBenchPickerModalForReserve(p);
                        }}
                        title="Move to bench"
                        className="text-[7.5px] font-black bg-emerald-950 text-emerald-300 hover:bg-emerald-800 border border-emerald-500/60 px-1.5 py-0.5 rounded cursor-pointer transition-all active:scale-95"
                      >
                        + {t('BENCH_SHORT') || 'Yedek'}
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setReservePickerModalForBench(p);
                        }}
                        title="Move to reserves"
                        className="text-[7.5px] font-black bg-rose-950 text-rose-300 hover:bg-rose-800 border border-rose-500/60 px-1.5 py-0.5 rounded cursor-pointer transition-all active:scale-95"
                      >
                        ⇄ {t('RESERVE_SHORT') || 'Rezerv'}
                      </button>
                    )}
                  </div>
                );
              })
            )}
          </div>

        </div>
      )}

      {/* INDIVIDUAL PLAYER TACTICAL ROLE SELECTION MODAL */}
      {roleSelectingPlayer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
          <div className="bg-[#15102a] border border-purple-500/50 rounded-2xl p-3 sm:p-4 max-w-lg w-[95vw] sm:w-full max-h-[85vh] flex flex-col shadow-2xl gap-2">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-[#2d2150] pb-2 shrink-0">
              <div className="flex items-center gap-2 min-w-0 pr-2">
                <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-purple-600/30 border border-purple-500/50 text-purple-300 font-black text-xs flex items-center justify-center shrink-0">
                  {roleSelectingPlayer.position}
                </div>
                <div className="min-w-0">
                  <h3 className="font-black text-xs sm:text-sm text-white flex items-center gap-1.5 truncate">
                    <span className="truncate">{roleSelectingPlayer.name}</span>
                    <span className="px-1 py-0.1 rounded bg-amber-950 border border-amber-500/50 text-amber-300 text-[9px] shrink-0">
                      {roleSelectingPlayer.overall} OVR
                    </span>
                  </h3>
                  <p className="text-[9px] sm:text-[10px] text-purple-300 font-bold truncate">
                    Taktiksel Rol & Görev Seçimi ({roleSelectingPlayer.position === 'GK' ? 'Kaleci' : roleSelectingPlayer.position === 'DEF' ? 'Savunma' : roleSelectingPlayer.position === 'MID' ? 'Orta Saha' : 'Hücum'})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setRoleSelectingPlayer(null)}
                className="w-7 h-7 rounded-lg bg-[#231a44] text-slate-400 hover:text-white flex items-center justify-center cursor-pointer text-xs font-black shrink-0"
              >
                ✕
              </button>
            </div>

            {/* Role Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 sm:gap-2 flex-1 min-h-0 overflow-y-auto custom-scrollbar pr-0.5">
              {(() => {
                const pos = roleSelectingPlayer.position;
                const roleOptions =
                  pos === 'GK' ? [
                    { title: 'Libero Kaleci', duty: 'Destek', desc: 'Ceza sahası dışına açılarak süpürücü rolü oynar ve geriden pasla oyun kurar.', stars: calculateRoleStars('LKL', roleSelectingPlayer) },
                    { title: 'Geleneksel Kaleci', duty: 'Savunma', desc: 'Kale çizgisinde kalarak refleksleriyle şutları ve tehlikeleri savuşturur.', stars: calculateRoleStars('KL', roleSelectingPlayer) }
                  ] : pos === 'DEF' ? [
                    { title: 'Pasör Stoper', duty: 'Savunma', desc: 'Topla sakin kalır, geriden isabetli uzun ve kısa paslarla hücumu başlatır.', stars: calculateRoleStars('PS', roleSelectingPlayer) },
                    { title: 'Çakılı Stoper', duty: 'Savunma', desc: 'Pozisyonunu kesinlikle terk etmez, riske girmez ve tehlikeyi hemen uzaklaştırır.', stars: calculateRoleStars('ÇS', roleSelectingPlayer) },
                    { title: 'Hücumcu Bek', duty: 'Hücum', desc: 'Kanattan bindirmeler yapar, ceza sahasına orta açar ve defansa hızla döner.', stars: calculateRoleStars('HB', roleSelectingPlayer) },
                    { title: 'İçe Kat Eden Bek', duty: 'Destek', desc: 'İçe kat ederek orta sahada ek bir pas istasyonu ve sayısal üstünlük sağlar.', stars: calculateRoleStars('İKB', roleSelectingPlayer) }
                  ] : pos === 'MID' ? [
                    { title: 'İki Yönlü (Box-to-Box)', duty: 'Destek', desc: 'Her iki ceza sahası arasında dinamik mekik dokur, pres ve hücum desteği verir.', stars: calculateRoleStars('B2B', roleSelectingPlayer) },
                    { title: 'Ofansif Oyun Kurucu', duty: 'Hücum', desc: 'Rakip savunma arkasına kilit paslar atar ve gol pozisyonları yaratır.', stars: calculateRoleStars('OOK', roleSelectingPlayer) },
                    { title: 'Savaşçı Orta Saha (DMC)', duty: 'Savunma', desc: 'Yüksek enerjiyle rakip atakları keser, top kapar ve basit oynar.', stars: calculateRoleStars('DOS', roleSelectingPlayer) },
                    { title: 'Derin Oyun Kurucu', duty: 'Destek', desc: 'Savunma önünde konumlanarak oyunun yönünü tayin eder ve tempoyu belirler.', stars: calculateRoleStars('DOK', roleSelectingPlayer) },
                    { title: 'Kanat Forvet', duty: 'Hücum', desc: 'Çizgiden ceza sahasına hızla sızarak doğrudan skora ve bitiriciliğe odaklanır.', stars: calculateRoleStars('KF', roleSelectingPlayer) }
                  ] : [
                    { title: 'Fırsatçı Golcü', duty: 'Hücum', desc: 'Defans arkasına koşular yapar ve ceza sahası içinde öldürücü vuruşlar yapar.', stars: calculateRoleStars('FG', roleSelectingPlayer) },
                    { title: 'Kanat Forvet', duty: 'Hücum', desc: 'Kanattan içeri girip gol arar, hız ve bitiricilikle etkili olur.', stars: calculateRoleStars('TAK', roleSelectingPlayer) },
                    { title: 'Hedef Santrafor', duty: 'Hücum', desc: 'Hava toplarında hakimiyet kurar ve sırtı dönük top saklayarak takımı taşır.', stars: calculateRoleStars('HS', roleSelectingPlayer) },
                    { title: 'Komple Forvet', duty: 'Hücum', desc: 'Fizik, teknik ve pas kalitesiyle hem asist yapar hem gol atar.', stars: calculateRoleStars('KF', roleSelectingPlayer) }
                  ];

                const currentRole = playerRoles[roleSelectingPlayer.id] || roleOptions[0].title;

                return roleOptions.map((opt) => {
                  const isSelected = currentRole.includes(opt.title) || opt.title.includes(currentRole);
                  const starStr = '★'.repeat(opt.stars) + '☆'.repeat(5 - opt.stars);
                  return (
                    <div
                      key={opt.title}
                      onClick={() => {
                        const updated = {
                          ...playerRoles,
                          [roleSelectingPlayer.id]: opt.title
                        };
                        setPlayerRoles(updated);
                        syncAllTacticsToParent(playStyle, defenseStyle, attackStyle, instructions, specialistRoles, updated);
                        setRoleSelectingPlayer(null);
                      }}
                      className={`p-2 rounded-xl border flex flex-col justify-between gap-1 cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-purple-900/50 border-purple-400 text-white shadow-lg ring-1 ring-purple-400'
                          : 'bg-[#18132e] border-[#2d234f] hover:border-purple-400/60 hover:bg-[#20183e]'
                      }`}
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-black text-[11px] sm:text-xs text-white truncate">{opt.title}</span>
                          <span className="text-[9px] text-amber-400 font-bold shrink-0">{starStr}</span>
                        </div>
                        <span className="inline-block px-1.5 py-0.1 rounded bg-purple-950 border border-purple-500/40 text-purple-300 text-[7.5px] font-bold">
                          {opt.duty}
                        </span>
                        <p className="text-[8.5px] sm:text-[9px] text-slate-300 font-medium leading-tight line-clamp-2">{opt.desc}</p>
                      </div>

                      <div className="flex justify-end pt-1 border-t border-[#2d234f]/50">
                        {isSelected ? (
                          <span className="px-1.5 py-0.2 rounded bg-emerald-500 text-slate-950 font-black text-[8px] sm:text-[8.5px] uppercase shadow">
                            Seçili
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.2 rounded bg-[#251a44] text-purple-200 font-bold text-[8px] sm:text-[8.5px] border border-purple-500/30">
                            Rolü Ata ➔
                          </span>
                        )}
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          </div>
        </div>
      )}

      {/* SPECIALIST ROLES MODAL (CAPTAIN, PENALTY, FREEKICK, CORNER) - Responsive & Mobile friendly */}
      {specialistModalType && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
          <div className="bg-[#15102a] border border-purple-500/40 rounded-2xl p-3 sm:p-4 max-w-lg w-[95vw] sm:w-full max-h-[85vh] flex flex-col shadow-2xl gap-2">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-[#2d2150] pb-2 shrink-0">
              <div className="flex items-center gap-2 min-w-0 pr-2">
                <span className="text-lg sm:text-xl shrink-0">
                  {specialistModalType === 'captain' ? '👑' : specialistModalType === 'penalty' ? '⚽' : specialistModalType === 'freekick' ? '🎯' : '🚩'}
                </span>
                <div className="min-w-0">
                  <h3 className="font-black text-xs sm:text-sm text-white truncate">
                    {specialistModalType === 'captain' ? (t('TEAM_CAPTAIN') || 'Takım Kaptanı Seçimi') :
                     specialistModalType === 'penalty' ? (t('PENALTY_TAKER') || 'Penaltı Kullanıcısı Seçimi') :
                     specialistModalType === 'freekick' ? (t('FREEKICK_TAKER') || 'Serbest Vuruş Kullanıcısı Seçimi') : (t('CORNER_TAKER') || 'Korner Kullanıcısı Seçimi')}
                  </h3>
                  <p className="text-[9px] sm:text-[10px] text-slate-400 font-bold truncate">
                    {language === 'TR' ? 'Tüm takım kadrosundan görevli oyuncuyu belirleyin' :
                     language === 'ES' ? 'Elige al jugador especialista de toda la plantilla' :
                     language === 'DE' ? 'Wähle den Spezialisten aus dem gesamten Kader' :
                     language === 'FR' ? 'Choisissez le spécialiste dans tout l\'effectif' :
                     language === 'IT' ? 'Scegli lo specialista dall\'intera rosa' :
                     language === 'PT' ? 'Escolha o especialista de todo o elenco' :
                     'Select the specialist player from the entire squad'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSpecialistModalType(null)}
                className="w-7 h-7 rounded-lg bg-[#231a44] text-slate-400 hover:text-white flex items-center justify-center cursor-pointer text-xs font-black shrink-0"
              >
                ✕
              </button>
            </div>

            {/* Full Squad Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 sm:gap-2 max-h-[55vh] overflow-y-auto custom-scrollbar pr-0.5">
              {team.players.map((p) => {
                const isCurrentSpecialist =
                  (specialistModalType === 'captain' && specialistRoles.captainId === p.id) ||
                  (specialistModalType === 'penalty' && specialistRoles.penaltyTakerId === p.id) ||
                  (specialistModalType === 'freekick' && specialistRoles.freekickTakerId === p.id) ||
                  (specialistModalType === 'corner' && specialistRoles.cornerTakerId === p.id);

                const starterIdx = starters.findIndex(s => s.id === p.id);

                const highlightStat =
                  specialistModalType === 'penalty' ? `${t('SHOOTING_SHORT') || 'Şut'}: ${p.attributes?.shooting || p.overall}` :
                  specialistModalType === 'freekick' ? `${t('PASSING_SHORT') || 'Pas'}/${t('SHOOTING_SHORT') || 'Şut'}: ${Math.max(p.attributes?.shooting || 0, p.attributes?.passing || 0)}` :
                  specialistModalType === 'corner' ? `${t('PASSING_SHORT') || 'Pas'}: ${p.attributes?.passing || p.overall}` :
                  `OVR: ${p.overall}`;

                return (
                  <div
                    key={p.id}
                    onClick={() => {
                      const updated = {
                        ...specialistRoles,
                        ...(specialistModalType === 'captain' ? { captainId: p.id } : {}),
                        ...(specialistModalType === 'penalty' ? { penaltyTakerId: p.id } : {}),
                        ...(specialistModalType === 'freekick' ? { freekickTakerId: p.id } : {}),
                        ...(specialistModalType === 'corner' ? { cornerTakerId: p.id } : {})
                      };
                      setSpecialistRoles(updated);
                      syncAllTacticsToParent(playStyle, defenseStyle, attackStyle, instructions, updated);
                      setSpecialistModalType(null);
                    }}
                    className={`p-2 rounded-xl border flex items-center justify-between gap-1.5 cursor-pointer transition-all ${
                      isCurrentSpecialist
                        ? 'bg-purple-900/50 border-purple-400 text-white shadow-lg ring-1 ring-purple-400'
                        : 'bg-[#18132e] border-[#2d234f] hover:border-purple-400/60 hover:bg-[#20183e]'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      <div className="w-5 h-5 rounded-md bg-purple-600/30 border border-purple-500/40 text-purple-300 text-[9px] font-black flex items-center justify-center shrink-0">
                        {starterIdx !== -1 ? starterIdx + 1 : '•'}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="font-black text-[11px] sm:text-xs text-white block truncate">{p.name}</span>
                          {p.isStarting && (
                            <span className="text-[7.5px] px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold shrink-0">
                              {language === 'TR' ? '11' : 'XI'}
                            </span>
                          )}
                        </div>
                        <span className="text-[8.5px] sm:text-[9px] text-purple-300 font-bold">{highlightStat} • {p.position}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <span className="px-1.5 py-0.5 rounded bg-[#2a1d4a] border border-[#3e2b69] text-emerald-400 font-black text-[9px]">
                        {p.overall}
                      </span>
                      {isCurrentSpecialist && (
                        <span className="px-1.5 py-0.2 rounded bg-emerald-500 text-slate-950 font-black text-[8px] sm:text-[8.5px] uppercase">
                          ✓
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* BENCH & RESERVES MANUAL PLAYER SELECTION MODAL */}
      {/* BENCH / SQUAD SWAP MODAL */}
      {benchSwapModalPlayer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
          <div className="bg-[#15102a] border border-purple-500/40 rounded-2xl p-3 sm:p-4 max-w-lg w-[95vw] sm:w-full max-h-[88vh] sm:max-h-[80vh] flex flex-col shadow-2xl gap-2">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-[#2d2150] pb-2 shrink-0">
              <div className="min-w-0 pr-2">
                <h3 className="font-black text-xs sm:text-sm text-white flex items-center gap-1.5 truncate">
                  <Users className="w-4 h-4 text-purple-400 shrink-0" />
                  <span className="truncate">{t('SQUAD_SWAP_TITLE') || 'Kadro Oyuncu Seçimi & Değiştir'}</span>
                </h3>
                <p className="text-[9.5px] text-slate-400 font-bold mt-0.5 truncate">
                  {t('TARGET_PLAYER') || 'Hedef Oyuncu'}: <span className="text-amber-300 font-black">{benchSwapModalPlayer.name} ({benchSwapModalPlayer.position} • {benchSwapModalPlayer.overall} OVR)</span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setBenchSwapModalPlayer(null);
                  setSwapSearchQuery('');
                }}
                className="w-8 h-8 rounded-full bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white flex items-center justify-center cursor-pointer text-sm font-black shrink-0 border border-rose-500/40 transition-colors shadow-lg active:scale-95"
                title={t('CLOSE') || 'Kapat'}
              >
                ✕
              </button>
            </div>

            {/* Search & Position Filters */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-1.5 shrink-0">
              <input
                type="text"
                value={swapSearchQuery}
                onChange={(e) => setSwapSearchQuery(e.target.value)}
                placeholder={t('SEARCH_PLAYER_PLACEHOLDER') || 'Oyuncu ara...'}
                className="flex-1 bg-[#120f21] border border-[#2e2354] rounded-lg px-2.5 py-1 text-xs text-white placeholder-slate-500 font-bold outline-none focus:border-purple-400"
              />

              <div className="flex items-center justify-center gap-0.5 bg-[#1a1433] p-0.5 rounded-lg border border-[#2e2352] shrink-0 overflow-x-auto">
                {['ALL', 'GK', 'DEF', 'MID', 'FW'].map((pos) => (
                  <button
                    key={pos}
                    type="button"
                    onClick={() => setSwapPositionFilter(pos as 'ALL' | 'GK' | 'DEF' | 'MID' | 'FW')}
                    className={`text-[8.5px] font-black px-2 py-0.8 rounded cursor-pointer transition-all ${
                      swapPositionFilter === pos
                        ? 'bg-[#7b2cbf] text-white shadow'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {pos === 'ALL' ? (t('ALL') || 'TÜMÜ') : pos}
                  </button>
                ))}
              </div>
            </div>

            {/* Candidate Players List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 flex-1 min-h-0 max-h-[46vh] sm:max-h-[50vh] overflow-y-auto custom-scrollbar pr-1">
              {team.players
                .filter(p => p.id !== benchSwapModalPlayer.id)
                .filter(p => !isInMatchTactics || starters.some(s => s.id === p.id) || benchPlayers.some(b => b.id === p.id))
                .filter(p => swapPositionFilter === 'ALL' || p.position === swapPositionFilter)
                .filter(p => !swapSearchQuery || p.name.toLowerCase().includes(swapSearchQuery.toLowerCase()))
                .map((p) => {
                  const isStarter = starters.some(s => s.id === p.id);
                  const isBench = benchPlayers.some(b => b.id === p.id);

                  return (
                    <div
                      key={p.id}
                      onClick={() => {
                        onSwapPlayers(benchSwapModalPlayer, p);
                        setBenchSwapModalPlayer(null);
                        setSwapSearchQuery('');
                      }}
                      className="p-1.5 sm:p-2 rounded-xl bg-[#18132e] border border-[#2d234f] hover:border-purple-400 hover:bg-[#221945] flex items-center justify-between gap-1.5 cursor-pointer transition-all group"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="w-6 h-6 rounded-md bg-[#251b47] text-purple-300 font-black text-[9px] flex items-center justify-center shrink-0 border border-purple-500/30">
                          {p.position}
                        </span>
                        <div className="min-w-0">
                          <span className="font-extrabold text-[11px] text-white block truncate group-hover:text-purple-200">
                            {p.name}
                          </span>
                          <span className="text-[8.5px] text-slate-400 font-bold truncate block">
                            {isStarter ? (t('ON_PITCH') || 'Sahada (11)') : isBench ? (t('BENCH') || 'Yedek') : (t('RESERVE') || 'Rezerv')} • {p.age} {t('AGE') || 'Yaş'}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <span className="font-black text-amber-300 text-[10.5px] bg-amber-950/60 border border-amber-500/40 px-1.5 py-0.5 rounded">
                          {p.overall}
                        </span>
                        <span className="text-[8.5px] font-bold text-purple-300 bg-purple-900/40 border border-purple-400/40 px-1.5 py-0.5 rounded">
                          {t('SELECT') || 'Seç'} ⇄
                        </span>
                      </div>
                    </div>
                  );
                })}
            </div>

            {/* Footer / Cancel */}
            <div className="flex items-center justify-between gap-2 pt-1.5 border-t border-[#2d2150] shrink-0">
              <span className="text-[9.5px] text-slate-400 font-bold hidden sm:inline">Değiştirmek istediğiniz oyuncuya tıklayın</span>
              <button
                type="button"
                onClick={() => {
                  setBenchSwapModalPlayer(null);
                  setSwapSearchQuery('');
                }}
                className="w-full sm:w-auto px-4 py-1.5 rounded-xl bg-rose-900/40 hover:bg-rose-800/60 text-rose-200 font-black text-xs transition-all cursor-pointer border border-rose-500/40 shadow-sm"
              >
                ✕ {t('CLOSE') || 'Pencereyi Kapat / Vazgeç'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: PICK FROM RESERVES (TO PUT INTO BENCH) */}
      {reservePickerModalForBench && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
          <div className="bg-[#15102a] border border-purple-500/40 rounded-2xl p-3 sm:p-4 max-w-lg w-[95vw] sm:w-full max-h-[88vh] sm:max-h-[80vh] flex flex-col shadow-2xl gap-2">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-[#2d2150] pb-2 shrink-0">
              <div className="min-w-0 pr-2">
                <h3 className="font-black text-xs sm:text-sm text-white flex items-center gap-1.5 truncate">
                  <Users className="w-4 h-4 text-purple-400 shrink-0" />
                  <span className="truncate">Rezervlerden Oyuncu Seç & Yedeğe Al</span>
                </h3>
                <p className="text-[9.5px] text-slate-400 font-bold mt-0.5 truncate">
                  Kulübedeki Hedef: <span className="text-amber-300 font-black">{reservePickerModalForBench.name} ({reservePickerModalForBench.position} - {reservePickerModalForBench.overall} OVR)</span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setReservePickerModalForBench(null)}
                className="w-8 h-8 rounded-full bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white flex items-center justify-center cursor-pointer text-sm font-black shrink-0 border border-rose-500/40 transition-colors shadow-lg active:scale-95"
                title={t('CLOSE') || 'Kapat'}
              >
                ✕
              </button>
            </div>

            {/* Subtitle / Tip */}
            <div className="bg-[#1a1334] px-2.5 py-1 rounded-xl border border-[#2e2352] text-[9.5px] text-purple-200 font-medium shrink-0 flex items-center justify-between">
              <span>Rezervler listesinden seçtiğiniz oyuncu kulübeye alınacaktır.</span>
              <span className="font-black text-amber-300 text-xs">{reservePlayers.length} Rezerv</span>
            </div>

            {/* Reserves Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 flex-1 min-h-0 max-h-[46vh] sm:max-h-[50vh] overflow-y-auto custom-scrollbar pr-1">
              {reservePlayers.length === 0 ? (
                <div className="col-span-2 py-8 text-center text-slate-400 text-xs font-bold">
                  Rezerv kadroda oyuncu bulunmuyor.
                </div>
              ) : (
                reservePlayers.map((p) => {
                  return (
                    <div
                      key={p.id}
                      onClick={() => {
                        onSwapPlayers(reservePickerModalForBench, p);
                        setReservePickerModalForBench(null);
                      }}
                      className="p-1.5 sm:p-2 rounded-xl bg-[#18132e] border border-[#2d234f] hover:border-emerald-400 hover:bg-[#1a203b] flex items-center justify-between gap-1.5 cursor-pointer transition-all group shadow"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="w-6 h-6 rounded-md bg-[#251b47] text-purple-300 font-black text-[9px] flex items-center justify-center shrink-0 border border-purple-500/30">
                          {p.position}
                        </span>
                        <div className="min-w-0">
                          <span className="font-extrabold text-[11px] text-white block truncate group-hover:text-emerald-300">
                            {p.name}
                          </span>
                          <span className="text-[8.5px] text-slate-400 font-bold block truncate">
                            HIZ: {p.attributes?.pace || p.overall} • PAS: {p.attributes?.passing || p.overall} • ŞUT: {p.attributes?.shooting || p.overall}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <span className="font-black text-amber-300 text-[10.5px] bg-amber-950/60 border border-amber-500/40 px-1.5 py-0.5 rounded">
                          {p.overall}
                        </span>
                        <span className="text-[8.5px] font-black text-slate-950 bg-emerald-400 hover:bg-emerald-300 px-1.5 py-0.5 rounded shadow">
                          Yedeğe Al ➔
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Footer / Cancel */}
            <div className="flex items-center justify-end gap-2 pt-1.5 border-t border-[#2d2150] shrink-0">
              <button
                type="button"
                onClick={() => setReservePickerModalForBench(null)}
                className="w-full sm:w-auto px-4 py-1.5 rounded-xl bg-rose-900/40 hover:bg-rose-800/60 text-rose-200 font-black text-xs transition-all cursor-pointer border border-rose-500/40 shadow-sm"
              >
                ✕ {t('CLOSE') || 'Pencereyi Kapat / Vazgeç'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: PICK FROM BENCH (TO SWAP WITH RESERVE) */}
      {benchPickerModalForReserve && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
          <div className="bg-[#15102a] border border-purple-500/40 rounded-2xl p-3 sm:p-4 max-w-lg w-[95vw] sm:w-full max-h-[88vh] sm:max-h-[80vh] flex flex-col shadow-2xl gap-2">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-[#2d2150] pb-2 shrink-0">
              <div className="min-w-0 pr-2">
                <h3 className="font-black text-xs sm:text-sm text-white flex items-center gap-1.5 truncate">
                  <Users className="w-4 h-4 text-purple-400 shrink-0" />
                  <span className="truncate">Kulübeden Değiştirilecek Oyuncuyu Seç</span>
                </h3>
                <p className="text-[9.5px] text-slate-400 font-bold mt-0.5 truncate">
                  Kulübeye Geçecek Rezerv: <span className="text-emerald-300 font-black">{benchPickerModalForReserve.name} ({benchPickerModalForReserve.position} - {benchPickerModalForReserve.overall} OVR)</span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setBenchPickerModalForReserve(null)}
                className="w-8 h-8 rounded-full bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white flex items-center justify-center cursor-pointer text-sm font-black shrink-0 border border-rose-500/40 transition-colors shadow-lg active:scale-95"
                title={t('CLOSE') || 'Kapat'}
              >
                ✕
              </button>
            </div>

            {/* Subtitle / Tip */}
            <div className="bg-[#1a1334] px-2.5 py-1 rounded-xl border border-[#2e2352] text-[9.5px] text-purple-200 font-medium shrink-0 flex items-center justify-between">
              <span>Seçeceğiniz yedek oyuncu rezervlere aktarılacak ve yerine bu oyuncu kulübeye girecektir.</span>
              <span className="font-black text-purple-300 text-xs">{benchPlayers.length} Yedek</span>
            </div>

            {/* Bench Players Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 flex-1 min-h-0 max-h-[46vh] sm:max-h-[50vh] overflow-y-auto custom-scrollbar pr-1">
              {benchPlayers.length === 0 ? (
                <div className="col-span-2 py-8 text-center text-slate-400 text-xs font-bold">
                  Yedek kulübesinde oyuncu bulunmuyor.
                </div>
              ) : (
                benchPlayers.map((p) => {
                  return (
                    <div
                      key={p.id}
                      onClick={() => {
                        onSwapPlayers(benchPickerModalForReserve, p);
                        setBenchPickerModalForReserve(null);
                      }}
                      className="p-1.5 sm:p-2 rounded-xl bg-[#18132e] border border-[#2d234f] hover:border-amber-400 hover:bg-[#20183e] flex items-center justify-between gap-1.5 cursor-pointer transition-all group shadow"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="w-6 h-6 rounded-md bg-[#251b47] text-purple-300 font-black text-[9px] flex items-center justify-center shrink-0 border border-purple-500/30">
                          {p.position}
                        </span>
                        <div className="min-w-0">
                          <span className="font-extrabold text-[11px] text-white block truncate group-hover:text-amber-300">
                            {p.name}
                          </span>
                          <span className="text-[8.5px] text-slate-400 font-bold block truncate">
                            HIZ: {p.attributes?.pace || p.overall} • PAS: {p.attributes?.passing || p.overall} • DEF: {p.attributes?.defending || p.overall}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <span className="font-black text-amber-300 text-[10.5px] bg-amber-950/60 border border-amber-500/40 px-1.5 py-0.5 rounded">
                          {p.overall}
                        </span>
                        <span className="text-[8.5px] font-black text-purple-200 bg-purple-900/60 hover:bg-purple-700 border border-purple-400/40 px-1.5 py-0.5 rounded shadow">
                          Değiştir ⇄
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Footer / Cancel */}
            <div className="flex items-center justify-end gap-2 pt-1.5 border-t border-[#2d2150] shrink-0">
              <button
                type="button"
                onClick={() => setBenchPickerModalForReserve(null)}
                className="w-full sm:w-auto px-4 py-1.5 rounded-xl bg-rose-900/40 hover:bg-rose-800/60 text-rose-200 font-black text-xs transition-all cursor-pointer border border-rose-500/40 shadow-sm"
              >
                ✕ {t('CLOSE') || 'Pencereyi Kapat / Vazgeç'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
