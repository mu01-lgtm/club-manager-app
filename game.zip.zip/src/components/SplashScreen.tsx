import React, { useEffect, useState } from 'react';
import { Sparkles, Play, Shield, Zap } from 'lucide-react';

interface SplashScreenProps {
  onFinishLoading: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinishLoading }) => {
  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState('CM 27 Futbol Motoru Başlatılıyor...');
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const texts = [
      'CM 27 Futbol Motoru Başlatılıyor...',
      'Dünya Kulüpleri ve Lig Veritabanı Yükleniyor...',
      'Taktik ve Yapay Zeka Simülatörü Hazırlanıyor...',
      'Kariyer Moduna Giriş Yapılıyor...'
    ];

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setFadeOut(true);
          setTimeout(() => {
            onFinishLoading();
          }, 500);
          return 100;
        }

        const next = prev + Math.floor(Math.random() * 12) + 6;
        if (next > 25 && next <= 50) setLoadingText(texts[1]);
        else if (next > 50 && next <= 75) setLoadingText(texts[2]);
        else if (next > 75) setLoadingText(texts[3]);

        return Math.min(next, 100);
      });
    }, 55);

    return () => clearInterval(interval);
  }, [onFinishLoading]);

  const handleSkip = () => {
    setFadeOut(true);
    setTimeout(() => {
      onFinishLoading();
    }, 300);
  };

  return (
    <div
      onClick={handleSkip}
      className={`fixed inset-0 z-[9999] bg-[#05030a] text-white flex flex-col items-center justify-between p-4 sm:p-8 select-none w-screen h-screen overflow-hidden transition-opacity duration-500 cursor-pointer ${
        fadeOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background Official Artwork Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-45 filter brightness-95 saturate-125 scale-105 transition-transform duration-1000"
        style={{
          backgroundImage: `url('/cm27-logo.png')`
        }}
      />

      {/* Atmospheric Vignette & Deep Stadium Gradient Overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#05030a] via-[#090517]/75 to-[#05030a]/90 pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_20%,_#05030a_92%)] pointer-events-none" />

      {/* High-tech Stadium Floodlight & Pitch Grid Accent */}
      <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#a855f7_1px,transparent_1px),linear-gradient(to_bottom,#a855f7_1px,transparent_1px)] bg-[size:36px_36px] pointer-events-none" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-48 bg-purple-600/20 blur-[100px] pointer-events-none" />

      {/* Top Branding Pill */}
      <div className="relative z-10 pt-3 flex items-center gap-2.5 bg-[#140b2a]/85 border border-purple-500/40 px-4 py-1.5 rounded-full backdrop-blur-md shadow-[0_0_20px_rgba(168,85,247,0.3)]">
        <Sparkles className="w-4 h-4 text-purple-300 animate-spin" />
        <span className="text-[11px] sm:text-xs font-black tracking-widest text-purple-100 uppercase">
          OFFICIAL CM 27 FOOTBALL SIMULATOR
        </span>
      </div>

      {/* Center Main Logo Showcase */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-xl w-full my-auto px-4">
        
        {/* CM Big Modern Emblem */}
        <div className="relative mb-5 flex flex-col items-center">
          
          {/* Logo Card with Neon Glow */}
          <div className="relative flex items-center justify-center p-3 sm:p-4 rounded-3xl bg-gradient-to-b from-[#1a0f35]/90 via-[#0e071e]/95 to-[#06030c] border border-purple-500/50 shadow-[0_0_50px_rgba(168,85,247,0.45)] backdrop-blur-xl">
            
            {/* CM Official Logo Graphic Preview */}
            <div className="relative flex flex-col items-center">
              
              {/* CM Monogram */}
              <div className="flex items-baseline font-black italic tracking-tighter leading-none select-none drop-shadow-[0_10px_25px_rgba(0,0,0,0.9)]">
                <span className="text-6xl sm:text-8xl text-white font-black tracking-tighter pr-1">C</span>
                <span className="text-6xl sm:text-8xl text-purple-500 font-black tracking-tighter drop-shadow-[0_0_35px_rgba(168,85,247,0.85)]">M</span>
              </div>

              {/* CLUB MANAGER Title */}
              <div className="w-full mt-1.5 flex flex-col items-center">
                <span className="text-sm sm:text-lg font-black tracking-[0.25em] text-white uppercase drop-shadow-md whitespace-nowrap">
                  CLUB MANAGER
                </span>
                
                {/* Purple Divider Line */}
                <div className="w-full h-[2.5px] bg-gradient-to-r from-transparent via-purple-500 to-transparent mt-1 mb-2 shadow-[0_0_10px_rgba(168,85,247,0.9)]" />

                {/* 27 + BUILD. MANAGE. WIN. */}
                <div className="w-full flex items-center justify-between gap-3 sm:gap-6 px-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-2xl sm:text-3xl font-black text-white italic tracking-tighter">
                      27
                    </span>
                  </div>

                  <div className="h-4 w-[1px] bg-purple-500/40" />

                  <div className="text-right">
                    <span className="block text-[8.5px] sm:text-[10px] font-black text-purple-300 tracking-widest uppercase leading-tight">
                      BUILD. MANAGE. WIN.
                    </span>
                  </div>
                </div>

              </div>

            </div>

          </div>

          {/* Glowing Pill Tag */}
          <div className="absolute -bottom-2.5 bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 text-white font-black text-[9px] sm:text-[10px] px-3 py-0.5 rounded-full border border-purple-300/60 uppercase shadow-lg shadow-purple-950/80 tracking-widest flex items-center gap-1">
            <Zap className="w-3 h-3 text-amber-300 fill-amber-300" />
            <span>GLOBAL FOOTBALL SIMULATION</span>
          </div>

        </div>

        {/* Loading Progress Section */}
        <div className="w-full space-y-2.5 max-w-md bg-[#0d071d]/90 p-4 rounded-2xl border border-purple-500/30 backdrop-blur-md shadow-2xl mt-3">
          <div className="flex items-center justify-between text-xs font-bold text-slate-200 px-1">
            <span className="flex items-center gap-2 truncate">
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping shrink-0" />
              <span className="truncate text-purple-200">{loadingText}</span>
            </span>
            <span className="font-mono text-purple-300 font-black text-sm shrink-0">%{progress}</span>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-3 bg-[#06030c] border border-purple-900/60 rounded-full overflow-hidden p-0.5 shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-purple-600 via-purple-400 to-indigo-400 rounded-full transition-all duration-150 ease-out shadow-[0_0_15px_rgba(168,85,247,0.9)]"
              style={{ width: `${progress}%` }}
            />
          </div>

          <p className="text-[10px] text-purple-300/80 font-semibold pt-1 flex items-center justify-center gap-1.5">
            <Play className="w-3 h-3 text-purple-400 fill-purple-400" />
            <span>Devam etmek için ekrana dokunun veya bekleyin</span>
          </p>
        </div>

      </div>

      {/* Footer copyright */}
      <div className="relative z-10 pb-2 text-[10px] text-purple-300/60 font-medium">
        © 2026-2027 CM Club Manager. Build. Manage. Win. Tüm Hakları Saklıdır.
      </div>
    </div>
  );
};


