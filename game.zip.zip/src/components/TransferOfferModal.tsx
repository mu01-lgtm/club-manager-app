import React, { useState } from 'react';
import { Player, Team } from '../types';
import { CustomSelect } from './CustomSelect';
import {
  X,
  DollarSign,
  RefreshCw,
  Shield,
  Check,
  AlertCircle,
  Percent,
  Award,
  Sparkles,
  ChevronRight,
  Flame,
  Zap,
  Handshake,
  FileText,
  TrendingUp,
  AlertTriangle,
  Building2,
  TrendingDown,
  CreditCard,
  Crown,
  Send,
  Mail
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useTranslation } from '../utils/i18n';

interface TransferOfferModalProps {
  isOpen: boolean;
  onClose: () => void;
  player: Player;
  sellerTeam?: Team;
  userTeam: Team;
  initialOfferType?: 'BUY' | 'LOAN';
  initialStage?: 'CLUB_DEAL' | 'PLAYER_CONTRACT';
  currentWeek?: number;
  onTransferSuccess: (player: Player, dealType: 'BUY' | 'LOAN', fee: number, updatedPlayerProps?: Partial<Player>, isPendingArrival?: boolean) => void;
  onSendBuyOffer?: (player: Player, sellerTeam: Team | undefined, offerFee: number, effectiveFee: number, buyProb: number) => void;
  onAddAirportCelebrationInbox?: (player: Player) => void;
  showToast?: (type: 'success' | 'error' | 'info', title: string, message: string) => void;
}

const RIVAL_CLUBS = [
  'Real Madrid',
  'Bayern Münih',
  'Paris Saint-Germain',
  'Manchester City',
  'Arsenal',
  'Al-Hilal',
  'Juventus',
  'Barcelona'
];

export const TransferOfferModal: React.FC<TransferOfferModalProps> = ({
  isOpen,
  onClose,
  player,
  sellerTeam,
  userTeam,
  initialOfferType = 'BUY',
  initialStage = 'CLUB_DEAL',
  currentWeek = 1,
  onTransferSuccess,
  onSendBuyOffer,
  onAddAirportCelebrationInbox,
  showToast
}) => {
  const { t, language } = useTranslation();

  const getLocalized = (
    tr: string,
    en: string,
    es?: string,
    fr?: string,
    it?: string,
    de?: string,
    pt?: string
  ) => {
    if (language === 'TR') return tr;
    if (language === 'EN') return en;
    if (language === 'ES') return es || en;
    if (language === 'FR') return fr || en;
    if (language === 'IT') return it || en;
    if (language === 'DE') return de || en;
    if (language === 'PT') return pt || en;
    return tr;
  };

  const getLocalizedText = (tr: string, en: string, es: string, fr: string, it: string, de: string, pt: string) => {
    const lang = (language || 'TR').toUpperCase();
    if (lang === 'EN') return en;
    if (lang === 'ES') return es;
    if (lang === 'FR') return fr;
    if (lang === 'IT') return it;
    if (lang === 'DE') return de;
    if (lang === 'PT') return pt;
    return tr;
  };

  if (!isOpen || !player) return null;


  const [offerType, setOfferType] = useState<'BUY' | 'LOAN'>(initialOfferType);
  const [stage, setStage] = useState<'CLUB_DEAL' | 'HIJACK_WAR' | 'PLAYER_CONTRACT' | 'COMPLETED' | 'REJECTED' | 'OFFER_SUBMITTED'>(initialStage);

  // Reset offerType and stage when initial values change
  React.useEffect(() => {
    setOfferType(initialOfferType || 'BUY');
    setStage(initialStage || 'CLUB_DEAL');
  }, [initialOfferType, initialStage, player?.id]);

  // Buy Offer State
  const baseValue = player.marketValue || 5000000;
  
  // For older players (30+), initial fee recommendation is lower than market value
  const isVeteran = player.age >= 30;
  const isOldVeteran = player.age >= 34;
  const initialOffer = isOldVeteran 
    ? Math.round(baseValue * 0.5) 
    : isVeteran 
    ? Math.round(baseValue * 0.75) 
    : baseValue;

  const [offerFee, setOfferFee] = useState<number>(initialOffer);
  const [sellClause, setSellClause] = useState<number>(10); // %
  const [championshipBonus, setChampionshipBonus] = useState<number>(0);
  const [uclBonus, setUclBonus] = useState<number>(0);
  const [goalMilestoneBonus, setGoalMilestoneBonus] = useState<number>(0);
  const [hasBuyBackClause, setHasBuyBackClause] = useState<boolean>(false);
  const [buyBackFee, setBuyBackFee] = useState<number>(Math.round(baseValue * 1.5));
  const [paymentMode, setPaymentMode] = useState<'CASH' | 'INSTALLMENTS'>('CASH');
  const [installmentCount, setInstallmentCount] = useState<number>(2); // 2, 3, 4, 5 Yıl

  // Hijack War State (Rakip Kulüpten Transfer Çalımı)
  const [rivalClubName, setRivalClubName] = useState<string>('');
  const [rivalFee, setRivalFee] = useState<number>(0);

  // Player Contract State
  const defaultWage = player.wage || Math.min(45000, Math.max(3000, Math.round((player.marketValue || 3000000) * 0.0012 + (player.overall - 65) * 200)));
  const [proposedWage, setProposedWage] = useState<number>(defaultWage);
  const [contractYears, setContractYears] = useState<number>(3);
  const [hasRelegationClause, setHasRelegationClause] = useState<boolean>(
    player.hasRelegationClause || (player.age <= 22 || player.overall >= 78)
  );
  const [releaseClause, setReleaseClause] = useState<number>(Math.round(baseValue * 2.5));

  // Loan Offer State
  const [loanDuration, setLoanDuration] = useState<'1_SEASON' | '6_MONTHS'>('1_SEASON');
  const [wageSharePercent, setWageSharePercent] = useState<number>(100);
  const [monthlyLoanFee, setMonthlyLoanFee] = useState<number>(250000);
  const [roleGuarantee, setRoleGuarantee] = useState<'STARTER' | 'ROTATION'>('STARTER');

  // Messages
  const [resultMessage, setResultMessage] = useState<string | null>(null);

  // Evaluation Metrics
  const isSuperStar = player.overall >= 85;
  const isStarPlayer = player.overall >= 78;

  // Check if User Team is a "Big European Giant" (Removed Fenerbahçe, Galatasaray, and all Süper Lig clubs)
  const euroBigClubKeywords = [
    'real madrid', 'barcelona', 'manchester city', 'manchester united', 'liverpool', 'arsenal',
    'bayern', 'paris', 'psg', 'inter', 'juventus', 'milan'
  ];
  const userTeamNameLower = userTeam.name.toLowerCase();
  const isEuroGiant = euroBigClubKeywords.some(k => userTeamNameLower.includes(k));

  // Team Success / Championship history check
  const teamTrophies = (userTeam as any).trophies || [];
  const teamChampionships = (userTeam as any).championships || 0;
  const seasonsPlayed = (userTeam as any).seasonsPlayed || 1;
  const hasWonTitles = teamTrophies.length > 0 || teamChampionships > 0 || seasonsPlayed >= 2;

  // Installment Team Policy Determination (Based on seller team name or ID)
  const teamSeed = (sellerTeam ? sellerTeam.name.length : 7) + (player.id ? player.id.length : 3);
  // Policy 0: NO_INSTALLMENTS (25%), Policy 1: EXTRA_CHARGE (50%), Policy 2: DIRECT_ACCEPT (25%)
  const installmentPolicyType = teamSeed % 4 === 0 ? 'NO_INSTALLMENTS' : teamSeed % 4 === 1 ? 'DIRECT_ACCEPT' : 'EXTRA_CHARGE';
  const installmentMarkupPercent = 20; // 20% extra fee required for installments

  // Effective fee considering installment markup
  const effectiveFee = (paymentMode === 'INSTALLMENTS' && installmentPolicyType === 'EXTRA_CHARGE')
    ? Math.round(offerFee * (1 + installmentMarkupPercent / 100))
    : offerFee;

  // Calculate Acceptance Probability
  const calculateBuyProbability = () => {
    if (paymentMode === 'INSTALLMENTS' && installmentPolicyType === 'NO_INSTALLMENTS') {
      return 0; // Seller refuses installments completely
    }

    const feeRatio = effectiveFee / Math.max(1, baseValue);
    let prob = 0;

    // Smooth baseline probability based on fee ratio and player profile
    if (isOldVeteran) {
      if (feeRatio >= 1.0) prob = 98;
      else if (feeRatio >= 0.75) prob = 85;
      else if (feeRatio >= 0.5) prob = 65;
      else if (feeRatio >= 0.35) prob = 40;
      else prob = 15;
    } else if (isVeteran) {
      if (feeRatio >= 1.2) prob = 98;
      else if (feeRatio >= 1.0) prob = 88;
      else if (feeRatio >= 0.8) prob = 70;
      else if (feeRatio >= 0.6) prob = 45;
      else if (feeRatio >= 0.4) prob = 20;
      else prob = 5;
    } else if (isSuperStar) {
      if (feeRatio >= 1.8) prob = 95;
      else if (feeRatio >= 1.5) prob = 82;
      else if (feeRatio >= 1.25) prob = 60;
      else if (feeRatio >= 1.0) prob = 35;
      else if (feeRatio >= 0.8) prob = 10;
      else prob = 2;
    } else if (isStarPlayer) {
      if (feeRatio >= 1.5) prob = 96;
      else if (feeRatio >= 1.25) prob = 84;
      else if (feeRatio >= 1.0) prob = 65;
      else if (feeRatio >= 0.8) prob = 35;
      else prob = 10;
    } else {
      if (feeRatio >= 1.3) prob = 98;
      else if (feeRatio >= 1.1) prob = 85;
      else if (feeRatio >= 0.95) prob = 65;
      else if (feeRatio >= 0.75) prob = 35;
      else prob = 10;
    }

    // Bonuses and clauses bonuses
    if (sellClause > 0) prob += Math.round(sellClause * 0.5);
    if (championshipBonus > 0) prob += 5;
    if (uclBonus > 0) prob += 8;
    if (goalMilestoneBonus > 0) prob += 4;
    if (hasBuyBackClause) prob += 12;
    if (paymentMode === 'CASH') prob += 6;

    return Math.min(98, Math.max(2, Math.round(prob)));
  };

  const calculateLoanProbability = () => {
    // High OVR / Star players rarely loan
    if (player.overall >= 78) return 5;
    if (player.isStarting) return 8;

    let prob = 20;
    prob += (wageSharePercent / 100) * 35;
    if (monthlyLoanFee >= 400000) prob += 25;
    else if (monthlyLoanFee >= 200000) prob += 15;
    if (roleGuarantee === 'STARTER') prob += 10;
    if (player.age >= 30) prob += 20; // older veterans easier to loan
    if ((player.form || 7.5) < 6.0) prob += 20; // out-of-form players easier to loan

    return Math.min(88, Math.max(2, Math.round(prob)));
  };

  const buyProb = calculateBuyProbability();
  const loanProb = calculateLoanProbability();

  // Submit initial offer to club
  const handleSendClubOffer = () => {
    const clubName = sellerTeam ? sellerTeam.name : (language === 'EN' ? 'Club' : 'Kulüp');

    if (offerType === 'BUY') {
      if (paymentMode === 'INSTALLMENTS' && installmentPolicyType === 'NO_INSTALLMENTS') {
        const msg = getLocalizedText(
          `TAKSİT REDDEDİLDİ! ⛔ ${clubName} yönetimi: "Kulübümüz taksitli satış yapmamaktadır. Sadece peşin ödemeleri kabul ediyoruz."`,
          `INSTALLMENTS REJECTED! ⛔ ${clubName} board: "Our club does not accept installment deals. Only upfront payments are accepted."`,
          `¡PLAZOS RECHAZADOS! ⛔ Directiva de ${clubName}: "No aceptamos ventas a plazos. Solo pago al contado."`,
          `PAIEMENT ÉCHELONNÉ REFUSÉ ! ⛔ Direction de ${clubName} : "Notre club refuse les paiements échelonnés. Paiement comptant exigé."`,
          `RATE RESPINTE! ⛔ Dirigenza ${clubName}: "Non accettiamo vendite a rate. Solo pagamento in un'unica soluzione."`,
          `RATENKAUF ABGELEHNT! ⛔ ${clubName}-Vorstand: "Unser Verein akzeptiert keine Ratenzahlungen. Nur Barzahlung."`,
          `PARCELAS RECUSADAS! ⛔ Diretoria do ${clubName}: "Nosso clube não aceita vendas parceladas. Apenas pagamento à vista."`
        );
        setStage('REJECTED');
        setResultMessage(msg);
        if (showToast) showToast('error', getLocalizedText('Taksit Kabul Edilmiyor', 'Installments Not Accepted', 'Plazos no aceptados', 'Échelonnement refusé', 'Rate non accettate', 'Raten nicht akzeptiert', 'Parcelamento não aceite'), msg);
        return;
      }

      if (userTeam.budget <= 0 || userTeam.budget < effectiveFee) {
        const msg = getLocalizedText(
          `Bütçe yetersiz! Bütçeniz €${(userTeam.budget / 1_000_000).toFixed(1)}M, gerekli tutar €${(effectiveFee / 1_000_000).toFixed(1)}M. Kasanız eksi veya yetersiz iken transfer yapamazsınız.`,
          `Insufficient budget! Your budget is €${(userTeam.budget / 1_000_000).toFixed(1)}M, required fee is €${(effectiveFee / 1_000_000).toFixed(1)}M.`,
          `¡Presupuesto insuficiente! Tu presupuesto es de €${(userTeam.budget / 1_000_000).toFixed(1)}M, importe requerido €${(effectiveFee / 1_000_000).toFixed(1)}M.`,
          `Budget insuffisant ! Votre budget est de €${(userTeam.budget / 1_000_000).toFixed(1)}M, montant requis €${(effectiveFee / 1_000_000).toFixed(1)}M.`,
          `Budget insufficiente! Il tuo budget è €${(userTeam.budget / 1_000_000).toFixed(1)}M, importo richiesto €${(effectiveFee / 1_000_000).toFixed(1)}M.`,
          `Unzureichendes Budget! Ihr Budget beträgt €${(userTeam.budget / 1_000_000).toFixed(1)}M, erforderlich sind €${(effectiveFee / 1_000_000).toFixed(1)}M.`,
          `Orçamento insuficiente! Seu saldo é de €${(userTeam.budget / 1_000_000).toFixed(1)}M, valor necessário €${(effectiveFee / 1_000_000).toFixed(1)}M.`
        );
        setStage('REJECTED');
        setResultMessage(msg);
        if (showToast) showToast('error', getLocalizedText('Bütçe Yetersiz ❌', 'Insufficient Budget ❌', 'Presupuesto Insuficiente ❌', 'Budget Insuffisant ❌', 'Budget Insufficiente ❌', 'Budget unzureichend ❌', 'Orçamento Insuficiente ❌'), msg);
        return;
      }

      // Protection rules (Do NOT apply price inflation to 30+ year old players!)
      const isYoungProspect = player.age <= 21 && player.overall >= 72;
      const isKeyStarter = player.isStarting && player.overall >= 78 && player.age < 30;

      if (isYoungProspect && offerFee < baseValue * 1.6) {
        setStage('REJECTED');
        const reqFee = Math.round(baseValue * 2.1);
        const rejectMsg = getLocalizedText(
          `SATILMIYOR! ❌ ${clubName} yönetimi: "${player.name} (${player.age} yaş) kulübümüzün kilit genç yeteneğidir. En az €${(reqFee / 1_000_000).toFixed(1)}M vermeden satamayız."`,
          `NOT FOR SALE! ❌ ${clubName} board: "${player.name} (${player.age} yo) is our key young prospect. We won't sell for less than €${(reqFee / 1_000_000).toFixed(1)}M."`,
          `¡NO SE VENDE! ❌ Directiva de ${clubName}: "${player.name} (${player.age} años) es una joven promesa clave. No lo venderemos por menos de €${(reqFee / 1_000_000).toFixed(1)}M."`,
          `INTRANSFÉRABLE ! ❌ Direction de ${clubName} : "${player.name} (${player.age} ans) est notre jeune espoir clé. Nous n'accepterons pas moins de €${(reqFee / 1_000_000).toFixed(1)}M."`,
          `INTRASFERIBILE! ❌ Dirigenza ${clubName}: "${player.name} (${player.age} anni) è un nostro giovane talento chiave. Non lo cederemo per meno di €${(reqFee / 1_000_000).toFixed(1)}M."`,
          `UNVERKÄUFLICH! ❌ ${clubName}-Vorstand: "${player.name} (${player.age} J.) ist unser Top-Talent. Unter €${(reqFee / 1_000_000).toFixed(1)}M verkaufen wir nicht."`,
          `NÃO ESTÁ À VENDA! ❌ Diretoria do ${clubName}: "${player.name} (${player.age} anos) é uma jovem promessa fundamental. Não vendemos por menos de €${(reqFee / 1_000_000).toFixed(1)}M."`
        );
        setResultMessage(rejectMsg);
        if (showToast) showToast('error', getLocalizedText('Genç Yetenek Satılmıyor', 'Prospect Not For Sale', 'Joven talento no se vende', 'Jeune talent intransférable', 'Giovane talento intrasferibile', 'Junges Talent unverkäuflich', 'Jovem talento não está à venda'), rejectMsg);
        return;
      }

      if (isKeyStarter && offerFee < baseValue * 1.25) {
        setStage('REJECTED');
        const reqFee = Math.round(baseValue * 1.5);
        const rejectMsg = getLocalizedText(
          `İLK 11 OYUNCUSU! ❌ ${clubName}, kadrosunun as oyuncusu ${player.name}'i bu fiyata bırakmıyor. En az €${(reqFee / 1_000_000).toFixed(1)}M talep ediliyor.`,
          `KEY STARTER! ❌ ${clubName} refuses to let key starter ${player.name} go at this price. At least €${(reqFee / 1_000_000).toFixed(1)}M demanded.`,
          `¡TITULAR CLAVE! ❌ ${clubName} no dejará salir a ${player.name} por este precio. Piden al menos €${(reqFee / 1_000_000).toFixed(1)}M.`,
          `TITULAIRE CLÉ ! ❌ ${clubName} refuse de céder ${player.name} à ce prix. Au moins €${(reqFee / 1_000_000).toFixed(1)}M exigés.`,
          `TITOLARE INAMOVIBILE! ❌ Il ${clubName} non lascerà partire ${player.name} per questa cifra. Richiesti almeno €${(reqFee / 1_000_000).toFixed(1)}M.`,
          `STAMM-SPIELER! ❌ ${clubName} lässt Leistungsträger ${player.name} zu diesem Preis nicht ziehen. Mindestens €${(reqFee / 1_000_000).toFixed(1)}M gefordert.`,
          `TITULAR ABSOLUTO! ❌ O ${clubName} não deixará ${player.name} sair por este valor. Exigem pelo menos €${(reqFee / 1_000_000).toFixed(1)}M.`
        );
        setResultMessage(rejectMsg);
        if (showToast) showToast('error', getLocalizedText('İlk 11 Oyuncusu', 'Key Starter', 'Titular Clave', 'Titulaire Clé', 'Titolare Chiave', 'Stammspieler', 'Titular Absoluto'), rejectMsg);
        return;
      }

      const isSuccess = Math.random() * 100 <= buyProb;

      if (isSuccess) {
        // Submit buy offer for 1-day club decision in Inbox
        if (onSendBuyOffer) {
          onSendBuyOffer(player, sellerTeam, offerFee, effectiveFee, buyProb);
        }
        setStage('OFFER_SUBMITTED');
        const submittedMsg = getLocalizedText(
          `TEKLİF KULÜBE ULAŞTIRILDI! 📩 ${clubName} yönetimi teklifinizi değerlendirmeye aldı. Karar 1 gün sonra Gelen Kutusu'na gelecektir.`,
          `OFFER SUBMITTED TO CLUB! 📩 ${clubName} board is reviewing your bid. Decision will arrive in Inbox in 1 day.`,
          `¡OFERTA ENVIADA AL CLUB! 📩 La directiva de ${clubName} está evaluando la oferta. La respuesta llegará al Buzón en 1 día.`,
          `OFFRE TRANSMISE AU CLUB ! 📩 La direction de ${clubName} examine votre offre. La réponse arrivera dans 1 jour dans la boîte de réception.`,
          `OFFERTA INVIATA AL CLUB! 📩 La dirigenza del ${clubName} sta valutando la proposta. La risposta arriverà tra 1 giorno nella Posta in Arrivo.`,
          `ANGEBOT EINGEREICHT! 📩 Der Vorstand von ${clubName} prüft Ihr Angebot. Die Entscheidung trifft in 1 Tag im Posteingang ein.`,
          `PROPOSTA ENVIADA AO CLUBE! 📩 A diretoria do ${clubName} está analisando sua oferta. A decisão chegará na Caixa de Entrada em 1 dia.`
        );
        setResultMessage(submittedMsg);
        if (showToast) showToast('info', getLocalizedText('Bonservis Teklifi Gönderildi 📩', 'Transfer Bid Submitted 📩', 'Oferta de traspaso enviada 📩', 'Offre de transfert envoyée 📩', 'Offerta inviata 📩', 'Angebot eingereicht 📩', 'Proposta enviada 📩'), getLocalizedText('Kulübün kararı 1 gün sonra Gelen Kutusu\'na ulaşacaktır.', 'Club decision will arrive in Inbox in 1 day.', 'La decisión del club llegará al buzón en 1 día.', 'La réponse arrivera dans 1 jour.', 'La risposta arriverà tra 1 giorno.', 'Entscheidung trifft in 1 Tag ein.', 'A resposta chegará em 1 dia.'));
      } else {
        setStage('REJECTED');
        let counterReq = Math.round(effectiveFee * 1.35);
        if (isSuperStar) counterReq = Math.round(Math.max(baseValue * 1.6, effectiveFee * 1.4));
        const rejectMsg = getLocalizedText(
          `TEKLİF REDDEDİLDİ! ❌ ${clubName}, ${player.name} için bu teklifi yetersiz buldu. En az €${(counterReq / 1_000_000).toFixed(1)}M talep ediliyor.`,
          `OFFER REJECTED! ❌ ${clubName} deemed this offer insufficient for ${player.name}. Demanding at least €${(counterReq / 1_000_000).toFixed(1)}M.`,
          `¡OFERTA RECHAZADA! ❌ ${clubName} consideró insuficiente la oferta por ${player.name}. Piden al menos €${(counterReq / 1_000_000).toFixed(1)}M.`,
          `OFFRE REFUSÉE ! ❌ ${clubName} a jugé cette offre insuffisante pour ${player.name}. Au moins €${(counterReq / 1_000_000).toFixed(1)}M exigés.`,
          `OFFERTA RESPINTA! ❌ Il ${clubName} ha ritenuto insufficiente l'offerta per ${player.name}. Richiesti almeno €${(counterReq / 1_000_000).toFixed(1)}M.`,
          `ANGEBOT ABGELEHNT! ❌ ${clubName} hält dieses Angebot für ${player.name} für unzureichend. Mindestens €${(counterReq / 1_000_000).toFixed(1)}M gefordert.`,
          `PROPOSTA RECUSADA! ❌ O ${clubName} considerou a oferta por ${player.name} insuficiente. Exigem pelo menos €${(counterReq / 1_000_000).toFixed(1)}M.`
        );
        setResultMessage(rejectMsg);
        if (showToast) showToast('error', getLocalizedText('Teklif Reddedildi', 'Offer Rejected', 'Oferta Rechazada', 'Offre Rejetée', 'Offerta Respinta', 'Angebot Abgelehnt', 'Proposta Recusada'), rejectMsg);
      }
    } else {
      // Loan Offer
      // 1. Budget check (Ensure user team has budget for monthly loan fee + player wage)
      const requiredCapital = monthlyLoanFee + Math.round((player.wage || 25000) * 4);
      if (userTeam.budget <= 0 || userTeam.budget < requiredCapital) {
        setStage('REJECTED');
        const msg = getLocalizedText(
          `BÜTÇE YETERSİZ! ⛔ Bütçeniz (€${(userTeam.budget / 1_000_000).toFixed(1)}M) kiralama ücreti ve oyuncunun maaşını karşılamıyor. En az €${(requiredCapital / 1_000_000).toFixed(2)}M bütçe gereklidir.`,
          `INSUFFICIENT BUDGET! ⛔ Your budget (€${(userTeam.budget / 1_000_000).toFixed(1)}M) cannot cover the loan fee and wage. At least €${(requiredCapital / 1_000_000).toFixed(2)}M is required.`,
          `¡PRESUPUESTO INSUFICIENTE! ⛔ Tu saldo (€${(userTeam.budget / 1_000_000).toFixed(1)}M) no cubre la cuota y salario. Se requiere al menos €${(requiredCapital / 1_000_000).toFixed(2)}M.`,
          `BUDGET INSUFFISANT ! ⛔ Votre budget (€${(userTeam.budget / 1_000_000).toFixed(1)}M) ne couvre pas le prêt et salaire. Au moins €${(requiredCapital / 1_000_000).toFixed(2)}M requis.`,
          `BUDGET INSUFFICIENTE! ⛔ Il tuo budget (€${(userTeam.budget / 1_000_000).toFixed(1)}M) non copre prestito e stipendio. Richiesti almeno €${(requiredCapital / 1_000_000).toFixed(2)}M.`,
          `BUDGET UNZUREICHEND! ⛔ Ihr Budget (€${(userTeam.budget / 1_000_000).toFixed(1)}M) reicht nicht für Leihgebühr und Gehalt. Mindestens €${(requiredCapital / 1_000_000).toFixed(2)}M erforderlich.`,
          `ORÇAMENTO INSUFICIENTE! ⛔ Seu saldo (€${(userTeam.budget / 1_000_000).toFixed(1)}M) não cobre a taxa de empréstimo e salário. Mínimo de €${(requiredCapital / 1_000_000).toFixed(2)}M necessário.`
        );
        setResultMessage(msg);
        if (showToast) showToast('error', getLocalizedText('Bütçe Yetersiz ❌', 'Insufficient Budget ❌', 'Presupuesto Insuficiente ❌', 'Budget Insuffisant ❌', 'Budget Insufficiente ❌', 'Budget unzureichend ❌', 'Orçamento Insuficiente ❌'), msg);
        return;
      }

      // 2. Hard Refusals for Valuable / Star Players
      const isSuperValuable = (player.overall >= 78 || baseValue >= 12000000) && player.age < 30 && (player.form || 7.5) >= 6.0;
      if (isSuperValuable) {
        setStage('REJECTED');
        const rejectMsg = getLocalizedText(
          `KİRALIK REDDEDİLDİ! ⛔ ${clubName} yönetimi: "${player.name} (${player.overall} OVR) kulübümüzün kilit yıldızıdır. Kiralık göndermemiz imkansızdır, sadece bonservisiyle satılık."`,
          `LOAN REJECTED! ⛔ ${clubName} board: "${player.name} (${player.overall} OVR) is our star player. We will not loan him, only permanent transfer."`,
          `¡CESIÓN RECHAZADA! ⛔ Directiva de ${clubName}: "${player.name} (${player.overall} OVR) es nuestra estrella. No lo cedemos, solo traspaso."`,
          `PRÊT REFUSÉ ! ⛔ Direction de ${clubName} : "${player.name} (${player.overall} OVR) est notre joueur star. Pas de prêt, uniquement transfert définitif."`,
          `PRESTITO RESPINTO! ⛔ Dirigenza ${clubName}: "${player.name} (${player.overall} OVR) è la nostra stella. Nessun prestito, solo cessione definitiva."`,
          `LEIHE ABGELEHNT! ⛔ ${clubName}-Vorstand: "${player.name} (${player.overall} OVR) ist unser Topstar. Nur Verkauf, keine Leihe."`,
          `EMPRÉSTIMO RECUSADO! ⛔ Diretoria do ${clubName}: "${player.name} (${player.overall} OVR) é nossa grande estrela. Não aceitamos empréstimo, apenas venda."`
        );
        setResultMessage(rejectMsg);
        if (showToast) showToast('error', getLocalizedText('Kiralık Verilmez ❌', 'Not For Loan ❌', 'No se Cede ❌', 'Prêt Refusé ❌', 'Non Cedibile in Prestito ❌', 'Keine Leihe möglich ❌', 'Não Emprestável ❌'), rejectMsg);
        return;
      }

      const isKeyStarter = player.isStarting && player.age < 29 && player.overall >= 73 && (player.form || 7.5) >= 5.5;
      if (isKeyStarter && (wageSharePercent < 100 || monthlyLoanFee < 350000)) {
        setStage('REJECTED');
        const rejectMsg = getLocalizedText(
          `İLK 11 OYUNCUSU! ❌ ${clubName}: "${player.name} ilk 11 oyuncumuzdur. Kiralık verilmesi için %100 maaş katkısı ve en az €350B/ay kiralama bedeli gerekir."`,
          `KEY STARTER! ❌ ${clubName}: "${player.name} is a key starter. To loan him, 100% wage coverage and €350K/month loan fee is required."`,
          `¡TITULAR CLAVE! ❌ ${clubName}: "${player.name} es titular. Para cederlo, se requiere 100% del salario y al menos €350K/mes."`,
          `TITULAIRE CLÉ ! ❌ ${clubName} : "${player.name} est titulaire. Prêt possible uniquement avec 100% du salaire et €350K/mois."`,
          `TITOLARE CHIAVE! ❌ ${clubName}: "${player.name} è titolare. Prestito possibile solo con 100% stipendio e €350K/mese."`,
          `STAMM-SPIELER! ❌ ${clubName}: "${player.name} ist Stammspieler. Leihe nur bei 100% Gehaltsübernahme und €350T/Monat."`,
          `TITULAR ABSOLUTO! ❌ ${clubName}: "${player.name} é titular. Empréstimo apenas com 100% do salário e €350K/mês."`
        );
        setResultMessage(rejectMsg);
        if (showToast) showToast('error', getLocalizedText('İlk 11 Kiralık Zor ❌', 'Starter Loan Demands ❌', 'Condiciones de Cesión ❌', 'Conditions de Prêt ❌', 'Condizioni Prestito ❌', 'Leihbedingungen ❌', 'Condições de Empréstimo ❌'), rejectMsg);
        return;
      }

      const isYoungProspect = player.age <= 21 && player.overall >= 73;
      if (isYoungProspect && (wageSharePercent < 100 || roleGuarantee !== 'STARTER')) {
        setStage('REJECTED');
        const rejectMsg = getLocalizedText(
          `GENÇ YETENEK KİRALANMAZ! ❌ ${clubName}: "${player.name} kulübümüzün geleceğidir. Yalnızca %100 maaş üstlenmesi ve İlk 11 garantisi verilirse kiralarız."`,
          `YOUNG PROSPECT! ❌ ${clubName}: "${player.name} is our future. We will only loan him with 100% wage coverage and a Starting 11 guarantee."`,
          `¡JOVEN PROMESA! ❌ ${clubName}: "${player.name} es nuestro futuro. Solo lo cederemos con 100% de salario y garantía de titular."`,
          `JEUNE TALENT ! ❌ ${clubName} : "${player.name} est notre avenir. Prêt accepté uniquement avec 100% de salaire et garantie de titulaire."`,
          `GIOVANE TALENTO! ❌ ${clubName}: "${player.name} è il nostro futuro. Prestito solo con 100% stipendio e garanzia da titolare."`,
          `TOP-TALENT! ❌ ${clubName}: "${player.name} ist unsere Zukunft. Leihe nur bei 100% Gehalt und Startelf-Garantie."`,
          `JOVEM TALENTO! ❌ ${clubName}: "${player.name} é o nosso futuro. Só emprestamos com 100% do salário e garantia de titular."`
        );
        setResultMessage(rejectMsg);
        if (showToast) showToast('error', getLocalizedText('Genç Yetenek Kiralama Şartı', 'Prospect Loan Terms', 'Condiciones de cesión', 'Conditions de prêt jeune', 'Termini prestito giovane', 'Bedingungen Nachwuchsleihe', 'Condições para jovem promessa'), rejectMsg);
        return;
      }

      if (wageSharePercent < 80 && player.overall >= 70) {
        setStage('REJECTED');
        const rejectMsg = getLocalizedText(
          `MAAŞ KATKISI YETERSİZ! ❌ ${clubName}: "Kiralık oyuncu için maaşının en az %80-%100'ünü ödemelisiniz."`,
          `WAGE CONTRIBUTION INSUFFICIENT! ❌ ${clubName}: "You must cover at least 80-100% of the player's wage."`,
          `¡CONTRIBUCIÓN SALARIAL INSUFICIENTE! ❌ ${clubName}: "Debes cubrir al menos el 80-100% del salario del jugador."`,
          `CONTRIBUTION SALARIALE INSUFFISANTE ! ❌ ${clubName} : "Vous devez prendre en charge au moins 80 à 100% du salaire."`,
          `CONTRIBUTO STIPENDIO INSUFFICIENTE! ❌ ${clubName}: "Dovete coprire almeno l'80-100% dello stipendio."`,
          `GEHALTSANTEIL UNZUREICHEND! ❌ ${clubName}: "Sie müssen mindestens 80-100% des Gehalts übernehmen."`,
          `PARTICIPAÇÃO SALARIAL INSUFICIENTE! ❌ ${clubName}: "Você deve pagar ao menos 80-100% do salário do jogador."`
        );
        setResultMessage(rejectMsg);
        if (showToast) showToast('error', getLocalizedText('Maaş Katkısı Yetersiz', 'Insufficient Wage Share', 'Salario insuficiente', 'Salaire insuffisant', 'Stipendio insufficiente', 'Gehalt unzureichend', 'Salário insuficiente'), rejectMsg);
        return;
      }

      const isSuccess = Math.random() * 100 <= loanProb;
      if (isSuccess) {
        setStage('COMPLETED');
        const successMsg = getLocalizedText(
          `KİRALAMA KABUL EDİLDİ VE TAMAMLANDI! 🔄 ${player.name} sezon sonuna kadar kiralık olarak kadronuza katıldı! (%${wageSharePercent} maaş üstlenildi)`,
          `LOAN ACCEPTED AND COMPLETED! 🔄 ${player.name} has joined your squad on loan until the end of the season! (${wageSharePercent}% wage covered)`,
          `¡CESIÓN ACEPTADA Y COMPLETADA! 🔄 ¡${player.name} se une a tu plantilla cedido hasta final de temporada! (${wageSharePercent}% de salario)`,
          `PRÊT ACCEPTÉ ET FINALISÉ ! 🔄 ${player.name} rejoint votre effectif en prêt jusqu'à la fin de la saison ! (${wageSharePercent}% salaire pris en charge)`,
          `PRESTITO ACCETTATO E CONCLUSO! 🔄 ${player.name} si è unito alla tua rosa in prestito fino al termine della stagione! (${wageSharePercent}% stipendio)`,
          `LEIHE ANGENOMMEN & VOLLZOGEN! 🔄 ${player.name} verstärkt Ihren Kader auf Leihbasis bis Saisonende! (${wageSharePercent}% Gehalt)`,
          `EMPRÉSTIMO ACEITO E CONCLUÍDO! 🔄 ${player.name} junta-se ao seu elenco por empréstimo até ao final da temporada! (${wageSharePercent}% salário)`
        );
        setResultMessage(successMsg);
        confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
        if (showToast) showToast('success', getLocalizedText('Kiralama Tamamlandı! ⚽', 'Loan Deal Completed! ⚽', '¡Cesión Completada! ⚽', 'Prêt Finalisé ! ⚽', 'Prestito Concluso! ⚽', 'Leihe abgeschlossen! ⚽', 'Empréstimo Concluído! ⚽'), successMsg);

        setTimeout(() => {
          onTransferSuccess(player, 'LOAN', monthlyLoanFee);
          onClose();
        }, 1800);
      } else {
        setStage('REJECTED');
        const rejectMsg = getLocalizedText(
          `KİRALAMA REDDEDİLDİ! ❌ ${clubName} kiralama teklifinizi reddetti.`,
          `LOAN REJECTED! ❌ ${clubName} has rejected your loan offer.`,
          `¡CESIÓN RECHAZADA! ❌ ${clubName} ha rechazado tu oferta de cesión.`,
          `PRÊT REFUSÉ ! ❌ ${clubName} a refusé votre offre de prêt.`,
          `PRESTITO RESPINTO! ❌ Il ${clubName} ha respinto la tua offerta di prestito.`,
          `LEIHE ABGELEHNT! ❌ ${clubName} hat Ihr Leihangebot abgelehnt.`,
          `EMPRÉSTIMO RECUSADO! ❌ O ${clubName} recusou a sua proposta de empréstimo.`
        );
        setResultMessage(rejectMsg);
        if (showToast) showToast('error', getLocalizedText('Kiralama Reddedildi ❌', 'Loan Rejected ❌', 'Cesión Rechazada ❌', 'Prêt Refusé ❌', 'Prestito Respinto ❌', 'Leihe Abgelehnt ❌', 'Empréstimo Recusado ❌'), rejectMsg);
      }
    }
  };

  // Outbid rival
  const handleOutbidRival = () => {
    const newFee = Math.round(rivalFee * 1.12);
    if (userTeam.budget < newFee) {
      if (showToast) showToast('error', getLocalizedText('Bütçe Yetersiz ❌', 'Insufficient Budget ❌', 'Presupuesto Insuficiente ❌', 'Budget Insuffisant ❌', 'Budget Insufficiente ❌', 'Budget unzureichend ❌', 'Orçamento Insuficiente ❌'), getLocalizedText('Rakip kulübü geçecek bütçeniz bulunmuyor.', 'Not enough budget to outbid rival club.', 'No tienes suficiente presupuesto para superar al rival.', 'Budget insuffisant pour surenchérir sur le club rival.', 'Budget insufficiente per superare il club rivale.', 'Nicht genug Budget, um das Konkurrenzangebot zu überbieten.', 'Saldo insuficiente para superar o clube rival.'));
      return;
    }
    setOfferFee(newFee);
    if (showToast) {
      showToast(
        'success',
        getLocalizedText('⚡ TEKLİF YÜKSELTİLDİ!', '⚡ BID RAISED!', '⚡ ¡OFERTA AUMENTADA!', '⚡ OFFRE AUGMENTÉE !', '⚡ OFFERTA RIALZATA!', '⚡ GEBOT ERHÖHT!', '⚡ PROPOSTA AUMENTADA!'),
        getLocalizedText(
          `${rivalClubName} ekarte edildi! €${(newFee / 1_000_000).toFixed(1)}M teklifinizle transfer yarışı kazanıldı.`,
          `${rivalClubName} outbid! Transfer battle won with your €${(newFee / 1_000_000).toFixed(1)}M bid.`,
          `¡${rivalClubName} superado! Batalla de fichajes ganada con tu oferta de €${(newFee / 1_000_000).toFixed(1)}M.`,
          `${rivalClubName} écarté ! Vous remportez la bataille avec une offre de €${(newFee / 1_000_000).toFixed(1)}M.`,
          `${rivalClubName} superato! Hai vinto la corsa al giocatore con l'offerta di €${(newFee / 1_000_000).toFixed(1)}M.`,
          `${rivalClubName} überboten! Transferduell mit €${(newFee / 1_000_000).toFixed(1)}M-Angebot gewonnen.`,
          `${rivalClubName} superado! Disputa de transferência ganha com proposta de €${(newFee / 1_000_000).toFixed(1)}M.`
        )
      );
    }
    setStage('PLAYER_CONTRACT');
  };

  // Add clauses to outsmart rival
  const handleAddClausesToOutsmart = () => {
    setSellClause(25);
    setHasBuyBackClause(true);
    if (showToast) {
      showToast(
        'success',
        getLocalizedText('💼 ÖZEL MADDELER EKLENDİ!', '💼 CLAUSES ADDED!', '💼 ¡CLÁUSULAS AÑADIDAS!', '💼 CLAUSES AJOUTÉES !', '💼 CLAUSOLE AGGIUNTE!', '💼 KLAUSELN HINZUGEFÜGT!', '💼 CLÁUSULAS ADICIONADAS!'),
        getLocalizedText(
          `%25 Sonraki satıştan pay ve Geri Satın Alma Maddesi eklendi. ${sellerTeam?.name || 'Kulüp'} teklifinizi kabul etti!`,
          `25% Sell-on and Buy-back clause added. ${sellerTeam?.name || 'Club'} accepted your offer!`,
          `25% de plusvalía y opción de recompra añadidas. ¡${sellerTeam?.name || 'Club'} aceptó la oferta!`,
          `25% à la revente et rachat ajoutés. ${sellerTeam?.name || 'Club'} a accepté votre offre !`,
          `25% futura rivendita e clausola recompra aggiunte. Il ${sellerTeam?.name || 'Club'} ha accettato!`,
          `25% Weiterverkaufsbeteiligung & Rückkaufklausel hinzugefügt. ${sellerTeam?.name || 'Club'} hat angenommen!`,
          `25% de futura venda e cláusula de recompra adicionadas. O ${sellerTeam?.name || 'Clube'} aceitou!`
        )
      );
    }
    setStage('PLAYER_CONTRACT');
  };

  // Finalize player contract signing
  const handleFinalizeContract = () => {
    const isBigStarPlayer = player.overall >= 78 || (player.age >= 30 && player.overall >= 75);

    // Calculate required wage based on team prestige & success
    let minWageMultiplier = 1.0;
    
    if (isBigStarPlayer && !isEuroGiant) {
      if (!hasWonTitles) {
        minWageMultiplier = 2.5; 
      } else {
        minWageMultiplier = 1.3;
      }
    }

    let requiredWage = Math.round(defaultWage * minWageMultiplier);
    if (hasRelegationClause) requiredWage = Math.round(requiredWage * 0.85);

    if (proposedWage < requiredWage) {
      const rejectMsg = getLocalizedText(
        `OYUNCU MAAŞI REDDETTİ! 🛑 ${player.name}: "Kadro projenize tam ikna olmak için en az €${requiredWage.toLocaleString('tr-TR')} / hafta maaş teklif edilmeli."`,
        `PLAYER REJECTED WAGE! 🛑 ${player.name}: "To be convinced by your project, I need at least €${requiredWage.toLocaleString('en-US')} / week."`,
        `¡EL JUGADOR RECHAZÓ EL SALARIO! 🛑 ${player.name}: "Para unirme a este proyecto, necesito al menos €${requiredWage.toLocaleString('es-ES')} / semana."`,
        `LE JOUEUR A REFUSÉ LE SALAIRE ! 🛑 ${player.name} : "Pour être convaincu par le projet, j'exige au moins €${requiredWage.toLocaleString('fr-FR')} / semaine."`,
        `GIOCATORE RIFIUTA LO STIPENDIO! 🛑 ${player.name}: "Per sposare il vostro progetto, chiedo almeno €${requiredWage.toLocaleString('it-IT')} a settimana."`,
        `SPIELER LEHNT GEHALT AB! 🛑 ${player.name}: "Um von Ihrem Projekt überzeugt zu sein, benötige ich mindestens €${requiredWage.toLocaleString('de-DE')} / Woche."`,
        `JOGADOR RECUSOU O SALÁRIO! 🛑 ${player.name}: "Para aceitar este projeto, exijo no mínimo €${requiredWage.toLocaleString('pt-PT')} / semana."`
      );
      if (showToast) showToast('error', getLocalizedText('Yetersiz Maaş Teklifi 🛑', 'Insufficient Wage Offer 🛑', 'Oferta salarial insuficiente 🛑', 'Offre de salaire insuffisante 🛑', 'Offerta stipendio insufficiente 🛑', 'Gehaltsangebot unzureichend 🛑', 'Oferta salarial insuficiente 🛑'), rejectMsg);
      return;
    }

    setStage('COMPLETED');
    const currentYear = new Date().getFullYear();
    const contractUntil = currentYear + contractYears;

    // Joining Date Rules: If league has started (currentWeek > 0), player joins in Ara Transfer Dönemi!
    const isLeagueRunning = currentWeek != null && currentWeek > 0;

    let successMsg = '';
    if (isLeagueRunning) {
      successMsg = getLocalizedText(
        `ANLAŞMA SAĞLANDI! ✍️ ${player.name} ile sözleşme imzalandı! Lig devam ettiği için oyuncu Ara Transfer Döneminde (18. Hafta) takıma katılacaktır.`,
        `AGREEMENT REACHED! ✍️ Contract signed with ${player.name}! As the league is running, player joins in Mid-Season Transfer Window (Week 18).`,
        `¡ACUERDO ALCANZADO! ✍️ ¡Contrato firmado con ${player.name}! El jugador se incorporará en el mercado de invierno (Jornada 18).`,
        `ACCORD CONCLU ! ✍️ Contrat signé avec ${player.name} ! Le joueur rejoindra l'effectif au mercato hivernal (Semaine 18).`,
        `ACCORDO RAGGIUNTO! ✍️ Contratto firmato con ${player.name}! Il giocatore si unirà alla rosa nel calciomercato invernale (Settimana 18).`,
        `EINIGUNG ERZIELT! ✍️ Vertrag mit ${player.name} unterzeichnet! Beitritt erfolgt im Wintertransferfenster (Woche 18).`,
        `ACORDO ALCANÇADO! ✍️ Contrato assinado com ${player.name}! O jogador integrará o elenco na janela de inverno (Semana 18).`
      );
    } else {
      successMsg = getLocalizedText(
        `TRANSFER TAMAMLANDI! ✍️ ${player.name} ile ${contractYears} yıllık sözleşme imzalandı ve hemen takıma katıldı! (€${proposedWage.toLocaleString('tr-TR')} / hafta)`,
        `TRANSFER COMPLETED! ✍️ ${contractYears}-year contract signed with ${player.name} and joined squad immediately! (€${proposedWage.toLocaleString('en-US')} / week)`,
        `¡FICHAJE COMPLETADO! ✍️ ¡Contrato de ${contractYears} años con ${player.name}, se incorpora de inmediato! (€${proposedWage.toLocaleString('es-ES')} / sem)`,
        `TRANSFERT BOUCLÉ ! ✍️ Contrat de ${contractYears} ans signé avec ${player.name}, arrivée immédiate ! (€${proposedWage.toLocaleString('fr-FR')} / sem)`,
        `TRASFERIMENTO COMPLETATO! ✍️ Contratto di ${contractYears} anni con ${player.name}, unito subito alla squadra! (€${proposedWage.toLocaleString('it-IT')} / sett)`,
        `TRANSFER ABGESCHLOSSEN! ✍️ ${contractYears}-Jahres-Vertrag mit ${player.name} unterschrieben, sofort spielberechtigt! (€${proposedWage.toLocaleString('de-DE')} / Woche)`,
        `TRANSFERÊNCIA CONCLUÍDA! ✍️ Contrato de ${contractYears} anos assinado com ${player.name}, integração imediata! (€${proposedWage.toLocaleString('pt-PT')} / sem)`
      );
    }

    setResultMessage(successMsg);
    confetti({ particleCount: 140, spread: 80, origin: { y: 0.5 } });

    // Airport Fan Celebration for Star / Good Players (Overall >= 75)
    if (player.overall >= 75) {
      if (onAddAirportCelebrationInbox) {
        onAddAirportCelebrationInbox(player);
      }
      if (showToast) showToast('success', getLocalizedText('🎉 HAVALİMANI ÇALKALANIYOR!', '🎉 AIRPORT IS BUZZING!', '🎉 ¡LOCURA EN EL AEROPUERTO!', '🎉 ÉBULLITION À L\'AÉROPORT !', '🎉 DELIRIO ALL\'AEROPORTO!', '🎉 FLUGHAFEN BEBT!', '🎉 AEROPORTO EM FESTA!'), getLocalizedText(`Taraftarlar ${player.name} için görkemli bir karşılaşma töreni düzenledi!`, `Fans organized a massive welcome ceremony for ${player.name}!`, `¡Los aficionados organizaron un recibimiento espectacular para ${player.name}!`, `Les supporters ont organisé un accueil triomphal pour ${player.name} !`, `I tifosi hanno organizzato un'accoglienza trionfale per ${player.name}!`, `Die Fans bereiteten ${player.name} einen gigantischen Empfang!`, `Os torcedores fizeram uma festa espetacular para receber ${player.name}!`));
    } else {
      if (showToast) showToast('success', getLocalizedText('Transfer Anlaşması Bitti! 🎉', 'Transfer Deal Done! 🎉', '¡Fichaje Cerrado! 🎉', 'Accord Finalisé ! 🎉', 'Accordo Concluso! 🎉', 'Transfer fixiert! 🎉', 'Transferência Fechada! 🎉'), successMsg);
    }

    setTimeout(() => {
      onTransferSuccess(player, offerType, effectiveFee, {
        wage: proposedWage,
        contractUntil,
        hasRelegationClause,
        releaseClause
      }, isLeagueRunning);
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-[10000] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-1.5 sm:p-3 animate-fadeIn">
      <div className="bg-[#18142a] border border-[#3d2f63] rounded-2xl w-full max-w-lg sm:max-w-xl max-h-[92vh] sm:max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 font-sans text-xs">
        
        {/* Modal Header (Without "1. AŞAMA" badge as requested) */}
        <div className="px-3 py-2 bg-gradient-to-r from-[#21193d] via-[#2d2252] to-[#1a1333] border-b border-[#3b2d63] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 text-slate-950 font-black text-xs shadow">
              {stage === 'HIJACK_WAR' ? '🔥' : stage === 'PLAYER_CONTRACT' ? '✍️' : '💰'}
            </div>
            <div>
              <h3 className="font-extrabold text-white text-xs flex items-center gap-1.5">
                <span>
                  {stage === 'HIJACK_WAR'
                    ? t('HIJACK_WAR_TITLE')
                    : stage === 'PLAYER_CONTRACT'
                    ? t('PLAYER_CONTRACT_TITLE')
                    : t('OFFICIAL_CLUB_TALKS')}
                </span>
              </h3>
              <p className="text-[9px] text-slate-400">
                {sellerTeam ? sellerTeam.name : t('FREE_AGENT_CLUB')} • {player.name}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg bg-[#281f42] hover:bg-[#392c5e] text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Player Mini Header Summary */}
        <div className="px-3 py-1.5 bg-[#120e21] border-b border-[#2d234d] space-y-1.5 shrink-0">
          <div className="bg-[#1a142e] border border-[#382a5c] px-2.5 py-1.5 rounded-xl flex items-center justify-between gap-2 shadow-inner">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-7 h-7 rounded-lg bg-purple-600/20 border border-purple-500/50 flex items-center justify-center font-black text-amber-300 text-xs shrink-0 shadow">
                {player.overall}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h4 className="font-black text-white text-xs truncate">{player.name}</h4>
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-emerald-950 border border-emerald-500/40 text-emerald-300 shrink-0">
                    {t('WAGE_PER_MONTH').replace('{amount}', ((player.wage ? player.wage * 4 : Math.round(baseValue * 0.008))).toLocaleString('tr-TR'))}
                  </span>
                  <span className="px-1 py-0.2 rounded text-[8px] font-black bg-purple-950 border border-purple-500/40 text-purple-300 shrink-0">
                    {player.specificRole || player.position}
                  </span>
                  {player.age >= 30 && (
                    <span className="px-1 py-0.2 rounded text-[8px] font-extrabold bg-amber-950/80 border border-amber-500/40 text-amber-300 shrink-0 flex items-center gap-0.5">
                      <TrendingDown className="w-2.5 h-2.5 text-rose-400" />
                      {t('EXPERIENCED_AGE').replace('{age}', String(player.age))}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1 text-[9px] text-slate-400">
                  <span>🛡️ {sellerTeam ? sellerTeam.name : 'Serbest'}</span>
                  <span>•</span>
                  <span>{player.age} {t('YEARS_OLD')}</span>
                </div>
              </div>
            </div>

            <div className="text-right shrink-0">
              <span className="text-[8px] uppercase font-bold text-slate-400 block">{t('MARKET_VALUE')}</span>
              <span className="text-xs font-black text-amber-300">
                €{(baseValue / 1_000_000).toFixed(1)}M
              </span>
            </div>
          </div>

          {/* Deal Type Switcher (Only in stage 1) */}
          {stage === 'CLUB_DEAL' && (
            <div className="grid grid-cols-2 gap-1 bg-[#171126] p-0.5 rounded-lg border border-[#2d234d]">
              <button
                onClick={() => setOfferType('BUY')}
                className={`py-1 rounded-md font-black text-[10px] flex items-center justify-center gap-1 transition-all ${
                  offerType === 'BUY'
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <DollarSign className="w-3 h-3" /> {t('PERMANENT_TRANSFER')}
              </button>

              <button
                onClick={() => setOfferType('LOAN')}
                className={`py-1 rounded-md font-black text-[10px] flex items-center justify-center gap-1 transition-all ${
                  offerType === 'LOAN'
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <RefreshCw className="w-3 h-3" /> {t('LOAN_OFFER')}
              </button>
            </div>
          )}
        </div>

        {/* Main Content Area */}
        <div className="p-2.5 sm:p-3 overflow-y-auto flex-1 space-y-2 custom-scrollbar bg-[#18142a]">

          {/* STAGE 1: CLUB_DEAL */}
          {stage === 'CLUB_DEAL' && (
            offerType === 'BUY' ? (
              <div className="space-y-2">

                {/* Sleek Custom Money Input (UNLIMITED Custom Fee Entry) */}
                <div className="bg-gradient-to-br from-[#18122c] via-[#1c1536] to-[#130e24] p-2.5 rounded-2xl border border-[#3e2e66] shadow-xl space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <div className="p-1 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 shrink-0">
                        <DollarSign className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-[10px] font-black uppercase text-slate-200 tracking-wider block truncate">
                          {t('TRANSFER_FEE_LABEL')}
                        </span>
                        <span className="text-[8.5px] text-slate-400 block truncate">
                          {t('MARKET_VALUE')}: €{(baseValue / 1_000_000).toFixed(1)}M
                        </span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-[8px] font-bold text-slate-400 block">{t('YOUR_CLUB_BUDGET')}</span>
                      <span className="text-xs font-black text-emerald-400">
                        €{(userTeam.budget / 1_000_000).toFixed(1)}M
                      </span>
                    </div>
                  </div>

                  {/* Direct Input Field for Unlimited Fee Entry with Dot Formatting */}
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 bg-[#0d091a] p-1.5 rounded-xl border border-[#362759]">
                      <span className="text-amber-300 font-black text-sm pl-1">€</span>
                      <input
                        type="text"
                        inputMode="numeric"
                        value={offerFee ? offerFee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.') : ''}
                        onChange={(e) => {
                          const rawVal = e.target.value.replace(/\D/g, '');
                          setOfferFee(rawVal ? parseInt(rawVal, 10) : 0);
                        }}
                        className="w-full bg-transparent text-white font-black text-sm sm:text-base focus:outline-none placeholder-slate-600"
                        placeholder={t('FEE_PLACEHOLDER')}
                      />
                      <span className="text-[10px] font-bold text-purple-300 pr-1 shrink-0">
                        ({(offerFee / 1_000_000).toFixed(2)}M €)
                      </span>
                    </div>

                    {/* Quick Steppers (Unlimited) */}
                    <div className="flex items-center justify-between gap-1 pt-0.5">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setOfferFee(prev => Math.max(100000, prev - 1000000))}
                          className="px-2 py-0.5 bg-[#231b3e] hover:bg-[#322657] active:scale-95 text-white font-extrabold rounded-lg border border-[#3b2c61] text-[9px] transition-all"
                        >
                          -€1.0M
                        </button>
                        <button
                          onClick={() => setOfferFee(prev => Math.max(100000, prev - 250000))}
                          className="px-2 py-0.5 bg-[#231b3e] hover:bg-[#322657] active:scale-95 text-white font-extrabold rounded-lg border border-[#3b2c61] text-[9px] transition-all"
                        >
                          -€0.25M
                        </button>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setOfferFee(prev => prev + 250000)}
                          className="px-2 py-0.5 bg-[#231b3e] hover:bg-[#322657] active:scale-95 text-white font-extrabold rounded-lg border border-[#3b2c61] text-[9px] transition-all"
                        >
                          +€0.25M
                        </button>
                        <button
                          onClick={() => setOfferFee(prev => prev + 1000000)}
                          className="px-2 py-0.5 bg-[#231b3e] hover:bg-[#322657] active:scale-95 text-white font-extrabold rounded-lg border border-[#3b2c61] text-[9px] transition-all"
                        >
                          +€1.0M
                        </button>
                        <button
                          onClick={() => setOfferFee(prev => prev + 5000000)}
                          className="px-2 py-0.5 bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 active:scale-95 text-amber-200 font-black rounded-lg border border-purple-400 text-[9px] transition-all shadow"
                        >
                          +€5.0M
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Ödeme Şekli & Taksit Seçenekleri Ekranı */}
                <div className="bg-[#120e21] p-2 sm:p-2.5 rounded-xl border border-[#2c224a] space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] font-black text-slate-200 uppercase flex items-center gap-1">
                      <CreditCard className="w-3.5 h-3.5 text-purple-400" />
                      {t('PAYMENT_METHOD')}
                    </span>

                    <div className="flex items-center gap-1 bg-[#1b1530] p-0.5 rounded-lg border border-[#382b5e]">
                      <button
                        onClick={() => setPaymentMode('CASH')}
                        className={`px-2.5 py-1 rounded-md text-[9.5px] font-extrabold transition-all ${
                          paymentMode === 'CASH'
                            ? 'bg-emerald-600 text-white shadow'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        💵 {t('CASH_PAYMENT')}
                      </button>
                      <button
                        onClick={() => setPaymentMode('INSTALLMENTS')}
                        className={`px-2.5 py-1 rounded-md text-[9.5px] font-extrabold transition-all ${
                          paymentMode === 'INSTALLMENTS'
                            ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        💳 {t('INSTALLMENT_PAYMENT')}
                      </button>
                    </div>
                  </div>

                  {/* Dynamic Installment Policy & Breakdown Screen */}
                  {paymentMode === 'INSTALLMENTS' && (
                    <div className="bg-[#18122c] border border-purple-500/40 p-2 sm:p-2.5 rounded-xl space-y-2 animate-in fade-in duration-200">
                      
                      {/* Team Policy Banner */}
                      {installmentPolicyType === 'NO_INSTALLMENTS' && (
                        <div className="p-2 rounded-lg bg-rose-950/80 border border-rose-500/60 text-rose-200 text-[9.5px] font-extrabold flex items-center gap-1.5">
                          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                          <span>⛔ {getLocalizedText(
                            `${sellerTeam?.name || 'Kulüp'} taksitli ödemeyi kabul etmiyor, sadece peşin ödeme talep ediyor.`,
                            `${sellerTeam?.name || 'Club'} does not accept installments, only cash upfront is accepted.`,
                            `${sellerTeam?.name || 'Club'} no acepta plazos, solo exige pago al contado.`,
                            `${sellerTeam?.name || 'Club'} n'accepte pas l'échelonnement, paiement comptant exigé.`,
                            `${sellerTeam?.name || 'Club'} non accetta pagamenti a rate, richiede solo contanti.`,
                            `${sellerTeam?.name || 'Club'} akzeptiert keine Raten, nur Barzahlung möglich.`,
                            `${sellerTeam?.name || 'Clube'} não aceita parcelamento, apenas pagamento à vista.`
                          )}</span>
                        </div>
                      )}

                      {installmentPolicyType === 'EXTRA_CHARGE' && (
                        <div className="p-2 rounded-lg bg-amber-950/80 border border-amber-500/60 text-amber-200 text-[9.5px] font-extrabold flex items-center gap-1.5">
                          <TrendingUp className="w-4 h-4 text-amber-400 shrink-0" />
                          <span>💳 {getLocalizedText(
                            `${sellerTeam?.name || 'Kulüp'} taksiti kabul ediyor ancak %${installmentMarkupPercent} vade farkı (+€${(offerFee * installmentMarkupPercent / 100 / 1_000_000).toFixed(2)}M) talep ediyor.`,
                            `${sellerTeam?.name || 'Club'} accepts installments with a ${installmentMarkupPercent}% surcharge (+€${(offerFee * installmentMarkupPercent / 100 / 1_000_000).toFixed(2)}M).`,
                            `${sellerTeam?.name || 'Club'} acepta plazos con recargo del ${installmentMarkupPercent}% (+€${(offerFee * installmentMarkupPercent / 100 / 1_000_000).toFixed(2)}M).`,
                            `${sellerTeam?.name || 'Club'} accepte l'échelonnement avec une majoration de ${installmentMarkupPercent}% (+€${(offerFee * installmentMarkupPercent / 100 / 1_000_000).toFixed(2)}M).`,
                            `${sellerTeam?.name || 'Club'} accetta le rate con un ricarico del ${installmentMarkupPercent}% (+€${(offerFee * installmentMarkupPercent / 100 / 1_000_000).toFixed(2)}M).`,
                            `${sellerTeam?.name || 'Club'} akzeptiert Raten mit einem Zinsaufschlag von ${installmentMarkupPercent}% (+€${(offerFee * installmentMarkupPercent / 100 / 1_000_000).toFixed(2)}M).`,
                            `${sellerTeam?.name || 'Clube'} aceita parcelamento com taxa de ${installmentMarkupPercent}% (+€${(offerFee * installmentMarkupPercent / 100 / 1_000_000).toFixed(2)}M).`
                          )}</span>
                        </div>
                      )}

                      {installmentPolicyType === 'DIRECT_ACCEPT' && (
                        <div className="p-2 rounded-lg bg-emerald-950/80 border border-emerald-500/60 text-emerald-200 text-[9.5px] font-extrabold flex items-center gap-1.5">
                          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>✅ {getLocalizedText(
                            `${sellerTeam?.name || 'Kulüp'} taksitli ödeme planını ek ücret talep etmeden kabul ediyor.`,
                            `${sellerTeam?.name || 'Club'} accepts the installment plan with no additional surcharge.`,
                            `${sellerTeam?.name || 'Club'} acepta el plan de pago a plazos sin cargo adicional.`,
                            `${sellerTeam?.name || 'Club'} accepte le plan d'échelonnement sans frais supplémentaires.`,
                            `${sellerTeam?.name || 'Club'} accetta il piano rateale senza costi aggiuntivi.`,
                            `${sellerTeam?.name || 'Club'} akzeptiert die Ratenzahlung ohne Zusatzkosten.`,
                            `${sellerTeam?.name || 'Clube'} aceita o plano de parcelamento sem taxas extras.`
                          )}</span>
                        </div>
                      )}

                      {/* Installment Selector & Calculations */}
                      <div className="grid grid-cols-2 gap-2">
                        {[2, 3].map(count => (
                          <button
                            key={count}
                            onClick={() => setInstallmentCount(count)}
                            className={`py-1.5 px-1 rounded-lg text-[9px] font-extrabold border transition-all text-center ${
                              installmentCount === count
                                ? 'bg-purple-600/90 border-purple-400 text-white shadow'
                                : 'bg-[#100c1e] border-[#312552] text-slate-400 hover:text-white'
                            }`}
                          >
                            <span className="block font-black text-amber-300">
                              {count} {getLocalizedText('Yıl', 'Years', 'Años', 'Ans', 'Anni', 'Jahre', 'Anos')}
                            </span>
                            <span className="block text-[8px]">
                              €{(effectiveFee / count / 1_000_000).toFixed(2)}M / {getLocalizedText('Yıl', 'Year', 'Año', 'An', 'Anno', 'Jahr', 'Ano')}
                            </span>
                          </button>
                        ))}
                      </div>

                      <div className="flex items-center justify-between text-[9px] text-slate-300 pt-0.5 border-t border-[#332657]">
                        <span>{getLocalizedText('Toplam Taksitli Maliyet', 'Total Installment Cost', 'Coste Total a Plazos', 'Coût Total Échelonné', 'Costo Totale a Rate', 'Gesamtkosten Raten', 'Custo Total Parcelado')}:</span>
                        <span className="font-black text-emerald-300 text-xs">€{(effectiveFee / 1_000_000).toFixed(2)}M</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Clauses & Extras */}
                <div className="grid grid-cols-2 gap-1.5">
                  {/* Sonraki Satıştan Pay */}
                  <div className="bg-[#120e21] p-2 rounded-xl border border-[#2c224a] space-y-1">
                    <label className="text-[9px] font-black text-slate-300 flex items-center justify-between">
                      <span>% {getLocalizedText('Sonraki Satıştan Pay', 'Sell-On Clause', 'Plusvalía Futura', 'Pourcentage Revente', 'Percentuale Rivendita', 'Weiterverkaufsbeteiligung', 'Cláusula de Revenda')}:</span>
                      <span className="text-purple-300 font-black">%{sellClause}</span>
                    </label>
                    <CustomSelect
                      value={String(sellClause)}
                      onChange={(val) => setSellClause(Number(val))}
                      options={[
                        { value: '0', label: `%0 ${getLocalizedText('Yok', 'None', 'Ninguno', 'Aucun', 'Nessuno', 'Keine', 'Nenhum')}` },
                        { value: '10', label: `%10 ${getLocalizedText('Pay', 'Clause', 'Plusvalía', 'Revente', 'Rivendita', 'Beteiligung', 'Revenda')}` },
                        { value: '15', label: `%15 ${getLocalizedText('Pay', 'Clause', 'Plusvalía', 'Revente', 'Rivendita', 'Beteiligung', 'Revenda')}` },
                        { value: '20', label: `%20 ${getLocalizedText('Pay', 'Clause', 'Plusvalía', 'Revente', 'Rivendita', 'Beteiligung', 'Revenda')}` },
                        { value: '25', label: `%25 ${getLocalizedText('Pay', 'Clause', 'Plusvalía', 'Revente', 'Rivendita', 'Beteiligung', 'Revenda')}` }
                      ]}
                    />
                  </div>

                  {/* Geri Satın Alma Maddesi */}
                  <div className="bg-[#120e21] p-2 rounded-xl border border-[#2c224a] space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-[9px] font-black text-slate-300">
                        🔄 {getLocalizedText('Geri Satın Alma Maddesi', 'Buy-Back Clause', 'Cláusula de Recompra', 'Clause de Rachat', 'Clausola di Riacquisto', 'Rückkauf-Klausel', 'Cláusula de Recompra')}
                      </label>
                      <input
                        type="checkbox"
                        checked={hasBuyBackClause}
                        onChange={(e) => setHasBuyBackClause(e.target.checked)}
                        className="w-3.5 h-3.5 accent-purple-500 rounded cursor-pointer"
                      />
                    </div>
                    {hasBuyBackClause ? (
                      <CustomSelect
                        value={String(buyBackFee)}
                        onChange={(val) => setBuyBackFee(Number(val))}
                        options={[
                          { value: String(Math.round(baseValue * 1.3)), label: `€${(baseValue * 1.3 / 1_000_000).toFixed(1)}M ${getLocalizedText('Geri Alma', 'Buy-Back', 'Recompra', 'Rachat', 'Riacquisto', 'Rückkauf', 'Recompra')}` },
                          { value: String(Math.round(baseValue * 1.6)), label: `€${(baseValue * 1.6 / 1_000_000).toFixed(1)}M ${getLocalizedText('Geri Alma', 'Buy-Back', 'Recompra', 'Rachat', 'Riacquisto', 'Rückkauf', 'Recompra')}` },
                          { value: String(Math.round(baseValue * 2.0)), label: `€${(baseValue * 2.0 / 1_000_000).toFixed(1)}M ${getLocalizedText('Geri Alma', 'Buy-Back', 'Recompra', 'Rachat', 'Riacquisto', 'Rückkauf', 'Recompra')}` }
                        ]}
                      />
                    ) : (
                      <p className="text-[8px] text-slate-400">{getLocalizedText('Gelecekte sabit bedelle geri alma opsiyonu kulübe indirim sağlar.', 'Buy-back option grants discounts on negotiation.', 'La opción de recompra abarata la negociación.', 'L\'option de rachat réduit le coût du transfert.', 'L\'opzione di riacquisto riduce il costo del trasferimento.', 'Rückkaufoption senkt die Ablöseforderung.', 'A opção de recompra reduz o valor da negociação.')}</p>
                    )}
                  </div>

                  {/* Şampiyonluk Bonusu */}
                  <div className="bg-[#120e21] p-2 rounded-xl border border-[#2c224a] space-y-1">
                    <label className="text-[9px] font-black text-slate-300 flex items-center justify-between">
                      <span>🏆 {t('CHAMPIONSHIP_TITLE')}:</span>
                      <span className="text-amber-300 font-extrabold">
                        {championshipBonus > 0 ? `€${(championshipBonus / 1_000_000).toFixed(1)}M` : t('NONE')}
                      </span>
                    </label>
                    <CustomSelect
                      value={String(championshipBonus)}
                      onChange={(val) => setChampionshipBonus(Number(val))}
                      options={[
                        { value: '0', label: t('NO_BONUS') },
                        { value: '1000000', label: '€1.0M' },
                        { value: '2500000', label: '€2.5M' },
                        { value: '5000000', label: '€5.0M' }
                      ]}
                    />
                  </div>

                  {/* UCL Bonusu */}
                  <div className="bg-[#120e21] p-2 rounded-xl border border-[#2c224a] space-y-1">
                    <label className="text-[9px] font-black text-slate-300 flex items-center justify-between">
                      <span>⭐ {t('EUROPEAN_TICKET')}:</span>
                      <span className="text-sky-300 font-extrabold">
                        {uclBonus > 0 ? `€${(uclBonus / 1_000_000).toFixed(1)}M` : t('NO_BONUS')}
                      </span>
                    </label>
                    <CustomSelect
                      value={String(uclBonus)}
                      onChange={(val) => setUclBonus(Number(val))}
                      options={[
                        { value: '0', label: t('NO_BONUS') },
                        { value: '1500000', label: '€1.5M UCL' },
                        { value: '3000000', label: '€3.0M UCL' }
                      ]}
                    />
                  </div>
                </div>

                {/* Kulüp Kabul İhtimali Göstergesi (RESPONSIVE SINGLE ROW ON MOBILE) */}
                <div className={`p-2 sm:p-2.5 rounded-xl border flex items-center justify-between gap-2 shadow-lg transition-all ${
                  buyProb >= 70
                    ? 'bg-emerald-950/80 border-emerald-500/70 text-emerald-200'
                    : buyProb >= 40
                    ? 'bg-amber-950/80 border-amber-500/70 text-amber-200'
                    : 'bg-rose-950/80 border-rose-500/70 text-rose-200'
                }`}>
                  <div className="flex items-center gap-2 min-w-0">
                    <Sparkles className="w-4 h-4 shrink-0 text-amber-300 animate-pulse" />
                    <div className="min-w-0">
                      <span className="font-black text-[10px] sm:text-[11px] block truncate">
                        {t('CLUB_AGREEMENT_ESTIMATE')}
                      </span>
                      <span className="text-[8.5px] sm:text-[9px] opacity-90 block leading-tight truncate">
                        {player.age >= 30
                          ? buyProb >= 60
                            ? '✅'
                            : t('CLUB_WAITING_NEGOTIATION')
                          : buyProb >= 70
                          ? ''
                          : buyProb >= 40
                          ? ''
                          : t('CLUB_WAITING_NEGOTIATION')}
                      </span>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full font-black text-[10px] sm:text-xs bg-slate-950/90 border border-white/20 text-amber-300 shadow shrink-0">
                    %{buyProb} Şans
                  </span>
                </div>

              </div>
            ) : (
              /* Loan Offer Controls */
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-1.5">
                  <div className="bg-[#120e21] p-2 rounded-xl border border-[#2c224a] space-y-1">
                    <label className="text-[9px] font-extrabold text-slate-300 block">{t('LOAN_DURATION_LABEL')}</label>
                    <CustomSelect
                      value={loanDuration}
                      onChange={(val) => setLoanDuration(val as any)}
                      options={[
                        { value: '1_SEASON', label: t('ONE_SEASON') },
                        { value: '6_MONTHS', label: t('SIX_MONTHS') }
                      ]}
                    />
                  </div>

                  <div className="bg-[#120e21] p-2 rounded-xl border border-[#2c224a] space-y-1">
                    <label className="text-[9px] font-extrabold text-slate-300 block flex items-center justify-between">
                      <span>{t('WAGE_CONTRIBUTION')}</span>
                      <span className="text-emerald-400 font-black">%{wageSharePercent}</span>
                    </label>
                    <CustomSelect
                      value={String(wageSharePercent)}
                      onChange={(val) => setWageSharePercent(Number(val))}
                      options={[
                        { value: '100', label: t('WAGE_SHARE_OURS', { percent: 100 }) },
                        { value: '90', label: t('WAGE_SHARE_OURS', { percent: 90 }) },
                        { value: '80', label: t('WAGE_SHARE_OURS', { percent: 80 }) },
                        { value: '70', label: t('WAGE_SHARE_OURS', { percent: 70 }) },
                        { value: '60', label: t('WAGE_SHARE_OURS', { percent: 60 }) },
                        { value: '50', label: t('WAGE_SHARE_SPLIT') },
                        { value: '40', label: t('WAGE_SHARE_OURS', { percent: 40 }) },
                        { value: '30', label: t('WAGE_SHARE_OURS', { percent: 30 }) },
                        { value: '20', label: t('WAGE_SHARE_OURS', { percent: 20 }) },
                        { value: '10', label: t('WAGE_SHARE_OURS', { percent: 10 }) }
                      ]}
                    />
                  </div>
                </div>

                {/* Calculated Wage Breakdown Box */}
                {(() => {
                  const totalMonthlyWage = player.wage ? player.wage * 4 : Math.round(baseValue * 0.008);
                  const ourPercent = wageSharePercent;
                  const opponentPercent = 100 - wageSharePercent;
                  const ourMonthlyWage = Math.round(totalMonthlyWage * (ourPercent / 100));
                  const opponentMonthlyWage = Math.round(totalMonthlyWage * (opponentPercent / 100));

                  return (
                    <div className="p-2.5 rounded-xl bg-[#110d21] border border-[#2d224d] space-y-2 shadow-inner">
                      <div className="flex items-center justify-between text-[10px] font-black uppercase text-slate-300">
                        <span>{t('MONTHLY_WAGE_DISTRIBUTION')}</span>
                        <span className="text-amber-300">{t('TOTAL_MONTHLY', { amount: totalMonthlyWage.toLocaleString('tr-TR') })}</span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs font-bold">
                        <div className="p-2 rounded-lg bg-emerald-950/70 border border-emerald-500/50 text-emerald-200 space-y-0.5">
                          <span className="text-[9px] font-black text-emerald-400 block uppercase">
                            {t('OUR_PAYMENT_SHARE', { percent: ourPercent })}
                          </span>
                          <span className="text-sm font-black text-white block">
                            €{ourMonthlyWage.toLocaleString('tr-TR')} {t('PER_MONTH_SHORT')}
                          </span>
                        </div>

                        <div className="p-2 rounded-lg bg-purple-950/70 border border-purple-500/50 text-purple-200 space-y-0.5">
                          <span className="text-[9px] font-black text-purple-400 block uppercase">
                            {t('OTHER_CLUB_SHARE', { team: sellerTeam?.name || t('OPPONENT_CLUB'), percent: opponentPercent })}
                          </span>
                          <span className="text-sm font-black text-white block">
                            €{opponentMonthlyWage.toLocaleString('tr-TR')} {t('PER_MONTH_SHORT')}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )
          )}

          {/* STAGE 2: HIJACK_WAR */}
          {stage === 'HIJACK_WAR' && (
            <div className="space-y-2 animate-in zoom-in duration-200">
              <div className="p-2.5 rounded-xl bg-gradient-to-r from-rose-950/80 via-amber-950/80 to-purple-950/80 border border-rose-500/60 shadow-xl space-y-1">
                <div className="flex items-center gap-1.5 text-rose-400 font-black text-xs uppercase tracking-wide">
                  <Flame className="w-4 h-4 text-amber-400 animate-bounce" />
                  <span>{t('HIJACK_TITLE')}</span>
                </div>
                <p className="text-[10px] text-slate-200 leading-relaxed font-medium">
                  {t('HIJACK_DESC', { rival: rivalClubName, player: player.name, fee: (rivalFee / 1_000_000).toFixed(1) })}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="bg-[#120e21] border border-[#3b2d63] p-2 rounded-xl text-center">
                  <span className="text-[9px] font-extrabold text-slate-400 uppercase block">{t('YOUR_OFFER')}</span>
                  <span className="text-sm font-black text-emerald-400 block">
                    €{(effectiveFee / 1_000_000).toFixed(1)}M
                  </span>
                  <span className="text-[8px] text-purple-300 font-bold block">
                    %{sellClause} {t('SELL_CLAUSE_SHORT')}
                  </span>
                </div>

                <div className="bg-[#24111d] border border-rose-500/50 p-2 rounded-xl text-center relative overflow-hidden">
                  <span className="text-[9px] font-extrabold text-rose-300 uppercase block">{rivalClubName}</span>
                  <span className="text-sm font-black text-rose-400 block">
                    €{(rivalFee / 1_000_000).toFixed(1)}M
                  </span>
                  <span className="text-[8px] text-amber-300 font-bold block">
                    {t('HIGH_PLAYER_BONUSES')}
                  </span>
                </div>
              </div>

              {/* Counter Action Options */}
              <div className="space-y-1.5 pt-0.5">
                <button
                  onClick={handleOutbidRival}
                  className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-[10px] uppercase tracking-wider shadow flex items-center justify-between transition-all active:scale-98"
                >
                  <div className="flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 fill-slate-950" />
                    <span>{t('OUTBID_BUTTON', { fee: (rivalFee * 1.12 / 1_000_000).toFixed(1) })}</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => setStage('CLUB_DEAL')}
                  className="w-full py-1.5 px-3 rounded-xl bg-[#241a42] hover:bg-[#32245c] border border-purple-500/40 text-purple-200 font-extrabold text-[10px] flex items-center justify-between transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-1.5">
                    <Handshake className="w-3.5 h-3.5 text-purple-400" />
                    <span>{t('REVISE_OFFER')}</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => {
                    setStage('REJECTED');
                    const msg = `${rivalClubName} kulübü transfer yarışını kazandı ve ${player.name}'i kadrosuna kattı.`;
                    setResultMessage(msg);
                    if (showToast) showToast('error', 'Transfer Yarışı Kaybedildi', msg);
                  }}
                  className="w-full py-1 px-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-400 text-[9px] font-bold transition-all text-center cursor-pointer"
                >
                  {t('WITHDRAW_OFFER')}
                </button>
              </div>
            </div>
          )}

          {/* STAGE 3: PLAYER_CONTRACT */}
          {stage === 'PLAYER_CONTRACT' && (
            <div className="space-y-2 animate-in fade-in duration-200">
              <div className="p-2.5 rounded-xl bg-gradient-to-r from-purple-950/60 to-indigo-950/60 border border-purple-500/40 space-y-0.5">
                <h4 className="font-extrabold text-[11px] text-purple-300 flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5 text-purple-400" />
                  <span>{t('AGENT_CONTRACT_DESK')}</span>
                </h4>
                <p className="text-[10px] text-slate-300">
                  {t('AGENT_CONTRACT_DESC', { player: player.name })}
                </p>
              </div>

              {/* POLITE ADVICE BANNER FOR STAR PLAYERS */}
              {(player.overall >= 78 || (player.age >= 30 && player.overall >= 75)) && (
                <div className="p-2.5 rounded-xl bg-gradient-to-r from-purple-950/90 via-indigo-900/80 to-purple-950/90 border border-purple-500/60 shadow-lg text-purple-200 space-y-1">
                  <div className="flex items-center gap-1.5 font-black text-[11px] text-amber-300">
                    <Crown className="w-4 h-4 text-amber-300" />
                    <span>{t('CAREER_ADVICE_TITLE')}</span>
                  </div>
                  <p className="text-[9.5px] leading-relaxed font-semibold text-slate-200">
                    {t('CAREER_ADVICE_DESC', { player: player.name, wage: (defaultWage * 2.2).toLocaleString('tr-TR') })}
                  </p>
                </div>
              )}

              {/* Proposed Wage with Current Wage Display */}
              <div className="bg-[#120e21] p-2.5 rounded-xl border border-[#2c224a] space-y-2">
                <div className="flex items-center justify-between text-[10px] bg-[#1a1430] p-1.5 rounded-lg border border-[#342759]">
                  <span className="text-slate-400 font-bold">{t('CURRENT_WEEKLY_WAGE')}</span>
                  <span className="font-extrabold text-amber-300">€{(player.wage || 25000).toLocaleString('tr-TR')} / hafta</span>
                </div>

                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-extrabold text-slate-200 uppercase">{t('PROPOSED_WEEKLY_WAGE')}</label>
                  <span className="text-[11px] font-black text-emerald-400">€{proposedWage.toLocaleString('tr-TR')} / hafta</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setProposedWage(prev => Math.max(5000, prev - 5000))}
                    className="px-2.5 py-1 bg-[#251d3d] hover:bg-[#342954] text-white font-extrabold rounded-lg border border-[#3f3066] text-[10px] cursor-pointer"
                  >
                    - €5.000
                  </button>
                  <input
                    type="number"
                    step="5000"
                    value={proposedWage}
                    onChange={(e) => setProposedWage(Number(e.target.value) || 0)}
                    className="flex-1 bg-[#1b1530] border border-[#382b5e] rounded-lg px-2 py-1 text-[11px] font-black text-emerald-300 focus:outline-none text-center"
                  />
                  <button
                    onClick={() => setProposedWage(prev => prev + 5000)}
                    className="px-2.5 py-1 bg-[#251d3d] hover:bg-[#342954] text-white font-extrabold rounded-lg border border-[#3f3066] text-[10px] cursor-pointer"
                  >
                    + €5.000
                  </button>
                  <button
                    onClick={() => setProposedWage(prev => prev + 25000)}
                    className="px-2 py-1 bg-gradient-to-r from-amber-600 to-yellow-600 text-slate-950 font-black rounded-lg text-[9.5px] cursor-pointer"
                  >
                    + €25.000
                  </button>
                </div>
              </div>

              {/* Contract Duration */}
              <div className="bg-[#120e21] p-2 rounded-xl border border-[#2c224a] space-y-1">
                <label className="text-[10px] font-extrabold text-slate-200 uppercase block">{t('CONTRACT_DURATION')}</label>
                <div className="grid grid-cols-5 gap-1">
                  {[1, 2, 3, 4, 5].map(yr => (
                    <button
                      key={yr}
                      onClick={() => setContractYears(yr)}
                      className={`py-1 rounded-lg text-[10px] font-black transition-all cursor-pointer ${
                        contractYears === yr
                          ? 'bg-purple-600 text-white shadow border border-purple-400'
                          : 'bg-[#1b1530] text-slate-400 border border-[#382b5e] hover:text-white'
                      }`}
                    >
                      {yr} {t('YEARS_UNIT')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Küme Düşerse Serbest Kalma Maddesi */}
              <div className="bg-[#120e21] p-2 rounded-xl border border-[#2c224a] space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-extrabold text-slate-200 block">
                      {t('RELEGATION_RELEASE_CLAUSE')}
                    </span>
                    <span className="text-[8px] text-slate-400 block leading-tight">
                      {t('RELEGATION_RELEASE_DESC')}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setHasRelegationClause(!hasRelegationClause)}
                    className={`w-9 h-5 rounded-full transition-colors relative p-0.5 shrink-0 cursor-pointer ${
                      hasRelegationClause ? 'bg-emerald-500' : 'bg-slate-700'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white transition-transform ${
                        hasRelegationClause ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Serbest Kalma Bedeli (Modern Tactics-style Pills) */}
              <div className="bg-[#120e21] p-2.5 rounded-xl border border-[#2c224a] space-y-1.5">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-extrabold text-slate-200 uppercase">{t('RELEASE_CLAUSE_LABEL')}</label>
                  <span className="text-[10px] font-black text-amber-300">€{(releaseClause / 1_000_000).toFixed(1)}M</span>
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 pt-0.5">
                  {[
                    { val: Math.round(baseValue * 1.5), label: t('RELEASE_LOW'), text: `€${(baseValue * 1.5 / 1_000_000).toFixed(1)}M` },
                    { val: Math.round(baseValue * 2.5), label: t('RELEASE_STANDARD'), text: `€${(baseValue * 2.5 / 1_000_000).toFixed(1)}M` },
                    { val: Math.round(baseValue * 4.0), label: t('RELEASE_HIGH'), text: `€${(baseValue * 4.0 / 1_000_000).toFixed(1)}M` },
                    { val: 150000000, label: t('RELEASE_SUPERSTAR'), text: '€150.0M' }
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      type="button"
                      onClick={() => setReleaseClause(opt.val)}
                      className={`py-1.5 px-2 rounded-xl text-[10px] font-bold border transition-all cursor-pointer ${
                        releaseClause === opt.val
                          ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-purple-400 shadow-md scale-[1.02]'
                          : 'bg-[#1b1530] border-[#382b5e] text-slate-300 hover:text-white hover:border-purple-400/50'
                      }`}
                    >
                      <div className="text-[8.5px] font-black uppercase text-amber-300">{opt.label}</div>
                      <div className="font-extrabold text-[10px]">{opt.text}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* OFFER SUBMITTED STAGE */}
          {stage === 'OFFER_SUBMITTED' && (
            <div className="py-6 px-4 text-center space-y-4 animate-fadeIn">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 mx-auto flex items-center justify-center shadow-lg animate-bounce">
                <Send className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  {t('OFFER_DELIVERED_TITLE')}
                </h3>
                <p className="text-xs text-slate-300 mt-2 max-w-md mx-auto leading-relaxed font-medium">
                  {t('OFFER_DELIVERED_BODY', { team: sellerTeam?.name || t('CLUB_LABEL'), player: player.name, fee: (effectiveFee / 1_000_000).toFixed(1) })}
                </p>
                <div className="mt-3 p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-300 text-[11px] font-bold inline-block">
                  {t('OFFER_DELIVERED_NOTE')}
                </div>
              </div>
            </div>
          )}

          {/* Result Alert Area */}
          {resultMessage && (
            <div className={`p-2.5 rounded-xl border text-[10px] font-bold leading-relaxed animate-shake ${
              stage === 'COMPLETED'
                ? 'bg-emerald-950/60 border-emerald-500/60 text-emerald-200'
                : 'bg-rose-950/60 border-rose-500/60 text-rose-200'
            }`}>
              {resultMessage}
            </div>
          )}

        </div>

        {/* Modal Footer Actions */}
        <div className="p-2.5 sm:p-3 bg-[#120e21] border-t border-[#2d234d] flex items-center justify-between gap-2 shrink-0">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-extrabold text-[10px] transition-colors"
          >
            {t('CANCEL')}
          </button>

          {stage === 'CLUB_DEAL' && (
            <button
              onClick={handleSendClubOffer}
              className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-[10px] uppercase tracking-wider shadow active:scale-95 transition-all flex items-center gap-1"
            >
              <span>{offerType === 'BUY' ? t('SEND_OFFICIAL_OFFER') : t('SUBMIT_LOAN_OFFER')}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}

          {stage === 'PLAYER_CONTRACT' && (
            <button
              onClick={handleFinalizeContract}
              className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white font-black text-[10px] uppercase tracking-wider shadow active:scale-95 transition-all flex items-center gap-1"
            >
              <span>{t('SIGN_DEAL')}</span>
              <Check className="w-3.5 h-3.5" />
            </button>
          )}

          {stage === 'REJECTED' && (
            <button
              onClick={() => {
                setStage('CLUB_DEAL');
                setResultMessage(null);
              }}
              className="px-4 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-black text-[10px] uppercase tracking-wider transition-all cursor-pointer"
            >
              {t('REVISE_OFFER')}
            </button>
          )}

          {stage === 'OFFER_SUBMITTED' && (
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-black text-[10px] uppercase tracking-wider transition-all cursor-pointer shadow flex items-center gap-1"
            >
              <span>{t('OK_CLOSE')}</span>
              <Check className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
