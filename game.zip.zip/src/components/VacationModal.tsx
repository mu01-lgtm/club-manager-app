import React, { useState } from 'react';
import { Calendar, Sun, Clock, AlertCircle, X, Play, Settings, CheckCircle2, ShieldAlert } from 'lucide-react';
import { useTranslation } from '../utils/i18n';

export type VacationOfferPolicy =
  | 'NONE'
  | 'REJECT_TRANSFERS'
  | 'REJECT_LOANS'
  | 'REJECT_ALL'
  | 'ACCEPT_LOAN_LISTED_ONLY'
  | 'ACCEPT_TRANSFER_LISTED_ONLY';

interface VacationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartVacation: (days: number) => void;
  vacationPolicy: VacationOfferPolicy;
  onUpdateVacationPolicy: (policy: VacationOfferPolicy) => void;
}

export const VacationModal: React.FC<VacationModalProps> = ({
  isOpen,
  onClose,
  onStartVacation,
  vacationPolicy,
  onUpdateVacationPolicy,
}) => {
  const { t } = useTranslation();
  const [selectedOption, setSelectedOption] = useState<number>(7); // Default 1 week
  const [showSettings, setShowSettings] = useState<boolean>(false);

  if (!isOpen) return null;

  const policyOptions: { id: VacationOfferPolicy; title: string; desc: string; badge: string; badgeColor: string }[] = [
    {
      id: 'NONE',
      title: t('VACATION_POLICY_NONE_TITLE'),
      desc: t('VACATION_POLICY_NONE_DESC'),
      badge: t('VACATION_POLICY_NONE_BADGE'),
      badgeColor: 'bg-slate-800 text-slate-300 border-slate-600'
    },
    {
      id: 'REJECT_TRANSFERS',
      title: t('VACATION_POLICY_REJECT_TRANSFERS_TITLE'),
      desc: t('VACATION_POLICY_REJECT_TRANSFERS_DESC'),
      badge: t('VACATION_POLICY_REJECT_TRANSFERS_BADGE'),
      badgeColor: 'bg-rose-950/80 text-rose-300 border-rose-600/50'
    },
    {
      id: 'REJECT_LOANS',
      title: t('VACATION_POLICY_REJECT_LOANS_TITLE'),
      desc: t('VACATION_POLICY_REJECT_LOANS_DESC'),
      badge: t('VACATION_POLICY_REJECT_LOANS_BADGE'),
      badgeColor: 'bg-amber-950/80 text-amber-300 border-amber-600/50'
    },
    {
      id: 'REJECT_ALL',
      title: t('VACATION_POLICY_REJECT_ALL_TITLE'),
      desc: t('VACATION_POLICY_REJECT_ALL_DESC'),
      badge: t('VACATION_POLICY_REJECT_ALL_BADGE'),
      badgeColor: 'bg-red-950 text-red-300 border-red-500'
    },
    {
      id: 'ACCEPT_LOAN_LISTED_ONLY',
      title: t('VACATION_POLICY_ACCEPT_LOAN_TITLE'),
      desc: t('VACATION_POLICY_ACCEPT_LOAN_DESC'),
      badge: t('VACATION_POLICY_ACCEPT_LOAN_BADGE'),
      badgeColor: 'bg-sky-950 text-sky-300 border-sky-500'
    },
    {
      id: 'ACCEPT_TRANSFER_LISTED_ONLY',
      title: t('VACATION_POLICY_ACCEPT_TRANSFER_TITLE'),
      desc: t('VACATION_POLICY_ACCEPT_TRANSFER_DESC'),
      badge: t('VACATION_POLICY_ACCEPT_TRANSFER_BADGE'),
      badgeColor: 'bg-emerald-950 text-emerald-300 border-emerald-500'
    }
  ];

  const options = [
    {
      id: 1,
      days: 1,
      title: t('VACATION_1_DAY_TITLE'),
      desc: t('VACATION_1_DAY_DESC'),
      icon: Clock,
      color: 'from-blue-600 to-indigo-600',
    },
    {
      id: 7,
      days: 7,
      title: t('VACATION_1_WEEK_TITLE'),
      desc: t('VACATION_1_WEEK_DESC'),
      icon: Calendar,
      color: 'from-purple-600 to-pink-600',
    },
    {
      id: 30,
      days: 30,
      title: t('VACATION_1_MONTH_TITLE'),
      desc: t('VACATION_1_MONTH_DESC'),
      icon: Sun,
      color: 'from-amber-600 to-orange-600',
    },
    {
      id: -1,
      days: -1,
      title: t('VACATION_UNLIMITED_TITLE'),
      desc: t('VACATION_UNLIMITED_DESC'),
      icon: Play,
      color: 'from-emerald-600 to-teal-600',
    },
  ];

  const activePolicyObj = policyOptions.find(p => p.id === vacationPolicy) || policyOptions[0];

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-3 animate-fade-in">
      <div className="bg-gradient-to-b from-[#1c1836] via-[#15112a] to-[#0f0c21] border border-[#392b63] rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 border-b border-[#2e2352] flex items-center justify-between bg-[#1f193d]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/20 text-amber-300 rounded-xl border border-amber-500/40 text-xl">
              🌴
            </div>
            <div>
              <h2 className="text-base font-black text-white">{t('VACATION_CENTER_TITLE')}</h2>
              <p className="text-[11px] text-slate-300">{t('VACATION_CENTER_SUBTITLE')}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowSettings(!showSettings)}
              className={`p-2 rounded-xl border font-bold text-xs flex items-center justify-center transition-all cursor-pointer ${
                showSettings || vacationPolicy !== 'NONE'
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-md'
                  : 'bg-[#181230] border-[#312554] text-slate-300 hover:text-white'
              }`}
              title={t('VACATION_TRANSFER_SETTINGS')}
            >
              <Settings className={`w-4 h-4 ${showSettings ? 'rotate-90 text-amber-300' : ''} transition-transform`} />
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-3 custom-scrollbar flex-1">
          {/* Active Policy Status Banner */}
          <div className="bg-[#181333] border border-[#37285e] p-3 rounded-xl flex items-center justify-between gap-2 shadow-inner">
            <div className="flex items-center gap-2 min-w-0">
              <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
              <div className="min-w-0">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">{t('ACTIVE_TRANSFER_POLICY')}</span>
                <span className="text-xs font-black text-white truncate block">{activePolicyObj.title}</span>
              </div>
            </div>
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="text-[10px] font-black text-amber-400 hover:text-amber-300 underline shrink-0 cursor-pointer"
            >
              {showSettings ? t('CLOSE_SETTINGS') : t('CONFIGURE_SETTINGS')}
            </button>
          </div>

          {/* Settings Drawer / Panel */}
          {showSettings && (
            <div className="bg-[#120e28] border-2 border-amber-500/40 p-3.5 rounded-2xl space-y-2.5 animate-fade-in shadow-xl">
              <div className="flex items-center justify-between border-b border-[#2d224d] pb-2">
                <div className="flex items-center gap-1.5 text-amber-300 font-black text-xs uppercase tracking-wider">
                  <Settings className="w-4 h-4" />
                  <span>⚙️ {t('VACATION_TRANSFER_SETTINGS')}</span>
                </div>
                <span className="text-[10px] text-slate-400">{t('CHOOSE_PREFERENCE')}</span>
              </div>

              <div className="space-y-2">
                {policyOptions.map((po) => {
                  const isSelected = vacationPolicy === po.id;
                  return (
                    <button
                      key={po.id}
                      type="button"
                      onClick={() => {
                        onUpdateVacationPolicy(po.id);
                      }}
                      className={`w-full p-2.5 rounded-xl border text-left transition-all flex items-start justify-between gap-2.5 cursor-pointer ${
                        isSelected
                          ? 'bg-amber-500/10 border-amber-400 ring-1 ring-amber-400/60 shadow-md'
                          : 'bg-[#181335] border-[#2c204d] hover:border-purple-500/50 text-slate-300'
                      }`}
                    >
                      <div className="flex items-start gap-2 min-w-0">
                        <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                          isSelected ? 'border-amber-400 bg-amber-400 text-slate-950' : 'border-slate-600 bg-slate-900'
                        }`}>
                          {isSelected && <CheckCircle2 className="w-3.5 h-3.5 fill-current" />}
                        </div>
                        <div className="min-w-0">
                          <h5 className="font-extrabold text-xs text-white leading-tight">{po.title}</h5>
                          <p className="text-[10px] text-slate-400 mt-0.5 leading-snug">{po.desc}</p>
                        </div>
                      </div>

                      <span className={`px-2 py-0.5 rounded-md border text-[9px] font-black shrink-0 ${po.badgeColor}`}>
                        {po.badge}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div className="bg-purple-950/40 border border-purple-500/30 p-3 rounded-xl flex items-start gap-2.5 text-xs text-purple-200">
            <AlertCircle className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
            <p className="leading-snug">
              {t('VACATION_NOTICE')}
            </p>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-black text-amber-300 uppercase tracking-wider block">
              {t('SELECT_VACATION_DURATION')}
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {options.map((opt) => {
                const isSelected = selectedOption === opt.days;
                const Icon = opt.icon;

                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setSelectedOption(opt.days)}
                    className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between relative overflow-hidden group cursor-pointer ${
                      isSelected
                        ? 'bg-gradient-to-br from-[#2a1d4f] to-[#1d143b] border-amber-400 ring-2 ring-amber-400/50 shadow-lg'
                        : 'bg-[#141029] border-[#291e4a] hover:border-purple-500/50 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <Icon className={`w-5 h-5 ${isSelected ? 'text-amber-300' : 'text-slate-400'}`} />
                    </div>

                    <div>
                      <h4 className="font-extrabold text-xs sm:text-sm text-white mb-0.5">
                        {opt.title}
                      </h4>
                      <p className="text-[10px] text-slate-400 leading-tight">
                        {opt.desc}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-[#2e2352] bg-[#15102a] flex items-center justify-between gap-3 shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white transition-colors"
          >
            {t('CANCEL')}
          </button>

          <button
            onClick={() => onStartVacation(selectedOption)}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs uppercase tracking-wider transition-all shadow-lg active:scale-95 flex items-center gap-1.5"
          >
            🌴 {t('START_VACATION')} &rarr;
          </button>
        </div>

      </div>
    </div>
  );
};


