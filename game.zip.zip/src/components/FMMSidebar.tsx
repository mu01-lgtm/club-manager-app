import React from 'react';
import { TabType } from './Navigation';
import { Team, GameMode } from '../types';
import { useTranslation } from '../utils/i18n';
import { TeamBadge } from './TeamBadge';
import {
  Mail,
  Home,
  Newspaper,
  Globe,
  Zap,
  Dumbbell,
  CalendarDays,
  UserCheck
} from 'lucide-react';

interface FMMSidebarProps {
  activeTab: TabType;
  onChangeTab: (tab: TabType) => void;
  currentTeam: Team;
  gameMode?: GameMode;
  unreadCount?: number;
  hasUnreadNews?: boolean;
  onOpenInboxModal?: () => void;
  onOpenMainMenu?: () => void;
}

export const FMMSidebar: React.FC<FMMSidebarProps> = ({
  activeTab,
  onChangeTab,
  currentTeam,
  gameMode = 'MANAGER',
  unreadCount = 2,
  hasUnreadNews = true,
  onOpenInboxModal,
  onOpenMainMenu
}) => {
  const { t } = useTranslation();
  const isPlayerMode = gameMode === 'PLAYER_CAREER';

  return (
    <aside className="w-14 sm:w-16 bg-[#131120] border-r border-[#27213d] flex flex-col items-center justify-between py-3 z-30 shrink-0 select-none h-full">
      
      {/* Top Main Navigation Icons */}
      <div className="flex flex-col items-center gap-2 sm:gap-2.5 w-full px-1 pt-2 overflow-y-auto no-scrollbar">
        
        {/* 1. Inbox / Messages Icon */}
        <button
          onClick={() => {
            if (onOpenInboxModal) onOpenInboxModal();
            else onChangeTab('HOME');
          }}
          title={t('INBOX')}
          className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-[#1d1832] hover:bg-[#2c244b] text-slate-300 hover:text-white flex items-center justify-center transition-all border border-[#2d254a] active:scale-95 shrink-0 my-0.5"
        >
          <Mail className="w-5 h-5 text-amber-400" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 min-w-[18px] h-4.5 px-1 rounded-full bg-rose-500 text-white text-[9.5px] font-black flex items-center justify-center border-2 border-[#131120] shadow-md z-20 leading-none">
              {unreadCount}
            </span>
          )}
        </button>

        {/* 2. Home / Overview */}
        <button
          onClick={() => {
            if (onOpenMainMenu) {
              if (window.confirm(t('CONFIRM_MAIN_MENU'))) {
                onOpenMainMenu();
              } else {
                onChangeTab('HOME');
              }
            } else {
              onChangeTab('HOME');
            }
          }}
          title={t('HOME')}
          className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl flex items-center justify-center transition-all border active:scale-95 ${
            activeTab === 'HOME'
              ? 'bg-[#7b2cbf] text-white border-[#9d4edd] shadow-lg shadow-purple-500/30'
              : 'bg-[#1d1832] hover:bg-[#2c244b] text-slate-400 hover:text-white border-[#2d254a]'
          }`}
        >
          <Home className="w-5 h-5" />
        </button>

        {/* 5. Son Haberler (News) - Placed under Home as requested */}
        <button
          onClick={() => onChangeTab('NEWS')}
          title={t('NEWS')}
          className={`relative w-10 h-10 sm:w-11 sm:h-11 rounded-xl flex items-center justify-center transition-all border active:scale-95 ${
            activeTab === 'NEWS'
              ? 'bg-[#7b2cbf] text-white border-[#9d4edd] shadow-lg shadow-purple-500/30'
              : 'bg-[#1d1832] hover:bg-[#2c244b] text-slate-400 hover:text-white border-[#2d254a]'
          }`}
        >
          <Newspaper className="w-5 h-5 text-amber-300" />
          {hasUnreadNews && (
            <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
          )}
        </button>

        {/* 6. Manager Tactics Pitch / Squad logo - Placed under News as requested */}
        {!isPlayerMode && (
          <button
            onClick={() => onChangeTab('TACTICS')}
            title={t('TACTICS')}
            className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl flex items-center justify-center transition-all border active:scale-95 ${
              activeTab === 'TACTICS'
                ? 'bg-[#7b2cbf] text-white border-[#9d4edd] shadow-lg shadow-purple-500/30'
                : 'bg-[#1d1832] hover:bg-[#2c244b] text-slate-400 hover:text-white border-[#2d254a]'
            }`}
          >
            <TeamBadge team={currentTeam} size="sm" />
          </button>
        )}

        {/* Player Career Dedicated Button */}
        {isPlayerMode && (
          <button
            onClick={() => onChangeTab('MY_PLAYER')}
            title={t('MY_PLAYER')}
            className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl flex items-center justify-center transition-all border active:scale-95 ${
              activeTab === 'MY_PLAYER'
                ? 'bg-sky-600 text-white border-sky-400 shadow-lg shadow-sky-500/30'
                : 'bg-[#1d1832] hover:bg-[#2c244b] text-sky-300 hover:text-white border-[#2d254a]'
            }`}
          >
            <UserCheck className="w-5 h-5" />
          </button>
        )}

        {/* 3. Personal Training / Antrenman */}
        <button
          onClick={() => onChangeTab(isPlayerMode ? 'MY_PLAYER' : 'TRAINING')}
          title={t('TRAINING')}
          className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl flex items-center justify-center transition-all border active:scale-95 ${
            activeTab === 'TRAINING' || (isPlayerMode && activeTab === 'MY_PLAYER')
              ? 'bg-emerald-600 text-white border-emerald-400 shadow-lg shadow-emerald-500/30'
              : 'bg-[#1d1832] hover:bg-[#2c244b] text-slate-400 hover:text-white border-[#2d254a]'
          }`}
        >
          <Dumbbell className="w-5 h-5 text-emerald-400" />
        </button>

        {/* 4. Transfer Request / Transfer Pazarı */}
        <button
          onClick={() => onChangeTab(isPlayerMode ? 'MY_PLAYER' : 'TRANSFERS')}
          title={t('TRANSFERS')}
          className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl flex items-center justify-center transition-all border active:scale-95 ${
            activeTab === 'TRANSFERS'
              ? 'bg-amber-600 text-white border-amber-400 shadow-lg shadow-amber-500/30'
              : 'bg-[#1d1832] hover:bg-[#2c244b] text-slate-400 hover:text-white border-[#2d254a]'
          }`}
        >
          <Zap className="w-5 h-5 text-yellow-400" />
        </button>

        {/* 7. Standings / League Table */}
        <button
          onClick={() => onChangeTab('STANDINGS')}
          title={t('STANDINGS')}
          className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl flex items-center justify-center transition-all border active:scale-95 ${
            activeTab === 'STANDINGS'
              ? 'bg-[#7b2cbf] text-white border-[#9d4edd] shadow-lg shadow-purple-500/30'
              : 'bg-[#1d1832] hover:bg-[#2c244b] text-slate-400 hover:text-white border-[#2d254a]'
          }`}
        >
          <Globe className="w-5 h-5 text-sky-400" />
        </button>

        {/* 8. Fixtures Schedule */}
        <button
          onClick={() => onChangeTab('FIXTURES')}
          title={t('FIXTURES')}
          className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl flex items-center justify-center transition-all border active:scale-95 ${
            activeTab === 'FIXTURES'
              ? 'bg-[#7b2cbf] text-white border-[#9d4edd] shadow-lg shadow-purple-500/30'
              : 'bg-[#1d1832] hover:bg-[#2c244b] text-slate-400 hover:text-white border-[#2d254a]'
          }`}
        >
          <CalendarDays className="w-5 h-5 text-purple-300" />
        </button>

      </div>

    </aside>
  );
};
