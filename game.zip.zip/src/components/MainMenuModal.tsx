import React, { useState, useEffect } from 'react';
import { 
  FolderOpen, Settings, Shield, Star, Volume2, VolumeX, Sparkles, 
  ClipboardList, Globe, ChevronRight, ArrowLeftRight, Trophy,
  User, ChevronDown, Power, Check, Calendar, Clock, BarChart2,
  PieChart, Mail, ShoppingCart, Lock, Zap, X
} from 'lucide-react';
import { SavedGameState } from './CareerStartModal';
import { PlayersAndManagerGroup } from './PlayersAndManagerGroup';
import { DevPanelModal, DevImageConfig, getStoredDevConfig, isDevAuthenticated } from './DevPanelModal';
import { DevSecurityGateModal } from './DevSecurityGateModal';
import { loadDevConfigFromStorage } from '../utils/devStorage';
import { ComingSoonModal } from './ComingSoonModal';
import { LanguageModal } from './LanguageModal';
import { useTranslation, SUPPORTED_LANGUAGES } from '../utils/i18n';
import { soundFx } from '../utils/soundEffects';
import { INITIAL_TEAMS } from '../data/initialData';
import { INTERNATIONAL_TEAMS } from './WorldScoutModal';

interface MainMenuModalProps {
  onStartNewGame: () => void;
  onContinueGame: () => void;
  onOpenSavedGames?: () => void;
  hasActiveGame: boolean;
  activeSaveInfo?: SavedGameState | null;
  onResetData?: () => void;
  onOpenWorldScout?: () => void;
}

export const MainMenuModal: React.FC<MainMenuModalProps> = ({
  onStartNewGame,
  onContinueGame,
  onOpenSavedGames,
  hasActiveGame,
  activeSaveInfo,
  onResetData,
  onOpenWorldScout,
}) => {
  const { language, t } = useTranslation();
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showDevModal, setShowDevModal] = useState(false);
  const [showSecurityGate, setShowSecurityGate] = useState(false);
  const [showLanguageModal, setShowLanguageModal] = useState(false);
  const [comingSoonType, setComingSoonType] = useState<'ONLINE' | 'TOURNAMENT' | 'CREATE_CLUB' | 'CLOUD_PROFILE' | null>(null);
  const [devConfig, setDevConfig] = useState<DevImageConfig>(getStoredDevConfig());
  const [soundEnabled, setSoundEnabled] = useState(soundFx.isEnabled());
  const [difficulty, setDifficulty] = useState('NORMAL');
  const [cloudConnected, setCloudConnected] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Dynamic user stats
  const [playtimeSecs, setPlaytimeSecs] = useState<number>(0);
  const [trophies, setTrophies] = useState<number>(0);
  const [lastTeam, setLastTeam] = useState<string>('');

  useEffect(() => {
    const updateStats = () => {
      const savedSecs = parseInt(localStorage.getItem('fm_total_playtime_seconds') || '0', 10);
      const savedTrophies = parseInt(localStorage.getItem('fm_total_trophies') || '0', 10);
      const savedTeam = localStorage.getItem('fm_last_played_team') || activeSaveInfo?.teamName || '';

      setPlaytimeSecs(savedSecs);
      setTrophies(savedTrophies);
      setLastTeam(savedTeam);
    };

    updateStats();
    const interval = setInterval(updateStats, 1000);
    return () => clearInterval(interval);
  }, [activeSaveInfo]);

  // Keyboard shortcut listener (Ctrl + Shift + D or Ctrl + Alt + M) - EXCLUSIVE ACCESS METHOD FOR DEV PANEL
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.shiftKey || e.altKey) && (e.key === 'D' || e.key === 'd' || e.key === 'M' || e.key === 'm')) {
        e.preventDefault();
        handleTriggerDevPanel();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleTriggerDevPanel = () => {
    try {
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate([40, 50, 40]);
      }
    } catch {}

    if (isDevAuthenticated()) {
      setShowDevModal(true);
    } else {
      setShowSecurityGate(true);
    }
  };

  const formatPlaytime = (seconds: number) => {
    if (seconds <= 0) return { primary: `0 ${t('HOURS')}`, secondary: `0 ${t('MINUTES')}` };
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    if (h > 0) {
      return { primary: `${h} ${t('HOURS')}`, secondary: `${m} ${t('MINUTES')}` };
    }
    return { primary: `0 ${t('HOURS')}`, secondary: `${m} ${t('MINUTES')}` };
  };

  const hasTeam = Boolean(
    lastTeam && 
    lastTeam !== t('NO_CLUB') && 
    lastTeam !== 'Yok' && 
    lastTeam !== '-' && 
    lastTeam !== 'Kulüp Yok'
  );

  const getTeamStarRating = (teamName: string) => {
    const found = INITIAL_TEAMS.find(t => t.name.toLowerCase() === teamName.toLowerCase()) ||
                  INTERNATIONAL_TEAMS.find(t => t.name.toLowerCase() === teamName.toLowerCase());
    if (!found) return 3;
    if (found.overall >= 80) return 5;
    if (found.overall >= 76) return 4;
    if (found.overall >= 70) return 3;
    return 2;
  };

  const teamStars = hasTeam ? getTeamStarRating(lastTeam) : 0;

  useEffect(() => {
    loadDevConfigFromStorage().then((cfg) => {
      if (cfg) {
        setDevConfig(cfg);
      }
    });
  }, []);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  return (
    <div className="fixed inset-0 top-0 left-0 right-0 bottom-0 z-[9990] text-white select-none w-screen h-screen h-[100dvh] overflow-hidden flex flex-col justify-between p-2 sm:p-4 font-sans bg-[#030712]">
      
      {/* FULLSCREEN BACKGROUND PLAYER & MANAGER IMAGE LAYER (TAM EKRAN ARKA PLAN) */}
      <div className="fixed inset-0 w-full h-full pointer-events-none z-0 overflow-hidden">
        <PlayersAndManagerGroup className="w-full h-full" config={devConfig} />
        
        {/* Optional Stadium BG overlay if configured */}
        {devConfig.stadiumBgUrl && (
          <div 
            className="absolute inset-0 bg-cover bg-center opacity-30 mix-blend-overlay pointer-events-none"
            style={{ backgroundImage: `url('${devConfig.stadiumBgUrl}')` }}
          />
        )}

        {/* Dynamic stadium glow */}
        {devConfig.glowColor !== 'none' && (
          <div 
            className={`absolute bottom-0 left-1/2 -translate-x-1/2 w-full h-32 blur-3xl rounded-full pointer-events-none ${
              devConfig.glowColor === 'purple'
                ? 'bg-purple-600/30'
                : devConfig.glowColor === 'amber'
                ? 'bg-amber-500/25'
                : devConfig.glowColor === 'emerald'
                ? 'bg-emerald-500/25'
                : devConfig.glowColor === 'rose'
                ? 'bg-rose-500/25'
                : 'bg-sky-500/20'
            }`} 
          />
        )}
      </div>

      {/* Subtle ambient lighting vignette overlay to enhance text readability */}
      <div className="fixed inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/50 pointer-events-none z-10" />

      {/* TOP HEADER BAR */}
      <div className="relative z-30 flex items-center justify-between w-full max-w-7xl mx-auto shrink-0 pt-1">
        
        {/* CM 27 OFFICIAL LOGO AREA */}
        <div 
          className="flex items-center gap-2.5 sm:gap-3 select-none"
        >
          {/* CM Shield Monogram Badge */}
          <div className="relative">
            <div className="px-2.5 py-1 bg-gradient-to-b from-[#1c0e38] via-[#0d071a] to-[#05020a] rounded-xl border border-purple-500/50 shadow-[0_0_20px_rgba(168,85,247,0.35)] flex items-center gap-1">
              <span className="text-xl sm:text-2xl font-black text-white italic tracking-tighter">C</span>
              <span className="text-xl sm:text-2xl font-black text-purple-500 italic tracking-tighter drop-shadow-[0_0_15px_rgba(168,85,247,0.8)]">M</span>
              <span className="text-[10px] font-black text-purple-300 bg-purple-950/80 px-1 py-0.2 rounded border border-purple-700/50 ml-0.5">27</span>
            </div>
          </div>

          {/* Title Branding (Yan Yana: CLUB MANAGER 27, Sub: BUILD. MANAGE. WIN.) */}
          <div className="text-left leading-tight">
            <h1 className="text-base sm:text-lg lg:text-xl font-black italic tracking-tight text-white uppercase drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)] font-sans whitespace-nowrap flex items-center gap-1.5">
              <span className="text-white">CLUB</span>
              <span className="text-purple-400">MANAGER</span>
              <span className="text-white font-extrabold text-xs sm:text-sm bg-purple-950/90 px-1.5 py-0.2 rounded-md border border-purple-500/50">27</span>
            </h1>
            <p className="text-[8px] sm:text-[9px] font-black text-purple-300 tracking-[0.2em] uppercase mt-0.5 drop-shadow flex items-center gap-1">
              <span>BUILD. MANAGE. WIN.</span>
            </p>
          </div>
        </div>

        {/* TOP RIGHT NAVIGATION TOOLBAR (AYARLAR, DİL, GİRİŞ YAP) */}
        <div className="flex items-center gap-2 text-xs font-black z-40">

          {/* AYARLAR */}
          <button
            onClick={() => setShowSettingsModal(true)}
            className="flex items-center gap-1.5 text-slate-200 hover:text-white uppercase tracking-wider transition-colors py-1.5 px-3 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 text-[11px] shadow active:scale-95"
          >
            <Settings className="w-4 h-4 text-sky-400" />
            <span className="hidden sm:inline">{t('SETTINGS')}</span>
          </button>

          {/* DİL SEÇİMİ BUTONU (MODERN TACTICAL DİZİLİŞ STİLİ MODAL AÇAR) */}
          <button
            onClick={() => setShowLanguageModal(true)}
            className="flex items-center gap-1.5 text-purple-200 hover:text-white uppercase tracking-wider py-1.5 px-3 rounded-xl bg-gradient-to-r from-[#21163e] to-[#161228] hover:from-[#2e1d57] hover:to-[#1f183d] border border-purple-500/50 hover:border-purple-400 transition-all text-[11px] font-black shadow-lg shadow-purple-950/50 active:scale-95"
            title="Oyun Dilini Değiştir / Select Language"
          >
            <Globe className="w-4 h-4 text-sky-400 shrink-0 animate-spin-slow" />
            <span>{t('LANGUAGE')}: {language}</span>
          </button>

          {/* GİRİŞ YAP / CLOUD CONNECT PILL */}
          <button
            onClick={() => setComingSoonType('CLOUD_PROFILE')}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-purple-500/50 bg-purple-950/80 hover:bg-purple-900 text-white transition-all shadow-md active:scale-95"
          >
            <div className="p-1 rounded-full bg-purple-800/80 border border-purple-400/40">
              <User className="w-3.5 h-3.5 text-purple-200" />
            </div>
            <div className="text-left leading-tight hidden sm:block">
              <span className="block text-[10px] font-black uppercase">
                {t('LOGIN')}
              </span>
              <span className="block text-[8px] text-purple-300 font-medium">
                {t('CONNECT_CLOUD')}
              </span>
            </div>
          </button>

        </div>

      </div>

      {/* MAIN CENTER CONTENT AREA */}
      <div className="relative z-20 w-full max-w-7xl mx-auto flex flex-1 items-center justify-between gap-2 sm:gap-4 my-auto py-1">
        
        {/* Left spacer for visual balance */}
        <div className="flex-1 pointer-events-none" />

        {/* RIGHT SIDE MAIN SLANTED MENU BUTTONS STACK (6 ADET MENÜ KART - Z-50 İLE HER ZAMAN ÜSTTE) */}
        <div className="relative z-50 w-[195px] min-[400px]:w-[225px] sm:w-[270px] md:w-[300px] lg:w-[320px] space-y-1.5 sm:space-y-2 shrink-0 ml-auto mr-0 sm:mr-2">
          
          {/* Card 1: YENİ KARİYER (Mavi) */}
          <div
            onClick={onStartNewGame}
            className="transform -skew-x-12 bg-gradient-to-r from-blue-700/90 via-blue-800/90 to-sky-950/90 hover:from-blue-600 hover:via-blue-700 hover:to-sky-900 border border-blue-400/80 hover:border-blue-300 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg shadow-[0_4px_16px_rgba(37,99,235,0.4)] cursor-pointer transition-all duration-200 group active:scale-[0.99] relative overflow-hidden backdrop-blur-sm"
          >
            <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-blue-300 to-transparent opacity-90" />
            
            <div className="transform skew-x-12 flex items-center justify-between">
              <div className="flex items-center gap-2 sm:gap-2.5">
                <div className="p-1.5 rounded bg-gradient-to-br from-blue-500 to-blue-900 border border-blue-300/60 text-white group-hover:scale-110 transition-all shrink-0 shadow">
                  <ClipboardList className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                
                <div className="text-left">
                  <span className="block text-[11px] min-[400px]:text-xs sm:text-sm font-black text-white tracking-wider uppercase group-hover:text-sky-200 transition-colors drop-shadow leading-tight">
                    {t('NEW_CAREER')}
                  </span>
                  <span className="text-[8px] sm:text-[9px] text-blue-200/90 font-bold block leading-none mt-0.5">
                    {t('NEW_CAREER_DESC')}
                  </span>
                </div>
              </div>

              <ChevronRight className="w-4 h-4 text-blue-300 group-hover:translate-x-1 transition-transform group-hover:text-white" />
            </div>
          </div>

          {/* Card 2: KARİYERİ YÜKLE (Koyu Mavi - Kayıtlı Oyunlar Sayfasını Açar) */}
          <div
            onClick={() => {
              if (onOpenSavedGames) {
                onOpenSavedGames();
              } else if (hasActiveGame) {
                onContinueGame();
              } else {
                onStartNewGame();
              }
            }}
            className="transform -skew-x-12 bg-gradient-to-r from-[#11223b]/95 via-[#0d1828]/95 to-[#070e19]/95 hover:from-[#1a3359] hover:via-[#13253d] hover:to-[#0d1828] border border-sky-400/80 hover:border-sky-300 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg shadow-[0_4px_14px_rgba(0,150,255,0.3)] cursor-pointer transition-all duration-200 group active:scale-[0.99] relative overflow-hidden backdrop-blur-sm"
          >
            <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-sky-300 to-transparent opacity-80" />

            <div className="transform skew-x-12 flex items-center justify-between">
              <div className="flex items-center gap-2 sm:gap-2.5">
                <div className="p-1.5 rounded bg-gradient-to-br from-[#1a2c42] to-[#09121f] border border-sky-400/60 text-sky-300 group-hover:text-amber-300 group-hover:scale-110 transition-all shrink-0 shadow">
                  <FolderOpen className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                
                <div className="text-left">
                  <span className="block text-[11px] min-[400px]:text-xs sm:text-sm font-black text-white tracking-wider uppercase group-hover:text-sky-200 transition-colors drop-shadow leading-tight">
                    {t('LOAD_CAREER')}
                  </span>
                  <span className="text-[8px] sm:text-[9px] text-sky-300/80 font-bold block leading-none mt-0.5">
                    {t('LOAD_CAREER_DESC')}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1">
                {hasActiveGame && (
                  <span className="text-[7px] font-black bg-emerald-500 text-slate-950 px-1 py-0.2 rounded uppercase tracking-wider transform -skew-x-12 inline-block shadow">
                    {t('SAVE_EXISTS')}
                  </span>
                )}
                <ChevronRight className="w-4 h-4 text-sky-400 group-hover:translate-x-1 transition-transform group-hover:text-amber-300" />
              </div>
            </div>
          </div>

          {/* Card 3: ONLINE KARİYER (Mor, YENİ etiketli) */}
          <div
            onClick={() => setComingSoonType('ONLINE')}
            className="transform -skew-x-12 bg-gradient-to-r from-[#2a134a]/95 via-[#1c0c33]/95 to-[#0e061c]/95 hover:from-[#3c1b69] hover:via-[#271147] hover:to-[#1c0c33] border border-purple-500/80 hover:border-purple-300 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg shadow-[0_4px_16px_rgba(168,85,247,0.4)] cursor-pointer transition-all duration-200 group active:scale-[0.99] relative overflow-hidden backdrop-blur-sm"
          >
            <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-purple-400 to-transparent opacity-90" />

            <div className="transform skew-x-12 flex items-center justify-between">
              <div className="flex items-center gap-2 sm:gap-2.5">
                <div className="p-1.5 rounded bg-gradient-to-br from-purple-600 to-purple-950 border border-purple-400/60 text-purple-200 group-hover:text-amber-300 group-hover:scale-110 transition-all shrink-0 shadow">
                  <Globe className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                
                <div className="text-left">
                  <div className="flex items-center gap-1.5">
                    <span className="block text-[11px] min-[400px]:text-xs sm:text-sm font-black text-white tracking-wider uppercase group-hover:text-purple-200 transition-colors drop-shadow leading-tight">
                      {t('ONLINE_CAREER')}
                    </span>
                    <span className="text-[7px] font-black bg-amber-400 text-slate-950 px-1 py-0.2 rounded uppercase tracking-wider">
                      {t('NEW_BADGE')}
                    </span>
                  </div>
                  <span className="text-[8px] sm:text-[9px] text-purple-300/80 font-bold block leading-none mt-0.5">
                    {t('ONLINE_CAREER_DESC')}
                  </span>
                </div>
              </div>

              <ChevronRight className="w-4 h-4 text-purple-400 group-hover:translate-x-1 transition-transform group-hover:text-amber-300" />
            </div>
          </div>

          {/* Card 4: TURNUVALAR & KUPA (Koyu Bordo / Altın) */}
          <div
            onClick={() => setComingSoonType('TOURNAMENT')}
            className="transform -skew-x-12 bg-gradient-to-r from-[#2b101c]/95 via-[#1d0912]/95 to-[#0f0409]/95 hover:from-[#3e1728] hover:via-[#2b101c] hover:to-[#1d0912] border border-rose-500/80 hover:border-rose-300 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg shadow-[0_4px_16px_rgba(244,63,94,0.3)] cursor-pointer transition-all duration-200 group active:scale-[0.99] relative overflow-hidden backdrop-blur-sm"
          >
            <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-rose-400 to-transparent opacity-80" />

            <div className="transform skew-x-12 flex items-center justify-between">
              <div className="flex items-center gap-2 sm:gap-2.5">
                <div className="p-1.5 rounded bg-gradient-to-br from-rose-700 to-rose-950 border border-rose-400/60 text-amber-300 group-hover:scale-110 transition-all shrink-0 shadow">
                  <Trophy className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                
                <div className="text-left">
                  <span className="block text-[11px] min-[400px]:text-xs sm:text-sm font-black text-white tracking-wider uppercase group-hover:text-rose-200 transition-colors drop-shadow leading-tight">
                    {t('TOURNAMENTS_AND_CUPS')}
                  </span>
                  <span className="text-[8px] sm:text-[9px] text-rose-300/80 font-bold block leading-none mt-0.5">
                    {t('TOURNAMENTS_DESC')}
                  </span>
                </div>
              </div>

              <ChevronRight className="w-4 h-4 text-rose-400 group-hover:translate-x-1 transition-transform group-hover:text-amber-300" />
            </div>
          </div>

        </div>

      </div>

      {/* BOTTOM METRICS STATUS BAR */}
      <div className="relative z-30 flex items-center justify-between w-full max-w-7xl mx-auto px-1 sm:px-2 py-1.5 text-[10px] sm:text-xs text-slate-300 shrink-0 border-t border-purple-900/30 bg-[#06030c]/90 rounded-xl backdrop-blur-md">
        
        {/* Left: Oynama Süresi & Aktif Kulüp */}
        <div className="flex items-center gap-3 sm:gap-6">
          <div className="flex items-center gap-1.5 text-purple-200 font-bold">
            <Clock className="w-3.5 h-3.5 text-purple-400" />
            <span>{t('PLAYTIME')}: <strong className="text-white">{formatPlaytime(playtimeSecs).primary}</strong></span>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 text-purple-200 font-bold">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>{t('WON_TROPHIES')}: <strong className="text-amber-300">{trophies}</strong></span>
          </div>

          {hasTeam && (
            <div className="hidden md:flex items-center gap-1.5 text-purple-200 font-bold">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>{t('LAST_CLUB')}: <strong className="text-emerald-300">{lastTeam}</strong></span>
            </div>
          )}
        </div>

        {/* Right: Sound FX Toggle & Version */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              const newState = !soundEnabled;
              setSoundEnabled(newState);
              soundFx.setEnabled(newState);
              showToast(newState ? 'Sesler Açıldı' : 'Sesler Kapatıldı');
            }}
            className="flex items-center gap-1 text-purple-300 hover:text-white font-bold transition-colors"
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Ses: Açık</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5 text-slate-500" />
                <span className="hidden sm:inline">Ses: Kapalı</span>
              </>
            )}
          </button>

          {/* Version Tag */}
          <span className="text-purple-400/60 font-mono text-[9px] select-none py-1 px-1.5">
            CM 27 v2.7.0
          </span>
        </div>

      </div>

      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-14 left-1/2 -translate-x-1/2 z-[10030] bg-[#170c2e] border border-purple-500/80 px-4 py-2 rounded-xl text-xs font-bold text-white shadow-2xl shadow-purple-950 flex items-center gap-2 animate-fadeIn">
          <Sparkles className="w-4 h-4 text-purple-300 animate-spin" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* SETTINGS MODAL */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-[10005] flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-fadeIn select-none">
          <div className="relative w-full max-w-md bg-[#0e071e] border border-purple-500/50 rounded-2xl p-5 text-white space-y-4 shadow-2xl">
            
            <div className="flex items-center justify-between border-b border-purple-900/40 pb-3">
              <h3 className="text-sm font-black uppercase text-purple-300 flex items-center gap-2">
                <Settings className="w-4 h-4 text-purple-400" />
                {t('SETTINGS')}
              </h3>
              <button onClick={() => setShowSettingsModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Sound Toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-[#140b2a] border border-purple-900/30">
              <div className="flex items-center gap-2 text-xs font-bold">
                <Volume2 className="w-4 h-4 text-purple-300" />
                <span>Oyun İçi Sesler ve Efektler</span>
              </div>
              <input
                type="checkbox"
                checked={soundEnabled}
                onChange={(e) => {
                  setSoundEnabled(e.target.checked);
                  soundFx.setEnabled(e.target.checked);
                }}
                className="w-4 h-4 accent-purple-600 rounded cursor-pointer"
              />
            </div>

            {/* Difficulty */}
            <div className="p-3 rounded-xl bg-[#140b2a] border border-purple-900/30 space-y-2">
              <span className="block text-xs font-bold text-purple-200">Simülasyon Zorluğu</span>
              <div className="grid grid-cols-3 gap-2">
                {['KOLAY', 'NORMAL', 'ZOR'].map((diff) => (
                  <button
                    key={diff}
                    onClick={() => setDifficulty(diff)}
                    className={`py-1.5 rounded-lg text-xs font-black uppercase transition-all ${
                      difficulty === diff
                        ? 'bg-purple-600 text-white shadow'
                        : 'bg-[#090514] text-slate-400 hover:text-white'
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            </div>

            {/* Reset All Game Data */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-rose-950/40 border border-rose-600/30">
              <div>
                <span className="text-xs font-bold text-rose-300 block">Tüm Kayıtları Sıfırla</span>
                <span className="text-[9px] text-rose-400/80">Tüm kariyer kayıtlarını ve ayarları temizler</span>
              </div>
              <button
                onClick={() => {
                  if (window.confirm('Tüm kariyer kayıtlarınız silinecektir. Devam etmek istiyor musunuz?')) {
                    localStorage.clear();
                    if (onResetData) onResetData();
                    else window.location.reload();
                  }
                }}
                className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs flex items-center gap-1"
              >
                <Power className="w-3.5 h-3.5" />
                SIFIRLA
              </button>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setShowSettingsModal(false)}
                className="w-full sm:w-auto px-6 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs rounded-xl uppercase tracking-wider shadow-xl"
              >
                KAYDET VE KAPAT
              </button>
            </div>

          </div>
        </div>
      )}

      {/* DEV SECURITY PIN GATE MODAL (Sadece Murat Girişi) */}
      <DevSecurityGateModal
        isOpen={showSecurityGate}
        onClose={() => setShowSecurityGate(false)}
        onSuccess={() => {
          setShowSecurityGate(false);
          setShowDevModal(true);
        }}
      />

      {/* DEV PANEL MODAL */}
      <DevPanelModal
        isOpen={showDevModal}
        onClose={() => setShowDevModal(false)}
        config={devConfig}
        onUpdateConfig={(newCfg) => setDevConfig(newCfg)}
        showToast={showToast}
      />

      {/* COMING SOON FEATURE MODAL */}
      <ComingSoonModal
        isOpen={!!comingSoonType}
        onClose={() => setComingSoonType(null)}
        type={comingSoonType}
      />

      {/* LANGUAGE SELECTION MODAL */}
      <LanguageModal
        isOpen={showLanguageModal}
        onClose={() => setShowLanguageModal(false)}
      />

    </div>
  );
};
