import React from 'react';
import { Square, Calendar, Trophy, Zap } from 'lucide-react';
import { useTranslation } from '../utils/i18n';

interface VacationOverlayProps {
  isActive: boolean;
  totalDays: number;
  daysElapsed: number;
  matchesPlayed: number;
  currentDayName: string;
  currentWeek: number;
  currentSeason?: number;
  currentDayIndex?: number;
  onStopVacation: () => void;
}

export const VacationOverlay: React.FC<VacationOverlayProps> = ({
  isActive,
  totalDays,
  daysElapsed,
  matchesPlayed,
  currentDayName,
  currentWeek,
  currentSeason = 1,
  currentDayIndex = 0,
  onStopVacation,
}) => {
  const { t } = useTranslation();

  if (!isActive) return null;

  const isInfinite = totalDays === -1;

  // Calculate formatted date
  const getSimulatedDate = (season: number, week: number, dayIndex: number) => {
    const baseDate = new Date(2026, 7, 10); // 10 August 2026
    const daysToAdd = ((season - 1) * 38 + (week - 1)) * 7 + dayIndex;
    const matchDate = new Date(baseDate.getTime() + daysToAdd * 24 * 60 * 60 * 1000);
    
    const months = [
      t('JANUARY'), t('FEBRUARY'), t('MARCH'), t('APRIL'), t('MAY'), t('JUNE'),
      t('JULY'), t('AUGUST'), t('SEPTEMBER'), t('OCTOBER'), t('NOVEMBER'), t('DECEMBER')
    ];
    
    return `${matchDate.getDate()} ${months[matchDate.getMonth()]} ${matchDate.getFullYear()}`;
  };

  const formattedDate = getSimulatedDate(currentSeason, currentWeek, currentDayIndex);

  return (
    <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-xl animate-fade-in pointer-events-auto">
      <div className="bg-gradient-to-r from-[#1f153a] via-[#2d1b54] to-[#1f153a] border-2 border-amber-400/80 rounded-2xl p-3 sm:p-4 shadow-2xl backdrop-blur-xl flex flex-col gap-2">
        
        {/* Header Row */}
        <div className="flex items-center justify-between gap-2 border-b border-[#432d73] pb-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-300 text-lg animate-pulse">
              🌴
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-xs sm:text-sm text-white tracking-wide uppercase">
                  {t('ON_VACATION_TITLE')}
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              </div>
              <p className="text-[10px] text-amber-300 font-semibold">
                {t('CALENDAR_PROGRESSING')}
              </p>
            </div>
          </div>

          <button
            onClick={onStopVacation}
            className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs uppercase tracking-wider transition-all shadow-md active:scale-95 flex items-center gap-1 shrink-0 cursor-pointer"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            {t('END_VACATION_BTN')}
          </button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-2 text-center pt-1">
          <div className="bg-[#140d29] p-1.5 sm:p-2 rounded-xl border border-[#37245c]">
            <span className="text-[9px] text-slate-400 font-bold uppercase block">{t('DATE_LABEL')}</span>
            <span className="font-extrabold text-xs text-amber-300 flex items-center justify-center gap-1 mt-0.5">
              <Calendar className="w-3 h-3 text-amber-400 shrink-0" />
              {formattedDate}
            </span>
          </div>

          <div className="bg-[#140d29] p-1.5 sm:p-2 rounded-xl border border-[#37245c]">
            <span className="text-[9px] text-slate-400 font-bold uppercase block">{t('TIME_ELAPSED')}</span>
            <span className="font-black text-xs text-emerald-300 flex items-center justify-center gap-1 mt-0.5">
              <Zap className="w-3 h-3 text-emerald-400" />
              {isInfinite ? `${daysElapsed} ${t('DAYS_UNIT')} (${t('VACATION_UNLIMITED_TITLE')})` : `${daysElapsed} / ${totalDays} ${t('DAYS_UNIT')}`}
            </span>
          </div>

          <div className="bg-[#140d29] p-1.5 sm:p-2 rounded-xl border border-[#37245c]">
            <span className="text-[9px] text-slate-400 font-bold uppercase block">{t('MATCHES_PLAYED')}</span>
            <span className="font-extrabold text-xs text-purple-300 flex items-center justify-center gap-1 mt-0.5">
              <Trophy className="w-3 h-3 text-purple-400" />
              {matchesPlayed} {t('MATCHES_UNIT')}
            </span>
          </div>
        </div>

      </div>
    </div>
  );
};

