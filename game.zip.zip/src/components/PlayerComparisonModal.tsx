import React, { useState } from 'react';
import { Player, Team } from '../types';
import { X, ArrowRightLeft, Shield, Sparkles, Trophy, Activity, Zap, ExternalLink } from 'lucide-react';
import { useTranslation } from '../utils/i18n';

interface PlayerComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
  allTeams: Team[];
  userTeam: Team;
  initialPlayer1?: Player | null;
  initialPlayer2?: Player | null;
  onOpenPlayerProfile?: (p: Player, team?: Team) => void;
}

export const PlayerComparisonModal: React.FC<PlayerComparisonModalProps> = ({
  isOpen,
  onClose,
  allTeams,
  userTeam,
  initialPlayer1,
  initialPlayer2,
  onOpenPlayerProfile
}) => {
  const { t, language } = useTranslation();
  if (!isOpen) return null;

  const getLocalizedText = (tr: string, en: string, es: string, fr: string, it: string, de: string, pt: string) => {
    const lang = (language || 'TR').toUpperCase();
    if (lang === 'EN') return en;
    if (lang === 'ES') return es;
    if (lang === 'FR') return fr;
    if (lang === 'IT') return it;
    if (lang === 'DE') return de;
    if (lang === 'PT') return pt;
    return tr;
  };

  // Flatten all available players
  const allPlayersList: { player: Player; team: Team; teamName: string; teamBadge: string }[] = [];
  allTeams.forEach(t => {
    t.players.forEach(p => {
      allPlayersList.push({ player: p, team: t, teamName: t.name, teamBadge: t.shortName });
    });
  });

  const [p1Id, setP1Id] = useState<string>(initialPlayer1?.id || userTeam.players[0]?.id || '');
  const [p2Id, setP2Id] = useState<string>(
    initialPlayer2?.id || (userTeam.players[1] ? userTeam.players[1].id : allPlayersList[1]?.player.id || '')
  );

  const p1Data = allPlayersList.find(item => item.player.id === p1Id) || {
    player: userTeam.players[0],
    team: userTeam,
    teamName: userTeam.name,
    teamBadge: userTeam.shortName
  };

  const p2Data = allPlayersList.find(item => item.player.id === p2Id) || {
    player: userTeam.players[1] || allPlayersList[1]?.player,
    team: userTeam,
    teamName: userTeam.name,
    teamBadge: userTeam.shortName
  };

  const p1 = p1Data.player;
  const p2 = p2Data.player;

  if (!p1 || !p2) return null;

  const compareStats = [
    { label: getLocalizedText('Genel Derece (OVR)', 'Overall Rating (OVR)', 'Media General (OVR)', 'Note Globale (OVR)', 'Valutazione Generale (OVR)', 'Gesamtstärke (OVR)', 'Classificação Geral (OVR)'), val1: p1.overall, val2: p2.overall, unit: 'OVR' },
    { label: getLocalizedText('Yaş', 'Age', 'Edad', 'Âge', 'Età', 'Alter', 'Idade'), val1: p1.age, val2: p2.age, unit: getLocalizedText('Yaş', 'yo', 'años', 'ans', 'anni', 'J.', 'anos'), invert: true },
    { label: getLocalizedText('Piyasa Değeri', 'Market Value', 'Valor de Mercado', 'Valeur Marchande', 'Valore di Mercato', 'Marktwert', 'Valor de Mercado'), val1: p1.marketValue, val2: p2.marketValue, format: (v: number) => `€${(v / 1_000_000).toFixed(1)}M` },
    { label: getLocalizedText('Haftalık Maaş', 'Weekly Wage', 'Salario Semanal', 'Salaire Hebdomadaire', 'Stipendio Settimanale', 'Wochengehalt', 'Salário Semanal'), val1: p1.wage || 15000, val2: p2.wage || 15000, format: (v: number) => `€${((v || 15000) / 1000).toFixed(0)}K` },
    { label: getLocalizedText('Form Performansı', 'Form Performance', 'Rendimiento de Forma', 'Performance de Forme', 'Rendimento di Forma', 'Formkurve', 'Desempenho de Forma'), val1: p1.form || 7.5, val2: p2.form || 7.5, format: (v: number) => v.toFixed(1) },
    { label: getLocalizedText('Kondisyon Enerjisi', 'Condition / Stamina', 'Energía / Resistencia', 'Condition Physique', 'Condizione / Energia', 'Kondition & Ausdauer', 'Condição Física'), val1: p1.stamina || 100, val2: p2.stamina || 100, unit: '%' },
    { label: getLocalizedText('Hız & Hızlanma (Pace)', 'Pace & Acceleration', 'Ritmo y Aceleración', 'Vitesse & Accélération', 'Velocità e Scatto', 'Tempo & Antritt', 'Ritmo e Aceleração'), val1: p1.attributes.pace, val2: p2.attributes.pace, unit: '' },
    { label: getLocalizedText('Şut & Bitiricilik (Shooting)', 'Shooting & Finishing', 'Tiro y Definición', 'Tir & Finition', 'Tiro e Conclusione', 'Schuss & Abschluss', 'Finalização e Chute'), val1: p1.attributes.shooting, val2: p2.attributes.shooting, unit: '' },
    { label: getLocalizedText('Pas & Vizyon (Passing)', 'Passing & Vision', 'Pase y Visión', 'Passe & Vision', 'Passaggio e Visione', 'Passen & Übersicht', 'Passe e Visão'), val1: p1.attributes.passing, val2: p2.attributes.passing, unit: '' },
    { label: getLocalizedText('Defans & Müdahale (Defending)', 'Defending & Tackling', 'Defensa y Entrada', 'Défense & Tacle', 'Difesa e Contrasto', 'Verteidigung & Zweikampf', 'Defesa e Desarme'), val1: p1.attributes.defending, val2: p2.attributes.defending, unit: '' },
    { label: getLocalizedText('Fizik & Güç (Physical)', 'Physical & Strength', 'Físico y Fuerza', 'Physique & Puissance', 'Fisico e Forza', 'Physis & Stärke', 'Físico e Força'), val1: p1.attributes.physical, val2: p2.attributes.physical, unit: '' },
    { label: getLocalizedText('Sezon Golleri', 'Season Goals', 'Goles de la Temporada', 'Buts de la Saison', 'Gol Stagionali', 'Saisontore', 'Gols na Temporada'), val1: p1.goalsScored || 0, val2: p2.goalsScored || 0, unit: '' },
    { label: getLocalizedText('Sezon Asistleri', 'Season Assists', 'Asistencias de la Temporada', 'Passes Décisives', 'Assist Stagionali', 'Saison-Vorlagen', 'Assistências'), val1: p1.assists || 0, val2: p2.assists || 0, unit: '' },
  ];

  return (
    <div className="fixed inset-0 z-[9990] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-[#181528] border-2 border-[#3d2f63] rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden my-auto text-slate-100 font-sans">
        
        {/* Header */}
        <div className="bg-[#120f21] p-3.5 sm:p-4 border-b border-[#2d244c] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-purple-600/20 border border-purple-500/40 text-purple-300 font-black text-sm">
              <ArrowRightLeft className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-white text-base sm:text-lg">
                {getLocalizedText('Oyuncu Karşılaştırma Analizi', 'Player Comparison Analysis', 'Análisis Comparativo de Jugadores', 'Analyse Comparative des Joueurs', 'Analisi Comparativa Giocatori', 'Spieler-Vergleichsanalyse', 'Análise de Comparação de Jogadores')}
              </h3>
              <p className="text-[11px] text-slate-400">
                {getLocalizedText('İki oyuncuyu yan yana nitelik, form ve istatistiklerine göre kıyaslayın', 'Compare two players head-to-head on attributes, form, and stats', 'Compara dos jugadores cara a cara por atributos, forma y estadísticas', 'Comparez deux joueurs côte à côte selon leurs attributs, forme et statistiques', 'Confronta due giocatori testa a testa per attributi, forma e statistiche', 'Vergleichen Sie zwei Spieler direkt nach Attributen, Form und Statistiken', 'Compare dois jogadores lado a lado por atributos, forma e estatísticas')}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-[#271f45] hover:bg-[#392e63] text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Player Selectors & Head-to-Head Cards */}
        <div className="p-3 sm:p-4 bg-[#141026] border-b border-[#2d244c] grid grid-cols-2 gap-3 shrink-0">
          
          {/* PLAYER 1 SELECTOR */}
          <div className="bg-[#1a1532] p-2.5 sm:p-3 rounded-xl border border-purple-500/30 space-y-2">
            <span className="text-[10px] font-extrabold text-purple-300 uppercase block">
              {getLocalizedText('1. Oyuncuyu Seçin:', 'Select 1st Player:', 'Seleccionar 1º Jugador:', 'Sélectionner 1er Joueur:', 'Seleziona 1° Giocatore:', '1. Spieler wählen:', 'Selecionar 1º Jogador:')}
            </span>
            <select
              value={p1Id}
              onChange={(e) => setP1Id(e.target.value)}
              className="w-full bg-[#120e24] border border-[#3b2e61] rounded-lg p-2 text-xs font-bold text-white focus:outline-none focus:border-purple-400"
            >
              {allPlayersList.map(item => (
                <option key={`p1-${item.player.id}`} value={item.player.id}>
                  {item.player.name} ({item.player.position} - {item.player.overall} OVR) [{item.teamBadge}]
                </option>
              ))}
            </select>

            {/* P1 Card Summary */}
            <div 
              onClick={() => onOpenPlayerProfile?.(p1, p1Data.team)}
              className="flex items-center justify-between pt-1 p-1.5 rounded-lg bg-[#120e24]/70 border border-purple-500/20 hover:border-purple-400 hover:bg-[#20173e] cursor-pointer transition-all group"
              title={getLocalizedText('Profili Aç', 'Open Profile', 'Abrir Perfil', 'Ouvrir le Profil', 'Apri Profilo', 'Profil Öffnen', 'Abrir Perfil')}
            >
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-xs sm:text-sm text-white group-hover:text-purple-300 truncate">{p1.name}</span>
                  <ExternalLink className="w-3 h-3 text-purple-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <span className="text-[10px] font-bold text-slate-400 block">{p1Data.teamName} • {p1.position}</span>
              </div>
              <div className="px-2.5 py-1 rounded-xl bg-purple-600 text-white font-black text-xs sm:text-sm border border-purple-400 shadow shrink-0">
                {p1.overall} OVR
              </div>
            </div>
          </div>

          {/* PLAYER 2 SELECTOR */}
          <div className="bg-[#1a1532] p-2.5 sm:p-3 rounded-xl border border-emerald-500/30 space-y-2">
            <span className="text-[10px] font-extrabold text-emerald-300 uppercase block">
              {getLocalizedText('2. Oyuncuyu Seçin:', 'Select 2nd Player:', 'Seleccionar 2º Jugador:', 'Sélectionner 2ème Joueur:', 'Seleziona 2° Giocatore:', '2. Spieler wählen:', 'Selecionar 2º Jogador:')}
            </span>
            <select
              value={p2Id}
              onChange={(e) => setP2Id(e.target.value)}
              className="w-full bg-[#120e24] border border-[#3b2e61] rounded-lg p-2 text-xs font-bold text-white focus:outline-none focus:border-emerald-400"
            >
              {allPlayersList.map(item => (
                <option key={`p2-${item.player.id}`} value={item.player.id}>
                  {item.player.name} ({item.player.position} - {item.player.overall} OVR) [{item.teamBadge}]
                </option>
              ))}
            </select>

            {/* P2 Card Summary */}
            <div 
              onClick={() => onOpenPlayerProfile?.(p2, p2Data.team)}
              className="flex items-center justify-between pt-1 p-1.5 rounded-lg bg-[#120e24]/70 border border-emerald-500/20 hover:border-emerald-400 hover:bg-[#152e25] cursor-pointer transition-all group"
              title={getLocalizedText('Profili Aç', 'Open Profile', 'Abrir Perfil', 'Ouvrir le Profil', 'Apri Profilo', 'Profil Öffnen', 'Abrir Perfil')}
            >
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-xs sm:text-sm text-white group-hover:text-emerald-300 truncate">{p2.name}</span>
                  <ExternalLink className="w-3 h-3 text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <span className="text-[10px] font-bold text-slate-400 block">{p2Data.teamName} • {p2.position}</span>
              </div>
              <div className="px-2.5 py-1 rounded-xl bg-emerald-600 text-white font-black text-xs sm:text-sm border border-emerald-400 shadow shrink-0">
                {p2.overall} OVR
              </div>
            </div>
          </div>

        </div>

        {/* COMPARISON TABLE */}
        <div className="p-3 sm:p-4 overflow-y-auto flex-1 space-y-2 custom-scrollbar bg-[#18142a]">
          <div className="rounded-xl border border-[#2d244c] overflow-hidden bg-[#120f21]">
            
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#1f1938] border-b border-[#2d244c] text-[10px] font-black uppercase text-slate-400">
                  <th className="py-2.5 px-3 text-left w-1/3 text-purple-300 truncate">{p1.name}</th>
                  <th className="py-2.5 px-2 text-center w-1/3">
                    {getLocalizedText('Kriter / Özellik', 'Attribute / Metric', 'Atributo / Métrica', 'Attribut / Métrique', 'Attributo / Metrica', 'Attribut / Kriterium', 'Atributo / Métrica')}
                  </th>
                  <th className="py-2.5 px-3 text-right w-1/3 text-emerald-300 truncate">{p2.name}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#251f3e] text-xs font-bold">
                {compareStats.map((stat, index) => {
                  const v1 = stat.val1;
                  const v2 = stat.val2;

                  let isP1Better = stat.invert ? v1 < v2 : v1 > v2;
                  let isP2Better = stat.invert ? v2 < v1 : v2 > v1;
                  let isEqual = v1 === v2;

                  const displayV1 = stat.format ? stat.format(v1) : `${v1} ${stat.unit || ''}`;
                  const displayV2 = stat.format ? stat.format(v2) : `${v2} ${stat.unit || ''}`;

                  return (
                    <tr key={index} className="hover:bg-[#1a1532] transition-colors">
                      {/* P1 Value */}
                      <td className="py-2.5 px-3 text-left">
                        <span className={`inline-block px-2 py-0.5 rounded font-black ${
                          isP1Better
                            ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm'
                            : 'text-slate-300'
                        }`}>
                          {displayV1} {isP1Better && '👑'}
                        </span>
                      </td>

                      {/* Stat Label */}
                      <td className="py-2.5 px-2 text-center text-[11px] text-slate-300 font-extrabold uppercase tracking-wide">
                        {stat.label}
                      </td>

                      {/* P2 Value */}
                      <td className="py-2.5 px-3 text-right">
                        <span className={`inline-block px-2 py-0.5 rounded font-black ${
                          isP2Better
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                            : 'text-slate-300'
                        }`}>
                          {isP2Better && '👑 '} {displayV2}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

          </div>

          {/* Last 5 Matches Stats Table Comparison */}
          <div className="bg-[#120f21] p-3 rounded-xl border border-[#2d244c] space-y-2 mt-2">
            <span className="font-black text-xs text-amber-300 uppercase tracking-wider block">
              📊 {getLocalizedText('Son 5 Maçlık İstatistik Karşılaştırması', 'Last 5 Matches Performance', 'Rendimiento de los Últimos 5 Partidos', 'Performance des 5 Derniers Matchs', 'Prestazioni Ultime 5 Partite', 'Form der Letzten 5 Spiele', 'Desempenho dos Últimos 5 Jogos')}
            </span>

            <div className="grid grid-cols-2 gap-3 text-xs">
              
              {/* P1 Recent Stats */}
              <div 
                onClick={() => onOpenPlayerProfile?.(p1, p1Data.team)}
                className="bg-[#19142e] hover:bg-[#221a3e] p-2.5 rounded-lg border border-[#312754] hover:border-purple-500/40 space-y-1 cursor-pointer transition-colors"
              >
                <span className="font-bold text-purple-300 block truncate">{p1.name}</span>
                <div className="flex items-center justify-between text-[11px] text-slate-300">
                  <span>{getLocalizedText('Ortalama Reyting:', 'Avg Rating:', 'Media Valoración:', 'Note Moyenne:', 'Valutazione Media:', 'Durchschn. Note:', 'Nota Média:')}</span>
                  <span className="font-extrabold text-amber-300">{(p1.form || 7.5).toFixed(1)} / 10</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-300">
                  <span>{getLocalizedText('Sarı / Kırmızı Kart:', 'Yellow / Red Cards:', 'Tarjetas A / R:', 'Cartons J / R:', 'Cartellini G / R:', 'Gelbe / Rote Karten:', 'Cartões A / V:')}</span>
                  <span className="font-extrabold text-slate-100">{p1.yellowCards || 0} / {p1.redCards || 0}</span>
                </div>
              </div>

              {/* P2 Recent Stats */}
              <div 
                onClick={() => onOpenPlayerProfile?.(p2, p2Data.team)}
                className="bg-[#19142e] hover:bg-[#1a2f26] p-2.5 rounded-lg border border-[#312754] hover:border-emerald-500/40 space-y-1 cursor-pointer transition-colors"
              >
                <span className="font-bold text-emerald-300 block truncate">{p2.name}</span>
                <div className="flex items-center justify-between text-[11px] text-slate-300">
                  <span>{getLocalizedText('Ortalama Reyting:', 'Avg Rating:', 'Media Valoración:', 'Note Moyenne:', 'Valutazione Media:', 'Durchschn. Note:', 'Nota Média:')}</span>
                  <span className="font-extrabold text-amber-300">{(p2.form || 7.5).toFixed(1)} / 10</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-300">
                  <span>{getLocalizedText('Sarı / Kırmızı Kart:', 'Yellow / Red Cards:', 'Tarjetas A / R:', 'Cartons J / R:', 'Cartellini G / R:', 'Gelbe / Rote Karten:', 'Cartões A / V:')}</span>
                  <span className="font-extrabold text-slate-100">{p2.yellowCards || 0} / {p2.redCards || 0}</span>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

