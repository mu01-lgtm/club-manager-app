import React, { useState } from 'react';
import { LeagueRow, Fixture, Team, Player } from '../types';
import { useTranslation } from '../utils/i18n';
import { Trophy, X, Users, DollarSign, Award, ChevronRight, ShoppingCart, ChevronDown, Check, Globe, Sparkles } from 'lucide-react';
import { TransferOfferModal } from './TransferOfferModal';
import { TeamBadge } from './TeamBadge';
import { ENGLISH_TEAMS } from '../data/englishTeams';
import { SPANISH_TEAMS } from '../data/spanishTeams';
import { BUNDESLIGA_TEAMS } from '../data/bundesligaTeams';
import { SERIE_A_TEAMS } from '../data/serieATeams';
import { LIGUE1_TEAMS } from '../data/ligue1Teams';
import { SUPER_LIG_TEAMS } from '../data/superLigTeams';
import { ADDITIONAL_EUROPEAN_TEAMS } from '../data/europeanTeams';
import { ExternalTeamData } from './WorldScoutModal';
import { EuropeanTournamentView } from './EuropeanTournamentView';
import { getTeamLogoUrl } from '../data/teamLogos';

export interface LeagueConfig {
  id: string;
  name: string;
  country: string;
  flag: string;
  badgeColor: string;
  isEuropean?: boolean;
}

export const LEAGUE_OPTIONS: LeagueConfig[] = [
  { id: 'super-lig', name: 'Trendyol Süper Lig', country: 'Türkiye', flag: '🇹🇷', badgeColor: 'from-red-600 to-amber-600' },
  { id: 'premier-league', name: 'Premier League', country: 'İngiltere', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', badgeColor: 'from-purple-700 to-blue-800' },
  { id: 'la-liga', name: 'La Liga', country: 'İspanya', flag: '🇪🇸', badgeColor: 'from-amber-500 to-red-600' },
  { id: 'bundesliga', name: 'Bundesliga', country: 'Almanya', flag: '🇩🇪', badgeColor: 'from-slate-700 to-red-800' },
  { id: 'serie-a', name: 'Serie A', country: 'İtalya', flag: '🇮🇹', badgeColor: 'from-blue-600 to-cyan-800' },
  { id: 'ligue-1', name: 'Ligue 1', country: 'Fransa', flag: '🇫🇷', badgeColor: 'from-sky-600 to-indigo-800' },
  { id: 'ucl', name: 'UEFA Şampiyonlar Ligi', country: 'Avrupa', flag: '⭐', badgeColor: 'from-blue-900 to-indigo-950', isEuropean: true },
  { id: 'uel', name: 'UEFA Avrupa Ligi', country: 'Avrupa', flag: '🏆', badgeColor: 'from-orange-700 to-amber-900', isEuropean: true },
  { id: 'uecl', name: 'UEFA Konferans Ligi', country: 'Avrupa', flag: '🛡️', badgeColor: 'from-emerald-700 to-teal-900', isEuropean: true },
];

interface QualificationZone {
  label: string;
  shortLabel: string;
  dotColor: string;
  textColor: string;
  badgeBg: string;
  borderLeftColor: string;
}

function getRankQualification(leagueId: string, rank: number, totalTeams: number): QualificationZone | null {
  if (leagueId === 'super-lig') {
    if (rank === 1) return { label: 'UEFA Şampiyonlar Ligi (Play-off)', shortLabel: 'ŞL', dotColor: 'bg-blue-500', textColor: 'text-blue-400', badgeBg: 'bg-blue-500/20 text-blue-300 border-blue-500/40', borderLeftColor: 'border-l-blue-500' };
    if (rank === 2) return { label: 'UEFA Şampiyonlar Ligi (2. Eleme)', shortLabel: 'ŞL Eleme', dotColor: 'bg-sky-400', textColor: 'text-sky-300', badgeBg: 'bg-sky-500/20 text-sky-300 border-sky-500/40', borderLeftColor: 'border-l-sky-400' };
    if (rank === 3) return { label: 'UEFA Avrupa Ligi (2. Eleme)', shortLabel: 'AL', dotColor: 'bg-amber-500', textColor: 'text-amber-400', badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-500/40', borderLeftColor: 'border-l-amber-500' };
    if (rank === 4) return { label: 'UEFA Konferans Ligi (2. Eleme)', shortLabel: 'KL', dotColor: 'bg-emerald-500', textColor: 'text-emerald-400', badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40', borderLeftColor: 'border-l-emerald-500' };
    if (rank >= totalTeams - 3) return { label: 'Küme Düşme (TFF 1. Lig)', shortLabel: 'Düşme', dotColor: 'bg-rose-500', textColor: 'text-rose-400', badgeBg: 'bg-rose-500/20 text-rose-300 border-rose-500/40', borderLeftColor: 'border-l-rose-500' };
  } else if (leagueId === 'premier-league' || leagueId === 'la-liga' || leagueId === 'serie-a') {
    if (rank >= 1 && rank <= 4) return { label: 'UEFA Şampiyonlar Ligi', shortLabel: 'ŞL', dotColor: 'bg-blue-500', textColor: 'text-blue-400', badgeBg: 'bg-blue-500/20 text-blue-300 border-blue-500/40', borderLeftColor: 'border-l-blue-500' };
    if (leagueId === 'la-liga' ? (rank === 5 || rank === 6) : rank === 5) return { label: 'UEFA Avrupa Ligi', shortLabel: 'AL', dotColor: 'bg-amber-500', textColor: 'text-amber-400', badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-500/40', borderLeftColor: 'border-l-amber-500' };
    if (leagueId === 'la-liga' ? rank === 7 : rank === 6) return { label: 'UEFA Konferans Ligi', shortLabel: 'KL', dotColor: 'bg-emerald-500', textColor: 'text-emerald-400', badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40', borderLeftColor: 'border-l-emerald-500' };
    if (rank >= totalTeams - 2) return { label: 'Küme Düşme', shortLabel: 'Düşme', dotColor: 'bg-rose-500', textColor: 'text-rose-400', badgeBg: 'bg-rose-500/20 text-rose-300 border-rose-500/40', borderLeftColor: 'border-l-rose-500' };
  } else if (leagueId === 'bundesliga') {
    if (rank >= 1 && rank <= 4) return { label: 'UEFA Şampiyonlar Ligi', shortLabel: 'ŞL', dotColor: 'bg-blue-500', textColor: 'text-blue-400', badgeBg: 'bg-blue-500/20 text-blue-300 border-blue-500/40', borderLeftColor: 'border-l-blue-500' };
    if (rank === 5) return { label: 'UEFA Avrupa Ligi', shortLabel: 'AL', dotColor: 'bg-amber-500', textColor: 'text-amber-400', badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-500/40', borderLeftColor: 'border-l-amber-500' };
    if (rank === 6) return { label: 'UEFA Konferans Ligi', shortLabel: 'KL', dotColor: 'bg-emerald-500', textColor: 'text-emerald-400', badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40', borderLeftColor: 'border-l-emerald-500' };
    if (rank === 16) return { label: 'Küme Düşme Play-Out (Baraj)', shortLabel: 'Play-Out', dotColor: 'bg-orange-400', textColor: 'text-orange-300', badgeBg: 'bg-orange-500/20 text-orange-300 border-orange-500/40', borderLeftColor: 'border-l-orange-400' };
    if (rank >= 17) return { label: 'Küme Düşme (2. Bundesliga)', shortLabel: 'Düşme', dotColor: 'bg-rose-500', textColor: 'text-rose-400', badgeBg: 'bg-rose-500/20 text-rose-300 border-rose-500/40', borderLeftColor: 'border-l-rose-500' };
  } else if (leagueId === 'ligue-1') {
    if (rank >= 1 && rank <= 3) return { label: 'UEFA Şampiyonlar Ligi', shortLabel: 'ŞL', dotColor: 'bg-blue-500', textColor: 'text-blue-400', badgeBg: 'bg-blue-500/20 text-blue-300 border-blue-500/40', borderLeftColor: 'border-l-blue-500' };
    if (rank === 4) return { label: 'UEFA Şampiyonlar Ligi (3. Ön Eleme)', shortLabel: 'ŞL Eleme', dotColor: 'bg-sky-400', textColor: 'text-sky-300', badgeBg: 'bg-sky-500/20 text-sky-300 border-sky-500/40', borderLeftColor: 'border-l-sky-400' };
    if (rank === 5) return { label: 'UEFA Avrupa Ligi', shortLabel: 'AL', dotColor: 'bg-amber-500', textColor: 'text-amber-400', badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-500/40', borderLeftColor: 'border-l-amber-500' };
    if (rank === 6) return { label: 'UEFA Konferans Ligi (Play-off)', shortLabel: 'KL', dotColor: 'bg-emerald-500', textColor: 'text-emerald-400', badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40', borderLeftColor: 'border-l-emerald-500' };
    if (rank === 16) return { label: 'Küme Düşme Play-Out (Baraj)', shortLabel: 'Play-Out', dotColor: 'bg-orange-400', textColor: 'text-orange-300', badgeBg: 'bg-orange-500/20 text-orange-300 border-orange-500/40', borderLeftColor: 'border-l-orange-400' };
    if (rank >= 17) return { label: 'Küme Düşme (Ligue 2)', shortLabel: 'Düşme', dotColor: 'bg-rose-500', textColor: 'text-rose-400', badgeBg: 'bg-rose-500/20 text-rose-300 border-rose-500/40', borderLeftColor: 'border-l-rose-500' };
  }
  return null;
}

function getLeagueLegendItems(leagueId: string) {
  if (leagueId === 'super-lig') {
    return [
      { dotColor: 'bg-blue-500', label: '1: Şampiyonlar Ligi (Play-off)' },
      { dotColor: 'bg-sky-400', label: '2: Şampiyonlar Ligi (2. Ön Eleme)' },
      { dotColor: 'bg-amber-500', label: '3: Avrupa Ligi (2. Ön Eleme)' },
      { dotColor: 'bg-emerald-500', label: '4: Konferans Ligi (2. Ön Eleme)' },
      { dotColor: 'bg-rose-500', label: '16 - 19: Düşme Hattı' }
    ];
  }
  if (leagueId === 'premier-league' || leagueId === 'serie-a') {
    return [
      { dotColor: 'bg-blue-500', label: '1 - 4: UEFA Şampiyonlar Ligi' },
      { dotColor: 'bg-amber-500', label: '5: UEFA Avrupa Ligi' },
      { dotColor: 'bg-emerald-500', label: '6: UEFA Konferans Ligi' },
      { dotColor: 'bg-rose-500', label: '18 - 20: Düşme Hattı' }
    ];
  }
  if (leagueId === 'la-liga') {
    return [
      { dotColor: 'bg-blue-500', label: '1 - 4: UEFA Şampiyonlar Ligi' },
      { dotColor: 'bg-amber-500', label: '5 - 6: UEFA Avrupa Ligi' },
      { dotColor: 'bg-emerald-500', label: '7: UEFA Konferans Ligi' },
      { dotColor: 'bg-rose-500', label: '18 - 20: Düşme Hattı' }
    ];
  }
  if (leagueId === 'bundesliga') {
    return [
      { dotColor: 'bg-blue-500', label: '1 - 4: UEFA Şampiyonlar Ligi' },
      { dotColor: 'bg-amber-500', label: '5: UEFA Avrupa Ligi' },
      { dotColor: 'bg-emerald-500', label: '6: UEFA Konferans Ligi' },
      { dotColor: 'bg-orange-400', label: '16: Play-Out (Baraj)' },
      { dotColor: 'bg-rose-500', label: '17 - 18: Düşme Hattı' }
    ];
  }
  if (leagueId === 'ligue-1') {
    return [
      { dotColor: 'bg-blue-500', label: '1 - 3: UEFA Şampiyonlar Ligi' },
      { dotColor: 'bg-sky-400', label: '4: Şampiyonlar Ligi (3. Ön Eleme)' },
      { dotColor: 'bg-amber-500', label: '5: UEFA Avrupa Ligi' },
      { dotColor: 'bg-emerald-500', label: '6: UEFA Konferans Ligi' },
      { dotColor: 'bg-orange-400', label: '16: Play-Out (Baraj)' },
      { dotColor: 'bg-rose-500', label: '17 - 18: Düşme Hattı' }
    ];
  }
  return [];
}

interface LeagueTableProps {
  standings: LeagueRow[];
  currentTeamId: string;
  fixtures?: Fixture[];
  allTeams?: Team[];
  currentWeek?: number;
  userTeam?: Team;
  onOpenPlayerProfile?: (player: Player, team?: Team) => void;
  onBuyPlayer?: (player: Player) => void;
  showToast?: (type: 'success' | 'error' | 'info', title: string, message: string) => void;
}

// Mathematically consistent and deterministic simulation for external leagues
function simulateExternalLeagueScheduleAndStandings(
  rawList: ExternalTeamData[],
  completedWeeks: number,
  leagueId: string
): {
  teams: Team[];
  standings: LeagueRow[];
} {
  const teams: Team[] = rawList.map(ext => ({
    id: ext.id,
    name: ext.name,
    shortName: ext.shortName,
    badgeColor: ext.badgeColor,
    logoUrl: ext.logoUrl || getTeamLogoUrl(ext.id) || getTeamLogoUrl(ext.name) || getTeamLogoUrl(ext.shortName),
    stadiumName: ext.stadium,
    budget: ext.budget,
    overall: ext.overall,
    reputation: Math.min(100, Math.round(ext.overall * 1.1)),
    country: ext.country,
    manager: ext.manager,
    formation: '4-3-3',
    tactic: 'BALANCED',
    players: ext.players.map(p => ({
      ...p,
      appearances: 0,
      goalsScored: 0,
      assists: 0,
      lastRating: Math.round((7.0 + (p.overall - 75) * 0.035) * 10) / 10
    }))
  }));

  const standingsMap: Record<string, LeagueRow> = {};
  teams.forEach(t => {
    standingsMap[t.id] = {
      teamId: t.id,
      teamName: t.name,
      played: 0,
      won: 0,
      drawn: 0,
      lost: 0,
      goalsFor: 0,
      goalsAgainst: 0,
      goalDifference: 0,
      points: 0,
      formHistory: []
    };
  });

  if (completedWeeks <= 0) {
    return { teams, standings: Object.values(standingsMap) };
  }

  const n = teams.length;
  const numRounds = n - 1;
  const maxWeeksToSim = Math.min(completedWeeks, 38);

  const pseudoRandom = (seedStr: string): number => {
    let hash = 0;
    for (let i = 0; i < seedStr.length; i++) {
      hash = ((hash << 5) - hash) + seedStr.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs((Math.sin(hash) * 10000) % 1);
  };

  for (let w = 1; w <= maxWeeksToSim; w++) {
    const roundIdx = (w - 1) % numRounds;
    const isSecondHalf = (w - 1) >= numRounds;

    for (let i = 0; i < n / 2; i++) {
      let homeIdx: number;
      let awayIdx: number;

      if (i === 0) {
        homeIdx = roundIdx;
        awayIdx = n - 1;
      } else {
        homeIdx = (roundIdx + i) % (n - 1);
        awayIdx = (roundIdx - i + (n - 1)) % (n - 1);
      }

      if ((i === 0 && roundIdx % 2 === 1) || isSecondHalf) {
        const temp = homeIdx;
        homeIdx = awayIdx;
        awayIdx = temp;
      }

      const homeTeam = teams[homeIdx];
      const awayTeam = teams[awayIdx];
      if (!homeTeam || !awayTeam) continue;

      const matchSeed = `${leagueId}-w${w}-${homeTeam.id}-${awayTeam.id}`;
      const r1 = pseudoRandom(matchSeed + '-1');
      const r2 = pseudoRandom(matchSeed + '-2');
      const r3 = pseudoRandom(matchSeed + '-3');
      const r4 = pseudoRandom(matchSeed + '-4');

      const homePower = homeTeam.overall + 2;
      const awayPower = awayTeam.overall;
      const powerDiff = homePower - awayPower;

      const homeExpected = Math.max(0.35, 1.45 + powerDiff * 0.08);
      const awayExpected = Math.max(0.35, 1.15 - powerDiff * 0.08);

      let homeScore = 0;
      let awayScore = 0;

      if (r1 < homeExpected / 3.0) homeScore++;
      if (r2 < homeExpected / 2.2) homeScore++;
      if (r3 < awayExpected / 3.2) awayScore++;
      if (r4 < awayExpected / 2.4) awayScore++;

      const homeRow = standingsMap[homeTeam.id];
      const awayRow = standingsMap[awayTeam.id];

      homeRow.played += 1;
      awayRow.played += 1;
      homeRow.goalsFor += homeScore;
      homeRow.goalsAgainst += awayScore;
      awayRow.goalsFor += awayScore;
      awayRow.goalsAgainst += homeScore;
      homeRow.goalDifference = homeRow.goalsFor - homeRow.goalsAgainst;
      awayRow.goalDifference = awayRow.goalsFor - awayRow.goalsAgainst;

      if (homeScore > awayScore) {
        homeRow.won += 1;
        homeRow.points += 3;
        homeRow.formHistory.unshift('W');
        awayRow.lost += 1;
        awayRow.formHistory.unshift('L');
      } else if (awayScore > homeScore) {
        awayRow.won += 1;
        awayRow.points += 3;
        awayRow.formHistory.unshift('W');
        homeRow.lost += 1;
        homeRow.formHistory.unshift('L');
      } else {
        homeRow.drawn += 1;
        homeRow.points += 1;
        homeRow.formHistory.unshift('D');
        awayRow.drawn += 1;
        awayRow.points += 1;
        awayRow.formHistory.unshift('D');
      }

      homeRow.formHistory = homeRow.formHistory.slice(0, 5);
      awayRow.formHistory = awayRow.formHistory.slice(0, 5);

      // Distribute goals and assists to key players
      const homeForwards = homeTeam.players.filter(p => p.position === 'FW').sort((a, b) => b.overall - a.overall);
      const homeMids = homeTeam.players.filter(p => p.position === 'MID').sort((a, b) => b.overall - a.overall);
      const homeAttackers = [...homeForwards, ...homeMids];

      for (let g = 0; g < homeScore; g++) {
        const scorerSeed = pseudoRandom(matchSeed + `-hg-${g}`);
        const scorer = homeAttackers.length > 0
          ? (scorerSeed < 0.65 ? homeAttackers[0] : homeAttackers[Math.floor(scorerSeed * homeAttackers.length)])
          : homeTeam.players[0];
        if (scorer) {
          scorer.goalsScored = (scorer.goalsScored || 0) + 1;
        }

        const assistSeed = pseudoRandom(matchSeed + `-ha-${g}`);
        const assistCandidates = homeAttackers.filter(p => p.id !== scorer?.id);
        const assistPlayer = assistCandidates.length > 0
          ? (assistSeed < 0.6 ? assistCandidates[0] : assistCandidates[Math.floor(assistSeed * assistCandidates.length)])
          : null;
        if (assistPlayer) {
          assistPlayer.assists = (assistPlayer.assists || 0) + 1;
        }
      }

      const awayForwards = awayTeam.players.filter(p => p.position === 'FW').sort((a, b) => b.overall - a.overall);
      const awayMids = awayTeam.players.filter(p => p.position === 'MID').sort((a, b) => b.overall - a.overall);
      const awayAttackers = [...awayForwards, ...awayMids];

      for (let g = 0; g < awayScore; g++) {
        const scorerSeed = pseudoRandom(matchSeed + `-ag-${g}`);
        const scorer = awayAttackers.length > 0
          ? (scorerSeed < 0.65 ? awayAttackers[0] : awayAttackers[Math.floor(scorerSeed * awayAttackers.length)])
          : awayTeam.players[0];
        if (scorer) {
          scorer.goalsScored = (scorer.goalsScored || 0) + 1;
        }

        const assistSeed = pseudoRandom(matchSeed + `-aa-${g}`);
        const assistCandidates = awayAttackers.filter(p => p.id !== scorer?.id);
        const assistPlayer = assistCandidates.length > 0
          ? (assistSeed < 0.6 ? assistCandidates[0] : assistCandidates[Math.floor(assistSeed * assistCandidates.length)])
          : null;
        if (assistPlayer) {
          assistPlayer.assists = (assistPlayer.assists || 0) + 1;
        }
      }

      // Distribute realistic yellow and red cards
      const homeDefenders = homeTeam.players.filter(p => p.position === 'DEF' || p.position === 'MID');
      const awayDefenders = awayTeam.players.filter(p => p.position === 'DEF' || p.position === 'MID');
      const cardSeedH = pseudoRandom(matchSeed + '-hc');
      if (cardSeedH > 0.35 && homeDefenders.length > 0) {
        const cardedP = homeDefenders[Math.floor(cardSeedH * homeDefenders.length)];
        if (cardedP) {
          cardedP.yellowCards = (cardedP.yellowCards || 0) + 1;
          if (cardSeedH > 0.96) {
            cardedP.redCards = (cardedP.redCards || 0) + 1;
          }
        }
      }
      const cardSeedA = pseudoRandom(matchSeed + '-ac');
      if (cardSeedA > 0.35 && awayDefenders.length > 0) {
        const cardedP = awayDefenders[Math.floor(cardSeedA * awayDefenders.length)];
        if (cardedP) {
          cardedP.yellowCards = (cardedP.yellowCards || 0) + 1;
          if (cardSeedA > 0.96) {
            cardedP.redCards = (cardedP.redCards || 0) + 1;
          }
        }
      }

      homeTeam.players.slice(0, 11).forEach(p => {
        p.appearances = (p.appearances || 0) + 1;
        const wonMatch = homeScore > awayScore;
        const lostMatch = homeScore < awayScore;
        const ratingDelta = (wonMatch ? 0.35 : lostMatch ? -0.35 : 0) + ((p.goalsScored || 0) > 0 ? 0.25 : 0) + ((p.assists || 0) > 0 ? 0.15 : 0);
        const baseR = 7.0 + (p.overall - 75) * 0.035 + ratingDelta;
        p.lastRating = Math.min(8.6, Math.max(6.2, Math.round(baseR * 10) / 10));
      });

      awayTeam.players.slice(0, 11).forEach(p => {
        p.appearances = (p.appearances || 0) + 1;
        const wonMatch = awayScore > homeScore;
        const lostMatch = awayScore < homeScore;
        const ratingDelta = (wonMatch ? 0.35 : lostMatch ? -0.35 : 0) + ((p.goalsScored || 0) > 0 ? 0.25 : 0) + ((p.assists || 0) > 0 ? 0.15 : 0);
        const baseR = 7.0 + (p.overall - 75) * 0.035 + ratingDelta;
        p.lastRating = Math.min(8.6, Math.max(6.2, Math.round(baseR * 10) / 10));
      });
    }
  }

  return {
    teams,
    standings: Object.values(standingsMap)
  };
}

export const LeagueTable: React.FC<LeagueTableProps> = ({
  standings,
  currentTeamId,
  fixtures = [],
  allTeams = [],
  currentWeek = 1,
  userTeam,
  onOpenPlayerProfile,
  onBuyPlayer,
  showToast
}) => {
  const { t } = useTranslation();

  // Detect user's current league based on userTeam and allTeams
  const detectedUserLeagueId = React.useMemo(() => {
    if (!userTeam) return 'super-lig';
    const c = (userTeam.country || '').toLowerCase();
    if (c.includes('ingiltere') || c.includes('england') || ENGLISH_TEAMS.some(t => t.id === userTeam.id)) return 'premier-league';
    if (c.includes('ispanya') || c.includes('spain') || SPANISH_TEAMS.some(t => t.id === userTeam.id)) return 'la-liga';
    if (c.includes('almanya') || c.includes('germany') || BUNDESLIGA_TEAMS.some(t => t.id === userTeam.id)) return 'bundesliga';
    if (c.includes('italya') || c.includes('italy') || SERIE_A_TEAMS.some(t => t.id === userTeam.id)) return 'serie-a';
    if (c.includes('fransa') || c.includes('france') || LIGUE1_TEAMS.some(t => t.id === userTeam.id)) return 'ligue-1';
    return 'super-lig';
  }, [userTeam]);

  const [selectedLeagueId, setSelectedLeagueId] = useState<string>(detectedUserLeagueId);
  const [isLeagueMenuOpen, setIsLeagueMenuOpen] = useState<boolean>(false);
  const [selectedDetailTeam, setSelectedDetailTeam] = useState<Team | null>(null);
  const [teamModalTab, setTeamModalTab] = useState<'SQUAD' | 'STATS'>('STATS');
  const [offerPlayerModal, setOfferPlayerModal] = useState<{ player: Player; team: Team } | null>(null);
  const [mainTab, setMainTab] = useState<'STANDINGS' | 'TOP_SCORERS' | 'TOP_ASSISTS' | 'PLAYER_RATINGS'>('STANDINGS');

  React.useEffect(() => {
    setSelectedLeagueId(detectedUserLeagueId);
  }, [detectedUserLeagueId]);

  const activeLeagueConfig = LEAGUE_OPTIONS.find(l => l.id === selectedLeagueId) || LEAGUE_OPTIONS[0];

  const isPlayingInSelectedLeague = selectedLeagueId === detectedUserLeagueId;

  // Calculate completed weeks
  const completedWeeks = React.useMemo(() => {
    const isCurrentWeekPlayed = fixtures.some(f => f.week === currentWeek && f.played);
    if (isCurrentWeekPlayed) return currentWeek;
    return Math.max(0, currentWeek - 1);
  }, [fixtures, currentWeek]);

  // Build teams list and standings for selected league
  const { activeTeamsList, activeStandingsList } = React.useMemo(() => {
    if (isPlayingInSelectedLeague) {
      return {
        activeTeamsList: allTeams,
        activeStandingsList: standings
      };
    }

    let rawExternalList: ExternalTeamData[] = [];
    if (selectedLeagueId === 'super-lig') rawExternalList = SUPER_LIG_TEAMS as unknown as ExternalTeamData[];
    else if (selectedLeagueId === 'premier-league') rawExternalList = ENGLISH_TEAMS;
    else if (selectedLeagueId === 'la-liga') rawExternalList = SPANISH_TEAMS;
    else if (selectedLeagueId === 'bundesliga') rawExternalList = BUNDESLIGA_TEAMS;
    else if (selectedLeagueId === 'serie-a') rawExternalList = SERIE_A_TEAMS;
    else if (selectedLeagueId === 'ligue-1') rawExternalList = LIGUE1_TEAMS;

    const simResult = simulateExternalLeagueScheduleAndStandings(
      rawExternalList,
      completedWeeks,
      selectedLeagueId
    );

    return {
      activeTeamsList: simResult.teams,
      activeStandingsList: simResult.standings
    };
  }, [isPlayingInSelectedLeague, selectedLeagueId, allTeams, standings, completedWeeks]);

  // Compute Top Scorers, Top Assists, and Top Ratings for the active league
  const allLeaguePlayersList: { player: Player; team: Team }[] = [];
  activeTeamsList.forEach(t => {
    t.players.forEach(p => {
      allLeaguePlayersList.push({ player: p, team: t });
    });
  });

  const topScorers = [...allLeaguePlayersList]
    .filter(item => (item.player.goalsScored || 0) > 0)
    .sort((a, b) => (b.player.goalsScored || 0) - (a.player.goalsScored || 0))
    .slice(0, 15);

  const topAssists = [...allLeaguePlayersList]
    .filter(item => (item.player.assists || 0) > 0)
    .sort((a, b) => (b.player.assists || 0) - (a.player.assists || 0))
    .slice(0, 15);

  const topRatings = [...allLeaguePlayersList]
    .sort((a, b) => {
      const rA = a.player.lastRating || a.player.form || 7.0;
      const rB = b.player.lastRating || b.player.form || 7.0;
      return rB - rA;
    })
    .slice(0, 15);

  // Sort standings by points desc, then goal difference desc, then goals for desc
  const sortedStandings = [...activeStandingsList].sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.goalDifference !== a.goalDifference) return b.goalDifference - a.goalDifference;
    return b.goalsFor - a.goalsFor;
  });

  const handleRowClick = (teamId: string) => {
    const found = activeTeamsList.find(t => t.id === teamId) || allTeams.find(t => t.id === teamId);
    if (found) {
      setSelectedDetailTeam(found);
      setTeamModalTab('STATS');
    }
  };

  const activeUserTeam = userTeam || allTeams.find(t => t.id === currentTeamId);

  return (
    <div className="bg-[#18142a] border border-[#2d244c] rounded-2xl p-2.5 sm:p-4 shadow-2xl space-y-2.5 relative flex-1 min-h-0 flex flex-col h-full overflow-hidden">
      
      {/* Table Header Banner & Tabs */}
      <div className="bg-[#130f24] p-2 sm:p-2.5 rounded-xl border border-[#2d244c] flex flex-col md:flex-row items-stretch md:items-center justify-between gap-2 shrink-0 relative z-20">
        
        {/* LEAGUE SELECTOR CLICKABLE HEADER */}
        <div className="flex items-center gap-2 relative">
          <div className="p-1.5 sm:p-2 rounded-lg bg-amber-500/20 border border-amber-500/30 text-amber-300 shrink-0">
            <Trophy className="w-4 h-4" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setIsLeagueMenuOpen(!isLeagueMenuOpen)}
                className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-[#1f1938] hover:bg-[#2c234f] border border-[#3f3168] text-white transition-all shadow group cursor-pointer"
                title="Ligleri değiştir"
              >
                <span className="text-base leading-none">{activeLeagueConfig.flag}</span>
                <span className="font-black text-xs sm:text-sm text-amber-300 group-hover:text-amber-200 tracking-tight">
                  {activeLeagueConfig.name}
                </span>
                <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 ${isLeagueMenuOpen ? 'rotate-180 text-amber-400' : ''}`} />
              </button>
            </div>
            <p className="text-[9.5px] text-slate-400 font-semibold mt-0.5">
              <span className="text-emerald-400 font-bold">{sortedStandings.length} {t('TEAM') || 'Takım'}</span> • {activeLeagueConfig.country}
            </p>
          </div>

          {/* LEAGUE SELECTION POPUP MENU */}
          {isLeagueMenuOpen && (
            <div className="absolute top-12 left-0 z-50 bg-[#161228] border-2 border-[#3d2f63] rounded-2xl p-2 shadow-2xl w-64 space-y-1 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="px-2 py-1.5 border-b border-[#2d244c] flex items-center justify-between">
                <span className="text-[10px] uppercase font-black text-slate-400 tracking-wider flex items-center gap-1">
                  <Globe className="w-3 h-3 text-purple-400" /> {t('LEAGUE_SELECTION') || 'Lig Seçimi'}
                </span>
                <button
                  onClick={() => setIsLeagueMenuOpen(false)}
                  className="text-slate-400 hover:text-white p-0.5 rounded-md hover:bg-slate-800"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="space-y-1 max-h-60 overflow-y-auto custom-scrollbar pt-1">
                {LEAGUE_OPTIONS.map((leg) => {
                  const isSelected = leg.id === selectedLeagueId;
                  return (
                    <button
                      key={leg.id}
                      onClick={() => {
                        setSelectedLeagueId(leg.id);
                        setIsLeagueMenuOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/50 font-black'
                          : 'text-slate-300 hover:bg-[#231b42] hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-base">{leg.flag}</span>
                        <span>{leg.name}</span>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-emerald-300" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* TAB SWITCHER OR EUROPEAN BADGE */}
        {activeLeagueConfig.isEuropean ? (
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-xl bg-gradient-to-r from-blue-900/60 to-purple-900/60 border border-purple-500/40 text-amber-300 font-black text-xs flex items-center gap-1.5 shadow">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              UEFA Formatı (36 Takım)
            </span>
          </div>
        ) : (
          <div className="grid grid-cols-4 sm:flex items-center bg-[#1f1938] p-1 rounded-xl border border-[#382d5e] gap-1 w-full md:w-auto">
            <button
              onClick={() => setMainTab('STANDINGS')}
              className={`px-2 py-1 text-center rounded-lg text-[10px] sm:text-xs font-black transition-all ${
                mainTab === 'STANDINGS'
                  ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/50'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t('STANDINGS')}
            </button>
            <button
              onClick={() => setMainTab('TOP_SCORERS')}
              className={`px-2 py-1 text-center rounded-lg text-[10px] sm:text-xs font-black transition-all ${
                mainTab === 'TOP_SCORERS'
                  ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/50'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t('TOP_SCORERS')}
            </button>
            <button
              onClick={() => setMainTab('TOP_ASSISTS')}
              className={`px-2 py-1 text-center rounded-lg text-[10px] sm:text-xs font-black transition-all ${
                mainTab === 'TOP_ASSISTS'
                  ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/50'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t('TOP_ASSISTS')}
            </button>
            <button
              onClick={() => setMainTab('PLAYER_RATINGS')}
              className={`px-2 py-1 text-center rounded-lg text-[10px] sm:text-xs font-black transition-all ${
                mainTab === 'PLAYER_RATINGS'
                  ? 'bg-[#7b2cbf] text-white shadow ring-1 ring-purple-400/50'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t('PLAYER_RATINGS')}
            </button>
          </div>
        )}
      </div>

      {/* RENDER EUROPEAN TOURNAMENTS OR DOMESTIC TABS */}
      {activeLeagueConfig.isEuropean ? (
        <div className="flex-1 min-h-0 overflow-y-auto custom-scrollbar">
          <EuropeanTournamentView
            initialCompId={(selectedLeagueId === 'uel' ? 'uel' : selectedLeagueId === 'uecl' ? 'uecl' : 'ucl')}
            onCompChange={(newId) => setSelectedLeagueId(newId)}
            currentWeek={currentWeek}
            userTeamId={currentTeamId}
          />
        </div>
      ) : (
        <>
          {/* TAB 1: STANDINGS TABLE */}
      {mainTab === 'STANDINGS' && (
        <div className="flex-1 min-h-0 flex flex-col overflow-hidden space-y-2">

          <div className="flex-1 min-h-0 overflow-x-auto overflow-y-auto rounded-xl border border-[#2d244c] bg-[#130f24] custom-fmm-scrollbar pr-0.5 pb-2 touch-auto">
            <table className="w-full text-left border-collapse min-w-[420px]">
            <thead className="sticky top-0 z-10 bg-[#1f1938] border-b border-[#2d244c] text-[10px] uppercase font-black text-slate-400 shadow-sm">
              <tr>
                <th className="py-2 px-2.5 w-8 text-center">{t('POS')}</th>
                <th className="py-2 px-2.5">{t('TABLE_TEAM')}</th>
                <th className="py-2 px-1.5 text-center">{t('PLAYED')}</th>
                <th className="py-2 px-1.5 text-center">{t('WON')}</th>
                <th className="py-2 px-1.5 text-center">{t('DRAWN')}</th>
                <th className="py-2 px-1.5 text-center">{t('LOST')}</th>
                <th className="py-2 px-1.5 text-center hidden sm:table-cell">{t('GOALS_FOR_SHORT')}</th>
                <th className="py-2 px-1.5 text-center hidden sm:table-cell">{t('GOALS_AGAINST_SHORT')}</th>
                <th className="py-2 px-1.5 text-center">{t('GOAL_DIFFERENCE')}</th>
                <th className="py-2 px-2.5 text-center text-emerald-400">{t('POINTS')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#282042] text-[11px] sm:text-xs font-bold">
              {sortedStandings.map((row, index) => {
                const isUserTeam = isPlayingInSelectedLeague && row.teamId === currentTeamId;
                const rank = index + 1;
                const teamObj = activeTeamsList.find(t => t.id === row.teamId) || { id: row.teamId, name: row.teamName };
                const qual = getRankQualification(selectedLeagueId, rank, sortedStandings.length);

                return (
                  <tr
                    key={row.teamId}
                    onClick={() => handleRowClick(row.teamId)}
                    title={qual ? `${teamObj.name} - ${qual.label}` : 'Takım Kadrosunu Göster'}
                    className={`transition-all cursor-pointer relative ${
                      isUserTeam
                        ? 'bg-emerald-500/20 text-white font-extrabold border-l-4 border-l-emerald-400 hover:bg-emerald-500/30'
                        : qual
                        ? `border-l-4 ${qual.borderLeftColor} text-slate-300 hover:bg-[#1e1836]`
                        : 'border-l-4 border-l-transparent text-slate-300 hover:bg-[#1e1836]'
                    }`}
                  >
                    {/* Rank */}
                    <td className="py-2 px-2.5 text-center font-black">
                      <div className="flex items-center justify-center gap-1">
                        <span className={`inline-flex items-center justify-center w-5 h-5 rounded text-[10px] ${
                          rank === 1
                            ? 'bg-amber-500 text-slate-950 font-black shadow-sm'
                            : rank === 2
                            ? 'bg-slate-300 text-slate-950 font-black shadow-sm'
                            : rank === 3
                            ? 'bg-amber-700/80 text-white font-black shadow-sm'
                            : qual
                            ? 'bg-[#1e173a] text-slate-200 border border-slate-700'
                            : 'bg-slate-800 text-slate-400'
                        }`}>
                          {rank}
                        </span>
                      </div>
                    </td>

                    {/* Team Name with TeamBadge logo & European Qualification Indicator */}
                    <td className="py-2 px-2.5">
                      <div className="flex items-center justify-between gap-2">
                        <TeamBadge team={teamObj} size="sm" showName={true} />
                        {qual && (
                          <span
                            className={`hidden md:inline-flex items-center gap-1 text-[9px] font-black px-1.5 py-0.5 rounded border ${qual.badgeBg}`}
                            title={qual.label}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${qual.dotColor}`}></span>
                            {qual.shortLabel}
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Played, Won, Drawn, Lost */}
                    <td className="py-2 px-1.5 text-center text-slate-300 font-bold">{row.played}</td>
                    <td className="py-2 px-1.5 text-center text-emerald-400 font-bold">{row.won}</td>
                    <td className="py-2 px-1.5 text-center text-amber-400 font-bold">{row.drawn}</td>
                    <td className="py-2 px-1.5 text-center text-rose-400 font-bold">{row.lost}</td>

                    <td className="py-2 px-1.5 text-center text-slate-400 hidden sm:table-cell">{row.goalsFor}</td>
                    <td className="py-2 px-1.5 text-center text-slate-400 hidden sm:table-cell">{row.goalsAgainst}</td>

                    {/* Goal Difference */}
                    <td className="py-2 px-1.5 text-center font-extrabold">
                      <span className={row.goalDifference > 0 ? 'text-emerald-400' : row.goalDifference < 0 ? 'text-rose-400' : 'text-slate-400'}>
                        {row.goalDifference > 0 ? `+${row.goalDifference}` : row.goalDifference}
                      </span>
                    </td>

                    {/* Points */}
                    <td className="py-2 px-2.5 text-center font-black text-emerald-400 text-xs sm:text-sm">
                      {row.points}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* LEAGUE QUALIFICATION & RELEGATION LEGEND */}
          {getLeagueLegendItems(selectedLeagueId).length > 0 && (
            <div className="m-2.5 p-2.5 bg-[#17112c]/90 rounded-xl border border-[#2d244c] flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[10px] sm:text-[11px] font-semibold text-slate-300 shadow-inner">
              <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 mr-1">
                {t('EUROPEAN_QUALIFICATION_LEGEND') || 'Kupalara Katılım:'}
              </span>
              {getLeagueLegendItems(selectedLeagueId).map((item, idx) => (
                <div key={idx} className="flex items-center gap-1.5 bg-[#20183e] px-2 py-0.5 rounded-lg border border-[#34275c]">
                  <span className={`w-2 h-2 rounded-full ${item.dotColor} shadow-sm`}></span>
                  <span className="font-bold text-slate-200">{item.label}</span>
                </div>
              ))}
            </div>
          )}
          </div>
        </div>
      )}

      {/* TAB 2: TOP SCORERS TABLE */}
      {mainTab === 'TOP_SCORERS' && (
        <div className="flex-1 min-h-0 overflow-y-auto space-y-4 custom-fmm-scrollbar pr-1">
          <div className="bg-[#130f24] p-3 rounded-xl border border-[#2d244c] space-y-2">
            <div className="flex items-center justify-between border-b border-[#2d244c] pb-2">
              <h4 className="font-black text-xs sm:text-sm text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                {activeLeagueConfig.flag} {activeLeagueConfig.name} {t('TOP_SCORERS')}
              </h4>
              <span className="text-[10px] text-slate-400 font-bold">{t('TOP_15_SCORERS')}</span>
            </div>

            {topScorers.length === 0 ? (
              <p className="text-xs text-slate-400 italic p-3 text-center">{t('NO_GOALS_YET')}</p>
            ) : (
              <div className="space-y-1.5">
                {topScorers.map((item, idx) => (
                  <div
                    key={`scorer-${item.player.id}`}
                    onClick={() => onOpenPlayerProfile && onOpenPlayerProfile(item.player, item.team)}
                    className="p-2 rounded-lg bg-[#19142e] hover:bg-[#231c3f] border border-[#2f254f] flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className={`w-5 h-5 rounded text-[10px] font-black flex items-center justify-center shrink-0 ${
                        idx === 0 ? 'bg-amber-400 text-slate-950' : idx === 1 ? 'bg-slate-300 text-slate-950' : idx === 2 ? 'bg-amber-700 text-white' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {idx + 1}
                      </span>
                      <TeamBadge team={item.team} size="xs" />
                      <div className="min-w-0">
                        <span className="font-extrabold text-xs text-white block truncate">{item.player.name}</span>
                        <span className="text-[10px] text-slate-400 block font-semibold">{item.team.name} • {item.player.position}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 font-black text-xs">
                        {item.player.goalsScored || 0} {t('GOAL_UNIT')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: TOP ASSISTS TABLE */}
      {mainTab === 'TOP_ASSISTS' && (
        <div className="flex-1 min-h-0 overflow-y-auto space-y-4 custom-fmm-scrollbar pr-1">
          <div className="bg-[#130f24] p-3 rounded-xl border border-[#2d244c] space-y-2">
            <div className="flex items-center justify-between border-b border-[#2d244c] pb-2">
              <h4 className="font-black text-xs sm:text-sm text-sky-300 uppercase tracking-wider flex items-center gap-1.5">
                {activeLeagueConfig.flag} {activeLeagueConfig.name} {t('TOP_ASSISTS')}
              </h4>
              <span className="text-[10px] text-slate-400 font-bold">{t('TOP_15_ASSISTS')}</span>
            </div>

            {topAssists.length === 0 ? (
              <p className="text-xs text-slate-400 italic p-3 text-center">{t('NO_ASSISTS_YET')}</p>
            ) : (
              <div className="space-y-1.5">
                {topAssists.map((item, idx) => (
                  <div
                    key={`assist-${item.player.id}`}
                    onClick={() => onOpenPlayerProfile && onOpenPlayerProfile(item.player, item.team)}
                    className="p-2 rounded-lg bg-[#19142e] hover:bg-[#231c3f] border border-[#2f254f] flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className={`w-5 h-5 rounded text-[10px] font-black flex items-center justify-center shrink-0 ${
                        idx === 0 ? 'bg-sky-400 text-slate-950' : idx === 1 ? 'bg-slate-300 text-slate-950' : idx === 2 ? 'bg-amber-700 text-white' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {idx + 1}
                      </span>
                      <TeamBadge team={item.team} size="xs" />
                      <div className="min-w-0">
                        <span className="font-extrabold text-xs text-white block truncate">{item.player.name}</span>
                        <span className="text-[10px] text-slate-400 block font-semibold">{item.team.name} • {item.player.position}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="px-2.5 py-1 rounded-lg bg-sky-500/20 text-sky-300 border border-sky-500/40 font-black text-xs">
                        {item.player.assists || 0} {t('ASSIST_UNIT')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: PLAYER RATINGS TABLE */}
      {mainTab === 'PLAYER_RATINGS' && (
        <div className="flex-1 min-h-0 overflow-y-auto space-y-4 custom-fmm-scrollbar pr-1">
          <div className="bg-[#130f24] p-3 rounded-xl border border-[#2d244c] space-y-2">
            <div className="flex items-center justify-between border-b border-[#2d244c] pb-2">
              <h4 className="font-black text-xs sm:text-sm text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                {activeLeagueConfig.flag} {activeLeagueConfig.name} {t('PLAYER_RATINGS')}
              </h4>
              <span className="text-[10px] text-slate-400 font-bold">{t('TOP_15_RATINGS')}</span>
            </div>

            {topRatings.length === 0 ? (
              <p className="text-xs text-slate-400 italic p-3 text-center">{t('NO_RATINGS_YET')}</p>
            ) : (
              <div className="space-y-1.5">
                {topRatings.map((item, idx) => {
                  const ratingScore = (item.player.lastRating || item.player.form || 7.0).toFixed(1);
                  return (
                    <div
                      key={`rating-${item.player.id}`}
                      onClick={() => onOpenPlayerProfile && onOpenPlayerProfile(item.player, item.team)}
                      className="p-2 rounded-lg bg-[#19142e] hover:bg-[#231c3f] border border-[#2f254f] flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className={`w-5 h-5 rounded text-[10px] font-black flex items-center justify-center shrink-0 ${
                          idx === 0 ? 'bg-purple-400 text-slate-950' : idx === 1 ? 'bg-slate-300 text-slate-950' : idx === 2 ? 'bg-amber-700 text-white' : 'bg-slate-800 text-slate-400'
                        }`}>
                          {idx + 1}
                        </span>
                        <TeamBadge team={item.team} size="xs" />
                        <div className="min-w-0">
                          <span className="font-extrabold text-xs text-white block truncate">{item.player.name}</span>
                          <span className="text-[10px] text-slate-400 block font-semibold">{item.team.name} • {item.player.position} ({item.player.overall} OVR)</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <span className="px-2.5 py-1 rounded-lg bg-purple-500/20 text-purple-300 border border-purple-500/40 font-black text-xs flex items-center gap-1">
                          {t('RATING_LABEL')} {ratingScore}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
      </>
      )}

      {/* TEAM SQUAD & DETAIL MODAL */}
      {selectedDetailTeam && (() => {
        const teamRow = standings.find(s => s.teamId === selectedDetailTeam.id);
        const playedTeamFixtures = fixtures
          .filter(f => f.played && (f.homeTeamId === selectedDetailTeam.id || f.awayTeamId === selectedDetailTeam.id))
          .sort((a, b) => a.week - b.week)
          .slice(-5);

        const avgOvr = Math.round(selectedDetailTeam.players.reduce((a, b) => a + b.overall, 0) / Math.max(1, selectedDetailTeam.players.length));
        const isOwnTeam = selectedDetailTeam.id === currentTeamId;

        return (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-3 animate-in fade-in duration-150">
            <div className="bg-[#181528] border-2 border-[#332b50] rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl text-slate-100 p-3 sm:p-4 space-y-3 max-h-[90vh] flex flex-col">
              
              {/* Modal Header */}
              <div className="flex items-center justify-between border-b border-[#2e264f] pb-2.5 shrink-0">
                <div className="flex items-center gap-3">
                  <TeamBadge team={selectedDetailTeam} size="md" />
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-black text-white text-sm sm:text-base">{selectedDetailTeam.name}</h3>
                      <span className="px-2 py-0.5 rounded-md bg-purple-600/30 border border-purple-500/50 text-purple-300 font-extrabold text-[10px] uppercase">
                        {selectedDetailTeam.players.length} {t('PLAYERS_UNIT')}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 font-semibold">{selectedDetailTeam.stadiumName}</p>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedDetailTeam(null)}
                  className="p-1.5 rounded-xl bg-[#2a2245] hover:bg-[#382e5b] text-slate-300 hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Tab Controls */}
              <div className="flex items-center bg-[#120f21] p-1 rounded-xl border border-[#2d244c] shrink-0">
                <button
                  onClick={() => setTeamModalTab('STATS')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-black transition-all text-center flex items-center justify-center gap-1.5 ${
                    teamModalTab === 'STATS'
                      ? 'bg-purple-600 text-white shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Award className="w-3.5 h-3.5 text-emerald-400" /> {t('CLUB_REPORT_FORM')}
                </button>

                <button
                  onClick={() => setTeamModalTab('SQUAD')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-black transition-all text-center flex items-center justify-center gap-1.5 ${
                    teamModalTab === 'SQUAD'
                      ? 'bg-purple-600 text-white shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Users className="w-3.5 h-3.5 text-amber-300" /> {t('ALL_SQUAD_COUNT', { count: selectedDetailTeam.players.length })}
                </button>
              </div>

              {/* TAB 1: SQUAD LIST WITH TRANSFER BUTTONS */}
              {teamModalTab === 'SQUAD' && (
                <div className="flex-1 overflow-y-auto min-h-0 space-y-1.5 pr-1 custom-scrollbar">
                  <div className="bg-[#120f21] p-2 rounded-xl border border-[#282142] text-[10px] text-slate-400 font-semibold flex items-center justify-between">
                    <span>{t('LEAGUE_TABLE_TEAM_CLICK_HINT')}</span>
                  </div>

                  <div className="space-y-1.5">
                    {[...selectedDetailTeam.players]
                      .sort((a, b) => b.overall - a.overall)
                      .map((player) => (
                        <div
                          key={player.id}
                          onClick={() => {
                            if (onOpenPlayerProfile) {
                              onOpenPlayerProfile(player, selectedDetailTeam);
                            }
                          }}
                          className="p-2 sm:p-2.5 rounded-xl bg-[#130e24] hover:bg-[#1a1430] border border-[#2a2245] flex items-center justify-between gap-2 transition-all shadow cursor-pointer group"
                        >
                          {/* Position & Name */}
                          <div className="flex items-center gap-2 min-w-0 flex-1">
                            <span className={`px-1.5 py-0.5 rounded text-[9px] font-black shrink-0 ${
                              player.position === 'FW' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                              player.position === 'MID' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                              player.position === 'DEF' ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30' :
                              'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            }`}>
                              {player.specificRole || player.position}
                            </span>

                            <div className="min-w-0">
                              <span className="font-extrabold text-white text-xs block truncate group-hover:text-purple-300 transition-colors">
                                {player.name}
                              </span>
                              <span className="text-[10px] text-slate-400 block font-semibold">
                                {player.age} Yaş • €{(player.marketValue / 1_000_000).toFixed(1)}M
                              </span>
                            </div>
                          </div>

                          {/* OVR Badge */}
                          <div className="flex items-center gap-2 shrink-0">
                            <span className="px-2 py-1 rounded-lg bg-purple-950/80 border border-purple-500/40 text-amber-300 font-black text-xs">
                              {player.overall} OVR
                            </span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}

              {/* TAB 2: CLUB STATS & FORM */}
              {teamModalTab === 'STATS' && (
                <div className="flex-1 overflow-y-auto min-h-0 space-y-3 pr-1 custom-scrollbar">
                  
                  {/* Kadro Kalitesi & Bütçe */}
                  <div className="bg-[#130f24] p-3 rounded-xl border border-[#2d244c] space-y-2">
                    <span className="text-[11px] font-black text-emerald-400 uppercase tracking-wider block">
                      ⭐ {t('SQUAD_QUALITY_BUDGET')}
                    </span>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      <div className="p-2 rounded-lg bg-[#19142e] border border-[#312754]">
                        <span className="text-[9px] text-slate-400 uppercase font-bold block">{t('AVERAGE_OVR')}</span>
                        <span className="font-black text-sky-400 text-sm">{avgOvr} OVR</span>
                      </div>
                      <div className="p-2 rounded-lg bg-[#19142e] border border-[#312754]">
                        <span className="text-[9px] text-slate-400 uppercase font-bold block">{t('SQUAD_SIZE')}</span>
                        <span className="font-black text-white text-sm">{selectedDetailTeam.players.length} {t('PLAYERS_UNIT')}</span>
                      </div>
                      <div className="p-2 rounded-lg bg-[#19142e] border border-[#312754]">
                        <span className="text-[9px] text-slate-400 uppercase font-bold block">{t('CLUB_BUDGET')}</span>
                        <span className="font-black text-amber-300 text-sm">€{(selectedDetailTeam.budget / 1_000_000).toFixed(1)}M</span>
                      </div>
                      <div className="p-2 rounded-lg bg-[#19142e] border border-[#312754]">
                        <span className="text-[9px] text-slate-400 uppercase font-bold block">{t('FORMATION_LABEL')}</span>
                        <span className="font-black text-purple-300 text-xs truncate block">{selectedDetailTeam.formation}</span>
                      </div>
                    </div>
                  </div>

                  {/* Gol İstatistikleri */}
                  {teamRow && (
                    <div className="bg-[#130f24] p-3 rounded-xl border border-[#2d244c] space-y-2">
                      <span className="text-[11px] font-black text-amber-400 uppercase tracking-wider block">
                        ⚽ {t('GOAL_STATS_LEAGUE_PERF')}
                      </span>
                      <div className="grid grid-cols-4 gap-2 text-center text-xs">
                        <div className="p-2 rounded-lg bg-[#19142e] border border-[#312754]">
                          <span className="text-[9px] text-slate-400 uppercase font-bold block">{t('GOALS_FOR')}</span>
                          <span className="font-black text-emerald-400 text-base">{teamRow.goalsFor}</span>
                        </div>
                        <div className="p-2 rounded-lg bg-[#19142e] border border-[#312754]">
                          <span className="text-[9px] text-slate-400 uppercase font-bold block">{t('GOALS_AGAINST')}</span>
                          <span className="font-black text-rose-400 text-base">{teamRow.goalsAgainst}</span>
                        </div>
                        <div className="p-2 rounded-lg bg-[#19142e] border border-[#312754]">
                          <span className="text-[9px] text-slate-400 uppercase font-bold block">{t('GOAL_DIFFERENCE')}</span>
                          <span className={`font-black text-base ${teamRow.goalDifference >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {teamRow.goalDifference > 0 ? `+${teamRow.goalDifference}` : teamRow.goalDifference}
                          </span>
                        </div>
                        <div className="p-2 rounded-lg bg-[#19142e] border border-[#312754]">
                          <span className="text-[9px] text-slate-400 uppercase font-bold block">{t('TOTAL_POINTS')}</span>
                          <span className="font-black text-amber-300 text-base">{teamRow.points}</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Son 5 Maçlık Form */}
                  <div className="bg-[#130f24] p-3 rounded-xl border border-[#2d244c] space-y-2">
                    <span className="text-[11px] font-black text-sky-400 uppercase tracking-wider block">
                      📈 {t('RECENT_5_MATCHES_FORM')}
                    </span>

                    {playedTeamFixtures.length === 0 ? (
                      <p className="text-xs text-slate-400 italic">{t('NO_PLAYED_MATCHES_YET') || 'No matches played yet.'}</p>
                    ) : (
                      <div className="flex items-center gap-2 overflow-x-auto custom-scrollbar pb-1">
                        {playedTeamFixtures.map(f => {
                          const isHome = f.homeTeamId === selectedDetailTeam.id;
                          const oppId = isHome ? f.awayTeamId : f.homeTeamId;
                          const opp = allTeams.find(t => t.id === oppId);
                          const myScore = isHome ? (f.homeScore || 0) : (f.awayScore || 0);
                          const oppScore = isHome ? (f.awayScore || 0) : (f.homeScore || 0);

                          let badge = t('FORM_D');
                          let badgeBg = 'bg-amber-500/20 text-amber-300 border-amber-500/40';
                          if (myScore > oppScore) {
                            badge = t('FORM_W');
                            badgeBg = 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
                          } else if (myScore < oppScore) {
                            badge = t('FORM_L');
                            badgeBg = 'bg-rose-500/20 text-rose-400 border-rose-500/40';
                          }

                          return (
                            <div key={f.id} className="p-2 rounded-lg bg-[#19142e] border border-[#312754] flex items-center gap-2 shrink-0">
                              <span className={`w-6 h-6 rounded-md font-black text-xs flex items-center justify-center border ${badgeBg}`}>
                                {badge}
                              </span>
                              <div className="text-[10px]">
                                <span className="font-bold text-white block">{opp ? opp.shortName : oppId}</span>
                                <span className="text-slate-400 font-semibold">{myScore} - {oppScore}</span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Modal Footer */}
              <div className="pt-2 border-t border-[#2e264f] flex justify-end shrink-0">
                <button
                  onClick={() => setSelectedDetailTeam(null)}
                  className="px-4 py-1.5 bg-[#7b2cbf] hover:bg-[#9d4edd] text-white font-extrabold text-xs rounded-xl uppercase"
                >
                  {t('CLOSE')}
                </button>
              </div>

            </div>
          </div>
        );
      })()}

      {/* TRANSFER OFFER MODAL */}
      {offerPlayerModal && activeUserTeam && (
        <TransferOfferModal
          isOpen={true}
          player={offerPlayerModal.player}
          sellerTeam={offerPlayerModal.team}
          userTeam={activeUserTeam}
          onClose={() => setOfferPlayerModal(null)}
          onTransferSuccess={(p) => {
            if (onBuyPlayer) onBuyPlayer(p);
            setOfferPlayerModal(null);
          }}
          showToast={showToast}
        />
      )}

    </div>
  );
};
