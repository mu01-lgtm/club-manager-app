import React, { useState, useEffect } from 'react';
import { MatchEvent, Team } from '../types';
import { Sparkles, X, Shield, Flame, Zap, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useTranslation } from '../utils/i18n';

interface AttackAnimationCanvasProps {
  latestEvent: MatchEvent | null;
  homeTeam: Team;
  awayTeam: Team;
  userTeamId?: string;
  speedMultiplier?: number;
  onResultReached?: (event: MatchEvent) => void;
  onAnimationFinished?: () => void;
}

export type AttackAnimStage = 'RUNNING' | 'RESULT';

export const AttackAnimationCanvas: React.FC<AttackAnimationCanvasProps> = ({
  latestEvent,
  homeTeam,
  awayTeam,
  userTeamId,
  speedMultiplier = 1,
  onResultReached,
  onAnimationFinished
}) => {
  const { t, language } = useTranslation();
  const [animStage, setAnimStage] = useState<AttackAnimStage>('RUNNING');
  const [animKey, setAnimKey] = useState<number>(0);

  const lang = (language || 'TR').toUpperCase();

  // Multi-language text helpers
  const getRadarTicker = () => {
    if (isPenalty) {
      if (lang === 'EN') return isUserAttack ? '🎯 OUR PENALTY' : '⚠️ OPPONENT PENALTY';
      if (lang === 'ES') return isUserAttack ? '🎯 NUESTRO PENALTI' : '⚠️ PENALTI RIVAL';
      if (lang === 'FR') return isUserAttack ? '🎯 NOTRE PENALTY' : '⚠️ PENALTY ADVERSE';
      if (lang === 'IT') return isUserAttack ? '🎯 NOSTRO RIGORE' : '⚠️ RIGORE AVVERSARIO';
      if (lang === 'PT') return isUserAttack ? '🎯 NOSSO PÊNALTI' : '⚠️ PÊNALTI ADVERSÁRIO';
      if (lang === 'DE') return isUserAttack ? '🎯 UNSER ELFMETER' : '⚠️ GEGNER ELFMETER';
      return isUserAttack ? '🎯 BİZİM PENALTI' : '⚠️ RAKİP PENALTI';
    }
    return isUserAttack ? (t('OUR_ATTACK') || 'BİZİM ATAK') : (t('OPPONENT_ATTACK') || 'RAKİP ATAK');
  };

  const getAttackStartMessage = () => {
    if (isPenalty) {
      if (lang === 'EN') return `🎯 ${attackerName} is at the penalty spot!`;
      if (lang === 'ES') return `🎯 ¡${attackerName} en el punto de penalti!`;
      if (lang === 'FR') return `🎯 ${attackerName} est au point de penalty !`;
      if (lang === 'IT') return `🎯 ${attackerName} sul dischetto del rigore!`;
      if (lang === 'PT') return `🎯 ${attackerName} na marca do pênalti!`;
      if (lang === 'DE') return `🎯 ${attackerName} steht am Elfmeterpunkt!`;
      return `🎯 ${attackerName} penaltı noktasında topun başında!`;
    }
    if (lang === 'EN') return `🟣 ${attackerName} is speeding on the counter-attack!`;
    if (lang === 'ES') return `🟣 ¡${attackerName} avanza a toda velocidad al ataque!`;
    if (lang === 'FR') return `🟣 ${attackerName} part à l'attaque à toute vitesse !`;
    if (lang === 'IT') return `🟣 ${attackerName} si lancia in velocità verso l'area!`;
    if (lang === 'PT') return `🟣 ${attackerName} avança rapidamente ao ataque!`;
    if (lang === 'DE') return `🟣 ${attackerName} stürmt mit Tempo nach vorne!`;
    return `🟣 ${attackerName} hızla atağa kalkıyor!`;
  };

  const getGoalHeader = () => {
    if (isPenalty) {
      if (lang === 'EN') return isUserAttack ? 'GOAAAL! PENALTY GOAL!' : 'GOAL! OPPONENT SCORED FROM PENALTY!';
      if (lang === 'ES') return isUserAttack ? '¡GOOOOL! ¡GOL DE PENALTI!' : '¡GOL! ¡RIVAL MARCA DE PENALTI!';
      if (lang === 'FR') return isUserAttack ? 'BUUUT ! BUT SUR PENALTY !' : 'BUT ! L\'ADVERSAIRE MARQUE SUR PENALTY !';
      if (lang === 'IT') return isUserAttack ? 'GOOOOL! GOL SU RIGORE!' : 'GOL! L\'AVVERSARIO SEGNA SU RIGORE!';
      if (lang === 'PT') return isUserAttack ? 'GOOOOL! GOL DE PÊNALTI!' : 'GOL! ADVERSÁRIO MARCA DE PÊNALTI!';
      if (lang === 'DE') return isUserAttack ? 'TOOOR! ELFMETERTOR!' : 'TOR! GEGNER TRIFFT PER ELFMETER!';
      return isUserAttack ? 'GOOOLL! PENALTI GOLÜ!' : 'GOL! RAKİP PENALTIDAN ATTI!';
    }
    if (lang === 'EN') return isUserAttack ? 'GOAAAL! BALL IN THE NET!' : 'GOAL! OPPONENT SCORES!';
    if (lang === 'ES') return isUserAttack ? '¡GOOOOL! ¡EL BALÓN A LA RED!' : '¡GOL! ¡GOL DEL RIVAL!';
    if (lang === 'FR') return isUserAttack ? 'BUUUT ! AU FOND DES FILETS !' : 'BUT ! L\'ADVERSAIRE MARQUE !';
    if (lang === 'IT') return isUserAttack ? 'GOOOOL! LA PALLA È IN RETE!' : 'GOL! L\'AVVERSARIO SEGNA!';
    if (lang === 'PT') return isUserAttack ? 'GOOOOL! BOLA NA REDE!' : 'GOL! GOL DO ADVERSÁRIO!';
    if (lang === 'DE') return isUserAttack ? 'TOOOR! DER BALL ZAPPELT IM NETZ!' : 'TOR! GEGNER TRIFFT!';
    return isUserAttack ? 'GOOOLL! TOP AĞLARDA!' : 'GOL! RAKİP ATTI!';
  };

  const getGoalDetail = () => {
    if (isPenalty) {
      if (lang === 'EN') return `${attackerName} beats goalkeeper ${gkName} from the penalty spot!`;
      if (lang === 'ES') return `¡${attackerName} supera al portero ${gkName} desde los once metros!`;
      if (lang === 'FR') return `${attackerName} trompe le gardien ${gkName} sur penalty !`;
      if (lang === 'IT') return `${attackerName} batte il portiere ${gkName} dal dischetto!`;
      if (lang === 'PT') return `${attackerName} supera o goleiro ${gkName} na cobrança de pênalti!`;
      if (lang === 'DE') return `${attackerName} verwandelt sicher gegen Torwart ${gkName}!`;
      return `${attackerName} penaltı noktasından kaleci ${gkName}'yi mağlup etti!`;
    }
    if (lang === 'EN') return `${attackerName} sends a brilliant strike straight into the net!`;
    if (lang === 'ES') return `¡${attackerName} envía un remate sensacional al fondo de la red!`;
    if (lang === 'FR') return `${attackerName} envoie une frappe magnifique au fond des filets !`;
    if (lang === 'IT') return `${attackerName} spedisce una conclusione fantastica in rete!`;
    if (lang === 'PT') return `${attackerName} manda um chute espetacular para o fundo do gol!`;
    if (lang === 'DE') return `${attackerName} hämmert den Ball mit einem satten Schuss ins Netz!`;
    return `${attackerName} harika bir vuruşla topu ağlara gönderdi!`;
  };

  const getMissHeader = () => {
    if (isSave) {
      if (lang === 'EN') return '🧤 SAVED BY GOALKEEPER!';
      if (lang === 'ES') return '🧤 ¡PARADÓN DEL PORTERO!';
      if (lang === 'FR') return '🧤 ARRÊT DU GARDIEN !';
      if (lang === 'IT') return '🧤 PARATA DEL PORTIERE!';
      if (lang === 'PT') return '🧤 DEFESA DO GOLEIRO!';
      if (lang === 'DE') return '🧤 GLANZPARADE VOM TORWART!';
      return '🧤 KALECİ KORNERE ÇELDİ!';
    }
    if (isPost) {
      if (lang === 'EN') return '💥 HIT THE POST / CROSSBAR!';
      if (lang === 'ES') return '💥 ¡AL PALO / TRAVESAÑO!';
      if (lang === 'FR') return '💥 SUR LE POTEAU !';
      if (lang === 'IT') return '💥 PALO / TRAVERSA!';
      if (lang === 'PT') return '💥 NA TRAVE!';
      if (lang === 'DE') return '💥 PFOSTENTREFFER!';
      return '💥 DİREKTEN DÖNDÜ!';
    }
    if (isBlock) {
      if (lang === 'EN') return '🛡️ BLOCKED BY DEFENSE!';
      if (lang === 'ES') return '🛡️ ¡BLOQUEADO POR LA DEFENSA!';
      if (lang === 'FR') return '🛡️ CONTRÉ PAR LA DÉFENSE !';
      if (lang === 'IT') return '🛡️ MURATO DALLA DIFESA!';
      if (lang === 'PT') return '🛡️ BLOQUEADO PELA DEFESA!';
      if (lang === 'DE') return '🛡️ ABGEWEHRT VON DER ABWEHR!';
      return '🛡️ SAVUNMA ARAYA GİRDİ!';
    }
    if (isCorner) {
      if (lang === 'EN') return '🚩 CORNER WON!';
      if (lang === 'ES') return '🚩 ¡CÓRNER GANADO!';
      if (lang === 'FR') return '🚩 CORNER OBTENU !';
      if (lang === 'IT') return '🚩 CALCIO D\'ANGOLO!';
      if (lang === 'PT') return '🚩 ESCANTEIO CONCEDIDO!';
      if (lang === 'DE') return '🚩 ECKBALL HERAUSGEHOLT!';
      return '🚩 KORNER KAZANILDI!';
    }
    if (isPenalty) {
      if (lang === 'EN') return '❌ PENALTY MISSED!';
      if (lang === 'ES') return '❌ ¡PENALTI FALLADO!';
      if (lang === 'FR') return '❌ PENALTY MANQUÉ !';
      if (lang === 'IT') return '❌ RIGORE SBAGLIATO!';
      if (lang === 'PT') return '❌ PÊNALTI DESPERDIÇADO!';
      if (lang === 'DE') return '❌ ELFMETER VERSCHOSSEN!';
      return '❌ PENALTI KAÇTI!';
    }
    if (lang === 'EN') return '❌ SHOT OFF TARGET!';
    if (lang === 'ES') return '❌ ¡DISPARO FUERA!';
    if (lang === 'FR') return '❌ TIR HORS CADRE !';
    if (lang === 'IT') return '❌ TIRO FUORI BERSAGLIO!';
    if (lang === 'PT') return '❌ CHUTE PRA FORA!';
    if (lang === 'DE') return '❌ SCHUSS NEBEN DAS TOR!';
    return '❌ ŞUT AUTA GİTTİ!';
  };

  const getMissDetail = () => {
    if (isSave) {
      if (lang === 'EN') return `${gkName} makes an incredible reflex save to push ${attackerName}'s shot away!`;
      if (lang === 'ES') return `¡${gkName} saca una mano prodigiosa y detiene el disparo de ${attackerName}!`;
      if (lang === 'FR') return `${gkName} réalise une parade exceptionnelle devant ${attackerName} !`;
      if (lang === 'IT') return `${gkName} compie un intervento miracoloso sul tiro di ${attackerName}!`;
      if (lang === 'PT') return `${gkName} faz uma defesa espetacular no chute de ${attackerName}!`;
      if (lang === 'DE') return `${gkName} pariert sensationell gegen den Schuss von ${attackerName}!`;
      return `${gkName} inanılmaz bir refleksle ${attackerName}'ın şutunu kornere çeldi!`;
    }
    if (isPost) {
      if (lang === 'EN') return `${attackerName} strikes with venom, but the shot smashes against the woodwork!`;
      if (lang === 'ES') return `¡El potente remate de ${attackerName} se estrella contra la madera!`;
      if (lang === 'FR') return `La frappe lourde de ${attackerName} s'écrase sur le poteau !`;
      if (lang === 'IT') return `Il tiro potente di ${attackerName} si stampa sul montante!`;
      if (lang === 'PT') return `O chute forte de ${attackerName} explode na trave!`;
      if (lang === 'DE') return `${attackerName} hämmert das Leder an den Außenpfosten!`;
      return `${attackerName} çok sert vurdu, top direğe çarpıp geri döndü!`;
    }
    if (isBlock) {
      if (lang === 'EN') return `${defenderName} steps in with a crucial goal-line block!`;
      if (lang === 'ES') return `¡${defenderName} realiza una intervención providencial para desviar el balón!`;
      if (lang === 'FR') return `${defenderName} s'interpose de justesse pour sauver la situation !`;
      if (lang === 'IT') return `${defenderName} interviene tempestivamente e blocca la traiettoria!`;
      if (lang === 'PT') return `${defenderName} trava o chute com um carrinho preciso!`;
      if (lang === 'DE') return `${defenderName} blockt den gefährlichen Abschluss in letzter Sekunde!`;
      return `${defenderName} kritik bir müdahaleyle topu engelledi!`;
    }
    if (isCorner) {
      if (lang === 'EN') return `Danger deflected behind by the defense for a corner.`;
      if (lang === 'ES') return `El ataque es despejado a córner por la defensa.`;
      if (lang === 'FR') return `L'action dangereuse est déviée en corner par la défense.`;
      if (lang === 'IT') return `La difesa respinge e concede il corner.`;
      if (lang === 'PT') return `A zaga corta e manda para escanteio.`;
      if (lang === 'DE') return `Die Abwehr klärt zur Ecke.`;
      return `${attackerName}'ın tehlikeli atağında savunma topu kornere yolladı.`;
    }
    if (isPenalty) {
      if (lang === 'EN') return `${attackerName}'s penalty kick flies wide of the goal!`;
      if (lang === 'ES') return `¡El penalti de ${attackerName} se marcha desviado!`;
      if (lang === 'FR') return `Le penalty de ${attackerName} passe à côté !`;
      if (lang === 'IT') return `Il rigore di ${attackerName} finisce a lato!`;
      if (lang === 'PT') return `A cobrança de pênalti de ${attackerName} vai direto para fora!`;
      if (lang === 'DE') return `${attackerName} schießt den Elfmeter am Kasten vorbei!`;
      return `${attackerName}'ın penaltı vuruşu çerçeveyi bulamadı!`;
    }
    if (lang === 'EN') return `${attackerName}'s powerful shot whistles narrowly wide of the post.`;
    if (lang === 'ES') return `El disparo de ${attackerName} se va rozando el poste.`;
    if (lang === 'FR') return `Le tir de ${attackerName} frôle le montant et sort.`;
    if (lang === 'IT') return `Il tiro di ${attackerName} sfiora il palo ed esce.`;
    if (lang === 'PT') return `O chute de ${attackerName} passa raspando a trave.`;
    if (lang === 'DE') return `Der Schuss von ${attackerName} zischt haarscharf am Tor vorbei.`;
    return `${attackerName}'ın sert şutu az farkla auta çıktı.`;
  };

  // Scale animation durations according to speedMultiplier (1x, 2x, 5x)
  const effectiveMultiplier = Math.max(1, speedMultiplier);
  const phase1Duration = Math.max(450, Math.round(2200 / effectiveMultiplier));
  const phase2Duration = Math.max(400, Math.round(2000 / effectiveMultiplier));
  const totalDuration = phase1Duration + phase2Duration;

  useEffect(() => {
    if (!latestEvent?.id) return;

    setAnimKey(prev => prev + 1);
    setAnimStage('RUNNING');

    const resultTimer = setTimeout(() => {
      setAnimStage('RESULT');
      if (onResultReached && latestEvent) {
        onResultReached(latestEvent);
      }
    }, phase1Duration);

    const finishTimer = setTimeout(() => {
      if (onAnimationFinished) {
        onAnimationFinished();
      }
    }, totalDuration);

    return () => {
      clearTimeout(resultTimer);
      clearTimeout(finishTimer);
    };
  }, [latestEvent?.id, effectiveMultiplier, phase1Duration, totalDuration]);

  if (!latestEvent) return null;

  const isGoal = latestEvent.type === 'GOAL';
  const isPenalty = latestEvent.text && (latestEvent.text.includes('PENALTI') || latestEvent.text.includes('Penaltı') || latestEvent.text.includes('penalty'));
  const isCorner = latestEvent.type === 'CORNER' || (latestEvent.text && (latestEvent.text.includes('KORNER') || latestEvent.text.includes('korner') || latestEvent.text.includes('Kornere') || latestEvent.text.includes('kornere')));
  const isSave = latestEvent.type === 'SAVE' || (latestEvent.text && (latestEvent.text.includes('kurtar') || latestEvent.text.includes('Kurtar') || latestEvent.text.includes('SAVE') || latestEvent.text.includes('çeldi')));
  const isPost = latestEvent.text && (latestEvent.text.includes('DİREK') || latestEvent.text.includes('direk') || latestEvent.text.includes('post') || latestEvent.text.includes('crossbar'));
  const isBlock = latestEvent.text && (latestEvent.text.includes('blok') || latestEvent.text.includes('savunma') || latestEvent.text.includes('kesildi') || latestEvent.text.includes('MARKAJ') || latestEvent.text.includes('PRES'));
  const isCard = latestEvent.type === 'YELLOW_CARD' || latestEvent.type === 'RED_CARD';
  
  const eventTeam = latestEvent.isHomeTeamEvent ? homeTeam : awayTeam;
  const defendingTeam = latestEvent.isHomeTeamEvent ? awayTeam : homeTeam;
  const teamBadgeColor = eventTeam?.badgeColor || 'from-purple-600 to-indigo-600';

  const isUserAttack = userTeamId
    ? (latestEvent.teamId ? latestEvent.teamId === userTeamId : (latestEvent.isHomeTeamEvent ? homeTeam.id === userTeamId : awayTeam.id === userTeamId))
    : latestEvent.isHomeTeamEvent;

  // Attacker Name
  let attackerName = '';
  const rawAttacker = latestEvent.playerName || '';
  const isGenericAttacker = !rawAttacker || 
    rawAttacker.toLowerCase().includes('forvet') || 
    rawAttacker.toLowerCase().includes('bizim') || 
    rawAttacker.toLowerCase().includes('rakip') || 
    rawAttacker.toLowerCase().includes('oyuncu') ||
    rawAttacker.toLowerCase().includes('striker');

  if (!isGenericAttacker) {
    attackerName = rawAttacker;
  } else if (eventTeam?.players && eventTeam.players.length > 0) {
    const fw = eventTeam.players.find(p => p.position === 'FW' && !p.isInjured) || 
               eventTeam.players.find(p => p.position === 'MID' && !p.isInjured) || 
               eventTeam.players[10] || 
               eventTeam.players[0];
    attackerName = fw ? fw.name : eventTeam.name;
  } else {
    attackerName = eventTeam.shortName || eventTeam.name;
  }

  // Defender Name
  let defenderName = latestEvent.defenderName || '';
  const isGenericDefender = !defenderName || 
    defenderName.toLowerCase().includes('bizim') || 
    defenderName.toLowerCase().includes('stoper') || 
    defenderName.toLowerCase().includes('savunma') || 
    defenderName.toLowerCase().includes('rakip') ||
    defenderName.toLowerCase().includes('defender') ||
    defenderName.toLowerCase().includes('oyuncu');

  if (isGenericDefender) {
    const defPlayer = defendingTeam?.players?.find(p => p.position === 'DEF' && !p.isInjured) || 
                      defendingTeam?.players?.find(p => p.position !== 'GK' && !p.isInjured) ||
                      defendingTeam?.players?.[1];
    defenderName = defPlayer ? defPlayer.name : defendingTeam.name;
  }

  // Goalkeeper Name
  let gkName = latestEvent.gkName || '';
  const isGenericGK = !gkName || 
    gkName.toLowerCase().includes('bizim') || 
    gkName.toLowerCase().includes('kaleci') || 
    gkName.toLowerCase().includes('rakip') ||
    gkName.toLowerCase().includes('goalkeeper') ||
    gkName.toLowerCase().includes('keeper');

  if (isGenericGK) {
    const gkPlayer = defendingTeam?.players?.find(p => p.position === 'GK' && !p.isInjured) || 
                    defendingTeam?.players?.[0];
    gkName = gkPlayer ? gkPlayer.name : defendingTeam.name;
  }

  return (
    <div className={`relative w-full border-2 rounded-2xl p-2.5 shadow-2xl overflow-hidden shrink-0 select-none transition-colors duration-500 ${
      isUserAttack
        ? 'bg-gradient-to-b from-[#091f16] via-[#071710] to-[#040e0a] border-emerald-500/50'
        : 'bg-gradient-to-b from-[#2a0a0a] via-[#1a0606] to-[#0c0202] border-rose-500/60'
    }`}>
      
      {/* Inline Embedded Keyframes for Straight Clean Ball Animation */}
      <style>{`
        @keyframes glidetoGoal {
          0% {
            left: ${isPenalty ? '58%' : '14%'};
            top: 50%;
            transform: translateY(-50%) scale(0.95);
          }
          100% {
            left: 82%;
            top: 50%;
            transform: translateY(-50%) scale(1.1);
          }
        }
        @keyframes ballFastSpin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(720deg); }
        }
      `}</style>

      {/* Field Grass Pattern Background */}
      <div className={`absolute inset-0 pointer-events-none ${
        isUserAttack
          ? 'bg-[repeating-linear-gradient(90deg,rgba(16,185,129,0.06),rgba(16,185,129,0.06)_30px,transparent_30px,transparent_60px)]'
          : 'bg-[repeating-linear-gradient(90deg,rgba(244,63,94,0.06),rgba(244,63,94,0.06)_30px,transparent_30px,transparent_60px)]'
      }`} />
      <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px] opacity-15 pointer-events-none" />

      {/* Top Header Live Ticker */}
      <div className="flex items-center justify-between mb-2 relative z-10 px-1 gap-2">
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="relative flex h-2.5 w-2.5">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isUserAttack ? 'bg-emerald-400' : 'bg-rose-400'}`} />
            <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${isUserAttack ? 'bg-emerald-500' : 'bg-rose-500'}`} />
          </span>
          <span className={`text-[10px] font-black uppercase tracking-wider flex items-center gap-1 ${isUserAttack ? 'text-emerald-300' : 'text-rose-300'}`}>
            <Flame className={`w-3.5 h-3.5 animate-bounce ${isUserAttack ? 'text-amber-400' : 'text-rose-400'}`} />
            {getRadarTicker()} ({latestEvent.minute}')
          </span>
        </div>

        {/* 1. AŞAMA: MOR YAZILI CANLI ATAK MESAJI */}
        <div className="bg-purple-950/90 border border-purple-400/80 px-2.5 sm:px-3 py-0.5 rounded-full shadow-[0_0_15px_rgba(168,85,247,0.7)] flex items-center gap-1.5 animate-pulse truncate">
          <span className="w-2 h-2 rounded-full bg-purple-300 animate-ping shrink-0" />
          <span className="text-[9.5px] sm:text-[10.5px] font-black text-purple-100 truncate">
            {getAttackStartMessage()}
          </span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <span className="px-2 py-0.5 rounded-full text-[9px] font-black text-amber-300 bg-[#140e2b] border border-amber-500/40 shadow">
            {attackerName}
          </span>
          <span className={`px-2 py-0.5 rounded-full text-[8.5px] font-black text-white bg-gradient-to-r ${teamBadgeColor} shadow`}>
            {eventTeam?.shortName || 'TAKIM'}
          </span>
        </div>
      </div>

      {/* Main Pitch Canvas Area */}
      <div className={`relative h-40 sm:h-48 w-full rounded-xl border overflow-hidden flex items-center justify-center shadow-inner transition-colors duration-500 ${
        isUserAttack
          ? 'bg-gradient-to-r from-emerald-950 via-emerald-900/90 to-emerald-950 border-emerald-500/50'
          : 'bg-gradient-to-r from-rose-950 via-stone-900/90 to-rose-950 border-rose-500/50'
      }`}>
        
        {/* Pitch Tactical Markings */}
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-28 h-44 border-2 border-white/20 rounded-r-full pointer-events-none" />
        <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-white/20 pointer-events-none" />

        {/* Penalty Area (Right) */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-44 h-36 border-2 border-white/30 rounded-l-xl bg-white/5 pointer-events-none" />
        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-16 h-20 border-2 border-white/40 rounded-l-md bg-white/10 pointer-events-none" />
        <div className="absolute right-32 top-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full bg-white/80 pointer-events-none shadow" />

        {/* 3D Goal Net Effect on Far Right */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-6 h-28 border-y-2 border-l-2 border-amber-300 bg-amber-400/30 shadow-[0_0_25px_rgba(251,191,36,0.7)] z-10 flex items-center justify-center rounded-l-sm">
          <div className="w-full h-full bg-[repeating-linear-gradient(45deg,transparent,transparent_3px,rgba(255,255,255,0.5)_3px,rgba(255,255,255,0.5)_6px)]" />
        </div>

        {/* Defender Token (HIDDEN IN PENALTIES AS REQUESTED) */}
        {!isPenalty && (
          <div className={`absolute top-1/2 -translate-y-1/2 flex flex-col items-center gap-0.5 z-10 transition-all duration-1000 ${
            animStage === 'RUNNING' ? 'right-28 scale-105' : 'right-36 scale-100'
          }`}>
            <div className={`w-8 h-8 rounded-full border-2 border-white shadow-xl flex items-center justify-center text-[10px] font-black text-white ${
              isUserAttack ? 'bg-rose-600' : 'bg-emerald-600'
            }`}>
              DEF
            </div>
            <span className="text-[8px] font-extrabold text-slate-100 bg-slate-950/90 px-1.5 py-0.2 rounded border border-slate-700/60 shadow truncate max-w-[85px]" title={defenderName}>
              {defenderName}
            </span>
          </div>
        )}

        {/* Goalkeeper Token */}
        <div className={`absolute top-1/2 -translate-y-1/2 flex flex-col items-center gap-0.5 z-10 transition-all duration-700 ${
          animStage === 'RUNNING' ? 'right-8 animate-bounce' : 'right-10'
        }`}>
          <div className="w-8 h-8 rounded-full bg-amber-500 border-2 border-white shadow-xl flex items-center justify-center text-[10px] font-black text-slate-950">
            GK
          </div>
          <span className="text-[8px] font-extrabold text-amber-200 bg-slate-950/90 px-1.5 py-0.2 rounded border border-amber-500/50 shadow truncate max-w-[85px]" title={gkName}>
            {gkName}
          </span>
        </div>

        {/* Attacker Token (Positioned at penalty spot right in front of GK for Penalties) */}
        <div className={`absolute top-1/2 -translate-y-1/2 flex flex-col items-center gap-0.5 z-10 transition-all duration-500 ${
          isPenalty
            ? 'right-32 scale-110 ring-4 ring-amber-400 rounded-full'
            : animStage === 'RUNNING'
            ? 'left-10 scale-110 ring-4 ring-purple-400 rounded-full'
            : 'left-10 scale-100'
        }`}>
          <div className={`w-9 h-9 rounded-full border-2 border-white shadow-xl flex items-center justify-center text-[11px] font-black ${
            isUserAttack ? 'bg-emerald-500 text-slate-950' : 'bg-rose-600 text-white'
          }`}>
            {isPenalty ? 'PEN' : 'ST'}
          </div>
          <span className={`text-[8px] font-black bg-slate-950/90 px-1.5 py-0.2 rounded border shadow truncate max-w-[85px] ${
            isUserAttack ? 'text-emerald-200 border-emerald-500/50' : 'text-rose-200 border-rose-500/50'
          }`} title={attackerName}>
            {attackerName}
          </span>
        </div>

        {/* 2. AŞAMA: TOP HAREKETİ VE TOPUN YANINDA OYUNCU İSMİ */}
        <div
          key={animKey}
          className={`absolute top-1/2 -translate-y-1/2 z-20 ease-out flex items-center gap-2 ${
            animStage === 'RUNNING'
              ? 'left-[70%] scale-125'
              : isGoal
              ? 'right-2 scale-110'
              : isPost
              ? 'right-10 scale-105'
              : isSave
              ? 'right-12 scale-100'
              : isBlock
              ? 'right-24 scale-95'
              : isCorner
              ? 'right-14 scale-95'
              : 'right-16 scale-95'
          }`}
          style={animStage === 'RUNNING' ? { animation: `glidetoGoal ${phase1Duration}ms ease-out forwards` } : { transition: `all ${phase1Duration}ms ease-out` }}
        >
          {/* Animated Ball */}
          <div className="relative flex items-center justify-center">
            <div className={`text-2xl sm:text-3xl filter drop-shadow-[0_4px_14px_rgba(251,191,36,0.95)] ${
              animStage === 'RUNNING' ? 'animate-spin' : ''
            }`}>
              ⚽
            </div>
            {animStage === 'RUNNING' && (
              <div className="absolute -left-12 top-1/2 -translate-y-1/2 w-14 h-4 bg-gradient-to-r from-transparent via-purple-500 to-amber-300 rounded-full blur-xs opacity-90" />
            )}
          </div>

          {/* Oyuncu İsmi Topun Yanında */}
          <div className="bg-[#190d33]/95 border border-purple-400 text-purple-100 px-2.5 py-0.5 rounded-full shadow-[0_0_14px_rgba(168,85,247,0.8)] flex items-center gap-1.5 shrink-0 whitespace-nowrap animate-pulse">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
            <span className="text-[9.5px] sm:text-[10.5px] font-black text-amber-300">
              {attackerName}
            </span>
          </div>
        </div>

        {/* 3. AŞAMA: ATAK SONUCU MODERN BİLDİRİM KARTI */}
        {animStage === 'RESULT' && (
          <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/85 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200 px-3">
            
            {/* 1. GOL İSE: MODERN ULTRA ŞIK GOLL BİLDİRİMİ */}
            {isGoal && (
              <div className={`relative flex flex-col items-center justify-center text-center p-3 sm:p-4 rounded-2xl border-2 shadow-2xl overflow-hidden max-w-[94%] ${
                isUserAttack
                  ? 'bg-gradient-to-br from-emerald-950 via-[#0a2e1d] to-teal-950 border-emerald-400 shadow-[0_0_40px_rgba(16,185,129,0.7)]'
                  : 'bg-gradient-to-br from-rose-950 via-[#3a0808] to-red-950 border-rose-400 shadow-[0_0_40px_rgba(225,29,72,0.7)]'
              }`}>
                <div className="flex items-center gap-2">
                  <span className="text-xl sm:text-2xl animate-bounce">⚽</span>
                  <span className={`text-base sm:text-xl font-black tracking-widest uppercase drop-shadow-md ${
                    isUserAttack ? 'text-emerald-300' : 'text-rose-300'
                  }`}>
                    {getGoalHeader()}
                  </span>
                  <Sparkles className="w-5 h-5 text-amber-300 animate-spin" />
                </div>
                <div className="mt-1.5 px-3 py-1 rounded-xl bg-slate-950/60 border border-white/10 text-xs sm:text-sm font-extrabold text-amber-200 shadow-inner">
                  {getGoalDetail()}
                </div>
              </div>
            )}

            {/* 2. GOL DEĞİLSE: ZENGİN VE MODERN ATAK SONUÇLARI */}
            {!isGoal && !isCard && (
              <div className="relative flex flex-col items-center justify-center text-center p-3 sm:p-4 rounded-2xl bg-gradient-to-br from-[#1b1238] via-[#100b24] to-[#0a0717] border-2 border-purple-400/80 shadow-[0_0_30px_rgba(168,85,247,0.5)] max-w-[94%]">
                <div className="flex items-center gap-2">
                  {isSave ? (
                    <span className="text-2xl">🧤</span>
                  ) : isPost ? (
                    <span className="text-2xl">💥</span>
                  ) : isBlock ? (
                    <Shield className="w-5 h-5 text-purple-300" />
                  ) : isCorner ? (
                    <span className="text-2xl">🚩</span>
                  ) : isPenalty ? (
                    <span className="text-2xl">❌</span>
                  ) : (
                    <X className="w-5 h-5 text-amber-400 stroke-[3]" />
                  )}
                  <span className="text-sm sm:text-base font-black text-white tracking-wider uppercase drop-shadow">
                    {getMissHeader()}
                  </span>
                </div>
                <div className="mt-1.5 px-3 py-1 rounded-xl bg-[#0e0a20]/80 border border-purple-500/30 text-xs font-bold text-purple-200">
                  {getMissDetail()}
                </div>
              </div>
            )}

            {/* 3. SARI / KIRMIZI KART / FAUL MODERN BİLDİRİMİ */}
            {isCard && (
              <div className="flex flex-col items-center justify-center p-3 sm:p-4 rounded-2xl bg-gradient-to-br from-[#241708] via-[#1a1106] to-slate-950 border-2 border-amber-400 shadow-[0_0_30px_rgba(251,191,36,0.6)] text-center max-w-[94%]">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                  <span className="text-sm sm:text-base font-black text-amber-300 uppercase tracking-wide">
                    {lang === 'EN' ? '⚠️ REFEREE BLOWS WHISTLE & CARD SHOWN' :
                     lang === 'ES' ? '⚠️ ¡EL ÁRBITRO PITA Y SACA TARJETA!' :
                     lang === 'FR' ? '⚠️ COUP DE SIFFLET ET CARTON DISTRIBUÉ' :
                     lang === 'IT' ? '⚠️ FISCHIO DELL\'ARBITRO E CARTELLINO' :
                     lang === 'PT' ? '⚠️ ÁRBITRO APITA E MOSTRA CARTÃO' :
                     lang === 'DE' ? '⚠️ PFIFF DES SCHIEDSRICHTERS & KARTE' :
                     '⚠️ HAKEM DÜDÜĞÜNÜ ÇALDI & KART ÇIKTI'}
                  </span>
                </div>
                <span className="text-xs font-extrabold text-slate-200 mt-1">
                  {lang === 'EN' ? 'Play stopped after a heavy tackle challenge.' :
                   lang === 'ES' ? 'Juego detenido tras una dura entrada.' :
                   lang === 'FR' ? 'Le jeu est arrêté suite à un duel appuyé.' :
                   lang === 'IT' ? 'Gioco fermo dopo un contrasto duro.' :
                   lang === 'PT' ? 'Jogo interrompido após disputa ríspida.' :
                   lang === 'DE' ? 'Spiel unterbrochen nach hartem Zweikampf.' :
                   'Sert ikili mücadele sonrasında oyun durdu.'}
                </span>
              </div>
            )}

          </div>
        )}

      </div>

    </div>
  );
};
