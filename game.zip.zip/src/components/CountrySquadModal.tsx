import React, { useState } from 'react';
import { Player, Team } from '../types';
import { X, Globe, Search, Shield, ArrowRight, ChevronRight, DollarSign, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';

interface CountrySquadModalProps {
  isOpen: boolean;
  onClose: () => void;
  countryName: string;
  allTeams: Team[];
  userTeam: Team;
  onTransferPlayer: (player: Player, sellerTeam: Team, buyerTeamId: string, transferFee: number) => void;
  showToast: (type: 'success' | 'error' | 'info', title: string, message: string) => void;
  onSelectPlayer?: (player: Player, team: Team) => void;
}

const FLAG_EMOJIS: Record<string, string> = {
  'Türkiye': '🇹🇷',
  'Uruguay': '🇺🇾',
  'Brezilya': '🇧🇷',
  'Arjantin': '🇦🇷',
  'Nijerya': '🇳🇬',
  'Kolombiya': '🇨🇴',
  'Danimarka': '🇩🇰',
  'Senegal': '🇸🇳',
  'Belçika': '🇧🇪',
  'Macaristan': '🇭🇺',
  'Almanya': '🇩🇪',
  'Hırvatistan': '🇭🇷',
  'Gana': '🇬🇭',
  'Hollanda': '🇳🇱',
  'Fas': '🇲🇦',
  'Fransa': '🇫🇷',
  'Polonya': '🇵🇱',
  'Sırbistan': '🇷🇸',
  'Bosna Hersek': '🇧🇦',
  'Norveç': '🇳🇴',
  'Kongo': '🇨🇩',
  'Libya': '🇱🇾',
  'Portekiz': '🇵🇹',
  'Kosova': '🇽🇰',
  'İtalya': '🇮🇹',
  'Arnavutluk': '🇦🇱',
  'Surinam': '🇸🇷',
  'Karadağ': '🇲🇪',
  'İngiltere': '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
  'Kuzey Makedonya': '🇲🇰',
  'Avusturya': '🇦🇹',
  'Romanya': '🇷🇴',
  'Yunanistan': '🇬🇷',
  'Çad': '🇹🇩',
  'Slovakya': '🇸🇰',
  'İspanya': '🇪🇸',
  'Kamerun': '🇨🇲'
};

export const CountrySquadModal: React.FC<CountrySquadModalProps> = ({
  isOpen,
  onClose,
  countryName,
  allTeams,
  userTeam,
  onTransferPlayer,
  showToast,
  onSelectPlayer
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [positionFilter, setPositionFilter] = useState<'ALL' | 'GK' | 'DEF' | 'MID' | 'FW'>('ALL');
  const [squadView, setSquadView] = useState<'NATIONAL_TEAM_ONLY' | 'ALL_LEGIONNAIRES'>('NATIONAL_TEAM_ONLY');
  const [selectedPlayer, setSelectedPlayer] = useState<{ player: Player; team: Team } | null>(null);
  const [offerFee, setOfferFee] = useState<number>(0);
  const [negotiationResult, setNegotiationResult] = useState<{ status: 'IDLE' | 'SUCCESS' | 'REJECTED'; message: string } | null>(null);

  if (!isOpen) return null;

  const flagEmoji = FLAG_EMOJIS[countryName] || '🌐';

  // Find all players of specified nationality across all teams
  const allNationalPlayers: { player: Player; team: Team }[] = [];
  allTeams.forEach(team => {
    team.players.forEach(p => {
      const pNation = p.nationality || 'Türkiye';
      if (pNation.toLowerCase() === countryName.toLowerCase()) {
        allNationalPlayers.push({ player: p, team });
      }
    });
  });

  // Sort all national players by overall rating descending
  allNationalPlayers.sort((a, b) => b.player.overall - a.player.overall);

  // Top 26 players form the official National A-Team Squad roster
  const nationalTeamSquadIds = new Set(allNationalPlayers.slice(0, 26).map(item => item.player.id));

  // Determine active dataset based on squadView filter
  const activeDataset = squadView === 'NATIONAL_TEAM_ONLY'
    ? allNationalPlayers.filter(item => nationalTeamSquadIds.has(item.player.id))
    : allNationalPlayers;

  // Filter by search & position
  const filteredPlayers = activeDataset.filter(({ player }) => {
    const matchesSearch = player.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPos = positionFilter === 'ALL' || player.position === positionFilter;
    return matchesSearch && matchesPos;
  });

  const handleOpenOfferModal = (item: { player: Player; team: Team }) => {
    setSelectedPlayer(item);
    setOfferFee(Math.round((item.player.marketValue || 5000000) * 1.1));
    setNegotiationResult({ status: 'IDLE', message: '' });
  };

  const handleSendOffer = () => {
    if (!selectedPlayer) return;
    const { player, team: sellerTeam } = selectedPlayer;

    if (sellerTeam.id === userTeam.id) {
      setNegotiationResult({
        status: 'REJECTED',
        message: 'Bu oyuncu zaten sizin takımınızda forma giyiyor!'
      });
      return;
    }

    if (offerFee > userTeam.budget) {
      setNegotiationResult({
        status: 'REJECTED',
        message: `Yetersiz bütçe! Bütçeniz: €${(userTeam.budget / 1_000_000).toFixed(1)}M, Teklif: €${(offerFee / 1_000_000).toFixed(1)}M`
      });
      return;
    }

    const marketValue = player.marketValue || 5000000;
    const isYoung = player.age <= 21 && player.overall >= 72;
    const isKeyStarter = player.isStarting && player.overall >= 78;
    const isHighWageOrSaudiMLS = sellerTeam.country === 'Suudi Arabistan' || sellerTeam.country === 'Amerika B. D.' || (player.wage && player.wage >= 200000);

    let minAcceptableFee = marketValue * 1.15;

    if (isYoung) {
      minAcceptableFee = marketValue * 2.0;
    } else if (isKeyStarter) {
      minAcceptableFee = marketValue * 1.6;
    } else if (player.overall >= 84) {
      minAcceptableFee = marketValue * 1.4;
    } else if (player.age > 33) {
      minAcceptableFee = marketValue * 0.95;
    }

    if (offerFee < minAcceptableFee) {
      setNegotiationResult({
        status: 'REJECTED',
        message: isYoung
          ? `${sellerTeam.name} yönetimi: "${player.name} (${player.age} yaş) kulübümüzün geleceğidir. Gelişime açık genç yeteneğimizi en az €${(minAcceptableFee / 1_000_000).toFixed(1)}M almadan vermeyiz!"`
          : isKeyStarter
          ? `${sellerTeam.name} yönetimi: "${player.name} ilk 11'in değişmez oyuncusudur. En az €${(minAcceptableFee / 1_000_000).toFixed(1)}M teklif edilmelidir."`
          : `${sellerTeam.name} yönetimi: "${player.name} için bu teklif yetersizdir. En az €${(minAcceptableFee / 1_000_000).toFixed(1)}M talep ediyoruz."`
      });
      return;
    }

    // Player Willingness Check
    if (isHighWageOrSaudiMLS && offerFee < marketValue * 2.1) {
      setNegotiationResult({
        status: 'REJECTED',
        message: `KULÜP KABUL ETTİ FAKAT OYUNCU REDDETTİ! ❌ ${player.name}, Suudi Arabistan / MLS / Avrupa kulübündeki yüksek kazançlı sözleşmesini bırakıp gelmek istemiyor!`
      });
      return;
    }

    setNegotiationResult({
      status: 'SUCCESS',
      message: `Tebrikler! ${sellerTeam.name} kulübü €${(offerFee / 1_000_000).toFixed(1)}M bonservis teklifini KABUL ETTİ!`
    });
    onTransferPlayer(player, sellerTeam, userTeam.id, offerFee);
    showToast('success', 'Transfer Tamamlandı!', `${player.name} €${(offerFee / 1_000_000).toFixed(1)}M bonservis bedeliyle ${userTeam.name} kadrosuna katıldı.`);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4">
      <div className="bg-[#120f21] border border-[#302652] w-full max-w-4xl h-[92vh] sm:h-[88vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden text-white animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-[#1b1535] via-[#2a1e50] to-[#1b1535] p-3 sm:p-4 border-b border-[#302652] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-[#7b2cbf] to-[#3a0ca3] border border-[#9d4edd] flex items-center justify-center text-2xl shadow-lg shrink-0">
              {flagEmoji}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm sm:text-lg font-black tracking-wide text-white">
                  {countryName.toUpperCase()} MİLLİ TAKIM KADROSU
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-purple-500/20 border border-purple-500/40 text-purple-300 font-extrabold text-[10px]">
                  {allNationalPlayers.length} Oyuncu
                </span>
              </div>
              <p className="text-[10px] sm:text-xs text-slate-400 font-medium">
                Süper Lig ve lig veritabanındaki tüm {countryName} uyruklu futbolcular
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-all active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filters Bar */}
        <div className="p-2 sm:p-3 bg-[#18142b] border-b border-[#2b2247] flex flex-wrap items-center justify-between gap-2 shrink-0">
          {/* Squad Type Toggle (A Milli Takım vs Tüm Lejyonerler) */}
          <div className="flex items-center gap-1 bg-[#120f21] p-1 rounded-xl border border-[#2b2247] text-[10px] font-bold">
            <button
              onClick={() => setSquadView('NATIONAL_TEAM_ONLY')}
              className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 ${
                squadView === 'NATIONAL_TEAM_ONLY'
                  ? 'bg-[#7b2cbf] text-white font-black shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>🌟 A Milli Takım (26 Kişi)</span>
            </button>

            <button
              onClick={() => setSquadView('ALL_LEGIONNAIRES')}
              className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 ${
                squadView === 'ALL_LEGIONNAIRES'
                  ? 'bg-[#7b2cbf] text-white font-black shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>🌐 Tüm Havuz ({allNationalPlayers.length})</span>
            </button>
          </div>

          {/* Position Tabs */}
          <div className="flex items-center gap-1 bg-[#120f21] p-1 rounded-xl border border-[#2b2247] text-[10px] font-bold">
            {(['ALL', 'GK', 'DEF', 'MID', 'FW'] as const).map(pos => (
              <button
                key={pos}
                onClick={() => setPositionFilter(pos)}
                className={`px-2.5 py-1 rounded-lg transition-all ${
                  positionFilter === pos
                    ? 'bg-[#7b2cbf] text-white font-black shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {pos === 'ALL' ? 'TÜMÜ' : pos === 'GK' ? 'KL' : pos === 'DEF' ? 'DEF' : pos === 'MID' ? 'OS' : 'FVT'}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative flex-1 min-w-[160px] max-w-xs">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Oyuncu adı ara..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full bg-[#120f21] border border-[#2b2247] rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors"
            />
          </div>
        </div>

        {/* Main Roster Grid */}
        <div className="p-2 sm:p-4 flex-1 overflow-y-auto custom-scrollbar bg-[#120f21]">
          {filteredPlayers.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-center p-4 text-slate-500">
              <Globe className="w-10 h-10 mb-2 stroke-[1.5]" />
              <p className="text-xs font-bold">Aramanızla eşleşen {countryName} uyruklu oyuncu bulunamadı.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
              {filteredPlayers.map(({ player, team }) => {
                const isUserTeamPlayer = team.id === userTeam.id;
                const formattedVal = `€${((player.marketValue || 5000000) / 1_000_000).toFixed(1)}M`;
                const formattedWage = `€${((player.wage || 25000) / 1000).toFixed(0)}k/hf`;
                const calcPot = player.potential || (
                  player.age <= 21
                    ? Math.min(99, player.overall + 10)
                    : player.age <= 25
                    ? Math.min(99, player.overall + 4)
                    : player.overall
                );

                return (
                  <div
                    key={player.id}
                    onClick={() => onSelectPlayer?.(player, team)}
                    className="bg-[#18142b] border border-[#2b2247] hover:border-[#7b2cbf] hover:bg-[#201a39] rounded-2xl p-2.5 sm:p-3 flex items-center justify-between gap-3 shadow-lg transition-all group cursor-pointer"
                    title="Oyuncu profilini görüntülemek için tıklayın"
                  >
                    {/* Left: OVR Badge & Details */}
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#7b2cbf] to-[#3a0ca3] border border-[#9d4edd] flex flex-col items-center justify-center shrink-0 shadow">
                        <span className="text-xs font-black text-amber-300 leading-none">{player.overall}</span>
                        <span className="text-[8px] font-extrabold text-slate-300 uppercase mt-0.5">{player.specificRole || player.position}</span>
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h4 className="font-extrabold text-xs sm:text-sm text-white group-hover:text-purple-300 transition-colors truncate">
                            {player.name}
                          </h4>
                          <span className="text-[10px] text-slate-400 font-bold">({player.age} yaş)</span>
                          <span className="text-[10px] text-emerald-400 font-extrabold bg-emerald-950/60 border border-emerald-500/30 px-1.5 py-0.2 rounded">
                            CA: {player.overall}
                          </span>
                          <span className="text-[10px] text-amber-300 font-extrabold bg-amber-950/60 border border-amber-500/30 px-1.5 py-0.2 rounded">
                            PA: {calcPot} ⭐
                          </span>
                        </div>

                        <div className="flex items-center gap-2 mt-1 text-[10px] font-semibold text-slate-300 flex-wrap">
                          <span className="px-1.5 py-0.5 rounded bg-[#221c3b] border border-[#342a59] text-amber-300 font-bold">
                            {formattedVal}
                          </span>
                          <span className="px-1.5 py-0.5 rounded bg-[#221c3b] border border-[#342a59] text-sky-300">
                            {formattedWage}
                          </span>
                          <div className="flex items-center gap-1 font-bold text-slate-300">
                            <Shield className="w-3 h-3 text-purple-400" />
                            <span className={isUserTeamPlayer ? 'text-emerald-400 font-black' : 'text-slate-300'}>
                              {team.name}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Right: Chevron Indicator */}
                    <div className="p-1.5 rounded-xl bg-purple-900/20 group-hover:bg-[#7b2cbf] text-purple-300 group-hover:text-white border border-purple-500/20 transition-all shrink-0">
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#18142b] border-t border-[#2b2247] flex items-center justify-between text-xs shrink-0">
          <span className="text-slate-400 font-medium">
            Bütçeniz: <strong className="text-emerald-400">€{(userTeam.budget / 1_000_000).toFixed(1)}M</strong>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-extrabold"
          >
            Kapat
          </button>
        </div>

      </div>

      {/* Transfer Offer Sub-Modal */}
      {selectedPlayer && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex items-center justify-center p-3">
          <div className="bg-[#18142b] border border-[#3b2d63] w-full max-w-md rounded-2xl p-4 shadow-2xl space-y-3.5 text-white animate-in zoom-in duration-150">
            
            <div className="flex items-center justify-between border-b border-[#2b2247] pb-2">
              <h4 className="font-extrabold text-sm uppercase text-purple-300 flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-400" /> Transfer Görüşmesi
              </h4>
              <button
                onClick={() => setSelectedPlayer(null)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Target Player Card */}
            <div className="bg-[#120f21] border border-[#2b2247] p-3 rounded-xl flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center font-black text-amber-300 text-sm shrink-0">
                {selectedPlayer.player.overall}
              </div>
              <div className="flex-1 min-w-0">
                <span className="font-black text-sm text-white block truncate">{selectedPlayer.player.name}</span>
                <span className="text-[11px] text-slate-400 block">
                  {selectedPlayer.team.name} • {selectedPlayer.player.age} Yaş • {selectedPlayer.player.specificRole || selectedPlayer.player.position}
                </span>
                <span className="text-[11px] text-amber-300 font-bold block mt-0.5">
                  Piyasa Değeri: €{((selectedPlayer.player.marketValue || 5000000) / 1_000_000).toFixed(1)}M
                </span>
              </div>
            </div>

            {/* Offer Fee Control */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-extrabold text-slate-300 uppercase block">
                Bonservis Teklifi (€)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  step="500000"
                  value={offerFee}
                  onChange={e => setOfferFee(Number(e.target.value))}
                  className="flex-1 bg-[#120f21] border border-[#3b2d63] rounded-xl px-3 py-2 text-sm font-black text-emerald-400 focus:outline-none focus:border-purple-500"
                />
                <button
                  onClick={() => setOfferFee(Math.round((selectedPlayer.player.marketValue || 5000000) * 1.2))}
                  className="px-2.5 py-2 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-[10px] font-bold text-purple-300"
                >
                  +%20
                </button>
              </div>
              <p className="text-[10px] text-slate-400">
                Mevcut Bütçeniz: <strong className="text-emerald-400">€{(userTeam.budget / 1_000_000).toFixed(1)}M</strong>
              </p>
            </div>

            {/* Negotiation Output Message */}
            {negotiationResult && negotiationResult.status !== 'IDLE' && (
              <div className={`p-3 rounded-xl border text-xs font-semibold leading-relaxed flex items-start gap-2 ${
                negotiationResult.status === 'SUCCESS'
                  ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
                  : 'bg-rose-950/40 border-rose-500/50 text-rose-200'
              }`}>
                {negotiationResult.status === 'SUCCESS' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                )}
                <span>{negotiationResult.message}</span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                onClick={() => setSelectedPlayer(null)}
                className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold"
              >
                İptal
              </button>
              {negotiationResult?.status !== 'SUCCESS' && (
                <button
                  onClick={handleSendOffer}
                  className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs uppercase tracking-wider shadow"
                >
                  Teklifi Gönder
                </button>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
