export type Position = 'GK' | 'DEF' | 'MID' | 'FW';

export interface PlayerAttributes {
  pace: number;      // Hız
  shooting: number;  // Şut
  passing: number;   // Pas
  defending: number; // Defans
  physical: number;  // Fizik
}

export interface PlayerRating {
  playerId: string;
  playerName: string;
  position: string;
  teamId: string;
  rating: number; // e.g. 7.8
  goals: number;
  assists: number;
  isMotm?: boolean;
  isWorst?: boolean;
}

export interface Player {
  id: string;
  teamId?: string;
  name: string;
  age: number;
  position: Position;
  specificRole: string; // e.g., 'ST', 'CAM', 'CB', 'GK', 'LW', 'CM'
  overall: number;      // 50-99
  potential?: number;    // 50-99 (Potansiyel Yetenek / PA)
  stamina: number;      // 0-100
  form: number;         // 1-10 rating
  marketValue: number;  // in € (e.g. 15000000)
  attributes: PlayerAttributes;
  isStarting: boolean;
  starterIndex?: number; // 0-10 for exact pitch starting slot
  subOrder?: number;    // 1-5 for sub list order
  goalsScored?: number;
  assists?: number;
  yellowCards?: number;
  redCards?: number;
  appearances?: number;
  averageRating?: number;
  unplayedStreak?: number;
  unhappyStatus?: string;
  // Injury System fields
  isInjured?: boolean;
  injuryWeeks?: number;
  injuryWeeksLeft?: number;
  injuryType?: string;
  // Suspension / Disciplinary System fields
  isSuspended?: boolean;
  suspensionMatchesLeft?: number;
  suspensionReason?: string;
  // FMM Details
  number?: number;
  wage?: number;          // in € per week e.g. 45000
  nationality?: string;   // e.g. 'Türkiye', Arjantin'
  contractUntil?: number; // e.g. 2028
  isLoaned?: boolean;     // Kiralık oyuncu mu
  parentClubName?: string;// Kiralık veren kulüp ismi
  preferredFoot?: 'Sol' | 'Sağ' | 'Her İkisi' | 'Left' | 'Right' | 'Both' | string; // Tercih Edilen Ayak
  isListedForTransfer?: boolean;
  isTransferListed?: boolean;
  isListedForLoan?: boolean;
  lastRating?: number;
  morale?: number;        // 0-100 (Oyuncu Morali - Yaş ve oynama durumuna göre dinamik)
  // Advanced Transfer Clauses
  releaseClause?: number;           // Serbest kalma bedeli (€)
  hasRelegationClause?: boolean;    // Küme düşerse serbest kalma maddesi
  buyBackClauseFee?: number;        // Geri satın alma bedeli (€)
  // Realistic FMM Training System
  trainingFocus?: 'Genel' | 'Hücum' | 'Pas' | 'Defans' | 'Fizik' | 'Yeni Pozisyon';
  trainingIntensity?: 'Hafif' | 'Normal' | 'Ağır';
  growthProgress?: number; // 0 to 100
  targetPosition?: string; // e.g. 'RW', 'CAM', 'LB' for position conversion
  targetPosProgress?: number; // 0 to 100 for position adaptation
}

export interface Team {
  id: string;
  name: string;
  shortName: string;
  badgeColor: string;
  logoUrl?: string;
  badgeTextColor?: string;
  secondaryColor?: string;
  stadiumName?: string;
  stadium?: string;
  stadiumCapacity?: number;
  country?: string;
  manager?: string;
  managerName?: string;
  overall?: number;
  overallRating?: number;
  budget: number;       // in USD
  reputation?: number;   // 1-5 stars
  players: Player[];
  formation: FormationType;
  tactic: TacticType;   // 'DEFENSIVE' | 'NEUTRAL' | 'ATTACKING'
  tacticalDetails?: {
    passing?: string;     // 'Kısa Pas' | 'Karma' | 'Direkt' | 'Uzun Top'
    tempo?: string;       // 'Yavaş' | 'Normal' | 'Hızlı'
    width?: string;       // 'Dar' | 'Dengeli' | 'Geniş'
    counter?: string;     // 'Açık' | 'Kapalı'
    pressZone?: string;   // 'Orta Bölge' | 'Tam Saha Pres' | 'Derin Blok'
    line?: string;        // 'Derin' | 'Normal' | 'Önde Basan'
    tackling?: string;    // 'Hafif' | 'Normal' | 'Sert (Agresif)'
    offsideTrap?: string; // 'Açık' | 'Kapalı'
    focus?: string;       // 'Karışık' | 'Kanatlardan' | 'Göbekten' | 'Beklerden'
    shooting?: string;    // 'Ceza Sahasına Gir' | 'Uzaktan Şut' | 'Gördüğü Yerden Şut'
    playOutOfDefense?: boolean;
    workBallIntoBox?: boolean;
    shootOnSight?: boolean;
    overlapWings?: boolean;
    earlyCrosses?: boolean;
    captainId?: string;
    penaltyTakerId?: string;
    freekickTakerId?: string;
    cornerTakerId?: string;
    playerRoles?: Record<string, string>;
    markedPlayerIds?: string[];
    markingType?: Record<string, 'TIGHT' | 'DOUBLE' | 'PRESS' | 'WEAK_FOOT' | 'HARD_TACKLE' | string>;
  };
}

export type FormationType = '4-3-3' | '4-2-3-1' | '4-4-2' | '3-5-2' | '5-3-2' | '4-1-4-1' | '3-4-3';
export type TacticType = 'DEFENSIVE' | 'BALANCED' | 'ATTACKING' | 'ALL_OUT_ATTACK';

export interface PitchPosition {
  role: string;
  posName: string;
  topPct: number; // percentage from top
  leftPct: number; // percentage from left
}

export interface LeagueRow {
  teamId: string;
  teamName: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDifference: number;
  points: number;
  formHistory: ('W' | 'D' | 'L')[];
  form?: ('W' | 'D' | 'L')[];
}

export type EventType = 
  | 'KICK_OFF'
  | 'PASS'
  | 'ATTACK'
  | 'SHOT'
  | 'GOAL'
  | 'SAVE'
  | 'MISS'
  | 'POST'
  | 'BLOCK'
  | 'YELLOW_CARD'
  | 'RED_CARD'
  | 'CORNER'
  | 'FOUL'
  | 'HALF_TIME'
  | 'FULL_TIME'
  | 'SUBSTITUTION'
  | 'INJURY'
  | 'TACTIC';

export interface MatchEvent {
  id: string;
  minute: number;
  type: EventType;
  text: string;
  teamId: string; // acting team
  playerName?: string;
  playerId?: string;
  scorerId?: string;
  assistantName?: string;
  assistantId?: string;
  defenderName?: string;
  gkName?: string;
  isHomeTeamEvent: boolean;
  scoreHome: number;
  scoreAway: number;
  isPenalty?: boolean;
  isPenaltyMissed?: boolean;
}

export interface MatchStats {
  possessionHome: number;
  possessionAway: number;
  shotsHome: number;
  shotsAway: number;
  shotsOnTargetHome: number;
  shotsOnTargetAway: number;
  cornersHome: number;
  cornersAway: number;
  foulsHome: number;
  foulsAway: number;
  yellowHome?: number;
  yellowAway?: number;
  redHome?: number;
  redAway?: number;
  offsidesHome?: number;
  offsidesAway?: number;
  yellowCardsHome?: number;
  yellowCardsAway?: number;
  savesHome?: number;
  savesAway?: number;
  cornerKicksHome?: number;
  cornerKicksAway?: number;
  passAccuracyHome?: number;
  passAccuracyAway?: number;
  xGHome?: string;
  xGAway?: string;
}

export interface Fixture {
  id: string;
  week: number;
  homeTeamId: string;
  awayTeamId: string;
  homeScore?: number;
  awayScore?: number;
  played: boolean;
  events?: MatchEvent[];
  matchDate?: string;
  matchTime?: string;
  dayName?: string;
  dayIndex?: number;
  leagueId?: string;
}

export interface ManagerProfile {
  name: string;
  experienceYears: number;
  nationality: string;
  favoriteFormation: FormationType;
  trophiesWon: number;
}

export type GameMode = 'MANAGER' | 'PLAYER_CAREER';

export interface CustomPlayerAvatar {
  skinTone: 'Açık' | 'Buğday' | 'Esmer' | 'Koyu' | 'Bronz';
  hairStyle: 'Kısa' | 'Bukleli' | 'Fade' | 'Uzun' | 'Buzz';
  hairColor: 'Siyah' | 'Kahverengi' | 'Sarı' | 'Kızıl' | 'Gümüş';
  eyeColor: 'Kahverengi' | 'Mavi' | 'Yeşil' | 'Ela';
  sleeveLength: 'Kısa Kol' | 'Uzun Kol' | 'Kol Bandı' | 'Termal İçlik';
  bootColor: 'Neon Sarı' | 'Kırmızı' | 'Mavi' | 'Siyah' | 'Beyaz' | 'Altın';
}

export interface CreatedPlayerProfile {
  id: string;
  name: string;
  age: number;
  position: Position;
  specificRole: string;
  preferredFoot: 'Sağ' | 'Sol';
  nationality: string;
  avatar: CustomPlayerAvatar;
  overall: number;
  marketValue: number;
  wage: number;
  attributes: PlayerAttributes;
  currentTeamId: string;
  matchesPlayed: number;
  goalsScored: number;
  assists: number;
  averageRating: number;
  managerTrust: number;
  stamina: number;
  form: number;
}

export interface Scout {
  id: string;
  name: string;
  nationality: string;
  judgmentRating: number; // 1-20
  weeklyWage: number;     // e.g. 2500
  assignedPlayerId?: string | null;
  assignedPlayerName?: string | null;
  assignedDaysLeft?: number | null; // Starts at 7 days (1 week)
}

export interface ScoutReport {
  playerId: string;
  playerName: string;
  revealedPotential: number;
  expiryDaysLeft: number; // Starts at 14 days (2 weeks)
}

export interface MatchReportScorer {
  name?: string;
  player?: string;
  minute: number;
  isHome?: boolean;
  team?: string;
  isPenalty?: boolean;
  isPenaltyMissed?: boolean;
  isOwnGoal?: boolean;
  scorerId?: string;
  assistantName?: string;
  assistantId?: string;
}

export interface MatchReportData {
  homeTeam: {
    id: string;
    name: string;
    shortName: string;
    badgeColor?: string;
  };
  awayTeam: {
    id: string;
    name: string;
    shortName: string;
    badgeColor?: string;
  };
  homeScore: number;
  awayScore: number;
  scorers: MatchReportScorer[];
  motm?: {
    name: string;
    rating: number;
    teamName: string;
    goals?: number;
    assists?: number;
  };
  standoutPlayers?: {
    name: string;
    teamName: string;
    rating: number;
    statSummary?: string;
  }[];
  cards?: {
    name: string;
    teamName: string;
    type: 'YELLOW' | 'RED';
    minute: number;
  }[];
  playerRatings?: {
    playerId?: string;
    name: string;
    teamName: string;
    rating: number;
    goals?: number;
    assists?: number;
    position?: string;
  }[];
  stats: {
    possessionHome: number;
    possessionAway: number;
    shotsHome: number;
    shotsAway: number;
    shotsOnTargetHome: number;
    shotsOnTargetAway: number;
    cornersHome: number;
    cornersAway: number;
    foulsHome: number;
    foulsAway: number;
    savesHome?: number;
    savesAway?: number;
    passAccuracyHome?: number;
    passAccuracyAway?: number;
    yellowCardsHome?: number;
    yellowCardsAway?: number;
    xGHome?: string;
    xGAway?: string;
  };
}

export interface MediaReviewItem {
  source: string;
  type?: 'NEWSPAPER' | 'PUNDIT' | 'INTERNATIONAL';
  headline?: string;
  comment: string;
  author?: string;
}

export interface MediaReviewData {
  matchSummary: string;
  reviews: MediaReviewItem[];
  keyHighlight?: string;
}

export interface InboxMessage {
  id: string;
  sender: string;
  senderName?: string;
  senderRole?: string;
  senderKey?: string;
  senderParams?: Record<string, string | number>;
  category?: string;
  subject: string;
  subjectKey?: string;
  subjectParams?: Record<string, string | number>;
  title?: string;
  date: string;
  content: string;
  contentKey?: string;
  contentParams?: Record<string, string | number>;
  isRead: boolean;
  tag?: 'YÖNETİM' | 'SAĞLIK' | 'SCOUT' | 'MEDYA' | 'TAKTIK' | 'TRANSFER' | 'MAÇ' | string;
  type?: string;
  actionType?: 'OPEN_CONTRACT_NEGOTIATION' | 'GOTO_TACTICS';
  actionData?: {
    player: Player;
    sellerTeam?: Team;
    effectiveFee?: number;
  };
  matchReport?: MatchReportData;
  mediaReview?: MediaReviewData;
}

export interface PendingBuyOffer {
  id: string;
  player: Player;
  sellerTeam?: Team;
  userTeam: Team;
  offerFee: number;
  effectiveFee: number;
  buyProb: number;
  submittedDayIndex: number;
  submittedWeek: number;
  daysRemaining: number; // Starts at 1 day
}


