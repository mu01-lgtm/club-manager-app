import { Player } from '../types';
import { getTeamLogoUrl } from '../data/teamLogos';

interface RealPlayerTemplate {
  name: string;
  position: 'GK' | 'DEF' | 'MID' | 'FW';
  role: string;
  age: number;
  overall: number;
  nationality: string;
  value: number;
  wage: number;
}

// Extensive Real Football Player Pools by Country (Sofascore, Maçkolik, Transfermarkt verified)
const REAL_PLAYERS_BY_COUNTRY: Record<string, RealPlayerTemplate[]> = {
  'Avusturya': [
    { name: 'Alexander Schlager', position: 'GK', role: 'GK', age: 28, overall: 77, nationality: 'Avusturya', value: 8000000, wage: 12000 },
    { name: 'Amar Dedić', position: 'DEF', role: 'RB', age: 21, overall: 79, nationality: 'Bosna Hersek', value: 20000000, wage: 18000 },
    { name: 'Oumar Solet', position: 'DEF', role: 'CB', age: 24, overall: 78, nationality: 'Fransa', value: 15000000, wage: 15000 },
    { name: 'Samson Baidoo', position: 'DEF', role: 'CB', age: 20, overall: 75, nationality: 'Avusturya', value: 9000000, wage: 10000 },
    { name: 'Oscar Gloukh', position: 'MID', role: 'CAM', age: 20, overall: 80, nationality: 'İsrail', value: 25000000, wage: 20000 },
    { name: 'Lucas Gourna-Douath', position: 'MID', role: 'CDM', age: 21, overall: 77, nationality: 'Fransa', value: 12000000, wage: 14000 },
    { name: 'Karim Konaté', position: 'FW', role: 'ST', age: 20, overall: 79, nationality: 'Fildişi Sahili', value: 18000000, wage: 16000 },
    { name: 'Guido Burgstaller', position: 'FW', role: 'ST', age: 35, overall: 74, nationality: 'Avusturya', value: 1500000, wage: 8000 },
    { name: 'Niklas Hedl', position: 'GK', role: 'GK', age: 23, overall: 75, nationality: 'Avusturya', value: 5000000, wage: 9000 },
    { name: 'Mika Biereth', position: 'FW', role: 'ST', age: 21, overall: 77, nationality: 'Danimarka', value: 10000000, wage: 12000 },
    { name: 'Gregory Wüthrich', position: 'DEF', role: 'CB', age: 29, overall: 76, nationality: 'İsviçre', value: 6000000, wage: 11000 },
    { name: 'Jon Gorenc Stanković', position: 'MID', role: 'CDM', age: 28, overall: 77, nationality: 'Slovenya', value: 8000000, wage: 13000 },
    { name: 'Otar Kiteishvili', position: 'MID', role: 'CM', age: 28, overall: 78, nationality: 'Gürcistan', value: 9000000, wage: 14000 },
    { name: 'William Bøving', position: 'FW', role: 'LW', age: 21, overall: 74, nationality: 'Danimarka', value: 5000000, wage: 8000 },
    { name: 'Dominik Fitz', position: 'MID', role: 'CAM', age: 25, overall: 75, nationality: 'Avusturya', value: 4500000, wage: 9000 },
    { name: 'Robert Žulj', position: 'MID', role: 'CAM', age: 32, overall: 76, nationality: 'Avusturya', value: 3000000, wage: 10000 },
    { name: 'Marin Ljubičić', position: 'FW', role: 'ST', age: 22, overall: 76, nationality: 'Hırvatistan', value: 8000000, wage: 11000 },
    { name: 'Lukas Lawal', position: 'GK', role: 'GK', age: 24, overall: 74, nationality: 'Avusturya', value: 3500000, wage: 7000 },
    { name: 'Philipp Ziereis', position: 'DEF', role: 'CB', age: 31, overall: 74, nationality: 'Almanya', value: 2500000, wage: 8000 },
    { name: 'Sascha Horvath', position: 'MID', role: 'CM', age: 28, overall: 74, nationality: 'Avusturya', value: 3000000, wage: 8000 }
  ],
  'Belçika': [
    { name: 'Simon Mignolet', position: 'GK', role: 'GK', age: 36, overall: 80, nationality: 'Belçika', value: 3000000, wage: 15000 },
    { name: 'Hans Vanaken', position: 'MID', role: 'CAM', age: 31, overall: 81, nationality: 'Belçika', value: 12000000, wage: 20000 },
    { name: 'Andreas Skov Olsen', position: 'FW', role: 'RW', age: 24, overall: 81, nationality: 'Danimarka', value: 22000000, wage: 22000 },
    { name: 'Ferran Jutglà', position: 'FW', role: 'ST', age: 25, overall: 78, nationality: 'İspanya', value: 12000000, wage: 15000 },
    { name: 'Maxim De Cuyper', position: 'DEF', role: 'LB', age: 23, overall: 78, nationality: 'Belçika', value: 16000000, wage: 16000 },
    { name: 'Joel Ordóñez', position: 'DEF', role: 'CB', age: 20, overall: 76, nationality: 'Ekvador', value: 10000000, wage: 11000 },
    { name: 'Raphael Onyedika', position: 'MID', role: 'CDM', age: 23, overall: 78, nationality: 'Nijerya', value: 15000000, wage: 15000 },
    { name: 'Gustaf Nilsson', position: 'FW', role: 'ST', age: 27, overall: 76, nationality: 'İsveç', value: 8000000, wage: 12000 },
    { name: 'Jan Vertonghen', position: 'DEF', role: 'CB', age: 37, overall: 77, nationality: 'Belçika', value: 2000000, wage: 14000 },
    { name: 'Yari Verschaeren', position: 'MID', role: 'CAM', age: 23, overall: 76, nationality: 'Belçika', value: 9000000, wage: 12000 },
    { name: 'Kasper Dolberg', position: 'FW', role: 'ST', age: 26, overall: 78, nationality: 'Danimarka', value: 12000000, wage: 16000 },
    { name: 'Anders Dreyer', position: 'FW', role: 'RW', age: 26, overall: 79, nationality: 'Danimarka', value: 15000000, wage: 18000 },
    { name: 'Thorgan Hazard', position: 'MID', role: 'LM', age: 31, overall: 77, nationality: 'Belçika', value: 6000000, wage: 15000 },
    { name: 'Jan-Carlo Simić', position: 'DEF', role: 'CB', age: 19, overall: 74, nationality: 'Sırbistan', value: 7000000, wage: 9000 },
    { name: 'Bryan Heynen', position: 'MID', role: 'CM', age: 27, overall: 78, nationality: 'Belçika', value: 11000000, wage: 14000 },
    { name: 'Tolu Arokodare', position: 'FW', role: 'ST', age: 23, overall: 76, nationality: 'Nijerya', value: 8000000, wage: 10000 },
    { name: 'Jarne Steuckers', position: 'MID', role: 'RM', age: 22, overall: 75, nationality: 'Belçika', value: 7000000, wage: 9000 },
    { name: 'Hyeon-gyu Oh', position: 'FW', role: 'ST', age: 23, overall: 74, nationality: 'Güney Kore', value: 5000000, wage: 8000 },
    { name: 'Toby Alderweireld', position: 'DEF', role: 'CB', age: 35, overall: 78, nationality: 'Belçika', value: 3000000, wage: 16000 },
    { name: 'Vincent Janssen', position: 'FW', role: 'ST', age: 30, overall: 77, nationality: 'Hollanda', value: 8000000, wage: 14000 }
  ],
  'İskoçya': [
    { name: 'Kasper Schmeichel', position: 'GK', role: 'GK', age: 37, overall: 79, nationality: 'Danimarka', value: 2000000, wage: 15000 },
    { name: 'Cameron Carter-Vickers', position: 'DEF', role: 'CB', age: 26, overall: 79, nationality: 'ABD', value: 14000000, wage: 18000 },
    { name: 'Alistair Johnston', position: 'DEF', role: 'RB', age: 25, overall: 77, nationality: 'Kanada', value: 9000000, wage: 12000 },
    { name: 'Greg Taylor', position: 'DEF', role: 'LB', age: 26, overall: 75, nationality: 'İskoçya', value: 6000000, wage: 10000 },
    { name: 'Callum McGregor', position: 'MID', role: 'CDM', age: 31, overall: 79, nationality: 'İskoçya', value: 9000000, wage: 18000 },
    { name: 'Reo Hatate', position: 'MID', role: 'CM', age: 26, overall: 78, nationality: 'Japonya', value: 11000000, wage: 15000 },
    { name: 'Arne Engels', position: 'MID', role: 'CM', age: 20, overall: 77, nationality: 'Belçika', value: 15000000, wage: 14000 },
    { name: 'Daizen Maeda', position: 'FW', role: 'LW', age: 26, overall: 77, nationality: 'Japonya', value: 8000000, wage: 13000 },
    { name: 'Kyogo Furuhashi', position: 'FW', role: 'ST', age: 29, overall: 79, nationality: 'Japonya', value: 14000000, wage: 20000 },
    { name: 'Nicolas Kühn', position: 'FW', role: 'RW', age: 24, overall: 77, nationality: 'Almanya', value: 10000000, wage: 12000 },
    { name: 'Jack Butland', position: 'GK', role: 'GK', age: 31, overall: 77, nationality: 'İngiltere', value: 5000000, wage: 14000 },
    { name: 'James Tavernier', position: 'DEF', role: 'RB', age: 32, overall: 78, nationality: 'İngiltere', value: 7000000, wage: 16000 },
    { name: 'John Souttar', position: 'DEF', role: 'CB', age: 27, overall: 75, nationality: 'İskoçya', value: 4500000, wage: 10000 },
    { name: 'Rıdvan Yılmaz', position: 'DEF', role: 'LB', age: 23, overall: 75, nationality: 'Türkiye', value: 6000000, wage: 11000 },
    { name: 'Nicolas Raskin', position: 'MID', role: 'CM', age: 23, overall: 75, nationality: 'Belçika', value: 7000000, wage: 10000 },
    { name: 'Mohamed Diomande', position: 'MID', role: 'CAM', age: 22, overall: 76, nationality: 'Fildişi Sahili', value: 9000000, wage: 12000 },
    { name: 'Václav Černý', position: 'FW', role: 'RW', age: 26, overall: 76, nationality: 'Çekya', value: 8000000, wage: 13000 },
    { name: 'Cyriel Dessers', position: 'FW', role: 'ST', age: 29, overall: 76, nationality: 'Nijerya', value: 6000000, wage: 12000 },
    { name: 'Lawrence Shankland', position: 'FW', role: 'ST', age: 28, overall: 76, nationality: 'İskoçya', value: 5000000, wage: 10000 },
    { name: 'Pape Gueye', position: 'FW', role: 'ST', age: 25, overall: 74, nationality: 'Senegal', value: 3500000, wage: 8000 }
  ],
  'Yunanistan': [
    { name: 'Konstantinos Tzolakis', position: 'GK', role: 'GK', age: 21, overall: 76, nationality: 'Yunanistan', value: 8000000, wage: 10000 },
    { name: 'Rodinei', position: 'DEF', role: 'RB', age: 32, overall: 77, nationality: 'Brezilya', value: 4000000, wage: 12000 },
    { name: 'David Carmo', position: 'DEF', role: 'CB', age: 25, overall: 78, nationality: 'Angola', value: 12000000, wage: 15000 },
    { name: 'Francisco Ortega', position: 'DEF', role: 'LB', age: 25, overall: 76, nationality: 'Arjantin', value: 7000000, wage: 11000 },
    { name: 'Santiago Hezze', position: 'MID', role: 'CDM', age: 22, overall: 78, nationality: 'Arjantin', value: 12000000, wage: 14000 },
    { name: 'Chiquinho', position: 'MID', role: 'CM', age: 29, overall: 76, nationality: 'Portekiz', value: 5000000, wage: 12000 },
    { name: 'Daniel Podence', position: 'FW', role: 'LW', age: 28, overall: 78, nationality: 'Portekiz', value: 10000000, wage: 18000 },
    { name: 'Giorgos Masouras', position: 'FW', role: 'RW', age: 30, overall: 76, nationality: 'Yunanistan', value: 5000000, wage: 11000 },
    { name: 'Ayoub El Kaabi', position: 'FW', role: 'ST', age: 31, overall: 79, nationality: 'Fas', value: 7000000, wage: 16000 },
    { name: 'Gelson Martins', position: 'FW', role: 'RW', age: 29, overall: 76, nationality: 'Portekiz', value: 6000000, wage: 13000 },
    { name: 'Bartłomiej Drągowski', position: 'GK', role: 'GK', age: 27, overall: 76, nationality: 'Polonya', value: 5000000, wage: 11000 },
    { name: 'Tin Jedvaj', position: 'DEF', role: 'CB', age: 28, overall: 75, nationality: 'Hırvatistan', value: 4000000, wage: 10000 },
    { name: 'Willian Arão', position: 'MID', role: 'CDM', age: 32, overall: 76, nationality: 'Brezilya', value: 3500000, wage: 12000 },
    { name: 'Anastasios Bakasetas', position: 'MID', role: 'CAM', age: 31, overall: 78, nationality: 'Yunanistan', value: 7000000, wage: 16000 },
    { name: 'Fotis Ioannidis', position: 'FW', role: 'ST', age: 24, overall: 79, nationality: 'Yunanistan', value: 18000000, wage: 18000 },
    { name: 'Facundo Pellistri', position: 'FW', role: 'RW', age: 22, overall: 76, nationality: 'Uruguay', value: 10000000, wage: 13000 },
    { name: 'Anthony Martial', position: 'FW', role: 'ST', age: 28, overall: 78, nationality: 'Fransa', value: 10000000, wage: 20000 },
    { name: 'Orbelín Pineda', position: 'MID', role: 'CM', age: 28, overall: 77, nationality: 'Meksika', value: 8000000, wage: 14000 },
    { name: 'Dominik Kotarski', position: 'GK', role: 'GK', age: 24, overall: 77, nationality: 'Hırvatistan', value: 9000000, wage: 12000 },
    { name: 'Andrija Živković', position: 'FW', role: 'RW', age: 28, overall: 78, nationality: 'Sırbistan', value: 10000000, wage: 15000 }
  ],
  'Danimarka': [
    { name: 'Nathan Trott', position: 'GK', role: 'GK', age: 25, overall: 74, nationality: 'İngiltere', value: 3000000, wage: 7000 },
    { name: 'Denis Vavro', position: 'DEF', role: 'CB', age: 28, overall: 76, nationality: 'Slovakya', value: 5000000, wage: 11000 },
    { name: 'Kevin Diks', position: 'DEF', role: 'CB', age: 27, overall: 76, nationality: 'Endonezya', value: 5000000, wage: 11000 },
    { name: 'Marcos López', position: 'DEF', role: 'LB', age: 24, overall: 74, nationality: 'Peru', value: 3500000, wage: 8000 },
    { name: 'Rasmus Falk', position: 'MID', role: 'CM', age: 32, overall: 75, nationality: 'Danimarka', value: 2500000, wage: 10000 },
    { name: 'Lukas Lerager', position: 'MID', role: 'CM', age: 31, overall: 75, nationality: 'Danimarka', value: 3000000, wage: 10000 },
    { name: 'Thomas Delaney', position: 'MID', role: 'CDM', age: 32, overall: 76, nationality: 'Danimarka', value: 3500000, wage: 12000 },
    { name: 'Viktor Claesson', position: 'MID', role: 'CAM', age: 32, overall: 76, nationality: 'İsveç', value: 4000000, wage: 12000 },
    { name: 'Mohamed Elyounoussi', position: 'FW', role: 'LW', age: 30, overall: 77, nationality: 'Norveç', value: 6000000, wage: 14000 },
    { name: 'Jordan Larsson', position: 'FW', role: 'RW', age: 27, overall: 75, nationality: 'İsveç', value: 4000000, wage: 10000 },
    { name: 'Andreas Cornelius', position: 'FW', role: 'ST', age: 31, overall: 75, nationality: 'Danimarka', value: 3000000, wage: 11000 },
    { name: 'Elias Olafsson', position: 'GK', role: 'GK', age: 24, overall: 74, nationality: 'İzlanda', value: 3000000, wage: 7000 },
    { name: 'Mads Bech Sørensen', position: 'DEF', role: 'CB', age: 25, overall: 75, nationality: 'Danimarka', value: 4500000, wage: 9000 },
    { name: 'Emiliano Martínez', position: 'MID', role: 'CDM', age: 24, overall: 76, nationality: 'Uruguay', value: 6000000, wage: 10000 },
    { name: 'Oliver Sørensen', position: 'MID', role: 'CM', age: 22, overall: 76, nationality: 'Danimarka', value: 8000000, wage: 10000 },
    { name: 'Darío Osorio', position: 'FW', role: 'RW', age: 20, overall: 77, nationality: 'Şili', value: 12000000, wage: 12000 },
    { name: 'Franculino Djú', position: 'FW', role: 'ST', age: 20, overall: 76, nationality: 'Gine-Bissau', value: 9000000, wage: 10000 },
    { name: 'Aral Simsir', position: 'FW', role: 'LW', age: 22, overall: 76, nationality: 'Türkiye', value: 8000000, wage: 10000 },
    { name: 'Patrick Pentz', position: 'GK', role: 'GK', age: 27, overall: 76, nationality: 'Avusturya', value: 5000000, wage: 10000 },
    { name: 'Daniel Wass', position: 'MID', role: 'CM', age: 35, overall: 74, nationality: 'Danimarka', value: 1500000, wage: 8000 }
  ],
  'İsveç': [
    { name: 'Johan Dahlin', position: 'GK', role: 'GK', age: 37, overall: 73, nationality: 'İsveç', value: 800000, wage: 5000 },
    { name: 'Jens Stryger Larsen', position: 'DEF', role: 'RB', age: 33, overall: 74, nationality: 'Danimarka', value: 2000000, wage: 8000 },
    { name: 'Pontus Jansson', position: 'DEF', role: 'CB', age: 33, overall: 76, nationality: 'İsveç', value: 3000000, wage: 10000 },
    { name: 'Derek Cornelius', position: 'DEF', role: 'CB', age: 26, overall: 75, nationality: 'Kanada', value: 5000000, wage: 9000 },
    { name: 'Gabriel Busanello', position: 'DEF', role: 'LB', age: 25, overall: 75, nationality: 'Brezilya', value: 4500000, wage: 9000 },
    { name: 'Lasse Berg Johnsen', position: 'MID', role: 'CDM', age: 24, overall: 75, nationality: 'Norveç', value: 5000000, wage: 9000 },
    { name: 'Sergio Peña', position: 'MID', role: 'CM', age: 28, overall: 74, nationality: 'Peru', value: 3500000, wage: 8000 },
    { name: 'Anders Christiansen', position: 'MID', role: 'CAM', age: 34, overall: 75, nationality: 'Danimarka', value: 2000000, wage: 9000 },
    { name: 'Isaac Kiese Thelin', position: 'FW', role: 'ST', age: 32, overall: 75, nationality: 'İsveç', value: 2500000, wage: 9000 },
    { name: 'Erik Botheim', position: 'FW', role: 'ST', age: 24, overall: 74, nationality: 'Norveç', value: 3500000, wage: 8000 },
    { name: 'Sead Hakšabanović', position: 'FW', role: 'LW', age: 25, overall: 75, nationality: 'Karadağ', value: 4500000, wage: 9000 },
    { name: 'Kristoffer Nordfeldt', position: 'GK', role: 'GK', age: 35, overall: 73, nationality: 'İsveç', value: 1000000, wage: 6000 },
    { name: 'Alexander Milošević', position: 'DEF', role: 'CB', age: 32, overall: 73, nationality: 'İsveç', value: 1200000, wage: 6000 },
    { name: 'Bersant Celina', position: 'MID', role: 'CAM', age: 27, overall: 74, nationality: 'Kosova', value: 3000000, wage: 8000 },
    { name: 'Ioannis Pittas', position: 'FW', role: 'ST', age: 28, overall: 75, nationality: 'Kıbrıs', value: 3500000, wage: 8000 },
    { name: 'Marcus Danielson', position: 'DEF', role: 'CB', age: 35, overall: 73, nationality: 'İsveç', value: 1000000, wage: 6000 },
    { name: 'Tobias Gulliksen', position: 'MID', role: 'CAM', age: 21, overall: 74, nationality: 'Norveç', value: 4000000, wage: 7000 },
    { name: 'Deniz Gül', position: 'FW', role: 'ST', age: 20, overall: 73, nationality: 'İsveç', value: 3000000, wage: 6000 },
    { name: 'Gustaf Lagerbielke', position: 'DEF', role: 'CB', age: 24, overall: 74, nationality: 'İsveç', value: 3500000, wage: 7000 },
    { name: 'Besard Sabovic', position: 'MID', role: 'CM', age: 26, overall: 73, nationality: 'İsveç', value: 2000000, wage: 6000 }
  ],
  'İsviçre': [
    { name: 'David von Ballmoos', position: 'GK', role: 'GK', age: 29, overall: 75, nationality: 'İsviçre', value: 3500000, wage: 8000 },
    { name: 'Loris Benito', position: 'DEF', role: 'CB', age: 32, overall: 74, nationality: 'İsviçre', value: 2000000, wage: 7000 },
    { name: 'Saidy Janko', position: 'DEF', role: 'RB', age: 28, overall: 73, nationality: 'Gambia', value: 2000000, wage: 6000 },
    { name: 'Filip Ugrinic', position: 'MID', role: 'CM', age: 25, overall: 77, nationality: 'İsviçre', value: 7000000, wage: 11000 },
    { name: 'Sandro Lauper', position: 'MID', role: 'CDM', age: 27, overall: 74, nationality: 'İsviçre', value: 3000000, wage: 7000 },
    { name: 'Łukasz Łakomy', position: 'MID', role: 'CM', age: 23, overall: 74, nationality: 'Polonya', value: 3500000, wage: 7000 },
    { name: 'Meschak Elia', position: 'FW', role: 'ST', age: 27, overall: 77, nationality: 'Demokratik Kongo', value: 8000000, wage: 12000 },
    { name: 'Silvère Ganvoula', position: 'FW', role: 'ST', age: 28, overall: 74, nationality: 'Kongo', value: 2500000, wage: 7000 },
    { name: 'Cedric Itten', position: 'FW', role: 'ST', age: 27, overall: 75, nationality: 'İsviçre', value: 4500000, wage: 9000 },
    { name: 'Marwin Hitz', position: 'GK', role: 'GK', age: 36, overall: 74, nationality: 'İsviçre', value: 1000000, wage: 6000 },
    { name: 'Dominik Schmid', position: 'DEF', role: 'LB', age: 26, overall: 74, nationality: 'İsviçre', value: 3000000, wage: 7000 },
    { name: 'Taulant Xhaka', position: 'MID', role: 'CDM', age: 33, overall: 73, nationality: 'Arnavutluk', value: 1500000, wage: 6000 },
    { name: 'Xherdan Shaqiri', position: 'MID', role: 'CAM', age: 32, overall: 78, nationality: 'İsviçre', value: 5000000, wage: 15000 },
    { name: 'Benjamin Kololli', position: 'FW', role: 'LW', age: 32, overall: 72, nationality: 'Kosova', value: 1200000, wage: 5000 },
    { name: 'Yanick Brecher', position: 'GK', role: 'GK', age: 31, overall: 74, nationality: 'İsviçre', value: 2500000, wage: 7000 },
    { name: 'Lindrit Kamberi', position: 'DEF', role: 'CB', age: 24, overall: 73, nationality: 'Kosova', value: 2000000, wage: 6000 },
    { name: 'Nikola Katić', position: 'DEF', role: 'CB', age: 27, overall: 74, nationality: 'Bosna Hersek', value: 3000000, wage: 7000 },
    { name: 'Bledian Krasniqi', position: 'MID', role: 'CM', age: 23, overall: 74, nationality: 'Kosova', value: 3500000, wage: 7000 },
    { name: 'Jonathan Okita', position: 'FW', role: 'LW', age: 27, overall: 74, nationality: 'Demokratik Kongo', value: 3000000, wage: 7000 },
    { name: 'Dereck Kutesa', position: 'FW', role: 'LW', age: 26, overall: 76, nationality: 'İsviçre', value: 6000000, wage: 9000 }
  ],
  'Romanya': [
    { name: 'Ştefan Târnovanu', position: 'GK', role: 'GK', age: 24, overall: 76, nationality: 'Romanya', value: 5000000, wage: 9000 },
    { name: 'Valentin Crețu', position: 'DEF', role: 'RB', age: 35, overall: 72, nationality: 'Romanya', value: 800000, wage: 4000 },
    { name: 'Joyskim Dawa', position: 'DEF', role: 'CB', age: 28, overall: 75, nationality: 'Kamerun', value: 3500000, wage: 7000 },
    { name: 'Siyabonga Ngezana', position: 'DEF', role: 'CB', age: 27, overall: 75, nationality: 'Güney Afrika', value: 3500000, wage: 7000 },
    { name: 'Risto Radunović', position: 'DEF', role: 'LB', age: 32, overall: 74, nationality: 'Karadağ', value: 2000000, wage: 6000 },
    { name: 'Adrian Şut', position: 'MID', role: 'CDM', age: 25, overall: 76, nationality: 'Romanya', value: 4500000, wage: 8000 },
    { name: 'Darius Olaru', position: 'MID', role: 'CM', age: 26, overall: 78, nationality: 'Romanya', value: 8000000, wage: 12000 },
    { name: 'Alexandru Băluță', position: 'MID', role: 'CAM', age: 30, overall: 73, nationality: 'Romanya', value: 1500000, wage: 5000 },
    { name: 'Daniel Bîrligea', position: 'FW', role: 'ST', age: 24, overall: 76, nationality: 'Romanya', value: 4000000, wage: 8000 },
    { name: 'David Miculescu', position: 'FW', role: 'RW', age: 23, overall: 73, nationality: 'Romanya', value: 2000000, wage: 5000 },
    { name: 'Ciprian Deac', position: 'MID', role: 'CAM', age: 38, overall: 72, nationality: 'Romanya', value: 500000, wage: 4000 },
    { name: 'Louis Munteanu', position: 'FW', role: 'ST', age: 22, overall: 76, nationality: 'Romanya', value: 5000000, wage: 8000 },
    { name: 'Nicușor Bancu', position: 'DEF', role: 'LB', age: 31, overall: 74, nationality: 'Romanya', value: 2000000, wage: 6000 },
    { name: 'Alexandru Mitriță', position: 'FW', role: 'LW', age: 29, overall: 77, nationality: 'Romanya', value: 5000000, wage: 10000 },
    { name: 'Elvir Koljić', position: 'FW', role: 'ST', age: 29, overall: 73, nationality: 'Bosna Hersek', value: 1500000, wage: 5000 },
    { name: 'Cristian Săpunaru', position: 'DEF', role: 'CB', age: 40, overall: 71, nationality: 'Romanya', value: 300000, wage: 3000 },
    { name: 'Claudiu Petrila', position: 'FW', role: 'LW', age: 23, overall: 74, nationality: 'Romanya', value: 3000000, wage: 6000 },
    { name: 'Aaron Boupendza', position: 'FW', role: 'ST', age: 28, overall: 76, nationality: 'Gabon', value: 4500000, wage: 9000 },
    { name: 'Denis Alibec', position: 'FW', role: 'ST', age: 33, overall: 73, nationality: 'Romanya', value: 1200000, wage: 5000 },
    { name: 'Nectarios Petre', position: 'MID', role: 'CM', age: 21, overall: 72, nationality: 'Romanya', value: 1500000, wage: 4000 }
  ],
  'Çekya': [
    { name: 'Peter Vindahl Jensen', position: 'GK', role: 'GK', age: 26, overall: 76, nationality: 'Danimarka', value: 4000000, wage: 8000 },
    { name: 'Martin Vitík', position: 'DEF', role: 'CB', age: 21, overall: 78, nationality: 'Çekya', value: 12000000, wage: 11000 },
    { name: 'Asger Sørensen', position: 'DEF', role: 'CB', age: 28, overall: 76, nationality: 'Danimarka', value: 4500000, wage: 8000 },
    { name: 'Filip Panák', position: 'DEF', role: 'CB', age: 28, overall: 75, nationality: 'Çekya', value: 3500000, wage: 7000 },
    { name: 'Angelo Preciado', position: 'DEF', role: 'RB', age: 26, overall: 76, nationality: 'Ekvador', value: 6000000, wage: 9000 },
    { name: 'Kaan Kairinen', position: 'MID', role: 'CM', age: 25, overall: 77, nationality: 'Finlandiya', value: 7000000, wage: 10000 },
    { name: 'Qazim Laçi', position: 'MID', role: 'CM', age: 28, overall: 75, nationality: 'Arnavutluk', value: 3500000, wage: 7000 },
    { name: 'Lukáš Haraslín', position: 'FW', role: 'LW', age: 28, overall: 78, nationality: 'Slovakya', value: 8000000, wage: 12000 },
    { name: 'Veljko Birmančević', position: 'FW', role: 'RW', age: 26, overall: 78, nationality: 'Sırbistan', value: 9000000, wage: 12000 },
    { name: 'Victor Olatunji', position: 'FW', role: 'ST', age: 24, overall: 74, nationality: 'Nijerya', value: 2500000, wage: 6000 },
    { name: 'Antonín Kinský', position: 'GK', role: 'GK', age: 21, overall: 75, nationality: 'Çekya', value: 4000000, wage: 7000 },
    { name: 'Igoh Ogbu', position: 'DEF', role: 'CB', age: 24, overall: 77, nationality: 'Nijerya', value: 6000000, wage: 9000 },
    { name: 'David Zima', position: 'DEF', role: 'CB', age: 23, overall: 76, nationality: 'Çekya', value: 5000000, wage: 8000 },
    { name: 'Tomáš Holeš', position: 'DEF', role: 'CB', age: 31, overall: 77, nationality: 'Çekya', value: 4000000, wage: 9000 },
    { name: 'El Hadji Malick Diouf', position: 'DEF', role: 'LB', age: 19, overall: 76, nationality: 'Senegal', value: 7000000, wage: 8000 },
    { name: 'Oscar Dorley', position: 'MID', role: 'CM', age: 26, overall: 77, nationality: 'Liberya', value: 6000000, wage: 9000 },
    { name: 'Christos Zafeiris', position: 'MID', role: 'CM', age: 21, overall: 78, nationality: 'Yunanistan', value: 10000000, wage: 11000 },
    { name: 'Lukáš Provod', position: 'MID', role: 'LM', age: 27, overall: 77, nationality: 'Çekya', value: 6000000, wage: 9000 },
    { name: 'Mojmír Chytil', position: 'FW', role: 'ST', age: 25, overall: 76, nationality: 'Çekya', value: 5000000, wage: 8000 },
    { name: 'Tomáš Chorý', position: 'FW', role: 'ST', age: 29, overall: 76, nationality: 'Çekya', value: 4500000, wage: 8000 }
  ]
};

const DEFAULT_REAL_PLAYERS: RealPlayerTemplate[] = [
  { name: 'Oliver Baumann', position: 'GK', role: 'GK', age: 34, overall: 80, nationality: 'Almanya', value: 8000000, wage: 20000 },
  { name: 'Robin Koch', position: 'DEF', role: 'CB', age: 28, overall: 79, nationality: 'Almanya', value: 14000000, wage: 22000 },
  { name: 'Tuta', position: 'DEF', role: 'CB', age: 25, overall: 78, nationality: 'Brezilya', value: 12000000, wage: 18000 },
  { name: 'Ellyes Skhiri', position: 'MID', role: 'CDM', age: 29, overall: 80, nationality: 'Tunus', value: 16000000, wage: 24000 },
  { name: 'Mario Götze', position: 'MID', role: 'CAM', age: 32, overall: 78, nationality: 'Almanya', value: 7000000, wage: 22000 },
  { name: 'Omar Marmoush', position: 'FW', role: 'ST', age: 25, overall: 82, nationality: 'Mısır', value: 35000000, wage: 30000 },
  { name: 'Hugo Ekitike', position: 'FW', role: 'ST', age: 22, overall: 79, nationality: 'Fransa', value: 25000000, wage: 25000 },
  { name: 'Nadiem Amiri', position: 'MID', role: 'CM', age: 27, overall: 78, nationality: 'Almanya', value: 10000000, wage: 18000 },
  { name: 'Mitchell Weiser', position: 'DEF', role: 'RB', age: 30, overall: 77, nationality: 'Almanya', value: 7000000, wage: 15000 },
  { name: 'Marvin Ducksch', position: 'FW', role: 'ST', age: 30, overall: 78, nationality: 'Almanya', value: 9000000, wage: 18000 },
  { name: ' Mile Svilar', position: 'GK', role: 'GK', age: 24, overall: 79, nationality: 'Sırbistan', value: 12000000, wage: 18000 },
  { name: 'Gianluca Mancini', position: 'DEF', role: 'CB', age: 28, overall: 81, nationality: 'İtalya', value: 22000000, wage: 28000 },
  { name: 'Evan Ndicka', position: 'DEF', role: 'CB', age: 24, overall: 80, nationality: 'Fildişi Sahili', value: 24000000, wage: 26000 },
  { name: 'Bryan Cristante', position: 'MID', role: 'CDM', age: 29, overall: 80, nationality: 'İtalya', value: 18000000, wage: 25000 },
  { name: 'Lorenzo Pellegrini', position: 'MID', role: 'CAM', age: 28, overall: 81, nationality: 'İtalya', value: 22000000, wage: 30000 },
  { name: 'Paulo Dybala', position: 'FW', role: 'ST', age: 30, overall: 84, nationality: 'Arjantin', value: 25000000, wage: 40000 },
  { name: 'Artem Dovbyk', position: 'FW', role: 'ST', age: 27, overall: 82, nationality: 'Ukrayna', value: 35000000, wage: 35000 },
  { name: 'Ivan Provedel', position: 'GK', role: 'GK', age: 30, overall: 81, nationality: 'İtalya', value: 15000000, wage: 22000 },
  { name: 'Alessio Romagnoli', position: 'DEF', role: 'CB', age: 29, overall: 80, nationality: 'İtalya', value: 16000000, wage: 24000 },
  { name: 'Mattia Zaccagni', position: 'FW', role: 'LW', age: 29, overall: 81, nationality: 'İtalya', value: 20000000, wage: 28000 },
  { name: 'Taty Castellanos', position: 'FW', role: 'ST', age: 25, overall: 79, nationality: 'Arjantin', value: 18000000, wage: 22000 },
  { name: 'Carnesecchi', position: 'GK', role: 'GK', age: 24, overall: 80, nationality: 'İtalya', value: 18000000, wage: 20000 },
  { name: 'Isak Hien', position: 'DEF', role: 'CB', age: 25, overall: 79, nationality: 'İsveç', value: 16000000, wage: 20000 },
  { name: 'Ederson', position: 'MID', role: 'CM', age: 25, overall: 82, nationality: 'Brezilya', value: 40000000, wage: 32000 },
  { name: 'Ademola Lookman', position: 'FW', role: 'ST', age: 26, overall: 84, nationality: 'Nijerya', value: 50000000, wage: 40000 },
  { name: 'Mateo Retegui', position: 'FW', role: 'ST', age: 25, overall: 81, nationality: 'İtalya', value: 28000000, wage: 30000 },
  { name: 'David de Gea', position: 'GK', role: 'GK', age: 33, overall: 81, nationality: 'İspanya', value: 8000000, wage: 25000 },
  { name: 'Moise Kean', position: 'FW', role: 'ST', age: 24, overall: 80, nationality: 'İtalya', value: 22000000, wage: 26000 }
];

const FIRST_NAMES_BY_COUNTRY: Record<string, string[]> = {
  'Türkiye': ['Ahmet', 'Mehmet', 'Can', 'Emre', 'Burak', 'Arda', 'Yusuf', 'Eren', 'Kaan', 'Kerem', 'Oğuz', 'Barış', 'Semih', 'Umut', 'Taha', 'Mert', 'Yasin', 'Cenk', 'Taylan', 'İrfan', 'Berkan', 'Orkun', 'Zeki', 'Caglar', 'Merih', 'Rıdvan', 'Samet'],
  'İspanya': ['Carlos', 'Alejandro', 'Pablo', 'Mateo', 'Hugo', 'Lucas', 'Daniel', 'Marcos', 'Javier', 'David', 'Adrián', 'Mario', 'Gonzalo', 'Álvaro', 'Raúl', 'Izan', 'Sergio', 'Ferran', 'Mikel', 'Iñigo', 'Pau', 'Aitor', 'Unai', 'Gavi', 'Lamine'],
  'İngiltere': ['Jack', 'Harry', 'Oliver', 'George', 'Charlie', 'Ethan', 'Thomas', 'Jacob', 'James', 'William', 'Mason', 'Liam', 'Callum', 'Archie', 'Leo', 'Joshua', 'Declan', 'Bukayo', 'Jude', 'Phil', 'Cole', 'Trent', 'Ezri', 'Kobbie'],
  'Almanya': ['Lukas', 'Maximilian', 'Felix', 'Julian', 'Paul', 'Jonas', 'Tim', 'Niklas', 'Leon', 'Moritz', 'Florian', 'Jan', 'Tobias', 'Sebastian', 'David', 'Manuel', 'Joshua', 'Kai', 'Jamal', 'Jonathan', 'Waldemar', 'Angelo', 'Alexander'],
  'İtalya': ['Marco', 'Matteo', 'Lorenzo', 'Francesco', 'Alessandro', 'Andrea', 'Federico', 'Leonardo', 'Davide', 'Filippo', 'Mattia', 'Gabriele', 'Tommaso', 'Nicolò', 'Gianluigi', 'Riccardo', 'Giacomo', 'Moise', 'Gianluca', 'Bryan'],
  'Fransa': ['Lucas', 'Hugo', 'Léo', 'Gabriel', 'Arthur', 'Louis', 'Jules', 'Antoine', 'Paul', 'Clément', 'Mathieu', 'Maxime', 'Enzo', 'Alexandre', 'Théo', 'Bradley', 'Warren', 'Dayot', 'Ibrahima', 'Kylian', 'Ousmane', 'William'],
  'Portekiz': ['João', 'Rodrigo', 'Martim', 'Afonso', 'Tomas', 'Gonçalo', 'Duarte', 'Tiago', 'Diogo', 'Bernardo', 'Pedro', 'Miguel', 'Rafael', 'Francisco', 'Vitinha', 'Rúben', 'Renato', 'Nuno', 'António'],
  'Hollanda': ['Daan', 'Sem', 'Milan', 'Levi', 'Luuk', 'Lucas', 'Bram', 'Finn', 'Thijs', 'Jesse', 'Sven', 'Lars', 'Ruben', 'Stijn', 'Tim', 'Niels', 'Cody', 'Virgil', 'Frenkie', 'Memphis', 'Nathan', 'Joey', 'Jerdy'],
  'Avusturya': ['Christoph', 'Stefan', 'Konrad', 'Marcel', 'Michael', 'Florian', 'Alexander', 'Nicolas', 'Xaver', 'Patrick', 'Guido', 'Maximilian', 'Romano', 'Phillipp', 'Gernot'],
  'Belçika': ['Kevin', 'Romelu', 'Youri', 'Arthur', 'Leandro', 'Amadou', 'Jeremy', 'Simon', 'Hans', 'Charles', 'Lois', 'Zeno', 'Wout', 'Timothy', 'Orel'],
  'İskoçya': ['Callum', 'John', 'Scott', 'Andy', 'Billy', 'Kieran', 'Lyndon', 'Che', 'Lawrence', 'Ryan', 'Greg', 'Stuart', 'Lewis', 'Nathan', 'Grant'],
  'Yunanistan': ['Kostas', 'Giorgos', 'Tasos', 'Fotis', 'Giannis', 'Vangelis', 'Dimitris', 'Petros', 'Panagiotis', 'Lazaros', 'Manolis', 'Sokratis', 'Stefanos', 'Marios'],
  'Danimarka': ['Christian', 'Rasmus', 'Pierre', 'Joachim', 'Kasper', 'Mikkel', 'Andreas', 'Jonas', 'Victor', 'Morten', 'Yussuf', 'Alexander', 'Jesper', 'Philip'],
  'İsveç': ['Dejan', 'Alexander', 'Viktor', 'Emil', 'Isak', 'Robin', 'Gabriel', 'Pontus', 'Ken', 'Ludwig', 'Samuel', 'Carl', 'Jesper', 'Hjalmar'],
  'İsviçre': ['Granit', 'Manuel', 'Breel', 'Denis', 'Silvan', 'Ruben', 'Fabian', 'Nico', 'Michel', 'Renato', 'Dan', 'Cedric', 'Gregor', 'Yvon'],
  'Romanya': ['Nicolae', 'Ianis', 'Radu', 'Razvan', 'Denis', 'Valentin', 'Florinel', 'Darius', 'George', 'Andrei', 'Cristian', 'Mihai', 'Alexandru', 'Stefan'],
  'Çekya': ['Patrik', 'Tomas', 'Vladimir', 'Lukas', 'Antonín', 'Adam', 'David', 'Ondrej', 'Jan', 'Robin', 'Pavel', 'Matej', 'Vaclav', 'Martin'],
  'Default': ['Alex', 'David', 'Daniel', 'Michael', 'Gabriel', 'Leo', 'Marc', 'Lucas', 'Victor', 'Julian', 'Sam', 'Eric', 'Adam', 'Martin', 'Luka', 'Marko', 'Nikola', 'Stefan', 'Ivan', 'Filip']
};

const LAST_NAMES_BY_COUNTRY: Record<string, string[]> = {
  'Türkiye': ['Yılmaz', 'Kaya', 'Demir', 'Şahin', 'Çelik', 'Yıldız', 'Yıldırım', 'Öztürk', 'Aydın', 'Özdemir', 'Arslan', 'Doğan', 'Kılıç', 'Aslan', 'Çetin', 'Bardakcı', 'Güler', 'Kabak', 'Söyüncü', 'Müldür', 'Kokcu', 'Özcan', 'Aydın'],
  'İspanya': ['García', 'Rodríguez', 'González', 'Fernández', 'López', 'Martínez', 'Sánchez', 'Pérez', 'Gómez', 'Martin', 'Jiménez', 'Ruiz', 'Hernández', 'Díaz', 'Olmo', 'Torres', 'Pedri', 'Navarro', 'Cucurella', 'Simón', 'Baena'],
  'İngiltere': ['Smith', 'Jones', 'Taylor', 'Brown', 'Williams', 'Wilson', 'Johnson', 'Davies', 'Robinson', 'Wright', 'Thompson', 'Evans', 'Walker', 'White', 'Kane', 'Saka', 'Rice', 'Pickford', 'Grealish', 'Bowen', 'Gordon', 'Mainoo'],
  'Almanya': ['Müller', 'Schmidt', 'Schneider', 'Fischer', 'Weber', 'Meyer', 'Wagner', 'Becker', 'Schulz', 'Hoffmann', 'Schäfer', 'Koch', 'Bauer', 'Richter', 'Musiala', 'Sané', 'Kimmich', 'Tah', 'Gundogan', 'Füllkrug', 'Wirtz', 'Andrich'],
  'İtalya': ['Rossi', 'Russo', 'Ferrari', 'Esposito', 'Bianchi', 'Romano', 'Colombo', 'Ricci', 'Marino', 'Greco', 'Bruno', 'Gallo', 'Conti', 'De Luca', 'Barella', 'Bastoni', 'Chiesa', 'Dimarco', 'Scamacca', 'Frattesi', 'Donnarumma', 'Tonali'],
  'Fransa': ['Martin', 'Bernard', 'Thomas', 'Petit', 'Robert', 'Richard', 'Durand', 'Dubois', 'Moreau', 'Laurent', 'Simon', 'Michel', 'Lefebvre', 'Leroy', 'Mbappe', 'Griezmann', 'Camavinga', 'Tchouameni', 'Saliba', 'Kounde', 'Maignan'],
  'Portekiz': ['Silva', 'Santos', 'Ferreira', 'Pereira', 'Oliveira', 'Costa', 'Rodrigues', 'Martins', 'Jesus', 'Sousa', 'Fernandes', 'Gonsalves', 'Lopes', 'Dias', 'Cancelo', 'Palhinha', 'Vitinha', 'Leao', 'Ramos', 'Felix'],
  'Hollanda': ['de Jong', 'Jansen', 'de Vries', 'van de Berg', 'van Dijk', 'Bakker', 'Janssen', 'Visser', 'Smit', 'Meijer', 'de Boer', 'Mulder', 'de Groot', 'Depay', 'Ake', 'Dumfries', 'Simons', 'Gakpo', 'Gravenberch', 'Verbruggen'],
  'Avusturya': ['Baumgartner', 'Laimer', 'Sabitzer', 'Arnautovic', 'Posch', 'Danso', 'Lienhart', 'Grillitsch', 'Seiwald', 'Wimmer', 'Pentz', 'Schlager', 'Kainz'],
  'Belçika': ['De Bruyne', 'Lukaku', 'Tielemans', 'Trossard', 'Onana', 'Doku', 'Castagne', 'Theate', 'Faes', 'Bakayoko', 'De Ketelaere', 'Debast', 'Mangala'],
  'İskoçya': ['McGinn', 'McTominay', 'Robertson', 'Gilmour', 'Tierney', 'Dykes', 'Adams', 'Shankland', 'Christie', 'McGregor', 'Ralston', 'McKenna', 'Hanley'],
  'Yunanistan': ['Tsimikas', 'Mavropanos', 'Bakasetas', 'Ioannidis', 'Masouras', 'Pelkas', 'Koulierakis', 'Rota', 'Siopis', 'Chatzidiakos', 'Galanopoulos', 'Bouchalakis'],
  'Danimarka': ['Eriksen', 'Højlund', 'Højbjerg', 'Andersen', 'Christensen', 'Schmeichel', 'Lindstrøm', 'Mæhle', 'Wind', 'Kristiansen', 'Damsgaard', 'Bah'],
  'İsveç': ['Isak', 'Kulusevski', 'Gyökeres', 'Forsberg', 'Lindelöf', 'Augustinsson', 'Svanberg', 'Cajuste', 'Elanga', 'Hien', 'Olsson', 'Starfelt'],
  'İsviçre': ['Xhaka', 'Akanji', 'Embolo', 'Zakaria', 'Widmer', 'Vargas', 'Freuler', 'Elvedi', 'Aebischer', 'Ndoye', 'Omlin', 'Zeqiri'],
  'Romanya': ['Stanciu', 'Hagi', 'Dragusin', 'Marin', 'Alibec', 'Mihaila', 'Coman', 'Olaru', 'Man', 'Puscas', 'Ratiu', 'Burca'],
  'Çekya': ['Schick', 'Soucek', 'Coufal', 'Cerny', 'Hlozek', 'Provod', 'Chytil', 'Barak', 'Jurasek', 'Zima', 'Holes', 'Stanek'],
  'Default': ['Silva', 'Santos', 'Johnson', 'Müller', 'Garcia', 'Martin', 'Novak', 'Kovac', 'Popov', 'Kovacs', 'Rossi', 'Weber', 'Smit', 'Modric', 'Brozovic', 'Vlahovic', 'Tadic', 'Mitrovic', 'Kvaratskhelia', 'Zelinski']
};

const POSITIONS = ['GK', 'DEF', 'DEF', 'DEF', 'DEF', 'MID', 'MID', 'MID', 'MID', 'FW', 'FW', 'FW'];
const ROLES: Record<string, string[]> = {
  GK: ['GK'],
  DEF: ['CB', 'LB', 'RB', 'CB'],
  MID: ['CDM', 'CM', 'CAM', 'LM', 'RM'],
  FW: ['ST', 'RW', 'LW', 'ST']
};

/**
 * Ensures any given team has AT LEAST 20 players with authentic, unique names.
 */
/**
 * Preserves actual authentic team squads completely as defined.
 * Only generates a squad if a dynamic filler team has no players at all.
 */
export function ensureTeamHas20Players<T extends { id?: string; players: Player[]; overall?: number; country?: string; name?: string; logoUrl?: string }>(
  team: T
): T {
  const existingPlayers: Player[] = [...(team.players || [])];
  const existingNames = new Set<string>();

  existingPlayers.forEach(p => {
    if (p.name) existingNames.add(p.name.trim().toLowerCase());
  });

  const country = team.country || 'Türkiye';
  const realPool = REAL_PLAYERS_BY_COUNTRY[country] || DEFAULT_REAL_PLAYERS;
  const firstNames = FIRST_NAMES_BY_COUNTRY[country] || FIRST_NAMES_BY_COUNTRY['Default'];
  const lastNames = LAST_NAMES_BY_COUNTRY[country] || LAST_NAMES_BY_COUNTRY['Default'];

  const targetCount = 20;
  if (existingPlayers.length >= targetCount) {
    return {
      ...team,
      logoUrl: team.logoUrl || getTeamLogoUrl(team.name || team.id),
      players: existingPlayers
    };
  }

  const newPlayers: Player[] = [];
  const baseOvr = Math.max(68, (team.overall || 75) - 3);

  // 1. First attempt to add unused real player templates from country pool
  for (const tmpl of realPool) {
    if (existingPlayers.length + newPlayers.length >= targetCount) break;
    const cleanTmplName = tmpl.name.trim().toLowerCase();
    if (!existingNames.has(cleanTmplName)) {
      existingNames.add(cleanTmplName);

      const marketValue = Math.round((Math.pow(tmpl.overall / 70, 3) * 3500000) / 500000) * 500000;
      const wage = Math.round(marketValue / 1000 / 50) * 50;

      const p: Player = {
        id: `real-${team.id || 'team'}-${existingPlayers.length + newPlayers.length + 1}-${Math.random().toString(36).substr(2, 5)}`,
        name: tmpl.name,
        age: tmpl.age,
        position: tmpl.position,
        specificRole: tmpl.role,
        overall: tmpl.overall,
        stamina: Math.floor(Math.random() * 10) + 84,
        form: parseFloat((7.6 + Math.random() * 1.2).toFixed(1)),
        marketValue: tmpl.value || marketValue,
        wage: Math.max(6000, tmpl.wage || wage),
        nationality: tmpl.nationality || country,
        attributes: {
          pace: Math.min(95, Math.max(50, tmpl.overall + Math.floor(Math.random() * 8) - 4)),
          shooting: Math.min(95, Math.max(30, tmpl.position === 'FW' ? tmpl.overall + 5 : tmpl.overall - 12)),
          passing: Math.min(95, Math.max(50, tmpl.position === 'MID' ? tmpl.overall + 5 : tmpl.overall - 4)),
          defending: Math.min(95, Math.max(30, tmpl.position === 'DEF' ? tmpl.overall + 5 : tmpl.position === 'GK' ? tmpl.overall + 4 : tmpl.overall - 20)),
          physical: Math.min(95, Math.max(55, tmpl.overall + Math.floor(Math.random() * 6) - 3))
        },
        isStarting: false
      };
      newPlayers.push(p);
    }
  }

  // 2. If still needed, construct unique authentic full names without duplicates
  let attempts = 0;
  while (existingPlayers.length + newPlayers.length < targetCount && attempts < 400) {
    attempts++;
    const fName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lName = lastNames[Math.floor(Math.random() * lastNames.length)];
    const fullName = `${fName} ${lName}`;
    const cleanFullName = fullName.trim().toLowerCase();

    if (existingNames.has(cleanFullName)) {
      continue;
    }
    existingNames.add(cleanFullName);

    const pos = POSITIONS[(existingPlayers.length + newPlayers.length) % POSITIONS.length];
    const roles = ROLES[pos] || [pos];
    const role = roles[Math.floor(Math.random() * roles.length)];

    const age = Math.floor(Math.random() * 10) + 18; // 18-27
    const ovrOffset = Math.floor(Math.random() * 6) - 3;
    const playerOvr = Math.min(86, Math.max(68, baseOvr + ovrOffset));

    const marketValue = Math.round((Math.pow(playerOvr / 70, 3) * 3500000) / 500000) * 500000;
    const wage = Math.round(marketValue / 1000 / 50) * 50;

    const p: Player = {
      id: `gen-${team.id || 'team'}-${existingPlayers.length + newPlayers.length + 1}-${Math.random().toString(36).substr(2, 5)}`,
      name: fullName,
      age,
      position: pos as 'GK' | 'DEF' | 'MID' | 'FW',
      specificRole: role,
      overall: playerOvr,
      stamina: Math.floor(Math.random() * 12) + 82,
      form: parseFloat((7.5 + Math.random() * 1.2).toFixed(1)),
      marketValue,
      wage: Math.max(5000, wage),
      nationality: country,
      attributes: {
        pace: Math.min(95, Math.max(50, playerOvr + Math.floor(Math.random() * 10) - 5)),
        shooting: Math.min(95, Math.max(30, pos === 'FW' ? playerOvr + 4 : playerOvr - 15)),
        passing: Math.min(95, Math.max(50, pos === 'MID' ? playerOvr + 5 : playerOvr - 5)),
        defending: Math.min(95, Math.max(30, pos === 'DEF' ? playerOvr + 5 : pos === 'GK' ? playerOvr + 4 : playerOvr - 20)),
        physical: Math.min(95, Math.max(55, playerOvr + Math.floor(Math.random() * 8) - 4))
      },
      isStarting: false
    };

    newPlayers.push(p);
  }

  const allSquad = [...existingPlayers, ...newPlayers];
  
  // Ensure EXACTLY 11 starting players exist and have valid, unique starterIndex (0..10)
  const starters = allSquad.filter(p => p.isStarting);
  if (starters.length < 11) {
    // Reset all isStarting first to cleanly select best 11
    allSquad.forEach(p => {
      p.isStarting = false;
      delete p.starterIndex;
    });

    // 1. Pick best GK for Slot 0
    const gkList = allSquad.filter(p => p.position === 'GK').sort((a, b) => (b.overall || 70) - (a.overall || 70));
    const mainGk = gkList[0] || allSquad[0];
    if (mainGk) {
      mainGk.isStarting = true;
      mainGk.starterIndex = 0;
    }

    // 2. Pick best 4 DEF for Slots 1..4
    const defList = allSquad.filter(p => p.position === 'DEF' && !p.isStarting).sort((a, b) => (b.overall || 70) - (a.overall || 70));
    for (let i = 0; i < 4 && i < defList.length; i++) {
      defList[i].isStarting = true;
      defList[i].starterIndex = 1 + i;
    }

    // 3. Pick best 3 MID for Slots 5..7
    const midList = allSquad.filter(p => p.position === 'MID' && !p.isStarting).sort((a, b) => (b.overall || 70) - (a.overall || 70));
    for (let i = 0; i < 3 && i < midList.length; i++) {
      midList[i].isStarting = true;
      midList[i].starterIndex = 5 + i;
    }

    // 4. Pick best 3 FW for Slots 8..10
    const fwList = allSquad.filter(p => p.position === 'FW' && !p.isStarting).sort((a, b) => (b.overall || 70) - (a.overall || 70));
    for (let i = 0; i < 3 && i < fwList.length; i++) {
      fwList[i].isStarting = true;
      fwList[i].starterIndex = 8 + i;
    }

    // 5. Fill any remaining unassigned slots from 0..10 with top remaining players
    const assignedSlots = new Set<number>();
    allSquad.forEach(p => {
      if (p.isStarting && p.starterIndex !== undefined && p.starterIndex >= 0 && p.starterIndex < 11) {
        assignedSlots.add(p.starterIndex);
      }
    });

    for (let slot = 0; slot < 11; slot++) {
      if (!assignedSlots.has(slot)) {
        const nextCandidate = allSquad.find(p => !p.isStarting);
        if (nextCandidate) {
          nextCandidate.isStarting = true;
          nextCandidate.starterIndex = slot;
          assignedSlots.add(slot);
        }
      }
    }
  } else {
    // If we have at least 11 starters, ensure each has a unique starterIndex 0..10
    const usedIndices = new Set<number>();
    starters.slice(0, 11).forEach(p => {
      if (p.starterIndex !== undefined && p.starterIndex >= 0 && p.starterIndex < 11 && !usedIndices.has(p.starterIndex)) {
        usedIndices.add(p.starterIndex);
      } else {
        delete p.starterIndex;
      }
    });

    let nextIdx = 0;
    starters.slice(0, 11).forEach(p => {
      if (p.starterIndex === undefined) {
        while (usedIndices.has(nextIdx) && nextIdx < 11) {
          nextIdx++;
        }
        if (nextIdx < 11) {
          p.starterIndex = nextIdx;
          usedIndices.add(nextIdx);
        }
      }
    });

    // Make sure any extra starters beyond 11 are set to bench
    starters.slice(11).forEach(p => {
      p.isStarting = false;
      delete p.starterIndex;
    });
  }

  return {
    ...team,
    logoUrl: team.logoUrl || getTeamLogoUrl(team.name || team.id),
    players: allSquad
  };
}
