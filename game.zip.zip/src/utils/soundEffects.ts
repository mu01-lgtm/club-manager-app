// Web Audio API Sound Synthesizer for Football Manager Global
// Zero external assets required, instant & crisp feedback across browsers

class SoundManager {
  private ctx: AudioContext | null = null;
  private soundEnabled: boolean = true;

  constructor() {
    const savedSetting = localStorage.getItem('fm_sound_enabled');
    this.soundEnabled = savedSetting !== null ? savedSetting === 'true' : true;

    // Attach global click sound listener
    if (typeof window !== 'undefined') {
      window.addEventListener('click', (e) => {
        if (!this.soundEnabled) return;
        const target = e.target as HTMLElement;
        if (
          target &&
          (target.closest('button') ||
            target.closest('a') ||
            target.closest('[role="button"]') ||
            target.closest('.cursor-pointer'))
        ) {
          this.playButtonClick();
        }
      }, { passive: true });
    }
  }

  public isEnabled(): boolean {
    return this.soundEnabled;
  }

  public setEnabled(enabled: boolean): void {
    this.soundEnabled = enabled;
    localStorage.setItem('fm_sound_enabled', enabled ? 'true' : 'false');
  }

  private getContext(): AudioContext | null {
    if (!this.soundEnabled) return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  // Crisp Button Click / Tap Sound
  public playButtonClick(): void {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(150, ctx.currentTime + 0.04);

      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.04);
    } catch (e) {
      console.warn('Audio click failed', e);
    }
  }

  // Goal Scored Fanfare / Stadium Horn
  public playGoalScored(): void {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;

      // Horn 1
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sawtooth';
      osc1.frequency.setValueAtTime(220, now); // A3
      osc1.frequency.exponentialRampToValueAtTime(440, now + 0.2); // A4

      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(330, now); // E4
      osc2.frequency.exponentialRampToValueAtTime(660, now + 0.2); // E5

      gain.gain.setValueAtTime(0.01, now);
      gain.gain.linearRampToValueAtTime(0.3, now + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.8);
      osc2.stop(now + 0.8);

      // Followed by high chime
      setTimeout(() => {
        const chimeCtx = this.getContext();
        if (!chimeCtx) return;
        const cNow = chimeCtx.currentTime;
        const oscChime = chimeCtx.createOscillator();
        const chimeGain = chimeCtx.createGain();

        oscChime.type = 'sine';
        oscChime.frequency.setValueAtTime(880, cNow); // A5
        oscChime.frequency.exponentialRampToValueAtTime(1760, cNow + 0.3);

        chimeGain.gain.setValueAtTime(0.25, cNow);
        chimeGain.gain.exponentialRampToValueAtTime(0.001, cNow + 0.5);

        oscChime.connect(chimeGain);
        chimeGain.connect(chimeCtx.destination);

        oscChime.start(cNow);
        oscChime.stop(cNow + 0.5);
      }, 150);

    } catch (e) {
      console.warn('Goal sound failed', e);
    }
  }

  // Goal Conceded / Disappointment Tone
  public playGoalConceded(): void {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(240, now);
      osc.frequency.exponentialRampToValueAtTime(90, now + 0.5);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.5);
    } catch (e) {
      console.warn('Conceded sound failed', e);
    }
  }

  // Referee Whistle
  public playWhistle(): void {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(2600, now);
      osc.frequency.setValueAtTime(2800, now + 0.05);
      osc.frequency.setValueAtTime(2600, now + 0.1);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.3);
    } catch (e) {
      console.warn('Whistle sound failed', e);
    }
  }
}

export const soundFx = new SoundManager();
