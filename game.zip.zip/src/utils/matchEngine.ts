import { Team, MatchEvent, MatchStats, Player, EventType, PlayerRating, FormationType } from '../types';
import { evaluatePlayerPositionFit } from './playerFootSkills';

export interface InjuredPlayerInfo {
  playerId: string;
  playerName: string;
  teamId: string;
  injuryType: string;
  weeks: number;
}

export function getPowerhouseHiddenBoost(teamName: string): number {
  if (!teamName) return 0;
  const name = teamName.toLowerCase().trim();

  // Süper Lig Giant Powerhouses
  if (name.includes('galatasaray') || name.includes('fenerbahçe') || name.includes('fenerbahce')) {
    return 6;
  }
  if (name.includes('beşiktaş') || name.includes('besiktas') || name.includes('trabzonspor')) {
    return 5;
  }

  // La Liga Powerhouses
  if (name.includes('real madrid') || name.includes('barcelona') || name.includes('atletico') || name.includes('atlético')) {
    return 6;
  }

  // Premier League Powerhouses
  if (
    name.includes('manchester city') || name.includes('man city') ||
    name.includes('manchester united') || name.includes('man utd') ||
    name.includes('liverpool') || name.includes('arsenal') ||
    name.includes('chelsea') || name.includes('tottenham')
  ) {
    return 6;
  }

  // Ligue 1 Powerhouses
  if (name.includes('paris') || name.includes('psg') || name.includes('lyon') || name.includes('marseille') || name.includes('monaco')) {
    return 5;
  }

  // Serie A Powerhouses
  if (name.includes('juventus') || name.includes('inter') || name.includes('milan') || name.includes('napoli') || name.includes('roma') || name.includes('lazio')) {
    return 5;
  }

  // Bundesliga Powerhouses
  if (name.includes('bayern') || name.includes('dortmund') || name.includes('leipzig') || name.includes('leverkusen')) {
    return 6;
  }

  // Other European Giants
  if (name.includes('ajax') || name.includes('psv') || name.includes('feyenoord') || name.includes('benfica') || name.includes('porto') || name.includes('sporting')) {
    return 4;
  }

  return 0;
}

export function getSlotCategory(index: number, formation?: FormationType): 'GK' | 'DEF' | 'MID' | 'FW' {
  if (index === 0) return 'GK';
  const f = formation || '4-2-3-1';
  switch (f) {
    case '4-2-3-1':
      if (index >= 1 && index <= 4) return 'DEF';
      if (index >= 5 && index <= 9) return 'MID';
      return 'FW';
    case '4-3-3':
      if (index >= 1 && index <= 4) return 'DEF';
      if (index >= 5 && index <= 7) return 'MID';
      return 'FW';
    case '4-4-2':
      if (index >= 1 && index <= 4) return 'DEF';
      if (index >= 5 && index <= 8) return 'MID';
      return 'FW';
    case '3-5-2':
      if (index >= 1 && index <= 3) return 'DEF';
      if (index >= 4 && index <= 8) return 'MID';
      return 'FW';
    case '5-3-2':
      if (index >= 1 && index <= 5) return 'DEF';
      if (index >= 6 && index <= 8) return 'MID';
      return 'FW';
    case '4-1-4-1':
      if (index >= 1 && index <= 4) return 'DEF';
      if (index >= 5 && index <= 9) return 'MID';
      return 'FW';
    case '3-4-3':
      if (index >= 1 && index <= 3) return 'DEF';
      if (index >= 4 && index <= 7) return 'MID';
      return 'FW';
    default:
      if (index >= 1 && index <= 4) return 'DEF';
      if (index >= 5 && index <= 8) return 'MID';
      return 'FW';
  }
}

export function calculatePlayerEffectiveOverall(
  player: Player,
  slotIndex: number,
  formation?: FormationType
): { effectiveOverall: number; penalty: number; isOutOfPosition: boolean; assignedSlot: 'GK' | 'DEF' | 'MID' | 'FW'; isRedAlert: boolean; fitLabel: string } {
  const evalResult = evaluatePlayerPositionFit(player, slotIndex, formation);
  return {
    effectiveOverall: evalResult.effectiveOverall,
    penalty: evalResult.penalty,
    isOutOfPosition: evalResult.isRedAlert,
    isRedAlert: evalResult.isRedAlert,
    assignedSlot: evalResult.assignedSlotCategory,
    fitLabel: evalResult.fitLabel
  };
}

export function calculateStartingXIOverall(team: Team): number {
  const starters = team.players.filter(p => p.isStarting && !p.isInjured).slice(0, 11);
  if (starters.length === 0) return 70;
  const total = starters.reduce((acc, p, idx) => {
    const eff = calculatePlayerEffectiveOverall(p, idx, team.formation);
    return acc + eff.effectiveOverall;
  }, 0);
  return Math.round(total / starters.length);
}

// Calculate post-match stamina drain based on age
export function calculatePostMatchStamina(player: Player): number {
  let drain = 6;
  if (player.age <= 22) {
    drain = 6 + Math.floor(Math.random() * 3); // 6-8 drain
  } else if (player.age <= 29) {
    drain = 5 + Math.floor(Math.random() * 3); // 5-7 drain
  } else {
    // Older players manage their pace better & suffer even less fatigue
    drain = 3 + Math.floor(Math.random() * 3); // 3-5 drain
  }
  return Math.max(82, player.stamina - drain);
}

export function generateMatchEvents(
  homeTeam: Team,
  awayTeam: Team,
  difficulty?: string,
  userTeamId?: string
): { 
  events: MatchEvent[]; 
  stats: MatchStats; 
  finalHomeScore: number; 
  finalAwayScore: number;
  injuredPlayers: InjuredPlayerInfo[];
  playerRatings: PlayerRating[];
} {
  let homeStarters = (homeTeam.players || []).filter(p => p.isStarting && !p.isInjured).slice(0, 11);
  if (homeStarters.length < 11) {
    const remaining = (homeTeam.players || []).filter(p => !homeStarters.some(s => s.id === p.id) && !p.isInjured).slice(0, 11 - homeStarters.length);
    homeStarters = [...homeStarters, ...remaining];
  }
  let awayStarters = (awayTeam.players || []).filter(p => p.isStarting && !p.isInjured).slice(0, 11);
  if (awayStarters.length < 11) {
    const remaining = (awayTeam.players || []).filter(p => !awayStarters.some(s => s.id === p.id) && !p.isInjured).slice(0, 11 - awayStarters.length);
    awayStarters = [...awayStarters, ...remaining];
  }

  // Maintain active line-ups strictly on the pitch during simulation
  let homeOnField: Player[] = [...homeStarters];
  let awayOnField: Player[] = [...awayStarters];

  // Helper for position-weighted attacker selection (Forwards & Wingers have significantly higher probability)
  const selectWeightedAttacker = (onField: Player[]): Player => {
    if (onField.length === 0) return onField[0];
    const weights = onField.map(p => {
      const role = (p.specificRole || '').toUpperCase();
      const pos = (p.position || '').toUpperCase();
      // Forwards (ST, CF, FW, SF, FG, KF, HS)
      if (pos === 'FW' || role.includes('ST') || role.includes('CF') || role.includes('SF') || role.includes('FG') || role.includes('KF') || role.includes('HS')) {
        return 6.0;
      }
      // Wingers & Attacking Midfielders (LW, RW, LM, RM, CAM, SGK, SLK, TAK, OOK, OOS)
      if (role.includes('LW') || role.includes('RW') || role.includes('LM') || role.includes('RM') || role.includes('CAM') || role.includes('SGK') || role.includes('SLK') || role.includes('TAK') || role.includes('OOK') || role.includes('OOS')) {
        return 4.5;
      }
      // Central Midfielders (CM, CDM, MID, DOS, B2B, DOK)
      if (pos === 'MID' || role.includes('CM') || role.includes('CDM') || role.includes('DOS') || role.includes('B2B') || role.includes('DOK')) {
        return 2.0;
      }
      // Fullbacks / Wing-backs (LB, RB, LWB, RWB, HB, İKB)
      if (role.includes('LB') || role.includes('RB') || role.includes('LWB') || role.includes('RWB') || role.includes('HB') || role.includes('İKB')) {
        return 1.0;
      }
      // Center Backs (CB, DEF, SS, ÇS, PS)
      if (pos === 'DEF' || role.includes('CB') || role.includes('SS') || role.includes('ÇS') || role.includes('PS')) {
        return 0.5;
      }
      return 0.05; // Goalkeeper
    });

    const total = weights.reduce((acc, w) => acc + w, 0);
    let r = Math.random() * total;
    for (let i = 0; i < onField.length; i++) {
      r -= weights[i];
      if (r <= 0) return onField[i];
    }
    return onField[0];
  };

  // Helper for selecting defending player on field
  const selectDefendingPlayer = (onField: Player[]): Player => {
    const defenders = onField.filter(p => p.position === 'DEF');
    if (defenders.length > 0) return defenders[Math.floor(Math.random() * defenders.length)];
    const mids = onField.filter(p => p.position === 'MID');
    if (mids.length > 0) return mids[Math.floor(Math.random() * mids.length)];
    return onField[0];
  };

  let homeAvg = calculateStartingXIOverall(homeTeam) + getPowerhouseHiddenBoost(homeTeam.name);
  let awayAvg = calculateStartingXIOverall(awayTeam) + getPowerhouseHiddenBoost(awayTeam.name);

  // Apply Game Difficulty Impact
  if (difficulty === 'ZOR' && userTeamId) {
    if (homeTeam.id === userTeamId) {
      awayAvg += 8; // AI opponent is boosted
    } else if (awayTeam.id === userTeamId) {
      homeAvg += 8;
    }
  } else if (difficulty === 'KOLAY' && userTeamId) {
    if (homeTeam.id === userTeamId) {
      homeAvg += 6;
    } else if (awayTeam.id === userTeamId) {
      awayAvg += 6;
    }
  }

  let homeWeight = homeAvg + (homeTeam.tactic === 'ATTACKING' ? 3 : homeTeam.tactic === 'DEFENSIVE' ? -2 : 0) + 2;
  let awayWeight = awayAvg + (awayTeam.tactic === 'ATTACKING' ? 3 : awayTeam.tactic === 'DEFENSIVE' ? -2 : 0);

  const totalWeight = homeWeight + awayWeight;
  const homeProb = homeWeight / totalWeight;

  const events: MatchEvent[] = [];
  const injuredPlayers: InjuredPlayerInfo[] = [];

  let scoreHome = 0;
  let scoreAway = 0;

  let shotsHome = 0;
  let shotsAway = 0;
  let shotsOnTargetHome = 0;
  let shotsOnTargetAway = 0;
  let cornersHome = 0;
  let cornersAway = 0;

  // Dynamic fouls for each team (realistic random range)
  let foulsHome = Math.floor(Math.random() * 7) + 6;
  let foulsAway = Math.floor(Math.random() * 7) + 6;
  let yellowHome = 0;
  let yellowAway = 0;
  let redHome = 0;
  let redAway = 0;

  // Track cards per player
  const playerYellowCards: Record<string, number> = {};

  // Track player goals & assists for match ratings
  const playerGoalCount: Record<string, number> = {};
  const playerAssistCount: Record<string, number> = {};

  // Kickoff
  events.push({
    id: `ev-0-${Math.random().toString(36).substring(2, 7)}`,
    minute: 1,
    type: 'KICK_OFF',
    text: `Hakem düdüğünü çaldı ve maç ${homeTeam.name} - ${awayTeam.name} arasında başladı!`,
    teamId: homeTeam.id,
    isHomeTeamEvent: true,
    scoreHome: 0,
    scoreAway: 0
  });

  const minutesToSimulate = [
    3, 7, 12, 18, 24, 29, 35, 41, 44, 45,
    48, 54, 61, 67, 73, 79, 84, 88, 90
  ];

  // Injury possibilities (small chance: ~12% chance in a match)
  const injuryOccurred = Math.random() < 0.12;
  const injuryMinute = injuryOccurred ? [18, 35, 54, 73][Math.floor(Math.random() * 4)] : -1;

  // Tactical modifiers
  const homeTactics = homeTeam.tacticalDetails || {};
  const awayTactics = awayTeam.tacticalDetails || {};

  const homeLongShots = homeTactics.shooting === 'Uzaktan Şut' || homeTactics.shooting === 'Gördüğü Yerden Şut';
  const awayLongShots = awayTactics.shooting === 'Uzaktan Şut' || awayTactics.shooting === 'Gördüğü Yerden Şut';

  for (const minute of minutesToSimulate) {
    if (minute === 45) {
      events.push({
        id: `ev-ht`,
        minute: 45,
        type: 'HALF_TIME',
        text: `Hakem ilk yarıyı bitiren düdüğü çaldı. İlk Yarı Sonucu: ${homeTeam.name} ${scoreHome} - ${scoreAway} ${awayTeam.name}`,
        teamId: homeTeam.id,
        isHomeTeamEvent: true,
        scoreHome,
        scoreAway
      });
      continue;
    }

    // Check Injury
    if (injuryOccurred && minute === injuryMinute && injuredPlayers.length === 0) {
      const isHomeInjured = Math.random() < 0.5;
      const targetTeam = isHomeInjured ? homeTeam : awayTeam;
      const targetOnField = isHomeInjured ? homeOnField : awayOnField;
      const injuredPlayer = targetOnField[Math.floor(Math.random() * targetOnField.length)];

      if (injuredPlayer) {
        const injuryTypes = [
          { type: 'Adale Zorlanması', weeks: 2 },
          { type: 'Diz Burkulması', weeks: 3 },
          { type: 'Bilek Burkulması', weeks: 2 },
          { type: 'Kas Yırtığı', weeks: 4 }
        ];
        const selectedInjury = injuryTypes[Math.floor(Math.random() * injuryTypes.length)];

        injuredPlayers.push({
          playerId: injuredPlayer.id,
          playerName: injuredPlayer.name,
          teamId: targetTeam.id,
          injuryType: selectedInjury.type,
          weeks: selectedInjury.weeks
        });

        events.push({
          id: `ev-${minute}-inj`,
          minute,
          type: 'INJURY',
          text: `SAKATLIK! 🚑 ${injuredPlayer.name} acı içinde yerde kaldı. Sağlık ekibi sahada! (${selectedInjury.type})`,
          teamId: targetTeam.id,
          playerName: injuredPlayer.name,
          isHomeTeamEvent: isHomeInjured,
          scoreHome,
          scoreAway
        });
      }
    }

    const isHome = Math.random() < homeProb;
    const activeTeam = isHome ? homeTeam : awayTeam;
    const activeOnField = isHome ? homeOnField : awayOnField;
    const opponentTeam = isHome ? awayTeam : homeTeam;
    const opponentOnField = isHome ? awayOnField : homeOnField;
    const activeTactics = isHome ? homeTactics : awayTactics;

    if (activeOnField.length === 0 || opponentOnField.length === 0) continue;

    const randomVal = Math.random();

    // Select weighted attacker on field (Forwards & Wingers favored)
    const attacker: Player = selectWeightedAttacker(activeOnField);
    const defender: Player = selectDefendingPlayer(opponentOnField);
    const gk: Player = opponentOnField.find(p => p.position === 'GK') || opponentOnField[0];

    const wantsLongShots = isHome ? homeLongShots : awayLongShots;

    // Special Set-Piece: Penalty Kick Opportunity (realistic rare chance: approx 2.5% chance per attack event)
    const isPenaltyEvent = randomVal > 0.01 && randomVal <= 0.035;
    if (isPenaltyEvent) {
      // Find designated penalty taker or best shooter on field
      const penaltyTaker = activeOnField.find(p => p.id === activeTactics.penaltyTakerId) || 
                           [...activeOnField].sort((a, b) => (b.attributes?.shooting || b.overall) - (a.attributes?.shooting || a.overall))[0] || 
                           attacker;
      
      const penaltySuccessChance = 0.74 + ((penaltyTaker.attributes?.shooting || penaltyTaker.overall) - (gk.attributes?.defending || gk.overall)) * 0.008;
      
      if (isHome) shotsHome++; else shotsAway++;
      
      if (Math.random() < Math.min(0.88, Math.max(0.60, penaltySuccessChance))) {
        // PENALTY GOAL
        if (isHome) { scoreHome++; shotsOnTargetHome++; }
        else { scoreAway++; shotsOnTargetAway++; }

        playerGoalCount[penaltyTaker.id] = (playerGoalCount[penaltyTaker.id] || 0) + 1;

        events.push({
          id: `ev-pen-goal-${minute}-${Math.random()}`,
          minute,
          type: 'GOAL',
          text: `PENALTI GOLÜ! ⚽🎯 Hakem beyaz noktayı gösterdi! Topun başına geçen ${penaltyTaker.name} soğukkanlı bir vuruşla kaleci ${gk.name}'yi ters köşeye yatırdı!`,
          teamId: activeTeam.id,
          playerName: penaltyTaker.name,
          playerId: penaltyTaker.id,
          scorerId: penaltyTaker.id,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway,
          isPenalty: true
        });
      } else if (Math.random() < 0.65) {
        // PENALTY SAVED
        if (isHome) shotsOnTargetHome++; else shotsOnTargetAway++;
        events.push({
          id: `ev-pen-save-${minute}-${Math.random()}`,
          minute,
          type: 'SAVE',
          text: `PENALTI KAÇTI! 🧤 Hakem penaltıyı verdi! ${penaltyTaker.name} vurdu fakat kaleci ${gk.name} harika bir refleksle köşeden çıkardı!`,
          teamId: activeTeam.id,
          playerName: penaltyTaker.name,
          playerId: penaltyTaker.id,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway,
          isPenalty: true,
          isPenaltyMissed: true
        });
      } else {
        // PENALTY MISSED
        events.push({
          id: `ev-pen-miss-${minute}-${Math.random()}`,
          minute,
          type: 'MISS',
          text: `PENALTI AUTA GİTTİ! ❌ ${penaltyTaker.name} penaltı noktasında topu direğin yanından dışarıya gönderdi!`,
          teamId: activeTeam.id,
          playerName: penaltyTaker.name,
          playerId: penaltyTaker.id,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway,
          isPenalty: true,
          isPenaltyMissed: true
        });
      }
      continue;
    }

    // Special Set-Piece: Freekick Opportunity (approx 8-10% chance)
    const isFreekickEvent = randomVal > 0.12 && randomVal <= 0.21;
    if (isFreekickEvent) {
      // Find designated freekick taker or best set-piece specialist on field
      const freekickTaker = activeOnField.find(p => p.id === activeTactics.freekickTakerId) || 
                            [...activeOnField].sort((a,b) => (Math.max(b.attributes?.shooting || 0, b.attributes?.passing || 0) || b.overall) - (Math.max(a.attributes?.shooting || 0, a.attributes?.passing || 0) || a.overall))[0] || 
                            attacker;
      
      const fkSkill = Math.max(freekickTaker.attributes?.shooting || 0, freekickTaker.attributes?.passing || 0) || freekickTaker.overall;
      const fkGoalProb = 0.28 + (fkSkill - (gk.attributes?.defending || gk.overall)) * 0.007;

      if (Math.random() < Math.min(0.48, Math.max(0.20, fkGoalProb))) { // GOAL from freekick
        if (isHome) { scoreHome++; shotsHome++; shotsOnTargetHome++; } 
        else { scoreAway++; shotsAway++; shotsOnTargetAway++; }

        playerGoalCount[freekickTaker.id] = (playerGoalCount[freekickTaker.id] || 0) + 1;

        events.push({
          id: `ev-fk-goal-${minute}-${Math.random()}`,
          minute,
          type: 'GOAL',
          text: `MÜTHİŞ FRİKİK GOLÜ! ⚽🎯 ${freekickTaker.name} serbest vuruştan muazzam bir şut çıkardı, top barajın üstünden 90'a gitti!`,
          teamId: activeTeam.id,
          playerName: freekickTaker.name,
          playerId: freekickTaker.id,
          scorerId: freekickTaker.id,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway
        });
      } else if (Math.random() < 0.6) { // SAVE from freekick
        if (isHome) { shotsHome++; shotsOnTargetHome++; } else { shotsAway++; shotsOnTargetAway++; }
        events.push({
          id: `ev-fk-save-${minute}-${Math.random()}`,
          minute,
          type: 'SAVE',
          text: `TEHLİKELİ SERBEST VURUŞ! 🎯 ${freekickTaker.name} direkt kaleye vurdu! Kaleci ${gk.name} harika uzanıp kornere çeldi! 🧤`,
          teamId: activeTeam.id,
          playerName: freekickTaker.name,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway
        });
      } else { // MISS from freekick
        if (isHome) shotsHome++; else shotsAway++;
        events.push({
          id: `ev-fk-miss-${minute}-${Math.random()}`,
          minute,
          type: 'MISS',
          text: `FRİKİK! 🎯 ${freekickTaker.name} barajın üstünden kaleyi denedi, top az farkla üstten dışarıya çıktı.`,
          teamId: activeTeam.id,
          playerName: freekickTaker.name,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway
        });
      }
      continue;
    }

    // CHECK OPPONENT MARKING ON CURRENT ATTACKER
    const opponentTactics = isHome ? awayTactics : homeTactics;
    const isAttackerMarked = opponentTactics.markedPlayerIds?.includes(attacker.id);
    const attackerMarkingType = isAttackerMarked ? (opponentTactics.markingType?.[attacker.id] || 'TIGHT') : null;

    // If opponent put DOUBLE or PRESS on this player, there's a strong chance of early interception
    if (isAttackerMarked) {
      if (attackerMarkingType === 'DOUBLE' && Math.random() < 0.48) {
        events.push({
          id: `ev-mark-double-${minute}-${Math.random()}`,
          minute,
          type: 'ATTACK',
          text: `İKİLİ SIKI MARKAJ! 🛡️ ${attacker.name} topla buluştuğu anda ${defender.name} ve kademedeki savunma araya girerek tehlikeyi büyümeden önledi!`,
          teamId: activeTeam.id,
          playerName: attacker.name,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway
        });
        continue;
      }

      if (attackerMarkingType === 'PRESS' && Math.random() < 0.42) {
        events.push({
          id: `ev-mark-press-${minute}-${Math.random()}`,
          minute,
          type: 'ATTACK',
          text: `ŞOK PRES! ⚡ ${defender.name}, ${attacker.name}'a nefes aldırmayarak presle topu kaptı ve kontra atağı başlattı!`,
          teamId: activeTeam.id,
          playerName: attacker.name,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway
        });
        continue;
      }
    }

    if (randomVal < (wantsLongShots ? 0.38 : 0.28)) { // GOAL OR SHOT
      if (isHome) shotsHome++; else shotsAway++;

      // Higher finishing and goal probability for forwards & wingers naturally
      const roleUpper = ((activeTactics.playerRoles?.[attacker.id] || attacker.specificRole || '')).toUpperCase();
      const posBonus = attacker.position === 'FW' || roleUpper.includes('FIRSATÇI') || roleUpper.includes('KOMPLE') || roleUpper.includes('ST') || roleUpper.includes('CF') || roleUpper.includes('SF') 
        ? 0.14 
        : roleUpper.includes('KANAT') || roleUpper.includes('LW') || roleUpper.includes('RW') || roleUpper.includes('CAM') || roleUpper.includes('OFANSİF')
          ? 0.09 
          : attacker.position === 'MID' 
            ? 0.03 
            : -0.05;

      // Role specific bonuses
      let roleFinishingMultiplier = 1.0;
      if (roleUpper.includes('FIRSATÇI')) roleFinishingMultiplier = 1.30;
      if (roleUpper.includes('KOMPLE')) roleFinishingMultiplier = 1.20;
      if (roleUpper.includes('SAVAŞÇI') || roleUpper.includes('ÇAKILI')) roleFinishingMultiplier = 0.85;

      let goalChance = (0.26 + posBonus + ((attacker.attributes?.shooting || attacker.overall) - (gk.attributes?.defending || gk.overall)) * 0.015) * roleFinishingMultiplier;
      
      // Tactical instructions impact on shots
      if (activeTactics.workBallIntoBox) {
        goalChance *= 1.15; // Better quality chances in the box
      }
      if (activeTactics.shootOnSight) {
        goalChance *= 0.90; // More hasty shots
      }
      if (wantsLongShots) {
        goalChance *= 0.75;
      }

      // Marking impact on attacker goal conversion
      if (isAttackerMarked) {
        if (attackerMarkingType === 'TIGHT') goalChance *= 0.65; // Sıkı markaj reduces goal rate by 35%
        if (attackerMarkingType === 'WEAK_FOOT') goalChance *= 0.60; // Forced to weak foot
        if (attackerMarkingType === 'HARD_TACKLE') goalChance *= 0.70;
      }

      if (difficulty === 'ZOR' && userTeamId) {
        if (activeTeam.id === userTeamId) goalChance *= 0.65;
        else goalChance *= 1.35;
      } else if (difficulty === 'KOLAY' && userTeamId) {
        if (activeTeam.id === userTeamId) goalChance *= 1.30;
        else goalChance *= 0.70;
      }
      
      if (Math.random() < goalChance) {
        if (isHome) { scoreHome++; shotsOnTargetHome++; } 
        else { scoreAway++; shotsOnTargetAway++; }

        playerGoalCount[attacker.id] = (playerGoalCount[attacker.id] || 0) + 1;

        // Choose assist player weighted by Playmakers & Wingers
        const assistCandidates = activeOnField.filter(p => p.id !== attacker.id);
        const assistPlayer = [...assistCandidates].sort((a, b) => {
          const aRole = (activeTactics.playerRoles?.[a.id] || '').toUpperCase();
          const bRole = (activeTactics.playerRoles?.[b.id] || '').toUpperCase();
          const aWeight = (aRole.includes('OFANSİF') || aRole.includes('DERİN') ? 25 : 0) + (a.attributes?.passing || a.overall);
          const bWeight = (bRole.includes('OFANSİF') || bRole.includes('DERİN') ? 25 : 0) + (b.attributes?.passing || b.overall);
          return (bWeight + Math.random() * 20) - (aWeight + Math.random() * 20);
        })[0] || assistCandidates[0];

        if (assistPlayer) {
          playerAssistCount[assistPlayer.id] = (playerAssistCount[assistPlayer.id] || 0) + 1;
        }

        const assistText = assistPlayer ? ` (Asist: ${assistPlayer.name})` : '';

        const goalMsg = wantsLongShots && Math.random() < 0.5
          ? `MÜTHİŞ UZAKTAN GOL! ⚽💥 ${attacker.name} 30 metreden füzeyi çıkardı! Top tam 90'a çakıldı!`
          : `GOOOOOLLLL! ⚽ ${attacker.name} ceza sahası içinden mükemmel vurdu ve ağları havalandırdı!`;

        events.push({
          id: `ev-${minute}-${Math.random()}`,
          minute,
          type: 'GOAL',
          text: `${goalMsg}${assistText}`,
          teamId: activeTeam.id,
          playerName: attacker.name,
          playerId: attacker.id,
          scorerId: attacker.id,
          assistantName: assistPlayer?.name,
          assistantId: assistPlayer?.id,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway
        });
      } else if (Math.random() < 0.55) { // SAVE
        if (isHome) shotsOnTargetHome++; else shotsOnTargetAway++;
        const saveMsg = wantsLongShots
          ? `${attacker.name} uzaktan şansını deniyor... Sert şutunu kaleci ${gk.name} refleksle kornere çeldi! 🧤`
          : `${attacker.name} kaleciyle karşı karşıya kaldı! Kaleci ${gk.name} köşeden harika bir kurtarış yaptı! 🧤`;

        events.push({
          id: `ev-${minute}-${Math.random()}`,
          minute,
          type: 'SAVE',
          text: saveMsg,
          teamId: activeTeam.id,
          playerName: attacker.name,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway
        });
      } else { // MISS / POST
        const isPostHit = Math.random() < 0.25;
        const missMsg = isPostHit
          ? `DİREKTEN DÖNDÜ! 💥 ${attacker.name} sert vurdu, top kale direğinde patladı!`
          : wantsLongShots
          ? `${attacker.name} çok uzaklardan şansını deniyor... Şut farkla üstten dışarıya çıktı.`
          : `${attacker.name} ceza sahası çaprazından vurdu, top az farkla dışarıya gitti.`;

        events.push({
          id: `ev-${minute}-${Math.random()}`,
          minute,
          type: 'MISS',
          text: missMsg,
          teamId: activeTeam.id,
          playerName: attacker.name,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway
        });
      }
    } else if (randomVal < 0.50) { // CORNER / ATTACK
      if (Math.random() < 0.5) {
        if (isHome) cornersHome++; else cornersAway++;
        const cornerTaker = activeOnField.find(p => p.id === activeTactics.cornerTakerId) || 
                            activeOnField.find(p => p.position === 'MID') || 
                            attacker;
        events.push({
          id: `ev-${minute}-${Math.random()}`,
          minute,
          type: 'CORNER',
          text: `KORNER! 🚩 ${activeTeam.name}, ${cornerTaker.name} ile köşe vuruşu kullanıyor. Defans kafa ile uzaklaştırdı.`,
          teamId: activeTeam.id,
          playerName: cornerTaker.name,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway
        });
      } else {
        events.push({
          id: `ev-${minute}-${Math.random()}`,
          minute,
          type: 'ATTACK',
          text: `${activeTeam.name}, ${attacker.name} ile kanattan hızlı hücuma kalkıyor...`,
          teamId: activeTeam.id,
          playerName: attacker.name,
          defenderName: defender.name,
          gkName: gk.name,
          isHomeTeamEvent: isHome,
          scoreHome,
          scoreAway
        });
      }
    } else if (randomVal < 0.72) { // FOUL / CARDS
      const isAggressiveTackling = (opponentTeam.tacticalDetails?.tackling === 'Sert (Agresif)');
      const yellowThreshold = isAggressiveTackling ? 0.32 : 0.15;
      const directRedThreshold = isAggressiveTackling ? 0.012 : 0.003;

      const activeFoulDefender = defender || opponentOnField[0];

      if (activeFoulDefender) {
        // Check for 2nd yellow -> Red, Direct Red card, or Yellow card
        const currentYellows = playerYellowCards[activeFoulDefender.id] || 0;

        if (currentYellows >= 1 && Math.random() < 0.15) { // 2ND YELLOW -> RED (realistic rare)
          if (isHome) { yellowAway++; redAway++; } else { yellowHome++; redHome++; }
          playerYellowCards[activeFoulDefender.id] = 2;

          // Remove player from active onfield list so they are sent off the pitch
          if (isHome) {
            awayOnField = awayOnField.filter(p => p.id !== activeFoulDefender.id);
          } else {
            homeOnField = homeOnField.filter(p => p.id !== activeFoulDefender.id);
          }

          events.push({
            id: `ev-red-2y-${minute}-${Math.random()}`,
            minute,
            type: 'RED_CARD',
            text: `2. SARI KART VE KIRMIZI KART! 🟥 ${activeFoulDefender.name} ikinci sarı karttan oyun dışı kaldı! ${opponentTeam.name} 10 kişi!`,
            teamId: opponentTeam.id,
            playerName: activeFoulDefender.name,
            playerId: activeFoulDefender.id,
            defenderName: activeFoulDefender.name,
            gkName: gk.name,
            isHomeTeamEvent: !isHome,
            scoreHome,
            scoreAway
          });
        } else if (Math.random() < directRedThreshold) { // DIRECT RED CARD (very rare)
          if (isHome) redAway++; else redHome++;

          // Remove player from active onfield list so they are sent off the pitch
          if (isHome) {
            awayOnField = awayOnField.filter(p => p.id !== activeFoulDefender.id);
          } else {
            homeOnField = homeOnField.filter(p => p.id !== activeFoulDefender.id);
          }

          events.push({
            id: `ev-red-direct-${minute}-${Math.random()}`,
            minute,
            type: 'RED_CARD',
            text: `DİREKT KIRMIZI KART! 🟥 Hakem, ${activeFoulDefender.name} tarafından yapılan sert müdahaleye tereddütsüz kırmızıyı çıkardı! ${opponentTeam.name} 10 kişi kaldı!`,
            teamId: opponentTeam.id,
            playerName: activeFoulDefender.name,
            playerId: activeFoulDefender.id,
            defenderName: activeFoulDefender.name,
            gkName: gk.name,
            isHomeTeamEvent: !isHome,
            scoreHome,
            scoreAway
          });
        } else if (Math.random() < yellowThreshold) { // YELLOW CARD
          if (isHome) yellowAway++; else yellowHome++;
          playerYellowCards[activeFoulDefender.id] = (playerYellowCards[activeFoulDefender.id] || 0) + 1;

          events.push({
            id: `ev-yellow-${minute}-${Math.random()}`,
            minute,
            type: 'YELLOW_CARD',
            text: `SARI KART! 🟨 Hakem, ${activeFoulDefender.name} tarafından yapılan faullü hareketi sarı kartla cezalandırdı.${isAggressiveTackling ? ' (Sert Müdahale)' : ''}`,
            teamId: opponentTeam.id,
            playerName: activeFoulDefender.name,
            playerId: activeFoulDefender.id,
            defenderName: activeFoulDefender.name,
            gkName: gk.name,
            isHomeTeamEvent: !isHome,
            scoreHome,
            scoreAway
          });
        }
      }
    }
  }

  // Generate AI Substitutions ONLY for non-user AI teams
  const isHomeUserTeam = userTeamId ? homeTeam.id === userTeamId : (homeTeam as any).isUserTeam;
  const isAwayUserTeam = userTeamId ? awayTeam.id === userTeamId : (awayTeam as any).isUserTeam;

  if (!isHomeUserTeam) {
    const subMinutesHome = [58, 70, 80];
    const homeBench = (homeTeam.players || []).filter(p => !p.isStarting && !p.isInjured);

    subMinutesHome.forEach(sMin => {
      if (homeBench.length > 0 && homeOnField.length > 0 && Math.random() < 0.65) {
        const outIdx = Math.floor(Math.random() * homeOnField.length);
        const outPlayer = homeOnField[outIdx];
        const inPlayer = homeBench.pop();

        if (outPlayer && inPlayer) {
          homeOnField.splice(outIdx, 1, inPlayer); // Update active pitch line-up
          events.push({
            id: `ev-sub-home-${sMin}-${Math.random()}`,
            minute: sMin,
            type: 'SUBSTITUTION',
            text: `🔄 OYUNCU DEĞİŞİKLİĞİ (${homeTeam.name}): ${sMin}. dakikada ${outPlayer.name} kenara geldi ➔ ${inPlayer.name} oyuna girdi!`,
            teamId: homeTeam.id,
            playerName: inPlayer.name, // Strictly new in-player name so attack engine doesn't show "Out -> In"
            isHomeTeamEvent: true,
            scoreHome,
            scoreAway
          });
        }
      }
    });
  }

  if (!isAwayUserTeam) {
    const subMinutesAway = [58, 68, 78];
    const awayBench = (awayTeam.players || []).filter(p => !p.isStarting && !p.isInjured);

    subMinutesAway.forEach(sMin => {
      if (awayBench.length > 0 && awayOnField.length > 0 && Math.random() < 0.75) {
        const outIdx = Math.floor(Math.random() * awayOnField.length);
        const outPlayer = awayOnField[outIdx];
        const inPlayer = awayBench.pop();

        if (outPlayer && inPlayer) {
          awayOnField.splice(outIdx, 1, inPlayer); // Update active pitch line-up
          events.push({
            id: `ev-sub-away-${sMin}-${Math.random()}`,
            minute: sMin,
            type: 'SUBSTITUTION',
            text: `🔄 OYUNCU DEĞİŞİKLİĞİ (${awayTeam.name}): ${sMin}. dakikada ${outPlayer.name} kenara geldi ➔ ${inPlayer.name} oyuna girdi!`,
            teamId: awayTeam.id,
            playerName: inPlayer.name, // Strictly new in-player name
            isHomeTeamEvent: false,
            scoreHome,
            scoreAway
          });
        }
      }
    });
  }

  // Sort events chronologically by minute
  events.sort((a, b) => a.minute - b.minute);

  // Full Time Event
  events.push({
    id: `ev-90`,
    minute: 90,
    type: 'FULL_TIME',
    text: `MAÇ BİTTİ! 🏁 Karşılaşma sonucu: ${homeTeam.name} ${scoreHome} - ${scoreAway} ${awayTeam.name}`,
    teamId: homeTeam.id,
    isHomeTeamEvent: true,
    scoreHome,
    scoreAway
  });

  const basePos = Math.round(homeProb * 100);
  const possessionHome = Math.max(35, Math.min(68, basePos + Math.floor(Math.random() * 7 - 3)));
  const possessionAway = 100 - possessionHome;

  const stats: MatchStats = {
    possessionHome,
    possessionAway,
    shotsHome: Math.max(shotsHome, scoreHome + 2),
    shotsAway: Math.max(shotsAway, scoreAway + 1),
    shotsOnTargetHome: Math.max(shotsOnTargetHome, scoreHome),
    shotsOnTargetAway: Math.max(shotsOnTargetAway, scoreAway),
    cornersHome: Math.max(cornersHome, 1),
    cornersAway: Math.max(cornersAway, 1),
    foulsHome,
    foulsAway,
    yellowHome,
    yellowAway,
    redHome,
    redAway
  };

  // Generate Ratings for all starters
  const playerRatings: PlayerRating[] = [];

  const allStarters = [
    ...homeStarters.map((p, idx) => ({ player: p, teamId: homeTeam.id, teamScore: scoreHome, oppScore: scoreAway, idx, formation: homeTeam.formation })),
    ...awayStarters.map((p, idx) => ({ player: p, teamId: awayTeam.id, teamScore: scoreAway, oppScore: scoreHome, idx, formation: awayTeam.formation }))
  ];

  allStarters.forEach(({ player, teamId, teamScore, oppScore, idx, formation }) => {
    const goals = playerGoalCount[player.id] || 0;
    const assists = playerAssistCount[player.id] || 0;

    const eff = calculatePlayerEffectiveOverall(player, idx, formation);

    // Natural varied baseline rating
    const seed = ((player.id.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0) + idx * 11) % 13);
    const variance = (seed - 6) * 0.08;
    let baseRating = 6.6 + (eff.effectiveOverall - 75) * 0.045 + variance;

    const scoreDiff = teamScore - oppScore;
    if (scoreDiff > 0) baseRating += Math.min(1.2, scoreDiff * 0.35);
    if (scoreDiff < 0) baseRating -= Math.min(1.4, Math.abs(scoreDiff) * 0.35);

    // Performance points
    baseRating += goals * 1.6;
    baseRating += assists * 0.95;

    // Defense & Goalkeeper conceded goals penalty
    if (oppScore > 0) {
      if (player.position === 'GK') {
        baseRating -= oppScore * 0.5;
      } else if (player.position === 'DEF' || eff.assignedSlot === 'DEF') {
        baseRating -= oppScore * 0.38;
      } else {
        baseRating -= oppScore * 0.12;
      }
    } else if (player.position === 'GK') {
      baseRating += 1.2; // Clean sheet boost for goalkeeper
    } else if (player.position === 'DEF' || eff.assignedSlot === 'DEF') {
      baseRating += 0.8; // Clean sheet boost for defense
    }

    // Check if player had yellow or red card or caused a penalty in events
    const playerHadRed = events.some(e => e.type === 'RED_CARD' && (e.scorerId === player.id || (e.playerName && e.playerName.includes(player.name))));
    const playerHadYellow = events.some(e => e.type === 'YELLOW_CARD' && (e.scorerId === player.id || (e.playerName && e.playerName.includes(player.name))));
    if (playerHadRed) baseRating -= 2.6;
    if (playerHadYellow) baseRating -= 0.35;

    if (eff.isOutOfPosition) {
      if (player.position === 'GK' || eff.assignedSlot === 'GK') {
        baseRating -= 2.6;
      } else {
        baseRating -= 1.4;
      }
    }

    const finalRating = Math.min(10.0, Math.max(3.0, Math.round(baseRating * 10) / 10));

    playerRatings.push({
      playerId: player.id,
      playerName: player.name,
      position: eff.assignedSlot || player.specificRole || player.position,
      teamId,
      rating: finalRating,
      goals,
      assists
    });
  });

  // Highlight MOTM and Worst
  if (playerRatings.length > 0) {
    let best = playerRatings[0];
    let worst = playerRatings[0];

    playerRatings.forEach(pr => {
      // Prioritize player with goals/assists or highest rating for MOTM
      const prScore = pr.rating + (pr.goals * 0.3) + (pr.assists * 0.15);
      const bestScore = best.rating + (best.goals * 0.3) + (best.assists * 0.15);
      if (prScore > bestScore) best = pr;
      if (pr.rating < worst.rating) worst = pr;
    });

    best.isMotm = true;
    worst.isWorst = true;
  }

  return {
    events,
    stats,
    finalHomeScore: scoreHome,
    finalAwayScore: scoreAway,
    injuredPlayers,
    playerRatings
  };
}

export function simulateQuickMatch(
  homeTeam: Team,
  awayTeam: Team,
  difficulty?: string,
  userTeamId?: string
): { 
  homeScore: number; 
  awayScore: number;
  playerStats: { playerId: string; goals: number; assists: number; rating: number }[];
} {
  let homeAvg = calculateStartingXIOverall(homeTeam) + 2 + getPowerhouseHiddenBoost(homeTeam.name);
  let awayAvg = calculateStartingXIOverall(awayTeam) + getPowerhouseHiddenBoost(awayTeam.name);

  if (difficulty === 'ZOR' && userTeamId) {
    if (homeTeam.id === userTeamId) awayAvg += 8;
    else if (awayTeam.id === userTeamId) homeAvg += 8;
  } else if (difficulty === 'KOLAY' && userTeamId) {
    if (homeTeam.id === userTeamId) homeAvg += 6;
    else if (awayTeam.id === userTeamId) awayAvg += 6;
  }

  const diff = homeAvg - awayAvg;
  let homeScore = 0;
  let awayScore = 0;

  let homeExpected = Math.max(0.3, 1.5 + diff * 0.08);
  let awayExpected = Math.max(0.3, 1.2 - diff * 0.08);

  if (difficulty === 'ZOR' && userTeamId) {
    if (homeTeam.id === userTeamId) homeExpected *= 0.7;
    if (awayTeam.id === userTeamId) homeExpected *= 0.7;
  }

  for (let i = 0; i < 4; i++) {
    if (Math.random() < homeExpected / 3.5) homeScore++;
    if (Math.random() < awayExpected / 3.5) awayScore++;
  }

  // Assign goals and assists to starters
  const playerStatsMap: Record<string, { playerId: string; goals: number; assists: number; rating: number }> = {};

  const homeStarters = homeTeam.players.filter(p => p.isStarting) || homeTeam.players.slice(0, 11);
  const awayStarters = awayTeam.players.filter(p => p.isStarting) || awayTeam.players.slice(0, 11);

  // Home Goals
  for (let g = 0; g < homeScore; g++) {
    const attackers = homeStarters.filter(p => p.position === 'FW' || p.position === 'MID');
    const scorer = attackers.length > 0 ? attackers[Math.floor(Math.random() * attackers.length)] : homeStarters[0];
    if (scorer) {
      if (!playerStatsMap[scorer.id]) playerStatsMap[scorer.id] = { playerId: scorer.id, goals: 0, assists: 0, rating: 7.0 };
      playerStatsMap[scorer.id].goals += 1;

      const assistCandidates = homeStarters.filter(p => p.id !== scorer.id);
      const assistPlayer = assistCandidates[Math.floor(Math.random() * assistCandidates.length)];
      if (assistPlayer) {
        if (!playerStatsMap[assistPlayer.id]) playerStatsMap[assistPlayer.id] = { playerId: assistPlayer.id, goals: 0, assists: 0, rating: 7.0 };
        playerStatsMap[assistPlayer.id].assists += 1;
      }
    }
  }

  // Away Goals
  for (let g = 0; g < awayScore; g++) {
    const attackers = awayStarters.filter(p => p.position === 'FW' || p.position === 'MID');
    const scorer = attackers.length > 0 ? attackers[Math.floor(Math.random() * attackers.length)] : awayStarters[0];
    if (scorer) {
      if (!playerStatsMap[scorer.id]) playerStatsMap[scorer.id] = { playerId: scorer.id, goals: 0, assists: 0, rating: 7.0 };
      playerStatsMap[scorer.id].goals += 1;

      const assistCandidates = awayStarters.filter(p => p.id !== scorer.id);
      const assistPlayer = assistCandidates[Math.floor(Math.random() * assistCandidates.length)];
      if (assistPlayer) {
        if (!playerStatsMap[assistPlayer.id]) playerStatsMap[assistPlayer.id] = { playerId: assistPlayer.id, goals: 0, assists: 0, rating: 7.0 };
        playerStatsMap[assistPlayer.id].assists += 1;
      }
    }
  }

  // Generate ratings for starters
  homeStarters.forEach((p, idx) => {
    const eff = calculatePlayerEffectiveOverall(p, idx, homeTeam.formation);
    const penalty = eff.isOutOfPosition ? (p.position === 'GK' || eff.assignedSlot === 'GK' ? 2.5 : 1.2) : 0;
    if (!playerStatsMap[p.id]) {
      const isWinner = homeScore > awayScore;
      const baseRating = 6.4 + (eff.effectiveOverall - 75) * 0.045 + (isWinner ? 0.5 : -0.35) + (Math.random() * 0.6 - 0.3) - penalty;
      playerStatsMap[p.id] = { playerId: p.id, goals: 0, assists: 0, rating: Math.min(9.5, Math.max(3.2, Math.round(baseRating * 10) / 10)) };
    } else {
      const st = playerStatsMap[p.id];
      const baseRating = 6.6 + st.goals * 1.6 + st.assists * 0.95 + (Math.random() * 0.5) - penalty;
      st.rating = Math.min(10.0, Math.max(3.0, Math.round(baseRating * 10) / 10));
    }
  });

  awayStarters.forEach((p, idx) => {
    const eff = calculatePlayerEffectiveOverall(p, idx, awayTeam.formation);
    const penalty = eff.isOutOfPosition ? (p.position === 'GK' || eff.assignedSlot === 'GK' ? 2.5 : 1.2) : 0;
    if (!playerStatsMap[p.id]) {
      const isWinner = awayScore > homeScore;
      const baseRating = 6.4 + (eff.effectiveOverall - 75) * 0.045 + (isWinner ? 0.5 : -0.35) + (Math.random() * 0.6 - 0.3) - penalty;
      playerStatsMap[p.id] = { playerId: p.id, goals: 0, assists: 0, rating: Math.min(9.5, Math.max(3.2, Math.round(baseRating * 10) / 10)) };
    } else {
      const st = playerStatsMap[p.id];
      const baseRating = 6.6 + st.goals * 1.6 + st.assists * 0.95 + (Math.random() * 0.5) - penalty;
      st.rating = Math.min(10.0, Math.max(3.0, Math.round(baseRating * 10) / 10));
    }
  });

  return { 
    homeScore, 
    awayScore,
    playerStats: Object.values(playerStatsMap)
  };
}
