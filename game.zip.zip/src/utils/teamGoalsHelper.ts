import { Team } from '../types';

export interface TeamGoalInfo {
  targetPosition: number;
  seasonGoalText: string;
}

/**
 * Returns specific target position and season goal text for any team.
 * Galatasaray, Fenerbahçe, Beşiktaş -> 1.lik (Şampiyonluk)
 * Trabzonspor, Başakşehir -> İlk 3 (Şampiyonlar Ligi)
 * Mid-table teams -> İlk 8
 * Relegation candidates -> Kümede Kalma (14.lük)
 */
export function getTeamTargetGoal(team: { id?: string; name?: string; overall?: number; budget?: number }): TeamGoalInfo {
  const nameLower = (team.name || '').toLowerCase();
  const idLower = (team.id || '').toLowerCase();

  // 1. Title Contenders (1st Place / Şampiyonluk)
  if (
    idLower.includes('galatasaray') || nameLower.includes('galatasaray') ||
    idLower.includes('fenerbahce') || nameLower.includes('fenerbahçe') ||
    idLower.includes('besiktas') || nameLower.includes('beşiktaş') ||
    idLower.includes('real-madrid') || idLower.includes('manchester-city') ||
    idLower.includes('barcelona') || idLower.includes('bayern') ||
    idLower.includes('psg') || idLower.includes('inter') ||
    idLower.includes('liverpool') || idLower.includes('arsenal')
  ) {
    return { targetPosition: 1, seasonGoalText: 'Şampiyonluk (1.lik)' };
  }

  // 2. Champions League / Top 3 (2. - 3.lük)
  if (
    idLower.includes('trabzonspor') || nameLower.includes('trabzonspor') ||
    idLower.includes('basaksehir') || nameLower.includes('başakşehir') ||
    idLower.includes('atletico') || idLower.includes('chelsea') ||
    idLower.includes('manchester-united') || idLower.includes('tottenham') ||
    idLower.includes('dortmund') || idLower.includes('juventus') ||
    idLower.includes('milan')
  ) {
    return { targetPosition: 3, seasonGoalText: 'Şampiyonlar Ligi / İlk 3' };
  }

  // 3. Upper Mid-Table (İlk 8'de Bitirme)
  if (
    (team.overall && team.overall >= 74) ||
    idLower.includes('samsun') || idLower.includes('adana') ||
    idLower.includes('antalya') || idLower.includes('sivas') ||
    idLower.includes('kasimpasa') || idLower.includes('rize') ||
    idLower.includes('goztepe') || idLower.includes('eyup') ||
    idLower.includes('kocaelispor') || idLower.includes('genclerbirligi')
  ) {
    return { targetPosition: 8, seasonGoalText: 'İlk 8\'de Bitirme' };
  }

  // 4. Relegation Safety (Kümede Kalma)
  return { targetPosition: 14, seasonGoalText: 'Kümede Kalma (Ligde Tutunma)' };
}

/**
 * Calculates dynamic Board Confidence (0 - 99%)
 * Highly reactive to match wins, draws, losses, ranking and club tier expectations.
 * Elite clubs targeting 1st place face extreme pressure and heavy penalties for dropped points.
 */
export function calculateBoardConfidence(
  currentRank: number,
  totalTeams: number,
  matchesPlayed: number,
  team: { id?: string; name?: string; overall?: number; budget?: number },
  won: number = 0,
  drawn: number = 0,
  lost: number = 0,
  form?: string[]
): number {
  const goal = getTeamTargetGoal(team);
  const targetPos = goal.targetPosition;

  // If no matches played yet, board provides high baseline honeymoon confidence
  if (matchesPlayed === 0) {
    return targetPos === 1 ? 92 : targetPos === 3 ? 90 : 88;
  }

  let confidence = 88;

  // 1. Target Tier Specific Weighting
  if (targetPos === 1) {
    // ELITE CLUBS (Target: 1st Place / Championship)
    // Demands near perfection. Every loss or draw hits confidence hard.
    confidence = 90;
    confidence += won * 2.0;
    confidence -= drawn * 3.0;
    confidence -= lost * 7.5;

    // Rank Discrepancy Penalty
    if (currentRank > 1) {
      const rankDeficit = currentRank - 1;
      confidence -= rankDeficit * 6.5;
      if (currentRank >= 4) {
        confidence -= 10; // Crisis penalty for top club falling out of top 3
      }
    } else {
      confidence += 5; // Leaders bonus
    }

    // Recent Form Check
    if (form && form.length >= 2) {
      const recentLosses = form.slice(-3).filter(r => r === 'L').length;
      if (recentLosses >= 2) {
        confidence -= 8; // Crisis for back-to-back slip-ups
      }
    }
  } else if (targetPos === 3) {
    // EUROPEAN / TOP 3 CONTENDERS
    confidence = 88;
    confidence += won * 2.5;
    confidence -= drawn * 1.0;
    confidence -= lost * 5.0;

    if (currentRank > 3) {
      confidence -= (currentRank - 3) * 4.0;
    } else {
      confidence += 4;
    }
  } else if (targetPos === 8) {
    // MID-TABLE TEAMS (Target: Top 8)
    confidence = 85;
    confidence += won * 3.5;
    confidence += drawn * 1.0;
    confidence -= lost * 2.5;

    if (currentRank > 8) {
      confidence -= (currentRank - 8) * 2.5;
    } else {
      confidence += 3;
    }
  } else {
    // RELEGATION BATTLE (Target: 14th / Survival)
    confidence = 82;
    confidence += won * 5.0; // Big praise for surprise wins
    confidence += drawn * 1.5;
    confidence -= lost * 2.0;

    if (currentRank >= 16) {
      confidence -= (currentRank - 15) * 6.0; // Relegation zone panic!
    } else if (currentRank <= 12) {
      confidence += 6; // Comfortable mid-table safety
    }
  }

  // Clamp within realistic range [25, 99]
  return Math.min(99, Math.max(25, Math.round(confidence)));
}

