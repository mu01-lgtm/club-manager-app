// Helper for generating realistic football calendar dates for Super Lig & World Leagues

export const DAYS_BY_LANG: Record<string, string[]> = {
  TR: ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'],
  EN: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
  DE: ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag'],
  ES: ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'],
  FR: ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'],
  IT: ['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica'],
  PT: ['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado', 'Domingo']
};

export const MONTHS_BY_LANG: Record<string, string[]> = {
  TR: ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'],
  EN: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
  DE: ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'],
  ES: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
  FR: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'],
  IT: ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'],
  PT: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']
};

export interface RealSimDate {
  dateStr: string;       // e.g. "8 August 2025"
  dayName: string;       // e.g. "Friday"
  fullDisplay: string;   // e.g. "Friday, 8 August 2025"
  year: number;
  monthIndex: number;
  dayOfMonth: number;
  isTransferWindowOpen: boolean;
  transferWindowDeadlineDays?: number;
}

export interface LeagueScheduleConfig {
  leagueId: string;
  leagueName: string;
  startMonth: number; // 0-indexed: 7 is August
  startDay: number;   // e.g. 15 for 15 August
  startYear: number;
  matchDistribution: {
    dayOffset: number; // 0 = Friday, 1 = Saturday, 2 = Sunday, 3 = Monday, etc.
    time: string;
    dayIndex: number;  // 0-6 (0 = Monday, 4 = Friday, 5 = Saturday, 6 = Sunday)
  }[];
}

export const LEAGUE_SCHEDULE_CONFIGS: Record<string, LeagueScheduleConfig> = {
  // La Liga: Starts 15 August 2025 (Friday 1 match, Saturday 4 matches, Sunday 4 matches, Monday 1 match)
  LALIGA: {
    leagueId: 'LALIGA',
    leagueName: 'La Liga EA Sports',
    startMonth: 7, // August
    startDay: 15,
    startYear: 2025,
    matchDistribution: [
      { dayOffset: 0, time: '22:00', dayIndex: 4 }, // Friday
      { dayOffset: 1, time: '18:00', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '20:00', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '20:30', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '22:30', dayIndex: 5 }, // Saturday
      { dayOffset: 2, time: '18:00', dayIndex: 6 }, // Sunday
      { dayOffset: 2, time: '20:00', dayIndex: 6 }, // Sunday
      { dayOffset: 2, time: '20:00', dayIndex: 6 }, // Sunday
      { dayOffset: 2, time: '22:30', dayIndex: 6 }, // Sunday
      { dayOffset: 3, time: '22:00', dayIndex: 0 }, // Monday
    ]
  },
  // Premier League: Starts 15 August 2025 (Friday 1 match, Saturday 6 matches, Sunday 3 matches)
  PREMIER_LEAGUE: {
    leagueId: 'PREMIER_LEAGUE',
    leagueName: 'Premier League',
    startMonth: 7, // August
    startDay: 15,
    startYear: 2025,
    matchDistribution: [
      { dayOffset: 0, time: '22:00', dayIndex: 4 }, // Friday
      { dayOffset: 1, time: '14:30', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '17:00', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '17:00', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '17:00', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '17:00', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '19:30', dayIndex: 5 }, // Saturday
      { dayOffset: 2, time: '16:00', dayIndex: 6 }, // Sunday
      { dayOffset: 2, time: '16:00', dayIndex: 6 }, // Sunday
      { dayOffset: 2, time: '18:30', dayIndex: 6 }, // Sunday
    ]
  },
  // Ligue 1: Starts 21 August 2025 (Friday 1 match, Saturday 4 matches, Sunday 4 matches)
  LIGUE_1: {
    leagueId: 'LIGUE_1',
    leagueName: 'Ligue 1 McDonald\'s',
    startMonth: 7, // August
    startDay: 21,
    startYear: 2025,
    matchDistribution: [
      { dayOffset: 0, time: '21:45', dayIndex: 4 }, // Friday 1 match
      { dayOffset: 1, time: '18:00', dayIndex: 5 }, // Saturday match 1
      { dayOffset: 1, time: '20:00', dayIndex: 5 }, // Saturday match 2
      { dayOffset: 1, time: '20:00', dayIndex: 5 }, // Saturday match 3
      { dayOffset: 1, time: '22:05', dayIndex: 5 }, // Saturday match 4
      { dayOffset: 2, time: '16:00', dayIndex: 6 }, // Sunday match 1
      { dayOffset: 2, time: '18:00', dayIndex: 6 }, // Sunday match 2
      { dayOffset: 2, time: '18:00', dayIndex: 6 }, // Sunday match 3
      { dayOffset: 2, time: '21:45', dayIndex: 6 }, // Sunday match 4
    ]
  },
  // Serie A: Starts 16 August 2025 (Saturday 4 matches, Sunday 4 matches, Monday 2 matches)
  SERIE_A: {
    leagueId: 'SERIE_A',
    leagueName: 'Serie A Enilive',
    startMonth: 7, // August
    startDay: 16,
    startYear: 2025,
    matchDistribution: [
      { dayOffset: 0, time: '19:30', dayIndex: 5 }, // Saturday
      { dayOffset: 0, time: '19:30', dayIndex: 5 }, // Saturday
      { dayOffset: 0, time: '21:45', dayIndex: 5 }, // Saturday
      { dayOffset: 0, time: '21:45', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '19:30', dayIndex: 6 }, // Sunday
      { dayOffset: 1, time: '19:30', dayIndex: 6 }, // Sunday
      { dayOffset: 1, time: '21:45', dayIndex: 6 }, // Sunday
      { dayOffset: 1, time: '21:45', dayIndex: 6 }, // Sunday
      { dayOffset: 2, time: '19:30', dayIndex: 0 }, // Monday
      { dayOffset: 2, time: '21:45', dayIndex: 0 }, // Monday
    ]
  },
  // Bundesliga: Starts 22 August 2025 (Friday 1 match opener, Saturday 6 matches, Sunday 2 matches)
  BUNDESLIGA: {
    leagueId: 'BUNDESLIGA',
    leagueName: 'Bundesliga',
    startMonth: 7, // August
    startDay: 22,
    startYear: 2025,
    matchDistribution: [
      { dayOffset: 0, time: '21:30', dayIndex: 4 }, // Friday 1 match
      { dayOffset: 1, time: '16:30', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '16:30', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '16:30', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '16:30', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '16:30', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '19:30', dayIndex: 5 }, // Saturday
      { dayOffset: 2, time: '16:30', dayIndex: 6 }, // Sunday
      { dayOffset: 2, time: '18:30', dayIndex: 6 }, // Sunday
    ]
  },
  // Süper Lig: Starts 8 August 2025 (Friday 1 match, Saturday 4 matches, Sunday 4 matches)
  SUPER_LIG: {
    leagueId: 'SUPER_LIG',
    leagueName: 'Trendyol Süper Lig',
    startMonth: 7, // August
    startDay: 8,
    startYear: 2025,
    matchDistribution: [
      { dayOffset: 0, time: '21:00', dayIndex: 4 }, // Friday
      { dayOffset: 1, time: '19:00', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '19:00', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '21:45', dayIndex: 5 }, // Saturday
      { dayOffset: 1, time: '21:45', dayIndex: 5 }, // Saturday
      { dayOffset: 2, time: '19:00', dayIndex: 6 }, // Sunday
      { dayOffset: 2, time: '19:00', dayIndex: 6 }, // Sunday
      { dayOffset: 2, time: '21:45', dayIndex: 6 }, // Sunday
      { dayOffset: 2, time: '21:45', dayIndex: 6 }, // Sunday
      { dayOffset: 3, time: '21:00', dayIndex: 0 }, // Monday
    ]
  }
};

/**
 * Detect league configuration based on team ID or league identifier
 */
export function getLeagueConfigForTeam(teamId: string = ''): LeagueScheduleConfig {
  const t = teamId.toLowerCase();
  if (
    t.includes('arsenal') || t.includes('city') || t.includes('liverpool') ||
    t.includes('chelsea') || t.includes('united') || t.includes('tottenham') ||
    t.includes('aston') || t.includes('newcastle') || t.includes('brighton') ||
    t.includes('west-ham') || t.includes('wolves') || t.includes('everton') ||
    t.includes('crystal') || t.includes('brentford') || t.includes('fulham') ||
    t.includes('bournemouth') || t.includes('nottingham') || t.includes('leicester') ||
    t.includes('ipswich') || t.includes('southampton')
  ) {
    return LEAGUE_SCHEDULE_CONFIGS.PREMIER_LEAGUE;
  }
  if (
    t.includes('real-madrid') || t.includes('barcelona') || t.includes('atletico') ||
    t.includes('sociedad') || t.includes('bilbao') || t.includes('sevilla') ||
    t.includes('valencia') || t.includes('betis') || t.includes('villarreal') ||
    t.includes('girona') || t.includes('celta') || t.includes('mallorca') ||
    t.includes('osasuna') || t.includes('getafe') || t.includes('alaves') ||
    t.includes('rayo') || t.includes('las-palmas') || t.includes('leganes') ||
    t.includes('valladolid') || t.includes('espanyol')
  ) {
    return LEAGUE_SCHEDULE_CONFIGS.LALIGA;
  }
  if (
    t.includes('bayern') || t.includes('dortmund') || t.includes('leverkusen') ||
    t.includes('leipzig') || t.includes('stuttgart') || t.includes('frankfurt') ||
    t.includes('wolfsburg') || t.includes('monchengladbach') || t.includes('freiburg') ||
    t.includes('hoffenheim') || t.includes('augsburg') || t.includes('bremen') ||
    t.includes('mainz') || t.includes('bochum') || t.includes('heidenheim') ||
    t.includes('st-pauli') || t.includes('holstein') || t.includes('union-berlin')
  ) {
    return LEAGUE_SCHEDULE_CONFIGS.BUNDESLIGA;
  }
  if (
    t.includes('inter') || t.includes('milan') || t.includes('juventus') ||
    t.includes('napoli') || t.includes('roma') || t.includes('lazio') ||
    t.includes('atalanta') || t.includes('fiorentina') || t.includes('bologna') ||
    t.includes('torino') || t.includes('genoa') || t.includes('monza') ||
    t.includes('verona') || t.includes('udinese') || t.includes('parma') ||
    t.includes('cagliari') || t.includes('empoli') || t.includes('lecce') ||
    t.includes('como') || t.includes('venezia')
  ) {
    return LEAGUE_SCHEDULE_CONFIGS.SERIE_A;
  }
  if (
    t.includes('psg') || t.includes('paris') || t.includes('marseille') ||
    t.includes('monaco') || t.includes('lyon') || t.includes('lille') ||
    t.includes('rennes') || t.includes('nice') || t.includes('lens') ||
    t.includes('toulouse') || t.includes('strasbourg') || t.includes('nantes') ||
    t.includes('reims') || t.includes('montpellier') || t.includes('brest') ||
    t.includes('auxerre') || t.includes('angers') || t.includes('saint-etienne') ||
    t.includes('le-havre')
  ) {
    return LEAGUE_SCHEDULE_CONFIGS.LIGUE_1;
  }
  return LEAGUE_SCHEDULE_CONFIGS.SUPER_LIG;
}

/**
 * Calculates realistic calendar dates based on season, week (1-38), day index (0-6), and language code.
 * Optionally factors in league specific start dates.
 */
export function getSimulatedRealDate(
  season: number,
  week: number,
  dayIndex: number = 0,
  langCode: string = 'TR',
  leagueOrTeamId?: string
): RealSimDate {
  const lang = (langCode && DAYS_BY_LANG[langCode]) ? langCode : 'TR';
  const daysList = DAYS_BY_LANG[lang] || DAYS_BY_LANG.TR;
  const monthsList = MONTHS_BY_LANG[lang] || MONTHS_BY_LANG.TR;

  const leagueConfig = leagueOrTeamId ? getLeagueConfigForTeam(leagueOrTeamId) : LEAGUE_SCHEDULE_CONFIGS.SUPER_LIG;

  const baseYear = (leagueConfig.startYear || 2025) + (season - 1);
  const startDate = new Date(baseYear, leagueConfig.startMonth, leagueConfig.startDay);

  // Calculate total days elapsed from Week 1 Day 0
  const totalDaysElapsed = ((week - 1) * 7) + dayIndex;
  
  const currentDate = new Date(startDate.getTime() + totalDaysElapsed * 24 * 60 * 60 * 1000);
  
  const dayOfMonth = currentDate.getDate();
  const monthIndex = currentDate.getMonth(); // 0-11
  const year = currentDate.getFullYear();
  const monthName = monthsList[monthIndex];

  // Map JS day (0=Sunday, 1=Monday...) to custom day index (0=Monday, 6=Sunday)
  const jsDay = currentDate.getDay();
  const customDayIndex = jsDay === 0 ? 6 : jsDay - 1;
  const dayName = daysList[customDayIndex];

  const dateStr = `${dayOfMonth} ${monthName} ${year}`;
  const fullDisplay = `${dayName}, ${dateStr}`;

  // Transfer Window Rules:
  // Summer Window: 15 June - 12 September
  // Winter Window: 12 January - 9 February
  let isTransferWindowOpen = false;
  let deadlineDays: number | undefined = undefined;

  if (
    (monthIndex === 5 && dayOfMonth >= 15) || // June 15+
    monthIndex === 6 ||                       // July
    monthIndex === 7 ||                       // August
    (monthIndex === 8 && dayOfMonth <= 12)    // Sept 1-12
  ) {
    isTransferWindowOpen = true;
    if (monthIndex === 8 && dayOfMonth <= 12) {
      deadlineDays = 12 - dayOfMonth;
    }
  } else if (
    (monthIndex === 0 && dayOfMonth >= 12) || // Jan 12+
    (monthIndex === 1 && dayOfMonth <= 9)     // Feb 1-9
  ) {
    isTransferWindowOpen = true;
    if (monthIndex === 1 && dayOfMonth <= 9) {
      deadlineDays = 9 - dayOfMonth;
    }
  }

  return {
    dateStr,
    dayName,
    fullDisplay,
    year,
    monthIndex,
    dayOfMonth,
    isTransferWindowOpen,
    transferWindowDeadlineDays: deadlineDays
  };
}

/**
 * Converts date strings containing month names (e.g. "10 Ağustos 2025") into the target language format.
 */
export function formatLocalizedDateString(dateStr: string, langCode: string = 'TR'): string {
  if (!dateStr) return '';
  const lang = (langCode && MONTHS_BY_LANG[langCode]) ? langCode : 'TR';
  const targetMonths = MONTHS_BY_LANG[lang] || MONTHS_BY_LANG.TR;

  let result = dateStr;
  
  // Look up any month name from all languages and replace with target language month name
  Object.keys(MONTHS_BY_LANG).forEach((srcLang) => {
    MONTHS_BY_LANG[srcLang].forEach((monthName, idx) => {
      if (monthName && result.includes(monthName)) {
        result = result.replace(new RegExp(monthName, 'g'), targetMonths[idx]);
      }
    });
  });

  return result;
}

