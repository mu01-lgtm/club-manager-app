import { Player, FormationType } from '../types';

export interface PlayerFootAndSkills {
  preferredFoot: 'Sağ' | 'Sol' | 'Her İkisi';
  weakFoot: number; // 1 - 5 stars
  skillMoves: number; // 1 - 5 stars
}

export type PositionFit = 'NATURAL' | 'COMPETENT' | 'UNCOMFORTABLE' | 'INCOMPATIBLE';

export interface PositionEvaluation {
  fit: PositionFit;
  effectiveOverall: number;
  penalty: number;
  isRedAlert: boolean; // Sadece gerçekten hiç oynayamadığı mevkilerde true
  assignedSlotRole: string; // e.g. 'KL', 'SS', 'SLB', 'SĞB', 'DOS', 'OS', 'OOS', 'SLK', 'SGK', 'SF'
  assignedSlotCategory: 'GK' | 'DEF' | 'MID' | 'FW';
  fitLabel: string;
}

// Known players database with authentic foot, weak foot and skill moves
const KNOWN_PLAYERS_FOOT_SKILLS: Record<string, PlayerFootAndSkills> = {
  // --- GALATASARAY ---
  'leroysane': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 4 },
  'mauroicardi': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 3 },
  'victorosimhen': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 3 },
  'barisalperyilmaz': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 3 },
  'fernandomuslera': { preferredFoot: 'Sağ', weakFoot: 2, skillMoves: 1 },
  'ugurcancakir': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 1 },
  'gunayguvenc': { preferredFoot: 'Sağ', weakFoot: 2, skillMoves: 1 },
  'lucastorreira': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },
  'ilkaygundogan': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 4 },
  'gabrielsara': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 3 },
  'davinsonsanchez': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 2 },
  'abdulkerimbardakci': { preferredFoot: 'Sol', weakFoot: 2, skillMoves: 2 },
  'victornelsson': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 2 },
  'erenelmali': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 2 },
  'wilfriedsingo': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },
  'kaanayhan': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 2 },
  'keremdemirbay': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 3 },
  'berkanismailkutlu': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 2 },
  'yunusakgun': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 4 },
  'ahmetcalik': { preferredFoot: 'Sağ', weakFoot: 2, skillMoves: 2 },

  // --- FENERBAHÇE ---
  'edindzeko': { preferredFoot: 'Her İkisi', weakFoot: 5, skillMoves: 3 },
  'dusanstadic': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 4 },
  'sebastianfszymanski': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 3 },
  'fred': { preferredFoot: 'Sol', weakFoot: 4, skillMoves: 4 },
  'youssefen-nesyri': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 3 },
  'dominiklivakovic': { preferredFoot: 'Sağ', weakFoot: 2, skillMoves: 1 },
  'irfancankahveci': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 4 },
  'cengizunder': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 4 },
  'allanfsaint-maximin': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 5 },
  'alexanderdjiku': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 2 },
  'rodrigofrbecao': { preferredFoot: 'Sağ', weakFoot: 2, skillMoves: 2 },
  'caglarsoyuncu': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 2 },
  'jaydenoosterwolde': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 3 },
  'mertmuldur': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 3 },
  'brightosayi-samuel': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },
  'sofyanamrabat': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },
  'ismailfyuksek': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },

  // --- BEŞİKTAŞ ---
  'ciroimmobile': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 3 },
  'rafasilva': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 4 },
  'gedsonfernandes': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 4 },
  'mertgunok': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 1 },
  'semihkilicsoy': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 3 },
  'gabrielpaulista': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 2 },
  'felixuduokhai': { preferredFoot: 'Sol', weakFoot: 2, skillMoves: 2 },
  'arthurmasuaku': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 3 },
  'jonassvensson': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },
  'al-musrati': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },
  'milotrashica': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 3 },
  'ernadmucı': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 4 },
  'joaomario': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },

  // --- TRABZONSPOR ---
  'paulonuachu': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 2 },
  'anthonynwakaeme': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 4 },
  'edinvisca': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 3 },
  'simonbanza': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },
  'stefansavic': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 2 },
  'denisdragus': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },
  'okanyokuslu': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },

  // --- WORLD SUPERSTARS ---
  'lionelmessi': { preferredFoot: 'Sol', weakFoot: 4, skillMoves: 4 },
  'cristianoronaldo': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 5 },
  'kylianmbappe': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 5 },
  'erlinghaaland': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 3 },
  'kevindebruyne': { preferredFoot: 'Sağ', weakFoot: 5, skillMoves: 4 },
  'viniciusjunior': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 5 },
  'judeffbellingham': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 4 },
  'mohamedfsalah': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 4 },
  'lamineyamal': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 5 },
  'robertlewandowski': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 4 },
  'harrykane': { preferredFoot: 'Her İkisi', weakFoot: 5, skillMoves: 3 },
  'rodri': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 3 },
  'neymarjr': { preferredFoot: 'Her İkisi', weakFoot: 5, skillMoves: 5 },
  'neymar': { preferredFoot: 'Her İkisi', weakFoot: 5, skillMoves: 5 },
  'sonheung-min': { preferredFoot: 'Her İkisi', weakFoot: 5, skillMoves: 4 },
  'ousmanedembele': { preferredFoot: 'Her İkisi', weakFoot: 5, skillMoves: 5 },
  'jamalmusiala': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 5 },
  'florianwirtz': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 4 },
  'lautaromartinez': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 4 },
  'nicoloftbarella': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },
  'rafaelleao': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 5 },
  'theobernandez': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 3 },
  'thibautcourtois': { preferredFoot: 'Sol', weakFoot: 2, skillMoves: 1 },
  'alisson': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 1 },
  'ederson': { preferredFoot: 'Sol', weakFoot: 3, skillMoves: 1 },
  'janoblak': { preferredFoot: 'Sağ', weakFoot: 2, skillMoves: 1 },
  'manuelneuer': { preferredFoot: 'Her İkisi', weakFoot: 4, skillMoves: 1 },
  'pedri': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 4 },
  'gavi': { preferredFoot: 'Sağ', weakFoot: 3, skillMoves: 3 },
  'federicovalverde': { preferredFoot: 'Sağ', weakFoot: 4, skillMoves: 3 },
  'lukamodric': { preferredFoot: 'Her İkisi', weakFoot: 4, skillMoves: 4 },
  'toniikroos': { preferredFoot: 'Her İkisi', weakFoot: 5, skillMoves: 3 }
};

const normalizeNameKey = (name: string): string => {
  if (!name) return '';
  return name
    .toLowerCase()
    .trim()
    .replace(/ı/g, 'i')
    .replace(/ğ/g, 'g')
    .replace(/ş/g, 's')
    .replace(/ç/g, 'c')
    .replace(/ö/g, 'o')
    .replace(/ü/g, 'u')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '');
};

export const getPlayerFootAndSkills = (player: Player): PlayerFootAndSkills => {
  const normKey = normalizeNameKey(player.name);

  // 1. Direct database match
  if (KNOWN_PLAYERS_FOOT_SKILLS[normKey]) {
    return KNOWN_PLAYERS_FOOT_SKILLS[normKey];
  }

  // 2. If preferredFoot is explicitly defined in player object
  let foot: 'Sağ' | 'Sol' | 'Her İkisi' = 'Sağ';
  if (player.preferredFoot) {
    if (player.preferredFoot === 'Sol' || player.preferredFoot === 'Left') foot = 'Sol';
    else if (player.preferredFoot === 'Her İkisi' || player.preferredFoot === 'Both') foot = 'Her İkisi';
    else foot = 'Sağ';
  } else {
    // Deterministic foot derivation
    const role = (player.specificRole || '').toUpperCase();
    const hash = (player.id + player.name).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);

    if (['LB', 'LWB', 'LM', 'LW'].includes(role)) {
      foot = (hash % 10 < 8) ? 'Sol' : 'Sağ';
    } else if (['RB', 'RWB', 'RM', 'RW'].includes(role)) {
      foot = (hash % 10 < 8) ? 'Sağ' : 'Sol';
    } else if (['CB'].includes(role)) {
      foot = (hash % 10 < 3) ? 'Sol' : 'Sağ';
    } else {
      foot = (hash % 20 === 0) ? 'Her İkisi' : (hash % 10 < 3) ? 'Sol' : 'Sağ';
    }
  }

  // Skill moves calculation
  let skillMoves = 3;
  const pos = player.position;
  const role = (player.specificRole || '').toUpperCase();
  const hash = (player.id + player.name).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);

  if (pos === 'GK') {
    skillMoves = 1;
  } else if (pos === 'DEF') {
    if (['LB', 'RB', 'LWB', 'RWB'].includes(role)) {
      skillMoves = player.attributes.pace >= 80 ? 3 : 2;
    } else {
      skillMoves = 2;
    }
  } else if (pos === 'MID') {
    if (['CAM', 'LM', 'RM'].includes(role)) {
      skillMoves = (player.overall >= 84 || player.attributes.pace >= 85) ? 4 : 3;
    } else {
      skillMoves = (player.attributes.passing >= 84) ? 4 : 3;
    }
  } else {
    // FW
    if (['LW', 'RW'].includes(role)) {
      skillMoves = (player.overall >= 84 || player.attributes.pace >= 90) ? 5 : 4;
    } else {
      skillMoves = (player.overall >= 84) ? 4 : 3;
    }
  }

  // Weak foot calculation
  let weakFoot = 3;
  if (foot === 'Her İkisi') {
    weakFoot = 5;
  } else if (pos === 'GK') {
    weakFoot = (hash % 4 === 0) ? 3 : 2;
  } else if (pos === 'DEF') {
    weakFoot = (player.attributes.passing >= 78) ? 3 : 2;
  } else if (pos === 'MID') {
    weakFoot = (player.attributes.passing >= 82 || player.attributes.shooting >= 80) ? 4 : (hash % 5 === 0 ? 4 : 3);
  } else {
    // FW
    weakFoot = (player.attributes.shooting >= 84) ? 4 : (hash % 4 === 0 ? 4 : 3);
  }

  return {
    preferredFoot: foot,
    weakFoot: Math.min(5, Math.max(1, weakFoot)),
    skillMoves: Math.min(5, Math.max(1, skillMoves))
  };
};

/**
 * Returns exact slot information for any formation
 */
export const getSlotDetailedInfo = (
  index: number,
  formation: FormationType = '4-2-3-1'
): { category: 'GK' | 'DEF' | 'MID' | 'FW'; slotRole: string; fmmCode: string } => {
  if (index === 0) return { category: 'GK', slotRole: 'GK', fmmCode: 'KL' };

  switch (formation) {
    case '4-2-3-1':
      if (index === 1) return { category: 'DEF', slotRole: 'LB', fmmCode: 'SLB' };
      if (index === 2) return { category: 'DEF', slotRole: 'CB', fmmCode: 'SS' };
      if (index === 3) return { category: 'DEF', slotRole: 'CB', fmmCode: 'SS' };
      if (index === 4) return { category: 'DEF', slotRole: 'RB', fmmCode: 'SĞB' };
      if (index === 5) return { category: 'MID', slotRole: 'CDM', fmmCode: 'DOS' };
      if (index === 6) return { category: 'MID', slotRole: 'CDM', fmmCode: 'DOS' };
      if (index === 7) return { category: 'MID', slotRole: 'LW', fmmCode: 'SLK' };
      if (index === 8) return { category: 'MID', slotRole: 'CAM', fmmCode: 'OOS' };
      if (index === 9) return { category: 'MID', slotRole: 'RW', fmmCode: 'SGK' };
      return { category: 'FW', slotRole: 'ST', fmmCode: 'SF' };

    case '4-3-3':
      if (index === 1) return { category: 'DEF', slotRole: 'LB', fmmCode: 'SLB' };
      if (index === 2) return { category: 'DEF', slotRole: 'CB', fmmCode: 'SS' };
      if (index === 3) return { category: 'DEF', slotRole: 'CB', fmmCode: 'SS' };
      if (index === 4) return { category: 'DEF', slotRole: 'RB', fmmCode: 'SĞB' };
      if (index === 5) return { category: 'MID', slotRole: 'CM', fmmCode: 'OS' };
      if (index === 6) return { category: 'MID', slotRole: 'CDM', fmmCode: 'DOS' };
      if (index === 7) return { category: 'MID', slotRole: 'CM', fmmCode: 'OS' };
      if (index === 8) return { category: 'FW', slotRole: 'LW', fmmCode: 'SLK' };
      if (index === 9) return { category: 'FW', slotRole: 'ST', fmmCode: 'SF' };
      return { category: 'FW', slotRole: 'RW', fmmCode: 'SGK' };

    case '4-4-2':
      if (index === 1) return { category: 'DEF', slotRole: 'LB', fmmCode: 'SLB' };
      if (index === 2) return { category: 'DEF', slotRole: 'CB', fmmCode: 'SS' };
      if (index === 3) return { category: 'DEF', slotRole: 'CB', fmmCode: 'SS' };
      if (index === 4) return { category: 'DEF', slotRole: 'RB', fmmCode: 'SĞB' };
      if (index === 5) return { category: 'MID', slotRole: 'LM', fmmCode: 'SLK' };
      if (index === 6) return { category: 'MID', slotRole: 'CM', fmmCode: 'OS' };
      if (index === 7) return { category: 'MID', slotRole: 'CM', fmmCode: 'OS' };
      if (index === 8) return { category: 'MID', slotRole: 'RM', fmmCode: 'SGK' };
      if (index === 9) return { category: 'FW', slotRole: 'ST', fmmCode: 'SF' };
      return { category: 'FW', slotRole: 'ST', fmmCode: 'SF' };

    case '3-5-2':
      if (index >= 1 && index <= 3) return { category: 'DEF', slotRole: 'CB', fmmCode: 'SS' };
      if (index === 4) return { category: 'MID', slotRole: 'LM', fmmCode: 'SLK' };
      if (index === 5) return { category: 'MID', slotRole: 'CDM', fmmCode: 'DOS' };
      if (index === 6) return { category: 'MID', slotRole: 'CAM', fmmCode: 'OOS' };
      if (index === 7) return { category: 'MID', slotRole: 'CDM', fmmCode: 'DOS' };
      if (index === 8) return { category: 'MID', slotRole: 'RM', fmmCode: 'SGK' };
      return { category: 'FW', slotRole: 'ST', fmmCode: 'SF' };

    case '5-3-2':
      if (index === 1) return { category: 'DEF', slotRole: 'LB', fmmCode: 'SLB' };
      if (index >= 2 && index <= 4) return { category: 'DEF', slotRole: 'CB', fmmCode: 'SS' };
      if (index === 5) return { category: 'DEF', slotRole: 'RB', fmmCode: 'SĞB' };
      if (index >= 6 && index <= 8) return { category: 'MID', slotRole: 'CM', fmmCode: 'OS' };
      return { category: 'FW', slotRole: 'ST', fmmCode: 'SF' };

    case '4-1-4-1':
      if (index === 1) return { category: 'DEF', slotRole: 'LB', fmmCode: 'SLB' };
      if (index === 2 || index === 3) return { category: 'DEF', slotRole: 'CB', fmmCode: 'SS' };
      if (index === 4) return { category: 'DEF', slotRole: 'RB', fmmCode: 'SĞB' };
      if (index === 5) return { category: 'MID', slotRole: 'CDM', fmmCode: 'DOS' };
      if (index === 6) return { category: 'MID', slotRole: 'LM', fmmCode: 'SLK' };
      if (index === 7 || index === 8) return { category: 'MID', slotRole: 'CM', fmmCode: 'OS' };
      if (index === 9) return { category: 'MID', slotRole: 'RM', fmmCode: 'SGK' };
      return { category: 'FW', slotRole: 'ST', fmmCode: 'SF' };

    case '3-4-3':
      if (index >= 1 && index <= 3) return { category: 'DEF', slotRole: 'CB', fmmCode: 'SS' };
      if (index === 4) return { category: 'MID', slotRole: 'LM', fmmCode: 'SLK' };
      if (index === 5 || index === 6) return { category: 'MID', slotRole: 'CM', fmmCode: 'OS' };
      if (index === 7) return { category: 'MID', slotRole: 'RM', fmmCode: 'SGK' };
      if (index === 8) return { category: 'FW', slotRole: 'LW', fmmCode: 'SLK' };
      if (index === 9) return { category: 'FW', slotRole: 'ST', fmmCode: 'SF' };
      return { category: 'FW', slotRole: 'RW', fmmCode: 'SGK' };

    default:
      if (index >= 1 && index <= 4) return { category: 'DEF', slotRole: 'CB', fmmCode: 'SS' };
      if (index >= 5 && index <= 8) return { category: 'MID', slotRole: 'CM', fmmCode: 'OS' };
      return { category: 'FW', slotRole: 'ST', fmmCode: 'SF' };
  }
};

/**
 * Evaluates whether a player fits the assigned tactical slot.
 * Sadece gerçekten imkansız mevkilerde 'INCOMPATIBLE' (Kırmızı Uyarı) verir:
 * - Saha içi oyuncusu kalede
 * - Kaleci sahada
 * - Defans oyuncusu forvette (ST/CF)
 * - Forvet oyuncusu defansta (CB/LB/RB)
 * - Saf kanat / forvet stoperde (CB)
 */
export const evaluatePlayerPositionFit = (
  player: Player,
  slotIndex: number,
  formation: FormationType = '4-2-3-1'
): PositionEvaluation => {
  const slot = getSlotDetailedInfo(slotIndex, formation);
  const playerPos = player.position;
  const playerRole = (player.specificRole || player.position).toUpperCase();
  const slotRole = slot.slotRole.toUpperCase();

  // 1. GOALKEEPER RULES
  if (playerPos === 'GK') {
    if (slot.category === 'GK') {
      return {
        fit: 'NATURAL',
        effectiveOverall: player.overall,
        penalty: 0,
        isRedAlert: false,
        assignedSlotRole: slot.fmmCode,
        assignedSlotCategory: 'GK',
        fitLabel: 'Doğal Mevki'
      };
    } else {
      // Kaleci sahada oynatılıyor -> Kesinlikle Kırmızı Uyarı!
      const penalty = 42;
      return {
        fit: 'INCOMPATIBLE',
        effectiveOverall: Math.max(30, player.overall - penalty),
        penalty,
        isRedAlert: true,
        assignedSlotRole: slot.fmmCode,
        assignedSlotCategory: slot.category,
        fitLabel: 'Mevki Dışı (Kaleci Sahada)'
      };
    }
  }

  // Saha içi oyuncusu kaleye geçti -> Kesinlikle Kırmızı Uyarı!
  if (slot.category === 'GK') {
    const penalty = 46;
    return {
      fit: 'INCOMPATIBLE',
      effectiveOverall: Math.max(30, player.overall - penalty),
      penalty,
      isRedAlert: true,
      assignedSlotRole: 'KL',
      assignedSlotCategory: 'GK',
      fitLabel: 'Mevki Dışı (Kaleci Değil)'
    };
  }

  // 2. DEFENDER AT STRIKER / FORWARD (Defans Forvette) -> Kesinlikle Kırmızı Uyarı!
  if (playerPos === 'DEF' && (slot.category === 'FW' || slotRole === 'ST' || slotRole === 'CF')) {
    const penalty = 24;
    return {
      fit: 'INCOMPATIBLE',
      effectiveOverall: Math.max(35, player.overall - penalty),
      penalty,
      isRedAlert: true,
      assignedSlotRole: slot.fmmCode,
      assignedSlotCategory: 'FW',
      fitLabel: 'Mevki Dışı (Defans Forvette)'
    };
  }

  // 3. STRIKER AT DEFENDER (Forvet Defansta) -> Kesinlikle Kırmızı Uyarı!
  if (playerPos === 'FW' && (slot.category === 'DEF' || slotRole === 'CB' || slotRole === 'LB' || slotRole === 'RB')) {
    const penalty = 26;
    return {
      fit: 'INCOMPATIBLE',
      effectiveOverall: Math.max(35, player.overall - penalty),
      penalty,
      isRedAlert: true,
      assignedSlotRole: slot.fmmCode,
      assignedSlotCategory: 'DEF',
      fitLabel: 'Mevki Dışı (Forvet Defansta)'
    };
  }

  // 4. NATURAL POSITIONS (Tam Uyum - Doğal Mevki)
  // Sadece tam aynı mevki veya doğal ikiz mevki (LB/LWB, RB/RWB)
  if (
    playerRole === slotRole ||
    (['LB', 'LWB'].includes(playerRole) && ['LB', 'LWB'].includes(slotRole)) ||
    (['RB', 'RWB'].includes(playerRole) && ['RB', 'RWB'].includes(slotRole))
  ) {
    return {
      fit: 'NATURAL',
      effectiveOverall: player.overall,
      penalty: 0,
      isRedAlert: false,
      assignedSlotRole: slot.fmmCode,
      assignedSlotCategory: slot.category,
      fitLabel: 'Doğal Mevki'
    };
  }

  // 5. COMPETENT POSITIONS (Yan Mevki / Oynayabilir - OVR Düşüşü Uygulanır)
  // Örn: Kanat (RW <-> LW / RM / LM)
  const isWingAttacker = ['RW', 'LW', 'RM', 'LM'].includes(playerRole);
  const isTargetSlotWingOrAttacking = ['RW', 'LW', 'RM', 'LM', 'CAM', 'ST', 'CF'].includes(slotRole);

  if (isWingAttacker && isTargetSlotWingOrAttacking) {
    const penalty = (slotRole === 'RW' && playerRole === 'LW') || (slotRole === 'LW' && playerRole === 'RW') 
      ? 5 
      : slotRole === 'ST' ? 8 : 6;
    return {
      fit: 'COMPETENT',
      effectiveOverall: Math.max(35, player.overall - penalty),
      penalty,
      isRedAlert: false,
      assignedSlotRole: slot.fmmCode,
      assignedSlotCategory: slot.category,
      fitLabel: 'İkincil Mevki'
    };
  }

  // Bek (LB/RB) kanat orta sahada (LM/RM) veya stoperde (CB) oynuyor
  const isFullback = ['LB', 'RB', 'LWB', 'RWB'].includes(playerRole);
  if (isFullback && (['LM', 'RM', 'CB', 'CDM'].includes(slotRole) || slot.category === 'DEF')) {
    const penalty = slotRole === 'CB' ? 6 : 7;
    return {
      fit: 'COMPETENT',
      effectiveOverall: Math.max(35, player.overall - penalty),
      penalty,
      isRedAlert: false,
      assignedSlotRole: slot.fmmCode,
      assignedSlotCategory: slot.category,
      fitLabel: 'İkincil Mevki'
    };
  }

  // Stoper (CB) bekte veya ön liberoda oynuyor
  if (playerRole === 'CB' && ['LB', 'RB', 'CDM'].includes(slotRole)) {
    const penalty = 7;
    return {
      fit: 'COMPETENT',
      effectiveOverall: Math.max(35, player.overall - penalty),
      penalty,
      isRedAlert: false,
      assignedSlotRole: slot.fmmCode,
      assignedSlotCategory: slot.category,
      fitLabel: 'İkincil Mevki'
    };
  }

  // Orta saha (CM/CAM/CDM) forvet arkasında veya kanatta oynuyor
  const isMidfielder = ['CM', 'CAM', 'CDM'].includes(playerRole) || playerPos === 'MID';
  if (isMidfielder && ['CAM', 'CM', 'CDM', 'LM', 'RM', 'LW', 'RW'].includes(slotRole)) {
    const penalty = (playerRole === 'CDM' && slotRole === 'CAM') || (playerRole === 'CAM' && slotRole === 'CDM') ? 7 : 5;
    return {
      fit: 'COMPETENT',
      effectiveOverall: Math.max(35, player.overall - penalty),
      penalty,
      isRedAlert: false,
      assignedSlotRole: slot.fmmCode,
      assignedSlotCategory: slot.category,
      fitLabel: 'İkincil Mevki'
    };
  }

  // Santrafor (ST/CF) kanat veya forvet arkasında (CAM/LW/RW) oynuyor
  const isStriker = ['ST', 'CF'].includes(playerRole);
  if (isStriker && ['CAM', 'LW', 'RW', 'SS'].includes(slotRole)) {
    const penalty = 6;
    return {
      fit: 'COMPETENT',
      effectiveOverall: Math.max(35, player.overall - penalty),
      penalty,
      isRedAlert: false,
      assignedSlotRole: slot.fmmCode,
      assignedSlotCategory: slot.category,
      fitLabel: 'İkincil Mevki'
    };
  }

  // Orta saha oyuncusu bek veya defansta (Uyumsuz)
  if (playerPos === 'MID' && slot.category === 'DEF') {
    const penalty = 12;
    return {
      fit: 'UNCOMFORTABLE',
      effectiveOverall: Math.max(35, player.overall - penalty),
      penalty,
      isRedAlert: false,
      assignedSlotRole: slot.fmmCode,
      assignedSlotCategory: slot.category,
      fitLabel: 'Uyumsuz Mevki'
    };
  }

  // Defans oyuncusu orta sahada (Uyumsuz)
  if (playerPos === 'DEF' && slot.category === 'MID') {
    const penalty = 11;
    return {
      fit: 'UNCOMFORTABLE',
      effectiveOverall: Math.max(35, player.overall - penalty),
      penalty,
      isRedAlert: false,
      assignedSlotRole: slot.fmmCode,
      assignedSlotCategory: slot.category,
      fitLabel: 'Uyumsuz Mevki'
    };
  }

  // Genel komşu bölgeler (kırmızı değil, belirgin ceza)
  return {
    fit: 'COMPETENT',
    effectiveOverall: Math.max(35, player.overall - 6),
    penalty: 6,
    isRedAlert: false,
    assignedSlotRole: slot.fmmCode,
    assignedSlotCategory: slot.category,
    fitLabel: 'Uyumlu'
  };
};
