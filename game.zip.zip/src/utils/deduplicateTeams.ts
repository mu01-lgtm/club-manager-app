import { Team, Player } from '../types';
import { getTeamLogoUrl } from '../data/teamLogos';
import { ensureTeamHas20Players } from './squadExpander';

/**
 * Ensures that every player across all teams exists in EXACTLY ONE team.
 * If a player with the same name appears in multiple teams,
 * the player is retained in their first/primary team, and deduplicated in subsequent teams.
 * After deduplicating, guarantees that EVERY team has at least 18-20 players with no duplicate names.
 */
export function deduplicateAndEnrichTeams(teams: Team[]): Team[] {
  const seenPlayerNames = new Set<string>();
  const seenPlayerIds = new Set<string>();

  const cleanedTeams = teams.map(team => {
    const updatedPlayers: Player[] = [];

    for (const player of team.players || []) {
      const normalizedName = (player.name || '')
        .trim()
        .toLowerCase()
        .replace(/ç/g, 'c')
        .replace(/ğ/g, 'g')
        .replace(/ı/g, 'i')
        .replace(/ö/g, 'o')
        .replace(/ş/g, 's')
        .replace(/ü/g, 'u');

      if (!normalizedName || seenPlayerNames.has(normalizedName)) {
        // Duplicate player name detected across teams - skip duplicate
        continue;
      }

      seenPlayerNames.add(normalizedName);

      let pId = player.id;
      if (seenPlayerIds.has(pId)) {
        pId = `${player.id}-${team.id}-${Math.random().toString(36).substr(2, 4)}`;
      }
      seenPlayerIds.add(pId);

      updatedPlayers.push({
        ...player,
        id: pId
      });
    }

    const logoUrl = team.logoUrl || getTeamLogoUrl(team.name || team.id);

    return {
      ...team,
      logoUrl,
      players: updatedPlayers
    };
  });

  // Ensure each team has at least 20 players without duplicates
  return cleanedTeams.map(t => ensureTeamHas20Players(t));
}

