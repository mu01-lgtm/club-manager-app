import { Team, LeagueRow, Fixture, GameMode, CreatedPlayerProfile, Scout, ScoutReport, InboxMessage, PendingBuyOffer } from '../types';

export interface SaveSlotData {
  saveDate: string;        // Timestamp e.g. "09.08.2026 14:30"
  gameDateStr: string;     // e.g. "1. Sezon, 4. Hafta"
  currentWeek: number;
  currentSeason: number;
  currentDayIndex: number;
  allTeams: Team[];
  standings: LeagueRow[];
  fixtures: Fixture[];
  scouts?: Scout[];
  scoutReports?: ScoutReport[];
  inboxMessages?: InboxMessage[];
  pendingBuyOffers?: PendingBuyOffer[];
  pendingTransferArrivals?: any[];
  gameMode?: GameMode;
  createdPlayer?: CreatedPlayerProfile | null;
  managerName: string;
  teamId: string;
}

export interface CareerSave {
  id: string;              // Unique career ID e.g. "career_1723180000000"
  saveName: string;        // Custom save file name e.g. "Galatasaray Efsanesi"
  managerName: string;
  teamId: string;
  gameMode: GameMode;
  createdPlayer?: CreatedPlayerProfile | null;
  createdAt: string;       // Timestamp string
  lastPlayedAt: string;    // Timestamp string
  normalSave?: SaveSlotData | null; // Manuel Kayıt
  autoSave?: SaveSlotData | null;   // Otomatik Kayıt
}

const STORAGE_KEY = 'fmm_saved_careers';
const LEGACY_STORAGE_KEY = 'fmm_saved_games';

export function formatCurrentRealDate(): string {
  const now = new Date();
  const day = String(now.getDate()).padStart(2, '0');
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const year = now.getFullYear();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  return `${day}.${month}.${year} ${hours}:${minutes}`;
}

export function getAllCareers(): CareerSave[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }

    // Check legacy storage migration
    const legacyRaw = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacyRaw) {
      const legacyParsed = JSON.parse(legacyRaw);
      if (Array.isArray(legacyParsed) && legacyParsed.length > 0) {
        const converted: CareerSave[] = legacyParsed.map((legacy: any, idx: number) => {
          const gameDateStr = `${legacy.currentSeason || 1}. Sezon, ${legacy.currentWeek || 1}. Hafta`;
          const slot: SaveSlotData = {
            saveDate: legacy.saveDate || formatCurrentRealDate(),
            gameDateStr,
            currentWeek: legacy.currentWeek || 1,
            currentSeason: legacy.currentSeason || 1,
            currentDayIndex: 0,
            allTeams: legacy.allTeams || [],
            standings: legacy.standings || [],
            fixtures: legacy.fixtures || [],
            gameMode: legacy.gameMode || 'MANAGER',
            createdPlayer: legacy.createdPlayer || null,
            managerName: legacy.managerName || 'Menajer',
            teamId: legacy.teamId || 'galatasaray'
          };

          return {
            id: legacy.id || `career_legacy_${idx}_${Date.now()}`,
            saveName: legacy.saveName || `${legacy.managerName || 'Menajer'} Kariyeri`,
            managerName: legacy.managerName || 'Menajer',
            teamId: legacy.teamId || 'galatasaray',
            gameMode: legacy.gameMode || 'MANAGER',
            createdPlayer: legacy.createdPlayer || null,
            createdAt: legacy.saveDate || formatCurrentRealDate(),
            lastPlayedAt: legacy.saveDate || formatCurrentRealDate(),
            normalSave: slot,
            autoSave: slot
          };
        });

        localStorage.setItem(STORAGE_KEY, JSON.stringify(converted));
        return converted;
      }
    }
  } catch (err) {
    console.error('Save system loading error:', err);
  }
  return [];
}

export function saveCareerSlot(
  careerId: string,
  saveName: string,
  slotType: 'NORMAL' | 'AUTO',
  slotData: SaveSlotData
): CareerSave[] {
  const careers = getAllCareers();
  const nowStr = formatCurrentRealDate();
  const existingIndex = careers.findIndex(c => c.id === careerId);

  let targetCareer: CareerSave;

  if (existingIndex >= 0) {
    targetCareer = { ...careers[existingIndex] };
  } else {
    targetCareer = {
      id: careerId,
      saveName: saveName.trim() || `${slotData.managerName} Kariyeri`,
      managerName: slotData.managerName,
      teamId: slotData.teamId,
      gameMode: slotData.gameMode || 'MANAGER',
      createdPlayer: slotData.createdPlayer || null,
      createdAt: nowStr,
      lastPlayedAt: nowStr
    };
  }

  if (saveName && saveName.trim()) {
    targetCareer.saveName = saveName.trim();
  }

  targetCareer.lastPlayedAt = nowStr;

  const slotEntry: SaveSlotData = {
    ...slotData,
    saveDate: nowStr,
    gameDateStr: `${slotData.currentSeason}. Sezon, ${slotData.currentWeek}. Hafta`
  };

  if (slotType === 'NORMAL') {
    targetCareer.normalSave = slotEntry;
  } else {
    targetCareer.autoSave = slotEntry;
  }

  if (existingIndex >= 0) {
    careers[existingIndex] = targetCareer;
  } else {
    careers.unshift(targetCareer);
  }

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(careers));

    // Keep legacy array synced for backwards compatibility
    const legacyList = careers.map(c => {
      const activeSlot = c.normalSave || c.autoSave;
      return {
        id: c.id,
        saveName: c.saveName,
        saveDate: activeSlot?.saveDate || c.lastPlayedAt,
        managerName: c.managerName,
        teamId: c.teamId,
        currentWeek: activeSlot?.currentWeek || 1,
        currentSeason: activeSlot?.currentSeason || 1,
        allTeams: activeSlot?.allTeams || [],
        standings: activeSlot?.standings || [],
        fixtures: activeSlot?.fixtures || [],
        gameMode: c.gameMode,
        createdPlayer: c.createdPlayer
      };
    });
    localStorage.setItem(LEGACY_STORAGE_KEY, JSON.stringify(legacyList));
  } catch (err) {
    console.error('Error saving career slot:', err);
  }

  return careers;
}

export function deleteCareer(careerId: string): CareerSave[] {
  const careers = getAllCareers().filter(c => c.id !== careerId);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(careers));
    localStorage.setItem(LEGACY_STORAGE_KEY, JSON.stringify(careers.map(c => ({ id: c.id, saveName: c.saveName }))));
  } catch (err) {
    console.error('Error deleting career:', err);
  }
  return careers;
}

export function deleteCareerSlot(careerId: string, slotType: 'NORMAL' | 'AUTO'): CareerSave[] {
  const careers = getAllCareers().map(c => {
    if (c.id !== careerId) return c;
    const updated = { ...c };
    if (slotType === 'NORMAL') updated.normalSave = null;
    if (slotType === 'AUTO') updated.autoSave = null;
    return updated;
  });

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(careers));
  } catch (err) {
    console.error('Error deleting career slot:', err);
  }
  return careers;
}
