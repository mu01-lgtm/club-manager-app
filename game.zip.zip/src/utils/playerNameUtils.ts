// Helper to get 1-word recognized "known" pitch name for any player
export const KNOWN_NAMES_MAP: Record<string, string> = {
  // Galatasaray
  'Fernando Muslera': 'Muslera',
  'Uğurcan Çakır': 'Uğurcan',
  'Mauro Icardi': 'Icardi',
  'Victor Osimhen': 'Osimhen',
  'Barış Alper Yılmaz': 'Barış',
  'Kerem Aktürkoğlu': 'Kerem',
  'Yunus Akgün': 'Yunus',
  'Lucas Torreira': 'Torreira',
  'Gabriel Sara': 'Sara',
  'Dries Mertens': 'Mertens',
  'Davinson Sánchez': 'Sánchez',
  'Abdülkerim Bardakcı': 'Bardakcı',
  'Eren Elmalı': 'Eren',
  'Wilfried Zaha': 'Zaha',
  'Hakim Ziyech': 'Ziyech',
  'Kaan Ayhan': 'Kaan',
  'Berkan Kutlu': 'Berkan',
  'Victor Nelsson': 'Nelsson',
  'Elias Jelert': 'Jelert',
  'Michy Batshuayi': 'Batshuayi',
  'Roland Sallai': 'Sallai',
  'İsmail Jakobs': 'Jakobs',
  'Günay Güvenç': 'Günay',
  'Eyüp Aydın': 'Eyüp',
  'Ali Turap Bülbül': 'Ali',
  'Efe Akman': 'Efe',

  // Fenerbahçe
  'Edin Dzeko': 'Dzeko',
  'Dusan Tadic': 'Tadic',
  'Fred': 'Fred',
  'Sebastian Szymanski': 'Szymanski',
  'Youssef En-Nesyri': 'En-Nesyri',
  'Dominik Livakovic': 'Livakovic',
  'Ferdi Kadıoğlu': 'Ferdi',
  'İrfan Can Kahveci': 'İrfan',
  'İsmail Yüksek': 'İsmail',
  'Cengiz Ünder': 'Cengiz',
  'Alexander Djiku': 'Djiku',
  'Jayden Oosterwolde': 'Oosterwolde',
  'Rodrigo Becao': 'Becao',
  'Çağlar Söyüncü': 'Çağlar',
  'Mert Müldür': 'Mert',
  'Bright Osayi-Samuel': 'Osayi',
  'Sofyan Amrabat': 'Amrabat',
  'Allan Saint-Maximin': 'Maximin',
  'Cenk Tosun': 'Cenk',
  'Mert Hakan Yandaş': 'Mert Hakan',
  'Oğuz Aydın': 'Oğuz',
  'Levent Mercan': 'Levent',
  'İrfan Can Eğribayat': 'İrfan Can',
  'Bartuğ Elmaz': 'Bartuğ',

  // Beşiktaş
  'Ciro Immobile': 'Immobile',
  'Rafa Silva': 'Rafa',
  'Gedson Fernandes': 'Gedson',
  'Semih Kılıçsoy': 'Semih',
  'Milot Rashica': 'Rashica',
  'Gabriel Paulista': 'Paulista',
  'Felix Uduokhai': 'Uduokhai',
  'Arthur Masuaku': 'Masuaku',
  'Mert Günok': 'Mert',
  'Ernest Muci': 'Muci',
  'Al-Musrati': 'Musrati',
  'Cher Ndour': 'Ndour',
  'Joao Mario': 'Mario',
  'Necip Uysal': 'Necip',
  'Salih Uçan': 'Salih',
  'Ersin Destanoğlu': 'Ersin',
  'Tayyip Talha Sanuç': 'Tayyip',
  'Emirhan Topçu': 'Emirhan',
  'Jonas Svensson': 'Svensson',
  'Mustafa Erhan Hekimoğlu': 'Mustafa',
  'Bakhtiyor Zaynutdinov': 'Bakhtiyor',
  'Onur Bulut': 'Onur',

  // Trabzonspor
  'Simon Banza': 'Banza',
  'Edin Visca': 'Visca',
  'Anthony Nwakaeme': 'Nwakaeme',
  'Enis Destan': 'Enis',
  'Okay Yokuşlu': 'Okay',
  'Ozan Tufan': 'Ozan',
  'Denis Dragus': 'Dragus',
  'Stefan Savic': 'Savic',
  'Arseniy Batagov': 'Batagov',
  'Pedro Malheiro': 'Malheiro',
  'Borna Barisic': 'Barisic',
  'John Lundstram': 'Lundstram',
  'Muhammed Cham': 'Cham',
  'Stefano Denswil': 'Denswil',
  'Enis Bardhi': 'Bardhi',
  'Umut Güneş': 'Umut',
  'Batuhan Şen': 'Batuhan',
  'Cihan Çanak': 'Cihan',

  // Real Madrid
  'Kylian Mbappé': 'Mbappé',
  'Vinícius Júnior': 'Vinícius',
  'Rodrygo': 'Rodrygo',
  'Jude Bellingham': 'Bellingham',
  'Federico Valverde': 'Valverde',
  'Eduardo Camavinga': 'Camavinga',
  'Aurélien Tchouaméni': 'Tchouaméni',
  'Luka Modric': 'Modric',
  'Arda Güler': 'Arda',
  'Brahim Díaz': 'Brahim',
  'Endrick': 'Endrick',
  'Dani Carvajal': 'Carvajal',
  'Éder Militão': 'Militão',
  'Antonio Rüdiger': 'Rüdiger',
  'David Alaba': 'Alaba',
  'Ferland Mendy': 'Mendy',
  'Thibaut Courtois': 'Courtois',
  'Andriy Lunin': 'Lunin',
  'Lucas Vázquez': 'Lucas',
  'Trent Alexander-Arnold': 'Arnold',
  'Raúl Asencio': 'Asencio',
  'Fran García': 'Fran',
  'Dani Ceballos': 'Ceballos',

  // Arsenal
  'Bukayo Saka': 'Saka',
  'Gabriel Martinelli': 'Martinelli',
  'Kai Havertz': 'Havertz',
  'Martin Ødegaard': 'Ødegaard',
  'Declan Rice': 'Rice',
  'Mikel Merino': 'Merino',
  'Thomas Partey': 'Partey',
  'Jorginho': 'Jorginho',
  'Gabriel Jesus': 'Jesus',
  'Leandro Trossard': 'Trossard',
  'Raheem Sterling': 'Sterling',
  'William Saliba': 'Saliba',
  'Gabriel Magalhães': 'Gabriel',
  'Ben White': 'White',
  'Jurriën Timber': 'Timber',
  'Riccardo Calafiori': 'Calafiori',
  'David Raya': 'Raya',
  'Oleksandr Zinchenko': 'Zinchenko',
  'Takehiro Tomiyasu': 'Tomiyasu',
  'Kieran Tierney': 'Tierney',
  'Jakub Kiwior': 'Kiwior',
  'Neto': 'Neto',

  // World Stars
  'Erling Haaland': 'Haaland',
  'Kevin De Bruyne': 'De Bruyne',
  'Rodri': 'Rodri',
  'Phil Foden': 'Foden',
  'Bernardo Silva': 'Bernardo',
  'Rúben Dias': 'Dias',
  'Ederson': 'Ederson',
  'Mohamed Salah': 'Salah',
  'Virgil van Dijk': 'Van Dijk',
  'Alisson Becker': 'Alisson',
  'Lamine Yamal': 'Yamal',
  'Robert Lewandowski': 'Lewandowski',
  'Pedri': 'Pedri',
  'Gavi': 'Gavi',
  'Raphinha': 'Raphinha',
  'Frenkie de Jong': 'De Jong',
  'Marc-André ter Stegen': 'Ter Stegen',
  'Harry Kane': 'Kane',
  'Jamal Musiala': 'Musiala',
  'Leroy Sané': 'Sané',
  'Manuel Neuer': 'Neuer',
  'Lautaro Martínez': 'Lautaro',
  'Hakan Çalhanoğlu': 'Hakan',
  'Nicolò Barella': 'Barella',
  'Rafael Leão': 'Leão',
  'Theo Hernández': 'Theo',
  'Mike Maignan': 'Maignan',
  'Cristiano Ronaldo': 'Ronaldo',
  'Lionel Messi': 'Messi',
  'Neymar Jr': 'Neymar'
};

export function getKnownPlayerName(fullName: string): string {
  if (!fullName) return '';
  const clean = fullName.trim();
  if (KNOWN_NAMES_MAP[clean]) return KNOWN_NAMES_MAP[clean];

  // Case-insensitive direct map check
  const lower = clean.toLowerCase();
  for (const [key, val] of Object.entries(KNOWN_NAMES_MAP)) {
    if (key.toLowerCase() === lower) return val;
  }

  // Remove any trailing dots or ellipses
  const noEllipsis = clean.replace(/\.{2,}/g, '').trim();

  const parts = noEllipsis.split(/\s+/);
  if (parts.length === 1) return parts[0];

  const first = parts[0];
  const last = parts[parts.length - 1];

  // Known single-name Brazilians / Portuguese / Spanish / Turkish
  const singleNameCandidates = [
    'barış', 'arda', 'kerem', 'yunus', 'ferdi', 'semih', 'ismail', 'cengiz', 'fred',
    'rafa', 'gedson', 'endrick', 'rodrygo', 'pedri', 'gavi', 'neymar', 'vinícius',
    'vinicius', 'militão', 'militao', 'gabriel', 'lucas', 'joao', 'ederson', 'alisson'
  ];
  if (singleNameCandidates.includes(first.toLowerCase())) {
    return first;
  }

  // Turkish common surnames where first name is the defining identity
  const commonTurkishSurnames = [
    'yılmaz', 'kaya', 'demir', 'çelik', 'şahin', 'yıldız', 'yıldırım', 'öztürk',
    'aydın', 'özdemir', 'arslan', 'doğan', 'kılıç', 'aslan', 'çetin', 'kara',
    'koç', 'kurt', 'özkan', 'şimşek', 'erdogan', 'erdoğan', 'çakır'
  ];
  if (commonTurkishSurnames.includes(last.toLowerCase()) && first.length >= 3) {
    return first;
  }

  // Return clean last name with no dots
  return last;
}
