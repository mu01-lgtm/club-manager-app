import { DevImageConfig, DEFAULT_DEV_CONFIG } from '../components/DevPanelModal';

const DB_NAME = 'FMDevPanelDB';
const STORE_NAME = 'dev_configs';
const CONFIG_KEY = 'current_config';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveDevConfigToStorage(config: DevImageConfig): Promise<boolean> {
  // 1. Primary: Save to IndexedDB (Supports unlimited MBs, base64 images, photos)
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.put(config, CONFIG_KEY);
    await new Promise((res, rej) => {
      tx.oncomplete = res;
      tx.onerror = rej;
    });
  } catch (err) {
    console.warn('IndexedDB write failed:', err);
  }

  // 2. Secondary: Save lightweight version to localStorage
  try {
    const lightConfig = { ...config };
    // If base64 data URL is too large for 5MB localStorage quota, save pruned fallback to localStorage
    if (lightConfig.customImageUrl.length > 200000) {
      lightConfig.customImageUrl = '73c9222d-a64f-4980-9a64-1f6df072fc6b.png';
    }
    localStorage.setItem('fm_dev_custom_image_config', JSON.stringify(lightConfig));
  } catch (err) {
    console.error('localStorage quota exceeded:', err);
  }

  return true;
}

export async function loadDevConfigFromStorage(): Promise<DevImageConfig> {
  // 1. Try IndexedDB
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req = store.get(CONFIG_KEY);
    const result = await new Promise<DevImageConfig | null>((resolve) => {
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });
    if (result) {
      return { ...DEFAULT_DEV_CONFIG, ...result };
    }
  } catch (err) {
    console.warn('IndexedDB read failed:', err);
  }

  // 2. Fallback to localStorage
  try {
    const stored = localStorage.getItem('fm_dev_custom_image_config');
    if (stored) {
      return { ...DEFAULT_DEV_CONFIG, ...JSON.parse(stored) };
    }
  } catch (e) {
    console.error('Failed to load from localStorage', e);
  }

  return DEFAULT_DEV_CONFIG;
}

export function getSyncDevConfig(): DevImageConfig {
  try {
    const stored = localStorage.getItem('fm_dev_custom_image_config');
    if (stored) {
      return { ...DEFAULT_DEV_CONFIG, ...JSON.parse(stored) };
    }
  } catch (e) {
    console.error('Sync load failed', e);
  }
  return DEFAULT_DEV_CONFIG;
}
